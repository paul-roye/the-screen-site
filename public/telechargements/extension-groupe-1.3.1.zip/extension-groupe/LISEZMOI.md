# Extension Chrome « The Seat · Party »

Pour tous les joueurs d'une campagne. Quand vous affichez votre feuille de personnage, un bandeau montre les héros de la campagne comme le tableau des joueurs du gestionnaire, avec le même dessin :

- le portrait, avec les **états** en icônes sur son bas (quatre au plus ; l'encombrement en tuile orange, rose quand il est lourd) ; un druide transformé prend le portrait de sa forme ;
- le prénom, puis « espèce · classe » et « sous-classe · historique » ; la forme sauvage d'un druide transformé à leur place ;
- la **santé** en mots (En forme, Ensanglanté, Critique), les jets contre la mort d'un héros à terre, « Mort » ;
- l'**équipement porté** : armes, armure, bouclier, sac équipé, objets magiques équipés (en jaune). Les objets identiques ne font qu'une ligne (« Dagger ×2 » ; deux lots de vingt flèches, « Arrows ×40 ») ;
- ses **compagnons** actifs (onglet Extras), avec leur santé et les états que le MJ leur a posés ;
- l'**inventaire commun** de la campagne, dans une fenêtre (bouton à la boîte) : la bourse et les objets. Elle se glisse par son titre.

Rien ne s'affiche au survol d'une carte. Une bulle donne le texte en entier seulement sur ce qui est coupé faute de place (le nom, l'identité, l'équipement, un compagnon), et le nom d'un état au survol de son icône.

Indépendante du gestionnaire : elle marche sans lui.

## Installer

1. Décompresser le dossier `extension-groupe` quelque part où il restera.
2. Chrome : `chrome://extensions`, activer « Mode développeur », puis « Charger l'extension non empaquetée » sur ce dossier.
3. Être connecté à D&D Beyond dans ce Chrome, ouvrir sa feuille : le bandeau paraît.

Nouvelle version : remplacer le dossier, « Recharger » sur la carte de l'extension, puis recharger la page D&D Beyond.

## En bas ou à gauche, complet ou compact

Par les boutons du bandeau, ou dans les réglages :

- **En bas** : les cartes de front. Le bandeau reste bas (une centaine de pixels) : l'équipement se range à côté de chaque héros et se coupe au-delà de sa place (un « … » le signale, la bulle le donne en entier). La page se termine au-dessus du bandeau.
- **À gauche** : une colonne, les cartes l'une sous l'autre, l'équipement en entier ; la feuille se décale à droite. Sur un écran trop étroit pour la feuille à côté de la colonne (moins de 1 500 px environ), la colonne devient un rail de portraits, avec la couleur de la santé, qui se déploie au survol.
- **Compact** : une ligne par héros (portrait, prénom, santé, états).

Le chevron réduit le bandeau à un petit onglet. À côté des boutons, l'**âge de la dernière lecture** des fiches (relues toutes les 20 s) : un clic les relit tout de suite ; il passe à l'orange quand la lecture date ou a échoué.

## Réglages

Le bouton aux curseurs ; gardés dans ce Chrome.

- **Position** : en bas, à gauche. **Affichage** : complet, compact.
- **Style** : « The Screen » (la charte du gestionnaire) ou « D&D Beyond » (ses gris sombres, sa police, et la couleur de thème de votre fiche à la place du violet ; chaque carte prend la couleur de la fiche de son héros).
- **PV des héros** : en mots, en barre, ou en chiffres.
- **Seuils** : Ensanglanté à 50 % et Critique à 25 % des PV max, d'office (ceux de l'écran des joueurs du gestionnaire).
- **Montrer l'équipement porté**, **Montrer mon personnage**.

### Ce que le MJ fixe pour sa campagne

Une ligne, dans les **notes publiques de la campagne** sur D&D Beyond (page de la campagne, « Edit Campaign », « Public Notes »), s'impose à tous les bandeaux de la campagne :

```
[Bandeau (MJ) : ensanglanté 40, critique 15, pv non]
```

Chaque élément est facultatif. `pv non` interdit l'affichage en chiffres ; `pv oui` le laisse. Le gestionnaire compose cette ligne (fenêtre Campagne, onglet « Fiches D&D Beyond ») ; à défaut, le MJ la tape. La fenêtre Réglages dit alors, réglage par réglage, ce qui est « fixé par le MJ ». La ligne se lit aussi dans les notes d'une fiche du groupe (onglet Notes, « Other »), si la campagne n'a pas de notes publiques. Contrat : `formats/note-compagnon.md` du gestionnaire.

## Ce qu'elle lit

Avec votre session, toutes les 20 s, page visible seulement :

- votre fiche, puis celles des autres héros de votre campagne (`character-service.dndbeyond.com`). D&D Beyond les laisse lire aux membres d'une campagne quand la fiche est en « Campaign Only » ; une fiche réglée en privé donne une carte « Fiche privée ». Chaque fiche porte les notes publiques de la campagne et sa couleur de thème ;
- l'inventaire commun de la campagne (même service) ; s'il ne se lit pas, son bouton ne paraît pas ;
- une fois par mois, les icônes des états, dans le code de la table virtuelle de D&D Beyond (`www.dndbeyond.com/games/<campagne>`, `media.dndbeyond.com`) ; sans elles, l'abréviation de l'état (« Em » pour Empoisonné).

Les polices viennent de Google Fonts (comme celles de D&D Beyond) ; sans elles, celles de la page. Rien n'est écrit sur D&D Beyond, rien de vos fiches n'est envoyé ailleurs.

Encombré, lourdement encombré : l'objet « Encumbered » ou « Heavily Encumbered » que le gestionnaire du MJ tient équipé sur la fiche, sinon la règle variante de l'encombrement choisie sur la fiche. Les états d'un compagnon : la ligne `[États (MJ) : …]` de sa note. La forme sauvage : la ligne `[Forme sauvage (joueur) : …]` que l'extension « The Seat · Wild Shape » écrit dans la note de la forme.

## Fichiers

`manifest.json`, `fond.js` (lecture des fiches, de l'inventaire commun et des icônes), `bandeau.js` (le bandeau, dans un Shadow DOM), `bandeau.css` (son style, celui du tableau des joueurs du gestionnaire, `.cm-tj` de `app/app.css` : à retoucher ensemble), `charte/tokens.css` (les couleurs de la charte), `icones/` (l'icône : l'hexagone des extensions de The Screen, trois héros ; `icone.svg` en est la source). `resumer.js` est le même fichier que `extensions/mj/resumer.js` : le modifier dans tous ses exemplaires.
