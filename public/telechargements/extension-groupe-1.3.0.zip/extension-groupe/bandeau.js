// Extension « The Seat · Party » : sur la feuille de personnage D&D Beyond, les héros de la campagne tels que les montre
// l'écran des joueurs du gestionnaire (app/tableau-joueurs.js) : portrait, états en icônes, santé en mots, équipement
// porté, compagnons ; l'inventaire commun dans une fenêtre. Deux positions, en bas de la page ou en colonne à gauche.
// Dans un Shadow DOM, pour ne rien mélanger avec la page (style : bandeau.css, couleurs : charte/tokens.css). Les réglages
// sont gardés dans Chrome, sauf ceux que le MJ impose par une ligne dans les notes d'une fiche du groupe (fond.js).

(() => {
  const FICHE = /^\/(?:profile\/[^/]+\/)?characters\/(\d+)\/?$/;
  const RELIRE_MS = 20000;
  const LARGEUR = 268, RAIL = 62;   // la colonne de gauche, et son rail de portraits
  const FICHE_LARGE = 1200;         // sous cette largeur libre, la fiche de D&D Beyond ne tient plus à côté de la colonne
  const DEFAUTS = { ensanglante: 50, critique: 25, pv: 'mots', moi: true, equipement: true, position: 'bas', taille: 'complet', style: 'screen', replie: false };
  const SANTES = { forme: 'En forme', ensanglante: 'Ensanglanté', critique: 'Critique', 'a-terre': 'À terre', mort: 'Mort' };
  const POLICES = 'https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:wght@400;500;600&family=Grenze+Gotisch:wght@500;600&family=Roboto+Condensed:wght@400;700&display=swap';
  const NS = 'http://www.w3.org/2000/svg';

  // Icônes : celles de la charte (épée, bouclier, étoile, pièce, griffe, crâne, cœur) et de Lucide (licence ISC), grille 24.
  const PICTOS = {
    epee: '<path d="M20.5 3.5l-.8 3.9L10 17.1 6.9 14l9.7-9.7z"/><path d="M5 12.6l6.4 6.4"/><path d="M8.2 15.8L4.3 19.7"/><circle cx="3.7" cy="20.3" r=".9"/>',
    bouclier: '<path d="M12 2.8l7.5 2.9v5.6c0 4.5-3.1 8-7.5 9.9-4.4-1.9-7.5-5.4-7.5-9.9V5.7z"/><path d="M12 2.8v18.4" stroke-opacity=".5"/>',
    etoile: '<path d="M12 2.8l1.9 7.3 7.3 1.9-7.3 1.9L12 21.2l-1.9-7.3L2.8 12l7.3-1.9z"/>',
    piece: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="5.8" stroke-opacity=".6"/><path d="M12 9.2l2 2.8-2 2.8-2-2.8z"/>',
    griffe: '<path d="M7 3.5c1.2 5.4.6 10.8-2.2 16.5M12 3c1.1 6 .7 12-1.6 18M17 3.5c1.1 5.4.7 10.8-1.9 16.5"/>',
    crane: '<path d="M12 3a7 7 0 0 0-7 7c0 2.4 1 4.1 2.5 5.1V18h9v-2.9c1.5-1 2.5-2.7 2.5-5.1a7 7 0 0 0-7-7z"/><circle cx="9.3" cy="10.6" r="1.6"/><circle cx="14.7" cy="10.6" r="1.6"/><path d="M12 13.2l-.9 1.8h1.8z"/><path d="M9 18v2.5h6V18M11 18v2.5M13 18v2.5"/>',
    coeur: '<path d="M12 20s-7.8-4.6-7.8-10.3A4.3 4.3 0 0 1 12 7.2a4.3 4.3 0 0 1 7.8 2.5C19.8 15.4 12 20 12 20z"/>',
    boite: '<path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
    sac: '<path d="M4 10a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z"/><path d="M8 10h8"/><path d="M8 18h8"/><path d="M8 22v-6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/>',
    poids: '<circle cx="12" cy="5" r="3"/><path d="M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8Z"/>',
    reglages: '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
    compact: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M21 9H3"/><path d="M21 15H3"/>',
    complet: '<rect width="18" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/>',
    actualiser: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    'en-bas': '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 15h18"/>',
    'a-gauche': '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
    bas: '<path d="m6 9 6 6 6-6"/>', haut: '<path d="m18 15-6-6-6 6"/>', gauche: '<path d="m15 18-6-6 6-6"/>', droite: '<path d="m9 18 6-6-6-6"/>',
    fermer: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  };
  // Les quinze états de D&D Beyond, par leur id : slug (celui de l'icône), nom du glossaire en VF, abréviation, gravité
  // (l'ordre sur le portrait, le plus grave d'abord). La même table que app/etats.js du gestionnaire.
  const ETATS = { 1: ['blinded', 'Aveuglé', 'Av', 8], 2: ['charmed', 'Charmé', 'Ch', 10], 3: ['deafened', 'Assourdi', 'As', 14], 4: ['exhaustion', 'Épuisement', 'Ép', 6],
    5: ['frightened', 'Effrayé', 'Ef', 9], 6: ['grappled', 'Agrippé', 'Ag', 7], 7: ['incapacitated', 'Neutralisé', 'Ne', 5], 8: ['invisible', 'Invisible', 'Iv', 15],
    9: ['paralyzed', 'Paralysé', 'Pa', 3], 10: ['petrified', 'Pétrifié', 'Pé', 2], 11: ['poisoned', 'Empoisonné', 'Em', 11], 12: ['prone', 'À terre', 'At', 12],
    13: ['restrained', 'Entravé', 'En', 6.5], 14: ['stunned', 'Étourdi', 'Ét', 4], 15: ['unconscious', 'Inconscient', 'Ic', 1] };
  const ENCOMBREMENTS = { encombre: 'Encombré', lourd: 'Lourdement encombré' };
  const PIECES = ['pp', 'po', 'pe', 'pa', 'pc'];

  let reglages = { ...DEFAUTS }, groupe = null, racine = null, hote = null, ficheId = null, message = null;
  let fenetre = null;                   // la fenêtre ouverte : 'inventaire', 'reglages' ou null
  let place = null;                     // où le joueur l'a glissée : { x, y }
  let dessine = null;                   // l'empreinte du dernier dessin : rien n'est redessiné quand rien n'a changé
  let iconesBrutes = null, iconesDemandees = false;
  const iconesPretes = new Set();
  let mesure = null;
  let luLe = null, echec = false;       // quand le groupe a été lu pour la dernière fois, et si la dernière lecture a échoué

  // Construit un élément ; les textes passent par textContent (les noms viennent des fiches).
  function el(tag, attrs = {}, ...enfants) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else if (k === 'class') n.className = v;
      else n.setAttribute(k, v === true ? '' : v);
    }
    for (const e of enfants.flat(Infinity)) if (e != null && e !== false) n.append(e);
    return n;
  }
  function picto(nom, classe = '') {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', ('bd-icone ' + classe).trim());
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS(NS, 'use');
    use.setAttribute('href', '#bd-' + nom);
    svg.append(use);
    return svg;
  }
  const bouton = (nom, titre, action, attrs = {}) => el('button', { class: 'bouton', type: 'button', title: titre, 'aria-label': titre, onclick: action, ...attrs }, picto(nom));

  // ───── Icônes des états (D&D Beyond) ─────
  // La tâche de fond les lit sur D&D Beyond ; ici, chaque SVG est relu élément par élément (formes et attributs de dessin
  // seuls, couleur du texte) avant d'entrer dans la page, en symboles #ddb-etat-<slug>. Sans elles : l'abréviation du nom.
  const FORMES = new Set(['svg', 'g', 'path', 'circle', 'ellipse', 'rect', 'polygon', 'polyline', 'line']);
  const ATTRIBUTS = new Set(['d', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'width', 'height', 'points', 'fill', 'fill-rule',
    'clip-rule', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'transform', 'opacity', 'fill-opacity', 'stroke-opacity']);
  function copiePropre(source) {
    const n = document.createElementNS(NS, source.localName);
    for (const a of source.attributes) {
      if (!ATTRIBUTS.has(a.name)) continue;
      const v = (a.name === 'fill' || a.name === 'stroke') && a.value !== 'none' ? 'currentColor' : a.value;
      if (/url\(|javascript:/i.test(v)) continue;
      n.setAttribute(a.name, v);
    }
    for (const c of source.children) if (FORMES.has(c.localName) && c.localName !== 'svg') n.append(copiePropre(c));
    return n;
  }
  function sprite() {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('aria-hidden', 'true');
    s.style.display = 'none';
    for (const [nom, trace] of Object.entries(PICTOS)) {
      const symbole = new DOMParser().parseFromString(`<symbol xmlns="${NS}" id="bd-${nom}" viewBox="0 0 24 24">${trace}</symbol>`, 'image/svg+xml').documentElement;
      s.append(document.importNode(symbole, true));
    }
    iconesPretes.clear();
    for (const [slug] of Object.values(ETATS)) {
      const texte = iconesBrutes?.[slug];
      if (typeof texte !== 'string') continue;
      const svg = new DOMParser().parseFromString(texte, 'image/svg+xml').documentElement;
      if (svg?.localName !== 'svg' || !svg.getAttribute('viewBox')) continue;
      const symbole = document.createElementNS(NS, 'symbol');
      symbole.id = 'ddb-etat-' + slug;
      symbole.setAttribute('viewBox', svg.getAttribute('viewBox'));
      for (const c of svg.children) if (FORMES.has(c.localName) && c.localName !== 'svg') symbole.append(copiePropre(c));
      s.append(symbole);
      iconesPretes.add(slug);
    }
    return s;
  }
  async function chargerIcones() {
    if (iconesDemandees || !groupe?.campagneId) return;
    iconesDemandees = true;
    const r = await chrome.runtime.sendMessage({ type: 'icones', campagne: groupe.campagneId }).catch(() => null);
    if (!r?.icones) return;
    iconesBrutes = r.icones;
    racine?.querySelector('.bd-sprite')?.replaceChildren(sprite());
    dessiner();
  }

  const etatDe = e => { const x = ETATS[e?.id]; return x ? { slug: x[0], nom: x[1], court: x[2], gravite: x[3], niveau: e.niveau || null } : null; };
  const etatsDe = m => (m.etats || []).map(etatDe).filter(Boolean).sort((a, b) => a.gravite - b.gravite);
  const nomEtat = e => (e.niveau ? `${e.nom} ${e.niveau}` : e.nom);
  function tuileEtat(e) {
    let dessin = el('span', { class: 'etat__court', 'aria-hidden': 'true' }, e.court);
    if (iconesPretes.has(e.slug)) {
      dessin = document.createElementNS(NS, 'svg');
      dessin.setAttribute('class', 'etat__svg');
      dessin.setAttribute('aria-hidden', 'true');
      const use = document.createElementNS(NS, 'use');
      use.setAttribute('href', '#ddb-etat-' + e.slug);
      dessin.append(use);
    }
    return el('span', { class: 'etat', 'data-etat': e.slug }, dessin, e.niveau ? el('sup', { class: 'etat__niveau' }, String(e.niveau)) : null);
  }
  const tuileEncombrement = etat => el('span', { class: 'etat' + (etat === 'lourd' ? ' etat--lourd' : ''), 'data-etat': 'encombrement' }, picto('poids'));

  // ───── Santé ─────
  const effectifs = () => {
    const mj = groupe?.mj;
    return { ensanglante: mj?.ensanglante ?? reglages.ensanglante, critique: mj?.critique ?? reglages.critique,
      pv: mj?.chiffres === false && reglages.pv === 'chiffres' ? 'mots' : reglages.pv, moi: reglages.moi, equipement: reglages.equipement,
      taille: reglages.taille === 'compact' ? 'compact' : 'complet' };
  };
  // « Ensanglanté » à la moitié des PV ou moins, « Critique » au quart, « À terre » à 0 PV, « Mort » après trois échecs.
  function santeDe(m, s) {
    if (!m.pv?.max) return null;
    if ((m.jds?.echecs || 0) >= 3) return 'mort';
    if (m.pv.actuels <= 0) return 'a-terre';
    const pct = (m.pv.actuels / m.pv.max) * 100;
    return pct <= s.critique ? 'critique' : pct <= s.ensanglante ? 'ensanglante' : 'forme';
  }
  // La santé telle que le joueur veut la voir : en mots (comme sur l'écran des joueurs), en barre ou en chiffres.
  function zoneSante(m, sante, s, petit = false) {
    if (!sante) return null;
    const classe = `sante-mot sante-${sante}${petit ? ' sante-mot--s' : ''}`;
    if (s.pv === 'barre') return el('span', { class: `barre sante-${sante}`, role: 'img', 'aria-label': SANTES[sante] }, el('span', { style: `width:${Math.min(100, Math.max(0, (m.pv.actuels / m.pv.max) * 100))}%` }));
    if (s.pv === 'chiffres') return el('span', { class: classe }, `${m.pv.actuels}/${m.pv.max}${m.pv.temporaires ? ` +${m.pv.temporaires}` : ''}`);
    return el('span', { class: classe }, SANTES[sante]);
  }
  function jetsContreLaMort({ succes = 0, echecs = 0, stabilise = false } = {}) {
    const stable = stabilise || succes >= 3;
    const texte = stable ? 'À terre, stabilisé' : `À terre. Jets contre la mort : ${succes} réussi${succes > 1 ? 's' : ''}, ${echecs} raté${echecs > 1 ? 's' : ''}`;
    const serie = (n, sorte) => el('span', { class: `jds__serie jds__serie--${sorte}` }, [0, 1, 2].map(i => el('span', { class: 'jds__pas' + (i < n ? ' est-fait' : '') })));
    return el('span', { class: 'jds', 'data-etat': stable ? 'stabilise' : null, role: 'img', 'aria-label': texte, title: texte }, serie(succes, 'reussis'), picto(stable ? 'coeur' : 'crane'), serie(echecs, 'rates'));
  }

  // ───── Cartes ─────
  function portrait(x) {
    const initiale = String(x.prenom || x.nom || '?').charAt(0).toUpperCase();
    const image = x.forme_avatar || x.avatar;   // un druide transformé : le portrait de sa forme
    return el('span', { class: 'portrait' }, image
      ? el('img', { src: image, alt: '', referrerpolicy: 'no-referrer', onerror: e => e.target.replaceWith(document.createTextNode(initiale)) })
      : initiale);
  }
  const ICONES_EQUIPEMENT = [[/sac|backpack|pack\b|besace|bag/i, 'sac'], [/bouclier|shield/i, 'bouclier']];
  function iconeEquipement(o) {
    for (const [re, ic] of ICONES_EQUIPEMENT) if (re.test(o.nom)) return ic;
    return o.type === 'arme' ? 'epee' : o.type === 'armure' ? 'bouclier' : o.magique ? 'etoile' : 'boite';
  }

  const nomObjet = o => o.nom + (o.quantite > 1 ? ` ×${o.quantite}` : '');
  // L'identité sur deux lignes, pour une carte basse : « espèce · classe », puis « sous-classe · historique ».
  const lignesIdentite = m => [[m.identite?.espece, m.identite?.classe], [m.identite?.sous_classe, m.identite?.historique]].map(l => l.filter(Boolean).join(' · ')).filter(Boolean);

  // Une carte. Complète : le portrait avec les états sur son bas, le nom, l'identité, la santé ; à côté ou dessous,
  // l'équipement porté et les compagnons. Compacte : le portrait, le nom, la santé et les états sur une ligne ; le reste est
  // dans la bulle.
  function carte(m, s) {
    const compact = s.taille === 'compact';
    const suivi = { tabindex: '0', onmouseenter: e => montrerBulle(e.currentTarget, m, s), onmouseleave: cacherBulle, onfocus: e => montrerBulle(e.currentTarget, m, s), onblur: cacherBulle };
    if (m.privee) {
      return el('article', { class: 'carte', 'data-sante': 'inconnue', ...suivi }, el('div', { class: 'carte__corps' }, el('div', { class: 'carte__tete' },
        el('span', { class: 'carte__portrait-cadre' }, portrait(m)),
        el('div', { class: 'carte__droite' }, el('div', { class: 'carte__titres' }, el('p', { class: 'carte__nom' }, m.prenom)),
          el('div', { class: 'carte__sante' }, el('span', { class: 'sante-mot sante-inconnue' + (compact ? ' sante-mot--s' : '') }, 'Fiche privée'))))));
    }
    const sante = santeDe(m, s);
    const tuiles = [...etatsDe(m).map(tuileEtat), m.encombrement ? tuileEncombrement(m.encombrement) : null].filter(Boolean).slice(0, 4);
    const equipement = !compact && s.equipement && m.equipement?.length ? el('ul', { class: 'carte__equipement' },
      m.equipement.map(o => el('li', { class: o.magique ? 'est-magique' : '' }, picto(iconeEquipement(o)), el('span', {}, nomObjet(o))))) : null;
    const compagnons = m.compagnons?.length ? el('div', { class: 'carte__compagnons' }, m.compagnons.map(c =>
      el('div', { class: 'compagnon' }, portrait(c), el('span', { class: 'compagnon__nom' }, c.nom), zoneSante(c, santeDe(c, s), s, true),
        etatsDe(c).map(e => { const t = tuileEtat(e); t.title = nomEtat(e); return t; })))) : null;
    return el('article', { class: 'carte' + (m.moi ? ' est-moi' : ''), 'data-sante': sante || 'inconnue', style: reglages.style === 'beyond' && m.couleur ? `--couleur-heros:${m.couleur}` : null, ...suivi },
      el('div', { class: 'carte__corps' },
        el('div', { class: 'carte__tete' },
          el('span', { class: 'carte__portrait-cadre' }, portrait(m), !compact && tuiles.length ? el('span', { class: 'carte__etats', 'data-nb': String(tuiles.length) }, tuiles) : null),
          el('div', { class: 'carte__droite' },
            el('div', { class: 'carte__titres' },
              el('p', { class: 'carte__nom' }, m.prenom, compact && m.forme ? picto('griffe', 'carte__nom-forme') : null),
              compact ? null : m.forme ? el('p', { class: 'carte__ligne carte__forme' }, picto('griffe'), m.forme) : lignesIdentite(m).map(l => el('p', { class: 'carte__ligne' }, l))),
            el('div', { class: 'carte__sante' },
              sante === 'mort' ? el('span', { class: 'mort', role: 'img', 'aria-label': 'Mort : trois jets contre la mort ratés' }, picto('crane'), 'Mort')
                : sante === 'a-terre' ? jetsContreLaMort(m.jds || {})   // le cadre des jets contre la mort dit « à terre » à lui seul
                  : zoneSante(m, sante, s, compact),
              compact && tuiles.length ? el('span', { class: 'carte__etats-ligne' }, tuiles) : null))),
        equipement || compagnons ? el('div', { class: 'carte__cote' }, equipement, compagnons) : null));
  }

  // La bulle d'une carte, au survol ou au clavier : le nom entier, le joueur, l'identité, les états et l'encombrement en
  // toutes lettres, tout l'équipement porté (la carte peut le couper), les compagnons.
  function montrerBulle(depuis, m, s) {
    const hoteBulle = racine?.querySelector('.bd-bulle');
    if (!hoteBulle) return;
    const etats = [...etatsDe(m).map(nomEtat), m.encombrement ? ENCOMBREMENTS[m.encombrement] : null].filter(Boolean);
    const identite = [m.identite?.espece, m.identite?.classe, m.identite?.sous_classe, m.identite?.historique].filter(Boolean);
    const b = el('div', { class: 'bulle', role: 'tooltip' }, el('b', {}, m.nom),
      m.joueur ? el('span', {}, `Joueur : ${m.joueur}`) : null,
      identite.length ? el('span', {}, identite.join(' · ')) : null,
      m.forme ? el('span', { class: 'bulle__fort' }, `Forme sauvage : ${m.forme}`) : null,
      etats.length ? el('span', { class: 'bulle__fort' }, etats.join(', ')) : null,
      s.equipement && m.equipement?.length ? el('span', {}, 'Porte : ' + m.equipement.map(nomObjet).join(', ')) : null,
      (m.compagnons || []).map(c => el('span', {}, [c.nom, SANTES[santeDe(c, s)], ...etatsDe(c).map(nomEtat)].filter(Boolean).join(' · '))));
    hoteBulle.replaceChildren(b);
    const r = depuis.getBoundingClientRect();
    if (reglages.position === 'gauche') {
      b.style.left = `${Math.round(Math.min(r.right + 8, innerWidth - b.offsetWidth - 8))}px`;
      b.style.top = `${Math.round(Math.max(8, Math.min(r.top, innerHeight - b.offsetHeight - 8)))}px`;
    } else {
      b.style.left = `${Math.round(Math.max(8, Math.min(r.left, innerWidth - b.offsetWidth - 8)))}px`;
      b.style.bottom = `${Math.round(innerHeight - r.top + 8)}px`;
    }
  }
  const cacherBulle = () => racine?.querySelector('.bd-bulle')?.replaceChildren();

  // ───── Fenêtres : l'inventaire commun, les réglages ─────
  function cadreFenetre(surtitre, titre, corps) {
    const f = el('section', { class: 'fenetre', role: 'dialog', 'aria-label': titre },
      el('header', { class: 'fenetre__tete' },
        el('div', { class: 'fenetre__titres' }, surtitre ? el('span', { class: 'fenetre__surtitre' }, surtitre) : null, el('span', { class: 'fenetre__titre' }, titre)),
        bouton('fermer', 'Fermer', () => ouvrir(null))),
      el('div', { class: 'fenetre__corps' }, corps));
    // Elle se glisse par sa tête, et reste où le joueur l'a posée.
    f.querySelector('.fenetre__tete').addEventListener('pointerdown', e => {
      if (e.button !== 0 || e.target.closest('button')) return;
      const r = f.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top, tete = e.currentTarget;
      tete.setPointerCapture(e.pointerId);
      const glisser = ev => { place = { x: Math.max(0, Math.min(innerWidth - 60, ev.clientX - dx)), y: Math.max(0, Math.min(innerHeight - 30, ev.clientY - dy)) }; placerFenetre(f); };
      tete.addEventListener('pointermove', glisser);
      tete.addEventListener('pointerup', () => tete.removeEventListener('pointermove', glisser), { once: true });
    });
    return f;
  }
  // D'office à côté du bandeau : au-dessus de lui, à droite, ou à droite de la colonne.
  function placerFenetre(f) {
    const bd = racine.querySelector('.bd').getBoundingClientRect();
    const x = place ? place.x : reglages.position === 'gauche' ? bd.right + 8 : innerWidth - f.offsetWidth - 8;
    const y = place ? place.y : reglages.position === 'gauche' ? 8 : bd.top - f.offsetHeight - 8;
    f.style.left = `${Math.round(Math.max(0, Math.min(x, innerWidth - f.offsetWidth)))}px`;
    f.style.top = `${Math.round(Math.max(0, Math.min(y, innerHeight - 30)))}px`;
  }
  function fenetreInventaire() {
    const g = groupe?.inventaire;
    const pieces = PIECES.filter(k => g?.argent?.[k]);
    return cadreFenetre(groupe?.campagne, 'Inventaire commun', !g ? el('p', { class: 'sourdine' }, 'L\'inventaire commun de cette campagne ne se lit pas.') : [
      pieces.length ? el('div', { class: 'bourse' }, pieces.map(k => el('span', { class: `piece piece--${k}` }, picto('piece'), `${g.argent[k]} ${k}`))) : null,
      g.objets.length ? el('ul', { class: 'objets' }, g.objets.map(o => el('li', {}, el('span', {}, o.nom), o.quantite > 1 ? el('span', { class: 'objets__nb' }, `×${o.quantite}`) : null)))
        : el('p', { class: 'sourdine' }, pieces.length ? 'Aucun objet.' : 'Rien pour le moment.'),
    ]);
  }
  function fenetreReglages() {
    const mj = groupe?.mj, s = effectifs();
    const garder = (cle, valeur) => { reglages[cle] = valeur; if (cle === 'position') place = null; chrome.storage.local.set({ reglages }); dessiner(); };
    // Ce que le MJ a fixé pour sa campagne ne se change pas ici, et le dit.
    const fixe = () => el('span', { class: 'reglages__mj' }, 'fixé par le MJ');
    const seuil = (libelle, cle) => el('label', {}, el('span', {}, libelle, mj?.[cle] != null ? fixe() : null), el('input', { type: 'number', min: '0', max: '100', value: String(s[cle]), disabled: mj?.[cle] != null,
      onchange: e => garder(cle, Math.min(100, Math.max(0, Number(e.target.value) || 0))) }));
    const choix = (libelle, cle, options, note = null) => el('label', {}, el('span', {}, libelle, note), el('select', { onchange: e => garder(cle, e.target.value) },
      options.map(([v, t, interdit]) => el('option', { value: v, selected: (cle === 'pv' ? s.pv : reglages[cle]) === v, disabled: interdit }, t))));
    const case_ = (libelle, cle) => el('label', {}, libelle, el('input', { type: 'checkbox', checked: reglages[cle], onchange: e => garder(cle, e.target.checked) }));
    const fixes = mj && (mj.ensanglante != null || mj.critique != null || mj.chiffres != null);
    return cadreFenetre(null, 'Réglages du bandeau', el('div', { class: 'reglages' },
      fixes ? el('div', { class: 'reglages__note' }, `Les limites de cette campagne sont fixées par le MJ (${mj.source === 'campagne' ? 'notes publiques de la campagne' : 'notes d\'une fiche du groupe'}).`) : null,
      choix('Position', 'position', [['bas', 'En bas'], ['gauche', 'À gauche']]),
      choix('Affichage', 'taille', [['complet', 'Complet'], ['compact', 'Compact']]),
      choix('Style', 'style', [['screen', 'The Screen'], ['beyond', 'D&D Beyond']]),
      choix('PV des héros', 'pv', [['mots', 'En mots'], ['barre', 'En barre'], ['chiffres', 'En chiffres', mj?.chiffres === false]], mj?.chiffres === false ? el('span', { class: 'reglages__mj' }, 'chiffres interdits par le MJ') : null),
      seuil('Ensanglanté à (% PV)', 'ensanglante'),
      seuil('Critique à (% PV)', 'critique'),
      case_('Montrer l\'équipement porté', 'equipement'),
      case_('Montrer mon personnage', 'moi')));
  }
  function ouvrir(nom) {
    fenetre = fenetre === nom ? null : nom;
    place = null;
    dessiner();
  }

  // ───── Dessin ─────
  // À gauche, la colonne pousse la page ; quand l'écran est trop étroit pour la fiche à côté d'elle, elle devient un rail de
  // portraits, déployé au survol.
  const enRail = () => reglages.position === 'gauche' && innerWidth < FICHE_LARGE + LARGEUR + 24;
  function marges() {
    const bd = racine?.querySelector('.bd'), style = document.documentElement.style;
    const gauche = reglages.position === 'gauche' && !reglages.replie;
    style.setProperty('--bd-groupe-bas', !bd || gauche || reglages.replie ? '0px' : `${Math.ceil(bd.getBoundingClientRect().height)}px`);
    style.setProperty('--bd-groupe-gauche', gauche ? `${enRail() ? RAIL : LARGEUR}px` : '0px');
    // Un équipement plus long que sa place sur la carte est coupé (le bandeau reste bas) : la carte le signale, la bulle le donne en entier.
    for (const liste of racine?.querySelectorAll('.carte__equipement') || []) liste.parentElement.classList.toggle('est-coupe', liste.scrollHeight > liste.clientHeight + 1);
  }

  // L'âge de la dernière lecture, mis à jour chaque seconde sans rien redessiner ; orange quand elle date ou a échoué.
  function ilYA(ms) {
    const sec = Math.max(0, Math.round(ms / 1000));
    return sec < 60 ? `${sec} s` : sec < 3600 ? `${Math.floor(sec / 60)} min` : `${Math.floor(sec / 3600)} h`;
  }
  function majAge() {
    const n = racine?.querySelector('.bd__age-texte');
    if (!n) return;
    const vieux = luLe && Date.now() - luLe > 3 * RELIRE_MS;
    n.textContent = luLe ? ilYA(Date.now() - luLe) : '…';
    n.parentElement.classList.toggle('est-vieux', !!(vieux || echec));
    n.parentElement.title = (luLe ? `Fiches lues il y a ${ilYA(Date.now() - luLe)}` : 'Fiches pas encore lues') + (echec ? ' (la dernière lecture a échoué)' : '') + `. Relues toutes les ${RELIRE_MS / 1000} s ; un clic les relit maintenant.`;
  }

  function dessiner() {
    if (!racine) return;
    const s = effectifs(), rail = enRail();
    const empreinte = JSON.stringify([groupe, reglages, fenetre, message, rail, iconesPretes.size]);
    if (empreinte === dessine) return;
    const position = reglages.position === 'gauche' ? 'gauche' : 'bas';
    const autre = position === 'bas' ? ['a-gauche', 'Mettre le bandeau à gauche', 'gauche'] : ['en-bas', 'Mettre le bandeau en bas', 'bas'];
    const basculer = v => { reglages.replie = v; fenetre = null; chrome.storage.local.set({ reglages }); dessiner(); };
    const bd = racine.querySelector('.bd');
    const taille = s.taille === 'compact' ? ['complet', 'Affichage complet', 'complet'] : ['compact', 'Affichage compact', 'compact'];
    cacherBulle();
    // Le style : la charte de The Screen, ou les couleurs de D&D Beyond, avec la couleur de thème de la fiche du joueur à la
    // place du violet (et, sur chaque carte, celle de la fiche de son héros).
    const beyond = reglages.style === 'beyond', theme = groupe?.membres?.find(m => m.moi)?.couleur;
    hote.dataset.style = beyond ? 'beyond' : 'screen';
    if (beyond && theme) hote.style.setProperty('--theme', theme); else hote.style.removeProperty('--theme');
    bd.dataset.position = position;
    bd.className = 'bd' + (s.taille === 'compact' ? ' bd--compact' : '') + (reglages.replie ? ' est-replie' : rail ? ' est-rail' : '') + (fenetre ? ' est-deployee' : '');
    bd.replaceChildren(...(reglages.replie
      ? [bouton(position === 'bas' ? 'haut' : 'droite', 'Montrer le bandeau du groupe', () => basculer(false))]
      : [
        el('div', { class: 'bd__cartes' },
          groupe?.membres?.length
            ? groupe.membres.filter(m => s.moi || !m.moi).map(m => carte(m, s))
            : el('div', { class: 'bd__message' }, message || 'Lecture du groupe…')),
        el('div', { class: 'bd__outils' },
          el('div', { class: 'bd__titres' },
            el('span', { class: 'bd__titre', title: groupe?.campagne || null }, groupe?.campagne || 'Le groupe'),
            el('button', { class: 'bd__age', type: 'button', onclick: () => lire(true) }, picto('actualiser'), el('span', { class: 'bd__age-texte' }, '…'))),
          groupe?.inventaire ? bouton('boite', 'Inventaire commun', () => ouvrir('inventaire'), { 'aria-pressed': String(fenetre === 'inventaire') }) : null,
          bouton(taille[0], taille[1], () => { reglages.taille = taille[2]; chrome.storage.local.set({ reglages }); dessiner(); }),
          bouton(autre[0], autre[1], () => { reglages.position = autre[2]; place = null; chrome.storage.local.set({ reglages }); dessiner(); }),
          bouton('reglages', 'Réglages du bandeau', () => ouvrir('reglages'), { 'aria-pressed': String(fenetre === 'reglages') }),
          bouton(position === 'bas' ? 'bas' : 'gauche', 'Réduire le bandeau', () => basculer(true))),
      ]));
    const f = reglages.replie ? null : fenetre === 'inventaire' ? fenetreInventaire() : fenetre === 'reglages' ? fenetreReglages() : null;
    racine.querySelector('.bd-fenetre').replaceChildren(...(f ? [f] : []));
    if (f) placerFenetre(f);
    dessine = empreinte;
    marges();
    majAge();
  }

  async function monter() {
    if (hote?.isConnected) return;
    hote = document.createElement('div');
    hote.id = 'bandeau-groupe-dndbeyond';
    racine = hote.attachShadow({ mode: 'open' });
    const lire = async chemin => { try { return await (await fetch(chrome.runtime.getURL(chemin))).text(); } catch { return ''; } };
    const tokens = (await lire('charte/tokens.css')).replace(/:root(,\s*\[data-theme="nuit"\])?/g, ':host').replace(/\[data-theme="[a-z]+"\]\s*\{[^}]*\}/g, '');
    const style = await lire('bandeau.css');
    const bd = el('div', { class: 'bd', 'data-position': 'bas', style: `--largeur:${LARGEUR}px;--rail:${RAIL}px` });
    racine.append(el('style', {}, tokens + style), el('div', { class: 'bd-sprite' }, sprite()), bd, el('div', { class: 'bd-fenetre' }), el('div', { class: 'bd-bulle' }));
    document.body.append(hote);
    // Les polices de la charte, comme le gestionnaire les charge ; sans elles, celles de la page.
    if (!document.getElementById('bandeau-groupe-polices')) document.head.append(el('link', { id: 'bandeau-groupe-polices', rel: 'stylesheet', href: POLICES }));
    // La page fait de la place au bandeau : en bas, de sa hauteur (elle suit son contenu) ; à gauche, de sa largeur.
    if (!document.getElementById('bandeau-groupe-marge')) {
      document.head.append(el('style', { id: 'bandeau-groupe-marge' }, 'body { padding-bottom: var(--bd-groupe-bas, 0px) !important; padding-left: var(--bd-groupe-gauche, 0px) !important; }'));
    }
    mesure?.disconnect();
    mesure = new ResizeObserver(marges);
    mesure.observe(bd);
    dessine = null;
    dessiner();
  }
  function demonter() {
    mesure?.disconnect();
    hote?.remove();
    hote = null; racine = null; groupe = null; dessine = null; fenetre = null;
    document.documentElement.style.removeProperty('--bd-groupe-bas');
    document.documentElement.style.removeProperty('--bd-groupe-gauche');
  }

  // force : relire tout de suite (un clic sur l'âge de la lecture), sans la réponse gardée par la tâche de fond.
  async function lire(force = false) {
    const id = FICHE.exec(location.pathname)?.[1];
    if (!id) { demonter(); ficheId = null; return; }
    if (id !== ficheId) { ficheId = id; groupe = null; luLe = null; iconesDemandees = false; }
    await monter();
    if (document.hidden) return;
    const r = await chrome.runtime.sendMessage({ type: 'groupe', fiche: id, force: force === true }).catch(() => null);
    echec = !r?.ok;
    if (r?.ok) {
      const { ok, lu: quand, ...lu } = r;
      groupe = lu;
      luLe = quand || Date.now();
      if (!lu.membres.length) message = 'Cette fiche n\'est pas dans une campagne.';
      chargerIcones();
    } else if (!groupe) message = r?.session ? 'Connectez-vous à D&D Beyond.' : 'Lecture impossible pour le moment.';
    dessiner();
    majAge();
  }

  chrome.storage.local.get('reglages').then(({ reglages: gardes }) => {
    reglages = { ...DEFAUTS, ...gardes };
    lire();
    setInterval(() => lire(), RELIRE_MS);
    setInterval(majAge, 1000);
    let dernier = location.pathname;
    setInterval(() => { if (location.pathname !== dernier) { dernier = location.pathname; lire(); } if (ficheId && hote && !hote.isConnected) { hote = null; monter(); } }, 1000);
    addEventListener('resize', () => { dessiner(); marges(); if (fenetre && racine) { const f = racine.querySelector('.fenetre'); if (f) placerFenetre(f); } });
    addEventListener('keydown', e => { if (e.key === 'Escape' && fenetre) ouvrir(null); });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) lire(); });   // un onglet ouvert en arrière-plan : lu dès qu'on y vient
  });
})();
