// Extension « The Seat · Party » : tâche de fond. Lit, avec la session du joueur, sa fiche et celles des autres héros de sa
// campagne (D&D Beyond les laisse lire aux membres de la campagne : fiches « Campaign Only »), l'inventaire commun de la
// campagne, et rend au bandeau ce qui s'y affiche : ce que montre le tableau des joueurs du gestionnaire
// (app/tableau-joueurs.js). Rien n'est écrit sur D&D Beyond, rien n'est envoyé ailleurs.

import { resumer, resumerGroupe, texte, OBJET_ENCOMBRE_ID, OBJET_LOURD_ID } from './resumer.js';

const SERVICE = 'https://character-service.dndbeyond.com/character/v5/';
const GARDER_MS = 10000;   // deux onglets ouverts ne relisent pas deux fois (le bandeau relit toutes les 20 s)
const GROUPES_FORME = [3, 13], CREATURE_NOTES = 47;
const LIGNE_FORME = /\[\s*Forme\s+sauvage\s*\(\s*joueur\s*\)[^\]\n]*\]/iu;
// Réglages fixés par le MJ : une ligne « [Bandeau (MJ) : ensanglanté 50, critique 20, pv non] », dans les notes publiques
// de sa campagne (page de la campagne, « Edit Campaign », « Public Notes » : chaque fiche les porte, campaign.publicNotes),
// sinon dans les notes d'une fiche du groupe (onglet Notes, « Other »). Contrat : formats/note-compagnon.md du gestionnaire.
const LIGNE_BANDEAU = /\[\s*Bandeau\s*\(\s*MJ\s*\)\s*:\s*([^\]\n]*)\]/iu;
// États d'un compagnon, posés par le MJ dans la note de la créature : « [États (MJ) : À terre, Épuisement 2] » (même contrat).
const LIGNE_ETATS = /\[\s*[ÉE]tats\s*\(\s*MJ\s*\)\s*:([^\]\n]*)\]/iu;
const ETATS = [null, 'Aveuglé', 'Charmé', 'Assourdi', 'Épuisement', 'Effrayé', 'Agrippé', 'Neutralisé', 'Invisible',
  'Paralysé', 'Pétrifié', 'Empoisonné', 'À terre', 'Entravé', 'Étourdi', 'Inconscient'];   // l'indice est l'id de D&D Beyond
const EPUISEMENT = 4;
const cle = t => String(t || '').normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().replace(/\s+/g, '');
const ETATS_PAR_CLE = new Map(ETATS.map((nom, id) => [cle(nom), id]).filter(([, id]) => id));

let jeton = null;
async function jetonBeyond() {
  if (jeton && Date.now() < jeton.jusqua) return jeton.valeur;
  const r = await fetch('https://auth-service.dndbeyond.com/v1/cobalt-token', { method: 'POST', credentials: 'include' }).catch(() => null);
  const j = r?.ok ? await r.json() : null;
  jeton = j?.token ? { valeur: j.token, jusqua: Date.now() + Math.max(0, (j.ttl || 300) - 60) * 1000 } : null;
  if (!jeton) throw new Error('session');
  return jeton.valeur;
}

async function lireBeyond(chemin) {
  let r = await fetch(SERVICE + chemin, { headers: { Authorization: 'Bearer ' + await jetonBeyond() } });
  if (r.status === 401) { jeton = null; r = await fetch(SERVICE + chemin, { headers: { Authorization: 'Bearer ' + await jetonBeyond() } }); }
  if (!r.ok) throw Object.assign(new Error('lecture'), { statut: r.status });
  return (await r.json())?.data;
}
async function lireFiche(id) {
  const d = await lireBeyond('character/' + id);
  if (!d?.id) throw new Error('lecture');
  return d;
}

const noteCreature = (d, c) => String((d.characterValues || []).find(v => v.typeId === CREATURE_NOTES && String(v.valueId) === String(c.id))?.value || '');
const formeDe = d => {
  const cr = (d.creatures || []).find(c => GROUPES_FORME.includes(c.groupId) && LIGNE_FORME.test(noteCreature(d, c)));
  return cr ? { nom: String(cr.name || cr.definition?.name || '').trim().replace(/\s*\((?:tiny|small|medium|large)\)\s*$/i, ''), avatar: cr.definition?.avatarUrl || null } : null;
};

// source : 'campagne' (ses notes publiques) ou 'fiche' (les notes d'une fiche), pour le dire dans les réglages du bandeau.
function reglagesMj(notes, source) {
  const m = LIGNE_BANDEAU.exec(texte(notes));   // les notes publiques sont du texte mis en forme : balises et entités retirées
  if (!m) return null;
  const nombre = re => { const x = re.exec(m[1]); return x ? Math.min(100, Math.max(0, Number(x[1]))) : null; };
  // « ensanglanté » : avec ou sans accent, ou son entité HTML.
  return { ensanglante: nombre(/ensanglant\S*\s*:?\s*(\d+)/iu), critique: nombre(/critique\s*:?\s*(\d+)/iu), chiffres: /\bpv\s*:?\s*non\b/iu.test(m[1]) ? false : /\bpv\s*:?\s*oui\b/iu.test(m[1]) ? true : null, source };
}

// Les objets identiques ne font qu'une ligne, quantités additionnées : deux dagues, « Dagger ×2 » ; deux lots de vingt
// flèches, « Arrows ×40 » (la quantité d'un objet empilé est déjà son nombre de pièces).
function regrouper(objets) {
  const vus = new Map();
  for (const o of objets) {
    const c = [o.nom, o.type || '', o.magique ? 1 : 0].join('|');
    if (vus.has(c)) vus.get(c).quantite += o.quantite || 1;
    else vus.set(c, { ...o, quantite: o.quantite || 1 });
  }
  return [...vus.values()];
}

// Les états d'un compagnon, lus dans sa note : noms comparés sans casse, accents ni espaces ; « Épuisement N » donne le
// niveau (1 à 6) ; un nom inconnu est ignoré.
function etatsDeLaNote(note) {
  const m = LIGNE_ETATS.exec(note);
  if (!m) return [];
  const vus = new Map();
  for (const brut of m[1].split(',')) {
    const x = /^(.*?)\s*(\d+)?\s*$/u.exec(brut.trim());
    const id = ETATS_PAR_CLE.get(cle(x?.[1]));
    if (id) vus.set(id, { id, nom: ETATS[id], niveau: id === EPUISEMENT ? Math.min(6, Math.max(1, Number(x[2]) || 1)) : null });
  }
  return [...vus.values()];
}

// Encombré ou lourdement encombré : l'objet homebrew que le MJ tient équipé sur la fiche (« Encumbered », « Heavily
// Encumbered », seuils de sa campagne), sinon la règle variante de la fiche. → 'encombre' | 'lourd' | null.
function encombrementDe(d, f) {
  const equipe = id => (d.inventory || []).some(i => i.equipped && i.definition?.id === id);
  if (equipe(OBJET_LOURD_ID)) return 'lourd';
  if (equipe(OBJET_ENCOMBRE_ID)) return 'encombre';
  return f.encombrement?.regle === 'variante' && ['encombre', 'lourd'].includes(f.encombrement.etat) ? f.encombrement.etat : null;
}

// Ce qui se voit d'un héros à la table : son identité, sa santé, ses états, ce qu'il porte, ses compagnons.
function membre(c, d, moi) {
  const f = resumer(d), forme = formeDe(d);
  const classes = f.classes || [];
  return {
    id: d.id, moi, nom: f.nom, prenom: f.nom.split(/\s+/)[0] || f.nom, joueur: c.username || f.joueur || null, avatar: f.avatar || c.avatarUrl || null,
    identite: { espece: f.espece || null, classe: classes.map(x => x.nom).filter(Boolean).join(' / ') || null,
      sous_classe: classes.map(x => x.sous_classe).filter(Boolean).join(' / ') || null, historique: f.historique || null },
    pv: f.pv, jds: f.jets_contre_la_mort,
    etats: f.etats.map(e => ({ id: e.id, nom: e.nom, niveau: e.niveau })),
    encombrement: encombrementDe(d, f),
    forme: forme?.nom || null, forme_avatar: forme?.avatar || null,   // transformé : le nom et le portrait de sa forme
    couleur: /^#[0-9a-f]{6}$/i.test(d.decorations?.themeColor?.themeColor || '') ? d.decorations.themeColor.themeColor : null,   // la couleur de thème de sa fiche (style « D&D Beyond » du bandeau)
    // Équipement porté : armes, armure, bouclier, conteneurs équipés (un sac à dos équipé est sur le dos), objets magiques équipés.
    equipement: regrouper([
      ...(f.objets_equipes || []).map(o => ({ nom: o.nom, type: o.type || null, quantite: o.quantite || 1, magique: false })),
      ...(f.objets_magiques || []).filter(o => o.equipe).map(o => ({ nom: o.nom, type: null, quantite: o.quantite || 1, magique: true })),
    ]),
    // Ses compagnons : les créatures actives de ses Extras (les formes sauvages n'en sont pas).
    compagnons: (f.creatures || []).filter(cr => cr.actif).map(cr => ({
      id: cr.id, nom: cr.nom, avatar: cr.profil?.avatarUrl || null, pv: cr.pv,
      etats: etatsDeLaNote(noteCreature(d, cr)),
    })),
  };
}

// L'inventaire commun de la campagne (« party inventory »), tel que la fiche le lit ; null s'il ne se lit pas.
async function lireInventaire(campagne) {
  try {
    const g = resumerGroupe(await lireBeyond('party/inventory/' + campagne));
    return { argent: g.argent, objets: regrouper(g.objets.filter(o => o.nom).map(o => ({ nom: o.nom, quantite: o.quantite }))) };
  } catch (e) {
    if (e.message === 'session') throw e;
    return null;
  }
}

const gardes = new Map();   // id de fiche -> { quand, resultat }
async function lireGroupe(id, force = false) {
  const g = gardes.get(id);
  if (!force && g && Date.now() - g.quand < GARDER_MS) return g.resultat;
  const d = await lireFiche(id);
  const liste = d.campaign?.characters || [];
  if (!liste.length) return { campagne: null, campagneId: null, membres: [], mj: null, inventaire: null, lu: Date.now() };
  let mj = reglagesMj(d.campaign.publicNotes, 'campagne') || reglagesMj(d.notes?.otherNotes, 'fiche');
  const [membres, inventaire] = await Promise.all([
    Promise.all(liste.map(async c => {
      try {
        const fiche = c.characterId === d.id ? d : await lireFiche(c.characterId);
        mj ||= reglagesMj(fiche.notes?.otherNotes, 'fiche');
        return membre(c, fiche, c.characterId === d.id);
      } catch {
        return { id: c.characterId, moi: false, nom: c.characterName, prenom: String(c.characterName || '').split(/\s+/)[0], joueur: c.username || null, avatar: c.avatarUrl || null, privee: true };
      }
    })),
    d.campaign.id ? lireInventaire(d.campaign.id) : null,
  ]);
  const resultat = { campagne: d.campaign.name || null, campagneId: d.campaign.id || null, membres, mj, inventaire, lu: Date.now() };
  gardes.set(id, { quand: Date.now(), resultat });
  return resultat;
}

// ───── Icônes des états ─────
// Celles de D&D Beyond (son VTT, Maps), lues comme dans l'extension du compagnon : la page de la partie
// (www.dndbeyond.com/games/<campagne>, avec la session du joueur) liste les morceaux de code de Maps (media.dndbeyond.com) ;
// l'un d'eux contient la table des icônes, un SVG par état (clés = slug anglais). Gardées 30 jours (chrome.storage.local) ;
// un échec n'est réessayé qu'au bout de 6 h. Le bandeau les relit élément par élément avant de s'en servir ; sans elles,
// l'abréviation du nom.
const GARDE_ICONES = 30 * 24 * 3600 * 1000, REESSAI_ICONES = 6 * 3600 * 1000;
const MORCEAU = /https:\/\/media\.dndbeyond\.com\/games\/_next\/static\/chunks\/[^"'\s\\]+\.js/g;
// Chaîne JavaScript entre apostrophes : ses échappements (\n, \', \uXXXX…) décodés.
const decoder = s => s.replace(/\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)/g, (_, e) =>
  e[0] === 'n' ? '\n' : e[0] === 't' ? '\t' : e[0] === 'r' ? '\r' : /^[ux]/.test(e) && e.length > 1 ? String.fromCharCode(parseInt(e.slice(1), 16)) : e);

async function lireIconesSurBeyond(campagne) {
  const page = await fetch(`https://www.dndbeyond.com/games/${campagne}`, { credentials: 'include' }).then(r => (r.ok ? r.text() : ''));
  for (const url of new Set(page.match(MORCEAU) || [])) {
    const code = await fetch(url).then(r => (r.ok ? r.text() : '')).catch(() => '');
    if (!/blinded:[\w$]+\('<svg/.test(code)) continue;
    const icones = {};
    for (const m of code.matchAll(/([a-z]+):[\w$]+\('(<svg(?:[^'\\]|\\.)*)'\)/g)) icones[m[1]] ||= decoder(m[2]).trim();
    if (Object.keys(icones).length >= 10) return icones;
  }
  return null;
}

let lectureIcones = null;   // une seule lecture à la fois, pour tous les onglets
function iconesEtats(campagne) {
  lectureIcones ||= (async () => {
    const { iconesEtats: garde } = await chrome.storage.local.get('iconesEtats');
    if (garde?.icones && Date.now() - garde.quand < GARDE_ICONES) return garde.icones;
    if (campagne && !(garde?.echec && Date.now() - garde.echec < REESSAI_ICONES)) {
      const icones = await lireIconesSurBeyond(campagne).catch(() => null);
      await chrome.storage.local.set({ iconesEtats: icones ? { quand: Date.now(), icones } : { ...garde, echec: Date.now() } });
      if (icones) return icones;
    }
    return garde?.icones || null;   // gardées depuis plus de 30 jours : mieux que rien
  })().finally(() => { lectureIcones = null; });
  return lectureIcones;
}

chrome.runtime.onMessage.addListener((m, _, repondre) => {
  if (m?.type === 'groupe') {
    lireGroupe(Number(m.fiche), !!m.force).then(r => repondre({ ok: true, ...r }), e => repondre({ ok: false, session: e.message === 'session' }));
    return true;
  }
  if (m?.type === 'icones') {
    iconesEtats(Number(m.campagne) || null).then(icones => repondre({ ok: true, icones }), () => repondre({ ok: false, icones: null }));
    return true;
  }
  return undefined;
});
