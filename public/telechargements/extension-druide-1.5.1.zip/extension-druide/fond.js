// Extension « The Seat · Wild Shape » : tâche de fond. Un clic sur l'icône ouvre ou referme le volet sur la fiche affichée (un
// message au script de la page, volet.js ; ailleurs que sur une fiche, personne ne répond). Et elle demande à D&D Beyond le
// jeton de session pour le volet (panneau.js) : le volet est un cadre posé dans la page de la fiche, d'où les cookies de
// session ne partiraient pas forcément avec la demande ; d'ici, ils partent. Rien n'est envoyé ailleurs que D&D Beyond.

chrome.action.onClicked.addListener(onglet => {
  if (onglet?.id != null) chrome.tabs.sendMessage(onglet.id, { type: 'basculer' }).catch(() => {});
});

async function jetonBeyond() {
  const r = await fetch('https://auth-service.dndbeyond.com/v1/cobalt-token', { method: 'POST', credentials: 'include' }).catch(() => null);
  const j = r?.ok ? await r.json().catch(() => null) : null;
  return j?.token ? { token: j.token, ttl: j.ttl || 300 } : null;
}

chrome.runtime.onMessage.addListener((m, _, repondre) => {
  if (m?.type !== 'jeton') return undefined;
  jetonBeyond().then(repondre, () => repondre(null));
  return true;
});
