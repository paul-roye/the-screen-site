// Volet de l'extension « The Seat · Wild Shape » : les formes sauvages du druide (les Extras de sa fiche D&D Beyond), la
// transformation d'un clic (un usage dépensé, les PV temporaires, une ligne dans la note de la forme pour le MJ) et la fiche
// fusionnée tant qu'il est transformé. Tout se lit et s'écrit sur D&D Beyond avec la session du navigateur ; rien n'est
// envoyé ailleurs. Relu toutes les 15 s. Cette page est affichée dans un cadre posé sur la fiche D&D Beyond (volet.js), qui
// lui donne la fiche à suivre dans son adresse (?fiche=<id>) et la recharge quand la fiche change. Deux styles (réglage
// « Style ») : la charte du gestionnaire, ou les couleurs de la fiche D&D Beyond (beyond.css).

import { h, icone, bouton, bascule, flottant, infobulle, activerInfobulles, onglets, ouvrirMenu } from './js/ui.js';
import { blocStats, signe, puissanceDe, libellePuissance } from './js/monstres.js';
import { reglagesDes, lancerVisible, formuleD20, AVANTAGES } from './js/lancers.js';
import { resumer } from './js/resumer.js';
import { formesDe, formeActive, nomForme, usagesDe, regleDuDruide, caDeForme, fusionner, definitionFusionnee, noteDe, noteAvecForme } from './js/druide.js';
import { nomFr, nomFamilier, imageDe, optionsDe, FAMILIERS, MOUVEMENT } from './js/bestiaire.js';

const SERVICE = 'https://character-service.dndbeyond.com/character/v5/';
const RELIRE_MS = 15000;
const CONFIG_MS = 24 * 3600 * 1000;
const NOTE_CREATURE = 47;
const TAILLES = { 2: 'Très petit', 3: 'Petit', 4: 'Moyen', 5: 'Grand', 6: 'Très grand', 7: 'Gigantesque' };
const VITESSES = { 1: '', 2: 'fouissement', 3: 'escalade', 4: 'vol', 5: 'nage' };
const CARAC_COURT = { for: 'For', dex: 'Dex', con: 'Con', int: 'Int', sag: 'Sag', cha: 'Cha' };
const CARAC_LONG = { for: 'Force', dex: 'Dextérité', con: 'Constitution', int: 'Intelligence', sag: 'Sagesse', cha: 'Charisme' };

const page = document.getElementById('page');
const FICHE = /^\d+$/.exec(new URLSearchParams(location.search).get('fiche') || '')?.[0] || '';   // la fiche suivie
let reglages = { son: true, recharger: true, onglet: 'formes', style: 'screen' };
let dernier = null;   // { fiche, resume, regle, quand }
let cfg = null, echec = null, enLecture = false, ecriture = false, message = null;
let volet = { ouvert: true, reduit: false, cote: 'droite', largeur: 'etroit' };   // où et comment le volet est posé (clé « volet », suivie par volet.js)
let theme = null;     // la couleur de thème de la fiche lue (style « D&D Beyond »)

// ───── D&D Beyond ─────

// Le jeton de session est demandé par la tâche de fond (fond.js) : d'un cadre posé dans la page de la fiche, les cookies de
// session ne partiraient pas forcément avec la demande.
let jeton = null;
async function jetonBeyond() {
  if (jeton && Date.now() < jeton.jusqua) return jeton.valeur;
  const j = await chrome.runtime.sendMessage({ type: 'jeton' }).catch(() => null);
  jeton = j?.token ? { valeur: j.token, jusqua: Date.now() + Math.max(0, (j.ttl || 300) - 60) * 1000 } : null;
  if (!jeton) throw new Error('Pas de session D&D Beyond : connectez-vous sur dndbeyond.com dans ce navigateur, puis relisez.');
  return jeton.valeur;
}

async function lireFiche(id) {
  const r = await fetch(SERVICE + 'character/' + id, { headers: { Authorization: 'Bearer ' + await jetonBeyond() } });
  if (r.status === 401) { jeton = null; throw new Error('Session D&D Beyond expirée : relisez.'); }
  if (r.status === 403 || r.status === 404) throw new Error('Fiche introuvable, ou pas à vous.');
  if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status}.`);
  const d = (await r.json())?.data;
  if (!d?.id) throw new Error('Fiche D&D Beyond illisible.');
  return d;
}

async function lireConfig() {
  const { config } = await chrome.storage.local.get('config');
  if (config && Date.now() - config.quand < CONFIG_MS) return config.valeur;
  const r = await fetch('https://www.dndbeyond.com/api/config/json');
  if (!r.ok) return config?.valeur || null;
  const j = await r.json();
  const liste = (l, f) => (l || []).map(f);
  const valeur = {
    tailles: liste(j.creatureSizes, x => ({ id: x.id, nom: x.name })),
    types: liste(j.monsterTypes, x => ({ id: x.id, nom: x.name })),
    alignements: liste(j.alignments, x => ({ id: x.id, nom: x.name })),
    mouvements: liste(j.movements, x => ({ id: x.id, nom: x.name })),
    sens: liste(j.senses, x => ({ id: x.id, nom: x.name })),
    carac: liste(j.stats, x => ({ id: x.id, cle: x.key })),
    etats: liste(j.conditions, x => ({ id: x.definition?.id, nom: x.definition?.name })),
    ajustements: liste(j.damageAdjustments, x => ({ id: x.id, nom: x.name, type: x.type })),
    puissances: liste(j.challengeRatings, x => ({ id: x.id, valeur: x.value, px: x.xp, maitrise: x.proficiencyBonus })),
  };
  await chrome.storage.local.set({ config: { quand: Date.now(), valeur } });
  return valeur;
}

async function ecrire(chemin, corps, methode = 'PUT') {
  const envoyer = async () => fetch(SERVICE + chemin, { method: methode,
    headers: { Authorization: 'Bearer ' + await jetonBeyond(), 'Content-Type': 'application/json' }, body: JSON.stringify(corps) });
  let r = await envoyer();
  if (r.status === 401) { jeton = null; r = await envoyer(); }
  if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status}.`);
  const j = await r.json().catch(() => null);
  if (j && j.success === false) throw new Error(j.message || 'D&D Beyond a refusé le changement.');
}
const poserUsage = (d, u, utilises) => ecrire('action/limited-use', { characterId: d.id, id: u.id, entityTypeId: u.entityTypeId, uses: utilises });
const poserPv = (d, perdus, temporaires) => ecrire('life/hp/damage-taken', { characterId: d.id, removedHitPoints: perdus, temporaryHitPoints: temporaires });
function poserNote(d, cr, note) {
  const cle = { characterId: d.id, typeId: NOTE_CREATURE, valueId: String(cr.id), valueTypeId: String(cr.entityTypeId), contextId: null, contextTypeId: null, partyId: null };
  return note ? ecrire('custom/value', { ...cle, value: note, notes: null }) : ecrire('custom/value', cle, 'DELETE');
}
// Remplace la ligne de la forme sauvage dans la note de la créature (texte du joueur gardé).
async function noterForme(d, cr, ligne) {
  const avant = noteDe(d, cr).trim(), apres = noteAvecForme(avant, ligne);
  if (apres !== avant) await poserNote(d, cr, apres);
}

// La fiche ouverte sur D&D Beyond ne sait pas que ses valeurs ont changé, et réécrirait les anciennes au prochain clic :
// sa page est rechargée, un instant après le dernier changement (réglage du volet). C'est le script de la page qui le
// fait (volet.js), à la demande de ce cadre ; le volet, posé dans la page, est rechargé avec elle.
let attenteRechargement = null;
function rechargerFiche() {
  if (!reglages.recharger || parent === window) return;
  clearTimeout(attenteRechargement);
  attenteRechargement = setTimeout(() => parent.postMessage({ aideDruide: 'recharger' }, 'https://www.dndbeyond.com'), 600);
}

// ───── Style ─────

// Réglage « Style » : « The Screen », la charte telle quelle, ou « D&D Beyond » : les neutres de beyond.css et, à la place
// du violet de la charte, la couleur de thème de la fiche (sans elle, le rouge de D&D Beyond, dans beyond.css). Le texte
// posé sur cette couleur (--sur-theme) est clair ou sombre selon elle.
const POLICE_BEYOND = 'https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;500;600;700&display=swap';
function luminance(hex) {
  const [r, g, b] = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255).map(v => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function appliquerStyle() {
  const racine = document.documentElement, beyond = reglages.style === 'beyond';
  const couleur = beyond && /^#[0-9a-f]{6}$/i.test(theme || '') ? theme : null;
  if (beyond) racine.dataset.style = 'beyond'; else delete racine.dataset.style;
  const poser = (nom, valeur) => (valeur ? racine.style.setProperty(nom, valeur) : racine.style.removeProperty(nom));
  poser('--ultra', couleur);
  poser('--halo-ultra', couleur && couleur + '8c');
  poser('--ultra-voile', couleur && couleur + '24');
  poser('--sur-theme', couleur && (luminance(couleur) > 0.18 ? 'var(--sur-accent)' : 'var(--os)'));
  // La police des titres de D&D Beyond, chargée comme celles de la charte (charte/barovie.css), seulement dans ce style.
  if (beyond && !document.getElementById('police-beyond')) document.head.append(h('link', { id: 'police-beyond', rel: 'stylesheet', href: POLICE_BEYOND }));
}

// ───── Actions ─────

// Une suite d'écritures : défaites si l'une échoue, puis relecture. fait(annuler) : annuler(fn) note ce qui défera l'étape.
async function action(libelle, fait) {
  if (ecriture || !dernier) return;
  ecriture = true; message = null;
  afficher();
  const defaire = [];
  let reussi = true;
  try {
    const d = await lireFiche(dernier.fiche.id);   // relue juste avant d'écrire
    await fait(d, resumer(d), fn => defaire.unshift(fn));
  } catch (e) {
    reussi = false;
    message = `${libelle} : ${e.message}`;
    for (const fn of defaire) await fn().catch(() => {});
  }
  ecriture = false;
  await relire();
  if (reussi) rechargerFiche();
}

function prendreForme(cr, { sansUsage = false } = {}) {
  return action(`${nomForme(cr)} : pas de transformation`, async (d, f, annuler) => {
    const regle = regleDuDruide(d, f);
    const u = usagesDe(d, f.maitrise);
    const frais = (d.creatures || []).find(c => String(c.id) === String(cr.id));
    if (!frais) throw new Error('forme introuvable sur la fiche.');
    const active = formeActive(d);
    if (u && !sansUsage && u.restants > 0) {
      await poserUsage(d, u, u.utilises + 1);
      annuler(() => poserUsage(d, u, u.utilises));
    }
    const avantTemp = d.temporaryHitPoints || 0, temp = Math.max(avantTemp, regle.pvTemp);
    if (temp !== avantTemp) {
      await poserPv(d, d.removedHitPoints || 0, temp);
      annuler(() => poserPv(d, d.removedHitPoints || 0, avantTemp));
    }
    if (active && String(active.id) !== String(frais.id)) {
      await noterForme(d, active, null);
      annuler(() => noterForme({ ...d, characterValues: [] }, active, `[Forme sauvage (joueur)]`));
    }
    await noterForme(d, frais, `[Forme sauvage (joueur) : CA ${caDeForme(d, frais, regle)}, PV temp. ${temp}]`);
  });
}

function quitterForme() {
  return action('Forme humaine pas reprise', async d => {
    const active = formeActive(d);
    if (active) await noterForme(d, active, null);
  });
}

// Compagnon sauvage : un usage de Forme sauvage pour lancer Find Familiar (le sort reste à jouer).
function depenserUsage() {
  return action('Usage pas dépensé', async (d, f) => {
    const u = usagesDe(d, f.maitrise);
    if (!u || !u.restants) throw new Error('plus d\'usage de Forme sauvage.');
    await poserUsage(d, u, u.utilises + 1);
  });
}
const regleUsages = n => action('Usages pas changés', async (d, f) => {
  const u = usagesDe(d, f.maitrise);
  if (u) await poserUsage(d, u, Math.min(u.max, Math.max(0, n)));
});

// ───── Morceaux d'affichage ─────

const garder = () => chrome.storage.local.set({ reglages });
const fp = v => ({ 0.125: '1/8', 0.25: '1/4', 0.5: '1/2' }[v] ?? String(v));
const vitessesDe = mv => (mv || []).filter(x => x.speed).map(x => `${VITESSES[x.movementId] ?? ''} ${x.speed} ft`.trim()).join(', ');
function ilYA(quand) {
  const sec = Math.max(0, Math.round((Date.now() - quand) / 1000));
  return sec < 60 ? `${sec} s` : `${Math.floor(sec / 60)} min`;
}
function majAge() {
  const b = document.querySelector('.dr-outils__age');
  if (!b) return;
  b.querySelector('span').textContent = echec ? 'échec' : dernier ? ilYA(dernier.quand) : '…';
  b.classList.toggle('est-en-echec', !!echec);
  b.title = `${echec || (dernier ? `Fiche lue il y a ${ilYA(dernier.quand)}.` : 'Fiche pas encore lue.')} Relue toutes les 15 s ; un clic la relit maintenant.`;
}

// La barre d'outils, en haut du volet (comme celle du bandeau du groupe) : l'âge de la lecture (un clic relit), les
// réglages, puis le volet lui-même : large ou étroit, à droite ou à gauche, réduit à un onglet, fermé. Ces quatre-là
// changent l'état gardé dans Chrome (clé « volet »), que le script de la page (volet.js) suit.
const outils = document.getElementById('outils');
const poserVolet = changements => chrome.storage.local.set({ volet: { ...volet, ...changements } });
function dessinerOutils() {
  const b = (ic, titre, action) => h('button', { type: 'button', class: 'dr-outil', title: titre, 'aria-label': titre, onclick: action }, icone(ic));
  const gauche = volet.cote === 'gauche', large = volet.largeur === 'large';
  outils.replaceChildren(
    h('span', { class: 'dr-outils__titre', title: 'The Seat · Wild Shape' }, 'Wild Shape'),   // le nom entier serait coupé dans le volet étroit
    h('button', { type: 'button', class: 'dr-outils__age', onclick: () => relire() }, icone('lu-refresh-cw'), h('span', {}, '…')),
    b('lu-sliders-horizontal', 'Réglages', e => ouvrirReglages(e.currentTarget)),
    b(large ? 'lu-chevrons-right-left' : 'lu-chevrons-left-right', large ? 'Volet étroit (texte plus petit)' : 'Volet large', () => poserVolet({ largeur: large ? 'etroit' : 'large' })),
    b(gauche ? 'lu-panel-right' : 'lu-panel-left', gauche ? 'Mettre le volet à droite' : 'Mettre le volet à gauche', () => poserVolet({ cote: gauche ? 'droite' : 'gauche' })),
    b(gauche ? 'lu-chevron-left' : 'lu-chevron-right', 'Réduire le volet à un onglet', () => poserVolet({ reduit: true })),
    b('lu-x', 'Fermer le volet (l\'icône de l\'extension le rouvre)', () => poserVolet({ ouvert: false })));
  majAge();
}
// Étroit : la même mise en page, réduite (le texte un peu plus petit) ; large : à sa taille.
function appliquerVolet() {
  document.documentElement.style.zoom = volet.largeur === 'large' ? '' : '0.84';
  dessinerOutils();
}

// Les usages en losanges, comme sur D&D Beyond : vide disponible, coché utilisé ; un clic pose le nombre d'usages dépensés.
function losangesUsages(u) {
  return h('span', { class: 'dr-usages', role: 'group', 'aria-label': `Usages dépensés : ${u.utilises} sur ${u.max}` },
    Array.from({ length: u.max }, (_, i) => {
      const coche = i < u.utilises;
      return h('button', { type: 'button', class: 'dr-losange' + (coche ? ' est-coche' : ''), disabled: ecriture, title: coche ? 'Rendre cet usage' : 'Dépenser cet usage', 'aria-pressed': String(coche),
        onclick: () => regleUsages(coche ? i : i + 1) }, coche ? icone('lu-check') : null);
    }));
}

function boutonJet(texte, bonus, legende) {
  const formule = formuleD20(bonus);
  const lancer = (ancre, avantage = null) => lancerVisible(formule, { legende: avantage ? `${legende} (${AVANTAGES[avantage].libelle})` : legende, couleur: 'ultra', depuis: ancre, avantage });
  return h('button', { type: 'button', class: 'bn-badge bn-dd bn-dd--jet', title: `${legende} : lancer ${formule} (clic droit : avec avantage ou désavantage)`,
    onclick: e => { e.stopPropagation(); lancer(e.currentTarget); },
    oncontextmenu: e => {
      e.preventDefault();
      const ancre = e.currentTarget;
      ouvrirMenu(ancre, [['Avec avantage', 'Deux d20, le meilleur', () => lancer(ancre, 'avantage')],
        ['Avec désavantage', 'Deux d20, le moins bon', () => lancer(ancre, 'desavantage')]], 'Lancer avec avantage ou désavantage');
    } }, icone('d20'), texte);
}

function ajouterLigne(fiche, titre, contenu, avant = null) {
  const lignes = fiche.querySelector(':scope > dl.bn-stat__lignes');
  if (!lignes || !contenu.length) return;
  const ligne = h('div', {}, h('dt', {}, titre), h('dd', {}, contenu));
  const repere = avant && [...lignes.children].find(el => el.querySelector('dt')?.textContent === avant);
  if (repere) repere.before(ligne); else lignes.prepend(ligne);
}

// La fiche officielle d'une bête sur D&D Beyond, dans un nouvel onglet : l'adresse que porte sa définition, sinon
// /monsters/<id> (D&D Beyond redirige vers la page complète).
function urlOfficielle(def) {
  const u = typeof def?.url === 'string' ? def.url.trim() : '';
  if (/^https:\/\/www\.dndbeyond\.com\//i.test(u)) return u;
  if (/^\/[^/\\]/.test(u)) return 'https://www.dndbeyond.com' + u;
  return def?.id > 0 ? `https://www.dndbeyond.com/monsters/${def.id}` : null;
}
function lienOfficiel(def) {
  const url = urlOfficielle(def);
  return url ? infobulle(h('a', { class: 'dr-officiel', href: url, target: '_blank', rel: 'noopener', 'aria-label': 'Fiche officielle sur D&D Beyond' }, icone('lu-external-link')),
    'Fiche officielle sur D&D Beyond') : null;
}

// La fiche du druide dans une forme (celle qu'il a prise, ou un aperçu) : le bloc de stats de la bête, aux valeurs fusionnées.
function ficheFusionnee(cr, d, f, regle) {
  const nomEn = nomForme(cr), nom = nomFr(nomEn) || nomEn;
  const options = optionsDe(d, cr);
  const fusion = fusionner(d, f, cr, regle, cfg);
  const mouvements = [...(cr.definition?.movements || []),
    ...Object.entries(options?.vitesses || {}).map(([k, speed]) => ({ movementId: MOUVEMENT[k], speed, notes: null }))];
  const image = imageDe(cr.definition, true);
  // url retirée : le lien vers la fiche officielle est une icône à côté du nom, pas la ligne en bas du bloc.
  const bloc = blocStats({ ...definitionFusionnee(cr, fusion, nom, mouvements), url: null }, cfg, { image, pb: f.maitrise });
  const officiel = lienOfficiel(cr.definition);
  if (officiel) bloc.querySelector('.bn-stat__nom')?.append(' ', officiel);
  const dt = t => [...bloc.querySelectorAll('dt')].find(x => x.textContent === t);
  dt('Points de vie')?.parentElement.remove();   // ceux du druide, qu'il garde : sur sa fiche D&D Beyond
  ajouterLigne(bloc, 'Compétences', fusion.competences.filter(c => c.maitrise).sort((a, b) => a.nom.localeCompare(b.nom, 'fr'))
    .flatMap((c, i) => [i ? ' ' : '', boutonJet(`${c.nom} ${signe(c.bonus)}`, c.bonus, `${nom} : ${c.nom}`)]).filter(x => x !== ''));
  const jsCles = Object.entries(fusion.sauvegardes);
  ajouterLigne(bloc, 'Jets de sauvegarde', jsCles.flatMap(([k, s], i) => [i ? ' ' : '',
    boutonJet(`${CARAC_COURT[k]} ${signe(s.bonus)}`, s.bonus, `${nom} : sauvegarde de ${CARAC_LONG[k]}`)]).filter(x => x !== ''), 'Compétences');
  if (options?.traits?.length) {
    bloc.append(h('h4', { class: 'bn-stat__section' }, 'Options retenues'),
      ...options.traits.map(([n, t]) => h('p', { class: 'bn-stat__trait' }, h('strong', {}, `${n}. `), t)));
  }
  return bloc;
}

function ouvrirForme(cr, d, f, regle, depuis) {
  const nomEn = nomForme(cr), nom = nomFr(nomEn) || nomEn;
  flottant('forme:' + cr.id, { surtitre: 'Aperçu de votre fiche dans cette forme', titre: nom, largeur: 460, depuis,
    contenu: h('div', { class: 'fc-corps' }, ficheFusionnee(cr, d, f, regle)) });
}

function vignette(url, nom) {
  return h('span', { class: 'dr-vignette' + (url ? '' : ' est-vide') }, url ? h('img', { src: url, alt: '', referrerpolicy: 'no-referrer' }) : (String(nom)[0] || '?'));
}

function ligneForme(cr, d, f, regle, u, active) {
  const def = cr.definition || {};
  const nomEn = nomForme(cr), nom = nomFr(nomEn) || nomEn;
  const puissance = puissanceDe(def, cfg);
  const estActive = active && String(active.id) === String(cr.id);
  const options = optionsDe(d, cr);
  const mouvements = [...(def.movements || []), ...Object.entries(options?.vitesses || {}).map(([k, speed]) => ({ movementId: MOUVEMENT[k], speed }))];
  const trop = puissance && puissance.valeur > regle.fpMax;
  const vol = (def.movements || []).some(x => x.movementId === MOUVEMENT.vol && x.speed);
  const detail = [TAILLES[def.sizeId], puissance ? libellePuissance(puissance) : null, `CA ${caDeForme(d, cr, regle)}`, vitessesDe(mouvements)].filter(Boolean).join(' · ');
  const reste = u ? u.restants : 1;
  const action = estActive ? badgeActif()
    : reste > 0
      ? infobulle(bouton(active ? 'Changer' : 'Prendre', { classe: 'bn-btn--s bn-btn--primaire', disabled: ecriture, onclick: () => prendreForme(cr) }),
        `Action bonus : dépense 1 usage de Forme sauvage (reste ${reste}), PV temporaires à ${Math.max(f.pv.temporaires, regle.pvTemp)}, noté sur la fiche pour le MJ.`, { titre: 'Forme sauvage' })
      : infobulle(bouton('Sans usage', { classe: 'bn-btn--s', disabled: ecriture, onclick: () => prendreForme(cr, { sansUsage: true }) }),
        'Plus d\'usage de Forme sauvage sur la fiche. Se transformer quand même, sans en dépenser (une décision du MJ, un oubli…).', { titre: 'Plus d\'usage', ton: 'cierge' });
  return h('li', { class: 'dr-forme' + (estActive ? ' est-active' : '') },
    h('button', { type: 'button', class: 'dr-forme__corps', title: 'Voir votre fiche dans cette forme', onclick: e => ouvrirForme(cr, d, f, regle, e.currentTarget) },
      vignette(imageDe(def), nom),
      h('span', { class: 'dr-forme__texte' }, h('span', { class: 'dr-forme__nom' }, nom),
        h('span', { class: 'ui-s cm-sourdine' }, detail))),
    lienOfficiel(def),
    (trop || (vol && !regle.vol)) ? infobulle(h('span', { class: 'dr-alerte', tabindex: '0' }, icone('lu-triangle-alert')),
      trop ? `FP au-dessus du maximum de votre niveau (${fp(regle.fpMax)}).` : 'Une forme avec une vitesse de vol n\'est permise qu\'à partir du niveau 8.', { titre: 'Forme non permise', ton: 'cierge' }) : null,
    action);
}
const badgeActif = () => h('span', { class: 'bn-badge bn-badge--ultra' }, 'Prise');

function listeFormes(d, f, regle, u, active) {
  const formes = formesDe(d);
  return h('div', { class: 'cm-pile' },
    formes.length
      ? h('ul', { class: 'dr-formes' }, formes.map(cr => ligneForme(cr, d, f, regle, u, active)))
      : h('p', { class: 'ui cm-sourdine' }, 'Aucune forme dans les Extras de cette fiche : ajoutez-les sur D&D Beyond (Extras, Manage Extras, Wild Shape).'),
    formes.length > regle.connues ? h('p', { class: 'ui-s dr-note' }, icone('lu-triangle-alert'), `${formes.length} formes dans les Extras, ${regle.connues} permises à votre niveau.`) : null);
}

function vueCompagnon(d, f, u) {
  const reste = u ? u.restants : 0;
  return h('div', { class: 'cm-pile' },
    h('p', { class: 'ui' }, 'Action Magie : dépensez un usage de Forme sauvage ou un emplacement de sort pour lancer ', h('b', {}, 'Find Familiar'), ', sans composante matérielle. Le familier est une fée, et disparaît à la fin d\'un repos long.'),
    h('div', { class: 'bn-groupe' }, bouton('Dépenser 1 usage', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-leaf', disabled: ecriture || !reste, onclick: depenserUsage }),
      h('span', { class: 'ui-s cm-sourdine' }, reste ? `${reste} usage${reste > 1 ? 's' : ''} restant${reste > 1 ? 's' : ''}` : 'Plus d\'usage')),
    h('ul', { class: 'dr-formes' }, FAMILIERS.map(def => {
      const nom = nomFamilier(def.name);
      return h('li', { class: 'dr-forme' }, h('button', { type: 'button', class: 'dr-forme__corps', onclick: e => flottant('familier:' + def.id, { surtitre: 'Compagnon sauvage', titre: nom, largeur: 420, depuis: e.currentTarget, contenu: h('div', { class: 'fc-corps' }, blocStats({ ...def, name: nom, url: null }, cfg, { pb: 2, image: imageDe(def, true) })) }) },
        vignette(imageDe(def), nom),
        h('span', { class: 'dr-forme__texte' }, h('span', { class: 'dr-forme__nom' }, nom),
          h('span', { class: 'ui-s cm-sourdine' }, [`CA ${def.armorClass}`, `PV ${def.averageHitPoints}`, vitessesDe(def.movements)].join(' · ')))), lienOfficiel(def));
    })));
}

// Règles résumées, avec les valeurs de ce druide. Rédaction propre, d'après le Player's Handbook 2024.
function vueRegles(regle, u) {
  const liste = lignes => h('ul', { class: 'dr-regles' }, lignes.filter(Boolean).map(l => h('li', { class: 'ui-s' }, l)));
  return h('div', { class: 'cm-pile' },
    h('section', { class: 'cm-section' }, h('h3', { class: 'etiquette' }, 'Forme sauvage'),
      liste([
        `Action bonus. Durée : ${regle.dureeH} h (la moitié du niveau de druide).`,
        'Prend fin : action bonus, nouvelle Forme sauvage, état Neutralisé, ou mort.',
        u ? `Usages : ${u.max} ; un usage revient au repos court, tous au repos long.` : null,
        `Formes connues : ${regle.connues}, FP ${fp(regle.fpMax)} au plus, ${regle.vol ? 'vol permis' : 'pas de vol avant le niveau 8'}. Une forme peut être échangée à chaque repos long.`,
        `PV temporaires à la transformation : ${regle.pvTemp}${regle.lune ? ' (3 × niveau de druide)' : ' (niveau de druide)'}.`,
      ])),
    h('section', { class: 'cm-section' }, h('h3', { class: 'etiquette' }, 'Pendant la forme'),
      liste([
        'Vous gardez : type de créature, PV et dés de vie, Intelligence, Sagesse, Charisme, capacités de classe, langues, dons, personnalité, parole.',
        'Le bloc de la bête remplace le reste. Compétences et sauvegardes : vos maîtrises et les siennes, avec votre bonus de maîtrise ; si le bloc donne plus, c\'est le bloc.',
        'Pas de sorts (sauf ceux du Cercle de la Lune), mais une concentration en cours continue.',
        'Objets : selon les membres de la forme. L\'équipement tombe, fusionne (sans effet) ou se porte, si le MJ juge que ça va.',
      ])),
    regle.lune ? h('section', { class: 'cm-section' }, h('h3', { class: 'etiquette' }, 'Cercle de la Lune'),
      liste([
        `FP maximum : le niveau de druide divisé par 3, arrondi à l'inférieur (${fp(regle.fpMax)}).`,
        `CA : 13 + modificateur de Sagesse (${regle.caMin}) si c'est mieux que celle de la bête.`,
        regle.sortsDuCercle.length ? `Sorts du Cercle, lançables en forme : ${regle.sortsDuCercle.join(', ')}.` : null,
        regle.niveau >= 6 ? 'Niveau 6 : vos attaques en forme peuvent infliger des dégâts radiants ; Sagesse ajoutée aux sauvegardes de Constitution.' : null,
        regle.niveau >= 10 ? 'Niveau 10 : Pas de lune (téléportation de 30 ft en action bonus, avantage à la prochaine attaque du tour).' : null,
      ])) : null,
    h('p', { class: 'ui-s cm-sourdine' }, h('a', { class: 'bn-lien', href: 'https://www.dndbeyond.com/classes/2190878-druid', target: '_blank', rel: 'noopener' }, 'La classe de druide sur D&D Beyond')));
}

// Réglages du volet. Le style choisi s'applique tout de suite ; la fenêtre est redessinée pour montrer le choix.
function ouvrirReglages(depuis) {
  const choisirStyle = v => { reglages.style = v; garder(); appliquerStyle(); ouvrirReglages(); };
  flottant('reglages', { titre: 'Réglages', largeur: 320, depuis,
    contenu: h('div', { class: 'cm-pile' },
      h('div', { class: 'cm-section' },
        h('div', { class: 'dr-ligne' }, h('span', { class: 'etiquette' }, 'Style'),
          bascule('Style', [['screen', 'The Screen'], ['beyond', 'D&D Beyond']], reglages.style === 'beyond' ? 'beyond' : 'screen', choisirStyle)),
        h('p', { class: 'ui-s cm-sourdine' }, 'D&D Beyond : les couleurs de votre fiche, avec sa couleur de thème.')),
      h('label', { class: 'bn-case-ligne dr-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: reglages.recharger, onchange: e => { reglages.recharger = e.target.checked; garder(); } }),
        h('span', { class: 'ui-s' }, 'Recharger la fiche D&D Beyond après un changement fait ici. Sinon, recharger la page à la main : la fiche ouverte réécrirait ses anciennes valeurs.')),
      h('label', { class: 'bn-case-ligne dr-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: reglages.son, onchange: e => { reglages.son = e.target.checked; reglagesDes.son = reglages.son; garder(); } }),
        h('span', { class: 'ui-s' }, 'Son des dés'))) });
}

function vueAttente(texte) {
  page.replaceChildren(h('section', { class: 'bn-carte cm-pile dr-attente' }, h('p', { class: 'ui' }, texte)));
}

function vueFiche() {
  const { fiche: d, resume: f, regle } = dernier;
  const u = usagesDe(d, f.maitrise);
  const active = formeActive(d);
  const nomActive = active ? (nomFr(nomForme(active)) || nomForme(active)) : null;
  const zone = onglets('The Seat · Wild Shape', [
    { id: 'formes', libelle: 'Formes', icone: 'griffe', rendu: () => listeFormes(d, f, regle, u, active) },
    { id: 'compagnon', libelle: 'Compagnon', icone: 'lu-leaf', rendu: () => vueCompagnon(d, f, u) },
    { id: 'regles', libelle: 'Règles', icone: 'livre', rendu: () => vueRegles(regle, u) },
  ], reglages.onglet, id => { reglages.onglet = id; garder(); });
  page.replaceChildren(...[
    h('section', { class: 'cm-pile fc-etat' },
      h('div', { class: 'dr-ligne' },
        h('span', { class: 'etiquette' }, 'Forme sauvage'),
        u ? losangesUsages(u) : h('span', { class: 'ui-s cm-sourdine' }, 'pas d\'usages sur la fiche'),
        active ? h('span', { class: 'dr-ligne__fin' }, bouton('Forme humaine', { icone: 'lu-rotate-ccw', classe: 'bn-btn--s', disabled: ecriture, titre: 'Action bonus : reprendre forme humaine. Les PV temporaires restent.', onclick: quitterForme })) : null),
      message ? h('p', { class: 'ui-s fc-erreur' }, icone('lu-triangle-alert'), message) : null),
    active ? h('section', { class: 'dr-active cm-pile' },
      h('div', { class: 'dr-active__tete' }, h('span', { class: 'surtitre' }, 'Transformé en'), h('span', { class: 'titre-m' }, nomActive)),
      h('div', { class: 'fc-corps' }, ficheFusionnee(active, d, f, regle)),
      h('details', { class: 'dr-replie' }, h('summary', { class: 'etiquette' }, 'Rappels'),
        h('ul', { class: 'dr-regles' },
          h('li', { class: 'ui-s' }, `Durée : ${regle.dureeH} h au plus.`),
          h('li', { class: 'ui-s' }, regle.sortsDuCercle.length ? `Sorts : seulement ceux du Cercle (${regle.sortsDuCercle.join(', ')}).` : 'Pas de sorts.'),
          h('li', { class: 'ui-s' }, 'Une concentration en cours continue.')))) : null,
    h('section', { class: 'cm-pile' }, zone.barre, zone.zone),
  ].filter(Boolean));
}

function afficher() {
  if (!dernier) return;
  const haut = document.scrollingElement.scrollTop;
  vueFiche();
  document.scrollingElement.scrollTop = haut;
}

async function relire() {
  if (!FICHE) return vueAttente('Ce volet s\'ouvre sur la fiche de votre druide, sur D&D Beyond : depuis la fiche, cliquez sur l\'icône de l\'extension.');
  if (enLecture || ecriture) return;
  enLecture = true;
  try {
    const [d, c] = await Promise.all([lireFiche(FICHE), lireConfig().catch(() => cfg)]);
    cfg = c;
    const resume = resumer(d), regle = regleDuDruide(d, resume);
    echec = null;
    const couleur = d.decorations?.themeColor?.themeColor || null;
    if (couleur !== theme) { theme = couleur; appliquerStyle(); }
    if (!regle) { dernier = null; enLecture = false; return vueAttente(`${d.name || 'Ce personnage'} n'est pas druide : ce volet ne sert qu'à un druide. Ouvrez la fiche de votre druide.`); }
    dernier = { fiche: d, resume, regle, quand: Date.now() };
    enLecture = false;
    if (!document.activeElement?.matches?.('input, select')) afficher();
  } catch (e) {
    echec = e.message;
    if (!dernier) vueAttente(e.message);
  } finally {
    enLecture = false;
    majAge();
  }
}

// ───── Démarrage ─────

// Les réglages gardés dans Chrome (1.0.0 y gardait aussi la fiche suivie : elle vient maintenant de l'adresse du cadre).
function reprendre(gardes) {
  reglages = { ...reglages, ...gardes };
  delete reglages.fiche;
  reglagesDes.son = reglages.son !== false;
  appliquerStyle();
}

activerInfobulles();
const gardes = await chrome.storage.local.get(['reglages', 'volet']);
volet = { ...volet, ...gardes.volet };
reprendre(gardes.reglages);
appliquerVolet();
relire();
// Le volet d'un autre onglet a changé un réglage : celui-ci suit (et ne le réécrira pas à l'ancienne valeur) ; chacun garde
// l'onglet qu'il montre.
chrome.storage.onChanged.addListener((c, zone) => {
  if (zone !== 'local') return;
  if (c.volet?.newValue) { volet = { ...volet, ...c.volet.newValue }; appliquerVolet(); }
  if (!c.reglages?.newValue) return;
  const { onglet, ...autres } = c.reglages.newValue;
  reprendre(autres);
});
setInterval(() => { if (!document.hidden) relire(); }, RELIRE_MS);
setInterval(majAge, 1000);
