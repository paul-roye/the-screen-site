# Extension Chrome « The Seat · Wild Shape »

Un volet posé dans la page de votre feuille de personnage D&D Beyond, à droite ou à gauche, pour un personnage druide. Elle montre les formes sauvages de votre fiche (Extras), vous transforme d'un clic, et affiche **votre fiche fusionnée avec la forme** tant que vous êtes transformé. Elle note aussi la forme prise sur la fiche, pour le MJ.

Indépendante du gestionnaire : elle ne lit rien de lui et marche sans lui. Seul échange, comme pour l'extension du compagnon : la note de la créature sur D&D Beyond (`formats/note-compagnon.md`).

## Installer (une fois)

1. Décompresser le dossier `extension-druide` quelque part où il restera.
2. Chrome : `chrome://extensions`, activer « Mode développeur ».
3. « Charger l'extension non empaquetée », choisir le dossier `extension-druide`.
4. Épingler l'extension (icône puzzle de la barre d'outils). Être connecté à D&D Beyond dans ce Chrome.
5. Recharger la page de la fiche si elle était déjà ouverte.

Nouvelle version : remplacer le dossier, « Recharger » sur la carte de l'extension, puis recharger la page de la fiche (le volet d'une page déjà ouverte se retire de lui-même).

## Le volet

- Il s'ouvre de lui-même sur la fiche d'un personnage (`dndbeyond.com/characters/<id>`), dans la page, à côté de la feuille. Il suit la fiche affichée, et disparaît ailleurs sur le site.
- Sa **barre d'outils**, en haut (comme celle du bandeau du groupe) : l'âge de la dernière lecture de la fiche (un clic la relit), les **réglages**, **large ou étroit**, **changer de côté** (à droite d'office, ou à gauche), **réduire** le volet à un petit onglet contre le bord (un clic sur l'onglet le ramène tel quel), **fermer**.
- **Étroit** (320 px, d'office) : la même mise en page, avec un texte un peu plus petit. **Large** (400 px) : à sa taille, plus confortable pour la fiche d'une forme.
- Un clic sur **l'icône de l'extension** ouvre ou referme le volet sur la fiche affichée (et le déplie s'il était réduit). Ouvert, réduit, côté, largeur : gardés dans Chrome, retrouvés à la fiche suivante et dans les autres onglets.
- Une seule barre de défilement, fine : celle du volet. La page de la fiche garde la sienne.
- **La feuille se remet en page à côté du volet.** D&D Beyond choisit sa mise en page d'après la largeur de la fenêtre : l'extension lui présente une fenêtre réduite de la largeur du volet (et de la colonne du bandeau du groupe, s'il est à gauche). Il lui faut 1 200 px pour sa mise en page d'ordinateur ; en dessous, elle passe d'elle-même à sa mise en page de tablette, comme dans une fenêtre plus étroite.
- La barre latérale de D&D Beyond (le détail d'un sort, d'un objet…) et ses boutons se rangent au bord de la feuille, à côté du volet, et plus dessous.
- Avec l'extension « The Seat · Party » : le volet s'arrête au-dessus du bandeau quand il est en bas, et se range à droite de sa colonne quand tous deux sont à gauche.

## S'en servir

- En haut : les usages de Forme sauvage en losanges (un clic en dépense ou en rend un) et « Forme humaine ». Le nom, la classe et les PV ne sont plus répétés : ils sont sur la feuille, juste à côté.
- **Formes** : les formes des Extras, avec leur CA réelle (celle du Cercle de la Lune compte), leurs vitesses, leur FP. Un clic sur une ligne : l'aperçu de votre fiche dans cette forme. « Prendre » : la transformation. Une forme au-dessus de votre FP maximum ou une forme volante avant le niveau 8 porte un triangle d'alerte (elle reste possible : c'est votre MJ qui décide).
- La petite flèche d'une forme (au bout de sa ligne, et à côté de son nom sur sa fiche) ouvre **sa fiche officielle sur D&D Beyond**, dans un nouvel onglet ; de même pour les formes du compagnon sauvage.
- « Prendre » dépense un usage, porte les PV temporaires à ce que donne la forme (12 pour un Cercle de la Lune de niveau 4 ; s'il y en a déjà plus, ils restent) et écrit la ligne pour le MJ. Si l'une de ces écritures échoue, les précédentes sont défaites. Sans usage restant, le bouton devient « Sans usage » : transformation sans rien dépenser.
- Transformé : la fiche fusionnée s'affiche (Force, Dextérité, Constitution, CA, vitesses, attaques de la bête ; Intelligence, Sagesse, Charisme et PV du druide ; compétences et sauvegardes : vos maîtrises et celles de la bête, avec votre bonus de maîtrise, ou la valeur du bloc si elle est plus haute). Tous les jets sont des boutons (clic droit : avantage ou désavantage). « Forme humaine » met fin à la transformation : les PV temporaires restent (ils durent jusqu'au repos long).
- **Compagnon** : le rappel de Compagnon sauvage, un bouton pour dépenser un usage, et les formes possibles du familier, chacune avec son bloc de stats. **Règles** : un résumé des règles avec les valeurs de votre niveau.
- Après un changement fait dans le volet, la page de la fiche est rechargée, et le volet avec elle (sinon la fiche réécrirait ses anciennes valeurs au prochain clic). Réglable dans les réglages du volet.

## Réglages (le bouton à curseurs, en haut du volet)

- **Style** : « The Screen » (d'office), la charte du gestionnaire ; ou « D&D Beyond » : la même mise en page aux couleurs de votre fiche, gris sombres de D&D Beyond, titres en Roboto Condensed, et la **couleur de thème de votre fiche** à la place du violet (le rouge de D&D Beyond si la fiche n'en a pas). Les couleurs qui ont un sens ne changent pas (PV critiques, alertes, soins…).
- Recharger la fiche après un changement ; son des dés.

## Ce qu'elle lit et écrit

- Lecture : votre fiche (`character-service.dndbeyond.com`) et le dictionnaire public (`www.dndbeyond.com/api/config/json`), avec votre session (le jeton de session est demandé à `auth-service.dndbeyond.com` par la tâche de fond). Rien de votre fiche n'est envoyé ailleurs que D&D Beyond.
- Écritures, comme la fiche les fait : `PUT …/character/v5/action/limited-use` (les usages), `PUT …/character/v5/life/hp/damage-taken` (PV et PV temporaires), `PUT` ou `DELETE …/character/v5/custom/value` (la note de la forme). La ligne pour le MJ, dans la note de la forme prise : `[Forme sauvage (joueur) : CA 17, PV temp. 12]`. Le reste de la note ne bouge pas.
- Dans la page de D&D Beyond, les scripts du volet ne lisent rien de la fiche : `volet.js` pose le cadre et pousse la page (un `padding` du `body`, variables `--dr-volet-droite` et `--dr-volet-gauche` sur `html`) ; `page.js`, dans la page elle-même, fait lire à la feuille une largeur de fenêtre réduite de la place prise (`window.innerWidth`), rien d'autre.
- Dans Chrome (`chrome.storage.local`) : `volet` (ouvert, réduit, côté, largeur), `reglages` (style, rechargement, son, onglet), `config` (le dictionnaire, gardé un jour).
- Les polices viennent de Google Fonts, comme dans le gestionnaire : celles de la charte, et Roboto Condensed dans le style « D&D Beyond ».

## Noms, images et options

Pour tout druide, l'extension donne le nom français des formes qu'elle connaît (le nom anglais sinon), une image aux ours et aux félins qui n'en ont pas sur D&D Beyond, et les formes du compagnon sauvage (le sort Find Familiar). Un nom personnalisé donné à une forme sur D&D Beyond est respecté.

**Vos options** (ce que vous avez retenu pour une forme) s'écrivent dans les notes de votre fiche D&D Beyond (onglet **Notes**, « Other »), un bloc par forme, terminé par une ligne vide :

```
[Options (joueur) : Petit ours]
Grimpeur : Vitesse d'escalade de 25 ft.
Vitesse : escalade 25
Sprint : Repos court ou long : sa vitesse est triplée jusqu'à la fin du tour.

[Options (joueur) : Grand félin / Lion]
Réception agile : Aucun dégât de chute jusqu'à 40 ft.
```

- L'en-tête donne la forme par son nom anglais ou français, plusieurs séparées par « / ».
- Chaque ligne, « Nom : texte », s'affiche sous « Options retenues » sur la fiche de la forme.
- « Vitesse : escalade 25 » (`marche`, `escalade`, `vol` ou `nage`) ajoute cette vitesse à la forme.
- Le reste de vos notes est ignoré, et l'extension n'y écrit rien.

## Fichiers

- `manifest.json`.
- `fond.js` : tâche de fond (clic sur l'icône, jeton de session).
- `volet.js`, `volet.css` : le script posé sur la fiche D&D Beyond et le style de son cadre (colonne, onglet), dans un Shadow DOM.
- `page.js` : le petit script qui tourne dans la page elle-même, pour que la feuille se mette en page à côté du volet.
- `panneau.html`, `panneau.js`, `style.css` : le volet lui-même, avec sa barre d'outils, une page de l'extension affichée dans le cadre (`panneau.html?fiche=<id>`).
- `beyond.css` : les couleurs du style « D&D Beyond » (les mêmes valeurs que dans l'extension du groupe : les changer dans les deux).
- `js/druide.js` (calculs sans DOM), `js/bestiaire.js` (formes du compagnon sauvage, noms français, images, lecture des options).
- Copies du gestionnaire et de l'extension du compagnon : `js/ui.js`, `js/monstres.js`, `js/lancers.js`, `js/des.js`, `js/des-3d.js`, `js/etats.js`, `js/icones-ui.js`, `charte/`, la première partie de `style.css`. `js/resumer.js` est le même fichier que `extensions/mj/resumer.js` (et `extensions/groupe/resumer.js`) : le modifier dans les trois.
