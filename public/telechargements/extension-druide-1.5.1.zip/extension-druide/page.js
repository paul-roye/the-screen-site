// Extension « The Seat · Wild Shape » : ce script tourne dans la page de la fiche elle-même (monde principal), avant elle.
// La feuille de D&D Beyond choisit sa mise en page (ordinateur, tablette, téléphone) et place sa barre latérale d'après
// window.innerWidth, pas d'après la place qu'on lui laisse : à côté du volet, elle se croyait toujours en pleine fenêtre
// et passait dessous. On lui présente donc une fenêtre réduite de la largeur prise sur la page (le volet, et la colonne du
// bandeau du groupe s'il y en a une), que volet.js note sur <html> (data-aide-druide-retrait, en px) avant d'envoyer un
// événement « resize » : la feuille se remet alors en page comme dans une fenêtre plus étroite. Rien d'autre n'est touché.

(() => {
  const html = document.documentElement;
  const d = Object.getOwnPropertyDescriptor(window, 'innerWidth') || Object.getOwnPropertyDescriptor(Window.prototype, 'innerWidth');
  if (!d?.get) return;
  const retrait = () => Math.max(0, Number(html.dataset.aideDruideRetrait) || 0);
  try {
    Object.defineProperty(window, 'innerWidth', {
      configurable: true, enumerable: true,
      get() { const reel = d.get.call(window); return Math.max(Math.min(reel, 320), reel - retrait()); },
      set(v) { d.set?.call(window, v); },
    });
  } catch { /* la page garde sa vraie largeur : le volet passe par-dessus son bord */ }
})();
