// Extension « The Seat · Wild Shape » : le volet, posé dans la page de la fiche D&D Beyond (comme le bandeau de l'extension du
// groupe). Une colonne fixe à droite ou à gauche, étroite ou large, dans un Shadow DOM pour ne rien mélanger avec la page
// (style : volet.css, couleurs : charte/tokens.css et beyond.css) : le volet lui-même est panneau.html dans un cadre (une page de l'extension : elle lit et écrit sur
// D&D Beyond, ce script ne lit rien), avec sa barre d'outils. La page de la fiche est poussée de la largeur du volet, et
// la feuille de D&D Beyond croit sa fenêtre réduite d'autant (page.js), pour se remettre en page à côté de lui.
// Ouvert, réduit, côté, largeur : gardés dans Chrome (clé « volet »), changés par la barre d'outils du volet (panneau.js)
// ou par un clic sur l'icône de l'extension (fond.js), retrouvés à la fiche suivante.

(() => {
  const FICHE = /^\/(?:profile\/[^/]+\/)?characters\/(\d+)\/?$/;
  const LARGEURS = { etroit: 320, large: 400 };
  const DEFAUTS = { ouvert: true, reduit: false, cote: 'droite', largeur: 'etroit' };
  const NS = 'http://www.w3.org/2000/svg';
  const GRIFFE = 'M7 3.5c1.2 5.4.6 10.8-2.2 16.5M12 3c1.1 6 .7 12-1.6 18M17 3.5c1.1 5.4.7 10.8-1.9 16.5';   // l'icône de la charte
  // La page fait de la place au volet. À gauche, l'extension du groupe pousse déjà la page de la largeur de sa colonne
  // (body, padding-left) : cette règle-ci l'emporte (« html body »), et additionne les deux.
  const MARGES = {
    droite: 'html body { padding-right: var(--dr-volet-droite, 0px) !important; }',
    gauche: 'html body { padding-left: calc(var(--bd-groupe-gauche, 0px) + var(--dr-volet-gauche, 0px)) !important; }',
  };
  // La barre latérale de D&D Beyond et ses boutons flottants se placent dans la fenêtre entière : on les ramène au bord de
  // la place laissée à la feuille. Les marges ne jouent que du côté où l'élément est ancré ; ses classes portent un suffixe
  // qui change à chaque version de la feuille, d'où le sélecteur par début de nom. Repliée, la barre garde sa flèche, et un
  // bouton de placement qui, au bord de la fenêtre, sort de l'écran : ramené ici, il tomberait sur le volet.
  const BEYOND = `.ct-sidebar__portal [class*="styles_sidebar__"] { margin-right: var(--dr-volet-droite, 0px) !important; margin-left: calc(var(--bd-groupe-gauche, 0px) + var(--dr-volet-gauche, 0px)) !important; }
.ct-sidebar__portal [class*="styles_sidebar__"][class*="styles_hidden__"] { overflow: hidden !important; }
.ct-sidebar__portal [class*="styles_sidebar__"][class*="styles_hidden__"] [class*="styles_placement__"] { display: none !important; }
[class*="styles_mobileNav__"] { right: var(--dr-volet-droite, 0px) !important; }`;

  let etat = { ...DEFAUTS }, style = 'screen';   // style : celui choisi dans les réglages du volet (The Screen, D&D Beyond)
  let hote = null, racine = null, marge = null, ficheId = null;
  let dessine = null;   // l'empreinte du dernier dessin : rien n'est redessiné quand rien n'a changé
  let feuille = null;   // le CSS du volet, lu une seule fois

  // L'extension rechargée ou retirée pendant que la page est ouverte : ce script n'a plus accès à rien, le volet se retire.
  const vivant = () => { try { return !!chrome.runtime?.id; } catch { return false; } };

  function garder(changements) {
    etat = { ...etat, ...changements };
    try { chrome.storage.local.set({ volet: etat }).catch(() => {}); } catch { /* extension rechargée : le volet se retire au prochain tour */ }
    suivre();
  }

  // La place prise sur la page, et ce que la feuille de D&D Beyond doit en savoir (page.js) : la largeur du volet, plus
  // celle de la colonne du bandeau du groupe, qui ne le lui dit pas elle-même.
  function marges() {
    const html = document.documentElement, gauche = etat.cote === 'gauche';
    const pousse = racine && !etat.reduit ? LARGEURS[etat.largeur] || LARGEURS.etroit : 0;
    html.style.setProperty('--dr-volet-droite', gauche ? '0px' : `${pousse}px`);
    html.style.setProperty('--dr-volet-gauche', gauche ? `${pousse}px` : '0px');
    if (marge) marge.textContent = pousse ? `${MARGES[gauche ? 'gauche' : 'droite']}\n${BEYOND}` : '';
    const groupe = pousse ? parseFloat(getComputedStyle(html).getPropertyValue('--bd-groupe-gauche')) || 0 : 0;
    const retrait = String(Math.round(pousse + groupe));
    if ((html.dataset.aideDruideRetrait || '0') !== retrait) {
      html.dataset.aideDruideRetrait = retrait;
      dispatchEvent(new Event('resize'));   // la feuille relit sa largeur
    }
  }

  function dessiner() {
    if (!racine) return;
    const empreinte = JSON.stringify([etat, style, ficheId]);
    if (empreinte !== dessine) {
      const volet = racine.querySelector('.dr-volet');
      volet.dataset.cote = etat.cote === 'gauche' ? 'gauche' : 'droite';
      volet.dataset.style = style;
      volet.style.setProperty('--largeur', `${LARGEURS[etat.largeur] || LARGEURS.etroit}px`);
      volet.classList.toggle('est-reduit', !!etat.reduit);
      // Le volet lui-même : chargé quand il se montre pour la première fois, rechargé quand la fiche change.
      let page = volet.querySelector('iframe');
      if (!etat.reduit && !page) volet.querySelector('.cadre').append(page = document.createElement('iframe'));
      if (page && page.dataset.fiche !== ficheId) {
        page.title = 'The Seat · Wild Shape';
        page.dataset.fiche = ficheId;
        page.src = `${chrome.runtime.getURL('panneau.html')}?fiche=${ficheId}`;
      }
      dessine = empreinte;
    }
    marges();
  }

  async function monter() {
    const lire = chemin => fetch(chrome.runtime.getURL(chemin)).then(r => r.text()).catch(() => '');
    feuille ??= Promise.all(['charte/tokens.css', 'beyond.css', 'volet.css'].map(lire)).then(([jetons, beyond, volet]) =>
      jetons.replace(/:root(,\s*\[data-theme="nuit"\])?/g, ':host').replace(/\[data-theme="[a-z]+"\]\s*\{[^}]*\}/g, '') + beyond + volet);
    const css = await feuille;
    if (hote?.isConnected || !ficheId || !etat.ouvert) return;   // monté entre-temps, ou plus rien à montrer
    hote = document.createElement('div');
    hote.id = 'aide-druide-dndbeyond';
    racine = hote.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = css;
    // L'onglet du volet réduit : la griffe de la charte.
    const onglet = document.createElement('button');
    onglet.type = 'button'; onglet.className = 'onglet'; onglet.title = 'Montrer l\'aide du druide';
    onglet.setAttribute('aria-label', onglet.title);
    onglet.addEventListener('click', () => garder({ reduit: false }));
    const svg = document.createElementNS(NS, 'svg'), trace = document.createElementNS(NS, 'path');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('aria-hidden', 'true');
    trace.setAttribute('d', GRIFFE);
    svg.append(trace); onglet.append(svg);
    const volet = document.createElement('div'), cadre = document.createElement('div');
    volet.className = 'dr-volet'; cadre.className = 'cadre';
    volet.append(onglet, cadre);
    racine.append(style, volet);
    document.body.append(hote);
    marge = document.getElementById('aide-druide-marge');
    if (!marge) { marge = document.createElement('style'); marge.id = 'aide-druide-marge'; document.head.append(marge); }
    dessine = null;
    dessiner();
  }
  function demonter() {
    hote?.remove();
    hote = null; racine = null; dessine = null;
    if (marge) marge.textContent = '';
    marges();   // plus rien de pris sur la page : la feuille retrouve sa vraie largeur
    document.documentElement.style.removeProperty('--dr-volet-droite');
    document.documentElement.style.removeProperty('--dr-volet-gauche');
  }

  // Sur une fiche, volet ouvert : il est là, à jour ; sinon (une autre page du site, volet fermé) : il se démonte.
  function suivre() {
    ficheId = FICHE.exec(location.pathname)?.[1] || null;
    if (!ficheId || !etat.ouvert) return demonter();
    if (hote?.isConnected) dessiner(); else monter();
  }

  // Le volet demande de recharger la fiche après une écriture (panneau.js) : la page ouverte ne voit pas ce qui s'écrit à
  // côté d'elle, et réécrirait ses anciennes valeurs. Seul le cadre de l'extension est écouté.
  const ORIGINE = chrome.runtime.getURL('').replace(/\/$/, '');   // chrome-extension://<id de l'extension>
  addEventListener('message', e => {
    if (e.origin !== ORIGINE || e.data?.aideDruide !== 'recharger') return;
    if (e.source === racine?.querySelector('iframe')?.contentWindow) location.reload();
  });
  // Un clic sur l'icône de l'extension (fond.js) : ouvrir, déplier s'il est réduit, sinon fermer.
  chrome.runtime.onMessage.addListener(m => {
    if (m?.type !== 'basculer' || !FICHE.test(location.pathname)) return;
    garder(!etat.ouvert ? { ouvert: true, reduit: false } : etat.reduit ? { reduit: false } : { ouvert: false });
  });
  // La barre d'outils du volet, ou un autre onglet, a déplacé, élargi, réduit ou fermé le volet : celui-ci suit.
  chrome.storage.onChanged.addListener((c, zone) => {
    if (zone !== 'local' || (!c.volet && !c.reglages)) return;
    if (c.volet) etat = { ...DEFAUTS, ...c.volet.newValue };
    if (c.reglages) style = c.reglages.newValue?.style === 'beyond' ? 'beyond' : 'screen';
    suivre();
  });

  chrome.storage.local.get(['volet', 'reglages']).then(({ volet, reglages }) => {
    etat = { ...DEFAUTS, ...volet };
    style = reglages?.style === 'beyond' ? 'beyond' : 'screen';
    suivre();
    // Chaque seconde : la fiche a changé (D&D Beyond navigue sans recharger la page), la page a retiré le volet, la colonne
    // du bandeau du groupe a changé de largeur.
    let chemin = location.pathname;
    const tour = setInterval(() => {
      if (!vivant()) { clearInterval(tour); demonter(); return; }
      if (location.pathname !== chemin) { chemin = location.pathname; suivre(); }
      if (ficheId && etat.ouvert && hote && !hote.isConnected) { hote = null; racine = null; monter(); }
      if (racine) marges();
    }, 1000);
  });
})();
