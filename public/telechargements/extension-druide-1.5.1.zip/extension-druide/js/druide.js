// Calculs de l'extension « The Seat · Wild Shape », sans accès au DOM : les formes de la fiche, la forme prise (une ligne dans la
// note de la créature), les usages, les règles selon le niveau et le cercle, et la fiche fusionnée quand le druide est
// transformé. d : fiche brute de D&D Beyond (character-service v5) ; f : son résumé (resumer.js).

import { COMPETENCES } from './resumer.js';

const CARAC = ['for', 'dex', 'con', 'int', 'sag', 'cha'];
const mod = v => Math.floor((v - 10) / 2);

// Groupes d'« extras » des formes sauvages : 13 « Wild Shape (2024) » (vu sur une vraie fiche, 2026-11-09), 3 l'ancien.
export const GROUPES_FORME = [3, 13];
const CREATURE_CA = 42, CREATURE_NOTES = 47;

// La forme prise est dite dans la note de la créature (contrat : formats/note-compagnon.md du gestionnaire) :
// « [Forme sauvage (joueur) : CA 17, PV temp. 12] ». Le reste de la note n'est jamais touché.
const LIGNE_FORME = /[ \t]*\[\s*Forme\s+sauvage\s*\(\s*joueur\s*\)[^\]\n]*\][ \t]*(?:\r?\n)?/giu;
const A_LA_LIGNE = /\[\s*Forme\s+sauvage\s*\(\s*joueur\s*\)[^\]\n]*\]/iu;
export const avecLigneForme = note => A_LA_LIGNE.test(String(note || ''));
export function noteAvecForme(avant, ligne) {
  const reste = String(avant || '').replace(LIGNE_FORME, '').replace(/\n{3,}/g, '\n\n').trim();
  return [reste, ligne].filter(Boolean).join('\n');
}

export function valeurCreature(d, cr, typeId) {
  const v = (d.characterValues || []).find(x => x.typeId === typeId && String(x.valueId) === String(cr.id)
    && (x.valueTypeId == null || cr.entityTypeId == null || String(x.valueTypeId) === String(cr.entityTypeId)));
  return v?.value ?? null;
}
export const noteDe = (d, cr) => String(valeurCreature(d, cr, CREATURE_NOTES) || '');
export const formesDe = d => (d.creatures || []).filter(c => GROUPES_FORME.includes(c.groupId));
export const formeActive = d => formesDe(d).find(c => avecLigneForme(noteDe(d, c))) || null;
export const nomForme = cr => String(cr?.name || cr?.definition?.name || 'Forme').trim();

// L'action « Wild Shape » de la fiche et ses usages. Rien sur la fiche : null.
export function usagesDe(d, maitrise) {
  const a = Object.values(d.actions || {}).flat().find(x => x?.limitedUse && /^\s*wild\s*shape\s*$/i.test(x.name || ''));
  if (!a) return null;
  const u = a.limitedUse;
  const max = (u.maxUses || 0) + (u.useProficiencyBonus ? maitrise : 0);
  return { id: a.id, entityTypeId: a.entityTypeId, utilises: u.numberUsed || 0, max, restants: Math.max(0, max - (u.numberUsed || 0)) };
}

// Ce que les règles donnent selon le niveau de druide et le cercle (Player's Handbook 2024, table Beast Shapes). null : pas
// de niveau de druide sur cette fiche.
export function regleDuDruide(d, f) {
  const classe = (d.classes || []).find(c => /druid/i.test(c.definition?.name || ''));
  if (!classe) return null;
  const niveau = classe.level;
  const sousClasse = classe.subclassDefinition?.name || '';
  const lune = /moon|lune/i.test(sousClasse);
  const fpTable = niveau >= 8 ? 1 : niveau >= 4 ? 0.5 : 0.25;
  return {
    niveau, sousClasse, lune,
    connues: niveau >= 8 ? 8 : niveau >= 4 ? 6 : 4,
    fpMax: lune && niveau >= 3 ? Math.max(fpTable, Math.floor(niveau / 3)) : fpTable,
    vol: niveau >= 8,
    dureeH: Math.max(1, Math.floor(niveau / 2)),
    pvTemp: lune && niveau >= 3 ? 3 * niveau : niveau,
    caMin: lune && niveau >= 3 ? 13 + f.caracteristiques.sag.mod : null,
    sortsDuCercle: !lune ? [] : [[3, 'Cure Wounds'], [3, 'Moonbeam'], [3, 'Starry Wisp'], [5, 'Conjure Animals'], [7, 'Fount of Moonlight'], [9, 'Mass Cure Wounds']]
      .filter(([n]) => niveau >= n).map(([, nom]) => nom),
  };
}

export const caDeForme = (d, cr, regle) => Math.max(Number(valeurCreature(d, cr, CREATURE_CA)) || cr.definition?.armorClass || 0, regle?.caMin ?? 0);

// La fiche du druide dans cette forme, selon les règles de 2024 : Force, Dextérité, Constitution, CA, vitesses et attaques
// de la bête ; Intelligence, Sagesse, Charisme, PV, dons et capacités du druide. Compétences et sauvegardes : les maîtrises
// du druide et celles de la bête, avec le bonus de maîtrise du druide ; si la valeur du bloc de stats est plus haute, elle
// l'emporte. cfg : le dictionnaire de D&D Beyond (pour le bonus de maîtrise du FP de la bête).
export function fusionner(d, f, cr, regle, cfg) {
  const def = cr.definition || {};
  const statBete = id => def.stats?.find(s => s.statId === id)?.value ?? 10;
  const valeurs = CARAC.map((k, i) => (i < 3 ? statBete(i + 1) : f.caracteristiques[k].valeur));
  const modDe = k => mod(valeurs[CARAC.indexOf(k)]);
  const pb = f.maitrise;
  const pbBete = (cfg?.puissances || []).find(x => x.id === def.challengeRatingId)?.maitrise ?? 2;

  const sauvegardes = Object.fromEntries(CARAC.map((k, i) => {
    const p = f.caracteristiques[k];
    const reste = p.sauvegarde - p.mod;   // sa maîtrise et ses bonus, sans la caractéristique
    const s = def.savingThrows?.find(x => x.statId === i + 1);
    const calcul = modDe(k) + Math.max(reste, s ? pb : 0);
    const bloc = s ? mod(statBete(i + 1)) + pbBete + (s.bonusModifier || 0) : -Infinity;
    return [k, { bonus: Math.max(calcul, bloc), maitrise: !!p.maitrise_sauvegarde || !!s }];
  }));

  const competences = COMPETENCES.map(({ id, cle, nom, carac }) => {
    const p = f.competences[cle];
    const reste = p.bonus - f.caracteristiques[carac].mod;   // sa maîtrise et ses bonus, sans la caractéristique
    const s = def.skills?.find(x => x.skillId === id);
    const bloc = s ? (s.value || 0) + (s.additionalBonus || 0) : -Infinity;
    const calcul = modDe(carac) + Math.max(reste, s ? pb : 0);
    return { id, cle, nom, carac, bonus: Math.max(calcul, bloc), maitrise: p.maitrise || (s ? 'maitrise' : null), avantage: p.avantage, desavantage: p.desavantage };
  });
  const perception = competences.find(c => c.cle === 'perception').bonus;
  const passive = Math.max(10 + perception + (f.passives.perception - 10 - f.competences.perception.bonus), def.passivePerception ?? 0);
  const initiative = Math.max(modDe('dex') + (f.initiative - f.caracteristiques.dex.mod), def.initiative?.bonus ?? -Infinity);

  const ca = caDeForme(d, cr, regle);
  return {
    ca,
    caDetail: regle?.caMin != null && regle.caMin > (def.armorClass || 0) ? `(13 + Sagesse ; ${def.armorClass} pour la bête)` : (def.armorClassDescription || ''),
    caracteristiques: Object.fromEntries(CARAC.map((k, i) => [k, { valeur: valeurs[i], mod: modDe(k), bete: i < 3 }])),
    sauvegardes, competences, initiative, passive,
  };
}

// La définition à donner au bloc de stats : celle de la bête, avec les valeurs du druide transformé. Les jets de sauvegarde
// et les compétences sont refaits à part, les PV sont ceux du druide (la barre, en haut).
export function definitionFusionnee(cr, fusion, nom, vitesses = null) {
  const def = cr.definition || {};
  return { ...def, name: nom, armorClass: fusion.ca, armorClassDescription: fusion.caDetail, hitPointDice: null,
    stats: CARAC.map((k, i) => ({ statId: i + 1, value: fusion.caracteristiques[k].valeur })),
    savingThrows: [], skills: [], skillsHtml: null, initiativeBonus: fusion.initiative, passivePerception: fusion.passive,
    movements: vitesses || def.movements };
}
