// Ce que la fiche D&D Beyond ne dit pas sur les formes d'un druide. Rien ici ne suppose une fiche :
// - les formes du compagnon sauvage (le sort Find Familiar), les mêmes pour tout druide. Traits résumés en français ; les
//   attaques gardent la tournure anglaise de la fiche (« Melee Attack Roll: +5 … Hit: 7 (1d8 + 3) »), que le bloc de stats
//   transforme en boutons de jet ;
// - les noms français des formes courantes, et une image pour celles qui n'en ont pas sur D&D Beyond ;
// - les options retenues par le joueur, qu'il écrit dans les notes de sa fiche (formats/note-compagnon.md du gestionnaire).

import { texte } from './resumer.js';

const COMPETENCE = { perception: 14, discretion: 5, acrobaties: 3, survie: 15 };
const FP = { 0: 1, 0.125: 2, 0.25: 3, 0.5: 4, 1: 5 };   // challengeRatingId de D&D Beyond
const MOUVEMENT = { marche: 1, escalade: 3, vol: 4, nage: 5 };

// Les bêtes officielles sur D&D Beyond (versions 2024, relevées le 2026-11-09 sur son service public des monstres) :
// [id, portrait, grande image]. De quoi montrer leur image et ouvrir leur fiche officielle.
const AVATARS = 'https://www.dndbeyond.com/avatars/';
const OFFICIELS = {
  Bat: [4775803, '43938/917/638607409598192740.jpeg', '43938/918/638607409599142805.png'],
  Cat: [4775808, '43939/80/638607414146520300.jpeg', '43939/81/638607414147450285.png'],
  Hawk: [4775824, '43939/626/638607427375996839.jpeg', '43939/627/638607427377886676.png'],
  Lizard: [4775827, '58415/744/639226667170988945.jpeg', '58415/745/639226667173629035.jpeg'],
  Owl: [4775831, '47158/950/638742837729688628.jpeg', '47158/951/638742837731128628.png'],
  Rat: [4775836, '47158/969/638742838302908263.jpeg', '47158/970/638742838304678258.jpeg'],
  Raven: [4775837, '47158/984/638742838862827460.jpeg', '47158/985/638742838863997460.png'],
  Spider: [4775844, '43939/861/638607433376132965.jpeg', '43939/862/638607433377512962.png'],
  Weasel: [4775849, '58416/835/639226704577624798.jpeg', '58416/836/639226704580244808.jpeg'],
};
const officiel = nom => {
  const [id, petit, grand] = OFFICIELS[nom] || [];
  return id ? { avatarUrl: AVATARS + petit, largeAvatarUrl: AVATARS + grand, url: `https://www.dndbeyond.com/monsters/${id}` } : { avatarUrl: null, largeAvatarUrl: null };
};

const trait = (nom, texte) => `<p><em><strong>${nom}.</strong></em> ${texte}</p>`;
const attaque = (nom, bonus, allonge, degats, suite = '') => `<p><em><strong>${nom}.</strong></em> <em>Melee Attack Roll:</em> ${bonus}, reach ${allonge} ft. <em>Hit:</em> ${degats}${suite ? ` ${suite}` : ''}</p>`;

// Une bête au format d'une définition de créature de D&D Beyond.
function bete(id, name, { taille, ca, pv, des, vitesses, stats, fp, competences = {}, vision = null, passive, traits = '', actions = '', bonus = '', reactions = '', initiative = null }) {
  return {
    id, name, sizeId: taille, typeId: 2, alignmentId: 10, armorClass: ca, armorClassDescription: '', averageHitPoints: pv, hitPointDice: des ? { diceString: des } : null,
    movements: Object.entries(vitesses).map(([k, speed]) => ({ movementId: MOUVEMENT[k], speed, notes: null })),
    stats: stats.map((value, i) => ({ statId: i + 1, name: null, value })), savingThrows: [],
    skills: Object.entries(competences).map(([k, value]) => ({ skillId: COMPETENCE[k], value, additionalBonus: null })),
    senses: vision ? [{ senseId: vision[0], notes: `${vision[1]} ft.` }] : [], passivePerception: passive, damageAdjustments: [], conditionImmunities: [], languages: [],
    challengeRatingId: FP[fp], specialTraitsDescription: traits, actionsDescription: actions, bonusActionsDescription: bonus, reactionsDescription: reactions,
    initiative: initiative == null ? null : { bonus: initiative, score: 10 + initiative }, isHomebrew: false, ...officiel(name),
  };
}
const SOMBRE = 2, AVEUGLE = 1;   // senseId : vision dans le noir, vision aveugle

// Formes du compagnon sauvage (le sort Find Familiar).
const griffe = (nom, bonus, type, suite = '') => attaque(nom, bonus, 5, `1 ${type} damage.`, suite);
const FAMILIERS = [
  bete(-11, 'Bat', { taille: 2, ca: 12, initiative: 2, pv: 1, des: '1d4 - 1', vitesses: { marche: 5, vol: 30 }, stats: [2, 15, 8, 2, 12, 4], fp: 0, vision: [AVEUGLE, 60], passive: 11, actions: griffe('Morsure (Bite)', '+4', 'Piercing') }),
  bete(-12, 'Cat', { taille: 2, ca: 12, initiative: 2, pv: 2, des: '1d4', vitesses: { marche: 40, escalade: 40 }, stats: [3, 15, 10, 3, 12, 7], fp: 0, competences: { perception: 3, discretion: 4 }, vision: [SOMBRE, 60], passive: 13, traits: trait('Sauteur', 'Distance de saut calculée avec la Dextérité.'), actions: griffe('Griffure (Scratch)', '+4', 'Slashing') }),
  bete(-13, 'Hawk', { taille: 2, ca: 13, initiative: 3, pv: 1, des: '1d4 - 1', vitesses: { marche: 10, vol: 60 }, stats: [5, 16, 8, 2, 14, 6], fp: 0, competences: { perception: 6 }, passive: 16, actions: griffe('Serres (Talons)', '+5', 'Slashing') }),
  bete(-14, 'Lizard', { taille: 2, ca: 10, initiative: 0, pv: 2, des: '1d4', vitesses: { marche: 20, escalade: 20 }, stats: [2, 11, 10, 1, 8, 3], fp: 0, vision: [SOMBRE, 30], passive: 9, traits: trait('Pattes d\'araignée', 'Grimpe sur les surfaces difficiles et au plafond, sans test.'), actions: griffe('Morsure (Bite)', '+2', 'Piercing') }),
  bete(-15, 'Owl', { taille: 2, ca: 11, initiative: 1, pv: 1, des: '1d4 - 1', vitesses: { marche: 5, vol: 60 }, stats: [3, 13, 8, 2, 12, 7], fp: 0, competences: { perception: 5, discretion: 5 }, vision: [SOMBRE, 120], passive: 15, traits: trait('Vol rasant', 'Ne provoque pas d\'attaque d\'opportunité en quittant l\'allonge d\'un ennemi.'), actions: griffe('Serres (Talons)', '+3', 'Slashing') }),
  bete(-16, 'Rat', { taille: 2, ca: 10, initiative: 0, pv: 1, des: '1d4 - 1', vitesses: { marche: 20, escalade: 20 }, stats: [2, 11, 9, 2, 10, 4], fp: 0, competences: { perception: 2 }, vision: [SOMBRE, 30], passive: 12, traits: trait('Agile', 'Ne provoque pas d\'attaque d\'opportunité en quittant l\'allonge d\'un ennemi.'), actions: griffe('Morsure (Bite)', '+2', 'Piercing') }),
  bete(-17, 'Raven', { taille: 2, ca: 12, initiative: 2, pv: 2, des: '1d4', vitesses: { marche: 10, vol: 50 }, stats: [2, 14, 10, 5, 13, 6], fp: 0, competences: { perception: 3 }, passive: 13, traits: trait('Imitation', 'Imite des sons simples déjà entendus ; DD 10 d\'Intuition pour déceler l\'imitation.'), actions: griffe('Bec (Beak)', '+4', 'Piercing') }),
  bete(-18, 'Spider', { taille: 2, ca: 12, initiative: 2, pv: 1, des: '1d4 - 1', vitesses: { marche: 20, escalade: 20 }, stats: [2, 14, 8, 1, 10, 2], fp: 0, competences: { discretion: 4 }, vision: [SOMBRE, 30], passive: 10, traits: trait('Pattes d\'araignée', 'Grimpe sur les surfaces difficiles et au plafond, sans test.') + trait('Marche sur les toiles', 'Ignore les restrictions de mouvement des toiles ; sent toute créature au contact de la même toile.'), actions: attaque('Morsure (Bite)', '+4', 5, '1 Piercing damage plus 2 (1d4) Poison damage.') }),
  bete(-19, 'Weasel', { taille: 2, ca: 13, initiative: 3, pv: 1, des: '1d4 - 1', vitesses: { marche: 30, escalade: 30 }, stats: [3, 16, 8, 2, 12, 3], fp: 0, competences: { acrobaties: 5, perception: 3, discretion: 5 }, vision: [SOMBRE, 60], passive: 13, actions: griffe('Morsure (Bite)', '+5', 'Piercing') }),
];
const NOMS_FAMILIERS = { Bat: 'Chauve-souris', Cat: 'Chat', Hawk: 'Faucon', Lizard: 'Lézard', Owl: 'Chouette', Rat: 'Rat', Raven: 'Corbeau', Spider: 'Araignée', Weasel: 'Belette' };

// Noms français des formes (le nom anglais reste au survol).
const NOMS = {
  'Little Bear (Medium)': 'Petit ours', 'Wildcat (Medium)': 'Grand félin', Elk: 'Élan', 'Giant Frog': 'Grenouille géante', 'Giant Octopus': 'Pieuvre géante',
  'Giant Spider': 'Araignée géante', Lion: 'Lion', 'Giant Toad': 'Crapaud géant', 'Little Wildcat': 'Chat sauvage',
};
export const nomFr = nom => NOMS[nom] || null;
export const nomFamilier = nom => NOMS_FAMILIERS[nom] || nom;

// Une forme sans image sur D&D Beyond prend celle d'une bête proche : les ours celle de « Bear (MCDM) » (monstre 4485785),
// les félins celle de « Wildcat (Large) » (monstre 4486046).
const IMAGES_DEFAUT = [[/\bbear\b/i, AVATARS + '41759/296/638512253691009202.jpeg'], [/wildcat/i, AVATARS + '41759/673/638512254347451795.jpeg']];
const imageDefaut = nom => IMAGES_DEFAUT.find(([re]) => re.test(String(nom || '')))?.[1] || null;

// L'image d'une forme : la sienne (grande = l'illustration, sinon le portrait), sinon celle d'une bête proche.
export const imageDe = (def, grande = false) => (grande && def?.largeAvatarUrl) || def?.avatarUrl || imageDefaut(def?.name);

// ───── Les options retenues ─────

// Dans les notes de la fiche (onglet Notes, « Other »), un bloc par forme, qui s'arrête à la première ligne vide :
//   [Options (joueur) : Petit ours]
//   Grimpeur : Vitesse d'escalade de 25 ft.
//   Vitesse : escalade 25
// L'en-tête donne la forme par son nom anglais ou français, plusieurs séparées par « / ».
const ENTETE = /^\[\s*options\s*\(\s*joueur\s*\)\s*:\s*([^\]]*)\]$/iu;
const VITESSE = /^vitesse\s*:\s*(marche|escalade|vol|nage)\s+(\d+)/iu;
const cle = s => String(s || '').trim().toLowerCase();

export function lireOptions(notes) {
  const blocs = [];
  let bloc = null;
  for (const brute of texte(notes).split('\n')) {
    const ligne = brute.trim().replace(/^[-•*]\s*/, '');
    const m = ENTETE.exec(ligne);
    if (m) { bloc = { formes: m[1].split('/').map(cle).filter(Boolean), traits: [], vitesses: {} }; blocs.push(bloc); continue; }
    if (!bloc) continue;
    if (!ligne || ligne.startsWith('[')) { bloc = null; continue; }
    const v = VITESSE.exec(ligne);
    if (v) { bloc.vitesses[v[1].toLowerCase()] = Number(v[2]); continue; }
    const i = ligne.indexOf(':');
    bloc.traits.push(i > 0 ? [ligne.slice(0, i).trim(), ligne.slice(i + 1).trim()] : [ligne, '']);
  }
  return blocs;
}

// Les options de cette forme sur cette fiche : null s'il n'y en a pas.
export function optionsDe(d, cr) {
  const noms = [cr?.name, cr?.definition?.name, nomFr(cr?.definition?.name), nomFr(cr?.name)].map(cle).filter(Boolean);
  const blocs = lireOptions(d?.notes?.otherNotes).filter(b => b.formes.some(f => noms.includes(f)));
  if (!blocs.length) return null;
  return { traits: blocs.flatMap(b => b.traits), vitesses: Object.assign({}, ...blocs.map(b => b.vitesses)) };
}

export { FAMILIERS, MOUVEMENT };
