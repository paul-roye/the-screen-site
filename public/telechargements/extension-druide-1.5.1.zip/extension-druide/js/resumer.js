// Résumé d'une fiche brute de D&D Beyond (API character-service, v5) : ce qui sert au MJ à la table.
// Module partagé : importé par l'extension (fond.js) et par le gestionnaire (app/beyond.js). Aucun accès au DOM.
// Format produit : formats/etat.md (beyond.json). Distances en pieds, comme sur la fiche.

export const ORIGINE_BEYOND = 'https://www.dndbeyond.com';

const CARAC = ['for', 'dex', 'con', 'int', 'sag', 'cha'];
const CARAC_EN = ['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma'];
const CLASSES = {
  Artificer: 'Artificier', Barbarian: 'Barbare', Bard: 'Barde', Cleric: 'Clerc', Druid: 'Druide', Fighter: 'Guerrier',
  Monk: 'Moine', Paladin: 'Paladin', Ranger: 'Rôdeur', Rogue: 'Roublard', Sorcerer: 'Ensorceleur', Warlock: 'Occultiste', Wizard: 'Magicien',
};
// Identifiants des états de D&D Beyond (ordre alphabétique anglais).
const ETATS = [null, 'Aveuglé', 'Charmé', 'Assourdi', 'Épuisement', 'Effrayé', 'Agrippé', 'Neutralisé', 'Invisible',
  'Paralysé', 'Pétrifié', 'Empoisonné', 'À terre', 'Entravé', 'Étourdi', 'Inconscient'];
const RECUP = { 1: 'repos court', 2: 'repos long', 3: 'aube' };
const RARETES = { Common: 'Commun', Uncommon: 'Peu commun', Rare: 'Rare', 'Very Rare': 'Très rare', Legendary: 'Légendaire', Artifact: 'Artefact', Varies: 'Variable' };
// Historiques des règles 2024 et de quelques aventures, en VF ; les autres restent sous leur nom anglais.
const HISTORIQUES = {
  Acolyte: 'Acolyte', Artisan: 'Artisan', Charlatan: 'Charlatan', Criminal: 'Criminel', Entertainer: 'Artiste', Farmer: 'Fermier',
  Guard: 'Garde', Guide: 'Guide', Hermit: 'Ermite', Merchant: 'Marchand', Noble: 'Noble', Sage: 'Sage', Sailor: 'Marin',
  Scribe: 'Scribe', Soldier: 'Soldat', Wayfarer: 'Voyageur', 'Haunted One': 'Hanté',
};
const ORDRE_RARETE = ['Artifact', 'Legendary', 'Very Rare', 'Rare', 'Uncommon', 'Varies', 'Common'];
const TYPES_OBJET = { Weapon: 'arme', Armor: 'armure', 'Other Gear': 'équipement' };   // filterType d'un objet de D&D Beyond
// Déplacements des créatures (movementId) et groupes d'« extras ».
const MOUVEMENTS = [null, 'marche', 'fouissement', 'escalade', 'vol', 'nage'];
const GROUPES = { 1: 'compagnon', 2: 'familier', 3: 'forme sauvage', 4: 'monture', 13: 'forme sauvage' };
// Formes sauvages d'un druide dans ses extras (13 : « Wild Shape (2024) », 3 : l'ancien groupe) : pas des compagnons.
const GROUPES_FORME = [3, 13];
// Compétences : identifiant de D&D Beyond (abilitySkills de api/config/json, celui des blocs de créature et de monstre),
// sous-type de ses modificateurs, nom VF du DRS 5.2.1, caractéristique. Partagé avec le gestionnaire (fiches de héros et
// de monstres, jets de groupe).
export const COMPETENCES = [
  [2, 'athletics', 'Athlétisme', 'for'], [3, 'acrobatics', 'Acrobaties', 'dex'], [4, 'sleight-of-hand', 'Escamotage', 'dex'],
  [5, 'stealth', 'Discrétion', 'dex'], [6, 'arcana', 'Arcanes', 'int'], [7, 'history', 'Histoire', 'int'],
  [8, 'investigation', 'Investigation', 'int'], [9, 'nature', 'Nature', 'int'], [10, 'religion', 'Religion', 'int'],
  [11, 'animal-handling', 'Dressage', 'sag'], [12, 'insight', 'Intuition', 'sag'], [13, 'medicine', 'Médecine', 'sag'],
  [14, 'perception', 'Perception', 'sag'], [15, 'survival', 'Survie', 'sag'], [16, 'deception', 'Tromperie', 'cha'],
  [17, 'intimidation', 'Intimidation', 'cha'], [18, 'performance', 'Représentation', 'cha'], [19, 'persuasion', 'Persuasion', 'cha'],
].map(([id, cle, nom, carac]) => ({ id, cle, nom, carac }));
const COMPETENCE_INTUITION = 12;
// Emplacements par niveau de lanceur (table du multiclassage).
const TABLE_LANCEUR = [[], [2], [3], [4, 2], [4, 3], [4, 3, 2], [4, 3, 3], [4, 3, 3, 1], [4, 3, 3, 2], [4, 3, 3, 3, 1],
  [4, 3, 3, 3, 2], [4, 3, 3, 3, 2, 1], [4, 3, 3, 3, 2, 1], [4, 3, 3, 3, 2, 1, 1], [4, 3, 3, 3, 2, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1],
  [4, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 2, 1, 1, 1, 1], [4, 3, 3, 3, 3, 1, 1, 1, 1], [4, 3, 3, 3, 3, 2, 1, 1, 1], [4, 3, 3, 3, 3, 2, 2, 1, 1]];

// Objet homebrew du MJ qui porte les malus de l'Épuisement, un par niveau (tenu à jour par l'extension, fond.js).
export const OBJET_EPUISEMENT_ID = 11959069;
// Et ceux qui portent les malus de l'encombrement selon les seuils de la campagne (depuis 1.16.0) : « Encumbered » ou
// « Heavily Encumbered », un seul exemplaire équipé selon l'état du héros, aucun sinon. L'ancien « Heavily Encumbered »
// (1.12.0 à 1.15.1 : les seuls désavantages, avec la variante de la fiche) est retiré des fiches, comme le premier
// « Encumbered » (12140046, 1.16.0 : ses malus ne s'appliquaient pas, remplacé par le MJ le 2026-10-31).
export const OBJET_ENCOMBRE_ID = 12142792;
export const OBJET_LOURD_ID = 12140026;
export const OBJET_LOURD_ANCIEN_ID = 12111887;
export const OBJET_ENCOMBRE_ANCIEN_ID = 12140046;
const OBJETS_ETAT_IDS = [OBJET_EPUISEMENT_ID, OBJET_ENCOMBRE_ID, OBJET_LOURD_ID, OBJET_LOURD_ANCIEN_ID, OBJET_ENCOMBRE_ANCIEN_ID];

const mod = v => Math.floor((v - 10) / 2);
const somme = l => l.reduce((a, b) => a + (Number(b) || 0), 0);

// regles : les règles de la campagne pour les fiches (fond.js, `regles_fiches` de etat/campagne.json) ;
// `encombrement` { encombre, lourd } (multiples de la Force) quand l'encombrement passe par les objets homebrew.
export function resumer(d, regles = {}) {
  const inventaire = d.inventory || [];
  // Modificateurs actifs : ceux des objets seulement s'ils sont équipés (et harmonisés si besoin), une fois par exemplaire :
  // D&D Beyond ne liste les modificateurs d'un objet qu'une fois, même quand plusieurs exemplaires sont équipés (les objets
  // « Exhaustion Level », un par niveau d'Épuisement).
  const exemplairesActifs = new Map();
  for (const i of inventaire) {
    if (i.equipped && (!i.definition?.canAttune || i.isAttuned)) exemplairesActifs.set(i.definition?.id, (exemplairesActifs.get(i.definition?.id) || 0) + 1);
  }
  const m = d.modifiers || {};
  // Règles 2024 : quand l'historique augmente les caractéristiques, D&D Beyond ignore les augmentations de l'espèce.
  const augmente = x => x.type === 'bonus' && /-score$/.test(x.subType);
  const parHistorique = [...(m.feat || []), ...(m.background || [])].some(augmente);
  const race = (m.race || []).filter(x => !(parHistorique && augmente(x)));
  const mods = race.concat(...['class', 'background', 'feat', 'condition'].map(k => m[k] || []))
    .concat((m.item || []).flatMap(x => Array(exemplairesActifs.get(x.componentId) || 0).fill(x)));
  const avec = (type, sousType) => mods.filter(x => x.type === type && x.subType === sousType);
  const a = (type, sousType) => avec(type, sousType).length > 0;
  // La valeur d'un bonus. Sans valeur, il suit une caractéristique (statId : Nature et Arcanes du druide de l'Ordre
  // primordial Magician) ou le bonus de maîtrise (bonusTypes 1 : le don Alert, à l'initiative), comme sur la fiche.
  const valeurBonus = x => x.value ?? (x.statId && !/-score$/.test(x.subType) ? mod(valeurs[x.statId - 1]) : x.bonusTypes?.includes(1) ? maitrise : 0);
  const bonus = sousType => somme(avec('bonus', sousType).map(valeurBonus));

  const niveau = Math.max(1, somme((d.classes || []).map(c => c.level)));
  const maitrise = Math.ceil(niveau / 4) + 1;

  // Caractéristiques : base + bonus saisi + modificateurs, ou valeur imposée.
  const valeurs = CARAC_EN.map((nom, i) => {
    const id = i + 1;
    const force = d.overrideStats?.find(s => s.id === id)?.value;
    if (force) return force;
    let v = (d.stats?.find(s => s.id === id)?.value || 10) + (d.bonusStats?.find(s => s.id === id)?.value || 0) + bonus(nom + '-score');
    for (const x of avec('set', nom + '-score')) v = Math.max(v, x.value || 0);
    return v;
  });
  const md = i => mod(valeurs[i]);
  // Tests de caractéristique (jets de groupe) : bonus des tests, et la moitié de la maîtrise d'un « Touche-à-tout »
  // (half-proficiency ; arrondie au-dessus pour « Athlète remarquable ») quand le héros n'en a pas de meilleure.
  const demiMaitrise = (cle, i) => {
    const tests = ['ability-checks', CARAC_EN[i] + '-ability-checks'];
    if ([cle, ...tests].some(x => x && a('half-proficiency-round-up', x))) return Math.ceil(maitrise / 2);
    return [cle, ...tests].some(x => x && a('half-proficiency', x)) ? Math.floor(maitrise / 2) : 0;
  };
  const bonusTest = i => bonus('ability-checks') + bonus(CARAC_EN[i] + '-ability-checks');
  // Avantage ou désavantage sur tous les tests d'une caractéristique (l'objet « Heavily Encumbered » : For, Dex, Con).
  const surTests = (type, i) => a(type, 'ability-checks') || a(type, CARAC_EN[i] + '-ability-checks');
  const caracteristiques = Object.fromEntries(CARAC.map((c, i) => {
    const s = CARAC_EN[i] + '-saving-throws';
    const maitriseJS = a('proficiency', s);
    return [c, { valeur: valeurs[i], mod: md(i), test: md(i) + demiMaitrise(null, i) + bonusTest(i), avantage_test: surTests('advantage', i), desavantage_test: surTests('disadvantage', i),
      sauvegarde: md(i) + (maitriseJS ? maitrise : 0) + bonus('saving-throws') + bonus(s), maitrise_sauvegarde: maitriseJS }];
  }));

  // Points de vie.
  const pvMax = d.overrideHitPoints || ((d.baseHitPoints || 0) + (d.bonusHitPoints || 0) + (md(2) + bonus('hit-points-per-level')) * niveau + bonus('hit-points'));
  const pv = { actuels: Math.max(0, pvMax - (d.removedHitPoints || 0)), max: pvMax, temporaires: d.temporaryHitPoints || 0 };

  // Classe d'armure.
  const equipe = inventaire.filter(i => i.equipped && i.definition?.armorTypeId);
  const armure = equipe.find(i => i.definition.armorTypeId <= 3);
  const bouclier = equipe.find(i => i.definition.armorTypeId === 4);
  let ca;
  if (armure) {
    const t = armure.definition.armorTypeId;
    ca = armure.definition.armorClass + (t === 1 ? md(1) : t === 2 ? Math.min(md(1), 2) : 0) + bonus('armored-armor-class');
  } else {
    ca = 10 + md(1) + somme(avec('set', 'unarmored-armor-class').map(x => (x.statId ? md(x.statId - 1) : 0) + (x.value || 0))) + bonus('unarmored-armor-class');
  }
  if (bouclier) ca += bouclier.definition.armorClass || 2;
  ca += bonus('armor-class');
  const valeurPerso = type => d.characterValues?.find(v => v.typeId === type && v.contextId == null)?.value;
  if (valeurPerso(1)) ca = valeurPerso(1);          // CA imposée sur la fiche
  else ca += (valeurPerso(2) || 0) + (valeurPerso(3) || 0);   // bonus magique, bonus divers

  // Compétences utiles au MJ : valeurs passives.
  const passive = (comp, i) => {
    const p = a('expertise', comp) ? 2 * maitrise : a('proficiency', comp) ? maitrise : a('half-proficiency', comp) ? Math.floor(maitrise / 2) : 0;
    return 10 + md(i) + p + bonus(comp) + bonus('passive-' + comp);
  };
  // Les dix-huit compétences (onglet Compétences de la fiche, jets de groupe) : bonus du jet, maîtrise, avantage ou
  // désavantage (une armure qui gêne la discrétion : stealthCheck 2).
  const competences = Object.fromEntries(COMPETENCES.map(({ cle, carac }) => {
    const i = CARAC.indexOf(carac);
    const niveauMaitrise = a('expertise', cle) ? 'expertise' : a('proficiency', cle) ? 'maitrise' : demiMaitrise(cle, i) ? 'demi' : null;
    const p = niveauMaitrise === 'expertise' ? 2 * maitrise : niveauMaitrise === 'maitrise' ? maitrise : demiMaitrise(cle, i);
    const gene = cle === 'stealth' && inventaire.some(x => x.equipped && x.definition?.stealthCheck === 2);
    return [cle, { bonus: md(i) + p + bonus(cle) + bonusTest(i), maitrise: niveauMaitrise,
      avantage: a('advantage', cle) || surTests('advantage', i), desavantage: a('disadvantage', cle) || surTests('disadvantage', i) || gene }];
  }));

  // Vitesses, en pieds. L'encombrement (règle variante) les réduit ; une vitesse imposée sur la fiche passe après, comme sur
  // la fiche. Avec les seuils de la campagne, ce sont les objets « Encumbered » et « Heavily Encumbered » équipés qui la
  // réduisent (leurs modificateurs, dans bonus('speed')).
  const vit = d.race?.weightSpeeds?.normal || {};
  const vitesses = { marche: (vit.walk || 30) + bonus('speed') + (armure ? 0 : bonus('unarmored-movement')) };
  for (const [cle, en] of [['vol', 'fly'], ['nage', 'swim'], ['escalade', 'climb'], ['fouissement', 'burrow']]) if (vit[en]) vitesses[cle] = vit[en];
  const encombrement = encombrementDe(d, valeurs[0], avec, regles.encombrement);
  if (encombrement.malus && !a('speed-reduction', 'remove')) {
    for (const cle of Object.keys(vitesses)) if (vitesses[cle]) vitesses[cle] = Math.max(0, vitesses[cle] - encombrement.malus);
  }
  for (const c of d.customSpeeds || []) {
    const cle = MOUVEMENTS[c.movementId];
    if (cle && c.distance) vitesses[cle] = c.distance;
  }

  // Magie : DD par classe, emplacements (multiclassage compris), magie de pacte.
  const lanceurs = (d.classes || []).filter(c => c.definition?.canCastSpells && c.definition.spellCastingAbilityId);
  const sorts = lanceurs.map(c => {
    const i = c.definition.spellCastingAbilityId - 1;
    return { classe: CLASSES[c.definition.name] || c.definition.name, carac: CARAC[i], dd: 8 + maitrise + md(i) + bonus('spell-save-dc'), attaque: maitrise + md(i) + bonus('spell-attacks') };
  });
  const occultistes = lanceurs.filter(c => c.definition.name === 'Warlock');
  const autres = lanceurs.filter(c => c.definition.name !== 'Warlock');
  let maxParNiveau = [];
  if (autres.length === 1) maxParNiveau = autres[0].definition.spellRules?.levelSpellSlots?.[autres[0].level] || [];
  else if (autres.length > 1) {
    const niv = somme(autres.map(c => {
      const r = c.definition.spellRules || {}, div = r.multiClassSpellSlotDivisor || 1;
      return r.multiClassSpellSlotRounding === 2 ? Math.ceil(c.level / div) : Math.floor(c.level / div);
    }));
    maxParNiveau = TABLE_LANCEUR[Math.min(20, niv)] || [];
  }
  const emplacements = maxParNiveau.map((max, i) => ({ niveau: i + 1, max, utilises: d.spellSlots?.find(s => s.level === i + 1)?.used || 0 })).filter(e => e.max);
  let pacte = null;
  if (occultistes.length) {
    const ligne = occultistes[0].definition.spellRules?.levelSpellSlots?.[occultistes[0].level] || [];
    const i = ligne.findIndex(n => n > 0);
    if (i >= 0) pacte = { niveau: i + 1, max: ligne[i], utilises: d.pactMagic?.find(s => s.level === i + 1)?.used || 0 };
  }

  // Capacités à usage limité (rage, imposition des mains…).
  const usages = Object.values(d.actions || {}).flat().filter(x => x?.limitedUse).map(x => {
    const u = x.limitedUse;
    const max = (u.maxUses || 0) + (u.useProficiencyBonus ? maitrise : 0) + (u.statModifierUsesId ? Math.max(1, md(u.statModifierUsesId - 1)) : 0);
    return { nom: x.name, utilises: u.numberUsed || 0, max, recuperation: RECUP[u.resetType] || null };
  }).filter(u => u.max > 0);

  // Objets magiques (pour voir qui est bien équipé), du plus rare au plus commun.
  // Les objets d'état homebrew (Exhaustion Level, Encumbered, Heavily Encumbered, tenus par l'extension) n'y figurent pas.
  const objets_magiques = inventaire.filter(i => !OBJETS_ETAT_IDS.includes(i.definition?.id) &&(i.definition?.magic || (i.definition?.rarity && i.definition.rarity !== 'Common')))
    .sort((x, y) => ORDRE_RARETE.indexOf(x.definition.rarity) - ORDRE_RARETE.indexOf(y.definition.rarity))
    .map(i => ({
      nom: i.definition.name, rarete: RARETES[i.definition.rarity] || i.definition.rarity || null, quantite: i.quantity || 1,
      equipe: !!i.equipped, harmonisation: !!i.definition.canAttune, harmonise: !!i.isAttuned,
    }));
  // Le reste de ce qui est porté (armes, armure, bouclier, équipement équipé), pour l'inventaire de la fiche.
  const objets_equipes = inventaire.filter(i => i.equipped && i.definition && !OBJETS_ETAT_IDS.includes(i.definition.id) && !(i.definition.magic || (i.definition.rarity && i.definition.rarity !== 'Common')))
    .map(i => ({ nom: i.definition.name, quantite: i.quantity || 1, type: TYPES_OBJET[i.definition.filterType] || null }));

  const vision = Math.max(0, ...avec('set-base', 'darkvision').map(x => x.value || 0));
  const joueur = d.campaign?.characters?.find(c => c.characterId === d.id)?.username || d.username || null;
  const argent = d.currencies || {};

  return {
    id: d.id,
    nom: String(d.name || '').trim(),
    joueur,
    url: `${ORIGINE_BEYOND}/characters/${d.id}`,
    avatar: d.decorations?.avatarUrl || null,
    niveau,
    classes: (d.classes || []).map(c => ({ nom: CLASSES[c.definition?.name] || c.definition?.name, niveau: c.level, sous_classe: c.subclassDefinition?.name || null })),
    espece: d.race?.fullName || null,
    historique: HISTORIQUES[d.background?.definition?.name] || d.background?.definition?.name || null,
    pv,
    ca,
    initiative: md(1) + bonus('initiative') + (a('proficiency', 'initiative') ? maitrise : 0),
    vitesses,
    encombrement,
    maitrise,
    caracteristiques,
    passives: { perception: passive('perception', 4), intuition: passive('insight', 4), investigation: passive('investigation', 3) },
    competences,
    vision_dans_le_noir: vision || null,
    sorts,
    emplacements,
    pacte,
    usages,
    objets_magiques,
    objets_equipes,
    // Ses objets personnalisés (« Add Custom Item ») : une babiole donnée par le gestionnaire porte en note « identifiant : … ».
    // L'un d'eux peut être rangé dans l'inventaire du groupe (groupe.objets, même id de définition).
    objets_perso: (d.customItems || []).map(x => ({ id: x.id, nom: String(x.name || '').trim(), quantite: x.quantity || 1, note: x.notes || null })),
    etats: (d.conditions || []).map(c => ({ id: c.id, nom: ETATS[c.id] || `État ${c.id}`, niveau: c.level || null })),
    jets_contre_la_mort: { succes: d.deathSaves?.successCount || 0, echecs: d.deathSaves?.failCount || 0, stabilise: !!d.deathSaves?.isStabilized },
    inspiration: !!d.inspiration,
    argent: { pp: argent.pp || 0, po: argent.gp || 0, pe: argent.ep || 0, pa: argent.sp || 0, pc: argent.cp || 0 },
    creatures: (d.creatures || []).filter(c => !GROUPES_FORME.includes(c.groupId)).map(c => resumerCreature(c, d.characterValues)),
    forme_sauvage: formeSauvage(d),
    modifie_le: d.dateModified || null,
    releve_le: new Date().toISOString(),
  };
}

// ───── Encombrement ─────
// Comme la fiche (character-app, relevé le 2026-10-21 et vérifié sur les quatre fiches de la campagne) :
// - réglage de la fiche `preferences.encumbranceType` : 1 standard (au-delà de la capacité de charge, 15 × For : pas d'effet
//   sur la vitesse), 2 aucun, 3 variante (au-delà de 5 × For : encombré, −10 ft ; de 10 × For : lourdement encombré, −20 ft) ;
// - capacité doublée pour une créature Grande ou plus (race.sizeId 5 à 7) ou un modificateur `carrying-capacity` de taille
//   (`large`, `huge`, `gargantuan` : Carrure puissante du goliath), divisée par deux pour une Très petite ; multipliée par le
//   plus fort modificateur `carrying-capacity` / `multiplier` ;
// - poids porté : les objets rangés sur le personnage, plus chaque conteneur **équipé** (son poids, plus son contenu ×
//   weightMultiplier : 0 pour un sac sans fond) ; un conteneur non équipé ne compte pas, ni son contenu. Objet empilable :
//   poids × quantité ÷ taille du lot ; poids retouché sur la fiche (valeur 22, WEIGHT_OVERRIDE) d'abord. Pièces : 1 lb pour 50,
//   sauf si la fiche les ignore (`ignoreCoinWeight`).
// Seuils de la campagne (`campagne` : { encombre, lourd }, multiples de la Force, option de l'encombrement par les objets
// homebrew, depuis 1.16.0) : la règle `campagne`, quel que soit le réglage de la fiche (l'extension lui impose « Use
// Encumbrance », sans effet sur la vitesse) ; encombré au-delà de encombre × For, lourdement au-delà de lourd × For (même
// facteur de taille) ; pas de malus calculé : ce sont les objets équipés qui réduisent la vitesse.
// → { regle ('variante' | 'standard' | 'aucune' | 'campagne'), etat (null | 'encombre' | 'lourd' | 'surcharge'), malus (ft),
//    porte (lb), seuils { encombre, lourd, capacite }, double (capacité doublée par la taille) }.
const REGLES_ENCOMBREMENT = { 1: 'standard', 2: 'aucune', 3: 'variante' };
const POIDS_PIECE = 0.02;
const arrondi2 = x => Math.round(x * 100) / 100;

function encombrementDe(d, force, avec, campagne = null) {
  const regle = campagne ? 'campagne' : REGLES_ENCOMBREMENT[d.preferences?.encumbranceType] || 'standard';
  const inv = d.inventory || [];
  const retouche = i => d.characterValues?.find(v => v.typeId === 22 && String(v.valueId) === String(i.id) && String(v.valueTypeId) === String(i.entityTypeId))?.value;
  const poids = i => {
    const w = retouche(i) ?? i.definition?.weight ?? 0;
    if (!w) return 0;
    return i.definition?.stackable ? arrondi2(w * ((i.quantity || 0) / (i.definition.bundleSize || 1))) : w;
  };
  const contenu = id => somme(inv.filter(i => i.containerEntityId === id && !i.definition?.isContainer).map(poids));
  let porte = contenu(d.id);
  for (const c of inv.filter(i => i.definition?.isContainer && i.equipped)) porte += (retouche(c) ?? c.definition.weight ?? 0) + contenu(c.id) * (c.definition.weightMultiplier ?? 1);
  if (!d.preferences?.ignoreCoinWeight) porte += somme(Object.values(d.currencies || {})) * POIDS_PIECE;
  porte = arrondi2(porte);

  const tailles = avec('carrying-capacity', 'large').length || avec('carrying-capacity', 'huge').length || avec('carrying-capacity', 'gargantuan').length;
  const double = !!tailles || [5, 6, 7].includes(d.race?.sizeId);
  let facteur = double ? 2 : avec('carrying-capacity', 'tiny').length || d.race?.sizeId === 2 ? 0.5 : 1;
  const multiplicateurs = avec('carrying-capacity', 'multiplier').map(x => x.value || 0).filter(Boolean);
  if (multiplicateurs.length) { const m = Math.max(...multiplicateurs); facteur = m < 0 ? facteur / -m : facteur * m; }
  const multiples = campagne || { encombre: 5, lourd: 10 };
  const seuils = { encombre: multiples.encombre * force * facteur, lourd: multiples.lourd * force * facteur, capacite: 15 * force * facteur };
  let etat = null;
  if (regle === 'campagne') return { regle, etat: porte > seuils.lourd ? 'lourd' : porte > seuils.encombre ? 'encombre' : null, malus: 0, porte, seuils, double };
  if (regle === 'variante') etat = porte > seuils.lourd ? 'lourd' : porte > seuils.encombre ? 'encombre' : null;
  else if (regle === 'standard') etat = porte > seuils.capacite ? 'surcharge' : null;
  return { regle, etat, malus: etat === 'lourd' ? 20 : etat === 'encombre' ? 10 : 0, porte, seuils, double };
}

// ───── Détails (relevé à la demande) ─────
// Les textes de la fiche qui racontent le personnage : espèce et ses traits, historique, dons, sous-classe, notes.
// Les descriptions de D&D Beyond sont en HTML : converties en texte simple (paragraphes, listes « - »).

const ENTITES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', rsquo: '’', lsquo: '‘', ldquo: '“', rdquo: '”', mdash: '—', ndash: '–', hellip: '…', times: '×' };
export function texte(html) {
  return String(html || '').replace(/\r/g, '')
    .replace(/<\s*br\s*\/?>/gi, '\n')
    .replace(/<\s*li[^>]*>/gi, '\n- ')
    .replace(/<\/\s*(p|div|h\d|li|tr|table|ul|ol)\s*>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e) => (e[0] === '#' ? String.fromCodePoint(e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)) : ENTITES[e.toLowerCase()] ?? m))
    .replace(/[ \t ]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

const element = def => (def?.name ? { nom: def.name, description: texte(def.description || def.snippet) } : null);
const PERSONNALITE = { personalityTraits: 'traits', ideals: 'ideaux', bonds: 'liens', flaws: 'defauts', appearance: 'apparence' };
// Mécaniques de création sans intérêt pour le lore : taille, vitesse, augmentations de caractéristiques, rappel d'un don déjà listé.
const TRAITS_SANS_INTERET = /^(ability score|size|speed)/i;
const CHOIX_SANS_INTERET = /^(strength|dexterity|constitution|intelligence|wisdom|charisma|increase .*scores?.*|.* feat)$/i;
const NOTES = { backstory: 'histoire', allies: 'allies', enemies: 'ennemis', organizations: 'organisations', personalPossessions: 'possessions', otherHoldings: 'biens', otherNotes: 'autres' };

// Inventaire du groupe (party inventory de la campagne : GET character/v5/party/inventory/<campagne>, comme la fiche) :
// sa bourse et ses objets. Un objet personnalisé y garde l'id de sa définition, celle de l'objet créé par un des héros
// (objets_perso de sa fiche, avec sa note) : definition.id, car definitionId y vaut 0 (vu le 2026-10-20).
// Format : formats/etat.md (groupe de beyond.json).
export function resumerGroupe(d) {
  const a = d?.currency || {};
  return {
    argent: { pp: a.pp || 0, po: a.gp || 0, pe: a.ep || 0, pa: a.sp || 0, pc: a.cp || 0 },
    objets: (d?.partyItems || []).map(i => ({ id: i.id, definition: i.definition?.id || i.definitionId || null, nom: String(i.definition?.name || '').trim(),
      quantite: i.quantity || 1, perso: !!i.definition?.isCustomItem })),
    releve_le: new Date().toISOString(),
  };
}

export function detailler(d) {
  const bg = d.background?.definition;
  const perso = d.background?.hasCustomBackground ? d.background.customBackground : null;
  const garder = (src, noms) => Object.fromEntries(Object.entries(noms).map(([en, fr]) => [fr, texte(src?.[en])]).filter(([, v]) => v));
  return {
    id: d.id,
    nom: String(d.name || '').trim(),
    espece: d.race ? {
      nom: d.race.fullName || d.race.baseName,
      description: texte(d.race.description),
      // Traits visibles sur la fiche, sans les mécaniques de création (augmentations de caractéristiques).
      traits: (d.race.racialTraits || []).map(t => t.definition)
        .filter(t => t && !t.hideInSheet && !TRAITS_SANS_INTERET.test(t.name) && (t.description || t.snippet))
        .map(element),
      options: (d.options?.race || []).map(o => element(o.definition)).filter(o => o?.description && !CHOIX_SANS_INTERET.test(o.nom)),
    } : null,
    historique: bg ? {
      nom: HISTORIQUES[bg.name] || bg.name,
      nom_original: bg.name,
      resume: texte(bg.shortDescription),
      description: texte(bg.description),
      aptitude: bg.featureName ? { nom: bg.featureName, description: texte(bg.featureDescription) } : null,
    } : perso ? { nom: perso.name, description: texte(perso.description) } : null,
    // Dons choisis ; les dons techniques cachés par D&D Beyond (catégories « __… ») sont écartés.
    dons: (d.feats || []).map(f => f.definition)
      .filter(f => f && !(f.categories || []).some(c => /^__/.test(c.tagName)))
      .map(f => ({ ...element(f), categorie: (f.categories || []).map(c => c.tagName).join(', ') || null })),
    classes: (d.classes || []).map(c => ({
      nom: CLASSES[c.definition?.name] || c.definition?.name,
      niveau: c.level,
      sous_classe: element(c.subclassDefinition),
    })),
    options_de_classe: (d.options?.class || []).map(o => element(o.definition)).filter(o => o?.description && !CHOIX_SANS_INTERET.test(o.nom)),
    apparence: Object.fromEntries(Object.entries({ genre: d.gender, age: d.age, cheveux: d.hair, yeux: d.eyes, peau: d.skin, taille: d.height, poids: d.weight, foi: d.faith }).filter(([, v]) => v)),
    personnalite: garder(d.traits, PERSONNALITE),
    notes: garder(d.notes, NOTES),
    modifie_le: d.dateModified || null,
    releve_le: new Date().toISOString(),
  };
}

// Valeur personnalisée d'une créature (onglet Extras, « Customize ») : une ligne de characterValues de la fiche, typeId
// CREATURE_AC (42) ou CREATURE_HIT_POINTS (43, « Max HP »), valueId = l'id de la créature (code de la fiche, character-app
// 1.72.9, relevé le 2026-10-20 : la valeur remplace celle du profil quand elle existe).
const CREATURE_CA = 42, CREATURE_PV_MAX = 43, CREATURE_NOTES = 47;
// Rampage d'un compagnon (Flee, Mortals!) : une ligne « [Rampage (joueur)] » dans sa note, écrite par l'extension du joueur
// (formats/note-compagnon.md).
const LIGNE_RAMPAGE = /\[\s*rampage\s*\(\s*joueur\s*\)\s*\]/i;
// Sa férocité, depuis l'extension du joueur 1.8.0 : « [Férocité (joueur) : 7] » ; sans la ligne : null.
const LIGNE_FEROCITE = /\[\s*f[ée]rocit[ée]\s*\(\s*joueur\s*\)\s*:\s*(\d+)\s*\]/i;
const ferociteDe = note => { const m = note.match(LIGNE_FEROCITE); return m ? Number(m[1]) : null; };
const noteCreature = (valeurs, c) => String((valeurs || []).find(x => x.typeId === CREATURE_NOTES && String(x.valueId) === String(c.id))?.value || '');
function valeurCreature(valeurs, c, typeId) {
  const v = (valeurs || []).find(x => x.typeId === typeId && String(x.valueId) === String(c.id)
    && (x.valueTypeId == null || c.entityTypeId == null || String(x.valueTypeId) === String(c.entityTypeId)));
  const n = Number(v?.value);
  return v?.value != null && v.value !== '' && n ? n : null;
}

// La forme sauvage qu'un druide a prise : une ligne « [Forme sauvage (joueur) : CA 17, PV temp. 12] » dans la note de la
// forme, écrite par l'extension du joueur « The Seat · Wild Shape » (formats/note-compagnon.md). → { id, nom, ca, vitesses } ou null.
const LIGNE_FORME = /\[\s*forme\s+sauvage\s*\(\s*joueur\s*\)([^\]\n]*)\]/i;
function formeSauvage(d) {
  const c = (d.creatures || []).find(x => GROUPES_FORME.includes(x.groupId) && LIGNE_FORME.test(noteCreature(d.characterValues, x)));
  if (!c) return null;
  const r = resumerCreature(c, d.characterValues);
  const ca = Number(/\bCA\s*(\d+)/i.exec(LIGNE_FORME.exec(noteCreature(d.characterValues, c))[1])?.[1]) || r.ca;
  return { id: r.id, nom: r.nom, ca, vitesses: r.vitesses, avatar: r.profil?.avatarUrl || null };   // avatar : le portrait de la forme, depuis 1.18.0
}

// Familier, compagnon animal, monture… (onglet Extras de la fiche). valeurs : characterValues de la fiche.
function resumerCreature(c, valeurs) {
  const def = c.definition || {};
  const stat = id => def.stats?.find(s => s.statId === id)?.value ?? 10;
  const max = valeurCreature(valeurs, c, CREATURE_PV_MAX) || def.averageHitPoints || 0;   // « Max HP » personnalisé, sinon celui du profil
  const vitesses = {};
  for (const mv of def.movements || []) { const cle = MOUVEMENTS[mv.movementId]; if (cle && mv.speed) vitesses[cle] = mv.speed; }
  const intuition = def.skills?.find(s => s.skillId === COMPETENCE_INTUITION);
  // Compétences du profil (bonus total), les autres au modificateur de leur caractéristique : jets de groupe.
  const competences = Object.fromEntries(COMPETENCES.map(({ id, cle, carac }) => {
    const s = def.skills?.find(x => x.skillId === id);
    return [cle, { bonus: s ? (s.value || 0) + (s.additionalBonus || 0) : mod(stat(CARAC.indexOf(carac) + 1)), maitrise: s ? 'maitrise' : null }];
  }));
  return {
    id: c.id,
    nom: String(c.name || def.name || '').trim(),
    groupe: GROUPES[c.groupId] || 'créature',
    actif: !!c.isActive,
    pv: { actuels: Math.max(0, max - (c.removedHitPoints || 0)), max, temporaires: c.temporaryHitPoints || 0 },
    ca: valeurCreature(valeurs, c, CREATURE_CA) ?? def.armorClass ?? null,   // CA personnalisée, sinon celle du profil
    rampage: LIGNE_RAMPAGE.test(noteCreature(valeurs, c)),   // noté par l'extension du joueur
    ferocite: ferociteDe(noteCreature(valeurs, c)),
    vitesses,
    // La valeur d'une compétence de créature est déjà le bonus total (comme la perception passive fournie).
    passives: { perception: def.passivePerception ?? 10 + mod(stat(5)), intuition: 10 + (intuition ? (intuition.value || 0) + (intuition.additionalBonus || 0) : mod(stat(5))) },
    caracteristiques: Object.fromEntries(CARAC.map((k, i) => [k, { valeur: stat(i + 1), mod: mod(stat(i + 1)) }])),
    competences,
    // Son profil, tel que D&D Beyond le donne (champs d'un monstre de monster-service), pour l'afficher en bloc de stats
    // comme l'extension du compagnon (fiche du compagnon dans Personnages, depuis 1.14.0).
    profil: Object.fromEntries(PROFIL.filter(k => def[k] != null).map(k => [k, def[k]])),
  };
}
const PROFIL = ['name', 'stats', 'armorClass', 'armorClassDescription', 'averageHitPoints', 'hitPointDice', 'movements', 'savingThrows', 'skills',
  'skillsHtml', 'damageAdjustments', 'conditionImmunities', 'senses', 'passivePerception', 'languageDescription', 'languageNote', 'challengeRatingId',
  'initiativeBonus', 'typeId', 'sizeId', 'alignmentId', 'avatarUrl', 'largeAvatarUrl', 'specialTraitsDescription', 'actionsDescription',
  'bonusActionsDescription', 'reactionsDescription', 'legendaryActionsDescription', 'mythicActionsDescription'];
