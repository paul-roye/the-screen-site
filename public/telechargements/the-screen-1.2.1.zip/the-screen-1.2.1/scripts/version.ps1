﻿# Version du gestionnaire et son empreinte : de quoi savoir si une copie a été modifiée depuis sa version officielle.
# À inclure :  . (Join-Path <racine> 'scripts\version.ps1')  puis  Empreinte-Gestionnaire <racine>
# version.json (à la racine, écrit par mainteneur/sceller-version.ps1, par le mainteneur seulement) : { version, date, empreinte }.
# L'empreinte couvre le code et les formats (app/, formats/, design-system/ sans les polices, scripts/, extensions/, regles/
# sans son environnement, les pages et lanceurs de la racine), pas les campagnes ni les réglages du poste. Les fins de ligne
# sont ignorées (une copie Windows et une copie Unix ont la même empreinte).

$script:DossiersCode = @('app', 'formats', 'design-system', 'scripts', 'outils', 'extensions', 'regles', 'modeles')
# extensions\druide et groupe : les outils de joueur du mainteneur, qui ne font pas partie du gestionnaire et ne partent pas.
$script:ExclusCode = @('design-system\fonts\', 'regles\.venv\', 'regles\index\', 'regles\modeles\', '__pycache__\', 'node_modules\', 'extensions\druide\', 'extensions\groupe\')

function Fichiers-Gestionnaire([string]$racine) {
    $liste = New-Object System.Collections.Generic.List[string]
    foreach ($d in $script:DossiersCode) {
        $base = Join-Path $racine $d
        if (-not (Test-Path $base -PathType Container)) { continue }
        foreach ($f in Get-ChildItem $base -Recurse -File) {
            $rel = $f.FullName.Substring($racine.TrimEnd('\').Length + 1)
            if ($script:ExclusCode | Where-Object { $rel.Contains($_) }) { continue }
            if ($rel -match '\.(tmp|log)$' -or $rel -match '(^|\\)\.env') { continue }
            $liste.Add($rel)
        }
    }
    foreach ($f in Get-ChildItem $racine -File) {
        if ($f.Extension -in '.html', '.ps1', '.cmd' -or $f.Name -in 'AGENTS.md', 'poste.exemple.json') { $liste.Add($f.Name) }
    }
    return @($liste | Sort-Object)
}

function Empreinte-Gestionnaire([string]$racine) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $lignes = foreach ($rel in Fichiers-Gestionnaire $racine) {
        $texte = [IO.File]::ReadAllText((Join-Path $racine $rel), [Text.Encoding]::UTF8).Replace("`r", '')
        $h = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($texte))).Replace('-', '').ToLowerInvariant()
        "$($rel.Replace('\', '/')) $h"
    }
    return [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(($lignes -join "`n")))).Replace('-', '').ToLowerInvariant()
}
