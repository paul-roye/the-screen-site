# Note d'un compagnon : les états posés par le MJ, la férocité et le rampage notés par le joueur

**Contrat entre le gestionnaire (MJ) et l'extension du joueur `extensions/compagnon/`** (fiche du compagnon d'un héros : son familier, son compagnon animal). Ce n'est pas un fichier de `data/` : c'est une ligne écrite dans la fiche D&D Beyond du personnage, seul lien entre les deux outils (l'extension du joueur ne lit rien du gestionnaire).

D&D Beyond ne pose pas d'état sur une créature (familier, compagnon). Le MJ pose ceux du compagnon dans le gestionnaire (`etat/etats-creatures.json`, voir [etat.md](etat.md)) ; le gestionnaire les recopie dans la **note de la créature** sur la fiche, où l'extension du joueur les lit.

## Où

- Fiche D&D Beyond du maître, onglet Extras, la créature (son `id` sur D&D Beyond), « Customize », champ **Notes**.
- Dans la fiche brute (`character-service…/character/v5/character/<id>`) : la ligne de `characterValues` dont `typeId` vaut **47** (`CREATURE_NOTES`), `valueId` l'`id` de la créature (en texte) et `valueTypeId` son `entityTypeId` (en texte) ; la note est dans `value`. Pas de ligne : pas de note.
- Écrite comme la fiche le fait : `PUT https://character-service.dndbeyond.com/character/v5/custom/value` `{ characterId, typeId: 47, value, notes: null, valueId, valueTypeId, contextId: null, contextTypeId: null, partyId: null }` (relevé dans le code de la fiche, character-app 1.72.9, le 2026-10-20).

## Format

Une ligne, n'importe où dans la note (le gestionnaire la met à la fin) :

```
[États (MJ) : À terre, Épuisement 2]
```

- Entre `[États (MJ) :` et `]` : les états, séparés par des virgules, du plus grave au moins grave.
- Noms de la VF, ceux du glossaire du DRS 5.2.1 (les 15 de `app/etats.js`) : Agrippé, À terre, Assourdi, Aveuglé, Charmé, Effrayé, Empoisonné, Entravé, Épuisement, Étourdi, Inconscient, Invisible, Neutralisé, Paralysé, Pétrifié. L'**Épuisement** est suivi de son niveau (1 à 6) : « Épuisement 2 ».
- Sans état : pas de ligne (le gestionnaire la retire).
- Le reste de la note appartient au joueur : le gestionnaire ne touche qu'à sa ligne (il la remplace, ou l'ajoute à la fin, après un saut de ligne).

## Lecture (extension du joueur)

- Chercher `[États (MJ) : … ]` (sans tenir compte de la casse ni des espaces autour du deux-points) ; découper sur les virgules.
- Comparer chaque nom aux 15 sans tenir compte de la casse, des accents ni des espaces ; « Épuisement N » donne le niveau N (1 si absent, au plus 6). Un nom inconnu est ignoré.
- Les états affichés au joueur sont en lecture seule : seul le MJ les change, dans le gestionnaire.
- L'extension `extensions/groupe/` (bandeau du groupe, 1.1.0) lit la même ligne, de la même façon, pour montrer à tous les joueurs les états des compagnons actifs de chaque héros.

## Qui écrit

- Le gestionnaire, à chaque changement d'un état du compagnon (Personnages : carte, fiche ; Combat), par l'extension du MJ (commande `etats-creature`, version 1.6.0, `extensions/mj/LISEZMOI.md`), un instant après le dernier changement. 
- Sur D&D Beyond, la note reste modifiable à la main : un état changé là n'est pas relu par le gestionnaire (`etat/etats-creatures.json` fait foi) et sera remplacé au prochain changement fait dans le gestionnaire.

## Rampage : la ligne du joueur (2026-10-20)

Une seconde ligne, dans la même note, écrite par l'**extension du joueur**, présente tant que le compagnon est en rampage (règles des compagnons de Flee, Mortals!) :

```
[Rampage (joueur)]
```

- Écrite quand le joueur met le compagnon en rampage, retirée quand le rampage prend fin (dans l'extension, avec la session du joueur, par la même requête `PUT …/character/v5/custom/value`, ou `DELETE` si la note devient vide).
- Chacun ne touche qu'à sa ligne : l'extension du joueur relit la note juste avant d'écrire et garde la ligne `[États (MJ) : …]` ; le gestionnaire garde de même la ligne du joueur quand il réécrit la sienne. Deux écritures au même instant peuvent faire perdre une ligne : elle revient au prochain changement de celui qui l'écrit.
- Lecture par le gestionnaire : l'extension du MJ (version 1.6.2) note `rampage: true` pour la créature dans son relevé (`beyond.json`, voir [etat.md](etat.md)) ; le MJ le voit dans Combat (ligne du compagnon) et Personnages (carte et fiche du compagnon). Recherche sans tenir compte de la casse ni des espaces : `[Rampage (joueur)]`.
## Férocité : la ligne du joueur (2026-10-21)

Depuis l'extension du joueur 1.8.0, une troisième ligne dans la même note, écrite par elle dès que sa fenêtre suit le compagnon :

```
[Férocité (joueur) : 7]
```

- Un entier (0 ou plus), la férocité telle que la fenêtre la tient (elle reste gardée dans l'extension, `chrome.storage.local` ; la ligne en est la copie pour le MJ). Écrite avant `[Rampage (joueur)]`, à la fin de la part du joueur.
- Mise à jour un instant (1,5 s) après le dernier changement de férocité (plusieurs clics, une écriture), aussitôt avec un changement de rampage ; à chaque lecture de la fiche (toutes les 15 s), réécrite si elle diffère de la fenêtre. Même requête et mêmes garde-fous que le rampage (note relue juste avant, seules les lignes du joueur changent).
- Un Chrome qui n'a jamais suivi ce compagnon prend la férocité de la note, sans écrire.
- Lecture par le gestionnaire : l'extension du MJ (version 1.7.2) note `ferocite` (le nombre, ou `null` sans la ligne) pour la créature dans son relevé ; Personnages l'affiche sur la carte du compagnon (mode Étendu, à la place des ressources d'un héros) et dans sa fiche (section « Férocité », sous les caractéristiques), dans la couleur de son état comme dans l'extension : gris à 0, jaune de 1 à 9, orange à 10 ou plus (le DD du test qui retient le rampage, 5 + férocité), rose en rampage (bonus de l'attaque de signature, moitié de la férocité). Recherche sans tenir compte de la casse, des accents ni des espaces : `[Férocité (joueur) : N]`.

## Forme sauvage d'un druide : la ligne du joueur (2026-11-09)

Écrite par l'extension du joueur `extensions/druide/`, dans la note de la **forme prise** (créature du groupe d'extras `Wild Shape (2024)`, `groupId` 13 ; 3 pour l'ancien groupe) :

```
[Forme sauvage (joueur) : CA 17, PV temp. 12]
```

- Présente tant que le druide est transformé ; une seule forme la porte. Le texte après les deux-points est indicatif (la CA de la forme, les PV temporaires à la transformation) : c'est la présence de la ligne qui compte. Même requête que le rampage (`PUT` ou `DELETE …/character/v5/custom/value`, `typeId` 47), note relue juste avant d'écrire, le reste de la note gardé.
- Lecture par le gestionnaire : `extensions/mj/resumer.js` (version 1.17.0) en tire `forme_sauvage { id, nom, ca, vitesses }` du résumé (`beyond.json`, voir [etat.md](etat.md)) ; Personnages (carte, fiche), Combat, le tableau des joueurs et le prompt de session le montrent. Les formes sauvages ne sont plus dans `creatures[]` du résumé : ce ne sont pas des compagnons.
- Lecture par l'extension `extensions/groupe/` : la forme s'affiche sur la carte du héros dans le bandeau des joueurs.

## Options des formes sauvages : le bloc du joueur (2026-11-09)

Écrit à la main par le joueur, lu par `extensions/druide/` (`lireOptions()` de `js/bestiaire.js`), dans les notes de la **fiche** (`notes.otherNotes`, onglet Notes, « Other ») : un bloc par forme, jusqu'à la première ligne vide.

```
[Options (joueur) : Petit ours / Little Bear (Medium)]
Grimpeur : Vitesse d'escalade de 25 ft.
Vitesse : escalade 25
```

- L'en-tête nomme la forme (nom personnalisé, anglais de D&D Beyond ou français de l'extension), plusieurs séparées par `/`, sans tenir compte de la casse.
- `Nom : texte` : une option ; `Vitesse : marche|escalade|vol|nage N` : une vitesse ajoutée à la forme.
- Plusieurs blocs pour une forme s'additionnent. L'extension n'écrit rien dans ces notes.

## The Seat · Party : la ligne du MJ (2026-11-09)

Ce que le MJ fixe pour l'extension des joueurs `extensions/groupe/` : une ligne, lue par l'extension avec la session de chaque joueur.

```
[Bandeau (MJ) : ensanglanté 40, critique 15, pv non]
```

- `ensanglanté N` et `critique N` : les seuils en % des PV max ; `pv non` : pas d'affichage des PV en chiffres ; `pv oui` : permis. Chaque élément est facultatif ; sans ligne, les réglages de chaque joueur s'appliquent. Lecture sans tenir compte de la casse ni des espaces autour du deux-points ; « ensanglante » sans accent est admis.
- **Où (depuis l'extension 1.2.0) : les notes publiques de la campagne** (page de la campagne sur D&D Beyond, « Edit Campaign », « Public Notes »). Chaque fiche brute les porte (`campaign.publicNotes`) : pas de requête de plus, un seul endroit, que seul le MJ modifie (les notes d'une fiche, elles, appartiennent à son joueur). Le texte est mis en forme par D&D Beyond : les balises et les entités sont retirées avant la lecture (`texte()` de `resumer.js`). À défaut de ligne dans ces notes, l'extension la cherche encore dans les notes des fiches du groupe (`notes.otherNotes`, onglet Notes, « Other » : le premier lieu, 1.0.0), la première trouvée.
- **Qui écrit** : le gestionnaire compose la ligne (fenêtre Campagne, onglet « Fiches D&D Beyond », `regles_fiches.bandeau` de `etat/campagne.json`, voir [etat.md](etat.md) : d'office les seuils de l'écran des joueurs, PV en chiffres interdits) et le MJ la colle dans les notes publiques. Le gestionnaire ne l'écrit pas encore lui-même (le formulaire de la campagne n'a pas été relevé avec une session).
- **Retour au MJ** : l'extension du MJ (1.18.0) note dans son relevé la ligne trouvée dans les notes publiques (`campagne.bandeau` de `beyond.json`) ; l'onglet dit « En place », « Une autre ligne est en place » ou « Pas encore en place ».
- L'extension dit au joueur, dans ses réglages, ce qui est « fixé par le MJ » et d'où (notes publiques de la campagne, ou notes d'une fiche).
- **Pas encore vérifié avec une session** (2026-11-09) : que `campaign.publicNotes` est bien dans la fiche lue par un joueur, et la forme exacte de son texte. Si le champ manque, l'extension retombe sur les notes des fiches, et l'onglet du gestionnaire dit que le relevé ne lit pas ces notes.
