// Page À propos (a-propos.html, lien « À propos » de la signature de l'en-tête) : le projet en quelques lignes, puis quatre
// onglets : Nouveautés (une nouvelle par version scellée), À venir (la feuille de route, pour les MJ), Bugs connus (et
// limites), Aide (app/aide.js). L'onglet et la section d'aide suivent l'adresse (#aide/combat), pour y renvoyer d'ailleurs.
// ?campagne=<id> : la page prend la charte et le thème de cette campagne (son manifeste et son etat/tableau.json).
// À tenir à jour par le mainteneur : une version scellée a sa nouvelle ; À venir et Bugs connus suivent FEUILLE-DE-ROUTE.md.

import { h, icone, onglets, badge, activerInfobulles } from './ui.js';
import { appliquerCharte } from './campagne.js';
import { signature } from './signature.js';
import { AIDE, GROUPES_AIDE } from './aide.js';

// ───── Contenu ─────

const NOUVEAUTES = [
  {
    version: '1.2.1', date: '2026-11-09', titre: 'L\'accueil pour tous, et les mises à jour par patch',
    texte: [
      'Une correction pour ceux qui viennent d\'installer le gestionnaire, et une façon plus légère de passer d\'une version à la suivante.',
    ],
    points: [
      ['Accueil', 'avec une seule campagne, l\'accueil était inaccessible, et « Nouvelle campagne » avec lui. Les flèches croisées de l\'en-tête y mènent maintenant toujours, et le premier lancement montre la liste.'],
      ['Patchs', 'un petit zip qui ne change que les fichiers nécessaires : décompressez-le, double-cliquez « Appliquer le patch.cmd » et choisissez votre gestionnaire. Vos campagnes ne sont pas touchées, et ce qui est remplacé reste dans anciennes-versions/.'],
      ['Extensions des joueurs', 'si vos joueurs utilisent « The Seat · Party », vous fixez ses limites pour votre campagne (seuils de santé, PV en chiffres ou non) dans la fenêtre Campagne, onglet « Fiches D&D Beyond ».'],
      ['Forme sauvage', 'un druide transformé (extension de son joueur) est montré avec sa forme, sa CA et son portrait dans Personnages, Combat et sur le tableau des joueurs.'],
      ['Extension du MJ', 'version 1.18.0, à recharger dans Chrome : relevé toutes les 20 secondes, et les formes sauvages d\'un druide ne sont plus relevées comme des compagnons.'],
    ],
  },
  {
    version: '1.2.0', date: '2026-11-08', titre: 'L\'écran des joueurs, les plugins et une table mieux tenue',
    texte: [
      'Le gestionnaire sort de l\'écran du MJ : des plugins le relient maintenant à ce qu\'il y a autour de la table, à commencer par un écran pour les joueurs. Et, après de vraies séances, il rattrape ce qu\'un MJ oublie dans le feu de l\'action.',
    ],
    points: [
      ['Plugins', 'activés campagne par campagne (fenêtre Campagne, onglet Plugins). Une campagne qui n\'en a pas l\'usage ne voit ni leurs outils ni leurs réglages.'],
      ['Écran des joueurs', 'sur un second écran ou une TV posée à plat : la carte à 1 pouce par case, brouillard de guerre, terrains, jetons, mesures et zones d\'effet, ping. Sans carte, le tableau des joueurs : l\'état de chaque héros en mots, sans chiffres. Vous préparez à part, un seul bouton Diffuser, et toute image s\'y envoie d\'un clic.'],
      ['The Table', 'un plugin pour piloter un ruban LED autour de la table pendant les combats : tour de chacun, dégâts, critiques, ambiances.'],
      ['Fin de combat', 'marquer une rencontre terminée propose de noter morts les PNJ tombés, de démarrer son jalon et, si c\'était sa dernière rencontre, de le terminer.'],
      ['Avant de terminer', 'terminer un jalon, une étape ou une piste montre d\'abord ce qui reste (rencontres, PNJ, objets, résurgences), à régler sans quitter la page ; un symbole d\'alerte reste sur ce qui a été terminé trop vite.'],
      ['Déroulé', 'des résurgences à cocher une fois jouées, une remarque du MJ sur chaque jalon, étape, piste et résurgence, reprise en fin de session ; une vue en arbre d\'une étape, à l\'essai ; deux étapes au même lieu ne se partagent plus tout ce qui s\'y trouve.'],
      ['Combat au clavier', 'des raccourcis, pavé numérique compris.'],
      ['Trajets', 'un trajet peut se faire sans rencontres aléatoires : seules comptent celles prévues sur la route.'],
      ['Fenêtres', 'toute fenêtre se réduit à sa barre de titre, sur place. Dans un champ de texte, Ctrl + Entrée valide.'],
      ['Tableau de départ', 'une nouvelle campagne ne reçoit que les outils dont elle a les données ; une fois vos fichiers rangés, « Disposition recommandée » pose les autres.'],
      ['Encombrement', 'des seuils propres à la campagne, et des objets homebrew qui portent ses malus, vitesse comprise.'],
    ],
  },
  {
    version: '1.1.1', date: '2026-10-27', titre: 'Mettre à jour sans rien perdre',
    texte: [
      'Une nouvelle version s\'installe maintenant par un script, depuis son dossier décompressé à part : outils/Mettre à jour.cmd met à jour votre gestionnaire actuel, à sa place, sans toucher à vos campagnes, à vos réglages ni à ce que vous avez installé sur ce PC. Le mode d\'emploi est dans le LISEZMOI, section « Mettre à jour ».',
    ],
    points: [
      ['Sauvegarde', 'l\'ancienne version est gardée dans anciennes-versions/ de votre gestionnaire.'],
      ['Images', 'depuis la 1.0.0, la bibliothèque d\'images rangée à la racine passe dans le dossier de votre campagne par défaut, où la 1.1 la cherche.'],
      ['Extension du MJ', 'le script dit quand il faut la recharger dans Chrome.'],
    ],
  },
  {
    version: '1.1.0', date: '2026-10-27', titre: 'Un tableau prêt à jouer',
    texte: [
      'Une nouvelle campagne ne s\'ouvre plus sur un tableau presque vide : chaque mode a déjà ses outils, à leur place, dans la disposition que l\'auteur de cet outil utilise à sa table.',
    ],
    points: [
      ['Dispositions recommandées', 'Exploration, Ville, Voyage et Rencontre s\'ouvrent la première fois sur leur disposition recommandée. Un outil dont il manque les données y est quand même, et dit quel fichier écrire.'],
      ['« Disposition recommandée »', 'en bas de la fenêtre Outil, remplace « Disposition d\'origine » : il remet la disposition recommandée du mode affiché, sans toucher aux autres modes ni aux tirages et journaux.'],
      ['Images', 'la bibliothèque d\'images de chaque campagne se range dans son dossier (images-library/), celle de la campagne par défaut comprise ; poste.json ne sert plus qu\'à la mettre ailleurs.'],
    ],
  },
  {
    version: '1.0.0', date: '2026-10-26', titre: 'The Screen sort en version 1.0',
    texte: [
      '« The Screen » Campaign Toolbox, l\'écran du MJ version numérique. Né pour mener une longue campagne d\'horreur gothique, il sert maintenant à toutes vos campagnes de D&D 5e (règles 2024) jouées avec D&D Beyond. C\'est un outil de MJ, sur votre PC : une page locale, ouverte dans Chrome, que les joueurs ne voient pas.',
      'Le principe : votre agent IA de campagne (un projet Claude, par exemple) lit vos livres, vos PDF et vos notes, et en tire les données de la campagne selon des fiches de format précises ; le gestionnaire les met en jeu, note tout ce qui se passe à la table, et lui rend la séance pour qu\'il tienne la suite à jour.',
    ],
    points: [
      ['Plusieurs campagnes', 'chacune dans son dossier, avec sa charte (Barovie Néon, Médiéval glorieux), son calendrier (Classique, Royaumes oubliés, Barovien, ou le vôtre), sa vraie météo, sa musique et ses mots.'],
      ['Vingt-deux outils', 'à disposer en quatre modes (Exploration, Ville, Voyage, Rencontre) : Personnages, Combat, Ici, Horloge, Rencontres, Déroulé, PNJ, Objets, Trajets, Musique, Dés en 3D…'],
      ['D&D Beyond', 'les fiches des héros relevées toutes les 30 secondes par l\'extension du MJ ; états, inspiration, PV et objets écrits en retour ; monstres et objets cherchés dans vos livres.'],
      ['Combats sur table', 'préparation avec la difficulté de Flee, Mortals!, initiative, tours, PV, états, fiches de monstres aux jets d\'un clic, état de fin gardé pour la suite.'],
      ['Le temps qui passe', 'heure par heure, avec les tests de rencontre, les repos, les trajets, l\'agenda et ses rappels.'],
      ['Fin de session', 'un prompt pour votre agent, et sa réponse appliquée après votre validation.'],
      ['Un module Curse of Strahd', 'le Tarokka de madame Éva, pour qui mène cette aventure.'],
    ],
  },
];

// La feuille de route, côté MJ : ce qui viendra, sans promesse de date.
const A_VENIR = [
  { titre: 'Bientôt', points: [
    ['Compteurs de campagne', 'Des compteurs, jauges et horloges de menace décrits dans les données (une faveur, une renommée, le temps avant un rituel, une intrigue qui avance sans les héros) : affichés au tableau, avancés en jeu et par la fin de session. Une campagne aura ses mécaniques sans une ligne de code.'],
    ['Notes de séance', 'Un petit outil pour noter vite pendant la partie, à l\'heure de jeu et à l\'heure réelle, avec la complétion des PNJ et des lieux ; les notes partent dans le prompt de fin de session.'],
    ['Extension du MJ et campagnes', 'Qu\'elle suive d\'elle-même la campagne ouverte, sans régler son adresse.'],
    ['Extensions des joueurs', 'Que le gestionnaire écrive lui-même, dans les notes publiques de votre campagne D&D Beyond, ce que vous fixez pour les extensions des joueurs (aujourd\'hui : une ligne à copier), et d\'autres échanges par ce chemin.'],
  ] },
  { titre: 'Idées', points: [
    ['Écran des joueurs, suite', 'Pendant un combat, l\'ordre de jeu et l\'état des ennemis en mots (« Blessé », « En sang ») sur l\'écran des joueurs ; les zones déjà explorées en gris ; la carte régionale version joueurs avec les lieux visités.'],
    ['The Table, suite', 'L\'ambiance du ruban LED qui suit d\'elle-même le lieu des héros et le moment de la journée ; d\'autres plugins sur le même modèle (un éclairage connecté, un écran).'],
    ['Tactiques des monstres', 'Les tactiques tirées des suppléments, sur la ligne d\'un monstre dans Combat.'],
    ['Règles', 'D\'autres livres dans l\'assistant de règles, des questions sur les fiches des héros, un raccourci dans le menu rapide.'],
    ['Règles rapides en français', 'Les états, l\'épuisement, l\'abri, la lutte, en résumés à portée de clic.'],
    ['L\'accueil dans la charte', 'La liste des campagnes, chacune dans sa charte.'],
    ['Tarokka', 'Où sont les trésors de la prophétie et qui les a ; les tirages personnels dans la fin de session.'],
  ] },
  { titre: 'Plus tard', points: [

    ['Partager une campagne', 'Exporter une campagne en paquet (données, charte, musique, sans l\'état) et l\'importer ailleurs. À très long terme : les données tirées des livres ne se partagent qu\'entre propriétaires des livres.'],
  ] },
];

const BUGS = [
  { titre: 'Bugs', points: [
    ['Icône d\'Entravé', 'L\'état Entravé s\'est affiché par son abréviation (« En ») au lieu de l\'icône de D&D Beyond. Pas reproduit depuis : si vous la voyez, relancez outils/Importer les icônes d\'états.cmd et dites à l\'auteur où (carte, fiche, Combat, extension du joueur).'],
    ['Musique et changement de fenêtre', 'YouTube met parfois la musique en pause juste après un changement de fenêtre ou d\'onglet. Le gestionnaire la relance d\'office ; la cause n\'est pas trouvée.'],
  ] },
  { titre: 'Limites connues', points: [
    ['YouTube', 'Pas de son seul ni de choix de qualité (360p ou 480p) : le lecteur reste caché, d\'au moins 200 × 200 px. Une vidéo dont l\'auteur interdit l\'intégration se signale à la lecture.'],
    ['Extension du MJ', 'Elle relève la campagne par défaut du poste. Pour une autre, réglez son adresse (http://localhost:8735/<identifiant>) dans sa fenêtre.'],
    ['Écritures sur D&D Beyond', 'Quelques-unes n\'ont pas encore servi en vraie partie (le nom d\'un objet changé après le don, les PV et le rampage d\'un compagnon écrits par l\'extension du joueur). En cas de doute, la fiche D&D Beyond fait foi.'],
    ['Monstres des livres non possédés', 'D&D Beyond les donne sans CA, PV ni capacités.'],
    ['Épuisement et encombrement', 'D&D Beyond n\'applique pas les malus de l\'Épuisement, et n\'a que des seuils d\'encombrement fixes : il faut les objets homebrew « Exhaustion Level », « Encumbered » et « Heavily Encumbered » dans votre collection (abonnement D&D Beyond). Sans eux, la vitesse encombrée n\'est calculée qu\'avec l\'encombrement variante.'],
    ['Objets sans équivalent', 'Un objet dont le nom anglais n\'existe pas sur D&D Beyond se cherche à la main, ou part en objet personnalisé.'],
    ['Plein écran', 'Montrer une image en plein écran dépend du navigateur ; sinon, elle s\'affiche en grand dans la page.'],
    ['Assistant de règles', 'Un petit modèle local peut se tromper : vérifiez ses citations. Le SRD n\'a pas tout le Manuel des joueurs.'],
    ['Sauvegardes du jour', 'Le serveur garde la première version du jour de chaque fichier d\'état (etat/sauvegardes/) et ne les efface jamais : faites le ménage de temps en temps.'],
    ['Windows seulement', 'Les lanceurs sont des scripts Windows (PowerShell 5.1), sans rien à installer.'],
  ] },
];

// ───── Page ─────

const racine = document.getElementById('app');
activerInfobulles();
const params = new URLSearchParams(location.search);
const idCampagne = /^[a-z0-9-]+$/.test(params.get('campagne') || '') ? params.get('campagne') : null;

// La charte et le thème de la campagne d'où l'on vient (sinon Barovie Néon, en Nuit).
if (idCampagne) {
  const lire = f => fetch(`/${idCampagne}/${f}`, { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  const [m, t] = await Promise.all([lire('manifeste.json'), lire('etat/tableau.json')]);
  if (m) await appliquerCharte(m);
  const theme = t?.theme || m?.theme;
  if (theme === 'nuit' || theme === 'parchemin') document.documentElement.dataset.theme = theme;
}

const liste = points => h('dl', { class: 'cm-apropos__liste' }, points.map(([nom, texte]) => [h('dt', {}, nom), h('dd', {}, texte)]));

function vueNouveautes() {
  return h('div', { class: 'cm-pile' }, NOUVEAUTES.map(n => h('article', { class: 'bn-carte cm-apropos__nouvelle' },
    h('p', { class: 'surtitre' }, `Version ${n.version} · ${n.date.split('-').reverse().join('/')}`),
    h('h2', { class: 'titre-m' }, n.titre),
    n.texte.map(t => h('p', { class: 'texte' }, t)),
    n.points?.length ? liste(n.points) : null)));
}

function vueGroupes(groupes, note) {
  return h('div', { class: 'cm-pile' },
    note ? h('p', { class: 'ui-s cm-sourdine' }, note) : null,
    groupes.map(g => h('section', { class: 'bn-carte cm-pile' }, h('h2', { class: 'titre-m' }, g.titre), liste(g.points))));
}

// L'aide : un sommaire (et une recherche) à gauche, les sections à droite. Une section ouverte par l'adresse est amenée en vue.
function vueAide() {
  const sections = AIDE.map(s => {
    const el = h('article', { class: 'bn-carte cm-pile cm-aide__section', id: `aide-${s.id}` },
      h('h2', { class: 'titre-m cm-aide__titre' }, icone(s.icone, 'bn-icone--l'), s.titre,
        s.requiert ? badge(`data/${s.requiert}.json`, null, 'lu-database') : null),
      h('p', { class: 'texte' }, s.resume),
      s.blocs.map(b => h('section', { class: 'cm-pile cm-aide__bloc' }, h('h3', { class: 'etiquette' }, b.titre), liste(b.points))));
    el.dataset.texte = [s.titre, s.resume, ...s.blocs.flatMap(b => [b.titre, ...b.points.flat()])].join(' ').toLowerCase();
    return el;
  });
  const liens = new Map(AIDE.map(s => [s.id, h('a', { class: 'cm-aide__lien', href: `#aide/${s.id}` }, icone(s.icone, 'bn-icone--s'), s.titre)]));
  const sommaire = h('nav', { class: 'cm-aide__sommaire', 'aria-label': 'Sommaire de l\'aide' },
    GROUPES_AIDE.map(([id, nom]) => h('div', { class: 'cm-pile' }, h('p', { class: 'etiquette' }, nom),
      h('ul', { class: 'cm-aide__liens' }, AIDE.filter(s => s.groupe === id).map(s => h('li', {}, liens.get(s.id)))))));
  const aucun = h('p', { class: 'ui cm-sourdine', hidden: true }, 'Rien ne correspond à cette recherche.');
  const recherche = h('input', { class: 'bn-input', type: 'search', placeholder: 'Chercher dans l\'aide : un outil, un bouton…', 'aria-label': 'Chercher dans l\'aide',
    oninput: () => {
      const mots = recherche.value.toLowerCase().split(/\s+/).filter(Boolean);
      let n = 0;
      for (const el of sections) {
        const vu = mots.every(m => el.dataset.texte.includes(m));
        el.hidden = !vu;
        liens.get(el.id.slice(5)).parentElement.hidden = !vu;
        if (vu) n++;
      }
      aucun.hidden = n > 0;
    } });
  return h('div', { class: 'cm-aide' },
    h('div', { class: 'cm-aide__gauche' }, recherche, sommaire),
    h('div', { class: 'cm-pile cm-aide__contenu' }, sections, aucun));
}

const ONGLETS = [
  { id: 'nouveautes', libelle: 'Nouveautés', icone: 'lu-sparkles', rendu: vueNouveautes },
  { id: 'a-venir', libelle: 'À venir', icone: 'lu-route', rendu: () => vueGroupes(A_VENIR, 'La feuille de route : ce qui viendra, sans promesse de date. Vos idées sont les bienvenues.') },
  { id: 'bugs', libelle: 'Bugs connus', court: 'Bugs', icone: 'lu-bug', rendu: () => vueGroupes(BUGS, 'Ce qui ne marche pas encore comme prévu, et ce que le gestionnaire ne peut pas faire.') },
  { id: 'aide', libelle: 'Aide', icone: 'lu-circle-help', rendu: vueAide },
];

// #aide/combat : l'onglet Aide, la section Combat en vue.
const lireAdresse = () => { const [o, s] = location.hash.slice(1).split('/'); return { onglet: ONGLETS.some(x => x.id === o) ? o : 'nouveautes', section: s || null }; };
let courant = lireAdresse().onglet;
const { barre, zone, choisir } = onglets('À propos', ONGLETS, courant, id => {
  if (id === courant) return;
  courant = id;
  if (lireAdresse().onglet !== id) history.replaceState(null, '', `#${id}`);
});
function allerSection() {
  const { onglet, section } = lireAdresse();
  if (onglet !== courant) choisir(onglet);
  if (section) requestAnimationFrame(() => document.getElementById(`aide-${section}`)?.scrollIntoView({ block: 'start' }));
}
window.addEventListener('hashchange', allerSection);

document.title = 'À propos · The Screen';
racine.replaceChildren(
  h('div', { class: 'cm-accueil__tete' }, h('span', { class: 'surtitre' }, 'The Screen'), signature(idCampagne)),
  h('h1', { class: 'titre-l' }, 'À propos'),
  h('p', { class: 'ui-l cm-apropos__nom' }, '« The Screen » Campaign Toolbox — gestionnaire de campagne pour D&D 5e'),
  h('div', { class: 'cm-pile cm-apropos__intro' },
    h('p', { class: 'texte' }, 'The Screen est l\'outil du MJ pour mener une campagne de D&D 5e (règles 2024) avec D&D Beyond : la trame, les lieux et les PNJ, le temps qui passe, les rencontres et les combats, les héros à jour depuis leurs fiches, la musique, les images. Il tourne sur votre PC, dans Chrome, et ne montre rien aux joueurs.'),
    h('p', { class: 'texte' }, 'Il ne remplace pas vos livres : votre agent IA de campagne en tire les données (les règles de travail de l\'agent sont dans AGENTS.md), le gestionnaire les met en jeu et note tout ce qui se passe à la table, puis lui rend chaque séance.')),
  barre, zone);
allerSection();
