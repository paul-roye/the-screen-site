// Feuilles D&D Beyond : lecture de etat/beyond.json (formats/etat.md), écrit toutes les 30 s par l'extension Chrome
// (extensions/mj/, voir extensions/mj/LISEZMOI.md). Le résumé d'une fiche est calculé par extensions/mj/resumer.js.

export { ORIGINE_BEYOND } from '../extensions/mj/resumer.js';

const VIDE = { schema: 1, campagne: null, fiches: {}, maj: null };

// L'empreinte d'un relevé, sans ses dates (`maj`, `releve…`) : deux relevés de même empreinte montrent la même chose, inutile de
// redessiner (retour du MJ, 2026-11-03 : l'affichage clignotait à chaque relevé, toutes les 30 s, et une fiche ouverte repartait du haut).
export const empreinteBeyond = b => JSON.stringify(b, (k, v) => (k === 'maj' || /^releve/.test(k) ? undefined : v));

export async function lireBeyond() {
  try {
    const r = await fetch('etat/beyond.json', { cache: 'no-store' });
    if (r.ok) return { ...structuredClone(VIDE), ...(await r.json()) };
  } catch { /* fichier absent ou serveur arrêté : rien de relevé */ }
  return structuredClone(VIDE);
}

// Demande directe à l'extension (monstres de D&D Beyond : rencontres du MJ et widget Combat ; objets : Babioles), sans passer par etat/ : commandes de
// extensions/mj/fond.js (ping, monstres, bestiaire, config, objet, etat, inspiration). L'extension note son identifiant dans
// etat/beyond.json (extension_id) ; la page doit être ouverte dans le Chrome où elle est installée (version 1.4.0 ou plus).
export async function demanderExtension(message, delai = 20000) {
  const id = (await lireBeyond()).extension_id;
  if (!globalThis.chrome?.runtime?.sendMessage) {
    throw new Error('Ce navigateur ne voit pas l\'extension. Ouvrez le gestionnaire dans le Chrome où elle est installée, et rechargez-la dans chrome://extensions (version 1.4.0 ou plus).');
  }
  if (!id) throw new Error('L\'extension n\'a pas encore noté son identifiant : rechargez-la dans chrome://extensions, puis attendez son prochain relevé (30 s au plus).');
  return new Promise((ok, ko) => {
    const minuterie = setTimeout(() => ko(new Error('L\'extension ne répond pas.')), delai);
    chrome.runtime.sendMessage(id, message, reponse => {
      clearTimeout(minuterie);
      if (chrome.runtime.lastError) return ko(new Error(`Extension injoignable : ${chrome.runtime.lastError.message} Rechargez-la dans chrome://extensions.`));
      if (!reponse?.ok) return ko(new Error(reponse?.erreur || 'Réponse vide de l\'extension.'));
      ok(reponse.resultat);
    });
  });
}

// Détails (historique, espèce, dons…) : relevés à la demande par l'extension dans etat/beyond-details.json.
export async function lireDetails() {
  try {
    const r = await fetch('etat/beyond-details.json', { cache: 'no-store' });
    if (r.ok) return await r.json();
  } catch { /* pas encore relevés */ }
  return { schema: 1, maj: null, fiches: {} };
}

// Demande de détails : l'extension la voit à son prochain relevé (30 s au plus) et note `traite`.
export async function demanderDetails() {
  const maintenant = new Date().toISOString();
  const r = await fetch('etat/beyond-demande.json', {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ schema: 1, details: maintenant, traite: null, maj: maintenant }, null, 2),
  });
  if (!r.ok) throw new Error(await r.text());
  return maintenant;
}

// ───── En Markdown, pour l'agent IA de campagne (widget Personnages, prompt de fin de session) ─────

export const LIBELLES_NOTES = { traits: 'Traits', ideaux: 'Idéaux', liens: 'Liens', defauts: 'Défauts', apparence: 'Apparence', histoire: 'Histoire', allies: 'Alliés', ennemis: 'Ennemis', organisations: 'Organisations', possessions: 'Possessions', biens: 'Biens', autres: 'Autres notes',
  genre: 'Genre', age: 'Âge', cheveux: 'Cheveux', yeux: 'Yeux', peau: 'Peau', taille: 'Taille', poids: 'Poids', foi: 'Foi' };

// Origines de tous les personnages (etat/beyond-details.json). `niveau` : niveau de titre d'un personnage (2 → « ## »).
export function originesEnMarkdown(details, beyond, niveau = 2) {
  const t = n => '#'.repeat(Math.min(6, niveau + n)) + ' ';
  const l = ['Textes de la fiche D&D Beyond de chaque personnage, en anglais tels quels (choix des joueurs). À croiser avec le wiki et les décisions du MJ, qui priment.', ''];
  for (const det of Object.values(details?.fiches || {})) {
    const joueur = beyond?.fiches?.[det.id]?.joueur;
    l.push(`${t(0)}${det.nom}${joueur ? ` (joué par ${joueur})` : ''}`, '');
    const bloc = (titre, texte) => { if (texte) l.push(`${t(2)}${titre}`, '', texte, ''); };
    if (det.espece) {
      l.push(`${t(1)}Espèce : ${det.espece.nom}`, '');
      if (det.espece.description) l.push(det.espece.description, '');
      [...det.espece.traits, ...det.espece.options].forEach(x => bloc(x.nom, x.description));
    }
    if (det.historique) {
      l.push(`${t(1)}Historique : ${det.historique.nom_original || det.historique.nom}`, '');
      if (det.historique.resume) l.push(`*${det.historique.resume}*`, '');
      if (det.historique.description) l.push(det.historique.description, '');
      if (det.historique.aptitude) bloc(det.historique.aptitude.nom, det.historique.aptitude.description);
    }
    if (det.dons?.length) { l.push(`${t(1)}Dons`, ''); det.dons.forEach(d => bloc(`${d.nom}${d.categorie ? ` (${d.categorie})` : ''}`, d.description)); }
    for (const c of det.classes || []) if (c.sous_classe) { l.push(`${t(1)}Sous-classe : ${c.sous_classe.nom} (${c.nom})`, ''); if (c.sous_classe.description) l.push(c.sous_classe.description, ''); }
    if (det.options_de_classe?.length) { l.push(`${t(1)}Options de classe`, ''); det.options_de_classe.forEach(o => bloc(o.nom, o.description)); }
    const libres = { ...det.apparence, ...det.personnalite, ...det.notes };
    if (Object.keys(libres).length) { l.push(`${t(1)}Notes de la fiche`, ''); Object.entries(libres).forEach(([k, v]) => l.push(`- **${LIBELLES_NOTES[k] || k}** : ${v}`)); l.push(''); }
  }
  return l.join('\n');
}

// Une fiche relevée (etat/beyond.json), en lignes Markdown : l'essentiel pour tenir à jour les fiches de l'agent.
const PIECES = [['pp', 10], ['po', 1], ['pe', 0.5], ['pa', 0.1], ['pc', 0.01]];
export const enPo = a => PIECES.reduce((s, [k, v]) => s + (a?.[k] || 0) * v, 0);
export const bourse = a => PIECES.filter(([k]) => a?.[k]).map(([k]) => `${a[k]} ${k}`).join(', ') || 'rien';
export function ficheEnMarkdown(f) {
  const restants = u => `${Math.max(0, u.max - u.utilises)}/${u.max}`;
  const ressources = [
    ...(f.emplacements || []).map(e => `emplacements niv. ${e.niveau} ${restants(e)}`),
    ...(f.pacte ? [`magie de pacte niv. ${f.pacte.niveau} ${restants(f.pacte)}`] : []),
    ...(f.usages || []).map(u => `${u.nom} ${restants(u)}`),
  ];
  const l = [
    `niveau ${f.niveau} (${f.classes.map(c => `${c.nom} ${c.niveau}${c.sous_classe ? `, ${c.sous_classe}` : ''}`).join(' / ')}), ${f.espece || 'espèce ?'}, historique ${f.historique || '?'}`,
    `PV ${f.pv.actuels}/${f.pv.max}${f.pv.temporaires ? ` (+${f.pv.temporaires} temporaires)` : ''} ; CA ${f.ca} ; perception passive ${f.passives.perception}, intuition passive ${f.passives.intuition}${f.sorts?.length ? ` ; DD des sorts ${f.sorts.map(s => s.dd).join('/')}` : ''}`,
  ];
  if (f.etats?.length || f.inspiration) l.push([...(f.etats || []).map(e => e.niveau ? `${e.nom} ${e.niveau}` : e.nom), f.inspiration ? 'inspiration héroïque disponible' : null].filter(Boolean).join(', '));
  if (ressources.length) l.push(`ressources restantes : ${ressources.join(', ')}`);
  l.push(`objets magiques : ${f.objets_magiques?.length ? f.objets_magiques.map(o => `${o.nom}${o.rarete ? ` (${o.rarete})` : ''}`).join(', ') : 'aucun'}`);
  l.push(`bourse : ${bourse(f.argent)}`);
  if (f.forme_sauvage) l.push(`en forme sauvage : ${f.forme_sauvage.nom}, CA ${f.forme_sauvage.ca}`);
  for (const c of f.creatures || []) l.push(`${c.groupe} : ${c.nom}, PV ${c.pv.actuels}/${c.pv.max}, CA ${c.ca}`);
  return l;
}

// Un héros à 0 PV (résumé d'une fiche) est à terre : il fait ses jets contre la mort ; trois ratés : il est mort.
// Personnages et Combat.
export const aTerre = f => !!f?.jets_contre_la_mort && f.pv?.actuels <= 0;
export const estMort = f => aTerre(f) && (f.jets_contre_la_mort.echecs || 0) >= 3;

export function idFeuille(url) {
  return String(url || '').match(/dndbeyond\.com\/(?:profile\/[^/]+\/)?characters\/(\d+)/)?.[1] || null;
}

const simple = t => String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const premierMot = t => simple(t).split(' ')[0];

// Fiche relevée d'un personnage joueur : par le lien liens.feuille, sinon par le premier mot du nom.
export function ficheDe(p, beyond) {
  if (!beyond || p.role !== 'personnage') return null;
  const id = idFeuille(p.liens?.feuille);
  if (id && beyond.fiches[id]) return beyond.fiches[id];
  const mot = premierMot(p.nom_court || p.nom);
  return Object.values(beyond.fiches).find(f => premierMot(f.nom) === mot) || null;
}

// Compagnons d'un personnage : ceux de data/personnages.json, appariés aux créatures de sa fiche (onglet Extras),
// plus les créatures de la fiche que l'agent ne connaît pas encore. → [{ p (ou null), creature (ou null) }]
export function compagnonsAvecFiches(compagnons, fiche) {
  const creatures = [...(fiche?.creatures || [])];
  const proche = (a, b) => { const x = simple(a), y = simple(b); return x && y && (x === y || x.includes(y) || y.includes(x)); };
  const paires = compagnons.map(p => {
    let i = creatures.findIndex(c => proche(c.nom, p.nom) || proche(c.nom, p.nom_court));
    if (i < 0 && compagnons.length === 1 && creatures.length === 1) i = 0;
    return { p, creature: i >= 0 ? creatures.splice(i, 1)[0] : null };
  });
  return [...paires, ...creatures.map(creature => ({ p: null, creature }))];
}
