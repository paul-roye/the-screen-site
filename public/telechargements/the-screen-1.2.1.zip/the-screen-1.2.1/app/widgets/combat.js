// Widget Combat (mode Rencontre) : mène la rencontre lancée depuis le gestionnaire (« Lancer » d'une rencontre prévue, créée
// ou tirée : app/rencontres-mj.js). La démarrer ; lancer l'initiative (un d20 par type de monstre ; les héros donnent la
// leur, un compagnon agit avec son maître) ; démarrer le combat, tour par tour (un monstre à 0 PV passe son tour) ; dégâts et soins des
// monstres, leurs fiches D&D Beyond ; la terminer, avec une remarque. La préparation reste modifiable (renforts…).
// Les PV et la CA des héros et de leurs compagnons viennent de leurs fiches (etat/beyond.json, relu toutes les 5 s) ; un
// héros à 0 PV montre ses jets contre la mort à la place de sa CA. Portraits : wiki pour les héros, D&D Beyond pour les
// monstres. Lien « Historique » en bas : les rencontres jouées ou commencées, et celles des tirages, en fenêtre.
// État : `combat` de etat/rencontres-mj.json (formats/etat.md).

import { h, icone, bouton, section, flottant, flottantOuvert, lienFlottant, jetsContreLaMort, marqueMort, infobulle, ouvrirMenu, deNom } from '../ui.js';
import { etatsDe, etatDe, iconeEtat, nomEtat, effetsEtat, coutEpuisement, choixEtats, chargerIconesEtats, poserEtat, retirerEtat, EPUISEMENT, NIVEAU_MAX, etatsCreatures, avecEtats, poserEtatCreature, retirerEtatCreature, iconeRampage, tuileEncombrement } from '../etats.js';
import { annoncer } from '../horloge.js';
import { lireBeyond, empreinteBeyond, idFeuille, aTerre, estMort, demanderExtension } from '../beyond.js';
import { lancer } from '../des.js';
import { montrerJets, formuleD20 } from '../lancers.js';
import { chargerWiki, portraitDuPersonnage } from '../wiki.js';
import { outilsRencontresMj } from '../rencontres-mj.js';
import { libellePuissance, signe } from '../monstres.js';
import { badgeDifficulte, vueDifficulte, ouvrirAide, majAide, ouvrirAideSbires, ROLES, rolesActifs } from '../difficulte.js';
import { emettre } from '../evenements.js';
import { contributions } from '../modules.js';

const RELIRE_MS = 5000;
const CAMPS = { pj: 'PJ', compagnon: 'Allié', monstre: 'Ennemi' };
const RANG_TYPE = { pj: 0, compagnon: 1, monstre: 2 };   // à égalité d'initiative : les héros, leurs compagnons, puis les monstres

// Jauge de PV compacte (composant BarrePV, variante mini). À 0 PV, un héros est inconscient, un monstre hors de combat.
// L'état de santé à côté des PV, un point médian entre les deux (« Ensanglanté · 11/22 », comme « PV · Inconscient » de
// Personnages) : sur un widget étroit, ce texte monte sur la ligne du camp, la barre juste dessous (CSS, .cm-combat).
function pvMini(nom, { actuels, max, temporaires = 0 }, pj) {
  const part = max ? actuels / max : 0;
  const etat = actuels <= 0 ? 'mort' : part < 0.2 ? 'critique' : part <= 0.5 ? 'ensanglante' : null;
  const mot = { mort: pj ? 'Inconscient' : 'Hors de combat', critique: 'Critique', ensanglante: 'Ensanglanté' }[etat];
  const total = Math.max(max, actuels + temporaires) || 1;
  return h('div', { class: 'bn-pv bn-pv--mini', 'data-etat': etat, style: `--pv: ${(actuels / total) * 100}%; --pv-temp: ${(temporaires / total) * 100}%` },
    h('div', { class: 'bn-pv__tete cm-combat__pv-tete' },
      h('span', { class: 'bn-pv__val' }, mot ? [h('span', { class: 'bn-pv__etat' }, mot), ' · '] : null,
        h('b', {}, actuels), '/' + max, temporaires ? h('span', { class: 'bn-pv__temp' }, ' +' + temporaires) : null)),
    h('div', { class: 'bn-pv__barre', role: 'meter', 'aria-label': `Points de vie de ${nom}`, 'aria-valuemin': '0', 'aria-valuemax': String(max), 'aria-valuenow': String(actuels) },
      h('span', { class: 'bn-pv__plein' }), temporaires ? h('span', { class: 'bn-pv__tampon' }) : null));
}

// Raccourcis clavier du combat (demande du MJ, 2026-10-31), au clavier principal et au pavé numérique. Leur aide : les plans
// du pavé et du clavier, chaque touche de la couleur de son action (ultra les tours, brume la ligne choisie, os les chiffres,
// sang les dégâts, mousse les soins, cierge la fiche et l'état ; sans ton : sans effet), dans une fenêtre ouverte par l'icône
// clavier de l'en-tête ; la touche appuyée s'y allume. code : la touche physique (event.code), cle : le caractère (event.key).
const touche = (g, ton, legende, { code, cle, forme } = {}) => ({ g, ton, legende, code, cle, forme });
const PAVE = [
  touche('Num', null, 'au choix', { code: 'NumLock' }), touche('/', 'ultra', 'Préc.', { code: 'NumpadDivide' }),
  touche('*', 'ultra', 'Suiv.', { code: 'NumpadMultiply' }), touche('−', 'sang', 'Dégâts', { code: 'NumpadSubtract' }),
  ...[7, 8, 9].map(n => touche(String(n), 'os', null, { code: 'Numpad' + n })), touche('+', 'mousse', 'Soins', { code: 'NumpadAdd', forme: 'haute' }),
  ...[4, 5, 6, 1, 2, 3].map(n => touche(String(n), 'os', null, { code: 'Numpad' + n })),
  touche('Entrée', 'sang', 'Dégâts\nseule : fiche', { code: 'NumpadEnter', forme: 'haute' }),
  touche('0', 'os', null, { code: 'Numpad0', forme: 'large' }), touche(',', null, null, { code: 'NumpadDecimal' }),
];
const NAVIGATION = [
  touche('Inser', null, null, { code: 'Insert' }), touche('Début', 'brume', 'Tour', { code: 'Home' }), touche('Pg préc.', 'ultra', 'Préc.', { code: 'PageUp' }),
  touche('Suppr', null, null, { code: 'Delete' }), touche('Fin', null, null, { code: 'End' }), touche('Pg suiv.', 'ultra', 'Suiv.', { code: 'PageDown' }),
];
const FLECHES = [null, touche('↑', 'brume', 'Ligne', { code: 'ArrowUp' }), null,
  touche('←', null, null, { code: 'ArrowLeft' }), touche('↓', 'brume', 'Ligne', { code: 'ArrowDown' }), touche('→', null, null, { code: 'ArrowRight' })];
const AUTRES = [
  touche('Échap', 'brume', 'Annuler', { code: 'Escape' }), touche('0 – 9', 'os', 'PV', { cle: '0123456789'.split(''), forme: 'large' }),
  touche('−', 'sang', 'Dégâts', { cle: ['-'] }), touche('+', 'mousse', 'Soins', { cle: ['+'] }),
  touche('Entrée', 'sang', 'Dégâts', { code: 'Enter', forme: 'large' }), touche('F', 'cierge', 'Fiche', { cle: ['f'] }), touche('E', 'cierge', 'État', { cle: ['e'] }),
];
const LEGENDE = [
  ['ultra', ['*', '/', 'Pg suiv.', 'Pg préc.'], 'Tour suivant, tour précédent.'],
  ['brume', ['↑', '↓', 'Début'], 'Choisir une ligne (contour bleu) ; Début ou Échap : celle du tour.'],
  ['os', ['0 – 9'], 'Les PV de la ligne choisie : la saisie s\'ouvre avec le chiffre.'],
  ['sang', ['−', 'Entrée'], 'Après les chiffres : dégâts. Échap : annuler.'],
  ['mousse', ['+'], 'Après les chiffres : soins (« + 8 Entrée » aussi).'],
  ['cierge', ['F', 'E'], 'Sa fiche (Entrée seule aussi) ; poser un état.'],
];
function vueTouche(t) {
  if (!t) return h('span', {});
  return h('kbd', { class: `cm-touche${t.ton ? '' : ' cm-touche--vide'}${t.forme ? ' cm-touche--' + t.forme : ''}`, 'data-ton': t.ton, 'data-code': t.code, 'data-cle': t.cle?.join(' ') },
    h('span', { class: 'cm-touche__g' + (t.g.length > 2 ? ' cm-touche__g--mot' : '') }, t.g),
    t.legende ? h('span', { class: 'cm-touche__l' }, t.legende) : null);
}
// Les plans (pour l'œil seul : la légende dessous dit tout), puis la légende.
function vueClavier() {
  const plan = (titre, ...blocs) => h('figure', { class: 'cm-clavier__plan' }, h('figcaption', { class: 'surtitre' }, titre), ...blocs);
  return h('div', { class: 'cm-clavier' },
    h('div', { class: 'cm-clavier__plans', 'aria-hidden': 'true' },
      plan('Pavé numérique', h('div', { class: 'cm-clavier__pave' }, PAVE.map(vueTouche))),
      plan('Navigation', h('div', { class: 'cm-clavier__nav' }, NAVIGATION.map(vueTouche)), h('div', { class: 'cm-clavier__nav' }, FLECHES.map(vueTouche))),
      plan('Clavier', h('div', { class: 'cm-clavier__autres' }, AUTRES.map(vueTouche)))),
    h('ul', { class: 'cm-clavier__legende' }, LEGENDE.map(([ton, touches, texte]) => h('li', { 'data-ton': ton },
      h('span', { class: 'cm-clavier__touches' }, touches.map(g => h('kbd', { class: 'cm-touche cm-touche--mini', 'data-ton': ton }, g))),
      h('span', { class: 'ui-s' }, texte)))),
    h('p', { class: 'ui-s cm-sourdine cm-clavier__note' }, 'Pendant le combat, quand rien d\'autre n\'a la main (champ, menu, autre fenêtre). Pavé numérique verrouillé ou non : ses chiffres comptent toujours, ses flèches aussi ; pour choisir la ligne, les flèches du clavier.'));
}
// La touche appuyée s'allume dans l'aide ouverte (au pavé, par sa touche physique ; ailleurs, aussi par son caractère).
function allumerTouche(fenetre, e) {
  const cle = e.key.toLowerCase();
  for (const el of fenetre.querySelectorAll('.cm-touche[data-code], .cm-touche[data-cle]')) {
    const oui = el.dataset.code === e.code || (!e.code.startsWith('Numpad') && el.dataset.cle?.split(' ').includes(cle));
    if (!oui) continue;
    el.classList.remove('est-appuyee');
    void el.offsetWidth;   // relance l'animation
    el.classList.add('est-appuyee');
  }
}
// « - » : dégâts, « + » : soins (clavier principal ou pavé).
const touchesSigne = e => (e.key === '-' || e.code === 'NumpadSubtract' ? 'degats' : e.key === '+' || e.code === 'NumpadAdd' ? 'soins' : null);

// Dégâts : les PV temporaires d'abord (règle de base). Renvoie { pv, pv_temp }.
function infliger(m, n) {
  const temp = Math.min(m.pv_temp || 0, n);
  return { pv: Math.max(0, m.pv - (n - temp)), pv_temp: (m.pv_temp || 0) - temp };
}

export default {
  type: 'combat',
  titre: 'Combat',
  icone: 'epee',
  description: 'Mène la rencontre lancée depuis le gestionnaire : initiative (un jet par type de monstre ; un compagnon joue au tour de son maître), round et tour, PV des monstres et leurs fiches D&D Beyond, les héros à jour depuis leurs fiches ; historique des rencontres jouées.',
  taille: { w: 8, h: 14 },
  min: { w: 4, h: 6 },
  unique: true,

  async monter({ corps, actions, donnees, etat, dialogue }) {
    const R = await outilsRencontresMj({ donnees, etat, dialogue });
    const persos = (await donnees('personnages')).donnees?.personnages || [];
    // Portraits des héros et de leurs compagnons ; icônes des états ; états des compagnons (gardés dans le gestionnaire).
    const [wiki, , sc] = await Promise.all([chargerWiki().catch(() => null), chargerIconesEtats(), etatsCreatures()]);
    let beyond = await lireBeyond();
    let edition = null;          // clé du monstre dont on change les PV
    let focusApres = null;       // clé du champ d'initiative à reprendre après le rendu (saisie à la suite)
    let choisie = null;          // clé de la ligne choisie au clavier (celle du tour, à chaque nouveau tour)
    let saisiePv = null;         // formulaire des PV ouvert au clavier : { mode: 'degats' | 'soins', texte } (premier chiffre)
    const combat = () => R.v().combat;
    const enregistrer = () => { R.enregistrer(surChangement); rendre(); };   // les autres abonnés sont prévenus, pas ce widget

    const widget = () => corps.closest('.bn-widget');
    const visible = () => !!corps.closest('.cm-tableau');   // dans la grille du mode affiché, pas en réserve
    const premierMot = t => String(t || '').trim().split(/\s+/)[0].toLowerCase();
    // Personnage de data/personnages.json d'une fiche : par le lien de sa feuille, sinon par le premier mot du nom.
    const persoDe = (id, f) => persos.find(x => x.role === 'personnage' && (idFeuille(x.liens?.feuille) === String(id) || premierMot(x.nom_court || x.nom) === premierMot(f.nom)));
    // Compagnon des données d'une créature : le seul du maître s'il n'y a qu'une créature, sinon par le premier mot du nom.
    function compagnonDe(maitre, f, cr) {
      const liste = maitre ? persos.filter(x => x.role === 'compagnon' && x.compagnon_de === maitre.id) : [];
      return (liste.length === 1 && (f.creatures || []).length === 1 ? liste[0] : null)
        || liste.find(x => premierMot(x.nom_court || x.nom) === premierMot(cr.nom)) || null;
    }

    // ───── Combattants ─────

    // Héros et compagnons (fiches D&D Beyond), puis monstres ; initiative et absence des héros gardées dans le combat.
    function combattants() {
      const c = combat();
      const heros = Object.entries(beyond.fiches || {}).flatMap(([id, f]) => {
        const perso = persoDe(id, f);
        return [
          { cle: 'pj:' + id, type: 'pj', nom: perso?.nom_court || perso?.nom || f.nom.split(' ')[0], perso: perso?.id || null, fiche: f, bonus: f.initiative || 0, defautAbsent: false,
            image: f.forme_sauvage?.avatar || portraitDuPersonnage(perso, wiki, f.avatar) },   // en forme sauvage : le portrait de la forme
          ...(f.creatures || []).map(cr => {
            const comp = compagnonDe(perso, f, cr);
            // Un compagnon agit au tour de son maître, avec son initiative (règles des compagnons de Flee, Mortals!, rappel du
            // MJ du 2026-10-20) : pas de jet à lui, pas de place à lui dans l'ordre, sa ligne suit celle de son maître.
            return { cle: `cr:${id}:${cr.id}`, type: 'compagnon', nom: comp?.nom_court || comp?.nom || cr.nom, perso: comp?.id || null, fiche: avecEtats(sc, cr), maitre: perso?.nom_court || f.nom.split(' ')[0],
              maitreCle: 'pj:' + id, defautAbsent: false,   // un compagnon combat toujours (même « inactif » sur sa fiche)
              image: portraitDuPersonnage(comp, wiki) };
          }),
        ];
      }).map(x => ({ ...x, init: c.heros?.[x.maitreCle || x.cle]?.init ?? null, absent: c.heros?.[x.cle]?.absent ?? x.defautAbsent }));
      const monstres = (c.monstres || []).map((m, i) => ({ cle: m.cle, type: 'monstre', nom: m.nom, m, fiche: m, rang: i, init: m.init, absent: false }));   // fiche : ses états (m.etats)
      return [...heros.map((x, i) => ({ ...x, rang: i })), ...monstres];
    }
    const valeur = x => (Number.isInteger(x.init) ? x.init : -99);
    const trier = l => [...l].sort((a, b) => valeur(b) - valeur(a) || RANG_TYPE[a.type] - RANG_TYPE[b.type] || a.rang - b.rang);
    // L'ordre des tours : les héros et les monstres présents (un compagnon passe avec son maître).
    const ordre = () => trier(combattants().filter(x => !x.absent && x.type !== 'compagnon'));
    // Les compagnons présents d'un héros (sa ligne, puis la leur, au même tour).
    const compagnonsDe = (tous, cle) => tous.filter(y => y.maitreCle === cle && !y.absent);
    // Le tour d'un compagnon (combat commencé avant le 2026-10-20, quand il avait le sien) : celui de son maître.
    const tourDe = cle => (String(cle || '').startsWith('cr:') ? 'pj:' + cle.split(':')[1] : cle);
    // Passent leur tour : un monstre à 0 PV, un héros mort (trois jets contre la mort ratés), sauf si son compagnon tient
    // encore debout (il agit alors seul, à ce tour-là).
    const horsCombat = x => (x.type === 'monstre' ? x.m.pv <= 0
      : x.type === 'pj' && estMort(x.fiche) && !compagnonsDe(combattants(), x.cle).some(y => (y.fiche.pv?.actuels ?? 1) > 0));

    // ───── Actions ─────

    // immediat : redessiner tout de suite (Entrée ou Tab, le champ suivant est déjà choisi) ; sinon (champ quitté à la souris)
    // juste après, pour garder le champ où l'on vient de cliquer, même si l'ordre change.
    function changerInitiative(x, texte, { immediat = false } = {}) {
      const val = texte === '' ? null : Math.round(Number(texte));
      if (val !== null && !Number.isFinite(val)) return;
      const c = combat();
      const m = x.type === 'monstre' ? c.monstres.find(y => y.cle === x.cle) : null;
      if ((m ? m.init : c.heros[x.cle]?.init) === val) return;
      if (m) m.init = val;
      else (c.heros[x.cle] ||= {}).init = val;
      R.enregistrer(surChangement);
      if (immediat) rendre(); else setTimeout(rendre, 0);
    }
    // Initiatives manquantes (ou toutes, tout : relancer) : un d20 par type de monstre (le groupe agit ensemble, comme dans
    // D&D Beyond). Les héros donnent la leur ; un compagnon prend celle de son maître.
    // Les d20 roulent en 3D, un résultat par ligne (app/lancers.js), et vont dans l'historique du widget Dés.
    function lancerInitiatives(tout = false, depuis = null) {
      const rect = depuis?.getBoundingClientRect() || null;   // mesuré avant le rendu, qui remplace le bouton
      const c = combat();
      const groupes = R.vueDe(c.rencontre)?.groupes || [];
      const parType = new Map();   // id de monstre -> son jet (un pour tout le type)
      const montres = [];
      for (const m of c.monstres) {
        if (!tout && Number.isInteger(m.init)) continue;
        if (!parType.has(m.monstre)) {
          const formule = formuleD20(m.bonus || 0), jet = lancer(formule);
          parType.set(m.monstre, jet);
          montres.push({ libelle: groupes.find(g => g.cle === m.groupe)?.nom || m.nom, jet, formule });
        }
        m.init = parType.get(m.monstre).total;
      }
      enregistrer();
      montrerJets(montres, { legende: 'Initiative', depuis: rect });
    }
    function basculerAbsent(x) {
      const c = combat();
      (c.heros[x.cle] ||= {}).absent = !x.absent;
      enregistrer();
    }
    function demarrerCombat() {
      const c = combat();
      R.demarrer(c.rencontre);
      const premier = ordre().find(x => !horsCombat(x));
      Object.assign(c, { phase: 'combat', round: 1, tour: premier?.cle || null });
      enregistrer();
    }
    // Tour suivant (sens 1) ou précédent (-1) : les monstres hors de combat sont passés ; le round change au bout de l'ordre.
    function avancer(sens) {
      const c = combat();
      const l = ordre();
      if (!l.length) return;
      let i = l.findIndex(x => x.cle === tourDe(c.tour));
      if (i < 0) i = sens > 0 ? -1 : 0;
      for (let n = 0; n < l.length; n++) {
        i += sens;
        if (i >= l.length) { i = 0; c.round += 1; }
        if (i < 0) { if (c.round <= 1) return; i = l.length - 1; c.round -= 1; }
        if (!horsCombat(l[i])) break;
      }
      c.tour = l[i].cle;
    }
    const tourSuivant = () => { avancer(1); enregistrer(); };
    const tourPrecedent = () => { avancer(-1); enregistrer(); };
    // Annuler (demande du MJ, 2026-10-25) : la rencontre n'a pas eu lieu, tout est défait (app/rencontres-mj.js, annuler()).
    async function annuler() {
      await R.annuler(combat().rencontre);
      edition = null;
      rendre();
    }
    // Remettre la rencontre à zéro (demande du MJ, 2026-10-20), après confirmation : l'initiative de tous, le combat avant
    // le round 1 ; au choix, les PV des monstres (au maximum, sans temporaires) et leurs états. Les états des héros restent
    // (sur leurs fiches), comme les absents.
    function remettreAZero() {
      const c = combat(), vue = R.vueDe(c.rencontre);
      let dlg;
      const casePv = h('input', { type: 'checkbox', class: 'bn-case', checked: true });
      const caseEtats = h('input', { type: 'checkbox', class: 'bn-case', checked: true });
      const valider = () => {
        for (const m of c.monstres || []) {
          m.init = null;
          if (casePv.checked) Object.assign(m, { pv: m.pv_max, pv_temp: 0 });
          if (caseEtats.checked) delete m.etats;
        }
        for (const x of Object.values(c.heros || {})) if (x) x.init = null;
        Object.assign(c, { round: 0, tour: null, phase: c.phase === 'combat' ? 'en-cours' : c.phase });
        edition = null;
        enregistrer();
        dlg.close();
      };
      dlg = dialogue('Combat', `Remettre à zéro : ${vue?.nom || 'la rencontre'}`, h('div', { class: 'cm-pile' },
        h('p', { class: 'ui' }, 'L\'initiative de tous est effacée ; le combat revient avant le round 1.'),
        h('label', { class: 'cm-case' }, casePv, 'Remettre les PV des monstres au maximum'),
        h('label', { class: 'cm-case' }, caseEtats, 'Retirer les états des monstres (ceux des héros restent sur leurs fiches)')),
      h('div', { class: 'bn-groupe' },
        bouton('Remettre à zéro', { classe: 'bn-btn--primaire', icone: 'lu-refresh-cw', onclick: valider }),
        bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    }
    function changerPv(m, quoi, n) {
      if (!(n > 0)) return;
      Object.assign(m, quoi === 'degats' ? infliger(m, n) : quoi === 'soins' ? { pv: Math.min(m.pv_max, m.pv + n) } : { pv_temp: n });
      edition = null;
      enregistrer();
      emettre('combat:pv', { cle: m.cle, type: 'monstre', nom: m.nom, perso: null, quoi, montant: n, pv: { actuels: m.pv, max: m.pv_max, temporaires: m.pv_temp || 0 } });
    }
    // Les PV d'un héros ou de son compagnon, écrits sur la fiche D&D Beyond par l'extension (commande pv) : affichés aussitôt,
    // puis relus ; échec : les PV d'avant reviennent, avec une annonce. pv (du relevé) : { actuels, max, temporaires }.
    // La créature est relue dans le relevé (x.fiche d'un compagnon en est une copie, avec ses états).
    const ficheBrute = x => {
      const [, id, cr] = x.cle.split(':');
      return x.type === 'pj' ? beyond.fiches?.[id] : beyond.fiches?.[id]?.creatures?.find(c => String(c.id) === cr);
    };
    async function changerPvHeros(x, quoi, n) {
      const f = ficheBrute(x);
      if (!(n > 0) || !f?.pv) return;
      const avant = { ...f.pv };
      const { pv: actuels, pv_temp: temporaires } = quoi === 'degats' ? infliger({ pv: avant.actuels, pv_temp: avant.temporaires }, n)
        : quoi === 'soins' ? { pv: Math.min(avant.max, avant.actuels + n), pv_temp: avant.temporaires } : { pv: avant.actuels, pv_temp: n };
      Object.assign(f.pv, { actuels, temporaires });
      edition = null;
      ecritures++;
      rendre();
      emettre('combat:pv', { cle: x.cle, type: x.type, nom: x.nom, perso: x.perso || null, quoi, montant: n, pv: { actuels, max: avant.max, temporaires } });
      const [, id, cr] = x.cle.split(':');
      try { await demanderExtension({ type: 'pv', personnage: id, creature: x.type === 'pj' ? null : cr, perdus: avant.max - actuels, temporaires }, 30000); }
      catch (e) { Object.assign(f.pv, avant); annoncer({ cle: 'beyond-ecriture', titre: `PV de ${x.nom} : fiche D&D Beyond inchangée`, icone: 'lu-triangle-alert', couleur: 'sang', texte: e.message }); }
      ecritures--;
      beyond = await lireBeyond();
      rendre();
    }

    // ───── Rendu ─────

    // Entrée ou Tab : la valeur est notée et le champ suivant prend la main, pour saisir les jets des joueurs à la suite :
    // depuis un héros, le héros suivant (dans l'ordre affiché avant le tri), sinon le premier héros sans initiative ; depuis
    // un autre combattant, le champ suivant.
    // Flèches haut / bas : ±1 (un champ vide part de 10). L'ordre n'est refait que 0,8 s après le dernier clic : la ligne ne
    // bouge pas sous la souris pendant qu'on clique.
    let reordonner = null;
    function pasInitiative(x, champ, ecart) {
      const n = (champ.value === '' ? 10 : Math.round(Number(champ.value))) + ecart;
      if (!Number.isFinite(n)) return;
      champ.value = String(n);
      const c = combat();
      const m = x.type === 'monstre' ? c.monstres.find(y => y.cle === x.cle) : null;
      if (m) m.init = n; else (c.heros[x.cle] ||= {}).init = n;
      R.enregistrer(surChangement);
      clearTimeout(reordonner);
      reordonner = setTimeout(rendre, 800);
    }
    function cellInitiative(x) {
      let champ;
      const fleche = (ic, ecart, titre) => h('button', { type: 'button', class: 'cm-combat__init-pas', tabindex: '-1', title: titre, 'aria-label': `${titre} : ${x.nom}`,
        onclick: () => pasInitiative(x, champ, ecart) }, icone(ic));
      // Avant le combat, un champ vide est souligné : le combat ne démarre pas sans lui.
      const manque = combat()?.phase !== 'combat' && !horsCombat(x) && !Number.isInteger(x.init);
      return h('span', { class: 'bn-init__score cm-combat__score' }, champ = h('input', {
        class: 'bn-input cm-combat__init' + (manque ? ' est-manquante' : ''), type: 'number', inputmode: 'numeric', value: x.init ?? '',
        'aria-label': `Initiative de ${x.nom}`, 'data-cle': x.cle, title: `Initiative ${signe(x.type === 'monstre' ? x.m.bonus || 0 : x.bonus || 0)}`,
        onchange: e => changerInitiative(x, e.target.value),
        onkeydown: e => {
          if (e.key !== 'Enter' && !(e.key === 'Tab' && !e.shiftKey)) return;
          e.preventDefault();
          const champs = [...corps.querySelectorAll('.cm-combat__init')];
          const heros = champs.filter(c => c.dataset.cle.startsWith('pj:'));
          const suivant = x.type !== 'pj' ? champs[champs.indexOf(e.target) + 1] || null
            : heros[heros.indexOf(e.target) + 1] || heros.find(c => c !== e.target && c.value === '') || null;
          focusApres = suivant?.dataset.cle || null;
          if (String(x.init ?? '') !== e.target.value) changerInitiative(x, e.target.value, { immediat: true });
          else { focusApres = null; suivant?.focus(); suivant?.select(); }
        },
      }), h('span', { class: 'cm-combat__init-fleches' }, fleche('lu-chevron-up', 1, 'Initiative +1'), fleche('lu-chevron-down', -1, 'Initiative −1')));
    }

    // Portrait d'un combattant (composant Initiative) : son image, sinon son initiale (un crâne pour un monstre).
    // surClic : le portrait devient un bouton (celui d'un héros ou d'un compagnon : poser un état ; ou : où il s'écrit).
    function portraitCombattant(src, nom, monstre = false, { surClic = null, titre = '', ou = '' } = {}) {
      const initiale = String(nom || '?').replace(/^(le|la|les|l['’])\s*/i, '').charAt(0).toUpperCase();
      const repli = () => (monstre ? icone('crane') : document.createTextNode(initiale));
      const el = h('span', { class: 'bn-init__portrait' + (surClic ? ' cm-combat__portrait-etats' : ''), 'aria-hidden': surClic ? null : 'true' },
        src ? h('img', { src, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer', onerror: e => e.target.replaceWith(repli()) }) : repli());
      if (!surClic) return el;
      Object.assign(el, { tabIndex: 0, onclick: surClic, onkeydown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); surClic(e); } } });
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', titre);
      return infobulle(el, `Un clic : poser un état, ${ou}.`, { titre: nom });
    }

    // ───── États des héros (app/etats.js) : en icônes, posés et retirés sur la fiche D&D Beyond par l'extension ─────
    // Le changement s'affiche aussitôt, puis la fiche est relue ; échec : l'état d'avant revient, avec une annonce. Pendant
    // une écriture, la relecture de fond attend. Ceux d'un compagnon sont gardés dans le gestionnaire (etats-creatures).
    sc.abonner(() => { if (combat()) rendre(); });
    let ecritures = 0;
    async function ecrireEtat(x, liste, ecriture, echec) {
      const f = x.fiche, avant = f.etats;
      f.etats = liste.map(e => ({ id: e.id, nom: e.nom, niveau: e.niveau }));
      ecritures++;
      rendre();
      try { await ecriture(); }
      catch (e) { f.etats = avant; annoncer({ cle: 'beyond-ecriture', titre: echec, icone: 'lu-triangle-alert', couleur: 'sang', texte: e.message }); }
      ecritures--;
      beyond = await lireBeyond();
      rendre();
    }
    // Ceux d'un monstre sont gardés avec lui dans le combat (rencontres-mj.json).
    function poserSur(x, id, niveau = null) {
      if (x.type === 'compagnon') return poserEtatCreature(sc, x.fiche, id, niveau);
      if (x.type === 'monstre') {
        const e = etatDe({ id, niveau });
        x.m.etats = [...(x.m.etats || []).filter(y => y.id !== id), { id, nom: e.nom, niveau: e.niveau }];
        return enregistrer();
      }
      const e = etatDe({ id, niveau });
      return ecrireEtat(x, [...etatsDe(x.fiche).filter(y => y.id !== id), e], () => poserEtat(x.fiche.id, id, e.niveau), `${nomEtat(e)} : pas posé sur la fiche de ${x.nom}`);
    }
    function retirerDe(x, id) {
      if (x.type === 'compagnon') return retirerEtatCreature(sc, x.fiche, id);
      if (x.type === 'monstre') {
        x.m.etats = (x.m.etats || []).filter(y => y.id !== id);
        if (!x.m.etats.length) delete x.m.etats;
        return enregistrer();
      }
      const e = etatDe({ id });
      return ecrireEtat(x, etatsDe(x.fiche).filter(y => y.id !== id), () => retirerEtat(x.fiche.id, id), `${e.nom} : pas retiré de la fiche de ${x.nom}`);
    }
    const menuPoser = x => ev => ouvrirMenu(ev.currentTarget, choixEtats(x.fiche, (id, niveau) => poserSur(x, id, niveau)), `Poser un état sur ${x.nom}`, { classe: 'cm-menu-etats' });
    // Les états d'un héros en icônes (pas de texte) ; un clic : ses effets, son niveau (Épuisement), le retirer.
    function iconesEtats(x) {
      // Un héros encombré (règle variante) : sa tuile après ses états (app/etats.js).
      const enc = x.cle?.startsWith('pj:') ? tuileEncombrement(x.fiche, x.nom, 'bn-etat--s cm-combat__etat') : null;
      // Un druide en forme sauvage (noté par l'extension de son joueur) : un petit badge, sa CA et sa forme au survol.
      const forme = x.cle?.startsWith('pj:') && x.fiche?.forme_sauvage ? infobulle(h('span', { class: 'bn-badge bn-badge--ultra cm-combat__forme', tabindex: '0', 'aria-label': `Forme sauvage : ${x.fiche.forme_sauvage.nom}` }, icone('griffe', 'bn-icone--s')),
        `${x.fiche.forme_sauvage.nom} : CA ${x.fiche.forme_sauvage.ca}. Il garde ses PV, avec ses PV temporaires.`, { titre: 'Forme sauvage', ton: 'ultra' }) : null;
      return [...etatsDe(x.fiche).map(e => {
        const ic = iconeEtat(e, 'bn-etat--s cm-combat__etat');
        const n = e.niveau;
        const ouvrirCe = ev => ouvrirMenu(ev.currentTarget, [
          [[icone('livre'), h('span', {}, 'Ses effets')], null, () => voirEffets(e, ic)],
          ...(e.id === EPUISEMENT ? [
            n < NIVEAU_MAX ? [[icone('lu-plus'), h('span', {}, `Niveau ${n + 1}`)], coutEpuisement(n + 1), () => poserSur(x, e.id, n + 1)] : null,
            n > 1 ? [[icone('lu-minus'), h('span', {}, `Niveau ${n - 1}`)], coutEpuisement(n - 1), () => poserSur(x, e.id, n - 1)] : null,
          ].filter(Boolean) : []),
          [[icone('lu-x'), h('span', {}, `Retirer ${e.id === EPUISEMENT ? 'l\'Épuisement' : nomEtat(e)}`)], null, () => retirerDe(x, e.id)],
        ], `${nomEtat(e)} de ${x.nom}`, { classe: 'cm-menu-etats' });
        Object.assign(ic, { tabIndex: 0, onclick: ouvrirCe, onkeydown: ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); ouvrirCe(ev); } } });
        ic.setAttribute('role', 'button');
        ic.setAttribute('aria-label', nomEtat(e));
        return infobulle(ic, [n ? coutEpuisement(n) + '.' : null, 'Un clic : ses effets, le retirer.'].filter(Boolean).join(' '), { titre: nomEtat(e) });
      }), enc, forme].filter(Boolean);
    }
    function voirEffets(e, depuis) {
      flottant('combat:etat:' + e.id, {
        surtitre: 'État', titre: e.nom, depuis, largeur: 440,
        contenu: h('article', { class: 'cm-pile cm-etat-fiche' },
          h('div', { class: 'cm-etat-fiche__tete' }, iconeEtat({ ...e, niveau: null }, 'bn-etat--l'), e.niveau ? h('p', { class: 'ui' }, `Niveau ${e.niveau} : ${coutEpuisement(e.niveau)}.`) : null),
          effetsEtat(e),
          h('p', { class: 'ui-s cm-sourdine' }, 'Glossaire des règles : ',
            h('a', { class: 'bn-lien', href: `sources/FR_SRD_CC_v5.2.1.pdf#page=${e.page}`, target: '_blank', rel: 'noopener' }, `DRS 5.2.1, p. ${e.page}`))),
      });
    }
    const caDe = ca => (ca != null ? h('span', { class: 'bn-init__ca', title: 'Classe d\'armure' }, icone('bouclier'), ca) : h('span'));

    // Fiche d'un héros ou d'un compagnon dans le widget Personnages (monté, même dans l'autre mode : c'est une fenêtre).
    function voirFiche(x) {
      const ev = new CustomEvent('cm:voir-personnage', { detail: { id: x.perso, ouvert: false } });
      document.dispatchEvent(ev);
      if (!ev.detail.ouvert) annoncer({ cle: 'personnages-absent', titre: 'Widget Personnages absent', icone: 'lu-user', couleur: 'brume', texte: `Ajoutez le widget Personnages au tableau pour ouvrir la fiche ${deNom(x.nom)}.` });
    }

    // Un héros à 0 PV est à terre : la ligne passe au rouge, ses jets contre la mort à la place de sa CA (en jaune, stabilisé).
    // Trois échecs : il est mort, le repère « Mort » à la place de la CA et des PV, et il ne joue plus.
    // suite : la ligne d'un compagnon, sous celle de son maître (même bloc, même tour, pas de champ d'initiative) ;
    // avecSuite : la ligne d'un héros suivie de celle de son compagnon.
    function ligneHeros(x, courant, enCombat, { suite = false, avecSuite = false } = {}) {
      const f = x.fiche;
      const pj = x.type === 'pj';
      const tombe = pj && aTerre(f), mort = pj && estMort(f);
      const meta = pj ? [...(f.classes || []).map(k => `${k.nom} ${k.niveau}`)].join(' / ') : `${f.groupe || 'compagnon'} de ${x.maitre}`;
      const li = h('li', { class: 'bn-init__ligne' + (mort ? ' est-decede' : tombe ? ' est-inconscient' : '') + (suite ? ' cm-combat__suite' : avecSuite ? ' cm-combat__avec-suite' : '')
        + (enCombat && choisie === x.cle ? ' est-choisie' : ''), 'data-camp': pj ? 'pj' : 'allie', 'data-cle': x.cle, 'aria-current': courant ? 'true' : null },
        suite ? infobulle(h('span', { class: 'bn-init__score cm-combat__lien', tabindex: '0', 'aria-label': `Agit au tour de ${x.maitre}` }, icone('lu-corner-left-up')),
          `Initiative de ${x.maitre} : il agit à son tour (règles des compagnons).`, { titre: x.nom })
          : cellInitiative(x),
        portraitCombattant(x.image, x.nom, false, mort ? {} : { surClic: menuPoser(x), titre: `Poser un état sur ${x.nom}`, ou: pj ? 'sur sa fiche D&D Beyond' : 'dans le gestionnaire (D&D Beyond n\'en pose pas sur les créatures)' }),
        h('span', { class: 'bn-init__qui' },
          x.perso ? h('button', { type: 'button', class: 'bn-init__nom cm-combat__nom', title: 'Ouvrir sa fiche', onclick: () => voirFiche(x) }, x.nom)
            : h('span', { class: 'bn-init__nom' }, x.nom),
          h('span', { class: 'bn-init__meta' }, h('span', { class: 'bn-init__camp' }, CAMPS[x.type]),
            !pj && f.rampage ? iconeRampage() : null, mort ? null : iconesEtats(x), meta ? `· ${meta}` : null,
            enCombat ? null : bouton('', { icone: 'lu-eye-off', titre: `${x.nom} n'est pas là : hors de l'ordre de combat`, classe: 'bn-btn--s bn-btn--fantome cm-combat__absent', onclick: () => basculerAbsent(x) }))),
        mort ? marqueMort()
          : [tombe ? jetsContreLaMort(f.jets_contre_la_mort) : caDe(f.forme_sauvage?.ca ?? f.ca),
            f.pv ? boutonPv(x.cle, pvMini(x.nom, f.pv, true), 'Dégâts, soins, PV temporaires : écrits sur la fiche D&D Beyond')
              : h('span', { class: 'ui-s cm-sourdine' }, 'fiche non relevée')]);
      return edition === x.cle && f.pv && !mort ? [li, formulairePv(x.nom, (quoi, n) => changerPvHeros(x, quoi, n))] : li;
    }
    // Les PV d'un combattant : un clic ouvre le formulaire dessous (monstre, héros ou compagnon, demande du MJ, 2026-10-20).
    const boutonPv = (cle, contenu, titre) => h('button', {
      type: 'button', class: 'cm-combat__pv', 'aria-expanded': String(edition === cle), title: titre,
      onclick: () => { edition = edition === cle ? null : cle; saisiePv = null; choisie = cle; rendre(); },
    }, contenu);
    // Formulaire des PV : Dégâts (Entrée), Soins, PV temporaires. appliquer(quoi, n) : 'degats', 'soins' ou 'temp'.
    // Au clavier (demande du MJ, 2026-10-31) : les chiffres, puis « - » (dégâts) ou « + » (soins) appliquent aussitôt ; tapés
    // avant les chiffres, ils choisissent ce que fera Entrée (« + 8 Entrée » : des soins). Les chiffres du pavé numérique
    // comptent même verrouillage numérique éteint (event.code), ouvert au clavier ou à la souris.
    function formulairePv(nom, appliquer) {
      let mode = saisiePv?.mode || 'degats';
      const champ = h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '1', inputmode: 'numeric', 'aria-label': `Points pour ${nom}`,
        onkeydown: e => {
          const signe = touchesSigne(e);
          const chiffre = /^Numpad\d$/.test(e.code) && !/^\d$/.test(e.key) ? e.code.slice(-1) : null;   // pavé, verrouillage numérique éteint
          if (e.key === 'Enter') { e.preventDefault(); appliquer(mode, Number(champ.value)); }
          else if (e.key === 'Escape') { e.preventDefault(); edition = null; saisiePv = null; rendre(); }
          else if (signe) { e.preventDefault(); if (champ.value !== '') appliquer(signe, Number(champ.value)); else choisir(signe); }
          else if (chiffre) { e.preventDefault(); champ.value += chiffre; }
          else if (['e', 'E', '.', ','].includes(e.key)) e.preventDefault();   // un champ nombre les accepte : pas des points de vie
        } });
      champ.value = saisiePv?.texte || '';   // le curseur au bout : le chiffre suivant s'ajoute
      saisiePv = null;
      setTimeout(() => champ.focus(), 0);
      const degats = bouton('Dégâts', { classe: 'bn-btn--s', icone: 'epee', onclick: () => appliquer('degats', Number(champ.value)) });
      const soins = bouton('Soins', { classe: 'bn-btn--s', icone: 'coeur', onclick: () => appliquer('soins', Number(champ.value)) });
      const aide = h('span', { class: 'ui-s cm-sourdine' });
      // Le bouton de ce que fera Entrée est le bouton principal.
      function choisir(m) {
        mode = m;
        degats.classList.toggle('bn-btn--primaire', m === 'degats');
        soins.classList.toggle('bn-btn--primaire', m === 'soins');
        aide.textContent = `Entrée : ${m === 'soins' ? 'soins' : 'dégâts'} ; « − » dégâts, « + » soins, Échap : annuler. Les dégâts entament d'abord les PV temporaires.`;
      }
      choisir(mode);
      return h('li', { class: 'cm-combat__edition' },
        champ, degats, soins,
        bouton('PV temp.', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-plus', onclick: () => appliquer('temp', Number(champ.value)) }),
        aide);
    }

    // Rôle d'un monstre (Flee, Mortals!), après son FP : son conseil de jeu au survol ; un sbire ouvre les règles des sbires.
    function roleMonstre(role) {
      const r = role && rolesActifs() && ROLES[role];
      if (!r) return null;
      if (role === 'sbire') return [' · ', h('button', { type: 'button', class: 'cm-lien-bouton cm-combat__role', title: `${r.conseil} Un clic : les règles des sbires en combat.`, onclick: e => ouvrirAideSbires(e.currentTarget) }, r.nom)];
      return [' · ', infobulle(h('span', { class: 'cm-combat__role', tabindex: '0' }, r.nom), r.conseil, { titre: `${r.nom} (${r.en})` })];
    }

    // Rappel de la difficulté (Flee, Mortals!) : le badge, sans les points (demande du MJ, 2026-10-23), qui ouvre le détail
    // (points, budget, alertes, journée d'aventure), l'aide des règles, et celle des sbires s'il y en a.
    function ligneDifficulte(vue, tous) {
      const absents = new Set(tous.filter(x => x.absent).map(x => x.cle));
      const ev = R.difficulteDe(vue, { absents, fiches: beyond });
      if (!ev?.niveau) { flottantOuvert('combat:difficulte')?.fermer(); return null; }   // option éteinte, ou plus de monstre
      const contenuDetail = () => [vueDifficulte(ev), R.vueJournee(vue, ev)];   // le compte des compagnons : fenêtre Campagne seule
      const ouvrirDetail = e => flottant('combat:difficulte', { surtitre: 'Flee, Mortals!', titre: `Difficulté : ${vue.nom}`, largeur: 480, depuis: e.currentTarget, contenu: contenuDetail() });
      // Le détail et l'aide ouverts suivent le groupe du moment (case « Compter les compagnons », héros absents).
      flottantOuvert('combat:difficulte')?.maj(contenuDetail());
      majAide(ev);
      const sbires = rolesActifs() && vue.groupes.some(g => g.role === 'sbire');
      return h('div', { class: 'cm-combat__difficulte' },
        h('button', { type: 'button', class: 'cm-combat__badge', title: 'Le détail : points, budget de FP, plafond, alertes, journée d\'aventure', onclick: ouvrirDetail }, badgeDifficulte(ev, { court: true })),
        ev.alertes.some(a => a.ton === 'sang') ? infobulle(h('span', { class: 'cm-combat__alerte', tabindex: '0' }, icone('lu-triangle-alert', 'bn-icone--s')), ev.alertes.filter(a => a.ton === 'sang').map(a => a.texte).join(' '), { titre: 'Attention', ton: 'sang' }) : null,
        sbires ? bouton('Sbires', { classe: 'bn-btn--s bn-btn--fantome', icone: 'crane', titre: 'Les règles des sbires en combat : excès de dégâts, attaques de groupe', onclick: e => ouvrirAideSbires(e.currentTarget) }) : null,
        bouton('', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-circle-help', titre: 'Les règles de Flee, Mortals! : budget, plafond, sbires, solo, rôles', onclick: e => ouvrirAide(ev, e.currentTarget) }));
    }

    function ligneMonstre(x, courant) {
      const m = x.m;
      const g = R.vueDe(combat().rencontre)?.groupes.find(y => y.cle === m.groupe);
      const li = h('li', { class: 'bn-init__ligne' + (m.pv <= 0 ? ' est-mort' : '') + (combat().phase === 'combat' && choisie === x.cle ? ' est-choisie' : ''),
        'data-camp': 'ennemi', 'data-cle': x.cle, 'aria-current': courant ? 'true' : null },
        cellInitiative(x),
        portraitCombattant(g?.avatar, m.nom, true, m.pv > 0 ? { surClic: menuPoser(x), titre: `Poser un état sur ${m.nom}`, ou: 'dans le combat' } : {}),
        h('span', { class: 'bn-init__qui' },
          h('button', { type: 'button', class: 'bn-init__nom cm-combat__nom', title: 'Ouvrir la fiche D&D Beyond', onclick: () => R.ouvrirMonstre(m.monstre) }, m.nom),
          h('span', { class: 'bn-init__meta' }, h('span', { class: 'bn-init__camp' }, CAMPS.monstre), m.pv > 0 ? iconesEtats(x) : null,
            g && g.nom !== g.nom_beyond ? `· ${g.nom_beyond}` : null, g?.fp != null ? `· ${libellePuissance({ valeur: g.fp })}` : null, roleMonstre(g?.role))),
        caDe(m.ca || null),
        boutonPv(m.cle, pvMini(m.nom, { actuels: m.pv, max: m.pv_max, temporaires: m.pv_temp }, false), 'Dégâts, soins, PV temporaires'));
      return edition === m.cle ? [li, formulairePv(m.nom, (quoi, n) => changerPv(m, quoi, n))] : li;
    }

    function vueCombat() {
      const c = combat();
      const vue = c && R.vueDe(c.rencontre);
      if (!vue) return vueSansCombat();
      const tous = combattants();
      const l = trier(tous.filter(x => !x.absent && x.type !== 'compagnon'));   // l'ordre des tours
      // Absents : un héros, ou un compagnon dont le maître est là (celui d'un absent part avec lui).
      const absents = tous.filter(x => x.absent && !(x.maitreCle && tous.find(y => y.cle === x.maitreCle)?.absent));
      const enCombat = c.phase === 'combat';
      const courant = enCombat ? l.find(x => x.cle === tourDe(c.tour)) : null;
      const manquantes = l.filter(x => x.type === 'monstre' && !Number.isInteger(x.init)).length;
      // Le combat ne démarre que quand chacun a son initiative (demande du MJ, 2026-10-20) ; les morts et les absents ne comptent pas.
      const sansInit = l.filter(x => !horsCombat(x) && !Number.isInteger(x.init));
      const demarrer = bouton('Démarrer', { classe: 'bn-btn--s bn-btn--primaire cm-combat__demarrer', icone: 'epee', disabled: !l.length || sansInit.length > 0, onclick: demarrerCombat });
      const boutonDemarrer = sansInit.length
        ? infobulle(h('span', { class: 'cm-combat__attente', tabindex: '0' }, demarrer), `Il manque l'initiative de ${sansInit.map(x => x.nom).join(', ')}.`, { titre: 'Démarrer le combat', ton: 'sang' })
        : (demarrer.title = 'Démarrer le combat : round 1, au tour du premier', demarrer);
      // Libellés courts, sur une ligne (demande du MJ, 2026-10-20) : le détail de chaque bouton au survol.
      const boutonInit = manquantes
        ? bouton('Initiative', { classe: 'bn-btn--s bn-btn--magie', icone: 'd20', titre: 'Lancer l\'initiative : un d20 par type de monstre ; les héros donnent la leur, leurs compagnons agissent avec eux', onclick: e => lancerInitiatives(false, e.currentTarget) })
        : bouton('Initiative', { classe: 'bn-btn--s cm-combat__relancer', icone: 'd20', titre: 'Relancer l\'initiative des monstres', onclick: e => lancerInitiatives(true, e.currentTarget) });
      const terminer = bouton('Terminer', { classe: 'bn-btn--s', icone: 'lu-check', titre: 'Terminer la rencontre, avec une remarque', onclick: () => R.demanderFin(vue.id) });
      const actions = enCombat
        ? [bouton('', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Tour précédent', disabled: c.round <= 1 && l[0]?.cle === tourDe(c.tour), onclick: tourPrecedent }),
          bouton('Tour suivant', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-arrow-right', onclick: tourSuivant }),
          terminer]
        : c.phase === 'prete'
          ? [boutonInit, bouton('Démarrer', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-play', titre: 'Démarrer la rencontre (notée en cours, avec l\'heure)', onclick: () => R.demarrer(vue.id) })]
          : [boutonInit, boutonDemarrer, terminer];
      const etape = enCombat ? `Round ${c.round}${courant ? ` · tour ${l.indexOf(courant) + 1}/${l.length} · ${courant.nom}` : ''}`
        : c.phase === 'prete' ? 'Prête' : 'En cours · combat pas commencé';
      // En-tête resserré : l'étape, le nom (qui ouvre la préparation) et le lieu à gauche ; modifier et annuler en haut à droite ;
      // les actions du moment dessous.
      return [
        h('div', { class: 'bn-carte cm-combat__tete' },
          h('div', { class: 'cm-combat__haut' },
            h('div', { class: 'cm-combat__titres' },
              h('span', { class: 'surtitre' }, etape),
              h('button', { type: 'button', class: 'cm-combat__titre', title: 'Ouvrir la préparation : monstres, nombres, noms', onclick: () => R.ouvrir(vue.id) }, vue.nom),
              h('span', { class: 'cm-combat__ou' }, icone('epingle', 'bn-icone--s'), R.ouDe(vue))),
            h('div', { class: 'bn-groupe cm-combat__outils' },
              contributions('combatEntete', { rencontre: vue }),   // le point d'état d'un plugin (The Table)
              bouton('', { icone: 'lu-pencil', titre: 'Préparation : monstres, nombres, noms (renforts…)', classe: 'bn-btn--s bn-btn--fantome', onclick: () => R.ouvrir(vue.id) }),
              bouton('', { icone: 'lu-refresh-cw', titre: 'Remettre à zéro : l\'initiative, et au choix les PV et les états des monstres', classe: 'bn-btn--s bn-btn--fantome', onclick: remettreAZero }),
              bouton('', { icone: 'lu-x', titre: 'Annuler : elle n\'a pas eu lieu (tirée au hasard : retirée du journal des rencontres et supprimée ; sinon, de nouveau à jouer)', classe: 'bn-btn--s bn-btn--fantome', onclick: annuler }))),
          h('div', { class: 'bn-groupe cm-combat__actions' }, actions),
          ligneDifficulte(vue, tous)),
        R.blocContexte(vue, { profils: true }),
        section('Ordre de combat', 'sablier', h('ol', { class: 'bn-init bn-init--portraits cm-combat__ordre' },
          l.map(x => (x.type === 'monstre' ? ligneMonstre(x, x === courant) : [
            ligneHeros(x, x === courant, enCombat, { avecSuite: compagnonsDe(tous, x.cle).length > 0 }),
            ...compagnonsDe(tous, x.cle).map(y => ligneHeros(y, x === courant, enCombat, { suite: true })),   // au même tour
          ])))),
        absents.length ? h('p', { class: 'ui-s cm-sourdine cm-combat__absents' }, 'Pas dans l\'ordre : ', absents.map((x, i) => [i ? ', ' : '',
          h('button', { type: 'button', class: 'cm-lien-bouton', title: `Remettre ${x.nom} dans l'ordre de combat`, onclick: () => basculerAbsent(x) }, x.nom)])) : null,
      ];
    }

    function vueSansCombat() {
      const preparees = R.preparees();
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'bn-carte cm-combat__vide' },
          h('p', { class: 'titre-m' }, 'Aucune rencontre lancée'),
          h('p', { class: 'ui-s cm-sourdine' }, '« Lancer » une rencontre : onglet Hors tables de Rencontres, un jalon du Déroulé, Ici, ou un tirage.'),
          h('div', { class: 'bn-groupe' }, R.boutonNouvelle({}, { classe: 'bn-btn--s' }))),
        preparees.length ? section('Préparées, pas encore jouées', 'lu-swords', h('div', { class: 'cm-rmj-liste' }, preparees.map(vue => R.ligne(vue)))) : null);
    }

    // Historique : les rencontres jouées ou commencées, et celles des tirages, dans une fenêtre ouverte par le lien du bas.
    function vueHistorique() {
      const l = R.historique();
      if (!l.length) return h('p', { class: 'ui cm-sourdine' }, 'Aucune rencontre jouée pour l\'instant.');
      return h('div', { class: 'cm-rmj-liste' }, l.map(vue => R.ligne(vue, { historique: true })));
    }
    const ouvrirHistorique = () => flottant('combat:historique', { surtitre: 'Combat', titre: 'Historique des rencontres', largeur: 520, contenu: vueHistorique() });
    function lienHistorique() {
      const n = R.historique().length;
      return h('div', { class: 'cm-combat__pied' }, lienFlottant(h('button', { type: 'button', class: 'cm-lien-bouton cm-ouvre', onclick: ouvrirHistorique },
        icone('livre', 'bn-icone--s'), h('span', { class: 'cm-ouvre__nom' }, `Historique des rencontres${n ? ` (${n})` : ''}`)), 'combat:historique'));
    }

    // L'état du combat pour les plugins (événement combat:etat, app/evenements.js) : la rencontre, la phase, le round, le
    // tour, et l'ordre des tours (héros et monstres présents, un compagnon passe avec son maître). Émis à chaque rendu où il
    // a changé ; null quand il n'y a plus de combat.
    function instantane() {
      const c = combat();
      const vue = c && R.vueDe(c.rencontre);
      if (!vue) return null;
      const tous = combattants();
      return {
        rencontre: vue.id, nom: vue.nom, lieu: R.ouDe(vue) || null, phase: c.phase, round: c.round || 0, tour: c.phase === 'combat' ? tourDe(c.tour) : null,
        ordre: trier(tous.filter(x => !x.absent && x.type !== 'compagnon')).map(x => ({
          cle: x.cle, type: x.type, nom: x.nom, perso: x.perso || null, fiche: x.type === 'pj' ? String(x.fiche.id ?? x.cle.slice(3)) : null,
          monstre: x.type === 'monstre' ? x.m.monstre : null, init: x.init,
          pv: x.type === 'monstre' ? { actuels: x.m.pv, max: x.m.pv_max } : x.fiche.pv ? { actuels: x.fiche.pv.actuels, max: x.fiche.pv.max } : null,
          hors_combat: horsCombat(x),
        })),
      };
    }
    let dernierInstantane = null;
    function signalerEtat() {
      const inst = instantane(), json = JSON.stringify(inst);
      if (json === dernierInstantane) return;
      dernierInstantane = json;
      emettre('combat:etat', { combat: inst });
    }

    let tourAffiche = null;
    function rendre() {
      signalerEtat();
      const haut = corps.scrollTop;
      const saisie = focusApres || (corps.contains(document.activeElement) ? document.activeElement.dataset?.cle : null);
      focusApres = null;
      const c = combat();
      const tour = c?.phase === 'combat' ? `${c.rencontre}:${c.round}:${c.tour}` : null;
      if (tour !== tourAffiche) choisie = tour ? tourDe(c.tour) : null;   // nouveau tour : la ligne choisie est celle du tour
      corps.replaceChildren(h('div', { class: 'cm-pile cm-combat' }, vueCombat(), lienHistorique()));
      corps.scrollTop = haut;
      if (saisie) { const champ = corps.querySelector(`.cm-combat__init[data-cle="${CSS.escape(saisie)}"]`); champ?.focus(); if (champ && document.activeElement === champ) champ.select(); }
      widget()?.classList.toggle('bn-panel--actif', c?.phase === 'combat');   // combat en cours : le widget luit (composant Initiative)
      // Nouveau tour : amener le combattant actif en vue, sans faire défiler la page.
      const actif = corps.querySelector('.bn-init__ligne[aria-current="true"]');
      if (tour !== tourAffiche && actif) {
        const cr = corps.getBoundingClientRect(), lr = actif.getBoundingClientRect();
        if (lr.top < cr.top || lr.bottom > cr.bottom) corps.scrollTop += lr.top - cr.top - cr.height / 3;
      }
      tourAffiche = tour;
    }

    // Changements faits ailleurs (préparation, rencontre lancée ou terminée) : le widget et la fenêtre de l'historique.
    function surChangement() {
      flottantOuvert('combat:historique')?.maj(vueHistorique());
      if (!(corps.contains(document.activeElement) && document.activeElement.matches('input'))) rendre();
    }
    R.s.abonner(surChangement);
    rendre();

    // ───── Raccourcis clavier (demande du MJ, 2026-10-31) ─────
    // Seulement pendant le combat et Combat dans le mode affiché ; jamais quand le focus est dans un champ, une fenêtre, un
    // dialogue ou un menu, qui ont leurs touches (une touche déjà prise par un élément, la poignée d'un widget, est laissée) ;
    // la fenêtre de leur aide exceptée, pour les essayer en la gardant ouverte.
    // Les chiffres du pavé numérique se lisent à leur touche (event.code) : verrouillage numérique allumé ou éteint.
    const lignes = () => [...corps.querySelectorAll('.cm-combat__ordre .bn-init__ligne[data-cle]')];
    const choisi = () => combattants().find(y => y.cle === choisie) || null;
    function choisir(cle) {
      choisie = cle;
      const el = lignes().find(li => li.dataset.cle === cle);
      for (const li of lignes()) li.classList.toggle('est-choisie', li === el);
      if (!el) return;
      const cr = corps.getBoundingClientRect(), lr = el.getBoundingClientRect();   // en vue, sans faire défiler la page
      if (lr.top < cr.top) corps.scrollTop += lr.top - cr.top - 8;
      else if (lr.bottom > cr.bottom) corps.scrollTop += lr.bottom - cr.bottom + 8;
    }
    function bouger(sens) {
      const l = lignes().map(li => li.dataset.cle);
      let i = l.indexOf(choisie);
      if (i < 0) i = l.indexOf(tourDe(combat().tour));
      if (l.length) choisir(l[Math.max(0, Math.min(l.length - 1, i + sens))]);
    }
    // Le formulaire des PV de la ligne choisie, avec le premier chiffre ou le signe tapé.
    function saisirPv(chiffre, signe) {
      const x = choisi();
      if (!x || (x.type === 'monstre' ? false : !x.fiche.pv || (x.type === 'pj' && estMort(x.fiche)))) return;
      edition = x.cle;
      saisiePv = { mode: signe || 'degats', texte: chiffre || '' };
      rendre();
      corps.querySelector('.cm-combat__edition input')?.focus();   // tout de suite : la touche suivante y va
    }
    function ficheChoisie() {
      const x = choisi();
      if (x?.type === 'monstre') R.ouvrirMonstre(x.m.monstre);
      else if (x?.perso) voirFiche(x);
    }
    function etatChoisi() {
      const x = choisi();
      const portrait = lignes().find(li => li.dataset.cle === choisie)?.querySelector('.cm-combat__portrait-etats');
      if (x && portrait) menuPoser(x)({ currentTarget: portrait });
    }
    function surTouche(e) {
      if (!corps.isConnected) { document.removeEventListener('keydown', surTouche); return; }   // widget retiré du tableau
      const aide = flottantOuvert('combat:clavier')?.el;
      if (aide && !e.repeat) allumerTouche(aide, e);
      if (e.defaultPrevented || e.ctrlKey || e.altKey || e.metaKey || e.isComposing) return;
      if (!corps.closest('.cm-tableau .bn-widget[data-type="combat"]') || combat()?.phase !== 'combat') return;
      const actif = document.activeElement;
      if (actif?.closest?.('input, textarea, select, [contenteditable="true"], dialog:not(.cm-clavier-fenetre), [popover]') || document.querySelector('dialog:modal, .bn-menu:popover-open')) return;
      const pave = e.code.startsWith('Numpad');
      const chiffre = /^Numpad\d$/.test(e.code) ? e.code.slice(-1) : /^\d$/.test(e.key) ? e.key : null;
      const signe = touchesSigne(e);
      const touche = e.key.toLowerCase();
      if (chiffre || signe) saisirPv(chiffre, signe);
      else if (e.key === '*' || e.key === 'PageDown') tourSuivant();
      else if (e.key === '/' || e.key === 'PageUp') tourPrecedent();
      else if (!pave && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) bouger(e.key === 'ArrowDown' ? 1 : -1);
      else if (!pave && e.key === 'Home') choisir(tourDe(combat().tour));
      else if (e.key === 'Escape') { choisir(tourDe(combat().tour)); return; }   // Échap reste aux autres (les dés en 3D)
      // Entrée sur un bouton (ou un portrait) qui a le focus : le sien.
      else if (touche === 'f' || (e.key === 'Enter' && !(actif && actif !== document.body && actif.matches('button, a[href], [role="button"], [tabindex]')))) ficheChoisie();
      else if (touche === 'e') etatChoisi();
      else return;
      e.preventDefault();
    }
    document.addEventListener('keydown', surTouche);
    // L'aide, par l'icône clavier de l'en-tête (widget déplié).
    const ouvrirClavier = e => flottant('combat:clavier', { surtitre: 'Combat', titre: 'Raccourcis clavier', largeur: 520, depuis: e.currentTarget, contenu: vueClavier() })
      .el.classList.add('cm-clavier-fenetre');
    actions.prepend(infobulle(bouton('', { icone: 'lu-keyboard', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', 'aria-label': 'Raccourcis clavier', onclick: ouvrirClavier }),
      'Le pavé numérique et les touches du combat, avec leurs actions.', { titre: 'Raccourcis clavier' }));

    // Relecture des fiches des héros toutes les 5 s (PV, CA, états), pas pendant une saisie.
    const minuterie = setInterval(async () => {
      if (!corps.isConnected) { clearInterval(minuterie); return; }   // widget retiré du tableau
      if (!visible() || edition || ecritures || corps.contains(document.activeElement) && document.activeElement.matches('input')) return;
      const neuf = await lireBeyond();
      if (neuf.maj === beyond.maj) return;
      // Un relevé qui ne change rien aux fiches (toutes les 30 s) ne redessine pas (retour du MJ, 2026-11-03 : ça clignotait).
      const pareil = empreinteBeyond(neuf) === empreinteBeyond(beyond);
      beyond = neuf;
      if (!pareil && combat()) rendre();
    }, RELIRE_MS);
    return {};
  },
};
