// Widget Personnages : les personnages joueurs, leurs compagnons et le groupe.
// Une carte par personnage (familier à sa droite) ; un clic ouvre sa fiche dans une fenêtre flottante, déplaçable,
// qui ne bouge pas le tableau de bord. « Le groupe » ouvre le récapitulatif (vie, ressources, objets, argent).
// Secrets et pistes (MJ seulement) : affichés sans masquage, le gestionnaire est l'outil du MJ seul (décision du MJ,
// formats/personnages.md). Les pistes d'un personnage viennent du déroulé (deroule-campagne.json, pistes avec `personnage`) ;
// une étape de quête (secrets[].etapes) renvoie à un jalon ou à une piste, avec son statut et un lien vers le Déroulé.
// Données : data/personnages.json (formats/personnages.md), data/deroule-campagne.json, wiki/wiki.json (portraits, texte
// intégral), etat/beyond.json (feuilles D&D Beyond, écrit toutes les 20 s par l'extension Chrome : voir extensions/mj/LISEZMOI.md),
// etat/deroule.json (statuts).

import { h, icone, bouton, avecEcranJoueurs, badge, alerte, alerteRepliable, bascule, section, heure, distance, infobulle, jauge, flottant, flottantOuvert, pastilleDD, jetsContreLaMort, marqueMort, boutonMenu, ouvrirMenu, onglets, deNom as de } from '../ui.js';
import { chargerLieux, nomLieu } from '../lieux.js';
import { chargerWiki, portraitDuPersonnage } from '../wiki.js';
import { CHAMPS_LORE, etatLore, loreDe, nettoyerLore, ouvrirEditionLore, ouvrirEditionSecrets } from '../lore.js';
import { lireBeyond, empreinteBeyond, lireDetails, demanderDetails, ficheDe, compagnonsAvecFiches, originesEnMarkdown, LIBELLES_NOTES, ORIGINE_BEYOND, aTerre, estMort } from '../beyond.js';
import { derouleSurLeTableau, voirJalon, voirPiste, ICONE_PISTE, LIBELLES_STATUT, etatDeroule, statutDe } from '../trame.js';
import { annoncer } from '../horloge.js';
import { contenuReglesCompagnons } from '../regles-compagnons.js';
import { ouvrirChoixJet, blocCompetences } from '../jets-heros.js';
import { blocCompagnon } from '../fiche-compagnon.js';
import { configBeyond } from '../rencontres-mj.js';
import { fichesBabioles, babioleDeLObjet, intituleBabiole } from '../babioles.js';
import { wikiActif } from '../campagne.js';
import { chargerIconesEtats, etatsDe, etatDe, iconeEtat, nomEtat, effetsEtat, coutEpuisement, choixEtats, EPUISEMENT, NIVEAU_MAX, poserEtat, retirerEtat, changerInspiration, etatsCreatures, avecEtats, poserEtatCreature, retirerEtatCreature, iconeRampage, encombrementDe, iconeEncombrement, tuileEncombrement, ouvrirEncombrement, resumeEncombrement, ENCOMBREMENTS } from '../etats.js';

const signe = n => (n >= 0 ? '+' : '−') + Math.abs(n);
const CARAC = [['for', 'For'], ['dex', 'Dex'], ['con', 'Con'], ['int', 'Int'], ['sag', 'Sag'], ['cha', 'Cha']];
const VIEUX_S = 120;   // au-delà, le relevé est signalé comme ancien (l'extension ne tourne plus ?)
const VERSION_EXTENSION = '1.18.0';   // extensions/mj/manifest.json : en dessous, le widget demande de la recharger
// « 1.9.1 » avant « 1.10.0 » : comparaison nombre par nombre, pas en texte.
const plusAncienne = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0); return false; };

// Jauge de PV (design-system, BarrePV). Un personnage à 0 PV est inconscient, pas mort.
function barrePV(nom, pv, mini) {
  const { actuels, max, temporaires } = pv;
  const part = max ? actuels / max : 0;
  const etat = actuels <= 0 ? 'mort' : part < 0.2 ? 'critique' : part <= 0.5 ? 'ensanglante' : null;
  const mot = { mort: 'Inconscient', critique: 'Critique', ensanglante: 'Ensanglanté' }[etat];
  const total = Math.max(max, actuels + temporaires) || 1;
  return h('div', {
    class: 'bn-pv' + (mini ? ' bn-pv--mini' : ''), 'data-etat': etat,
    style: `--pv: ${(actuels / total) * 100}%; --pv-temp: ${(temporaires / total) * 100}%`,
  },
    h('div', { class: 'bn-pv__tete' },
      h('span', { class: 'etiquette' }, 'PV', mot ? h('span', { class: 'bn-pv__etat' }, ' · ' + mot) : null),
      h('span', { class: 'bn-pv__val' }, h('b', {}, actuels), '/' + max, temporaires ? h('span', { class: 'bn-pv__temp' }, ' +' + temporaires) : null)),
    h('div', { class: 'bn-pv__barre', role: 'meter', 'aria-label': `Points de vie de ${nom}`, 'aria-valuemin': '0', 'aria-valuemax': String(max), 'aria-valuenow': String(actuels) },
      h('span', { class: 'bn-pv__plein' }), temporaires ? h('span', { class: 'bn-pv__tampon' }) : null));
}

// Valeurs de table, chacune avec sa mini-icône et son nom complet au survol.
// Une distance a son infobulle (mètres, cases) : elle passe sur tout le chip, le libellé en titre.
function chip(ic, libelle, valeur, classe = '') {
  const el = h('span', { class: ('cm-chip ' + classe).trim() }, icone(ic), h('span', { class: 'cm-invisible' }, libelle + ' '), valeur);
  if (valeur?.dataset?.bulle) {
    infobulle(el, valeur.dataset.bulle, { titre: libelle });
    delete valeur.dataset.bulle;
  } else el.title = libelle;
  return el;
}
const ddSorts = f => f.sorts.map(s => s.dd).filter((v, i, l) => l.indexOf(v) === i).join('/');
// Vitesse réduite par l'encombrement (règle variante) : en orange (encombré) ou en rose (lourdement), le détail au survol.
function vitesseEncombree(el, f) {
  const enc = encombrementDe(f);
  if (!enc) return el;
  el.classList.add(`cm-vitesse--${enc.etat}`);
  return infobulle(el, `${ENCOMBREMENTS[enc.etat].nom} : ${ENCOMBREMENTS[enc.etat].effet.split(' ;')[0].replace(/\.$/, '')}.`, { titre: 'Vitesse', ton: enc.etat === 'lourd' ? 'sang' : 'cierge' });
}
// Un druide en forme sauvage (`forme_sauvage` du relevé, noté par l'extension du joueur) : la CA et la vitesse de la forme.
const caDe = f => f?.forme_sauvage?.ca ?? f?.ca;
const chipVitesse = f => (f.forme_sauvage?.vitesses?.marche != null ? chip('lu-footprints', 'Vitesse (forme sauvage)', distance(f.forme_sauvage.vitesses.marche))
  : vitesseEncombree(chip('lu-footprints', 'Vitesse', distance(f.vitesses.marche)), f));
const badgeForme = f => (f?.forme_sauvage ? infobulle(h('span', { class: 'bn-badge bn-badge--ultra cm-perso-forme', tabindex: '0' }, icone('griffe', 'bn-icone--s'), f.forme_sauvage.nom),
  `Noté sur sa fiche par son joueur. CA ${f.forme_sauvage.ca} ; il garde ses PV, avec ses PV temporaires.`, { titre: 'Forme sauvage', ton: 'ultra' }) : null);
function chips(f) {
  return h('div', { class: 'cm-chips' },
    caDe(f) != null ? chip('bouclier', 'Classe d\'armure', caDe(f)) : null,
    chip('oeil', 'Perception passive', f.passives.perception),
    chip('lu-brain', 'Intuition passive', f.passives.intuition),
    f.sorts?.length ? pastilleDD(ddSorts(f), 'DD des sorts (jet de sauvegarde des cibles)') : null,
    f.vitesses?.marche != null ? chipVitesse(f) : null);   // 0 ft s'affiche (encombré et épuisé)
}

// Un personnage à 0 PV est à terre (aTerre de app/beyond.js) : ses jets contre la mort (composant JetsMort) remplacent CA
// et valeurs sur sa carte. Trois échecs (estMort) : il est mort, le repère « Mort » à la place des PV, des valeurs, des
// pouvoirs et des états. Ses états (app/etats.js) : en icônes sur le portrait de sa carte, en badges dans sa fiche.

// Emplacements de sorts (et magie de pacte), puis capacités à usage limité : un losange par charge, plein quand elle a servi.
const restant = u => Math.max(0, u.max - u.utilises);
function ressources(f, { carte = false } = {}) {
  const lignes = [
    ...(f.emplacements || []).map(e => [`Niv. ${e.niveau}`, `Emplacements de niveau ${e.niveau}`, e, 'ultra']),
    ...(f.pacte ? [[`Pacte niv. ${f.pacte.niveau}`, `Magie de pacte, niveau ${f.pacte.niveau}`, f.pacte, 'ultra']] : []),
    ...(f.usages || []).map(u => [u.nom, u.nom + (u.recuperation ? ` (${u.recuperation})` : ''), u, 'cierge']),
  ];
  if (!lignes.length) return null;
  const titre = (long, u) => `${long} : ${restant(u)} disponible(s) sur ${u.max}`;
  // Carte : une ligne par ressource, nom (tronqué) puis jauge ; le détail au survol.
  if (carte) return h('div', { class: 'cm-ressources cm-ressources--carte' }, lignes.map(([court, long, u, c]) => h('div', { class: 'cm-ressource', title: titre(long, u) },
    h('span', { class: 'cm-ressource__nom' }, court), jauge(Math.min(u.utilises, u.max), u.max, long, c))));
  return h('div', { class: 'cm-ressources' }, lignes.map(([court, long, u, c]) => h('div', { class: 'cm-ressource', title: titre(long, u) },
    h('span', { class: 'ui-s cm-ressource__nom' }, court),
    jauge(Math.min(u.utilises, u.max), u.max, long, c),
    u.max > 6 ? null : h('span', { class: 'ui-s cm-sourdine' }, `${restant(u)}/${u.max}`))));   // au-delà de 6, la jauge donne déjà le compte
}

// Férocité d'un compagnon de Flee, Mortals! (tenue par le joueur dans l'extension du compagnon, notée dans la note de la
// créature : `ferocite` et `rampage` du relevé, formats/note-compagnon.md), à la place des sorts et capacités d'un héros.
// Couleur de son état, comme dans l'extension : grise à 0, jaune de 1 à 9, orange à 10 ou plus (le rampage menace : le DD
// du test qui le retient), rose en rampage (le bonus de son attaque de signature). Une barre jusqu'à 10, le seuil.
const SEUIL_RAMPAGE = 10;
function ferocite(cr, { carte = false } = {}) {
  if (cr?.ferocite == null && !cr?.rampage) return null;
  const x = cr.ferocite ?? 0, connue = cr.ferocite != null;
  const etat = cr.rampage ? 'rampage' : x >= SEUIL_RAMPAGE ? 'alerte' : x > 0 ? 'monte' : 'zero';
  // Sur la carte (140 px au plus étroit), le rampage se dit par ses crocs et son bonus ; le mot est dans l'infobulle.
  const suite = etat === 'rampage' ? badge(`${carte ? '' : 'Rampage '}+${Math.floor(x / 2)}`, 'sang', 'crocs')
    : etat === 'alerte' ? infobulle(h('span', { class: 'cm-ferocite__dd', tabindex: '0' }, pastilleDD(5 + x)),
      `Le soigneur peut le retenir : Sagesse (Dressage) DD ${5 + x}, sans action.`, { titre: 'Rampage possible', ton: 'cierge' })
    : null;
  const texte = { rampage: `En rampage : il fonce sur la créature la plus proche et lui porte son attaque de signature, +${Math.floor(x / 2)} dégâts si elle touche ; puis sa férocité retombe à 0.`,
    alerte: `Rampage possible (10 ou plus) : le soigneur peut le retenir, Sagesse (Dressage) DD ${5 + x}, sans action ; sinon il entre en rampage.`,
    monte: 'Elle monte à chaque début de son tour (1d4 + les ennemis à 5 ft) et se dépense en pouvoirs ; à 10 ou plus, le rampage menace.',
    zero: 'Calme. Elle monte à chaque début de son tour (1d4 + les ennemis à 5 ft) ; à 10 ou plus, le rampage menace.' }[etat];
  const barre = h('span', { class: 'cm-ferocite__barre', 'aria-hidden': 'true' }, h('span', { style: `width: ${Math.min(100, x * 100 / SEUIL_RAMPAGE)}%` }));
  const valeur = h('span', { class: 'cm-ferocite__valeur' }, connue ? String(x) : '?');
  if (carte) return h('div', { class: 'cm-ressources cm-ressources--carte' },
    infobulle(h('div', { class: `cm-ferocite cm-ferocite--${etat}`, tabindex: '0', 'aria-label': `Férocité : ${connue ? x : 'inconnue'}` },
      h('span', { class: 'cm-ferocite__ligne' }, icone('griffe', 'bn-icone--s'), h('span', { class: 'cm-ferocite__nom' }, 'Férocité'), valeur, suite), barre),
    texte, { titre: `Férocité : ${connue ? x : '?'}`, ton: { rampage: 'sang', alerte: 'cierge', monte: 'soleil' }[etat] || null }));
  return h('div', { class: `cm-ferocite cm-ferocite--${etat} cm-ferocite--fiche` },
    h('span', { class: 'cm-ferocite__ligne' }, icone('griffe', 'bn-icone--s'), valeur, suite), barre,
    h('p', { class: 'ui-s' }, texte),
    h('p', { class: 'ui-s cm-sourdine' }, 'Tenue par le joueur (extension du compagnon), relevée sur D&D Beyond.'));
}

// Carte : la CA dans un bouclier (contour seul, sans l'arête de l'icône « bouclier »), à droite.
function ecuCA(ca) {
  if (ca == null) return null;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  const trace = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  trace.setAttribute('d', 'M12 2.8l7.5 2.9v5.6c0 4.5-3.1 8-7.5 9.9-4.4-1.9-7.5-5.4-7.5-9.9V5.7z');
  svg.append(trace);
  return h('span', { class: 'cm-ca', title: 'Classe d\'armure' }, svg,
    h('span', { class: 'cm-ca__val' }, h('span', { class: 'cm-invisible' }, 'Classe d\'armure '), ca));
}

// Carte : CA (cartes étroites, sinon dans le bouclier), passives, DD des sorts, puis la vitesse à droite. Sur une ligne et
// plus grandes quand elles tiennent (grand écran, .est-large) ; sinon empilées : icône au-dessus de la valeur, DD dans un
// cadre vertical (.est-empile). Voir ajusterCartes(). À terre : ses jets contre la mort seuls (inconscient, il ne bouge
// plus : pas de vitesse, et le cadre tient sur une carte étroite).
function ligneCarte(f) {
  if (aTerre(f)) return h('div', { class: 'cm-perso-carte__ligne cm-perso-carte__ligne--a-terre' }, jetsContreLaMort(f.jets_contre_la_mort));
  return h('div', { class: 'cm-perso-carte__ligne' },
    h('span', { class: 'cm-chips' },
      caDe(f) != null ? chip('bouclier', 'Classe d\'armure', caDe(f), 'cm-chip--ca') : null,
      chip('oeil', 'Perception passive', f.passives.perception),
      chip('lu-brain', 'Intuition passive', f.passives.intuition),
      // Sans sorts : un DD invisible garde la place, pour que les valeurs s'alignent d'une carte à l'autre.
      f.sorts?.length ? pastilleDD(ddSorts(f), 'DD des sorts (jet de sauvegarde des cibles)')
        : h('span', { class: 'cm-dd-vide', 'aria-hidden': 'true' }, pastilleDD(10))),
    f.vitesses?.marche != null ? chipVitesse(f) : null);   // 0 ft s'affiche (encombré et épuisé)
}

// Affichage des cartes (Basique ou Étendu), propre à chaque mode du tableau (Exploration, Rencontre) : gardé avec sa
// disposition (`reglages.affichage` dans etat/tableau.json). Le réglage d'avant, gardé dans le navigateur, sert de départ.
const CLE_MODE_ANCIEN = 'cm:personnages:mode';
function modeAncien() {
  try { return localStorage.getItem(CLE_MODE_ANCIEN) === 'basique' ? 'basique' : 'etendu'; } catch { return 'etendu'; }
}

function caracteristiques(f, sauvegardes) {
  return h('dl', { class: 'cm-carac' }, CARAC.map(([c, l]) => {
    const x = f.caracteristiques[c];
    return h('div', { class: sauvegardes && x.maitrise_sauvegarde ? 'cm-carac--maitrise' : null, title: sauvegardes ? `Sauvegarde ${signe(x.sauvegarde)}${x.maitrise_sauvegarde ? ' (maîtrisée)' : ''}` : null },
      h('dt', { class: 'etiquette' }, l),
      h('dd', {}, signe(x.mod), h('span', {}, x.valeur,
        sauvegardes ? [' · JS ', signe(x.sauvegarde), x.maitrise_sauvegarde ? icone('lu-check', 'bn-icone--s') : null] : null)));
  }));
}

const PIECES = [['pp', 10], ['po', 1], ['pe', 0.5], ['pa', 0.1], ['pc', 0.01]];
const enPo = a => PIECES.reduce((s, [k, v]) => s + (a?.[k] || 0) * v, 0);
const po = n => n.toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' po';
// Une bourse : chaque sorte de pièce avec sa petite pièce de couleur (platine, or, électrum, argent, cuivre ; le nom au
// survol), puis le total en po s'il y en a de plusieurs sortes (demande du MJ, 2026-10-20).
const NOMS_PIECES = { pp: 'Pièces de platine', po: 'Pièces d\'or', pe: 'Pièces d\'électrum', pa: 'Pièces d\'argent', pc: 'Pièces de cuivre' };
function bourse(a) {
  const l = PIECES.filter(([k]) => a?.[k]);
  if (!l.length) return h('span', { class: 'ui-s cm-sourdine' }, 'Rien');
  return h('span', { class: 'ui cm-bourse' },
    l.map(([k]) => infobulle(h('span', { class: `cm-piece cm-piece--${k}`, tabindex: '0' }, icone('piece'), String(a[k])), NOMS_PIECES[k])),
    l.length > 1 ? h('span', { class: 'cm-sourdine' }, `= ${po(enPo(a))}`) : null);
}

function vitesses(v) {
  const autres = Object.entries(v || {}).filter(([k]) => k !== 'marche');
  return [v?.marche != null ? distance(v.marche) : null, ...autres.flatMap(([k, x]) => [', ', distance(x, `${k} `)])];
}

// Bloc D&D Beyond d'une fiche de personnage. etats : ses états et ses jets contre la mort (etatsFiche() du widget).
// CA, passives, DD des sorts et vitesse sur une ligne (demande du MJ, 2026-10-20) : libellés courts, le nom entier au survol.
function beyondDetail(f, etats) {
  const chiffre = (ic, court, valeur, long) => infobulle(h('div', { class: 'cm-beyond__chiffre', tabindex: '0', 'aria-label': `${long} : ${typeof valeur === 'object' ? valeur.textContent : valeur}` },
    h('span', { class: 'etiquette' }, icone(ic, 'bn-icone--s'), court), h('span', { class: 'chiffre' }, valeur)), long);
  return h('div', { class: 'cm-pile' },
    estMort(f) ? marqueMort({ grand: true }) : barrePV(f.nom, f.pv, false),   // mort : le repère à la place de la barre
    estMort(f) ? null : etats,
    h('div', { class: 'cm-beyond__chiffres' },
      chiffre('bouclier', 'CA', caDe(f), 'Classe d\'armure'),
      chiffre('oeil', 'PP', f.passives.perception, 'Perception passive'),
      chiffre('lu-brain', 'PI', f.passives.intuition, 'Intuition passive'),
      chiffre('lu-search', 'Inv.', f.passives.investigation, 'Investigation passive'),
      f.sorts.length ? chiffre('d20', 'DD', ddSorts(f), 'DD des sorts : ' + f.sorts.map(s => `${s.classe}, DD ${s.dd}, attaque ${signe(s.attaque)}`).join(' · ')) : null,
      vitesseEncombree(chiffre('lu-footprints', 'Vit.', distance(f.vitesses.marche), 'Vitesse'), f)),
    h('p', { class: 'ui-s cm-sourdine' },
      Object.keys(f.vitesses).length > 1 ? ['Déplacements : ', ...vitesses(f.vitesses), ' · '] : null,
      f.vision_dans_le_noir ? ['Vision dans le noir ', distance(f.vision_dans_le_noir), ' · '] : null,
      `Maîtrise ${signe(f.maitrise)}`),   // la bourse est dans l'onglet Inventaire
    caracteristiques(f, true),
    section('Sorts et capacités', 'glyphe', ressources(f)));
}
// Objets magiques d'une fiche (onglet Beyond).
const objetsMagiques = f => section('Objets magiques', 'potion', f.objets_magiques?.length ? h('ul', { class: 'cm-liste ui' }, f.objets_magiques.map(o => h('li', {},
  h('b', {}, o.nom), o.quantite > 1 ? ` ×${o.quantite}` : '', o.rarete ? ' · ' + o.rarete : '',
  o.harmonisation ? (o.harmonise ? ' · harmonisé' : ' · non harmonisé') : '', o.equipe ? ' · équipé' : ''))) : null);
// Onglet Inventaire d'une fiche (demande du MJ, 2026-10-20) : objets magiques, ce qui est équipé, la bourse.
// babioles : la liste de ses babioles (listeBabioles() du widget), ou null.
function inventaire(f, babioles = null) {
  const equipes = f.objets_equipes || [];   // relevés depuis la version 1.5.2 de l'extension
  return [
    objetsMagiques(f),
    section('Équipé', 'bouclier', equipes.length ? h('ul', { class: 'cm-liste ui' }, equipes.map(o => h('li', {},
      h('b', {}, o.nom), o.quantite > 1 ? ` ×${o.quantite}` : '', o.type ? h('span', { class: 'cm-sourdine' }, ` · ${o.type}`) : null))) : null),
    section('Babioles', 'lu-gift', babioles),
    section('Bourse', 'piece', h('p', {}, bourse(f.argent))),
  ];
}

// Bloc D&D Beyond d'une créature (familier…). etats : ses états, gardés dans le gestionnaire (etatsFiche() du widget).
// bloc : son profil en bloc de stats (blocCompagnon de app/fiche-compagnon.js, extension 1.14.0), comme dans l'extension
// du joueur : PV, états, férocité, puis le bloc ; sans profil relevé, les valeurs du résumé.
function creatureDetail(c, etats, bloc = null) {
  if (bloc) {
    return h('div', { class: 'cm-pile' },
      barrePV(c.nom, c.pv, false),
      etats,
      ferocite(c),
      h('div', { class: 'cm-compagnon__bloc' }, bloc));
  }
  return h('div', { class: 'cm-pile' },
    barrePV(c.nom, c.pv, false),
    etats,
    h('p', { class: 'ui-s cm-sourdine' }, 'Son bloc de stats, comme dans l\'extension du joueur, vient avec l\'extension 1.14.0 : rechargez-la dans chrome://extensions.'),
    chips(c),
    Object.keys(c.vitesses || {}).length > 1 ? h('p', { class: 'ui-s cm-sourdine' }, 'Déplacements : ', ...vitesses(c.vitesses)) : null,
    caracteristiques(c, false),
    // À la place des sorts et capacités d'un héros. Pas encore notée : l'extension du joueur (1.8.0) ou celle du MJ
    // (1.7.2) n'est pas à jour, ou le compagnon n'a pas de férocité.
    section('Férocité', 'griffe', ferocite(c) || h('p', { class: 'ui-s cm-sourdine' },
      'Pas notée sur D&D Beyond : l\'extension du compagnon (1.8.0) la note dans la note de la créature, dès que le joueur s\'en sert.')));
}

// ───── Origines : détails relevés à la demande (historique, espèce, dons…) ─────
// Textes de D&D Beyond, en anglais comme sur la fiche ; repliés, ils servent à construire le lore.

const paragraphe = t => (t ? h('p', { class: 'texte cm-texte-beyond' }, t) : null);
function repli(titre, ...contenu) {
  const c = contenu.flat(Infinity).filter(Boolean);
  return c.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, titre), h('div', { class: 'cm-pile cm-origines' }, c)) : null;
}
const elementBeyond = e => h('div', { class: 'cm-origine' }, h('p', { class: 'ui' }, h('b', {}, e.nom), e.categorie ? h('span', { class: 'cm-sourdine' }, ` · ${e.categorie}`) : null), paragraphe(e.description));
function blocOrigines(det) {
  if (!det) return null;
  const e = det.espece, hi = det.historique;
  const sousClasses = (det.classes || []).filter(c => c.sous_classe);
  const libres = { ...det.apparence, ...det.personnalite, ...det.notes };
  return section('Origines', 'livre',
    e ? repli(`Espèce : ${e.nom}`, paragraphe(e.description), e.traits.map(elementBeyond), e.options.map(elementBeyond)) : null,
    hi ? repli(`Historique : ${hi.nom}${hi.nom_original && hi.nom_original !== hi.nom ? ` (${hi.nom_original})` : ''}`,
      hi.resume ? h('p', { class: 'ui-l' }, hi.resume) : null, paragraphe(hi.description), hi.aptitude ? elementBeyond(hi.aptitude) : null) : null,
    det.dons?.length ? repli(`Dons : ${det.dons.map(d => d.nom).join(', ')}`, det.dons.map(elementBeyond)) : null,
    sousClasses.length ? repli(`Sous-classe : ${sousClasses.map(c => c.sous_classe.nom).join(', ')}`, sousClasses.map(c => elementBeyond(c.sous_classe))) : null,
    det.options_de_classe?.length ? repli('Options de classe', det.options_de_classe.map(elementBeyond)) : null,
    Object.keys(libres).length ? repli('Notes de la fiche', Object.entries(libres).map(([k, v]) => h('p', { class: 'ui' }, h('b', {}, LIBELLES_NOTES[k] || k), ' : ', v))) : null);
}

export default {
  type: 'personnages',
  titre: 'Personnages',
  surtitre: 'Les héros',
  icone: 'bouclier',
  description: 'Les personnages joueurs et leurs compagnons, à jour depuis D&D Beyond : PV, CA, passives, sorts et capacités. Un clic ouvre la fiche complète ; « Le groupe » récapitule vie, ressources, objets et argent.',
  taille: { w: 6, h: 14 },
  min: { w: 4, h: 3 },
  unique: true,

  async monter({ corps, actions, resume, ajusterHauteur, reglages, donnees, etat, dialogue }) {
    const lecture = await donnees('personnages');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Personnages indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const g = d.groupe || {};
    const tous = d.personnages || [];
    const joueurs = tous.filter(p => p.role === 'personnage');
    const compagnonsDe = id => tous.filter(p => p.role === 'compagnon' && p.compagnon_de === id);
    const [lieux, wiki, , sc] = await Promise.all([chargerLieux(donnees), chargerWiki(), chargerIconesEtats(), etatsCreatures()]);
    const fb = await fichesBabioles({ donnees, etat, dialogue }).catch(() => null);   // les babioles (fenêtre d'une babiole)
    // États des compagnons (gardés dans le gestionnaire), posés ici ou dans Combat : cartes et fenêtres redessinées.
    sc.abonner(() => { rendre(); [...ouvertes.keys()].forEach(rafraichir); });
    const pnj = new Map(((await donnees('pnj')).donnees?.pnj || []).map(p => [p.id, p]));
    const deroule = (await donnees('deroule-campagne')).donnees;   // null s'il est absent ou refusé (format)
    const jalons = new Map((deroule?.jalons || []).map(j => [j.id, j]));
    const pistes = new Map((deroule?.pistes || []).map(x => [x.id, x]));
    const sDeroule = deroule ? await etatDeroule(etat, donnees) : null;
    const statut = (genre, id) => (sDeroule ? statutDe(sDeroule.valeur, genre, id) : 'a-venir');
    const ordreEtape = new Map((deroule?.etapes || []).map(e => [e.id, e.ordre]));
    // Pistes du déroulé qui appartiennent à la quête personnelle d'un personnage, dans l'ordre conseillé de leurs étapes.
    const pistesDe = p => [...pistes.values()].map((x, i) => ({ x, i })).filter(({ x }) => x.personnage === p.id)
      .sort((a, b) => (ordreEtape.get(a.x.etape) ?? Infinity) - (ordreEtape.get(b.x.etape) ?? Infinity) || a.i - b.i).map(({ x }) => x);
    let beyond = await lireBeyond();
    let details = await lireDetails();   // historique, espèce, dons… relevés à la demande
    // Lore et secrets : ceux du fichier, et les retouches du MJ (app/lore.js) ; celles que le fichier a reprises s'effacent.
    const sLore = await etatLore(etat);
    if (nettoyerLore(sLore, tous)) sLore.enregistrer(0);
    const apresLore = () => { rendre(); [...ouvertes.keys()].forEach(rafraichir); };

    const parId = id => tous.find(p => p.id === id);
    const nomCourt = p => p.nom_court || p.nom;
    const compagnons = p => compagnonsAvecFiches(compagnonsDe(p.id), ficheDe(p, beyond));

    // Portrait : `portrait` de personnages.json, sinon (en attendant) celui du wiki, sinon l'avatar de la fiche D&D Beyond.
    function portrait(p, nom, taille) {
      // Un druide en forme sauvage : le portrait de sa forme (relevé de l'extension, depuis 1.18.0), tant qu'il est transformé.
      const fp = p?.role === 'personnage' ? ficheDe(p, beyond) : null;
      const src = p ? fp?.forme_sauvage?.avatar || portraitDuPersonnage(p, wiki, fp?.avatar || null) : null;
      const initiale = String(nom || '?').replace(/^(le|la|les|l')\s*/i, '').charAt(0).toUpperCase();
      return h('span', { class: `cm-portrait cm-portrait--${taille}` },
        src ? h('img', { src, alt: '', loading: 'lazy', onerror: e => e.target.replaceWith(document.createTextNode(initiale)) }) : initiale);
    }

    // ...apres : d'autres boutons au bout de la ligne (« + État » d'une fiche).
    function liensExternes(liens, ...apres) {
      return h('div', { class: 'bn-groupe' },
        wikiActif() && liens?.wiki?.url ? h('a', { class: 'bn-btn bn-btn--s bn-btn--fantome', href: liens.wiki.url, target: '_blank', rel: 'noopener' }, icone('livre'), h('span', {}, 'Wiki')) : null,
        liens?.feuille ? h('a', { class: 'bn-btn bn-btn--s bn-btn--fantome', href: liens.feuille, target: '_blank', rel: 'noopener' }, icone('d20'), h('span', {}, 'Feuille')) : null,
        ...apres);
    }

    // ───── Fenêtres flottantes ─────
    // Chaque fenêtre ouverte garde sa fonction de rendu : elle est redessinée à chaque nouveau relevé.

    const ouvertes = new Map();     // clé -> () => { surtitre, titre, contenu }
    function ouvrir(cle, rendu) {
      ouvertes.set(cle, rendu);
      flottant(cle, rendu());
    }
    function rafraichir(cle) {
      const f = flottantOuvert(cle), rendu = ouvertes.get(cle);
      if (!f || !rendu) { ouvertes.delete(cle); return; }
      const o = rendu();
      f.maj(o.contenu, o.titre, o.surtitre);
    }

    // Un jalon ou une piste du déroulé : ouvrir le widget Déroulé dessus (défilé jusqu'à lui, sa fenêtre ouverte).
    function ouvrirDansDeroule(genre, x) {
      if (derouleSurLeTableau()) (genre === 'jalon' ? voirJalon : voirPiste)(x.id);
      else annoncer({ cle: 'deroule-absent', titre: 'Widget Déroulé absent', icone: 'sablier', couleur: 'brume', texte: `Ajoutez le widget Déroulé au tableau de ce mode pour voir « ${x.nom} ».` });
    }
    // Lien vers un jalon (sablier) ou une piste (son icône), le nom au survol, puis son statut : à venir, en cours ou
    // commencée, terminé.
    function lienDeroule(genre, x) {
      const st = statut(genre, x.id);
      const etape = deroule.etapes?.find(e => e.id === x.etape);
      return h('span', { class: 'bn-lien-deroule' },
        infobulle(h('button', { type: 'button', class: 'bn-lien-jalon', 'aria-label': `Ouvrir « ${x.nom} » dans le Déroulé`, onclick: () => ouvrirDansDeroule(genre, x) },
          icone(genre === 'jalon' ? 'sablier' : ICONE_PISTE, 'bn-icone--s')),
          `${genre === 'jalon' ? 'Jalon' : 'Piste'} · ouvrir dans le Déroulé${etape ? ` (${genre === 'jalon' ? 'étape' : 's\'ouvre à l\'étape'} ${etape.ordre} de la campagne : ${etape.nom})` : ''}`, { titre: x.nom }),
        h('span', { class: `bn-statut-deroule bn-statut-deroule--${st}` }, st === 'termine' ? icone('lu-check', 'bn-icone--s') : null, LIBELLES_STATUT[genre][st]));
    }
    // Secret qui se lit comme une suite d'étapes (quête personnelle) : liste numérotée par `numero`, à la place du texte.
    // Une étape renvoie à un jalon ou à une piste ; introuvable (ou déroulé indisponible) : un avertissement, sans lien.
    const etapesDuSecret = etapes => h('ol', { class: 'cm-liste cm-quete' }, [...etapes].sort((a, b) => a.numero - b.numero).map(e => {
      const genre = e.jalon !== undefined ? 'jalon' : e.piste !== undefined ? 'piste' : null;
      const cible = genre === 'jalon' ? jalons.get(e.jalon) : genre === 'piste' ? pistes.get(e.piste) : null;
      return h('li', { value: Number.isInteger(e.numero) ? e.numero : null }, e.texte,
        cible ? lienDeroule(genre, cible)
          : genre ? infobulle(h('span', { class: 'bn-lien-introuvable', tabindex: '0' }, icone('lu-triangle-alert', 'bn-icone--s')),
            deroule ? `${genre === 'jalon' ? 'Jalon' : 'Piste'} « ${e[genre]} » absent${genre === 'piste' ? 'e' : ''} de deroule-campagne.json` : 'Déroulé indisponible (bouton Données)', { ton: 'sang' }) : null);
    }));

    // Secrets du MJ et pistes de la quête personnelle, sans masquage (onglet MJ de la fiche : sans intitulé).
    // Deux onglets (demande du MJ, 2026-10-20) : Secret (les secrets en texte) et Quête (le secret qui se lit en étapes, le
    // déroulé de la quête personnelle, puis les pistes de la quête). Encadré violet : pour le MJ seul.
    const enEtapes = x => Array.isArray(x.etapes) && x.etapes.length > 0;
    // Secrets (hors quêtes en étapes) : ceux du fichier, ou la retouche du MJ ; « Modifier » toujours là (un MJ sans IA les
    // écrit lui-même).
    function blocSecrets(p) {
      const l = loreDe(p, sLore);
      return h('div', { class: 'cm-secrets cm-pile' },
        l.secrets.length ? h('ul', { class: 'cm-liste ui' }, l.secrets.map(x => h('li', {}, h('b', {}, x.sujet), ' : ', x.texte))) : h('p', { class: 'ui-s cm-sourdine' }, 'Aucun secret.'),
        h('div', { class: 'bn-groupe' },
          bouton('Modifier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', titre: 'Modifier les secrets de ce personnage', onclick: () => ouvrirEditionSecrets(p, sLore, dialogue, apresLore) }),
          l.secretsRetouches ? badge('Retouchés par le MJ', 'cierge', 'lu-pencil') : null));
    }
    function blocQuete(p) {
      const l = (p.secrets || []).filter(enEtapes), ps = pistesDe(p);
      if (!l.length && !ps.length) return null;
      return h('div', { class: 'cm-secrets' },
        l.length ? h('ul', { class: 'cm-liste ui' }, l.map(x => h('li', {}, h('b', {}, x.sujet), etapesDuSecret(x.etapes)))) : null,
        ps.length ? section('Pistes de la quête', ICONE_PISTE, h('ul', { class: 'cm-liste ui cm-pistes-perso' }, ps.map(x => h('li', {}, x.nom, lienDeroule('piste', x))))) : null);
    }

    // Le lore du personnage (onglet Lore de la fiche) : ce que l'IA a mis dans personnages.json, retouché au besoin par le
    // MJ (app/lore.js ; une section retouchée porte un crayon orange). Pas le wiki : il sert à l'IA, pas au gestionnaire.
    function blocLore(p) {
      const l = loreDe(p, sLore);
      const c = l.champs;
      const titre = (libelle, cle) => (l.retouches.has(cle) ? [libelle, ' ', h('span', { class: 'cm-retouche', title: 'Retouché par le MJ : la fin de session le donnera à votre agent IA de campagne' }, icone('lu-pencil', 'bn-icone--s cm-actif'))] : libelle);
      const sections = {
        apparence: v => h('p', { class: 'texte' }, v), personnalite: v => h('p', { class: 'texte' }, v), origine: v => h('p', { class: 'texte' }, v),
        motivations: v => h('ul', { class: 'cm-liste ui' }, v.map(m => h('li', {}, m))),
        objets_notables: v => v.map(o => h('p', { class: 'ui' }, h('b', {}, o.nom), o.texte ? [' : ', o.texte] : null)),
        allegeances: v => h('ul', { class: 'cm-puces' }, v.map(a => h('li', {}, a))),
      };
      const rempli = v => (Array.isArray(v) ? v.length : !!v);
      return [
        rempli(c.accroche) ? h('p', { class: 'ui-l' }, c.accroche, l.retouches.has('accroche') ? [' ', icone('lu-pencil', 'bn-icone--s cm-actif')] : null) : null,
        CHAMPS_LORE.filter(([cle]) => sections[cle] && rempli(c[cle])).map(([cle, libelle, , ic]) => {
          const s = section('x', ic, sections[cle](c[cle]));
          s.querySelector('.cm-section__titre').replaceChildren(icone(ic, 'bn-icone--s'), ...[titre(libelle, cle)].flat());
          return s;
        }),
        CHAMPS_LORE.some(([cle]) => rempli(c[cle])) ? null : h('p', { class: 'ui-s cm-sourdine' }, 'Pas encore de lore pour ce personnage.'),
        h('div', { class: 'bn-groupe' }, bouton('Modifier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', titre: 'Modifier le lore de ce personnage', onclick: () => ouvrirEditionLore(p, sLore, dialogue, apresLore) })),
      ];
    }

    // Sous les sorts et capacités, des onglets (demandes du MJ, 2026-10-20) : Inventaire (objets magiques, équipés,
    // bourse), Beyond (origines relevées à la demande), VVD (le wiki), Secret (icône « caché ») et Quête (pour le MJ seul).
    // Un onglet vide n'apparaît pas ; l'onglet choisi reste d'un relevé à l'autre.
    const ongletsChoisis = new Map();   // clé de la fenêtre -> onglet
    function ongletsFiche(cle, liste) {
      const l = liste.map(o => ({ ...o, contenu: [o.contenu].flat(Infinity).filter(Boolean) })).filter(o => o.contenu.length);
      if (!l.length) return null;
      const { barre, zone } = onglets('Détails', l.map(o => ({ id: o.id, libelle: o.libelle, court: o.court, icone: o.icone, rendu: () => h('div', { class: 'cm-pile' }, o.contenu) })),
        ongletsChoisis.get(cle), id => ongletsChoisis.set(cle, id));
      return h('div', { class: 'cm-pile cm-perso-onglets' }, barre, zone);
    }

    // ───── Jets (demande du MJ, 2026-10-23 : app/jets-heros.js) ─────
    // Le dé de l'en-tête lance pour tout le groupe (héros vivants et compagnons qui ont une fiche), le résultat classé ;
    // le dé en haut à droite d'une fiche, pour ce héros seul.
    const participantsGroupe = () => joueurs.flatMap(p => {
      const f = ficheDe(p, beyond);
      return [f && !estMort(f) ? { nom: nomCourt(p), fiche: f } : null,
        ...compagnons(p).filter(c => c.creature).map(c => ({ nom: c.p ? nomCourt(c.p) : c.creature.nom, fiche: c.creature, creature: true }))];
    }).filter(Boolean);
    const lancerPourLeGroupe = ev => ouvrirChoixJet({ cle: 'jet:groupe', surtitre: 'Le groupe, résultat pour le MJ', titre: 'Jet de groupe', participants: participantsGroupe, depuis: ev.currentTarget, groupe: true });
    const boutonJet = (cle, nom, participants) => bouton('', { icone: 'd20', titre: `Lancer un jet pour ${nom}`, classe: 'bn-btn--s bn-btn--fantome cm-perso-fiche__de',
      onclick: ev => ouvrirChoixJet({ cle: 'jet:' + cle, surtitre: nom, titre: 'Lancer un jet', participants, depuis: ev.currentTarget }) });

    function ouvrirPersonnage(p) {
      const cle = 'perso:' + p.id;
      ouvrir(cle, () => {
        const f = ficheDe(p, beyond);
        const comp = compagnons(p);
        return {
          surtitre: ['Personnage joueur', p.joueur ? `joué par ${p.joueur}` : null].filter(Boolean).join(' · '),
          titre: p.nom,
          miniature: portraitDuPersonnage(p, wiki, f?.avatar),
          pictogramme: 'lu-user',
          contenu: h('article', { class: 'cm-pile cm-perso-fiche' },
            f ? boutonJet(p.id, nomCourt(p), () => [{ nom: nomCourt(p), fiche: ficheDe(p, beyond) }]) : null,
            h('div', { class: 'cm-perso-fiche__tete' },
              // L'inspiration sur le coin (un clic) ; les états sont sous la barre de PV, « + État » à droite du portrait.
              // L'icône de diffusion en haut à droite du portrait : sur l'écran des joueurs (plugin actif, demande du MJ, 2026-11-03).
              avecEcranJoueurs(f ? cadre(p, p.nom, 'l', f, cibleHeros(p), { etats: false }) : portrait(p, p.nom, 'l'), portraitDuPersonnage(p, wiki, f?.avatar), p.nom),
              h('div', { class: 'cm-pile cm-perso-fiche__titres' },
                h('div', { class: 'bn-groupe' }, [p.classe, p.race, p.historique || f?.historique].filter(Boolean).map(x => badge(x, null)),
                  f ? badge(`Niveau ${f.niveau}`, 'ultra') : null),
                liensExternes({ ...p.liens, feuille: p.liens?.feuille || f?.url }, boutonPoserEtat(cibleHeros(p), f)),
                comp.length ? h('div', { class: 'bn-groupe' }, comp.map(c => bouton(c.p?.nom || c.creature.nom, { icone: 'loup', classe: 'bn-btn--s bn-btn--fantome', onclick: () => ouvrirCompagnon(p, c) }))) : null)),
            f ? beyondDetail(f, etatsFiche(cibleHeros(p), f)) : h('p', { class: 'ui-s cm-sourdine' }, 'Pas encore de relevé D&D Beyond pour ce personnage.'),
            ongletsFiche(cle, [
              { id: 'competences', libelle: 'Compétences', court: 'Comp.', icone: 'lu-list', contenu: f ? blocCompetences(f, nomCourt(p)) : [] },
              { id: 'inventaire', libelle: 'Inventaire', icone: 'potion', contenu: f ? inventaire(f, listeBabioles(babiolesHeros(f))) : [] },
              { id: 'beyond', libelle: 'Beyond', icone: 'd20', contenu: f ? blocOrigines(details.fiches[f.id]) : [] },
              { id: 'lore', libelle: 'Lore', icone: 'livre', contenu: blocLore(p) },
              { id: 'secret', libelle: 'Secret', icone: 'lu-eye-off', contenu: blocSecrets(p) },
              { id: 'quete', libelle: 'Quête', icone: ICONE_PISTE, contenu: blocQuete(p) },
            ])),
        };
      });
    }

    // ───── Babioles dans les inventaires D&D Beyond (demande du MJ, 2026-10-20) ─────
    // Celles d'un héros (ses objets personnalisés, sauf ceux rangés dans l'inventaire du groupe) et celles du groupe ; un
    // objet est une babiole par sa note (« Donner ») ou son nom (babioleDeLObjet de app/babioles.js). Un clic ouvre sa
    // fenêtre (texte, note du MJ…).
    const dansLeGroupe = () => new Set((beyond.groupe?.objets || []).filter(o => o.perso).map(o => String(o.definition)));
    const babiolesDe = objets => (objets || []).map(o => ({ o, b: babioleDeLObjet(fb, o) })).filter(x => x.b);
    const babiolesHeros = f => babiolesDe((f?.objets_perso || []).filter(o => !dansLeGroupe().has(String(o.id))));
    function babiolesGroupe() {   // avec la note de l'objet personnalisé d'origine (celui d'un héros)
      const notes = new Map(Object.values(beyond.fiches || {}).flatMap(f => (f.objets_perso || []).map(o => [String(o.id), o.note])));
      return babiolesDe((beyond.groupe?.objets || []).map(o => ({ ...o, note: o.perso ? notes.get(String(o.definition)) : null })));
    }
    const listeBabioles = items => (items.length ? h('ul', { class: 'cm-liste ui' }, items.map(({ o, b }) => h('li', {},
      h('button', { type: 'button', class: 'cm-lien-bouton', title: 'Ouvrir la babiole', onclick: () => fb.ouvrir(b.l) }, intituleBabiole(b.l)),
      o.quantite > 1 ? ` ×${o.quantite}` : ''))) : null);

    // Résumé des règles des créatures compagnons (Flee, Mortals!), avec la partie du MJ et le lien vers D&D Beyond.
    function ouvrirReglesCompagnons(depuis) {
      flottant('regles:compagnons', { surtitre: 'Flee, Mortals!', titre: 'Créatures compagnons', largeur: 480, depuis, contenu: contenuReglesCompagnons({ mj: true }) });
    }

    // Le bloc de stats d'un compagnon (app/fiche-compagnon.js) : niveau et bonus de maîtrise de son soigneur, dictionnaire de
    // D&D Beyond (lu une fois par l'extension ; en attendant, les fenêtres ouvertes se redessinent quand il arrive).
    let cfgBeyond = null, cfgDemande = false;
    function blocDuCompagnon(maitre, cr) {
      if (!cr?.profil) return null;
      if (!cfgDemande) {
        cfgDemande = true;
        configBeyond().then(c => { cfgBeyond = c; [...ouvertes.keys()].forEach(rafraichir); }).catch(() => {});
      }
      const f = ficheDe(maitre, beyond);
      return blocCompagnon(cr, { cfg: cfgBeyond, niveau: f?.niveau || 1, pb: f?.maitrise || 2 });
    }

    function ouvrirCompagnon(maitre, paire) {
      const cle = 'perso:' + (paire.p?.id || 'creature-' + paire.creature.id);
      ouvrir(cle, () => {
        // Relire la créature dans le dernier relevé.
        const c = compagnons(maitre).find(x => (paire.p && x.p?.id === paire.p.id) || (!paire.p && x.creature?.id === paire.creature?.id)) || paire;
        const p = c.p, cr = c.creature;
        const nom = p ? nomCourt(p) : cr?.nom;
        const cible = cr ? cibleCreature(nom, cr) : null, crEtats = cr ? avecEtats(sc, cr) : null;
        return {
          surtitre: `${cr ? cr.groupe.charAt(0).toUpperCase() + cr.groupe.slice(1) : 'Compagnon'} ${de(nomCourt(maitre))}`,
          titre: p?.nom || cr.nom,
          miniature: p ? portraitDuPersonnage(p, wiki, null) : null,
          pictogramme: 'lu-user',
          largeur: cr?.profil ? 560 : undefined,   // son bloc de stats : les six caractéristiques de front
          contenu: h('article', { class: 'cm-pile cm-perso-fiche' },
            cr ? boutonJet(cle, nom, () => [{ nom, fiche: compagnons(maitre).find(x => x.creature?.id === cr.id)?.creature || cr, creature: true }]) : null,
            h('div', { class: 'cm-perso-fiche__tete' },
              avecEcranJoueurs(cadre(p, p?.nom || cr.nom, 'l', crEtats, cible, { etats: false }), p ? portraitDuPersonnage(p, wiki, null) : null, p?.nom || cr.nom),   // ses états sous la barre de PV
              h('div', { class: 'cm-pile cm-perso-fiche__titres' },
                p || crEtats?.rampage ? h('div', { class: 'bn-groupe' }, p ? [p.classe, p.race].filter(Boolean).map(x => badge(x, null)) : null, crEtats?.rampage ? badge('Rampage', 'sang', 'crocs') : null) : null,
                p ? liensExternes(p.liens) : null,
                h('div', { class: 'bn-groupe' }, bouton(maitre.nom, { icone: 'lu-arrow-right', classe: 'bn-btn--s bn-btn--fantome', onclick: () => ouvrirPersonnage(maitre) }),
                  cible ? boutonPoserEtat(cible, crEtats) : null,
                  // Aide : le résumé des règles des créatures compagnons de Flee, Mortals! en fenêtre (app/regles-compagnons.js, partagé
                  // avec l'extension du joueur), demande du MJ, 2026-10-20.
                  infobulle(bouton('Règles', { icone: 'lu-info', classe: 'bn-btn--s bn-btn--fantome', onclick: e => ouvrirReglesCompagnons(e.currentTarget) }),
                    'Flee, Mortals! : le résumé des règles des créatures compagnons (férocité, rampage), et le lien vers D&D Beyond.', { titre: 'Règles des compagnons' })))),
            cr ? creatureDetail(crEtats, etatsFiche(cible, crEtats), blocDuCompagnon(maitre, crEtats)) : h('p', { class: 'ui-s cm-sourdine' }, 'Pas de créature correspondante dans les « extras » de la fiche D&D Beyond.'),
            p ? ongletsFiche(cle, [
              { id: 'lore', libelle: 'Lore', icone: 'livre', contenu: blocLore(p) },
              { id: 'secret', libelle: 'Secret', icone: 'lu-eye-off', contenu: blocSecrets(p) },
              { id: 'quete', libelle: 'Quête', icone: ICONE_PISTE, contenu: blocQuete(p) },
            ]) : null),
        };
      });
    }

    // ───── États et inspiration héroïque, écrits sur la fiche D&D Beyond (extension, app/etats.js) ─────
    // Le changement s'affiche aussitôt sur le relevé gardé ; l'extension écrit, relève les fiches, et le widget relit alors
    // le relevé. Échec : l'ancien état revient, avec une annonce. Pendant une écriture, les relectures de fond attendent.

    const enEcriture = new Set();   // `inspi:<fiche>`, `etat:<fiche>:<état>`
    async function relire(forcer = false) {
      const [neuf, neufsDetails] = await Promise.all([lireBeyond(), lireDetails()]);
      if (neufsDetails.maj !== details.maj) { details = neufsDetails; [...ouvertes.keys()].forEach(rafraichir); }
      if (!forcer && (neuf.maj === beyond.maj || enEcriture.size)) return;   // écriture commencée pendant la lecture
      // Un relevé qui ne change rien (toutes les 20 s) : l'âge du relevé seulement, pas de redessin (retour du MJ, 2026-11-03 :
      // ça clignotait, et une fiche ouverte repartait du haut).
      if (!forcer && empreinteBeyond(neuf) === empreinteBeyond(beyond)) { beyond = neuf; majAge(); return; }
      beyond = neuf;
      rendre();
      [...ouvertes.keys()].forEach(rafraichir);
      majAge();
    }
    async function ecrire(f, cle, changer, ecriture, echec) {
      if (enEcriture.has(cle)) return;
      enEcriture.add(cle);
      changer(f);
      rendre();
      [...ouvertes.keys()].forEach(rafraichir);
      try { await ecriture(); }
      catch (e) { annoncer({ cle: 'beyond-ecriture', titre: echec, icone: 'lu-triangle-alert', couleur: 'sang', texte: e.message }); }
      enEcriture.delete(cle);
      await relire(true);
    }

    function basculerInspiration(p, f) {
      const valeur = !f.inspiration;
      return ecrire(f, 'inspi:' + f.id, x => { x.inspiration = valeur; }, () => changerInspiration(f.id, valeur),
        `Inspiration de ${prenom(p)} : fiche D&D Beyond inchangée`);
    }
    const garderEtats = (f, l) => { f.etats = l.map(e => ({ id: e.id, nom: e.nom, niveau: e.niveau })); };
    // Poser un état, ou changer le niveau d'Épuisement (niveau 1 à 6).
    function poser(p, f, id, niveau = null) {
      const e = etatDe({ id, niveau });
      return ecrire(f, `etat:${f.id}:${id}`, x => garderEtats(x, [...etatsDe(x).filter(y => y.id !== id), e]),
        () => poserEtat(f.id, id, e.niveau), `${nomEtat(e)} : pas posé sur la fiche de ${prenom(p)}`);
    }
    function retirer(p, f, id) {
      const e = etatDe({ id });
      return ecrire(f, `etat:${f.id}:${id}`, x => garderEtats(x, etatsDe(x).filter(y => y.id !== id)),
        () => retirerEtat(f.id, id), `${e.nom} : pas retiré de la fiche de ${prenom(p)}`);
    }

    // Qui porte les états : un héros (sa fiche D&D Beyond, écrite par l'extension) ou une créature, familier ou compagnon
    // (le gestionnaire seul : D&D Beyond n'en pose pas sur les créatures). fiche() : la fiche à jour, états compris.
    function cibleHeros(p) {
      const f = () => ficheDe(p, beyond);
      return {
        cle: 'pj:' + p.id, nom: prenom(p), ou: 'sur sa fiche D&D Beyond', fiche: f,
        poser: (id, niveau) => f() && poser(p, f(), id, niveau),
        retirer: id => f() && retirer(p, f(), id),
        occupe: id => !!f() && enEcriture.has(`etat:${f().id}:${id}`),
      };
    }
    const cibleCreature = (nom, cr) => ({
      cle: 'cr:' + cr.id, nom, ou: 'dans le gestionnaire (D&D Beyond n\'en pose pas sur les créatures)', fiche: () => avecEtats(sc, cr),
      poser: (id, niveau) => poserEtatCreature(sc, cr, id, niveau),
      retirer: id => retirerEtatCreature(sc, cr, id),
      occupe: () => false,
    });

    // Fiche : ses états en badges (un clic ouvre l'état), « État » pour en poser un, ses jets contre la mort.
    // (sous la barre de PV ; rien s'il n'en a pas). « + État » est à droite du portrait (boutonPoserEtat).
    function etatsFiche(cible, f) {
      const l = etatsDe(f);
      const enc = cible.cle.startsWith('pj:') ? encombrementDe(f) : null;   // l'encombrement en badge, après les états
      if (!l.length && !enc && !aTerre(f) && !f?.forme_sauvage) return null;
      return h('div', { class: 'bn-groupe cm-etats-fiche' },
        badgeForme(f),
        l.map(e => h('button', {
          type: 'button', class: 'bn-badge bn-badge--cierge cm-etat-badge' + (cible.occupe(e.id) ? ' est-en-cours' : ''),
          onclick: ev => ouvrirEtat(cible, e.id, ev.currentTarget),
        }, iconeEtat({ ...e, niveau: null }), nomEtat(e))),   // le niveau est dans le libellé
        enc ? infobulle(h('button', { type: 'button', class: `bn-badge bn-badge--${enc.etat === 'lourd' ? 'sang' : 'cierge'} cm-etat-badge`,
          onclick: ev => ouvrirEncombrement(f, cible.nom, ev.currentTarget) }, iconeEncombrement(enc, 'bn-etat--s'), ENCOMBREMENTS[enc.etat].nom),
        `${resumeEncombrement(enc)} Un clic : le détail.`, { titre: ENCOMBREMENTS[enc.etat].nom }) : null,
        aTerre(f) ? jetsContreLaMort(f.jets_contre_la_mort) : null);
    }
    // « + État » d'une fiche (demande du MJ, 2026-10-20 : à droite du portrait, plus d'états sur celui de la fiche).
    function boutonPoserEtat(cible, f) {
      if (!f || estMort(f)) return null;
      const [declencheur, menu] = boutonMenu(bouton('État', { icone: 'lu-plus', classe: 'bn-btn--s bn-btn--fantome' }),
        choixEtats(f, cible.poser), `Poser un état sur ${cible.nom}`);
      menu.classList.add('cm-menu-etats');
      return [declencheur, menu];
    }

    // Fenêtre d'un état : ce qu'il coûte et les actions (retirer, niveau d'Épuisement), puis ses effets.
    function ouvrirEtat(cible, id, depuis) {
      ouvrir(`etat:${cible.cle}:${id}`, () => {
        const f = cible.fiche();
        const present = etatsDe(f).find(e => e.id === id);
        const e = present || etatDe({ id });
        const occupe = cible.occupe(id);
        const n = present?.niveau;
        const actions = !f || estMort(f) ? null : present ? [
          id === EPUISEMENT ? h('span', { class: 'cm-etat-niveaux' },
            bouton('', { icone: 'lu-minus', classe: 'bn-btn--s', titre: n > 1 ? `Niveau ${n - 1}` : 'Retirer l\'Épuisement', disabled: occupe, onclick: () => (n > 1 ? cible.poser(id, n - 1) : cible.retirer(id)) }),
            h('span', { class: 'cm-etat-niveaux__val' }, n),
            bouton('', { icone: 'lu-plus', classe: 'bn-btn--s', titre: `Niveau ${n + 1}`, disabled: occupe || n >= NIVEAU_MAX, onclick: () => cible.poser(id, n + 1) })) : null,
          bouton('Retirer', { icone: 'lu-x', classe: 'bn-btn--s', disabled: occupe, onclick: () => cible.retirer(id) }),
        ] : bouton('Poser', { icone: 'lu-plus', classe: 'bn-btn--s', disabled: occupe, onclick: () => cible.poser(id, id === EPUISEMENT ? 1 : null) });
        return {
          surtitre: `État · ${cible.nom}`,
          titre: e.nom,
          depuis,
          largeur: 440,
          contenu: h('article', { class: 'cm-pile cm-etat-fiche' },
            h('div', { class: 'cm-etat-fiche__tete' },
              iconeEtat(present ? e : { ...e, niveau: null }, 'bn-etat--l' + (occupe ? ' est-en-cours' : '')),
              h('div', { class: 'cm-pile' },
                h('p', { class: 'ui' }, present ? (n ? `Niveau ${n} : ${coutEpuisement(n)}.` : `${cible.nom} a cet état.`) : `${cible.nom} n'a pas cet état.`),
                actions ? h('div', { class: 'bn-groupe' }, actions) : null)),
            effetsEtat(e),
            h('p', { class: 'ui-s cm-sourdine' }, 'Glossaire des règles : ',
              h('a', { class: 'bn-lien', href: `sources/FR_SRD_CC_v5.2.1.pdf#page=${e.page}`, target: '_blank', rel: 'noopener' }, `DRS 5.2.1, p. ${e.page}`))),
        };
      });
    }

    // ───── Récapitulatif du groupe ─────

    function ouvrirGroupe() {
      ouvrir('perso:groupe', () => {
        const lignes = joueurs.map(p => ({ p, f: ficheDe(p, beyond), comp: compagnons(p) }));
        const avecFiche = lignes.filter(l => l.f);
        const pvGroupe = avecFiche.reduce((s, l) => ({ actuels: s.actuels + l.f.pv.actuels, max: s.max + l.f.pv.max, temporaires: s.temporaires + l.f.pv.temporaires }), { actuels: 0, max: 0, temporaires: 0 });
        const nom = (texte, ouvrirFn) => h('button', { type: 'button', class: 'cm-lien-bouton ui', onclick: ouvrirFn }, texte);
        return {
          surtitre: 'Récapitulatif',
          titre: g.nom || 'Le groupe',
          contenu: h('article', { class: 'cm-pile' },
            alerteImport(),
            avecFiche.length
              ? section('Vie', 'coeur',
                h('div', { class: 'cm-recap' }, lignes.flatMap(({ p, f, comp }) => [
                  f ? h('div', { class: 'cm-recap__ligne' }, nom(nomCourt(p), () => ouvrirPersonnage(p)), estMort(f) ? marqueMort() : barrePV(p.nom, f.pv, true)) : null,
                  ...comp.filter(c => c.creature).map(c => h('div', { class: 'cm-recap__ligne cm-recap__ligne--compagnon' },
                    nom(nomCourt(c.p || c.creature), () => ouvrirCompagnon(p, c)), barrePV(c.creature.nom, c.creature.pv, true))),
                ])),
                h('div', { class: 'cm-recap__ligne cm-recap__total' }, h('span', { class: 'etiquette' }, 'Groupe'), barrePV('du groupe', pvGroupe, true)))
              : h('p', { class: 'ui-s cm-sourdine' }, 'Pas encore de relevé D&D Beyond : voir le bouton d20 du widget.'),
            // Sous la vie, trois onglets (demande du MJ, 2026-10-20) ; l'onglet choisi reste d'un relevé à l'autre.
            ongletsFiche('perso:groupe', [
              { id: 'pouvoirs', libelle: 'Sorts et pouvoirs', court: 'Pouvoirs', icone: 'glyphe', contenu: avecFiche.length ? h('div', { class: 'cm-recap' }, avecFiche.map(({ p, f }) =>
                h('div', { class: 'cm-recap__ligne' }, nom(nomCourt(p), () => ouvrirPersonnage(p)), ressources(f) || h('span', { class: 'ui-s cm-sourdine' }, 'Aucune ressource limitée')))) : null },
              { id: 'inventaire', libelle: 'Inventaire', icone: 'potion', contenu: avecFiche.length ? inventaireGroupe(avecFiche, nom) : null },
              { id: 'campagne', libelle: 'Campagne', icone: 'carte', contenu: campagneGroupe() },
            ])),
        };
      });
    }

    // Onglet Inventaire du récapitulatif : objets magiques, argent et babioles de chaque héros et de l'inventaire commun.
    function inventaireGroupe(avecFiche, nom) {
      const totalPo = avecFiche.reduce((s, l) => s + enPo(l.f.argent), 0);
      const aucune = () => h('span', { class: 'ui-s cm-sourdine' }, 'Aucune');
      const parHeros = avecFiche.map(({ p, f }) => ({ p, l: babiolesHeros(f) })), communes = babiolesGroupe();
      return [
        section('Objets magiques', 'potion', h('div', { class: 'cm-recap' }, avecFiche.map(({ p, f }) =>
          h('div', { class: 'cm-recap__ligne' }, nom(nomCourt(p), () => ouvrirPersonnage(p)),
            f.objets_magiques?.length
              ? h('div', { class: 'bn-groupe' }, f.objets_magiques.map(o => badge(o.nom + (o.rarete ? ` · ${o.rarete}` : ''), o.rarete && o.rarete !== 'Commun' ? 'ultra' : null)))
              : h('span', { class: 'ui-s cm-sourdine' }, 'Aucun objet magique'))))),
        // Argent : chaque héros, puis l'inventaire commun (party inventory, extension 1.7.0) et le total.
        section('Argent', 'piece', h('div', { class: 'cm-recap' },
          avecFiche.map(({ p, f }) => h('div', { class: 'cm-recap__ligne' }, nom(nomCourt(p), () => ouvrirPersonnage(p)), bourse(f.argent))),
          beyond.groupe ? h('div', { class: 'cm-recap__ligne' }, h('span', { class: 'ui' }, 'Inventaire commun'), bourse(beyond.groupe.argent)) : null,
          h('div', { class: 'cm-recap__ligne cm-recap__total' }, h('span', { class: 'etiquette' }, 'Groupe'),
            h('span', { class: 'ui' }, h('b', {}, po(totalPo + enPo(beyond.groupe?.argent))))))),
        // Babioles : celles de chaque héros, puis celles de l'inventaire commun (s'il y en a au moins une).
        communes.length || parHeros.some(x => x.l.length) ? section('Babioles', 'lu-gift', h('div', { class: 'cm-recap' },
          parHeros.map(({ p, l }) => h('div', { class: 'cm-recap__ligne' }, nom(nomCourt(p), () => ouvrirPersonnage(p)), listeBabioles(l) || aucune())),
          beyond.groupe ? h('div', { class: 'cm-recap__ligne' }, h('span', { class: 'ui' }, 'Inventaire commun'), listeBabioles(communes) || aucune()) : null)) : null,
      ];
    }

    // Onglet Campagne du récapitulatif : niveau, lieu et étape, puis lieux visités, PNJ rencontrés, documents trouvés.
    function campagneGroupe() {
      const etape = deroule?.etapes?.find(e => e.id === g.etape);
      return [
        h('div', { class: 'cm-totaux__grille' },
          h('div', {}, h('span', { class: 'etiquette' }, 'Niveau'), h('span', { class: 'chiffre' }, g.niveau ?? '—')),
          h('div', {}, h('span', { class: 'etiquette' }, 'Lieu actuel'), h('span', { class: 'ui-l' }, g.lieu_actuel ? nomLieu(lieux, g.lieu_actuel) : '—')),
          h('div', {}, h('span', { class: 'etiquette' }, 'Étape'), h('span', { class: 'ui-l' }, etape ? etape.nom : '—'))),
        liensExternes({ wiki: g.wiki }),
        section('Lieux visités', 'epingle', g.lieux_visites?.length ? h('ol', { class: 'cm-puces' }, g.lieux_visites.map(id => h('li', {}, nomLieu(lieux, id)))) : null),
        section('PNJ rencontrés', 'crocs', g.pnj_rencontres?.length ? h('ul', { class: 'cm-puces' }, g.pnj_rencontres.map(id => h('li', {}, pnj.get(id)?.nom || id))) : null),
        section('Documents trouvés', 'lettre', (g.documents || []).map(doc => h('div', { class: 'cm-document' },
          h('p', { class: 'ui' }, wikiActif() && doc.wiki?.url ? h('a', { class: 'bn-lien', href: doc.wiki.url, target: '_blank', rel: 'noopener' }, doc.nom) : h('b', {}, doc.nom)),
          doc.resume ? h('p', { class: 'ui-s cm-sourdine' }, doc.resume) : null))),
        wikiActif() && g.journal?.url ? h('p', { class: 'ui' }, h('a', { class: 'bn-lien', href: g.journal.url, target: '_blank', rel: 'noopener' }, 'Journal de bord sur le wiki')) : null,
      ];
    }

    // L'agent IA de campagne a-t-il traité le dernier import du wiki ?
    function alerteImport() {
      if (!wiki?.importe_le || !g.import_wiki) return null;
      if (new Date(wiki.importe_le) <= new Date(g.import_wiki)) return null;
      return alerte('cierge', 'lu-refresh-cw', 'Wiki plus récent',
        `Le wiki a été importé le ${heure(wiki.importe_le)} ; votre agent IA de campagne n'a traité que l'import du ${heure(g.import_wiki)}. Donnez-lui wiki/changements.md.`);
    }

    // ───── Extension D&D Beyond ─────

    const age = () => (beyond.maj ? Math.max(0, Math.round((Date.now() - new Date(beyond.maj)) / 1000)) : null);
    const texteAge = s => (s == null ? '—' : s < 60 ? `${s} s` : s < 3600 ? `${Math.floor(s / 60)} min` : `${Math.floor(s / 3600)} h`);

    function ouvrirBeyond() {
      const s = age();
      const campagne = beyond.campagne?.id ? `${ORIGINE_BEYOND}/campaigns/${beyond.campagne.id}` : null;
      dialogue('Feuilles D&D Beyond', 'Relevé automatique', h('div', { class: 'cm-pile' },
        s == null ? alerte('cierge', 'lu-info', 'Aucun relevé', 'Installez l\'extension ci-dessous : elle relève les fiches toutes les 20 s.')
          : s > VIEUX_S ? alerte('cierge', 'lu-triangle-alert', `Dernier relevé il y a ${texteAge(s)}`, 'L\'extension est-elle installée, active, et Chrome connecté à D&D Beyond ? Son badge indique ce qui bloque.')
            : alerte('brume', 'lu-check', `Relevé il y a ${texteAge(s)}`, `${Object.keys(beyond.fiches).length} fiches, mises à jour toutes les 20 s.`),
        section('Installer l\'extension (une seule fois)', 'lu-puzzle',
          h('ol', { class: 'cm-liste ui' },
            h('li', {}, 'Dans Chrome, ouvrez ', h('code', {}, 'chrome://extensions'), ' et activez le « Mode développeur » (en haut à droite).'),
            h('li', {}, 'Cliquez « Charger l\'extension non empaquetée » et choisissez le dossier ', h('code', {}, 'extensions/mj'), ' du gestionnaire.'),
            h('li', {}, 'Épinglez l\'extension (icône puzzle) : son badge affiche les secondes écoulées depuis le dernier relevé.'),
            h('li', {}, 'Restez connecté à D&D Beyond dans Chrome',
              campagne ? [' (', h('a', { class: 'bn-lien', href: campagne, target: '_blank', rel: 'noopener' }, 'page de la campagne'), ')'] : null, '.')),
          h('p', { class: 'ui-s cm-sourdine' }, 'L\'extension ne relève rien quand le gestionnaire est arrêté. Elle lit les fiches avec votre session, dans votre navigateur, et n\'écrit que dans etat/ de ce poste.')),
        sectionDetails()));
    }

    // Détails à la demande : après un remaniement des fiches par les joueurs.
    function sectionDetails() {
      const zone = h('div', { class: 'cm-pile' });
      const fiches = Object.values(details.fiches || {});
      // Extension restée sur une version qui ne connaît pas les détails, ou demande qui attend depuis trop longtemps.
      const avertissement = h('div');
      const aRecharger = !beyond.extension || plusAncienne(beyond.extension, VERSION_EXTENSION);
      fetch('etat/beyond-demande.json', { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null).then(dm => {
        const attente = dm?.details && (!dm.traite || dm.traite < dm.details) ? (Date.now() - new Date(dm.details)) / 1000 : 0;
        if (aRecharger || attente > 75) avertissement.replaceChildren(alerte('cierge', 'lu-triangle-alert',
          aRecharger ? 'Extension à recharger' : `Demande en attente depuis ${texteAge(Math.round(attente))}`,
          aRecharger ? `L'extension tourne sur une version antérieure (${beyond.extension || 'avant 1.1'}) à celle qu'attend le gestionnaire (${VERSION_EXTENSION}). Dans Chrome : chrome://extensions, bouton « Recharger » de l'extension. Après chaque mise à jour de ses fichiers, c'est nécessaire.`
            : 'L\'extension ne l\'a pas traitée : est-elle active, et rechargée depuis sa dernière mise à jour (chrome://extensions, « Recharger ») ?'));
      });
      const statut = h('p', { class: 'ui' }, details.maj
        ? `Derniers détails relevés le ${heure(details.maj)} (${fiches.length} fiche${fiches.length > 1 ? 's' : ''}).`
        : 'Aucun détail relevé pour l\'instant.');
      const btnDemander = bouton('Relever les détails', {
        icone: 'lu-refresh-cw', classe: 'bn-btn--s bn-btn--primaire',
        onclick: async () => {
          btnDemander.disabled = true;
          try {
            await demanderDetails();
            zone.replaceChildren(alerte('brume', 'lu-check', 'Demande envoyée', 'L\'extension relèvera les détails à son prochain passage (20 s au plus). Ils s\'afficheront dans les fiches.'));
          } catch (e) {
            zone.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Demande non enregistrée', e.message));
          }
          btnDemander.disabled = false;
        },
      });
      const btnCopier = bouton('Copier pour l\'agent IA', {
        icone: 'lu-copy', classe: 'bn-btn--s', disabled: !fiches.length,
        onclick: async () => {
          const md = [`# Origines des personnages (D&D Beyond, relevé le ${heure(details.maj)})`, '', originesEnMarkdown(details, beyond, 2)].join('\n');
          try {
            await Promise.race([navigator.clipboard.writeText(md), new Promise((_, ko) => setTimeout(() => ko(new Error('délai')), 1500))]);
            zone.replaceChildren(alerte('brume', 'lu-check', 'Copié', `${md.length.toLocaleString('fr-FR')} caractères en Markdown : collez-les dans votre agent IA de campagne.`));
          } catch {
            // Presse-papiers refusé (page sans le focus…) : le texte, à copier à la main.
            const champ = h('textarea', { class: 'bn-textarea', rows: 10, readonly: true }, md);
            zone.replaceChildren(alerte('cierge', 'lu-info', 'Copie automatique refusée', 'Sélectionnez le texte ci-dessous (Ctrl+A, Ctrl+C).'), champ);
            champ.focus();
            champ.select();
          }
        },
      });
      return section('Détails des personnages (à la demande)', 'livre',
        h('p', { class: 'ui-s cm-sourdine' }, 'Historique, espèce et ses traits, dons, sous-classe et notes de chaque fiche, avec leurs textes. À relever quand les joueurs remanient leurs fiches.'),
        avertissement, statut, h('div', { class: 'bn-groupe' }, btnDemander, btnCopier), zone);
    }

    // ───── Cartes ─────

    // Portrait de carte ; pour un personnage, l'inspiration héroïque dans un petit rond sur le coin supérieur gauche (un clic
    // la donne ou la retire sur D&D Beyond) et ses états par-dessus (quatre au plus, du plus grave au moins grave ; un clic
    // sur une icône ouvre l'état). Un clic sur le portrait : le menu des états à poser. Mort : rien de tout cela.
    // Dans la carte (un bouton), les clics de ces éléments ne l'ouvrent pas.
    const sansCarte = fn => ev => { ev.stopPropagation(); ev.preventDefault(); fn(ev); };
    const auClavier = fn => ev => { if (ev.key === 'Enter' || ev.key === ' ') sansCarte(fn)(ev); };
    // cible : qui porte les états (cibleHeros, ou cibleCreature : ni inspiration, ni D&D Beyond).
    // etats : faux dans une fiche (ni icônes ni clic sur le portrait : les états sont sous la barre de PV, « + État » à droite).
    function cadre(p, nom, taille, f, cible, { etats: avecEtatsPortrait = true } = {}) {
      if (!f || !cible || estMort(f)) return h('span', { class: 'cm-portrait-cadre' }, portrait(p, nom, taille));
      const coin = !cible.cle.startsWith('pj:') ? (f.rampage ? iconeRampage('cm-rampage--coin') : null) : infobulle(h('span', {
        class: 'cm-inspi cm-inspi--coin' + (f.inspiration ? ' est-dispo' : '') + (enEcriture.has('inspi:' + f.id) ? ' est-en-cours' : ''),
        role: 'button', tabindex: '0', 'aria-pressed': String(!!f.inspiration),
        'aria-label': `Inspiration héroïque de ${prenom(p)}`,
        onclick: sansCarte(() => basculerInspiration(p, f)), onkeydown: auClavier(() => basculerInspiration(p, f)),
      }), f.inspiration ? 'Disponible. Un clic la retire sur la fiche D&D Beyond.' : 'Pas d\'inspiration. Un clic la donne sur la fiche D&D Beyond.',
      { titre: 'Inspiration héroïque', ton: 'soleil' });
      // L'encombrement (règle variante) prend l'une des quatre places, après les états.
      const enc = cible.cle.startsWith('pj:') ? tuileEncombrement(f, prenom(p)) : null;
      const l = etatsDe(f), vus = l.slice(0, enc ? 3 : 4), caches = l.slice(vus.length);
      const etats = vus.length || enc ? h('span', { class: 'cm-etats-portrait', 'data-nb': String(vus.length + (enc ? 1 : 0)) }, vus.map(e => {
        const ouvrirCe = ev => ouvrirEtat(cible, e.id, ev.currentTarget);
        const ic = iconeEtat(e, cible.occupe(e.id) ? 'est-en-cours' : '');
        Object.assign(ic, { tabIndex: 0, onclick: sansCarte(ouvrirCe), onkeydown: auClavier(ouvrirCe) });
        ic.setAttribute('role', 'button');
        ic.setAttribute('aria-label', `${nomEtat(e)} : ses effets`);
        return infobulle(ic, [e.niveau ? coutEpuisement(e.niveau) + '.' : null, 'Un clic : ses effets.',
          caches.length ? `Aussi : ${caches.map(nomEtat).join(', ')}.` : null].filter(Boolean).join(' '), { titre: nomEtat(e) });
      }), enc) : null;
      const image = portrait(p, nom, taille);
      if (!avecEtatsPortrait) return h('span', { class: 'cm-portrait-cadre' }, image, coin);
      const menuEtats = ev => ouvrirMenu(ev.currentTarget, choixEtats(cible.fiche(), cible.poser), `Poser un état sur ${cible.nom}`, { classe: 'cm-menu-etats' });
      Object.assign(image, { tabIndex: 0, onclick: sansCarte(menuEtats), onkeydown: auClavier(menuEtats) });
      image.setAttribute('role', 'button');
      image.setAttribute('aria-label', `Poser un état sur ${cible.nom}`);
      image.classList.add('cm-portrait--etats');
      return h('span', { class: 'cm-portrait-cadre' }, infobulle(image, `Un clic : poser un état, ${cible.ou}.`, { titre: cible.nom }), etats, coin);
    }
    const prenom = p => p.nom_court || String(p.nom).split(' ')[0];

    // Une carte = 3 ou 4 rangées (tête, PV, valeurs, puis ressources s'il y en a sur au moins une carte), alignées d'une
    // carte à l'autre (sous-grille) : les barres de PV sont toutes à la même hauteur, compagnon compris. Les états sont sur
    // le portrait. Pas de rangée vide : son écart laisserait une marge sous les cartes. Le mode étendu ajoute seulement les
    // ressources.
    let mode = reglages.lire('affichage', modeAncien());
    // Mort : le repère « Mort » à la place de la barre de PV ; ni valeurs, ni pouvoirs, ni états.
    const rangees = (tete, f, ressourcesCarte) => (estMort(f) ? [
      tete, marqueMort({ grand: true }), h('span'), h('span', { class: 'cm-rangee-vide', 'data-rangee': 'ressources' }),
    ] : [
      tete,
      f ? barrePV(tete.dataset.nom, f.pv, true) : h('span'),
      f ? ligneCarte(f) : h('span'),
      (f && mode !== 'basique' && ressourcesCarte) || h('span', { class: 'cm-rangee-vide', 'data-rangee': 'ressources' }),
    ]);

    function cartePersonnage(p) {
      const f = ficheDe(p, beyond);
      const identite = [p.classe, p.race, p.historique || f?.historique].filter(Boolean);
      const tete = h('span', { class: 'cm-perso-carte__tete', 'data-nom': p.nom },
        cadre(p, p.nom, 'm', f, cibleHeros(p)),
        h('span', { class: 'cm-perso-carte__titres' },
          h('span', { class: 'cm-perso-carte__nom' }, prenom(p)),
          // Cartes étroites : chaque ligne coupée en « … », le tout dans l'infobulle.
          f?.forme_sauvage ? badgeForme(f) : infobulle(h('span', { class: 'cm-perso-carte__identite' }, identite.map(x => h('span', {}, x))), identite.join(' · '))),
        aTerre(f) ? null : ecuCA(caDe(f)));
      return h('button', { type: 'button', class: 'bn-carte cm-perso-carte' + (estMort(f) ? ' est-decede' : aTerre(f) ? ' est-inconscient' : ''), onclick: () => ouvrirPersonnage(p), 'aria-label': `Ouvrir la fiche de ${p.nom}` },
        rangees(tete, f, f ? ressources(f, { carte: true }) : null));
    }

    function carteCompagnon(maitre, c) {
      const nom = c.p ? nomCourt(c.p) : c.creature.nom;
      const cr = c.creature ? avecEtats(sc, c.creature) : null;   // ses états, gardés dans le gestionnaire
      const tete = h('span', { class: 'cm-perso-carte__tete', 'data-nom': nom },
        cadre(c.p, nom, 'm', cr, cr ? cibleCreature(nom, c.creature) : null),
        h('span', { class: 'cm-perso-carte__titres' },
          h('span', { class: 'cm-perso-carte__nom' }, nom),
          h('span', { class: 'cm-perso-carte__identite' },
            h('span', {}, c.creature ? c.creature.groupe.charAt(0).toUpperCase() + c.creature.groupe.slice(1) : 'Compagnon'),
            h('span', {}, de(prenom(maitre))))),
        ecuCA(c.creature?.ca));
      return h('button', { type: 'button', class: 'bn-carte cm-perso-carte', onclick: () => ouvrirCompagnon(maitre, c), 'aria-label': `Ouvrir la fiche de ${nom}` },
        rangees(tete, c.creature, ferocite(c.creature, { carte: true })));   // à la place des ressources d'un héros
    }

    // Mise en page des cartes selon leur largeur : mesurée sur place, à chaque redimensionnement, pour toutes à la fois.
    // 1. Un prénom ou une identité déborde vers le grand bouclier : bouclier plus petit (.est-ecu-petit) ; s'il déborde
    //    encore : mode étroit, la CA passe dans la ligne des valeurs.
    // 2. Le prénom ne tient pas à droite du portrait : il passe au-dessus.
    // 3. Valeurs sur une ligne, plus grandes (.est-large : icône à gauche de la valeur, DD avec son mot), si elles tiennent
    //    sur chaque carte (grand écran) ; sinon empilées (.est-empile, posé au rendu).
    function ajusterCartes(ligne) {
      ligne.classList.remove('est-ecu-petit', 'est-etroite', 'est-tres-etroite', 'est-large');
      ligne.classList.add('est-empile');
      const deborde = sel => [...ligne.querySelectorAll(sel)].some(e => e.scrollWidth > e.clientWidth + 1);
      const titres = '.cm-perso-carte__nom, .cm-perso-carte__identite';
      if (deborde(titres)) ligne.classList.add('est-ecu-petit');
      if (deborde(titres)) ligne.classList.replace('est-ecu-petit', 'est-etroite');
      if (deborde('.cm-perso-carte__nom')) ligne.classList.add('est-tres-etroite');
      ligne.classList.replace('est-empile', 'est-large');
      if (deborde('.cm-perso-carte__ligne')) ligne.classList.replace('est-large', 'est-empile');
    }
    const observateur = new ResizeObserver(entrees => entrees.forEach(e => ajusterCartes(e.target)));

    // En-tête : le niveau du groupe (le plus élevé) ; en orange si un personnage n'a pas encore passé ce niveau.
    function majNiveau() {
      const fiches = joueurs.map(p => ({ p, f: ficheDe(p, beyond) })).filter(x => x.f?.niveau);
      if (!fiches.length) { resume.replaceChildren(); return; }
      const niveau = Math.max(...fiches.map(x => x.f.niveau));
      const enRetard = fiches.filter(x => x.f.niveau < niveau);
      const titre = `Niveau du groupe : ${niveau}` + (enRetard.length
        ? `\nPas encore passé : ${enRetard.map(x => `${prenom(x.p)} (niveau ${x.f.niveau})`).join(', ')}`
        : '\nTous les personnages ont ce niveau.');
      resume.replaceChildren(h('div', { title: titre }, badge(`Niv. ${niveau}`, enRetard.length ? 'cierge' : 'ultra', enRetard.length ? 'lu-triangle-alert' : null)));
    }

    // Ce que l'extension ne peut pas régler seule (`alertes` de beyond.json, depuis la version 1.11.0) : un objet d'état
    // homebrew (« Exhaustion Level », « Encumbered », « Heavily Encumbered », nommé dans `objet`) absent de la collection
    // du MJ (pour toute la campagne), des exemplaires que D&D Beyond a refusé d'ajouter à une fiche, le homebrew désactivé
    // sur une fiche. Repliées, le héros et le joueur sur la ligne ; elles disparaissent
    // d'elles-mêmes une fois réglé.
    function alertesFiches() {
      const titre = a => {
        const objet = a.objet || 'Exhaustion Level';   // alertes d'avant la version 1.12.0 : seulement l'Épuisement
        if (a.type.endsWith('-collection')) return `${objet} absent de votre collection`;
        const quoi = a.type.endsWith('-objet') ? `objets ${objet} manquants` : { 'homebrew-desactive': 'homebrew désactivé sur la fiche', 'reglage-refuse': 'réglage de la fiche refusé' }[a.type] || 'à régler';
        return `${String(a.nom || '').split(' ')[0]} : ${quoi}`;
      };
      // L'adresse d'un objet dans le texte de l'extension (« dndbeyond.com/magic-items/… ») devient un lien : sa page, pour l'ajouter
      // à la collection (« Add to Collection »).
      const avecLiens = t => String(t || '').split(/(dndbeyond\.com\/magic-items\/[\w-]+)/).map((x, i) => (i % 2
        ? h('a', { class: 'bn-lien', href: `https://www.${x}`, target: '_blank', rel: 'noopener' }, 'sa page sur D&D Beyond') : x));
      const l = (beyond.alertes || []).map(a => alerteRepliable('sang', 'lu-triangle-alert', titre(a),
        a.joueur ? h('span', { class: 'ui-s' }, a.joueur) : null, avecLiens(a.texte)));
      return l.length ? h('div', { class: 'cm-pile' }, l) : null;
    }

    // Tous les personnages sur une ligne, chaque compagnon juste après son maître, de même largeur.

    function rendre() {
      const haut = corps.scrollTop;
      majNiveau();
      const cartes = joueurs.flatMap(p => [cartePersonnage(p), ...compagnons(p).map(c => carteCompagnon(p, c))]);
      // Une rangée vide sur toutes les cartes (pas de ressources en mode basique) : retirée partout.
      for (const r of ['ressources']) {
        const vides = cartes.map(c => c.querySelector(`:scope > [data-rangee="${r}"]`));
        if (vides.every(Boolean)) vides.forEach(v => v.remove());
      }
      const nbRangees = cartes[0]?.children.length || 3;
      const ligne = h('div', { class: 'cm-perso-ligne est-empile', style: `--colonnes: repeat(${cartes.length}, minmax(0, 1fr)); --rangees: ${nbRangees}` }, cartes);
      observateur.disconnect();
      corps.replaceChildren(h('div', { class: 'cm-pile' }, alerteImport(), alertesFiches(), h('div', { class: 'cm-perso-zone' }, ligne)));
      observateur.observe(ligne);
      document.fonts?.ready.then(() => ligne.isConnected && ajusterCartes(ligne));   // les polices changent la largeur des textes
      corps.scrollTop = haut;
    }

    // ───── En-tête, relevés ─────

    const ageBeyond = h('span', { class: 'cm-age' });
    // Le relevé D&D Beyond (son âge) : icône d'actualisation ; le dé est celui des jets de groupe (demande du MJ, 2026-10-23).
    const btnBeyond = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome', onclick: ouvrirBeyond }, icone('lu-refresh-cw'), ageBeyond);
    // Basique ou étendu : l'étendu ajoute seulement les ressources. Le widget prend la hauteur de ses cartes, sans
    // défilement ni redimensionnement à la main. Propre à chaque mode du tableau (en combat, l'étendu par exemple) : au
    // changement de mode, le widget reprend l'affichage et la taille gardés pour ce mode. Masqué quand le widget est réduit.
    const zoneMode = h('span', { class: 'cm-si-deplie', title: 'Étendu : ajoute les emplacements de sorts et les capacités à usage limité. Réglage propre à chaque mode (Exploration, Rencontre).' });
    function majMode() {
      zoneMode.replaceChildren(bascule('Affichage des cartes', [['basique', 'Basique'], ['etendu', 'Étendu']], mode, m => {
        if (m === mode) return;
        mode = m;
        reglages.ecrire('affichage', m);
        majMode();
        rendre();
        ajusterHauteur();
      }));
    }
    majMode();
    reglages.surChangement(() => {
      const m = reglages.lire('affichage', modeAncien());
      if (m === mode) return;
      mode = m;
      majMode();
      rendre();
    });
    actions.append(
      zoneMode,
      bouton('Le groupe', { icone: 'lu-users', classe: 'bn-btn--s bn-btn--fantome', onclick: ouvrirGroupe }),
      bouton('', { icone: 'd20', titre: 'Jet de groupe : compétence, test, sauvegarde ou initiative, pour tous les héros (résultat pour le MJ seul)', classe: 'bn-btn--s bn-btn--fantome', onclick: lancerPourLeGroupe }),
      btnBeyond);
    function majAge() {
      const s = age();
      ageBeyond.textContent = texteAge(s);
      ageBeyond.classList.toggle('cm-age--vieux', s == null || s > VIEUX_S);
      btnBeyond.title = s == null ? 'Feuilles D&D Beyond : aucun relevé' : `Feuilles D&D Beyond : relevé il y a ${texteAge(s)}`;
    }

    // Fiche demandée par un autre widget (le PJ d'un jalon du Déroulé) : cm:voir-personnage, { id } ; ouvert passe à vrai.
    // Widget dans l'autre mode (en réserve) : la fiche s'ouvre quand même, c'est une fenêtre flottante.
    function voirPersonnage(ev) {
      const p = corps.isConnected ? parId(ev.detail?.id) : null;
      if (!p) return;
      if (p.role === 'compagnon') {
        const maitre = parId(p.compagnon_de);
        const c = maitre && compagnons(maitre).find(x => x.p?.id === p.id);
        if (!c) return;
        ouvrirCompagnon(maitre, c);
      } else ouvrirPersonnage(p);
      ev.detail.ouvert = true;
    }
    document.addEventListener('cm:voir-personnage', voirPersonnage);
    // « Le groupe » du menu rapide (app/menu-rapide.js) : le récapitulatif, même widget réduit ou dans l'autre mode.
    function voirGroupe(ev) {
      if (!corps.isConnected) { document.removeEventListener('cm:voir-groupe', voirGroupe); return; }
      ouvrirGroupe();
      if (ev.detail) ev.detail.ouvert = true;
    }
    document.addEventListener('cm:voir-groupe', voirGroupe);
    // Statuts des jalons et des pistes changés (Déroulé, fin de session) : les fiches ouvertes se redessinent.
    sDeroule?.abonner(() => { if (corps.isConnected) [...ouvertes.keys()].forEach(rafraichir); });

    rendre();
    majAge();
    // Le fichier change toutes les 20 s (extension) : relu toutes les 5 s, redessiné s'il a changé (pas pendant une écriture
    // sur une fiche : le relevé d'avant effacerait le changement affiché).
    const minuteries = [
      setInterval(majAge, 1000),
      setInterval(() => {
        if (!corps.isConnected) {   // widget retiré du tableau
          minuteries.forEach(clearInterval);
          document.removeEventListener('cm:voir-personnage', voirPersonnage);
          observateur.disconnect();
          [...ouvertes.keys()].forEach(cle => flottantOuvert(cle)?.fermer());
          return;
        }
        if (!enEcriture.size) relire();
      }, 5000),
    ];
    return {};
  },
};
