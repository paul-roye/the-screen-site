// Tableau de bord : en-tête, grille de widgets, dialogues (ajouter un outil, données, campagne).
// Ajouter un widget : écrire app/widgets/<type>.js (même forme que rencontres.js) et l'inscrire dans WIDGETS ; un widget
// propre à une campagne va dans un module de campagne (app/modules.js), chargé d'après le manifeste.
// monter() reçoit corps, actions (boutons de l'en-tête ; .cm-si-deplie : masqué quand le widget est réduit), resume (résumé
// de l'en-tête, visible même réduit), deplier(), ajusterHauteur() (le widget prend la hauteur de son contenu), reglages
// (réglages propres à chaque mode, gardés avec sa disposition : voir reglagesDe()), donnees, etat, campagne et dialogue.
// Quatre modes, Exploration, Ville, Voyage et Rencontre, chacun avec sa disposition (etat/tableau.json). Un widget présent
// dans plusieurs modes est le même (même clé, même instance) : il change seulement de place. Les widgets des autres modes
// restent montés, dans une réserve cachée : ils restent à jour, et le changement de mode est immédiat.

import { h, icone, bouton, badge, alerte, bascule, onglets, identifiant, activerInfobulles, boutonMenu } from './ui.js';
import { contenuLivres, contenuFiches } from './livres-beyond.js';
import { creerGrille } from './grille.js';
import { chargerCampagne, campagneOuverte, listerCampagnes, vocabulaire, appliquerCharte, listerChartes, listerMeteos, enregistrerManifeste, lireVersion } from './campagne.js';
import { CALENDRIERS, reglagesTemps } from './calendrier.js';
import { formulaireCampagne } from './config-campagne.js';
import { contenuImages } from './config-images.js';
import { chargerModules, preparerModules, MODULES_DISPONIBLES } from './modules.js';
import { chargerPlugins, contenuPlugins, pluginActif, pluginDe, PLUGINS } from './plugins.js';
import { emettre } from './evenements.js';
import { signature } from './signature.js';
import { etat, surStatut } from './etat.js';
import { FORMATS, chargerDonnees, libelleCondition } from './donnees.js';
import { ouvrirSession } from './session.js';
import { monterMenuRapide } from './menu-rapide.js';
import { surveillerDeparts } from './restes.js';
import { appliquerLargeur, activerDebogage, debogageActif, LARGEURS } from './debogage.js';
import { vueReglagesPoste } from './plugins/ecran-joueurs.js';
import { etatDeroule, orphelinsDeroule, retirerOrphelin, rattachementsPerimes } from './trame.js';
import { etatRencontresMj } from './rencontres-mj.js';
import rencontres from './widgets/rencontres.js';
import noms from './widgets/noms.js';
import maisons from './widgets/maisons.js';
import faune from './widgets/faune.js';
import trajets from './widgets/trajets.js';
import pnj from './widgets/pnj.js';
import marchands from './widgets/marchands.js';
import connaissances from './widgets/connaissances.js';
import deroule from './widgets/deroule.js';
import personnages from './widgets/personnages.js';
import images from './widgets/images.js';
import minuteur from './widgets/minuteur.js';
import convertisseur from './widgets/convertisseur.js';
import factions from './widgets/factions.js';
import babioles from './widgets/babioles.js';
import objets from './widgets/objets.js';
import ici from './widgets/ici.js';
import horloge from './widgets/horloge.js';
import combat from './widgets/combat.js';
import musique from './widgets/musique.js';
import des from './widgets/des.js';
import regles from './widgets/regles.js';

// Les widgets des modules de campagne (le Tarokka) s'y ajoutent au démarrage.
const WIDGETS = [personnages, combat, ici, horloge, rencontres, deroule, pnj, factions, trajets, marchands, objets, connaissances, images, musique, noms, babioles, maisons, faune, des, regles, minuteur, convertisseur];
const parType = new Map(WIDGETS.map(w => [w.type, w]));
// champ : où etat/tableau.json garde la disposition du mode. horsCombat : choisi sur le premier bouton de l'en-tête
// (Exploration, Ville ou Voyage, un menu sur le même bouton) ; Rencontre a le sien.
const MODES = {
  exploration: { libelle: 'Exploration', icone: 'carte', champ: 'widgets', horsCombat: true },
  ville: { libelle: 'Ville', icone: 'lu-house', champ: 'widgets_ville', horsCombat: true },
  voyage: { libelle: 'Voyage', icone: 'lu-route', champ: 'widgets_voyage', horsCombat: true },
  rencontre: { libelle: 'Rencontre', icone: 'epee', champ: 'widgets_rencontre' },
};
// Dispositions recommandées, une par mode (modeles/dispositions.json : celles du MJ, tirées de son tableau par
// mainteneur/recommander-dispositions.ps1, demande du 2026-10-27) : celles d'une campagne à la première ouverture d'un mode,
// et du bouton « Disposition recommandée ». Comme dans « Ajouter un outil », on n'y pose que ce que la campagne peut avoir
// (2026-11-08) : ni un widget sans ses données, ni celui d'un module ou d'un plugin qu'elle n'a pas ; le tableau se tasse.
// Les données arrivées ensuite : bouton « Disposition recommandée », ou « Ajouter un outil ».
async function lireDispositions() {
  try {
    const r = await fetch('/modeles/dispositions.json', { cache: 'no-store' });
    return r.ok ? await r.json() : {};
  } catch { return {}; }
}

const racine = document.getElementById('app');
appliquerLargeur();   // largeur simulée du mode débogage, avant de monter le tableau

if (location.protocol === 'file:') {
  racine.append(h('main', { class: 'cm-page' }, alerte('sang', 'lu-triangle-alert', 'Ouvrez le gestionnaire par le serveur local',
    'Le navigateur bloque la lecture de data/ quand la page est ouverte comme fichier. Double-cliquez « Lancer le gestionnaire.cmd » (ou lancez lancer.ps1) : la page s\'ouvrira sur http://localhost:8735/ (ou le port réglé par « port » dans poste.json).')));
} else {
  activerInfobulles();
  demarrer();
}

async function demarrer() {
  // La campagne ouverte (app/campagne.js) : titre, icône, thème de départ, charte.
  const manifeste = await chargerCampagne();
  await appliquerCharte(manifeste);
  document.title = `${manifeste.titre} · The Screen`;
  document.querySelector('link[rel="icon"]')?.setAttribute('href', `design-system/icons/${manifeste.icone}.svg`);
  // Modules de campagne (app/modules.js) : leurs fichiers de data/ et leurs widgets rejoignent les autres.
  for (const m of await chargerModules(manifeste.modules)) {
    Object.assign(FORMATS, m.formats || {});
    for (const w of m.widgets || []) { WIDGETS.push(w); parType.set(w.type, w); }
  }
  const tableau = await etat('tableau', { schema: 1, theme: manifeste.theme, verrou: false, mode: 'exploration', widgets: null, widgets_rencontre: null });
  const recommandees = await lireDispositions();
  if (!MODES[tableau.valeur.mode]) tableau.valeur.mode = 'exploration';
  const mode = () => tableau.valeur.mode;
  const autresModes = () => Object.keys(MODES).filter(m => m !== mode());
  const dispositionDe = m => tableau.valeur[MODES[m].champ];
  // Un widget est-il dans la disposition d'un mode qui n'est pas affiché ? (il reste alors monté, en réserve)
  const ailleurs = cle => autresModes().some(m => (dispositionDe(m) || []).some(e => e.cle === cle));
  // Le mode hors combat du premier bouton : celui affiché, sinon le dernier choisi (`mode_hors_combat`).
  const modeHorsCombat = () => (MODES[mode()].horsCombat ? mode() : MODES[tableau.valeur.mode_hors_combat]?.horsCombat ? tableau.valeur.mode_hors_combat : 'exploration');
  const campagneEtat = await etat('campagne', { schema: 1 });
  document.documentElement.dataset.theme = tableau.valeur.theme;

  // Contexte partagé par les widgets : le libellé d'une condition d'écart, d'après les données déjà lues.
  const donneesConnues = [];
  const campagne = {
    libelle: id => libelleCondition(id, ...donneesConnues),
  };
  const donnees = async jeu => {
    const l = await chargerDonnees(jeu);
    if (l.donnees && !donneesConnues.includes(l.donnees)) donneesConnues.push(l.donnees);
    majBadgeDonnees();
    return l;
  };
  // Le bouton Données de l'en-tête, posé plus bas : un module ou un plugin qui lit data/ avant l'en-tête (son badge se met à
  // jour à chaque lecture) ne doit pas planter dessus.
  let btnDonnees = null;
  await preparerModules({ donnees, etat });   // leurs données et leur état, avant les widgets qui les affichent
  // Plugins (app/plugins.js) : les actifs démarrent avant les widgets (ils écoutent dès le premier événement) ; les widgets
  // de tous les plugins sont connus (grisés dans « Ajouter un outil » quand leur plugin est inactif).
  await chargerPlugins({ etat, donnees, dialogue });
  for (const p of PLUGINS) for (const w of p.widgets || []) { WIDGETS.push(w); parType.set(w.type, w); }

  // ───── En-tête ─────
  const statut = h('div', { class: 'cm-statut' });
  // Un fichier bloqué (illisible, ou modifié dans un autre onglet : app/etat.js) : l'alerte reste, avec de quoi recharger.
  surStatut((err, bloque) => statut.replaceChildren(err ? alerte('sang', 'lu-triangle-alert', 'État non enregistré', err,
    bloque ? [' ', bouton('Recharger la page', { classe: 'bn-btn--s', icone: 'lu-rotate-ccw', onclick: () => location.reload() })] : null) : ''));

  btnDonnees = bouton('Données', { icone: 'lu-database', classe: 'bn-btn--s bn-btn--fantome', titre: 'Les données de jeu et leurs vérifications', onclick: () => ouvrirDonnees() });
  majBadgeDonnees();   // les lectures faites avant l'en-tête (modules, plugins) comptent aussi
  const btnCampagne = bouton('Campagne', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome', titre: 'Réglages de la campagne', onclick: () => ouvrirCampagne() });
  const btnSession = bouton('Session', { icone: 'livre', classe: 'bn-btn--s bn-btn--fantome', titre: 'Fin de session : l\'état de la campagne pour votre agent IA de campagne, et le retour de son analyse', onclick: () => ouvrirSession({ dialogue, donnees }) });
  const btnVerrou = bouton('', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => verrouiller(!tableau.valeur.verrou, true) });
  const btnTheme = bouton('', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => {
    tableau.valeur.theme = tableau.valeur.theme === 'nuit' ? 'parchemin' : 'nuit';
    document.documentElement.dataset.theme = tableau.valeur.theme;
    majTheme();
    tableau.enregistrer();
  } });
  // Libellé court : l'en-tête tient sur une ligne à 1280 px (demande du MJ, 2026-10-23).
  const btnAjouter = bouton('Outil', { icone: 'lu-plus', classe: 'bn-btn--s bn-btn--primaire', titre: 'Ajouter un outil au tableau', onclick: () => ouvrirAjout() });

  function majTheme() {
    const nuit = tableau.valeur.theme === 'nuit';
    btnTheme.replaceChildren(icone(nuit ? 'soleil' : 'lune'));
    btnTheme.setAttribute('aria-label', nuit ? 'Passer en thème Parchemin' : 'Passer en thème Nuit');
    btnTheme.title = btnTheme.getAttribute('aria-label');
  }
  // Un calendrier ou une météo de data/ que la campagne ne prend pas (elle a choisi ceux du gestionnaire, ou aucun : fenêtre
  // Campagne, section « Le temps ») : pas une alerte, seulement « Non utilisé » dans la fenêtre Données. Le texte dit pourquoi.
  function nonUtilise(jeu) {
    const t = reglagesTemps(campagneOuverte() || {});
    if (jeu === 'calendrier' && t.calendrier.type !== 'importe') {
      return t.calendrier.type === 'modele' ? `La campagne prend le calendrier ${CALENDRIERS.find(c => c.id === t.calendrier.modele)?.nom.toLowerCase() || t.calendrier.modele} du gestionnaire` : 'La campagne n\'a pas de calendrier';
    }
    if (jeu === 'meteo' && t.meteo.type !== 'importe') return t.meteo.type === 'modele' ? `La campagne prend la météo ${String(t.meteo.modele).replace(/^./, c => c.toUpperCase()).replace(/-(?=\d{4}-)/, ' ')} du gestionnaire` : 'La campagne n\'a pas de météo';
    return null;
  }

  function majBadgeDonnees() {
    Promise.all([Promise.all(Object.keys(FORMATS).map(chargerDonnees)), orphelins()]).then(([ls, orph]) => {
      // Un fichier absent n'est pas une alerte : une campagne n'a pas tous les fichiers (la fenêtre le montre quand même).
      // Un fichier que la campagne n'utilise pas non plus.
      const ko = ls.filter(l => l.statut !== 'absent' && !nonUtilise(l.jeu) && (l.statut !== 'ok' || l.problemes.length)).length + (orph.liste.length ? 1 : 0) + (orph.perimes.length ? 1 : 0);
      if (!btnDonnees) return;   // l'en-tête n'est pas encore là : il relancera le compte
      btnDonnees.querySelector('.cm-pastille')?.remove();
      if (ko) btnDonnees.append(h('span', { class: 'cm-pastille', 'aria-label': `${ko} à vérifier` }, String(ko)));
    });
  }
  // Suivi du déroulé (etat/deroule.json) qui renvoie à une étape, un jalon ou une piste disparus des données (format 2).
  async function orphelins() {
    const s = await etatDeroule(etat, chargerDonnees);
    const d = (await chargerDonnees('deroule-campagne')).donnees;
    const rencontresMj = await etatRencontresMj(etat);
    return { s, liste: orphelinsDeroule(s.valeur, d), perimes: rattachementsPerimes(rencontresMj.valeur.rencontres, d) };
  }
  majTheme();
  // À la première ouverture avec un déroulé au format 2, les jalons devenus pistes passent dans le suivi des pistes (mêmes dates).
  etatDeroule(etat, chargerDonnees).then(s => {
    if (!s.migration?.length) return;
    document.dispatchEvent(new CustomEvent('cm:annonce', { detail: {
      cle: 'migration-deroule', titre: 'Déroulé : suivi mis à jour', icone: 'lu-waypoints', couleur: 'brume',
      texte: `Devenus des pistes, avec leurs dates : ${s.migration.map(x => (x.avant === x.apres ? x.apres : `${x.avant} → ${x.apres}`)).join(', ')}.`,
    } }));
  });

  // Mode du tableau : Exploration, Ville ou Voyage sur le premier bouton (un clic : ce mode ; la flèche : le menu des
  // trois), Rencontre sur le second (demande du MJ, 2026-10-23 : pas un bouton de plus par mode).
  const surtitreEntete = h('span', { class: 'surtitre' });
  const zoneMode = h('div', { class: 'cm-entete__mode' });
  function majMode() {
    const hors = modeHorsCombat(), dehors = MODES[mode()].horsCombat;
    const btn = (id, contenu, attrs = {}) => h('button', { type: 'button', class: 'bn-btn bn-btn--s', 'aria-pressed': String(mode() === id), onclick: () => changerMode(id), ...attrs }, contenu);
    const fleche = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone cm-mode__fleche', 'aria-pressed': String(dehors),
      title: 'Exploration, Ville ou Voyage', 'aria-label': 'Choisir le mode : Exploration, Ville ou Voyage' }, icone('lu-chevron-down'));
    const [, menu] = boutonMenu(fleche, Object.entries(MODES).filter(([, m]) => m.horsCombat).map(([id, m]) => [m.libelle, `Mode ${m.libelle}`, () => changerMode(id), () => mode() === id]), 'Mode hors combat');
    zoneMode.replaceChildren(h('div', { class: 'bn-bascule cm-mode', role: 'group', 'aria-label': 'Mode du tableau' },
      h('span', { class: 'cm-mode__hors' }, btn(hors, [icone(MODES[hors].icone), h('span', {}, MODES[hors].libelle)]), fleche),
      btn('rencontre', [icone(MODES.rencontre.icone), h('span', {}, MODES.rencontre.libelle)])), menu);
    surtitreEntete.textContent = mode() === 'exploration' ? 'The Screen' : `The Screen · ${MODES[mode()].libelle}`;
    document.body.dataset.mode = mode();
  }

  // L'accueil : la liste des campagnes et « Nouvelle campagne ». Même avec une seule campagne, sinon une installation neuve
  // (la campagne témoin seule) n'aurait aucun chemin pour en créer une. Caché seulement sans dossier campagnes/ (pas d'accueil).
  const btnCampagnes = bouton('', { icone: 'lu-arrow-left-right', classe: 'bn-btn--s bn-btn--fantome', titre: 'Accueil : changer de campagne ou en créer une', hidden: true,
    onclick: () => { location.href = '/?choisir'; } });
  listerCampagnes().then(l => { btnCampagnes.hidden = !l.length; });
  // Gestionnaire modifié depuis sa version officielle (version.json, scripts/version.ps1) : on le dit, sauf au mainteneur.
  lireVersion().then(v => {
    if (!v?.modifie || v.mainteneur) return;
    document.dispatchEvent(new CustomEvent('cm:annonce', { detail: {
      cle: 'version', titre: 'Gestionnaire modifié', icone: 'lu-triangle-alert', couleur: 'cierge',
      texte: `${v.version ? `Le code ou les formats ne sont plus ceux de la version officielle ${v.version}` : 'Cette copie n\'a pas de version officielle (version.json)'} : les mises à jour officielles ne pourront plus s'appliquer sans perdre ces modifications, et les données doivent suivre les formats modifiés. Voir AGENTS.md.`,
    } }));
  });
  racine.append(h('header', { class: 'cm-entete' },
    h('div', { class: 'cm-entete__titres' },
      surtitreEntete,
      h('h1', { class: 'titre-l bn-neon bn-gresille' }, manifeste.titre)),
    zoneMode,
    // En haut à droite, la signature (auteur, version, « À propos ») ; les boutons dessous, au pied de l'en-tête.
    h('div', { class: 'cm-entete__droite' }, signature(manifeste.id),
      h('div', { class: 'bn-groupe cm-entete__outils' }, btnCampagnes, btnDonnees, btnCampagne, btnSession, btnVerrou, btnTheme, btnAjouter))),
    statut);

  // Annonces des widgets (la nuit tombe, repos long en retard…) : document.dispatchEvent(new CustomEvent('cm:annonce',
  // { detail: { cle, titre, texte, couleur, icone } })). Elles restent en haut de l'écran jusqu'à « Compris » ; même clé : remplacée.
  const annonces = h('div', { class: 'cm-annonces', 'aria-live': 'polite' });
  racine.append(annonces);
  document.addEventListener('cm:annonce', e => {
    const { cle, titre, texte, couleur = '', icone: ic = 'lu-info' } = e.detail || {};
    if (!titre) return;
    if (cle) annonces.querySelector(`[data-cle="${CSS.escape(cle)}"]`)?.remove();
    const a = alerte(couleur, ic, titre, texte || '', ' ', bouton('Compris', { classe: 'bn-btn--s', onclick: () => a.remove() }));
    if (cle) a.dataset.cle = cle;
    annonces.append(a);
  });

  // ───── Grille ─────
  const zone = h('main', { class: 'cm-tableau', 'aria-label': 'Outils du MJ' });
  racine.append(zone);
  const vide = h('div', { class: 'cm-tableau-vide', hidden: true },
    icone('brume', 'bn-icone--xl'), h('p', { class: 'ui-l' }, 'Le tableau est vide.'),
    bouton('Ajouter un outil', { icone: 'lu-plus', classe: 'bn-btn--primaire', onclick: () => ouvrirAjout() }));
  racine.append(vide);
  // Widgets de l'autre mode : montés, mais hors de la grille.
  const reserve = h('div', { class: 'cm-reserve', hidden: true, 'aria-hidden': 'true' });
  racine.append(reserve);

  const presents = new Map();    // cle -> type : widgets du mode affiché
  const instances = new Map();   // cle -> { type, el, majReduire } : widgets montés, dans la grille ou en réserve
  // Les réglages d'un widget propres au mode (`reglages` de son entrée dans la disposition) suivent ses déplacements.
  function sauverDisposition(disp) {
    const avant = new Map((dispositionDe(mode()) || []).map(e => [e.cle, e]));
    tableau.valeur[MODES[mode()].champ] = disp.map(i => ({ cle: i.cle, type: presents.get(i.cle), x: i.x, y: i.y, w: i.w, h: i.h,
      ...(i.reduit ? { reduit: true, hPlein: i.hPlein } : {}), ...(avant.get(i.cle)?.reglages ? { reglages: avant.get(i.cle).reglages } : {}) }));
    tableau.enregistrer();
    vide.hidden = presents.size > 0;
  }

  // Réglages d'un widget propres à chaque mode (affichage Basique / Étendu de Personnages…), gardés avec la disposition du
  // mode : lire(nom, défaut), ecrire(nom, valeur), surChangement(fn) : appelé quand le mode affiché change (le widget relit).
  const ecouteursReglages = new Map();   // cle -> Set de fonctions
  const entreeAffichee = cle => (dispositionDe(mode()) || []).find(e => e.cle === cle);
  function reglagesDe(cle) {
    return {
      lire: (nom, defaut) => entreeAffichee(cle)?.reglages?.[nom] ?? defaut,
      ecrire: (nom, valeur) => {
        const e = entreeAffichee(cle);
        if (!e) return;
        e.reglages = { ...e.reglages, [nom]: valeur };
        tableau.enregistrer();
      },
      surChangement: fn => { if (!ecouteursReglages.has(cle)) ecouteursReglages.set(cle, new Set()); ecouteursReglages.get(cle).add(fn); },
    };
  }
  const grille = creerGrille(zone, { surChangement: sauverDisposition });

  let menuRapide = null;   // monté plus bas, une fois les widgets en place
  function verrouiller(v, sauver) {
    tableau.valeur.verrou = v;
    grille.verrouiller(v);
    menuRapide?.verrouiller(v);
    btnVerrou.replaceChildren(icone(v ? 'lu-lock' : 'lu-lock-open'));
    btnVerrou.setAttribute('aria-pressed', String(v));
    btnVerrou.setAttribute('aria-label', v ? 'Déverrouiller la disposition' : 'Verrouiller la disposition');
    btnVerrou.title = btnVerrou.getAttribute('aria-label');
    if (sauver) tableau.enregistrer();
  }
  verrouiller(!!tableau.valeur.verrou, false);

  // Monter un widget (une fois par clé) : son élément est rangé par l'appelant, dans la grille ou en réserve.
  function instance(cle, type) {
    if (instances.has(cle)) return instances.get(cle);
    const def = parType.get(type);
    const corps = h('div', { class: 'bn-widget__corps' });
    const actions = h('div', { class: 'bn-widget__actions' });
    // Résumé dans l'en-tête (étape en cours, cartes du tirage…), visible même réduit ; data-quand="reduit" : seulement réduit.
    const resume = h('div', { class: 'bn-widget__resume' });
    const idTitre = 'w-' + cle;
    const btnReduire = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone bn-btn--fantome', 'aria-controls': 'c-' + cle });
    corps.id = 'c-' + cle;
    const el = h('section', { class: 'bn-panel bn-widget' + (def.compact ? ' bn-widget--compact' : ''), 'aria-labelledby': idTitre, 'data-type': type },
      h('header', { class: 'bn-widget__tete' },
        h('button', {
          type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone bn-btn--fantome bn-widget__poignee',
          'aria-label': `Déplacer « ${def.titre} » (flèches ; Maj et flèches pour la taille)`, title: 'Glisser pour déplacer',
        }, icone('lu-grip-vertical')),
        h('div', { class: 'bn-widget__titres' },
          vocabulaire(def.surtitre) ? h('span', { class: 'surtitre' }, vocabulaire(def.surtitre)) : null,   // « Bêtes {de_monde} » : app/campagne.js
          h('h2', { class: 'bn-widget__titre', id: idTitre }, icone(def.icone, 'cm-widget-icone'), ' ', def.titre)),
        resume,
        actions,
        btnReduire,
        bouton('', { icone: 'lu-x', titre: `Retirer « ${def.titre} » du tableau`, classe: 'bn-btn--s bn-btn--fantome bn-widget__fermer', onclick: () => retirer(cle) })),
      corps,
      h('span', { class: 'bn-widget__redim', title: 'Glisser pour redimensionner' }));
    // Réduire : bouton chevron, ou double-clic sur l'en-tête (hors boutons).
    const majReduire = r => {
      btnReduire.replaceChildren(icone(r ? 'lu-chevron-down' : 'lu-chevron-up'));
      btnReduire.setAttribute('aria-expanded', String(!r));
      btnReduire.setAttribute('aria-label', `${r ? 'Déplier' : 'Réduire'} « ${def.titre} »`);
      btnReduire.title = r ? 'Déplier' : 'Réduire';
      corps.hidden = r;
    };
    const basculerReduit = () => { const r = !grille.estReduit(cle); grille.reduire(cle, r); majReduire(r); };
    btnReduire.addEventListener('click', basculerReduit);
    el.querySelector('.bn-widget__tete').addEventListener('dblclick', e => { if (!e.target.closest('button, input, select, textarea, a')) basculerReduit(); });
    const inst = { type, el, majReduire };
    instances.set(cle, inst);
    // Mettre le widget à la hauteur de son contenu, sans défilement (Personnages, au changement d'affichage) : mesuré une fois
    // la page redessinée. Seulement dans le mode affiché, déplié.
    const ajusterHauteur = () => requestAnimationFrame(() => requestAnimationFrame(() => {
      if (!presents.has(cle) || grille.estReduit(cle) || !corps.clientHeight) return;
      const r = corps.getBoundingClientRect();
      const bas = Math.max(r.top, ...[...corps.children].filter(e => e.getClientRects().length).map(e => e.getBoundingClientRect().bottom));
      const contenu = bas - r.top + corps.scrollTop + parseFloat(getComputedStyle(corps).paddingBottom);
      grille.hauteurPx(cle, contenu + el.getBoundingClientRect().height - corps.clientHeight);
    }));
    Promise.resolve()
      .then(() => def.monter({ corps, actions, resume, deplier: () => { if (grille.estReduit(cle)) basculerReduit(); }, ajusterHauteur, reglages: reglagesDe(cle), donnees, etat, campagne, dialogue }))
      .catch(err => {
        console.error(err);
        corps.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Ce widget a planté', String(err?.message || err)));
      });
    return inst;
  }

  // Poser un widget dans la grille du mode affiché (monté au besoin). Réduit ou non : propre à chaque mode.
  // differe : disposition enregistrée posée d'un bloc (afficher), tassée une seule fois ensuite (grille.poserTout).
  function placer({ cle, type, x, y, w, h: haut, reduit, hPlein }, differe = false) {
    const def = parType.get(type);
    if (!def) return;
    const inst = instance(cle, type);
    presents.set(cle, type);
    grille.ajouter({ cle, x, y, w: w || def.taille.w, h: haut || def.taille.h, min: def.min, el: inst.el, reduit: !!reduit, hPlein, differe });
    inst.majReduire(!!reduit);
    vide.hidden = true;
  }

  // Retirer du mode affiché. Encore dans l'autre mode : il reste monté, en réserve ; sinon il est détruit
  // (ses minuteries s'arrêtent quand son élément quitte la page).
  function retirer(cle) {
    presents.delete(cle);
    grille.retirer(cle);
    if (ailleurs(cle)) reserve.append(instances.get(cle).el);
    else instances.delete(cle);
  }

  // Un widget unique déjà monté garde sa clé (donc son instance) quand on l'ajoute à l'autre mode.
  const cleDe = type => (parType.get(type)?.unique && [...instances].find(([, i]) => i.type === type)?.[0]) || identifiant();

  // Afficher la disposition du mode courant ; la première fois, la recommandée du mode (les widgets uniques déjà montés pour
  // un autre mode y sont repris : même instance).
  function afficher() {
    reserve.append(...grille.vider());
    presents.clear();
    let d = dispositionDe(mode());
    if (!d) {
      d = (Array.isArray(recommandees[mode()]) ? recommandees[mode()] : []).filter(w => recommandable(w.type)).map(w => ({ ...w, cle: cleDe(w.type) }));
      tableau.valeur[MODES[mode()].champ] = d;
      tableau.enregistrer();
    }
    d.forEach(e => placer(e, true));
    grille.poserTout();
    vide.hidden = presents.size > 0;
    for (const cle of presents.keys()) ecouteursReglages.get(cle)?.forEach(fn => fn());   // réglages du mode affiché
  }

  function changerMode(m) {
    if (m === mode() || !MODES[m]) return;
    tableau.valeur.mode = m;
    if (MODES[m].horsCombat) tableau.valeur.mode_hors_combat = m;
    tableau.enregistrer();
    afficher();
    majMode();
    window.scrollTo({ top: 0 });
    emettre('mode:change', { mode: m });
  }

  // Un widget demande un mode, et au besoin un outil dans ce mode (« Lancer » une rencontre : mode Rencontre, widget Combat) :
  // document.dispatchEvent(new CustomEvent('cm:mode', { detail: { mode, widget } })). L'outil absent est posé à une place libre.
  document.addEventListener('cm:mode', e => {
    const { mode: m, widget } = e.detail || {};
    if (!MODES[m]) return;
    changerMode(m);
    const def = parType.get(widget);
    if (def && ![...presents.values()].includes(widget)) {
      placer({ cle: cleDe(widget), type: widget, ...grille.placeLibre(def.taille.w), h: def.taille.h });
      sauverDisposition(grille.disposition());
    }
    const el = [...instances.values()].find(i => i.type === widget)?.el;
    if (el && presents.size) requestAnimationFrame(() => el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
  });

  // Ce que la campagne peut avoir sur son tableau, pour les dispositions recommandées (lu une fois : « Disposition recommandée »
  // recharge la page).
  const sansDonnees = await typesSansDonnees();
  const recommandable = type => { const def = parType.get(type); return !!def && !sansDonnees.has(type) && !(def.plugin && !pluginActif(def.plugin)); };
  // Les autres modes d'abord, en réserve : leurs widgets uniques gardent leur clé si le mode affiché part de sa disposition
  // de départ.
  for (const m of autresModes()) for (const e of dispositionDe(m) || []) if (parType.has(e.type)) reserve.append(instance(e.cle, e.type).el);
  afficher();
  majMode();
  menuRapide = monterMenuRapide({ donnees, etat, dialogue });   // raccourcis sur le bord gauche, dans les deux modes
  menuRapide.verrouiller(!!tableau.valeur.verrou);
  surveillerDeparts({ donnees, etat, dialogue });   // alerte en quittant un lieu, fenêtre de fin d'un trajet
  appliquerLargeur();   // de nouveau, la barre de défilement de la page maintenant là
  aideDemarrage();

  // ───── Aide de démarrage d'une nouvelle campagne (demande du MJ, 2026-10-25) ─────
  // Le serveur crée etat/demarrage.json ({ montrer: true }) avec la campagne ; la fenêtre revient à chaque ouverture tant que
  // le MJ n'a pas cliqué « Ne plus montrer ». Une campagne sans ce fichier (créée avant cette aide, ou la témoin) ne la voit jamais.
  async function aideDemarrage() {
    const s = await etat('demarrage', { schema: 1, montrer: false });
    if (!s.valeur.montrer) return;
    const id = campagneOuverte()?.id || '<identifiant>';
    const etape = (titre, ...texte) => h('li', {}, h('b', {}, titre), ' ', ...texte);
    let dlg;
    dlg = dialogue('Nouvelle campagne', 'Bienvenue dans votre campagne', h('div', { class: 'cm-pile ui' },
      h('p', {}, 'La campagne est créée, mais encore vide : le gestionnaire n\'a ni lieux, ni PNJ, ni déroulé à vous montrer. Voici ce qu\'il reste à faire, dans l\'ordre qui vous conviendra.'),
      h('ol', { class: 'cm-liste cm-pile' },
        etape('Ses données.', `Ce sont des fichiers à écrire à la main ou, plus simplement, avec un agent IA de campagne qui lit votre matériel (livres, PDF, notes). Donnez-lui les instructions du dossier campagnes/${id}/data/LISEZMOI.md et les fiches de formats/, puis rangez ce qu'il produit dans campagnes/${id}/data/. Commencez par le minimum : les lieux, les PNJ et le déroulé de la campagne. Rechargez la page, puis vérifiez les fichiers avec le bouton Données de l'en-tête.`),
        etape('Ses réglages.', 'Le bouton Campagne de l\'en-tête : le calendrier et la météo, la campagne D&D Beyond des héros, le wiki, la charte, les mots du monde.'),
        etape('Ses héros.', 'Avec la campagne D&D Beyond réglée, l\'extension du MJ (extensions/mj/) relève les fiches des héros dans le widget Personnages.'),
        etape('Son tableau.', 'Le bouton Outil ajoute des widgets ; chaque mode (Exploration, Ville, Voyage, Rencontre) a sa disposition. Le tableau de départ ne montre que les outils dont la campagne a déjà les données ; les autres s\'y montrent en grisé, avec la raison. Une fois vos fichiers rangés, le bouton Disposition recommandée, en bas de la même fenêtre, les pose à leur place.'),
        etape('Après chaque séance.', 'Le bouton Session prépare un résumé de la séance pour votre agent IA de campagne ; sa réponse met à jour l\'avancée de la campagne.')),
      h('p', { class: 'ui-s cm-sourdine' }, 'Cette aide revient à chaque ouverture de la campagne, jusqu\'à « Ne plus montrer ».')),
    h('div', { class: 'bn-groupe' },
      bouton('Ne plus montrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => { s.valeur.montrer = false; s.enregistrer(0); dlg.close(); } }),
      bouton('Fermer', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })), { large: true });
  }

  // ───── Dialogues ─────
  // Aussi passé aux widgets (fiche d'un PNJ depuis un marchand…). options.large : 860px au lieu de 560px.
  function dialogue(surtitre, titre, contenu, pied, options = {}) {
    const dlg = h('dialog', { class: 'bn-dialogue' + (options.large ? ' bn-dialogue--large' : ''), 'aria-label': titre },
      h('div', { class: 'bn-panel' },
        h('div', { class: 'bn-panel__tete' },
          h('div', { class: 'bn-panel__titres' }, h('span', { class: 'surtitre' }, surtitre), h('h2', { class: 'titre-m' }, titre)),
          bouton('', { icone: 'lu-x', titre: 'Fermer', classe: 'bn-btn--s bn-btn--fantome', onclick: () => dlg.close() })),
        h('div', { class: 'bn-panel__corps' }, contenu),
        pied ? h('div', { class: 'bn-panel__pied' }, pied) : null));
    dlg.addEventListener('close', () => dlg.remove());
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    document.body.append(dlg);
    dlg.showModal();
    return dlg;
  }

  // Les widgets dont un fichier de data/ requis est absent : ni proposés (nommés en bas de la fenêtre), ni posés d'office.
  async function typesSansDonnees() {
    return new Set((await Promise.all(WIDGETS.filter(w => w.requiert).map(async w => ((await chargerDonnees(w.requiert)).statut === 'absent' ? w.type : null)))).filter(Boolean));
  }

  async function ouvrirAjout() {
    let dlg;
    const absents = await typesSansDonnees();
    // Les outils qu'on ne peut pas ajouter restent visibles, grisés, avec la raison (demande du MJ, 2026-10-25) : leurs données
    // manquent, ou ils appartiennent à un module que la campagne n'a pas.
    const indisponible = (titre, ic, description, raison) => h('div', { class: 'bn-carte cm-choix cm-choix--indisponible', 'aria-disabled': 'true' },
      h('span', { class: 'cm-choix__tete' }, icone(ic || 'lu-puzzle', 'bn-icone--l'), h('span', { class: 'cm-choix__nom' }, titre), badge('Indisponible', null, 'lu-lock')),
      h('span', { class: 'ui-s cm-sourdine' }, description),
      h('span', { class: 'ui-s cm-choix__raison' }, raison));
    const actifs = new Set(campagneOuverte()?.modules || []);
    // Le widget d'un plugin inactif (app/plugins.js) : grisé, avec où l'activer.
    const sansPlugin = w => w.plugin && !pluginActif(w.plugin);
    const grises = [
      ...WIDGETS.filter(w => absents.has(w.type)).map(w => indisponible(w.titre, w.icone, w.description,
        `Il lui faut data/${w.requiert}.json, que cette campagne n'a pas encore : écrivez-le d'après formats/${w.requiert}.md, à la main ou avec votre agent IA de campagne, puis rechargez la page.`)),
      ...WIDGETS.filter(sansPlugin).map(w => indisponible(w.titre, w.icone, w.description,
        `Plugin « ${pluginDe(w.plugin)?.titre || w.plugin} » désactivé : activez-le dans la fenêtre Campagne, onglet Plugins.`)),
      ...MODULES_DISPONIBLES.filter(x => !actifs.has(x.id)).map(x => indisponible(x.titre, x.icone, x.description,
        `Module de campagne que cette campagne n'a pas : un module se choisit à la création de la campagne (accueil, « Nouvelle campagne »)${x.genre ? ', et celui-ci ne marche qu\'avec une campagne Curse of Strahd' : ''}.`)),
    ];
    const cartes = WIDGETS.filter(w => !absents.has(w.type) && !sansPlugin(w)).map(w => {
      const deja = w.unique && [...presents.values()].includes(w.type);
      return h('button', {
        type: 'button', class: 'bn-carte cm-choix', disabled: deja,
        onclick: () => {
          const p = grille.placeLibre(w.taille.w);
          placer({ cle: cleDe(w.type), type: w.type, ...p, h: w.taille.h });
          sauverDisposition(grille.disposition());
          dlg.close();
        },
      },
        h('span', { class: 'cm-choix__tete' }, icone(w.icone, 'bn-icone--l'), h('span', { class: 'cm-choix__nom' }, w.titre),
          deja ? badge('Sur le tableau', 'brume', 'lu-check') : null),
        h('span', { class: 'ui-s cm-sourdine' }, w.description));
    });
    const libelleMode = MODES[mode()].libelle;
    dlg = dialogue(`Tableau · ${libelleMode}`, 'Ajouter un outil', h('div', { class: 'cm-pile' },
      h('div', { class: 'cm-choix-grille' }, cartes, grises)),
      bouton('Disposition recommandée', { icone: 'lu-layout-grid', classe: 'bn-btn--s bn-btn--fantome', titre: `Les outils recommandés du mode ${libelleMode}, à leur place`, onclick: () => {
        if (!confirm(`Remplacer la disposition du mode ${libelleMode} par la disposition recommandée ? Les autres modes ne changent pas ; les tirages, journaux et notes sont conservés.`)) return;
        tableau.valeur[MODES[mode()].champ] = null;   // la recommandée, recréée au rechargement
        tableau.enregistrer(0);
        setTimeout(() => location.reload(), 150);
      } }), { large: true });
  }

  async function ouvrirDonnees() {
    const lectures = await Promise.all(Object.keys(FORMATS).map(chargerDonnees));
    const zoneEtat = h('div');
    dialogue('Fichiers de data/', 'Données', h('div', { class: 'cm-pile' },
      zoneEtat,
      lectures.map(l => {
        const ok = l.statut === 'ok' && !l.problemes.length;
        const nu = l.statut !== 'absent' ? nonUtilise(l.jeu) : null;
        if (nu) {
          return h('div', { class: 'bn-carte' },
            h('div', { class: 'cm-fiche__tete' }, h('span', { class: 'cm-choix__nom' }, l.donnees?.titre || l.jeu), badge('Non utilisé', null)),
            h('p', { class: 'des cm-sourdine' }, l.fichier),
            h('p', { class: 'ui-s' }, `${nu} (fenêtre Campagne, section « Le temps ») : ce fichier n'est pas lu. Il peut être retiré de data/, ou choisi comme ${l.jeu === 'calendrier' ? '« Calendrier importé » (au format 2 : 365 jours)' : '« Météo importée »'}.`),
            ok ? null : h('p', { class: 'ui-s cm-sourdine' }, `S'il servait, il serait à reprendre : ${l.problemes[0] || 'illisible'}`));
        }
        return h('div', { class: 'bn-carte' },
          h('div', { class: 'cm-fiche__tete' },
            h('span', { class: 'cm-choix__nom' }, l.donnees?.titre || l.jeu),
            ok ? badge('À jour', 'brume', 'lu-check') : l.statut === 'absent' ? (l.facultatif ? badge('Facultatif', null) : badge('Absent', 'cierge')) : l.schemaRecu !== undefined ? badge(`Format ${l.schemaRecu} refusé`, 'sang') : badge(l.statut === 'ok' ? 'À vérifier' : 'Illisible', l.statut === 'ok' ? 'cierge' : 'sang')),
          h('p', { class: 'des cm-sourdine' }, l.fichier + (l.donnees ? ` · format ${l.converti ?? l.donnees.schema} · généré le ${l.donnees.genere_le}` : '')),
          // Ancien format converti au chargement (app/conversions.js) : il marche, l'agent IA de campagne le réexportera.
          l.converti ? h('p', { class: 'ui-s' }, badge(`Format ${l.converti} converti`, 'ultra', 'lu-refresh-cw'), ` Lu au format ${l.donnees.schema} par une conversion au chargement : rien à faire tout de suite, à réexporter au format ${l.donnees.schema} à la prochaine occasion (formats/${l.jeu}.md).`) : null,
          l.problemes.length ? h('ul', { class: 'ui-s cm-liste' }, l.problemes.slice(0, 20).map(p => h('li', {}, p)),
            l.problemes.length > 20 ? h('li', {}, `… et ${l.problemes.length - 20} autres.`) : null) : null,
          h('p', { class: 'ui-s cm-sourdine' }, `Format : formats/${l.jeu}.md`));
      }),
      h('p', { class: 'ui-s cm-sourdine' }, 'Ces fichiers s\'écrivent à la main ou avec votre agent IA de campagne. Une erreur se corrige à sa source, puis le fichier est réécrit (voir formats/README.md). Rechargez la page après avoir remplacé un fichier.')));
    // État de la campagne qui renvoie à un élément disparu du déroulé (renommé ou retiré à un export) : gardé, à retirer ici.
    const GENRES = { reference: 'étape de référence', etape: 'étape', jalon: 'jalon', piste: 'piste' };
    async function majEtat() {
      const { s, liste, perimes } = await orphelins();
      const cartePerimes = perimes.length ? h('div', { class: 'bn-carte' },
        h('div', { class: 'cm-fiche__tete' }, h('span', { class: 'cm-choix__nom' }, 'Rattachements de rencontres'), badge('À vérifier', 'cierge')),
        h('p', { class: 'des cm-sourdine' }, 'etat/rencontres-mj.json'),
        h('p', { class: 'ui-s' }, 'Ces rencontres gardent un rattachement que deroule-campagne.json ne confirme plus. Il est ignoré, mais pas effacé : à rattacher ailleurs si besoin.'),
        h('ul', { class: 'cm-confirmation__pnj' }, perimes.map(x => h('li', {}, h('span', { class: 'ui-s' }, h('b', {}, x.nom), h('span', { class: 'cm-sourdine' }, x.jalon ? ` · jalon ${x.jalon}` : ` · étape ${x.etape}`)))))) : null;
      if (!liste.length) { zoneEtat.replaceChildren(...(cartePerimes ? [cartePerimes] : [])); return; }
      const retirer = xs => { xs.forEach(x => retirerOrphelin(s.valeur, x)); s.enregistrer(0); s.signaler(); majEtat(); majBadgeDonnees(); };
      zoneEtat.replaceChildren(...[cartePerimes, h('div', { class: 'bn-carte' },
        h('div', { class: 'cm-fiche__tete' }, h('span', { class: 'cm-choix__nom' }, 'Suivi du déroulé'), badge('À vérifier', 'cierge')),
        h('p', { class: 'des cm-sourdine' }, 'etat/deroule.json'),
        h('p', { class: 'ui-s' }, 'Ces éléments sont notés dans le suivi, mais n\'existent plus dans deroule-campagne.json (ni en jalon, ni en piste). Ils restent dans l\'état tant que vous ne les retirez pas.'),
        h('ul', { class: 'cm-confirmation__pnj' }, liste.map(x => {
          const suivi = x.genre === 'reference' ? null : s.valeur.suivi?.[{ etape: 'etapes', jalon: 'jalons', piste: 'pistes' }[x.genre]]?.[x.id];
          return h('li', {}, h('span', { class: 'ui-s' }, h('b', {}, x.id), h('span', { class: 'cm-sourdine' }, ` · ${GENRES[x.genre]}${suivi ? (suivi.fin ? ', terminé' : ', en cours') : ''}`)),
            bouton('Retirer', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'Retirer du suivi (etat/deroule.json)', onclick: () => retirer([x]) }));
        })),
        liste.length > 1 ? h('div', { class: 'bn-groupe' }, bouton('Tout retirer', { classe: 'bn-btn--s', icone: 'lu-trash-2', onclick: () => retirer(liste) })) : null)].filter(Boolean));
    }
    majEtat();
  }

  // Réglages de la campagne : rencontres, livres et fiches de D&D Beyond (app/livres-beyond.js), plugins (app/plugins.js), ce
  // poste. Plus de conditions de campagne à cocher (demande du MJ, 2026-10-23) : les écarts conditionnels sont une information.
  async function ouvrirCampagne() {
    const zoneLivres = h('div', {});
    contenuLivres(etat).then(z => zoneLivres.replaceChildren(z));
    const zoneFiches = h('div', {});
    let zoneImages = null;   // sources et import de la bibliothèque d'images (app/config-images.js), au premier affichage
    contenuFiches(etat).then(z => zoneFiches.replaceChildren(z));
    // Rencontres (demande du MJ, 2026-10-23) : la difficulté selon Flee, Mortals! (app/difficulte.js), activable, et le compte
    // des compagnons ; `difficulte` de etat/campagne.json, signalé aux préparations et au widget Combat.
    const reglageDifficulte = (cle, defaut) => campagneEtat.valeur.difficulte?.[cle] ?? defaut;
    const ecrireDifficulte = (cle, oui) => {
      campagneEtat.valeur.difficulte = { ...(campagneEtat.valeur.difficulte || {}), [cle]: oui };
      campagneEtat.enregistrer(0);
      campagneEtat.signaler();
    };
    const vueRencontres = () => {
      const caseCompagnons = h('input', { type: 'checkbox', class: 'bn-case', checked: reglageDifficulte('compagnons', true), disabled: !reglageDifficulte('actif', true), onchange: e => ecrireDifficulte('compagnons', e.target.checked) });
      // Un seul encadré : l'option, puis dessous, en retrait, le réglage qui en dépend (demande du MJ, 2026-10-23), éteint
      // avec elle.
      const sous = h('label', { class: 'cm-case cm-reglage__sous' }, caseCompagnons,
        h('span', {}, h('b', {}, 'Compter les compagnons pour le calcul du budget de FP'), h('br'),
          h('span', { class: 'ui-s cm-sourdine' }, 'Un compagnon compte comme un personnage de 2 niveaux de moins que son maître, 1 au moins ; pas pour le plafond de FP.')));
      // Rôles des monstres (demande du MJ, 2026-10-23) : seulement utiles avec des monstres qui en portent.
      const caseRoles = h('input', { type: 'checkbox', class: 'bn-case', checked: reglageDifficulte('roles', true), onchange: e => ecrireDifficulte('roles', e.target.checked) });
      const sousRoles = h('label', { class: 'cm-case cm-reglage__sous' }, caseRoles,
        h('span', {}, h('b', {}, 'Rôles des monstres'), h('br'),
          h('span', { class: 'ui-s cm-sourdine' }, 'Pour les monstres de Flee, Mortals!, ou des homebrews qui portent ces rôles (sous-type Solo, Minion, Brute…) : le rôle est lu sur D&D Beyond et se choisit dans la préparation ; sbires et solos changent le calcul de la difficulté. Décoché : pas de rôle, toutes les créatures comptent comme standard.')));
      const eteindre = oui => { [caseCompagnons, caseRoles].forEach(c => { c.disabled = oui; }); [sous, sousRoles].forEach(s => s.classList.toggle('est-eteint', oui)); };
      eteindre(!reglageDifficulte('actif', true));
      return h('div', { class: 'cm-reglage' },
        h('label', { class: 'cm-case' },
          h('input', { type: 'checkbox', class: 'bn-case', checked: reglageDifficulte('actif', true), onchange: e => { ecrireDifficulte('actif', e.target.checked); eteindre(!e.target.checked); } }),
          h('span', {}, h('b', {}, 'Difficulté des rencontres selon Flee, Mortals!'), h('span', { class: 'cm-sourdine' }, ' (MCDM)'), h('br'),
            h('span', { class: 'ui-s cm-sourdine' }, 'Les règles de construction des rencontres de Flee, Mortals! : budget de FP par rencontre, plafond de FP, points de la journée d\'aventure, avec leur aide. Dans la préparation des rencontres, leurs lignes et le widget Combat. Décoché : rien de tout cela n\'est affiché.'))),
        sous, sousRoles);
    };
    // Ce poste (2026-10-23) : réglages propres à ce navigateur, pas à la campagne ; le mode débogage (app/debogage.js) ;
    // l'écran des joueurs de ce PC (plugin app/plugins/ecran-joueurs.js : quel écran, la largeur de sa dalle, la mire).
    const vuePoste = () => h('div', { class: 'cm-pile' },
      h('div', { class: 'cm-reglage' },
        h('label', { class: 'cm-case' },
          h('input', { type: 'checkbox', class: 'bn-case', checked: debogageActif(), onchange: e => activerDebogage(e.target.checked) }),
          h('span', {}, h('b', {}, 'Mode débogage'), h('br'),
            h('span', { class: 'ui-s cm-sourdine' }, `Outils pour tester l'affichage, sur ce navigateur seulement : dans le menu rapide, une largeur d'écran simulée (${LARGEURS.map(([l]) => l).join(', ')} px). Les fenêtres flottantes, menus et dés gardent la vraie largeur.`)))),
      vueReglagesPoste());
    // La campagne elle-même (son manifeste, app/config-campagne.js) : titre, charte, vocabulaire, liens (D&D Beyond, wiki,
    // agent IA). Enregistré par le serveur ; la page se recharge pour tout appliquer (charte, titre, wiki).
    const zoneConfig = h('div', {}, h('p', { class: 'ui-s cm-sourdine' }, 'Chargement…'));
    // Calendrier et météo importés dans data/ : proposés seulement s'ils existent.
    const existe = f => fetch(f, { method: 'HEAD', cache: 'no-store' }).then(r => r.ok).catch(() => false);
    Promise.all([listerChartes(), fetch('design-system/icons/icons.json').then(r => r.json()).catch(() => ({})), listerMeteos(), existe('data/calendrier.json'), existe('data/meteo.json')]).then(([chartes, icones, meteos, aCal, aMeteo]) => {
      const f = formulaireCampagne(manifeste, { chartes, icones: Object.keys(icones).sort((a, b) => a.localeCompare(b, 'fr')), modules: MODULES_DISPONIBLES, meteos, importes: { calendrier: aCal, meteo: aMeteo } });
      const erreur = h('div');
      zoneConfig.replaceChildren(f.element, erreur, h('div', { class: 'bn-groupe' },
        bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', titre: 'Enregistrer les réglages de la campagne, puis recharger la page', onclick: async () => {
          try {
            await enregistrerManifeste(f.lire());
            location.reload();
          } catch (e) { erreur.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Réglages non enregistrés', e.message)); }
        } })));
    });
    const { barre, zone } = onglets('Réglages de la campagne', [
      { id: 'campagne', libelle: 'Campagne', icone: manifeste.icone, rendu: () => zoneConfig },
      { id: 'rencontres', libelle: 'Rencontres', icone: 'lu-swords', rendu: vueRencontres },
      { id: 'livres', libelle: 'Livres D&D Beyond', icone: 'livre', rendu: () => zoneLivres },
      { id: 'images', libelle: 'Images', icone: 'lu-image', rendu: () => (zoneImages ||= contenuImages(manifeste)) },
      { id: 'fiches', libelle: 'Fiches D&D Beyond', icone: 'lu-users', rendu: () => zoneFiches },
      { id: 'plugins', libelle: 'Plugins', icone: 'lu-plug', rendu: () => contenuPlugins() },   // connexions à des appareils ou services (app/plugins.js)
      { id: 'poste', libelle: 'Ce poste', icone: 'lu-monitor', rendu: vuePoste },
    ], 'campagne');
    dialogue('État de la campagne', 'Campagne', h('div', { class: 'cm-pile' }, barre, zone), null, { large: true });
  }
}
