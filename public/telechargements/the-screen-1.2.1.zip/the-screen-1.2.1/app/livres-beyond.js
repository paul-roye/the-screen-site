// Livres de D&D Beyond où chercher les monstres (rencontres du MJ) et les objets (app/objets.js) : réglage de la campagne,
// gardé dans etat/campagne.json (« livres_beyond », formats/etat.md), modifiable dans la fenêtre Campagne de l'en-tête
// (contenuLivres()). Sans réglage : ceux du manifeste de la campagne (`livres_beyond`, app/campagne.js), sinon les livres de
// règles 2024 (LIVRES_BASE). Pour les objets, en plus : le contenu partenaire débloqué (Partnered Content : éditeurs tiers,
// comme MCDM pour Flee, Mortals!) et les homebrews de la campagne.
// La liste de tous les livres vient du dictionnaire de D&D Beyond, lu par l'extension (commande « config », depuis 1.8.0).

import { h, alerte, normaliser } from './ui.js';
import { demanderExtension, lireBeyond } from './beyond.js';
import { campagneOuverte } from './campagne.js';

// [id de source de D&D Beyond, sigle, titre] : filtre « Source » de dndbeyond.com/monsters. Règles de base 2024
// (gratuites) : les armes et armures ordinaires (Dagger, Chain Mail…) n'ont que cette source au catalogue, pas le Player's
// Handbook (relevé du 2026-10-21).
export const LIVRES_BASE = [
  [147, 'MM', 'Monster Manual (2024)'],
  [146, 'DMG', 'Dungeon Master’s Guide (2024)'],
  [145, 'PHB', 'Player’s Handbook (2024)'],
  [148, 'BR', 'D&D Beyond Basic Rules (2024)'],
];
// Livres de départ de la campagne : `livres_beyond` du manifeste ([{ id, sigle, titre }]), sinon LIVRES_BASE.
function livresDefaut() {
  const l = campagneOuverte().livres_beyond;
  return Array.isArray(l) && l.length ? l.map(s => [s.id, s.sigle, s.titre]) : LIVRES_BASE;
}

let sCampagne = null;
const abonnes = new Set();

export async function chargerLivres(etat) {
  sCampagne ||= await etat('campagne', { schema: 1 });
  return livres();
}

// { liste: [[id, sigle, titre]], ids: [id], sigle: Map(id -> sigle), partenaires, homebrew }. Synchrone après chargerLivres().
export function livres() {
  const r = sCampagne?.valeur?.livres_beyond;
  const liste = Array.isArray(r?.sources) && r.sources.length ? r.sources.map(s => [s.id, s.sigle, s.titre]) : livresDefaut();
  return {
    liste, ids: liste.map(s => s[0]), sigle: new Map(liste.map(([id, sigle]) => [id, sigle])),
    partenaires: r?.partenaires ?? true, homebrew: r?.homebrew ?? true, homebrew_monstres: r?.homebrew_monstres ?? true,
  };
}

// Prévient les recherches (bestiaire, catalogue d'objets) que les livres ont changé : elles se rechargent.
export const surChangementLivres = fn => { abonnes.add(fn); return () => abonnes.delete(fn); };

function enregistrer(modif) {
  const v = sCampagne.valeur;
  const actuel = livres();
  v.livres_beyond = { sources: actuel.liste.map(([id, sigle, titre]) => ({ id, sigle, titre })), partenaires: actuel.partenaires, homebrew: actuel.homebrew, homebrew_monstres: actuel.homebrew_monstres };
  modif(v.livres_beyond);
  sCampagne.enregistrer(0);
  abonnes.forEach(fn => fn());
}

let promesseConfig = null;
const configLivres = () => {
  promesseConfig ||= demanderExtension({ type: 'config' });
  promesseConfig.catch(() => { promesseConfig = null; });
  return promesseConfig;
};

// Onglet « Livres D&D Beyond » de la fenêtre Campagne : les livres cochés, une recherche pour en ajouter, et les deux
// options des objets. Les catégories « partenaires » sont celles que D&D Beyond laisse masquer (isHideable).
export async function contenuLivres(etat) {
  await chargerLivres(etat);
  const zone = h('div', { class: 'cm-pile cm-livres' });
  let texte = '';
  let cfg = null, erreur = null;
  configLivres().then(c => { cfg = c; rendre(); }, e => { erreur = e; rendre(); });

  function caseOption(libelle, detail, cle) {
    return h('label', { class: 'cm-case cm-case--grande', title: detail },
      h('input', { type: 'checkbox', class: 'bn-case', checked: livres()[cle], onchange: e => enregistrer(l => { l[cle] = e.target.checked; }) }),
      h('span', {}, libelle, h('span', { class: 'ui-s cm-sourdine' }, ' · ' + detail)));
  }

  function rendre() {
    const l = livres();
    const choisis = new Set(l.ids);
    const categories = new Map((cfg?.categories || []).map(c => [c.id, c]));
    const champ = h('input', { class: 'bn-input', type: 'search', value: texte, placeholder: 'Ajouter un livre : Tasha, Van Richten, Kobold…', 'aria-label': 'Chercher un livre',
      oninput: e => { texte = e.target.value; majTrouves(); } });
    const trouves = h('ul', { class: 'cm-livres__trouves' });
    function majTrouves() {
      const mots = normaliser(texte).split(/\s+/).filter(Boolean);
      trouves.replaceChildren(...(!mots.length || !cfg ? [] : (cfg.sources || [])
        .filter(s => s.publie && !choisis.has(s.id) && categories.get(s.categorie)?.nom !== 'Hidden Sources' && mots.every(m => normaliser(`${s.sigle} ${s.titre}`).includes(m)))
        .slice(0, 12).map(s => h('li', {}, h('button', { type: 'button', class: 'cm-lien-bouton', title: 'Ajouter ce livre',
          onclick: () => { texte = ''; enregistrer(x => { x.sources.push({ id: s.id, sigle: s.sigle, titre: s.titre }); }); rendre(); } },
        `${s.sigle} · ${s.titre}`, categories.get(s.categorie)?.partenaire ? h('span', { class: 'ui-s cm-sourdine' }, ` · ${categories.get(s.categorie).nom}`) : null)))));
    }
    majTrouves();
    zone.replaceChildren(...[   // un null s'écrirait « null »
      h('p', { class: 'ui cm-sourdine' }, 'Les livres où chercher les monstres des rencontres et les objets à donner. Seul ce que votre compte D&D Beyond a débloqué donne des fiches complètes.'),
      h('ul', { class: 'cm-livres__liste' }, l.liste.map(([id, sigle, titre]) => h('li', {},
        h('span', {}, h('b', {}, sigle), ` · ${titre}`, h('span', { class: 'des cm-sourdine' }, ` ${id}`)),
        h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome bn-btn--icone', title: `Retirer ${titre}`, 'aria-label': `Retirer ${titre}`, disabled: l.liste.length <= 1,
          onclick: () => { enregistrer(x => { x.sources = x.sources.filter(s => s.id !== id); }); rendre(); } }, '×')))),
      champ, trouves,
      erreur ? alerte('cierge', 'lu-triangle-alert', 'Liste des livres indisponible', `${erreur.message} Les livres déjà choisis restent utilisés.`) : !cfg ? h('p', { class: 'ui-s cm-sourdine' }, 'Lecture des livres de D&D Beyond…') : null,
      h('p', { class: 'etiquette cm-section__titre' }, 'En plus des livres'),
      caseOption('Contenu partenaire', 'objets des éditeurs partenaires que vous avez débloqués', 'partenaires'),
      caseOption('Objets homebrew', 'vos objets homebrew, et ceux partagés dans la campagne', 'homebrew'),
      caseOption('Monstres homebrew', 'les monstres de votre collection homebrew, dans la recherche des rencontres', 'homebrew_monstres')].filter(Boolean));
  }
  rendre();
  return zone;
}

// ───── Règles des fiches D&D Beyond (onglet « Fiches D&D Beyond » de la fenêtre Campagne) ─────
// etat/campagne.json, `regles_fiches` : lu par l'extension du MJ à chaque relevé (extensions/mj/fond.js, depuis 1.11.0).
// - epuisement_homebrew (vrai d'office) : objets « Exhaustion Level » tenus à jour ;
// - encombrement_homebrew (vrai d'office) : objets « Encumbered » et « Heavily Encumbered » tenus à jour (un seul, selon
//   l'état du héros), « Use Encumbrance » imposé aux fiches (depuis l'extension 1.16.0 ; avant : la variante) ;
// - encombrement_seuils { encombre, lourd } : les seuils, en multiples de la Force (5 et 10 d'office, ceux de la variante) ;
// - homebrew (vrai d'office) : le contenu homebrew autorisé sur les fiches ;
// - pieces (faux d'office) : les pièces comptent dans le poids porté, imposé aux fiches.
export const reglesFiches = () => {
  const r = sCampagne?.valeur?.regles_fiches || {};
  return { epuisement_homebrew: r.epuisement_homebrew !== false, encombrement_homebrew: r.encombrement_homebrew !== false, homebrew: r.homebrew !== false, pieces: r.pieces === true,
    encombrement_seuils: seuilsEncombrement(r.encombrement_seuils),
    ...(r.bandeau ? { bandeau: r.bandeau } : {}) };   // la ligne du MJ pour les extensions des joueurs (reglesBandeau()) : gardée telle quelle
};
// Les seuils d'encombrement, en multiples de la Force : ceux de la campagne, ou ceux de la variante (lus aussi par
// l'extension, optionsFiches() de extensions/mj/fond.js, avec la même correction d'un seuil lourd trop bas).
const SEUILS_ENCOMBREMENT = { encombre: 5, lourd: 10 };
function seuilsEncombrement(x) {
  const m = (v, defaut) => (Number(v) > 0 ? Number(v) : defaut);
  const s = { encombre: m(x?.encombre, SEUILS_ENCOMBREMENT.encombre), lourd: m(x?.lourd, SEUILS_ENCOMBREMENT.lourd) };
  if (s.lourd <= s.encombre) s.lourd = s.encombre * 2;
  return s;
}

export async function contenuFiches(etat) {
  await chargerLivres(etat);
  const zone = h('div', { class: 'cm-pile cm-livres' });
  // Les objets homebrew du MJ sont publics sur D&D Beyond (2026-10-26) : tout MJ les ajoute à sa collection (« Add to
  // Collection ») depuis leur page, pour que l'extension puisse les poser sur les fiches.
  const lienObjet = (url, nom) => h('a', { class: 'bn-lien', href: url, target: '_blank', rel: 'noopener' }, nom);
  // suite : sous la case, dans son cadre (les seuils de l'encombrement), grisée et sans effet quand elle est décochée.
  const caseRegle = (cle, libelle, detail, suite = null) => {
    const activer = oui => {
      suite?.classList.toggle('est-eteint', !oui);
      suite?.querySelectorAll('input').forEach(x => { x.disabled = !oui; });
    };
    const c = h('label', { class: 'cm-case' + (suite ? '' : ' cm-case--grande') },
      h('input', { type: 'checkbox', class: 'bn-case', checked: reglesFiches()[cle], onchange: e => {
        sCampagne.valeur.regles_fiches = { ...reglesFiches(), [cle]: e.target.checked };
        sCampagne.enregistrer(0);
        activer(e.target.checked);
      } }),
      h('span', {}, h('b', {}, libelle), h('br'), h('span', { class: 'ui-s cm-sourdine' }, detail)));
    if (!suite) return c;
    activer(reglesFiches()[cle]);
    return h('div', { class: 'cm-reglage' }, c, suite);
  };
  const EPUISEMENT_URL = 'https://www.dndbeyond.com/magic-items/11959069-exhaustion-level';
  const ENCOMBRE_URL = 'https://www.dndbeyond.com/magic-items/12142792-encumbered';
  const LOURD_URL = 'https://www.dndbeyond.com/magic-items/12140026-heavily-encumbered';
  // Les seuils, dits comme une phrase sous la case de l'encombrement, grisés quand elle est décochée.
  const nombre = (cle, libelle) => h('input', { class: 'bn-input bn-input--nombre cm-phrase__nombre', type: 'number', min: '1', step: '1',
    value: reglesFiches().encombrement_seuils[cle], 'aria-label': libelle, disabled: !reglesFiches().encombrement_homebrew, onchange: e => {
      const v = Number(e.target.value);
      if (v > 0) {
        sCampagne.valeur.regles_fiches = { ...reglesFiches(), encombrement_seuils: seuilsEncombrement({ ...reglesFiches().encombrement_seuils, [cle]: v }) };
        sCampagne.enregistrer(0);
      }
      const s = reglesFiches().encombrement_seuils;
      champEncombre.value = s.encombre; champLourd.value = s.lourd;
    } });
  const champEncombre = nombre('encombre', 'Encombré au-delà de … fois la Force');
  const champLourd = nombre('lourd', 'Lourdement encombré au-delà de … fois la Force');
  const phraseSeuils = h('div', { class: 'cm-phrase ui cm-reglage__sous' }, 'Encombré au-delà de', champEncombre, '× la Force, lourdement au-delà de', champLourd, '×.');
  zone.append(
    h('p', { class: 'ui cm-sourdine' }, 'Ce que l\'extension du MJ tient à jour sur les fiches des héros, à chaque relevé (20 s). Une fiche mal réglée est corrigée ; ce qu\'elle ne peut pas corriger s\'affiche en alerte dans le widget Personnages.'),
    caseRegle('epuisement_homebrew', 'Épuisement par l\'objet homebrew « Exhaustion Level »',
      ['Autant d\'exemplaires équipés que le niveau d\'Épuisement (D&D Beyond n\'applique pas ses malus). L\'objet, public, doit être dans votre collection D&D Beyond : ', lienObjet(EPUISEMENT_URL, 'Exhaustion Level'), ', « Add to Collection » (une alerte le dit sinon).']),
    caseRegle('encombrement_homebrew', 'Encombrement par les objets homebrew « Encumbered » et « Heavily Encumbered »',
      ['Selon le poids porté et les seuils ci-dessous, l\'un des deux est équipé (encombré, ou lourdement), aucun sinon : ils portent les malus, vitesse comprise. Impose l\'encombrement « Use Encumbrance » aux fiches, qui ne touche pas à la vitesse. Les objets, publics, doivent être dans votre collection D&D Beyond : ', lienObjet(ENCOMBRE_URL, 'Encumbered'), ' et ', lienObjet(LOURD_URL, 'Heavily Encumbered'), ', « Add to Collection » (une alerte le dit sinon). Décoché : les deux objets sont retirés des fiches, et chaque fiche garde son réglage d\'encombrement (en variante, D&D Beyond réduit lui-même la vitesse, au-delà de 5 et 10 × la Force).'], phraseSeuils),
    caseRegle('homebrew', 'Contenu homebrew autorisé sur les fiches',
      'Impose aux fiches d\'accepter le contenu homebrew (« Preferences », « Homebrew ») : sans lui, vos objets homebrew (Exhaustion Level compris) restent sans effet. Décoché : chaque fiche garde son réglage.'),
    caseRegle('pieces', 'Les pièces comptent dans le poids porté',
      'Impose aux fiches de compter les pièces (1 lb pour 50). Décoché : chaque fiche garde son réglage.'),
    blocBandeau());
  return zone;
}

// ───── Extensions des joueurs : ce que le MJ fixe pour sa campagne ─────
// Le bandeau du groupe (extensions/groupe/) lit une ligne « [Bandeau (MJ) : ensanglanté 50, critique 25, pv non] » dans les
// notes publiques de la campagne D&D Beyond (chaque fiche les porte) : contrat formats/note-compagnon.md. Le gestionnaire
// compose la ligne (etat/campagne.json, `regles_fiches.bandeau` { ensanglante, critique, chiffres } ; d'office les seuils de
// l'écran des joueurs, sans chiffres), le MJ la colle dans D&D Beyond, et le relevé de l'extension du MJ (1.18.0,
// `campagne.bandeau` de beyond.json) dit si elle y est.
export function reglesBandeau() {
  const b = sCampagne?.valeur?.regles_fiches?.bandeau || {}, ecran = sCampagne?.valeur?.plugins?.['ecran-joueurs']?.seuils || {};
  const pct = (v, defaut) => (Number(v) >= 1 && Number(v) <= 99 ? Math.round(Number(v)) : defaut);
  return { ensanglante: pct(b.ensanglante, pct(ecran.ensanglante, 50)), critique: pct(b.critique, pct(ecran.critique, 25)), chiffres: b.chiffres === true };
}
export const ligneBandeau = (r = reglesBandeau()) => `[Bandeau (MJ) : ensanglanté ${r.ensanglante}, critique ${r.critique}, pv ${r.chiffres ? 'oui' : 'non'}]`;

function blocBandeau() {
  const url = String(campagneOuverte().beyond?.url || '').replace(/\/+$/, '');
  const champ = h('input', { class: 'bn-input cm-bandeau__ligne', type: 'text', readonly: true, value: ligneBandeau(), 'aria-label': 'La ligne à coller dans les notes publiques de la campagne', onfocus: e => e.target.select() });
  const etat = h('p', { class: 'ui-s cm-sourdine', 'aria-live': 'polite' }, 'Lecture du dernier relevé…');
  // Ce que dit le dernier relevé : la ligne en place, une autre, aucune, ou un relevé qui ne lit pas encore ces notes.
  async function verifier() {
    const camp = (await lireBeyond()).campagne;
    const ligne = ligneBandeau();
    etat.replaceChildren(...(!camp ? ['Aucun relevé D&D Beyond : l\'extension du MJ dira ici si la ligne est en place.']
      : !('bandeau' in camp) ? ['Le relevé ne dit pas encore si la ligne est en place : rechargez l\'extension du MJ (version 1.18.0), puis attendez un relevé.']
        : camp.bandeau === ligne ? [h('b', { class: 'cm-bandeau__ok' }, 'En place'), ' dans les notes publiques de la campagne, au dernier relevé.']
          : camp.bandeau ? [h('b', { class: 'cm-bandeau__ecart' }, 'Une autre ligne est en place'), ` : ${camp.bandeau}. Remplacez-la par celle-ci.`]
            : [h('b', { class: 'cm-bandeau__ecart' }, 'Pas encore en place'), ' : collez la ligne dans les notes publiques de la campagne.']));
  }
  const garder = patch => {
    sCampagne.valeur.regles_fiches = { ...(sCampagne.valeur.regles_fiches || {}), bandeau: { ...reglesBandeau(), ...patch } };
    sCampagne.enregistrer(0);
    champ.value = ligneBandeau();
    verifier();
  };
  const nombre = (cle, libelle) => h('input', { class: 'bn-input bn-input--nombre cm-phrase__nombre', type: 'number', min: '1', max: '99', step: '1', value: reglesBandeau()[cle], 'aria-label': libelle,
    onchange: e => { const v = Math.round(Number(e.target.value)); if (v >= 1 && v <= 99) garder({ [cle]: v }); e.target.value = reglesBandeau()[cle]; } });
  const copier = h('button', { type: 'button', class: 'bn-btn bn-btn--s', onclick: async () => {
    try { await navigator.clipboard.writeText(champ.value); copier.textContent = 'Copiée'; } catch { champ.focus(); champ.select(); copier.textContent = 'Ctrl + C'; }
    setTimeout(() => { copier.textContent = 'Copier'; }, 1500);
  } }, 'Copier');
  verifier();
  return h('div', { class: 'cm-reglage' },
    h('p', { class: 'ui' }, h('b', {}, 'Extensions des joueurs : le bandeau du groupe')),
    h('p', { class: 'ui-s cm-sourdine' }, 'Les joueurs qui ont l\'extension « The Seat · Party » voient l\'état du groupe sur leur fiche. Vous fixez ici ses limites pour votre campagne ; leurs réglages disent alors qu\'elles viennent du MJ.'),
    h('div', { class: 'cm-phrase ui' }, '« Ensanglanté » à', nombre('ensanglante', '« Ensanglanté » à … % des PV'), '% des PV, « Critique » à', nombre('critique', '« Critique » à … % des PV'), '%.'),
    h('label', { class: 'cm-case' },
      h('input', { type: 'checkbox', class: 'bn-case', checked: reglesBandeau().chiffres, onchange: e => garder({ chiffres: e.target.checked }) }),
      h('span', {}, h('b', {}, 'Les joueurs peuvent voir les PV en chiffres'), h('br'), h('span', { class: 'ui-s cm-sourdine' }, 'Décoché : en mots ou en barre seulement, comme sur l\'écran des joueurs.'))),
    h('div', { class: 'cm-phrase' }, champ, copier,
      url ? h('a', { class: 'bn-lien ui-s', href: `${url}/edit#form-field-public-notes`, target: '_blank', rel: 'noopener' }, 'Ouvrir les notes publiques de la campagne') : null),
    h('p', { class: 'ui-s cm-sourdine' }, 'À coller dans les notes publiques de la campagne sur D&D Beyond (« Edit Campaign », « Public Notes »), n\'importe où dans le texte : les extensions des joueurs la lisent avec leur fiche. Sans la ligne, chaque joueur garde ses réglages.'),
    etat);
}
