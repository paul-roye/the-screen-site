// Aide du gestionnaire (page À propos, onglet Aide) : ce que fait chaque outil, chaque bouton, chaque fenêtre.
// À tenir à jour avec le code : un bouton ajouté, renommé ou retiré change aussi sa ligne ici (consigne de CLAUDE.md).
// Chaque section : { id, groupe, titre, icone, resume, requiert?, blocs: [{ titre, points: [[nom, texte]] }] }.
// `groupe` : 'base' (prise en main), 'widget' (un outil du tableau), 'module' (un module de campagne). `requiert` : le fichier
// de data/ sans lequel l'outil n'est pas proposé.

export const GROUPES_AIDE = [
  ['base', 'Prise en main'],
  ['widget', 'Les outils du tableau'],
  ['module', 'Modules de campagne'],
  ['plugin', 'Plugins'],
];

export const AIDE = [
  // ───────────── Prise en main ─────────────
  {
    id: 'demarrer', groupe: 'base', titre: 'Démarrer', icone: 'lu-play',
    resume: 'The Screen, le gestionnaire de campagne, est une page web locale : un petit serveur sur votre PC, ouvert dans Chrome. Rien ne part sur Internet, sauf ce que vous demandez à D&D Beyond ou à YouTube.',
    blocs: [
      { titre: 'Lancer', points: [
        ['Lancer le gestionnaire.cmd', 'Double-cliquez ce fichier, à la racine du dossier : le serveur démarre et Chrome ouvre http://localhost:8735/. Gardez la fenêtre noire ouverte pendant la partie : la fermer arrête le gestionnaire.'],
        ['L\'accueil', 'Il rouvre la dernière campagne ouverte sur ce navigateur ; au premier lancement, il les liste, avec « Nouvelle campagne ». Pour y revenir : les flèches croisées de l\'en-tête. Chaque campagne a son adresse : http://localhost:8735/<identifiant>/.'],
        ['Nouvelle campagne', 'Depuis l\'accueil : titre, identifiant (le nom de son dossier), genre (Classique, ou Curse of Strahd, qui pré-règle la charte, le calendrier et le module Tarokka), charte, calendrier et météo, musique de départ, modules. Le gestionnaire crée le dossier campagnes/<identifiant>/ et ouvre la campagne.'],
        ['L\'aide de démarrage', 'Une nouvelle campagne s\'ouvre sur une fenêtre qui dit quoi faire ensuite : les données, les réglages, les héros, le tableau. Elle revient à chaque ouverture jusqu\'à « Ne plus montrer ».'],
      ] },
      { titre: 'Les données de la campagne', points: [
        ['data/', 'Les lieux, PNJ, factions, déroulé, rencontres, objets… de la campagne, en fichiers JSON. Ils s\'écrivent à la main ou, bien plus simplement, avec votre agent IA de campagne (un projet Claude, par exemple), qui lit vos livres, vos PDF et vos notes.'],
        ['Les instructions de l\'agent', 'Donnez-lui AGENTS.md (à la racine), le guide campagnes/<identifiant>/data/LISEZMOI.md et les fiches de formats/ : elles disent exactement ce que chaque fichier doit contenir. Commencez par le minimum : lieux, PNJ et déroulé.'],
        ['etat/', 'Ce que le gestionnaire note pendant les séances : l\'heure de jeu, où sont les héros, les étapes en cours, les tirages, les combats… Le gestionnaire fait foi pour l\'avancée de la campagne. L\'agent peut le lire, jamais l\'écrire.'],
        ['Bouton Données', 'Vérifie chaque fichier de data/ : format, références vers des identifiants inconnus, champs manquants. Une pastille orange dans l\'en-tête compte les fichiers à reprendre.'],
      ] },
    ],
  },
  {
    id: 'tableau', groupe: 'base', titre: 'Le tableau et ses modes', icone: 'lu-layout-grid',
    resume: 'Le tableau est une grille d\'outils (les widgets) que vous disposez comme vous voulez. Chaque mode a sa propre disposition.',
    blocs: [
      { titre: 'Les quatre modes', points: [
        ['Exploration, Ville, Voyage', 'Le premier bouton de l\'en-tête : un clic passe au mode affiché, sa flèche ouvre le menu des trois. Ville et Voyage partent d\'une disposition proposée (PNJ, marchands, noms pour la ville ; horloge, trajets, rencontres pour le voyage), à retoucher.'],
        ['Rencontre', 'Le second bouton : le mode des combats. « Lancer » une rencontre, d\'où que ce soit, y passe d\'office et pose le widget Combat s\'il manque.'],
        ['Un même outil dans plusieurs modes', 'C\'est le même : il garde son contenu et change seulement de place. Les outils des autres modes restent à jour en arrière-plan.'],
      ] },
      { titre: 'Un widget', points: [
        ['Poignée (six points)', 'Glissez pour déplacer le widget. Au clavier : les flèches le déplacent, Maj et les flèches changent sa taille.'],
        ['Coin en bas à droite', 'Glissez pour le redimensionner.'],
        ['Chevron', 'Réduit le widget à sa barre de titre (ou double-cliquez sur la barre). Réduit, il garde souvent l\'essentiel dans sa barre : l\'heure de l\'Horloge, l\'étape du Déroulé, les cartes du Tarokka…'],
        ['Croix', 'Retire le widget du tableau de ce mode. Ses données restent : il revient tel quel par le bouton Outil.'],
        ['Boutons de la barre', 'Propres à chaque outil (filtres, bascule d\'affichage…). Ceux qui ne servent que widget déplié disparaissent quand il est réduit.'],
      ] },
      { titre: 'Disposer le tableau', points: [
        ['Outil', 'Ajoute un outil au mode affiché. Les outils grisés manquent de données (le fichier de data/ qu\'il leur faut est nommé) ou d\'un module que la campagne n\'a pas.'],
        ['Disposition recommandée', 'En bas de la fenêtre Outil : remplace la disposition du mode affiché par celle que vous recommande l\'auteur de cet outil, celle d\'une nouvelle campagne, avec seulement les outils que la campagne peut avoir (pas d\'outil sans ses données, ni de plugin désactivé). À relancer quand de nouveaux fichiers de data/ sont arrivés. Les autres modes, les tirages et les journaux sont conservés.'],
        ['Cadenas', 'Verrouille la disposition : plus de déplacement ni de redimensionnement par mégarde, et le menu rapide reste où il est.'],
        ['Soleil / lune', 'Passe du thème Nuit (pour jouer) au thème Parchemin (en plein jour, ou pour imprimer).'],
      ] },
    ],
  },
  {
    id: 'entete', groupe: 'base', titre: 'L\'en-tête', icone: 'lu-sliders-horizontal',
    resume: 'Le titre de la campagne, les modes, et les commandes de toute la campagne.',
    blocs: [
      { titre: 'Les boutons', points: [
        ['Flèches croisées', 'L\'accueil : la liste des campagnes de ce poste, pour en ouvrir une autre ou en créer une.'],
        ['Données', 'Les fichiers de data/ et leurs vérifications (voir « Démarrer »). On y retire aussi un suivi du déroulé qui renvoie à un élément disparu des données, et on y voit les rencontres dont le rattachement à un jalon ou une étape ne vaut plus.'],
        ['Campagne', 'Les réglages de la campagne et de ce poste (voir « Réglages de la campagne »).'],
        ['Session', 'La fin de session avec votre agent IA de campagne (voir « Fin de session »).'],
        ['Cadenas, soleil / lune, Outil', 'Voir « Le tableau et ses modes ».'],
        ['Par … · version · À propos', 'L\'auteur et la version du gestionnaire (« + » si cette copie a été modifiée), et cette page.'],
      ] },
      { titre: 'Les annonces', points: [
        ['Bandeau en haut du tableau', 'La nuit tombe, un repos long en retard, un fichier à recharger… Une annonce reste jusqu\'à « Compris ».'],
        ['État non enregistré', 'Le gestionnaire n\'écrase jamais un fichier en silence : si un autre onglet a changé le même fichier, ou s\'il est illisible, il le dit et propose « Recharger la page ». N\'ouvrez une campagne que dans un seul onglet.'],
      ] },
    ],
  },
  {
    id: 'reglages', groupe: 'base', titre: 'Réglages de la campagne', icone: 'lu-sliders-horizontal',
    resume: 'Bouton Campagne de l\'en-tête : une fenêtre à sept onglets.',
    blocs: [
      { titre: 'Les onglets', points: [
        ['Campagne', 'Titre, sous-titre, icône, charte et thème ; les mots du monde (« Bêtes d\'Aurval », « Nommer un Aurvalien ») ; ciel toujours voilé ; campagne D&D Beyond des héros ; le temps (calendrier, date de départ, météo, et comment importer les vôtres) ; plafond de rencontres et événements de campagne ; wiki vvd.world (facultatif) et « Importer le wiki ». « Enregistrer » recharge la page.'],
        ['Rencontres', 'La difficulté des rencontres selon Flee, Mortals! (budget de FP, plafond, sbires, solos), le compte des compagnons dans le budget, les rôles des monstres. Décochée : rien de tout cela n\'est montré.'],
        ['Livres D&D Beyond', 'Les livres où chercher les monstres et les objets ; pour les objets, le contenu partenaire et vos homebrews en plus.'],
        ['Images', 'Les sources de la bibliothèque d\'images : un livre D&D Beyond (« Relever le livre » par l\'extension), des documents Homebrewery, vos propres dossiers. « Importer », « Tout importer », « Ouvrir » le dossier, et le journal de l\'import.'],
        ['Fiches D&D Beyond', 'Ce que l\'extension du MJ impose aux fiches des héros : malus de l\'Épuisement et de l\'encombrement, avec vos seuils (objets homebrew « Exhaustion Level », « Encumbered » et « Heavily Encumbered », à ajouter à votre collection), pièces comptées dans le poids, contenu homebrew autorisé ; et, pour l\'extension des joueurs « The Seat · Party », les limites que vous fixez (seuils « Ensanglanté » et « Critique », PV en chiffres ou non) : une ligne à coller dans les notes publiques de votre campagne D&D Beyond, dont l\'onglet dit si elle est en place.'],
        ['Plugins', 'Les connexions à un appareil ou à un service, à activer pour cette campagne : The Table (voir « Plugins »). Chacun avec ses réglages, et en bas les derniers événements du gestionnaire (ce que les plugins reçoivent).'],
        ['Ce poste', 'Réglages de ce navigateur seul : le mode débogage (une largeur d\'écran simulée, depuis le menu rapide) ; l\'écran des joueurs de ce PC (quel écran, la largeur de sa dalle, la mire : voir « Écran des joueurs » dans Plugins).'],
      ] },
    ],
  },
  {
    id: 'menu-rapide', groupe: 'base', titre: 'Le menu rapide', icone: 'lu-sparkles',
    resume: 'Une languette sur le bord gauche de la page : au survol, une colonne de grandes icônes, par-dessus le tableau.',
    blocs: [
      { titre: 'Les raccourcis', points: [
        ['Haut de page', 'Remonte en haut du tableau.'],
        ['Le groupe', 'Le récapitulatif du groupe (widget Personnages), même réduit ou dans un autre mode.'],
        ['Carte', 'La carte des trajets en grand (widget Trajets).'],
        ['Rencontres', 'L\'onglet Tirage du widget Rencontres, dans une fenêtre.'],
        ['Babiole', 'Tire une babiole dans l\'une des tables, et l\'ouvre.'],
        ['Dés', 'Le widget Dés dans une fenêtre, qui partage ses réglages et son historique avec celui du tableau.'],
        ['Poignée', 'Glissez le menu de haut en bas (sa place est gardée sur ce poste). Cachée quand la disposition est verrouillée.'],
        ['Largeur simulée', 'Avec le mode débogage (Campagne, onglet « Ce poste ») : simuler un écran de 1280, 1422, 1600 px…'],
      ] },
      { titre: 'Bon à savoir', points: [
        ['Outil absent', 'Si l\'outil qu\'un raccourci demande n\'est pas monté, une annonce dit lequel ajouter.'],
      ] },
    ],
  },
  {
    id: 'fenetres', groupe: 'base', titre: 'Fenêtres et infobulles', icone: 'lu-maximize-2',
    resume: 'Le détail d\'un élément (un PNJ, un jalon, une babiole, une rencontre…) s\'ouvre dans une fenêtre flottante, jamais déplié dans la liste.',
    blocs: [
      { titre: 'Fenêtres flottantes', points: [
        ['Ouvrir', 'Un clic sur la ligne : sa fenêtre s\'ouvre près du clic, et la ligne reste marquée tant qu\'elle est ouverte. Un nouveau clic sur un élément déjà ouvert ramène sa fenêtre devant.'],
        ['Déplacer, fermer', 'Glissez la barre de titre ; la croix ou Échap ferme. Plusieurs fenêtres peuvent rester ouvertes : elles se mettent à jour d\'elles-mêmes.'],
        ['Réduire', 'Le chevron de la barre de titre, ou un double-clic sur la barre : la fenêtre ne garde que sa barre de titre, à sa place, avec son nom (le monstre, la rencontre, le trajet) et sa miniature (héros, monstre) ou son icône. On peut toujours la déplacer. Le chevron la déplie ; rouvrir l\'élément depuis sa liste aussi.'],
        ['Valider au clavier', 'Dans un champ de texte à plusieurs lignes (une remarque, une note), Entrée passe à la ligne. Maintenez Ctrl : le bouton qui valide le champ montre la touche « Entrée », et Ctrl + Entrée l\'actionne.'],
        ['Une activité en cours', 'La fenêtre d\'un trajet, d\'un repos ou d\'une attente ne se ferme pas : elle se réduit seulement, pour ne pas perdre le fil. Elle se ferme d\'elle-même à la fin de l\'activité.'],
        ['Dialogues', 'Les choix importants (régler l\'heure, démarrer une étape, terminer un combat) s\'ouvrent au centre, par-dessus la page.'],
      ] },
      { titre: 'Infobulles et repères', points: [
        ['Infobulle', 'Au survol, le détail d\'un élément, dans sa couleur (orange pour une alerte, jaune pour la route, rouge pour une info importante). Les distances en pieds y donnent les mètres et les cases.'],
        ['Pastille de DD', 'Un dé et le DD (« DD 12 ») : une sauvegarde ou un test.'],
        ['Encadré violet « Pour le MJ, ne pas lire »', 'Ce qui est réservé au MJ, sous un texte à lire aux joueurs.'],
        ['Écarts des sources', 'Quand une source plus haute (vos décisions, un supplément) change le livre : appliqué d\'office, ou montré comme une information avec sa condition, ou en question à trancher. « Version d\'origine » montre ce que disait le livre.'],
      ] },
    ],
  },
  {
    id: 'session', groupe: 'base', titre: 'Fin de session et agent IA', icone: 'livre',
    resume: 'Bouton Session de l\'en-tête : l\'aller-retour avec votre agent IA de campagne, après chaque séance.',
    blocs: [
      { titre: 'Les deux onglets', points: [
        ['Avant l\'analyse', 'Un prompt en Markdown, à copier ou télécharger : l\'état noté par le gestionnaire pendant la séance (étapes, jalons et pistes, lieux, heure, rencontres jouées et leur état de fin, PNJ rencontrés, babioles et objets donnés, notes, agenda…), et le format de la réponse attendue. Donnez-le à votre agent avec vos notes de séance (ou le wiki importé).'],
        ['Toute la campagne', 'Dans « Avant l\'analyse », l\'export de tout ce qui a été noté depuis le début, avec le déroulé élément par élément et vos remarques sur les rencontres, même ajoutées après coup. Il ne compte pas comme un envoi.'],
        ['Après l\'analyse', 'Collez la réponse de l\'agent : son bloc « maj-etat ». Chaque changement est montré avant d\'être appliqué ; vous validez. L\'historique des sessions est gardé.'],
      ] },
      { titre: 'Les règles du jeu avec l\'agent', points: [
        ['Le gestionnaire fait foi', 'L\'agent part de l\'état du gestionnaire, pas de sa mémoire. Il ne touche qu\'aux données (data/) et à ses propres fiches, jamais au gestionnaire.'],
        ['Une erreur de contenu', 'Elle se corrige chez l\'agent, qui réécrit le fichier de data/ : on ne retouche pas data/ à la main.'],
      ] },
    ],
  },
  {
    id: 'beyond', groupe: 'base', titre: 'D&D Beyond et l\'extension du MJ', icone: 'd20',
    resume: 'Une extension Chrome (extensions/mj/) relève les fiches des héros sur D&D Beyond, avec votre session, et écrit ce que vous changez dans le gestionnaire.',
    blocs: [
      { titre: 'Installer (une fois)', points: [
        ['Charger l\'extension', 'Chrome, chrome://extensions, « Mode développeur », « Charger l\'extension non empaquetée », le dossier extensions/mj. Épinglez-la : son badge dit le temps depuis le dernier relevé.'],
        ['Régler', 'Dans sa fenêtre : l\'adresse du gestionnaire (http://localhost:8735, ou http://localhost:8735/<identifiant> pour une autre campagne que celle par défaut). Restez connecté à D&D Beyond dans Chrome.'],
        ['Mettre à jour', 'Après une nouvelle version, « Recharger » l\'extension dans chrome://extensions : le widget Personnages le rappelle.'],
      ] },
      { titre: 'Ce qu\'elle fait', points: [
        ['Relevé', 'Toutes les 20 secondes : PV, CA, passives, sorts, capacités, inventaire, argent, états, compétences, familiers et compagnons.'],
        ['Écritures', 'États et inspiration héroïque posés depuis le gestionnaire, PV changés dans Combat, objets donnés (Babioles, Objets) : ils arrivent sur les fiches.'],
        ['Monstres et objets', 'La recherche dans le bestiaire et le catalogue d\'objets des livres choisis (fiches complètes des livres que vous possédez).'],
        ['Épuisement, encombrement', 'Si vous l\'activez (Campagne, « Fiches D&D Beyond ») : elle tient équipés les objets homebrew qui portent leurs malus, que D&D Beyond n\'applique pas.'],
      ] },
      { titre: 'L\'extension du joueur', points: [
        ['extensions/compagnon/', 'Pour le joueur d\'un héros qui a un familier ou un compagnon : sa fiche au format d\'un monstre, ses dés, et les états que vous lui posez (transmis par la note de la créature sur D&D Beyond). Indépendante du gestionnaire.'],
      ] },
    ],
  },
  {
    id: 'outils', groupe: 'base', titre: 'Le dossier outils/', icone: 'lu-folder-open',
    resume: 'Des scripts à double-cliquer, pour ce qui se prépare hors de la page. La plupart se lancent aussi depuis le gestionnaire.',
    blocs: [
      { titre: 'Les scripts', points: [
        ['Importer les images.cmd', 'Télécharge les images des sources de la campagne (livre D&D Beyond, Homebrewery, vos dossiers), puis les indexe. Aussi dans Campagne, onglet « Images ». Une autre campagne : -Campagne <identifiant>.'],
        ['Indexer les images.cmd', 'Refait l\'index de la bibliothèque d\'images (fait d\'office à chaque lancement du gestionnaire).'],
        ['Importer la musique.cmd', 'Lit musique/sources.json de la campagne (playlists YouTube, étiquettes) et écrit la liste des pistes du widget Musique.'],
        ['Importer la météo.cmd', 'Deux années de vraie météo d\'une ville (Open-Meteo, gratuit), résumées pour l\'Horloge : -Ville, -Pays, -Annee, -Campagne.'],
        ['Importer le wiki.cmd', 'Copie le wiki vvd.world de la campagne dans wiki/, pour votre agent IA. Aussi dans Campagne, onglet « Campagne ».'],
        ['Importer les icônes d\'états.cmd', 'Les icônes des états de D&D Beyond (Aveuglé, Empoisonné…), pour les cartes des héros. Sans elles, une abréviation.'],
        ['Installer l\'assistant de règles.cmd', 'Installe le service du widget Règles (Python géré par uv, index des PDF des règles). Facultatif.'],
        ['Mettre à jour.cmd', 'À lancer depuis le dossier décompressé d\'une nouvelle version : il met à jour votre gestionnaire actuel, que vous choisissez, sans toucher à vos campagnes ni à vos réglages, et garde l\'ancienne version dans anciennes-versions/.'],
      ] },
    ],
  },

  // ───────────── Les outils du tableau ─────────────
  {
    id: 'personnages', groupe: 'widget', titre: 'Personnages', icone: 'bouclier',
    resume: 'Les héros et leurs compagnons, à jour depuis D&D Beyond : une carte chacun, sur une ligne.',
    requiert: 'personnages',
    blocs: [
      { titre: 'Les cartes', points: [
        ['Une carte', 'Portrait (niveau sur son coin), prénom, classe et espèce, CA dans le bouclier, barre de PV, perception et intuition passives, DD des sorts, vitesse. Un clic ouvre la fiche complète.'],
        ['Rond d\'inspiration', 'Sur le coin du portrait : un clic donne ou retire l\'inspiration héroïque, sur la fiche D&D Beyond.'],
        ['Portrait', 'Un clic : poser un état (écrit sur la fiche D&D Beyond ; pour un familier, gardé dans le gestionnaire). Les états s\'affichent en icônes sur le portrait, quatre au plus ; un clic sur une icône ouvre ses effets.'],
        ['Tuile orange ou rose', 'Encombré ou lourdement encombré (seuils de la campagne, ou règle variante de la fiche) : la vitesse réduite prend la même couleur. Un clic explique.'],
        ['À 0 PV', 'La carte passe au rouge et montre les jets contre la mort à la place des valeurs ; mort, « Mort » à la place des PV.'],
      ] },
      { titre: 'L\'en-tête du widget', points: [
        ['Niv.', 'Le niveau du groupe ; en orange si un héros ne l\'a pas encore passé.'],
        ['Basique / Étendu', 'L\'étendu ajoute les emplacements de sorts et les capacités à usage limité (losanges cochés quand ils ont servi). Réglage propre à chaque mode : l\'étendu en combat, le basique en exploration, par exemple.'],
        ['Le groupe', 'Le récapitulatif : la vie de tous, puis Sorts et pouvoirs, Inventaire (objets magiques, argent avec l\'inventaire commun, babioles) et Campagne (niveau, lieu, étape, lieux visités, PNJ rencontrés, documents).'],
        ['Dé', 'Jet de groupe secret : une compétence, un test, une sauvegarde ou l\'initiative pour tous les héros, avec avantage ou désavantage ; le résultat classé du plus grand au plus petit.'],
        ['Actualiser (et un âge)', 'Le temps depuis le dernier relevé de D&D Beyond ; un clic : l\'état de l\'extension, comment l\'installer, et « Relever les détails » (historique, espèce, dons, en anglais) avec « Copier pour l\'agent IA ».'],
      ] },
      { titre: 'La fiche d\'un héros', points: [
        ['Dé en haut à droite', 'Lancer un jet de ce héros.'],
        ['+ État, Wiki, Feuille', 'Poser un état ; ouvrir sa page du wiki ou sa feuille D&D Beyond.'],
        ['Valeurs', 'CA, PP, PI, investigation passive, DD et vitesse ; caractéristiques et sauvegardes ; sorts et capacités.'],
        ['Onglets', 'Compétences (un clic lance le jet), Inventaire, Beyond (origines relevées), Lore (le lore des données, que vous pouvez retoucher : « Modifier »), Secret et Quête (pour le MJ seul : ses secrets, sa quête personnelle et ses pistes, avec leur statut dans le Déroulé).'],
        ['Compagnon', 'Sa fiche en bloc de stats ; pour un compagnon de Flee, Mortals!, sa férocité et son rampage, et « Règles » pour le résumé des règles des compagnons.'],
      ] },
    ],
  },
  {
    id: 'combat', groupe: 'widget', titre: 'Combat', icone: 'epee',
    resume: 'Mène la rencontre lancée depuis le gestionnaire, tour par tour. Il vit dans le mode Rencontre.',
    blocs: [
      { titre: 'Avant le combat', points: [
        ['Le titre', 'Le nom de la rencontre : un clic (ou le crayon) ouvre sa préparation, encore modifiable (renforts, noms, nombres).'],
        ['Démarrer (rencontre prête)', 'Note la rencontre en cours, avec l\'heure de jeu.'],
        ['Initiative', 'Un d20 par type de monstre, qui roule en 3D ; les héros donnent la leur (tapez-la : Entrée passe au héros suivant ; flèches : ±1). Un compagnon agit au tour de son maître, sur la ligne sous la sienne. Relancé : seulement l\'initiative des monstres.'],
        ['Œil barré', 'Un héros absent ce soir : hors de l\'ordre de combat (un clic sur son nom, en bas, le remet).'],
        ['Démarrer le combat', 'Round 1, au tour du premier. Il attend que chacun ait son initiative (l\'infobulle dit qui manque).'],
      ] },
      { titre: 'Pendant le combat', points: [
        ['Tour suivant, flèche arrière', 'Avance ou recule d\'un tour ; un monstre à 0 PV et un héros mort sont passés. Le combattant actif reste en vue.'],
        ['PV', 'Un clic sur la barre de PV : Dégâts (Entrée), Soins, PV temporaires. Les dégâts entament d\'abord les PV temporaires. Pour un héros ou un compagnon, écrits sur la fiche D&D Beyond.'],
        ['Lampe (plugin The Table)', 'En haut à droite, avec le plugin The Table actif : le point d\'état de la table (vert synchronisée, orange en attente, rouge refusée). Un clic ouvre sa fenêtre. Voir « The Table » dans Plugins.'],
        ['Clavier et pavé numérique', 'Pendant le combat (icône clavier du titre : le pavé et les touches en image, chacune de la couleur de son action ; la touche appuyée s\'y allume).* ou Pg suiv. : tour suivant ; / ou Pg préc. : tour précédent. ↑ ↓ : choisir une ligne (contour bleu ; à chaque tour, celle du combattant actif), Début : y revenir. Des chiffres ouvrent les PV de la ligne choisie : puis − ou Entrée pour des dégâts, + pour des soins (« + 8 Entrée » aussi), Échap pour annuler. Entrée sans chiffre ou F : sa fiche ; E : poser un état. Les chiffres du pavé comptent que le verrouillage numérique soit allumé ou non. Rien quand on écrit dans un champ ou qu\'une fenêtre, un dialogue ou un menu a la main.'],
        ['Portrait', 'Un clic : poser un état (héros, compagnon ou monstre). Un clic sur l\'icône d\'un état : ses effets, son niveau (Épuisement), le retirer.'],
        ['Nom d\'un monstre', 'Sa fiche D&D Beyond : chaque attaque, dégât, sauvegarde ou test se lance d\'un clic sur son encadré violet ; les états nommés dans les textes ouvrent leurs effets en français ; un clic sur l\'illustration l\'affiche en grand, et l\'icône de diffusion sur son coin l\'envoie sur l\'écran des joueurs (plugin actif).'],
        ['Difficulté', 'Le badge de difficulté (Flee, Mortals!) : un clic pour le détail (points, budget, plafond, journée d\'aventure) ; « Sbires » et « ? » pour leurs règles.'],
      ] },
      { titre: 'Finir', points: [
        ['Terminer', 'Une remarque, puis l\'état de fin (monstres morts ou leurs PV, héros tombés), gardé avec la rencontre : dans le Déroulé, l\'historique et le prompt de fin de session. Les créatures pas à 0 PV sont signalées : cochez celles qui sont mortes, elles y passent. La même fenêtre propose de marquer morts les PNJ tombés, de démarrer le jalon de la rencontre et, si c\'était sa dernière, de le terminer.'],
        ['Remarque', 'À tout moment : le bouton « Remarque » en bas de la fenêtre de la rencontre (quel que soit l\'onglet), ou la ligne de la rencontre (Ajouter une remarque…, Modifier la remarque…). Sur une rencontre terminée comme sur une trouvaille ou une scène sans combat, sans avoir à la marquer terminée. Une fois écrite, elle s\'affiche sous l\'en-tête de la fenêtre : un clic dessus la modifie. L\'export de fin de session la reprend, même si la rencontre a déjà été envoyée.'],
        ['Remettre à zéro', 'L\'initiative de tous effacée, et au choix les PV et les états des monstres.'],
        ['Croix (Annuler)', 'La rencontre n\'a pas eu lieu : tirée au hasard, elle sort du journal des rencontres (numéro et plafond rendus) ; prévue, elle redevient à jouer.'],
        ['Historique des rencontres', 'Le lien du bas : les rencontres jouées ou commencées, en fenêtre.'],
      ] },
    ],
  },
  {
    id: 'ici', groupe: 'widget', titre: 'Ici', icone: 'epingle',
    resume: 'Le lieu où sont les héros, et tout ce qui s\'y rattache. On peut regarder un autre lieu sans les y emmener.',
    requiert: 'lieux',
    blocs: [
      { titre: 'La carte du lieu', points: [
        ['Choix du lieu', 'La liste en haut (masquable par le bouton à curseurs de la barre, orange quand un autre lieu que celui des héros est affiché).'],
        ['Les héros arrivent ici', 'Note leur arrivée, à l\'heure de l\'horloge ; le terrain des rencontres suit (à l\'abri en ville…).'],
        ['Sous-lieux', 'Les badges sous le titre : un clic descend dans un bâtiment ou un niveau ; tout le widget se réduit à lui. Le lien au-dessus du titre remonte au lieu entier.'],
        ['Où ils sont', 'Revient au lieu des héros.'],
      ] },
      { titre: 'Les onglets', points: [
        ['PNJ', 'Les PNJ du lieu, du plus important au plus discret (mineurs repliés), ceux qu\'on y croise aussi, ses factions, et « Qui ouvre la porte ? » (table des occupants des maisons, avec « Lancer » si la rencontre tourne mal).'],
        ['Rencontres', 'Les rencontres prévues sur place ; « Rencontre ici » en crée une.'],
        ['Objets', 'Les objets à trouver ici (le compte de ceux qui restent à donner), « Objet ici », et les marchands du lieu.'],
        ['Trame', 'Les étapes et jalons qui se jouent ici, les pistes commencées à y faire reparaître ; le sablier ouvre l\'élément dans le Déroulé.'],
        ['Lieu', 'Vos notes sur le lieu, les trajets au départ d\'ici (distance et temps de marche), ses images, et l\'historique des déplacements (corriger le lieu actuel, retirer une ligne, « Annuler »).'],
      ] },
    ],
  },
  {
    id: 'horloge', groupe: 'widget', titre: 'Horloge', icone: 'lune',
    resume: 'Le temps de jeu : jour de campagne, date, heure, moment (aube, jour, crépuscule, nuit), météo, lune, jours marqués, dernier repos long. Le temps n\'avance que quand vous le décidez.',
    blocs: [
      { titre: 'Lire l\'horloge', points: [
        ['Jour et date', '« Jour 1 · date · année ». Au survol de la date, une ligne sur ce jour ; un clic ouvre la fenêtre du jour (fêtes, entrées d\'agenda, météo de la journée à copier pour le compte rendu, le calendrier en détail).'],
        ['Ligne du ciel', 'Le temps qu\'il fait sur ce créneau ; avec un ciel toujours voilé, une icône de brume rappelle la règle du monde.'],
        ['Heure', 'Un clic règle l\'horloge : jour, heure, dernier repos long, lever et coucher du soleil. Pour rattraper un oubli.'],
        ['Réduit', 'La barre garde l\'icône du moment, l\'heure, la météo, où sont les héros et l\'activité en cours.'],
      ] },
      { titre: 'Faire passer le temps', points: [
        ['Les héros sont', 'À l\'abri, sur la route ou en pleine nature : décide s\'il y a des tests de rencontre.'],
        ['+', 'Avancer de 10 min, 30 min, 1 h ou 4 h. Dès une heure dehors, une fenêtre mène le temps heure par heure, avec un test de rencontre par heure.'],
        ['Court, long', 'Repos court (1 h) ; repos long (8 h, jusqu\'à l\'heure ronde suivante, noté comme dernier repos long).'],
        ['→ aube, → soir', 'Attendre le lever ou le coucher du soleil.'],
        ['Flèche de retour (Annuler)', 'Défait la dernière avancée, et propose de défaire aussi ce qui s\'est passé pendant ce temps (tests, arrivées, rencontres lancées).'],
        ['Activité en cours', 'Un trajet, un repos, une attente se mènent dans une fenêtre ; fermée, la carte de l\'activité la rouvre.'],
        ['Sans aléatoires', 'Dans la fenêtre d\'une activité : coupe les tests de rencontre aléatoire (enfoncé), ou les reprend. Un campement garde le choix du trajet.'],
        ['Rencontres prévues de la route', 'Dans la fenêtre d\'un trajet : les rencontres prévues entre deux lieux de l\'itinéraire, celles du tronçon en cours en tête ; un clic pour l\'ouvrir ou la lancer.'],
        ['Journal', 'Les avancées ; la dernière s\'annule, une plus ancienne se retire sans changer l\'heure.'],
      ] },
      { titre: 'L\'agenda', points: [
        ['Bouton calendrier', 'Le calendrier de l\'année, mois par mois : aujourd\'hui en rouge, jours passés estompés, jours marqués d\'une étoile, entrées d\'agenda en orange.'],
        ['Une date', 'Ses jours marqués, ses entrées (modifier, retirer, revenir au texte du fichier), « Ajouter une entrée » : un nom, des détails, et des alertes (le jour même, N jours avant).'],
        ['Rappels', 'Quand l\'horloge passe à un jour suivant, une fenêtre rappelle les entrées qui arrivent.'],
      ] },
      { titre: 'Alertes', points: [
        ['Fatigue +1', 'Plus de 24 h sans repos long : un rappel replié (vous jugez).'],
        ['La nuit tombe, le temps change', 'Une annonce en haut du tableau.'],
      ] },
    ],
  },
  {
    id: 'rencontres', groupe: 'widget', titre: 'Rencontres', icone: 'loup',
    resume: 'Les rencontres aléatoires : test à chaque heure de voyage, tirage sur les tables de jour et de nuit, fiche prête à jouer, journal.',
    requiert: 'rencontres-aleatoires',
    blocs: [
      { titre: 'Onglet Tirage', points: [
        ['Jour, Nuit', 'La table à utiliser ; elle suit l\'horloge (la forcer demande confirmation).'],
        ['Abri, Route, Nature', 'Où sont les héros : à l\'abri, pas de test ; sur la route ou en nature, le seuil du test change.'],
        ['Jauge « 12 h »', 'Le plafond de rencontres sur la période (réglable dans Campagne) ; atteint, plus de test.'],
        ['Cases', 'Les modificateurs de la table (un guide…) et « À l\'arrêt » (certaines rencontres n\'arrivent qu\'en marche).'],
        ['Tester', 'Le test de rencontre de l\'heure. Il est noté au journal ; s\'il réussit, la rencontre n\'est que proposée.'],
        ['Rencontre', 'Tire une rencontre sans test. Rien n\'est noté tant que vous ne la lancez pas : fermer la fenêtre, c\'est n\'avoir rien tiré.'],
        ['Événements', 'Les événements de la campagne (des espions qui suivent les héros…), s\'ils sont activés : « Ajouter comme rencontre » ou « Passer ».'],
      ] },
      { titre: 'La fiche d\'une rencontre', points: [
        ['Lancer', 'Ouvre la préparation (monstres reliés à leur nombre tiré, difficulté), puis « Lancer le combat » : la rencontre est notée et passe dans Combat.'],
        ['Noter, Écarter', 'Noter une trouvaille (elle compte) ; écarter la rencontre d\'un test (le test reste noté).'],
        ['Relancer', 'Le nombre d\'une créature.'],
        ['Rencontre unique', 'La cacher des tables une fois jouée (case « Rencontrée »), ou la garder.'],
        ['Suivi', 'Une conséquence à garder en tête : « Noter le suivi » ; elle s\'affiche dans l\'onglet Tirage jusqu\'à « Résolu ».'],
        ['Notes', 'Ce qui s\'est passé.'],
      ] },
      { titre: 'Les autres onglets', points: [
        ['Tables', 'Les tables entières : le dé d\'une ligne la tire, l\'œil cache une rencontre ; un clic sur une créature la relie d\'avance à son monstre de D&D Beyond (soulignée en orange tant qu\'elle ne l\'est pas). « Règles du tirage » en bas.'],
        ['Hors tables', 'Les rencontres prévues et celles que vous créez, dans l\'ordre de la campagne ; un clic ouvre leur menu (Ouvrir, Lancer, Marquer terminée, Supprimer). « + Rencontre » en crée une.'],
        ['Journal', 'Les tests et rencontres notés ; la croix efface une ligne (son numéro et sa place dans le plafond sont rendus). « Vider le journal », « Tout remettre à zéro ».'],
      ] },
    ],
  },
  {
    id: 'deroule', groupe: 'widget', titre: 'Déroulé', icone: 'sablier',
    resume: 'La trame de la campagne : les arcs et leurs étapes (indicatives), leurs jalons, et les pistes à garder en tête. Rien n\'est terminé d\'office, et rien ne déplace les héros sans vous le demander.',
    requiert: 'deroule-campagne',
    blocs: [
      { titre: 'La frise', points: [
        ['Une étape', 'Son numéro, son nom, ses niveaux, ses lieux, sa description et ce qui marque sa fin. Plusieurs étapes peuvent être en cours.'],
        ['Démarrer, Plus en cours, Marquer terminée, Rouvrir', 'Le statut de l\'étape. Démarrer propose de terminer celle d\'avant (et ses jalons), de commencer les pistes attendues, et demande si les héros se rendent au lieu.'],
        ['Un jalon', 'Un moment précis (trajet, rencontre prévue, événement, amorce, halte) : un clic ouvre sa fenêtre, avec « Marquer en cours », « Marquer terminé », « Rouvrir », « Rencontre » et « Objet ».'],
        ['Démarrer le trajet', 'Sur un jalon de trajet : le dialogue de départ (rythme, guides…), puis le trajet heure par heure dans l\'Horloge.'],
        ['Fin atteinte', 'Tous les jalons clés d\'une étape sont faits : le widget propose de la terminer.'],
      ] },
      { titre: 'L\'en-tête du widget', points: [
        ['Résumé', 'L\'étape de référence (la dernière démarrée), les autres en cours, les jalons en cours ; un clic y ramène.'],
        ['Cible', 'Va à l\'étape en cours la plus haute de la frise.'],
        ['Personnage', 'Filtre la frise et les pistes sur la quête personnelle d\'un héros.'],
        ['Pistes (avec un nombre)', '« À garder en tête » : les pistes par groupes, de la plus urgente à la moins : à jouer maintenant, à décider (Commencer ou Terminer d\'un bouton), en veille (avec leur prochaine résurgence), à venir et terminées repliées. Les étapes en petits carrés numérotés, leur nom en infobulle. Les boutons des joueurs filtrent ; « Étapes en cours » ne garde que les deux premiers groupes. Un clic sur un en-tête trie la colonne ; d\'office, les pistes des joueurs d\'abord. Vue normale : sans les textes de départ et de fin ; vue détaillée : tous les textes.'],
        ['Flèche', 'Étape suivante : la démarrer.'],
      ] },
      { titre: 'Terminer, et ce qui reste', points: [
        ['Avant de terminer', 'Terminer un jalon, une étape ou une piste liste ce qui reste : jalons et trajets pas terminés, rencontres pas jouées, pistes pas commencées, PNJ pas rencontrés, objets pas donnés. Un clic ouvre chaque élément pour le régler, sans bloquer le reste de la page. Le secondaire (facultatif, PNJ mineurs, sur place) est replié.'],
        ['Terminer, tout est bon', 'Terminé et validé par le MJ. « Terminer, à revoir » : terminé, avec une alerte sur sa ligne.'],
        ['Symbole d\'alerte', 'Sur un élément terminé auquel il reste quelque chose d\'important, en rouge ; un clic ouvre ce qui reste, pour le régler ou pour valider (« Tout est bon »). Validé, il passe en jaune, plus petit : « Validé par le MJ ».'],
        ['Jalons clés terminés', 'Sous la fin d\'une étape, un clic ouvre ses jalons clés dans une fenêtre.'],
        ['En quittant un lieu', 'Une annonce dit ce qui y reste, avec « Voir ». À la fin d\'un trajet, une fenêtre liste ses rencontres prévues pas jouées et son jalon pas terminé.'],
      ] },
      { titre: 'Les pistes', points: [
        ['Une piste', 'Un fil de fond à faire reparaître : ses résurgences, c\'est-à-dire où et comment (étapes, lieux, jalons, trajets), ses rencontres et PNJ. Commencer, Terminer, Plus commencée, Rouvrir.'],
        ['Résurgences à jouer', 'Celles d\'une étape ou d\'un jalon en cours, du lieu où sont les héros, d\'une route qui en part, et pas encore jouées. La vue détaillée déplie les autres. Chaque résurgence a sa case : cochez-la une fois jouée (un clic l\'annule) ; cela commence la piste si elle ne l\'était pas. La case est la même partout : « À garder en tête », fenêtre de la piste, arbre d\'une étape, ce qui reste.'],
        ['Remarque sur une résurgence', 'Le petit crayon à côté de sa case, qu\'elle soit jouée ou non : ce qui s\'est passé, ou pourquoi vous l\'avez sautée. Le crayon devient violet, la remarque s\'affiche sous la résurgence (dans l\'arbre : en petit nœud dessous), et la fin de session la reprend. Une résurgence sautée reste listée dans ce qui reste : « Tout est bon : valider » lève l\'alerte de l\'étape.'],
        ['Remarque sur le début, la fin', 'Dans la fenêtre d\'une piste, le même crayon sur ses lignes « Début » et « Fin » : comment elle s\'est vraiment ouverte ou conclue à la table. La remarque s\'affiche dessous, en nœud sous la piste dans l\'arbre, dans la vue détaillée de « À garder en tête », et la fin de session la reprend.'],
        ['Remarque', 'Dans la fenêtre d\'un jalon ou d\'une piste et sous une étape : ce qui s\'est passé, même sans rencontre. Un petit livre sur la ligne dit qu\'il y en a une ; la fin de session la reprend.'],
        ['Arbre', 'Sous une étape : ses jalons et ce qu\'ils portent, ses pistes et où elles mènent, en branches, dans une fenêtre en plein écran qui défile dans les deux sens. Le carré d\'un nœud compte ce qu\'il y a dessous, « faits / total » : jalons terminés, rencontres jouées, objets donnés, PNJ rencontrés, pistes commencées, résurgences jouées ; seulement ce qui est de cette étape, et chaque élément une seule fois même s\'il paraît à plusieurs endroits. Une piste repliée montre ses résurgences à jouer ; dépliée, toutes. Couleurs des résurgences : orange, à jouer dans cette étape ; bleu, jouée dans cette étape ; rouge, elle aurait dû être jouée dans une étape d\'avant ; en sourdine, passée ou d\'une étape à venir. La piste prend la couleur de la plus pressante.'],
        ['Deux étapes au même lieu', 'Quand deux étapes se jouent au même lieu (une maison, puis son sous-sol), chacune ne montre et ne compte que ce qui est de ses pièces : PNJ, rencontres et objets, dans l\'arbre comme dans ce qui reste à faire. Le gestionnaire le déduit des jalons de chaque étape (ceux qui citent l\'élément, ceux qui se passent dans sa pièce) ; les données peuvent aussi le dire (« sous_lieux » d\'une étape, « etapes » d\'un élément). Ce qu\'il ne sait pas ranger reste dans toutes les étapes du lieu.'],
        ['À commencer ? À terminer ?', 'Son jalon de début est arrivé, ou son jalon de fin est terminé.'],
      ] },
    ],
  },
  {
    id: 'pnj', groupe: 'widget', titre: 'PNJ', icone: 'crocs',
    resume: 'Qui est qui : les PNJ par lieu et sous-lieu, avec leur fiche et leur suivi de campagne.',
    requiert: 'pnj',
    blocs: [
      { titre: 'Trouver un PNJ', points: [
        ['Recherche', 'Par nom, alias, rôle, profil ou notes du MJ.'],
        ['Filtres', 'Lieu, état, rang (VIP, majeurs, mineurs), faction, savoir (ceux qui en savent long sur une intrigue). Le bouton à curseurs de la barre les masque (orange s\'ils cachent un filtre actif).'],
        ['Suivre la zone', 'La liste s\'ouvre sur le lieu où sont les héros.'],
        ['Vus', 'Un clic fait le tour : tous, déjà rencontrés, pas encore rencontrés.'],
        ['Flèche de tri', 'Par rang (VIP, majeurs, mineurs) ou dans l\'ordre du lieu.'],
      ] },
      { titre: 'Une ligne', points: [
        ['Nom', 'Un clic ouvre sa fiche : profil, rôle, description, factions, ce qu\'il sait, images de la galerie, décision du MJ, version du livre, et son suivi (état en jeu, notes).'],
        ['Puce de rang', 'VIP, M ou m : un clic change son rang en jeu.'],
        ['Vu', 'Marque le PNJ comme rencontré (partagé avec Ici et Factions).'],
        ['Factions secrètes', 'Masquées tant que vous ne demandez pas à les voir.'],
      ] },
    ],
  },
  {
    id: 'factions', groupe: 'widget', titre: 'Factions', icone: 'bouclier',
    resume: 'Les factions, peuples et assemblées de la campagne, par type.',
    requiert: 'factions',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Une faction', 'Un clic ouvre sa fiche : description, lieux, membres triés par rang (un clic sur un membre ouvre sa fiche de PNJ, « Vu » le marque rencontré).'],
        ['Factions secrètes', 'Une case les affiche (« Jamais côté joueurs »).'],
      ] },
    ],
  },
  {
    id: 'trajets', groupe: 'widget', titre: 'Trajets', icone: 'carte',
    resume: 'Un itinéraire tronçon par tronçon : distances, temps de marche, journées de 8 heures, rythme et monture, tests de rencontre à prévoir.',
    requiert: 'temps-de-voyage',
    blocs: [
      { titre: 'Composer l\'itinéraire', points: [
        ['Sur la carte', 'Un clic sur un lieu ajoute une étape ; le clic droit retire le dernier point. Les lieux en jaune, l\'itinéraire en orange, le dernier lieu atteint en rond plein.'],
        ['Afficher la carte, Agrandir', 'Montrer la carte dans le widget, ou en grand dans une fenêtre (aussi depuis le menu rapide).'],
        ['Retirer le dernier, Nouvel itinéraire, Effacer', 'Défaire un tronçon, repartir de zéro. Les deux premiers sont répétés en icônes au bout de la ligne des options, s\'il y a la place.'],
        ['Rythme', 'Lent, normal ou rapide (à pas de loup, en marche, en course), et la monture : le temps de marche suit. Le terrain difficile double le temps.'],
        ['Miles ou km', 'L\'unité des distances (l\'autre au survol).'],
      ] },
      { titre: 'Partir', points: [
        ['Démarrer le trajet', 'Le trajet se mène heure par heure dans l\'Horloge, avec un test de rencontre par heure (ou « Sans aléatoires » : seulement les rencontres prévues de la route) ; à l\'arrivée, les héros sont au bout.'],
        ['Arriver', 'Noter les lieux traversés, sans suivre l\'heure.'],
        ['Plus de 8 h de marche', 'Marche forcée ou campement : un clic pour les règles.'],
        ['Repartir de…', 'Recommencer un itinéraire depuis le lieu atteint.'],
      ] },
    ],
  },
  {
    id: 'marchands', groupe: 'widget', titre: 'Marchands', icone: 'piece',
    resume: 'Boutiques, tavernes et auberges par ville, avec un panier.',
    requiert: 'marchands',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Ville', 'D\'office celle où sont les héros.'],
        ['Recherche', 'Un article ou une boutique, dans toute la ville. Le bouton à curseurs de la barre masque la recherche et le choix de la ville (orange s\'il cache une recherche).'],
        ['Un marchand', 'Un clic ouvre sa fiche : description, tenanciers (un clic : leur fiche de PNJ), règle de prix, services, articles triables par nom ou par prix ; « + » met un article au panier.'],
        ['Panier', 'Les articles et leur nombre (+ / −), une ligne libre (une épée longue chez l\'armurier, avec son prix), le total en po, pa et pc. « Vider le panier ».'],
      ] },
    ],
  },
  {
    id: 'objets', groupe: 'widget', titre: 'Objets', icone: 'amulette',
    resume: 'Les objets à trouver dans la campagne (magiques, équipement, trésors, documents) et ceux que vous créez, à donner aux héros jusque dans D&D Beyond.',
    blocs: [
      { titre: 'La liste', points: [
        ['Recherche', 'Par nom français ou anglais.'],
        ['Filtres', 'État (à donner, donnés), genre, lieu ; « Ici » (l\'épingle) : là où sont les héros, sous-lieux compris.'],
        ['+ Objet', 'Créer un objet (aussi depuis Ici, un jalon, une étape ou une rencontre).'],
        ['Barre du widget', 'Même réduit, combien d\'objets restent à donner là où sont les héros.'],
      ] },
      { titre: 'La fenêtre d\'un objet', points: [
        ['Objet de D&D Beyond', 'Choisi dans le catalogue des livres de la campagne (recherche par le nom anglais ; souvent choisi d\'office), ou un objet personnalisé (nom, description, commentaire, poids, valeur).'],
        ['Donner', 'À un héros ou au groupe : il arrive dans l\'inventaire D&D Beyond, sous son nom français. Le don est noté. Le nombre n\'est pas limité : en donner plus que prévu augmente le total, et un objet déjà donné se donne encore (« Donner encore »).'],
        ['Annuler un don', 'Jamais de retrait automatique sur D&D Beyond : « Retrait demandé » (les joueurs le retirent), puis « C\'est fait : annuler le don », ou « Garder le don ».'],
        ['Terminer une étape ou un jalon', 'Le gestionnaire rappelle d\'abord les objets qui y tiennent et ne sont pas encore donnés.'],
      ] },
    ],
  },
  {
    id: 'connaissances', groupe: 'widget', titre: 'Qui sait quoi', icone: 'oeil',
    resume: 'Pour chaque intrigue secrète, qui en sait quoi ; et ce que tout le monde croit savoir.',
    requiert: 'connaissances',
    blocs: [
      { titre: 'Utiliser', points: [
        ['La grille', 'Les groupes en lignes, les sujets en colonnes (leur icône quand le widget est étroit). Une pastille pleine : oui ; à moitié : en partie ; un petit rond creux : non.'],
        ['Une case, un groupe', 'Un clic ouvre le détail : ce qu\'ils savent, à qui demander (les membres qui en savent long, « Fiche du PNJ »).'],
        ['Savoir commun', 'Par thème (une liste) : ce que tout le monde sait ou croit. « Fausses » ne montre que les croyances fausses, en rouge avec « En vérité : ».'],
        ['À propos de cette grille', 'Replié en bas : résumé, chaîne d\'informateurs, règle.'],
      ] },
    ],
  },
  {
    id: 'images', groupe: 'widget', titre: 'Images', icone: 'carte',
    resume: 'Les cartes et illustrations de la campagne, à retrouver vite et à montrer aux joueurs.',
    blocs: [
      { titre: 'Trouver une image', points: [
        ['Recherche', 'Par titre, PNJ ou dossier.'],
        ['Filtres', 'Source, catégorie, lieu, PNJ ; « Ici » (l\'épingle) : là où sont les héros. Les versions joueurs des cartes se montrent ou se cachent.'],
        ['Flèche de tri', 'Regrouper par lieu, par source, par catégorie, ou tout par titre.'],
        ['Barre du widget', 'Le nombre d\'images affichées (« 9 sur 249 »).'],
      ] },
      { titre: 'Une image', points: [
        ['Fenêtre', 'L\'image, sa catégorie (à changer), ses lieux et PNJ (déduits du nom du fichier : à retirer, ou à ajouter en étiquettes).'],
        ['En grand', 'Par-dessus tout le gestionnaire, en plein écran si le navigateur l\'accepte : pour la montrer aux joueurs. Un clic, Échap ou la croix ferment. Avec le plugin Écran des joueurs, un bouton l\'envoie sur leur écran.'],
        ['Écran des joueurs', 'Avec le plugin du même nom : montrer l\'image aux joueurs, l\'afficher comme carte (1 pouce par case), ou en faire le fond du tableau des joueurs pour un de ses lieux ou pour la campagne.'],
        ['Bibliothèque', 'Ses sources se règlent dans Campagne, onglet « Images ».'],
      ] },
    ],
  },
  {
    id: 'musique', groupe: 'widget', titre: 'Musique', icone: 'lu-music',
    resume: 'La musique d\'ambiance des playlists YouTube, le son seul, en boucle. Elle continue quand le widget est réduit ou dans un autre mode.',
    blocs: [
      { titre: 'L\'en-tête', points: [
        ['Lancer, Arrêter', 'La piste choisie, en boucle.'],
        ['Mini-boutons', 'Les thèmes de début et de fin de séance, et celui de chaque héros (jamais en boucle).'],
        ['Volume', 'Propre à ce poste.'],
      ] },
      { titre: 'Trouver une piste', points: [
        ['Recherche', 'Parmi toutes les pistes : nom, titre YouTube, étiquettes, playlist.'],
        ['Thème, Lieu, PNJ / Factions, Auteurs / Playlists', 'Des filtres en boutons ; un nouveau clic sur le bouton ouvert passe à l\'autre vue (PNJ ou factions, auteurs ou playlists). Lieu a « Ici », le lieu des héros.'],
        ['Une étiquette d\'une ligne', 'Un clic filtre sur elle.'],
        ['Étoile', 'Favori.'],
        ['Crayon', 'Retoucher les étiquettes d\'une piste ; « Rétablir » rend celles de l\'import ; « Cacher » la retire de la liste (« Montrer » la remet).'],
      ] },
      { titre: 'Ajouter de la musique', points: [
        ['Thèmes de la campagne et des héros', 'Chaque MJ règle les siens : l\'identifiant YouTube d\'une vidéo dans `themes` de musique/sources.json (`ouverture` et `fin` pour le début et la fin de séance, `pj:<id du héros>` pour un héros), puis outils/Importer la musique.cmd. Sans thème, le mini-bouton du héros reste grisé.'],
        ['musique/sources.json', 'Les playlists et vidéos de la campagne, puis outils/Importer la musique.cmd.'],
      ] },
    ],
  },
  {
    id: 'noms', groupe: 'widget', titre: 'Noms', icone: 'lettre',
    resume: 'Un prénom et un nom de famille accordé au genre, en un clic, pour un PNJ improvisé.',
    requiert: 'noms',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Tirer un nom', 'Prénom et nom, selon le genre choisi.'],
        ['Autre prénom, Autre nom', 'Relancer une seule moitié.'],
        ['Copier', 'Le nom complet.'],
        ['Retenir', 'Garder le nom avec une note (« l\'aubergiste du gué ») ; la croix en efface un ; « Effacer les non retenus ».'],
      ] },
    ],
  },
  {
    id: 'babioles', groupe: 'widget', titre: 'Babioles', icone: 'cle',
    resume: 'Les petits objets étranges à faire trouver aux héros.',
    requiert: 'babioles',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Table', 'Les tables de la campagne (par exemple : avancées, basiques, des joueurs).'],
        ['Tirer', 'Une babiole dans la table, sauf celles déjà données (case « Écarter du tirage les babioles déjà données »).'],
        ['Parcourir', 'La table entière, filtrée par thème, type de lien, élément lié, données ou non, et recherche ; « Tirer parmi ces lignes ».'],
        ['Une babiole', 'Sa fenêtre : le texte à lire aux joueurs, ses liens (PNJ, lieux, factions), le secret du MJ replié, « Donner » à un héros ou au groupe (jusque dans D&D Beyond).'],
        ['Derniers tirages', 'Les rouvrir, ou retirer un tirage de la liste.'],
      ] },
    ],
  },
  {
    id: 'maisons', groupe: 'widget', titre: 'Maisons', icone: 'porte',
    resume: 'Qui ouvre la porte d\'une maison quelconque d\'un village ou d\'une ville.',
    requiert: 'occupants-maisons',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Lancer le d20', 'Les occupants, leurs nombres lancés (relançables), et comment les jouer.'],
        ['Lancer (une ligne avec des créatures)', 'Si ça tourne à la rencontre : sa préparation (créatures reliées à leur nombre, difficulté), puis « Lancer le combat ». Elle ne compte pas dans le plafond des rencontres aléatoires.'],
      ] },
    ],
  },
  {
    id: 'faune', groupe: 'widget', titre: 'Faune', icone: 'corbeau',
    resume: 'Les animaux de la campagne par milieu, pour décrire une forêt ou un marais.',
    requiert: 'faune',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Milieux', 'Les bêtes de chaque milieu (bois, marais, montagnes…).'],
        ['Tirer', 'Un prédateur, un gibier ou un oiseau au hasard dans un milieu.'],
      ] },
    ],
  },
  {
    id: 'des', groupe: 'widget', titre: 'Dés', icone: 'd20',
    resume: 'Des dés qui roulent en 3D sur toute la page, le résultat en très grand au centre.',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Un dé', 'Un clic en ajoute un (d4 à d100) ; le clic droit ou « − » en retire un.'],
        ['Modificateur', '+ et − ; un clic sur la valeur la remet à 0.'],
        ['Avantage, désavantage', 'Pour un d20.'],
        ['Lancer', 'Les dés roulent ; un 20 naturel brille, un 1 naturel s\'éteint. La croix retire tous les dés et le modificateur.'],
        ['Historique', 'Les derniers jets, ceux de ce widget et ceux du gestionnaire (initiative, nombre de monstres, jets des fiches), avec leur motif ; « Relancer » une formule.'],
      ] },
    ],
  },
  {
    id: 'regles', groupe: 'widget', titre: 'Règles', icone: 'livre',
    resume: 'Questions de règles de D&D 2024 : un assistant cherche dans le SRD 5.2.1 (VF et VO) et répond en citant ses pages. Facultatif : il s\'installe à part (outils/Installer l\'assistant de règles.cmd).',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Question', 'Tapez-la, Entrée l\'envoie (Maj + Entrée : à la ligne). La réponse arrive au fil de l\'eau ; « Arrêter la réponse » la coupe.'],
        ['Citations', '« [DRS p. 187] » ouvre le PDF à la page ; les sources s\'ouvrent en fenêtre, avec leur section entière.'],
        ['Loupe (Recherche seule)', 'Les passages trouvés, sans modèle : instantané, et sans Ollama ni clé. Orange quand elle est activée.'],
        ['Nouvelle conversation', 'L\'assistant oublie les questions précédentes.'],
        ['Réessayer', 'Si le service ne répond pas (il démarre avec le gestionnaire quand il est installé).'],
      ] },
    ],
  },
  {
    id: 'minuteur', groupe: 'widget', titre: 'Minuteur', icone: 'sablier',
    resume: 'Un compte à rebours compact pour limiter un moment (une décision, une pause, une épreuve).',
    blocs: [
      { titre: 'Utiliser', points: [
        ['+1′, +5′, +10′, +30′', 'À l\'arrêt, ils composent la durée ; en marche ou en pause, ils prolongent le temps restant.'],
        ['Lecture, Pause', 'Lancer, suspendre.'],
        ['Remettre à zéro', 'Revient à 0:00.'],
        ['Rechargement', 'Le minuteur continue si la page est rechargée.'],
      ] },
    ],
  },
  {
    id: 'convertisseur', groupe: 'widget', titre: 'Pieds ↔ m', icone: 'epingle',
    resume: 'Pieds, mètres et cases de 5 pieds, dans les deux sens.',
    blocs: [
      { titre: 'Utiliser', points: [
        ['Pieds, Mètres', 'Tapez dans l\'un : l\'autre et les cases suivent.'],
        ['Règle', 'Celle de la VF (5 pieds = 1,5 m) ou la valeur exacte (0,3048 m par pied).'],
      ] },
    ],
  },

  // ───────────── Modules de campagne ─────────────
  {
    id: 'tarokka', groupe: 'module', titre: 'Tarokka', icone: 'tarokka',
    resume: 'Module de campagne pour Curse of Strahd seulement (choisi à la création) : la lecture de madame Éva et les tirages personnels, préparés d\'avance dans data/tarokka.json.',
    requiert: 'tarokka',
    blocs: [
      { titre: 'Les onglets', points: [
        ['Tirage', 'Les cinq cartes, face cachée tant que le tirage n\'est pas validé : un clic retourne une carte, un autre ouvre son détail (la prophétie à lire, l\'encadré « Pour le MJ », « Trouvé », vos notes). L\'icône « Cacher » les recache.'],
        ['Joueurs', 'Un bouton par héros ; à droite, le tourment et la voie expliqués, ou les deux cartes du héros choisi.'],
        ['Édition', '« Noter les cartes » réellement posées, puis valider : le tirage se verrouille. « Forcer la modification » pour corriger une erreur, « Retirer la validation ».'],
        ['Déroulement', 'Calculé d\'après le tirage : l\'ordre des paquets, la croix, les étapes.'],
      ] },
      { titre: 'Ailleurs', points: [
        ['Table de madame Éva', 'Bouton de l\'en-tête : la croix et les joueurs en plein écran, la prophétie au survol.'],
        ['Réduit', 'Les cinq cartes en miniature dans la barre, auréolées d\'or une fois l\'objet trouvé ou l\'allié recruté.'],
        ['Déroulé, Ici', 'Ce que les cartes placent aux étapes et aux lieux.'],
      ] },
    ],
  },

  // ───────────── Plugins ─────────────
  {
    id: 'the-table', groupe: 'plugin', titre: 'The Table', icone: 'lu-lamp',
    resume: 'Plugin pour le boîtier The Table, le ruban LED qui entoure votre table de jeu (ESP32 sur le Wi‑Fi de la maison). À activer pour la campagne dans la fenêtre Campagne, onglet Plugins. Sans boîtier, il ne sert à rien.',
    blocs: [
      { titre: 'Brancher', points: [
        ['Adresse, jeton', 'http://the-table.local d\'office (ou l\'IP de sa page, onglet Boîtier ; http://192.168.4.1 en mode autonome). Le jeton seulement s\'il est réglé sur la table (Boîtier, Accès).'],
        ['Tester', 'Lit la version du boîtier, les joueurs installés et qui gère le combat. Si ça échoue : même Wi‑Fi ? l\'adresse répond-elle dans un onglet ? Chrome demande parfois l\'accès aux appareils du réseau local.'],
        ['Héros et joueurs', 'Les joueurs et leurs places se règlent sur la page de The Table. Chaque héros est relié au joueur de même nom ; choisissez-le ici quand les noms diffèrent.'],
      ] },
      { titre: 'Pendant un combat', points: [
        ['Piloter The Table', 'Dès que le combat démarre dans Combat, la place du joueur dont c\'est le tour s\'éclaire, le cadre passe au rouge au tour d\'un monstre, et la page de The Table affiche « Combat piloté par The Screen ». Tour suivant, renforts, initiative changée : tout suit. Terminer, annuler ou remettre à zéro rend la main.'],
        ['Point dans l\'en-tête de Combat', 'Gris : pas de combat. Vert : synchronisée. Orange : la table ne répond pas (le combat continue, elle se resynchronise seule à son retour), ou vous avez repris la main sur sa page. Rouge : jeton ou envoi refusé. Un clic ouvre la fenêtre The Table.'],
        ['Reprendre la main, Reconnecter', '« Reprendre la main » sur la page de The Table coupe le pilotage sans arrêter le combat ici ; « Reconnecter » (fenêtre ou widget The Table) le reprend. Page fermée en plein combat : la table repasse en mode local au bout de 15 min.'],
        ['Effets lumineux', 'Dégâts et soins d\'un héros (Combat) sur sa place ; 20 naturel d\'un héros, éclat or sur sa place ; 20 naturel d\'un monstre (jet de sa fiche), flash rouge sur toute la table. Décochable.'],
      ] },
      { titre: 'Le widget The Table', points: [
        ['État', 'Le point et son texte, « Reconnecter » ou « Réessayer » quand il le faut.'],
        ['Ambiances', 'Celles de la table (brume, taverne, orage… et celles que vous créez sur sa page), l\'ambiance en cours en surbrillance ; un clic change. « Actualiser » les relit.'],
        ['Effets', 'Critique, Dégâts, Soins, Éclair sur toute la table, d\'un clic.'],
      ] },
    ],
  },
  {
    id: 'ecran-joueurs', groupe: 'plugin', titre: 'Écran des joueurs', icone: 'lu-monitor',
    resume: 'Plugin pour une seconde fenêtre destinée aux joueurs, en plein écran sur un autre écran (une TV à plat sous les figurines, un écran partagé) : la carte du lieu à 1 pouce par case, avec le brouillard de combat ; sans carte, le tableau des joueurs. À activer pour la campagne dans la fenêtre Campagne, onglet Plugins.',
    blocs: [
      { titre: 'Brancher', points: [
        ['Ce poste', 'Fenêtre Campagne, onglet « Ce poste » : l\'écran où ouvrir la fenêtre (« Lister les écrans » demande une autorisation à Chrome, une fois) et la largeur de la dalle, en pouces, en centimètres ou par la diagonale 16/9. Propre à ce PC.'],
        ['Mire', 'Affiche sur l\'écran des joueurs un carré de 1 pouce, 10 cm et la grille des cases : posez une règle. Si la grille ne va pas jusqu\'aux bords, la TV coupe l\'image (« Scan uniquement » dans ses réglages).'],
        ['Écran (en-tête du widget)', 'Le point d\'état : gris, fenêtre fermée (un clic l\'ouvre sur l\'écran choisi, en plein écran quand Chrome le permet) ; orange, ouverte mais pas en plein écran (un clic dans la fenêtre, ou F11) ; vert, en plein écran. Clic droit : la fermer.'],
        ['Onglet Plugins', 'Rotation par défaut, grille dessinée d\'office, le tableau des joueurs et ses seuils (« Ensanglanté », « Critique » en % des PV), l\'image de campagne du tableau.'],
      ] },
      { titre: 'À l\'écran et atelier', points: [
        ['Deux zones', 'En haut, le bandeau « À l\'écran » : ce que voient les joueurs en ce moment (sa miniature, son nom) et les seules commandes de leur écran. Dessous, l\'atelier : la carte que vous préparez, avec ses outils. Ouvrir ou changer de carte dans l\'atelier ne change jamais l\'écran.'],
        ['Diffuser', 'Le bouton de l\'atelier, quand sa carte n\'est pas à l\'écran (pastille « Pas à l\'écran ») : elle y va, et vous êtes en direct dessus. Préparez-la d\'abord tranquillement : calibrage, brouillard, jetons.'],
        ['En direct', 'La pastille « En direct » : la carte de l\'atelier est celle de l\'écran, chaque geste (brouillard, jetons, cadrage, ping) part aux joueurs. Rien à basculer.'],
        ['Geler', 'Le flocon du bandeau, carte à l\'écran : les joueurs la gardent telle qu\'elle est, le temps de la retoucher dans l\'atelier sans rien montrer (« Retouches en attente »). Un nouveau clic, ou « Diffuser », leur envoie vos retouches et rend le direct.'],
        ['Retour au tableau', 'Le bouton aux silhouettes du bandeau, carte à l\'écran : le tableau des joueurs revient à l\'écran, la carte reste dans l\'atelier.'],
        ['Miniature', 'La miniature du bandeau est l\'écran des joueurs, tel quel. Un clic la met en grand sous l\'atelier, un autre la range.'],
      ] },
      { titre: 'La carte', points: [
        ['Choisir', 'Le nom de la carte, dans l\'atelier, ouvre la liste : d\'abord les cartes du lieu où sont les héros (sous-lieux compris), puis toutes les cartes par lieu ; « J » : la carte a une version joueurs, c\'est elle qu\'ils verront. La fenêtre d\'une image de carte propose aussi « Préparer comme carte ». Rien ne part à l\'écran avant « Diffuser ».'],
        ['Calibrer', 'Une fois par carte : l\'outil règle, zoomez à la molette sur une case bien nette, puis deux clics sur deux de ses coins (un côté, ou la diagonale). Plus précis : « sur N cases » à côté de l\'outil, et deux coins à N cases l\'un de l\'autre. La grille se dessine pour vérifier ; refaites si elle ne tombe pas sur les traits. L\'échelle est gardée avec la carte.'],
        ['Échelle', '« 1″ » : 1 pouce par case sur l\'écran des joueurs (carte calibrée, écran mesuré) ; « Entière » : toute la carte ; « Zoom + » et « Zoom − » : libre (« ×1,5 »). Tout cela change ce que voient les joueurs.'],
        ['Déplacer, rotation, grille', 'La main : glissez le cadre orange (ce que voient les joueurs) sur la carte. Rotation par quarts de tour. Grille : la grille des cases dessinée par-dessus (carte sans grille, illustration).'],
        ['Projection', 'La carte entière, le cadre des joueurs en orange, le dehors en sourdine, le brouillard translucide : ce qu\'il y a dans le cadre est, à l\'échelle près, ce que la TV montre.'],
        ['Zoomer la projection', 'D\'office, votre projection montre toute la carte et, s\'il en déborde, tout le cadre des joueurs (une carte plus petite que leur écran se place dans l\'écran). La molette zoome autour du pointeur (pour viser les coins au calibrage, ou voir la zone projetée de près), jamais plus loin que cette vue d\'ensemble ; la cible alterne la vue sur la zone projetée et la vue d\'ensemble. Avec la main, glissez le cadre par son bord ; ailleurs, vous glissez la carte sous le cadre, qui reste à sa place à l\'écran (ce que voient les joueurs change). Le bouton droit (ou Ctrl + glisser, ou le bouton du milieu s\'il glisse) fait défiler votre vue, sans rien changer pour les joueurs.'],
      ] },
      { titre: 'La barre d\'outils', points: [
        ['Organisation', 'La ligne du haut, par groupes : Annuler, Tout éclaircir, Tout assombrir ; l\'aimant ; quoi dessiner (Assombrir, Éclaircir) et comment (Pinceau, Rectangle, Rond, Polygone) ; Jeton et Terrain ; Distance et Zone d\'effet ; à droite, l\'échelle et la rotation. À gauche de la projection : la grille, la vue (toute la carte ou la zone projetée), le calibrage, puis la main et le ping. Un bouton qui a des types (Jeton, Terrain, Zone d\'effet), le Pinceau (carré ou rond, taille en cases) et le calibrage (sur N cases) ouvrent une petite barre flottante sous eux ; le bouton prend l\'icône du type choisi.'],
        ['Éclaircir, assombrir', 'Éclaircir révèle aux joueurs, Assombrir recache, avec la forme choisie : pinceau (glisser ; carré ou rond, taille en cases : une case d\'office), rectangle (glisser d\'un coin à l\'autre), rond (glisser depuis le centre), polygone (clics pour les sommets, clic droit retire le dernier, double-clic ou Entrée ferme). Noir opaque pour les joueurs, translucide pour vous. Pinceau, rectangle et rond se voient en direct dans votre projection, l\'aperçu du pinceau sous le pointeur ; les joueurs reçoivent la zone au relâchement. Le bord du brouillard est flouté sur un quinzième de case (réglable dans l\'onglet Plugins) ; recacher une zone révélée la rend comme avant.'],
        ['Tout, annuler', '« Tout éclaircir » (carré vide) et « Tout assombrir » (carré plein) repartent de zéro ; « Annuler » (ou Ctrl+Z) retire la dernière zone éclaircie ou assombrie. Le brouillard est gardé par carte, d\'une séance à l\'autre.'],
        ['Magnétisme', 'L\'aimant (carte calibrée) : rectangles, ronds, polygones et mesures s\'alignent sur les lignes de la grille (le rond par cases entières de rayon), le pinceau et les jetons vont case par case.'],
        ['Ping', 'Un clic du bouton du milieu (la molette) sur la carte, avec n\'importe quel outil, ou l\'outil ondes puis un clic : trois ondes violettes à cet endroit, sur votre projection et sur l\'écran des joueurs.'],
      ] },
      { titre: 'Terrains, jetons, mesures', points: [
        ['Terrains', 'Le bouton Terrain ouvre ses types : terrain difficile (jaune), zone enflammée (orange), glacée (bleue), végétation et ronces (verte), arcanique (violette), d\'ombre (grise) ; la zone se dessine comme le brouillard (pinceau, rectangle, rond, polygone), hachurée dans sa couleur avec son symbole, vue des joueurs aussi. Clic droit sur une zone : elle disparaît.'],
        ['Jetons', 'Le bouton Jeton ouvre ses types : porte dissimulée, piège (pics, fosse, feu, flèches, gaz, lame, poison), coffre ou trésor, point d\'intérêt, corps, lumière, passage ou escalier. Un clic sur la carte le pose (sur la case, avec l\'aimant) ; la main le déplace ; clic droit le retire.'],
        ['Distance', 'Glisser d\'un point à l\'autre : la distance en pieds, mètres et cases (5 ft et 1,5 m par case), gardée sur les deux écrans jusqu\'à un clic droit dessus (ou, l\'outil en cours, sur la dernière).'],
        ['Zones d\'effet', 'Les zones des règles 2024 : cône (aussi large que long), cube (depuis un coin), cylindre et sphère (rayon), émanation (depuis l\'espace de la créature), ligne (5 ft de large). Glisser depuis l\'origine ; sur une carte calibrée, la taille se mesure en cases entières. Visibles des joueurs, retirées d\'un clic droit.'],
      ] },
      { titre: 'Sans carte', points: [
        ['Tableau des joueurs', 'Ce que montre l\'écran tant qu\'aucune carte n\'y est diffusée. Le fond du lieu (sinon un dégradé de la charte), le titre de la campagne ; en haut à gauche la météo du moment, en haut à droite le moment de la journée (aube, matin, après-midi, crépuscule, nuit) et, la nuit, la lune à sa phase, voilée ou cachée selon le ciel. Les héros tels que les joueurs les voient, cadrés pareil : portrait, prénom, espèce, classe, sous-classe et origine l\'une sous l\'autre, santé en mots (En forme, Ensanglanté, Critique, À terre, Mort), états et encombrement en icônes, équipement porté (armure, armes, sac à dos équipé), le compagnon sous son maître ; en bas, l\'inventaire commun de D&D Beyond. Jamais un chiffre de PV, un niveau, l\'inspiration ni un objet non équipé. Suit le relevé toutes les 5 secondes et l\'Horloge.'],
        ['Rotations', 'Une seule rotation dans le bandeau, pour ce qui est à l\'écran : le tableau des joueurs (en portrait, pour une lecture depuis un petit côté de la table) ou l\'image diffusée. Le fond du tableau se tourne à part, par le menu « … » du bandeau ; une carte, par ses propres outils. Une image plus haute que large (un portrait, une affiche) arrive en portrait, puis se tourne comme les autres. La rotation par défaut du tableau et des cartes se règle dans l\'onglet Plugins.'],
        ['Fond du tableau', 'Dans la fenêtre d\'une image (widget Images, Ici, fiche d\'un PNJ), bouton « Écran des joueurs » : « Fond pour <lieu> » (l\'écran le prend quand les héros y sont, sous-lieux compris) ou « Fond par défaut » (l\'image de la campagne). Le fond en cours est nommé dans le widget, avec sa croix.'],
        ['Une image', 'D\'où qu\'elle vienne, l\'icône de diffusion dans le coin haut droit de l\'image, au survol (façon Chromecast, quand le plugin est actif) : portrait sur la fiche d\'un héros ou d\'un compagnon, illustration d\'un monstre, fenêtre d\'une image (Images, Ici, galerie d\'un PNJ : son menu « Écran des joueurs » propose aussi « Montrer maintenant », « Préparer comme carte », un fond), image en grand. L\'image passe par-dessus ce qu\'il y a à l\'écran, seule, sans nom dessous, sans toucher à l\'atelier ; le bandeau la tourne, et « Retirer » rend ce qu\'il y avait.'],
      ] },
    ],
  },
];
