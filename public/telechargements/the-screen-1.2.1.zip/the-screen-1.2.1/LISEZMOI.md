# « The Screen » Campaign Toolbox

*Gestionnaire de campagne pour D&D 5e.*

L'outil du MJ pour mener une campagne de D&D 5e (règles 2024) avec D&D Beyond : la trame, les lieux et les PNJ, le temps qui passe, les rencontres et les combats, les héros à jour depuis leurs fiches, la musique, les images. Il tourne sur votre PC, dans Chrome, et ne montre rien aux joueurs. Par Nizzren.

L'aide complète, outil par outil, est dans le gestionnaire : le lien **À propos**, en haut à droite.

## Ce qu'il vous faut

- Windows (rien à installer : le gestionnaire tourne avec PowerShell, déjà présent) et Chrome.
- Un compte D&D Beyond, avec la campagne de vos joueurs (pour le relevé des fiches des héros, les monstres et les objets).
- Un agent IA de campagne, pour écrire les données de la campagne à partir de vos livres et de vos notes : un projet Claude, ou une autre IA qui lit des fichiers.

## Démarrer

1. Décompressez le dossier où vous voulez (pas dans un dossier synchronisé qui verrouille les fichiers, si possible).
2. Double-cliquez **`Lancer le gestionnaire.cmd`** : une fenêtre noire s'ouvre (gardez-la ouverte pendant la partie), puis Chrome sur http://localhost:8735/.
3. Pour essayer : la campagne témoin, *Les Bannières d'Aurval*, inventée, avec quelques données.
4. Pour votre campagne : à l'accueil (la première page au premier lancement, ensuite les flèches croisées en haut à droite), **Nouvelle campagne** (titre, identifiant, charte, calendrier, météo, musique). Le gestionnaire crée son dossier, `campagnes/<identifiant>/`, et vous dit quoi faire ensuite.

## Les données, avec votre agent IA

Le gestionnaire lit les données de la campagne dans `campagnes/<identifiant>/data/` : lieux, PNJ, factions, déroulé, rencontres, objets… Votre agent les écrit pour vous.

1. Donnez-lui **`AGENTS.md`** (ses règles de travail), **`formats/README.md`** et le guide **`campagnes/<identifiant>/data/LISEZMOI.md`**, puis vos livres et vos notes.
2. Demandez-lui un fichier à la fois, au format de sa fiche (`formats/<fichier>.md`) : d'abord `lieux.json`, `pnj.json` et `deroule-campagne.json`, le minimum pour jouer.
3. Rangez chaque fichier dans `data/`, rechargez la page, et vérifiez-le avec le bouton **Données** de l'en-tête : il dit précisément ce qui manque ou ne va pas. Donnez cette liste à l'agent pour qu'il corrige.
4. Un outil grisé dans **Outil** (en haut à droite) dit quel fichier il lui faut. Le tableau de départ ne montre que les outils dont la campagne a les données : une fois vos fichiers rangés, le bouton **Disposition recommandée**, en bas de cette fenêtre, pose les autres à leur place (mode par mode).

La campagne témoin (`campagnes/temoin/data/`) montre des fichiers complets et valides : un bon exemple pour l'agent.

## Après chaque séance

Le bouton **Session** donne un prompt : tout ce que le gestionnaire a noté pendant la séance (où sont les héros, l'heure, les étapes, les combats, les PNJ rencontrés, les objets donnés…). Donnez-le à votre agent avec vos notes ; sa réponse se termine par un bloc `maj-etat`, que vous collez dans l'onglet « Après l'analyse » : chaque changement vous est montré avant d'être appliqué.

Le gestionnaire fait foi pour l'avancée de la campagne : il l'écrit dans `campagnes/<identifiant>/etat/`, que votre agent peut lire pour savoir où vous en êtes, mais n'écrit jamais.

## D&D Beyond : l'extension du MJ

Pour relever les fiches des héros (PV, CA, sorts, inventaire, états…) et écrire sur elles depuis le gestionnaire :

1. Chrome, `chrome://extensions`, « Mode développeur », « Charger l'extension non empaquetée », le dossier `extensions/mj`.
2. Épinglez-la ; dans sa fenêtre, l'adresse du gestionnaire : `http://localhost:8735/<identifiant>` (votre campagne).
3. Dans le gestionnaire, bouton **Campagne** : l'adresse de votre campagne D&D Beyond.

Restez connecté à D&D Beyond dans Chrome : l'extension lit les fiches avec votre session. Un joueur dont le héros a un familier ou un compagnon peut installer `extensions/compagnon`.

## Le dossier `outils/`

Des scripts à double-cliquer : importer les images, la musique, la vraie météo d'une ville, le wiki de la campagne, les icônes des états de D&D Beyond, et installer l'assistant de règles (facultatif). L'aide (À propos) les décrit.

## Mettre à jour

Ne décompressez **pas** une nouvelle version ni un patch par-dessus votre gestionnaire : l'un comme l'autre se décompresse à part.

**Avec un patch** (un petit zip `the-screen-patch-<version>-vers-<version>.zip`, qui ne s'applique qu'à la version dont il part) : fermez le gestionnaire, décompressez le patch, double-cliquez **`Appliquer le patch.cmd`** et choisissez le dossier de votre gestionnaire actuel. Rien d'autre que les fichiers du patch ne change, et ce qu'il remplace est gardé dans `anciennes-versions/`.

**Avec une version complète**, quelle que soit la vôtre :

1. Fermez le gestionnaire (sa fenêtre noire).
2. Décompressez le zip de la nouvelle version dans un autre dossier, par exemple dans Téléchargements.
3. Dans ce dossier décompressé, double-cliquez **`outils/Mettre à jour.cmd`**, puis choisissez le dossier de votre gestionnaire actuel (celui qui contient `Lancer le gestionnaire.cmd` et `campagnes/`).
4. Le script remplace les fichiers du gestionnaire et retire ceux que la nouvelle version n'a plus. Il ne touche jamais à `campagnes/` (vos campagnes, leurs données, leur état, leurs images ; seuls les fichiers d'exemple de la campagne témoin sont rafraîchis), à `poste.json`, à `sources/`, aux icônes d'états importées ni à l'assistant de règles installé. L'ancienne version est gardée dans `anciennes-versions/` de votre gestionnaire.
5. Si le script le demande, rechargez l'extension du MJ dans Chrome (`chrome://extensions`, flèche ronde « Recharger »).
6. Relancez le gestionnaire : la nouvelle version s'affiche en haut à droite. Le dossier décompressé peut être supprimé.

Ne modifiez pas le gestionnaire lui-même (`app/`, `formats/`, `scripts/`…) : une copie modifiée ne pourrait plus recevoir les mises à jour sans perdre ses modifications, et le gestionnaire le signale (« Gestionnaire modifié »). Un besoin nouveau se demande à son auteur.
