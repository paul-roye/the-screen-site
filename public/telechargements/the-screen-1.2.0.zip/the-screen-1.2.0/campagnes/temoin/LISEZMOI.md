# Campagne témoin : Les Bannières d'Aurval

Une campagne **inventée**, minuscule, pour essayer le gestionnaire, et un exemple de données pour l'agent IA de campagne : charte « médiéval glorieux », calendrier Classique, aucun module. Le mainteneur s'en sert aussi pour vérifier qu'aucun outil ne suppose une campagne particulière. Ouverte sous http://localhost:8735/temoin/.

- `manifeste.json` : le manifeste de la campagne (`formats/campagne.md`).
- `data/` : quelques fichiers au format de `formats/` (lieux, PNJ, factions, déroulé, distances), écrits à la main. Ils servent d'essai : à garder valides (bouton Données sans alerte) quand un format change.
- `etat/` : écrit par le gestionnaire pendant les essais, hors dépôt (`.gitignore`).
