// Fenêtre de l'extension (clic sur l'icône) : état du dernier relevé, relevé immédiat, pause, réglages.

const REGLAGES = { gestionnaire: 'http://localhost:8735', actif: true, fiche: '' };
const $ = id => document.getElementById(id);

async function lire() {
  const { reglages, dernier } = await chrome.storage.local.get(['reglages', 'dernier']);
  return { reglages: { ...REGLAGES, ...reglages }, dernier: dernier || null };
}

function depuis(quand) {
  const s = Math.max(0, Math.round((Date.now() - quand) / 1000));
  return s < 60 ? `${s} s` : s < 3600 ? `${Math.floor(s / 60)} min` : `${Math.floor(s / 3600)} h`;
}

// La charte du gestionnaire, servie par lui-même.
function charte(base) {
  for (const f of ['design-system/tokens.css', 'design-system/barovie.css', 'app/app.css']) {
    const l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = `${base.replace(/\/+$/, '')}/${f}`;
    document.head.append(l);
  }
}

function alerte(couleur, titre, texte) {
  const div = document.createElement('div');
  div.className = `bn-alerte bn-alerte--${couleur}`;
  const t = document.createElement('p'); t.className = 'bn-alerte__titre'; t.textContent = titre;
  const x = document.createElement('div'); x.className = 'bn-alerte__texte'; x.textContent = texte || '';
  div.append(t, x);
  return div;
}

async function afficher() {
  const { reglages, dernier } = await lire();
  $('pause').textContent = reglages.actif ? 'Mettre en pause' : 'Reprendre';
  const { detailsReleves, detailsDemandes } = await chrome.storage.local.get(['detailsReleves', 'detailsDemandes']);
  if (!$('details').disabled) {
    $('details-date').textContent = detailsDemandes ? 'Demandés : au prochain relevé (30 s au plus).'
      : detailsReleves ? `Derniers détails il y a ${depuis(detailsReleves)}.` : '';
  }
  const ok = ['ok', 'partiel'].includes(dernier?.statut);
  $('statut').replaceChildren(
    !reglages.actif ? alerte('cierge', 'En pause', 'Aucun relevé tant que vous ne reprenez pas.')
      : ok ? alerte('brume', `Relevé il y a ${depuis(dernier.quand)}`, dernier.message || `${dernier.fiches.length} fiches à jour dans le gestionnaire.`)
        : dernier ? alerte('sang', dernier.quand ? `Dernier relevé il y a ${depuis(dernier.quand)}` : 'Aucun relevé', dernier.message)
          : alerte('cierge', 'Premier relevé en cours…', ''));
  $('fiches').replaceChildren(...(dernier?.fiches || []).map(f => {
    const li = document.createElement('li');
    const b = document.createElement('b'); b.textContent = f.nom;
    li.append(b, ` · PV ${f.pv}`);
    return li;
  }));
}

const { reglages } = await lire();
charte(reglages.gestionnaire);
$('gestionnaire').value = reglages.gestionnaire;
$('fiche').value = reglages.fiche;

async function regler(changement) {
  const { reglages: r } = await lire();
  await chrome.storage.local.set({ reglages: { ...r, ...changement } });
  await chrome.runtime.sendMessage({ type: 'badge' });
  afficher();
}

$('relever').addEventListener('click', async () => {
  $('relever').disabled = true;
  await chrome.runtime.sendMessage({ type: 'relever' });
  $('relever').disabled = false;
  afficher();
});
$('details').addEventListener('click', async () => {
  $('details').disabled = true;
  $('details-date').textContent = 'Relevé en cours…';
  try {
    const ok = await chrome.runtime.sendMessage({ type: 'details' });
    if (!ok) throw new Error('pas de réponse');
    $('details').disabled = false;
    afficher();
  } catch {
    // Tâche de fond d'une version antérieure : elle ne connaît pas ce message.
    $('details').disabled = false;
    $('details-date').textContent = 'L\'extension doit être rechargée : chrome://extensions, bouton « Recharger ».';
  }
});
$('pause').addEventListener('click', async () => {
  const { reglages: r } = await lire();
  await regler({ actif: !r.actif });
  if (!r.actif) chrome.runtime.sendMessage({ type: 'relever' });
});
$('gestionnaire').addEventListener('change', e => regler({ gestionnaire: e.target.value.trim() || REGLAGES.gestionnaire }));
$('fiche').addEventListener('change', e => regler({ fiche: e.target.value.trim() }));

afficher();
setInterval(afficher, 1000);
