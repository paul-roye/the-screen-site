// Fenêtre de l'extension « Fiche du compagnon » : la fiche du compagnon (familier…) d'un personnage D&D Beyond, au format
// d'un monstre, avec les états que le MJ a posés (ligne « [États (MJ) : …] » de la note du compagnon, voir LISEZMOI.md).
// Tout se lit sur D&D Beyond, avec la session du navigateur du joueur : la fiche du personnage (character-service), le
// dictionnaire public (api/config/json). Relue toutes les 15 s, et d'un clic. Les jets de la fiche roulent en 3D. Le joueur
// change les PV du compagnon (dégâts, soins, PV temporaires), écrits sur sa fiche ; un compagnon de Flee, Mortals! a sa
// férocité (gardée dans l'extension) et son rampage, tous deux notés dans sa note pour le MJ.

import { h, icone, bouton, flottant, infobulle, activerInfobulles, deNom, pastilleDD, ouvrirMenu } from './js/ui.js';
import { blocStats, signe, modificateur } from './js/monstres.js';
import { reglagesDes, montrerJets, lancerVisible, formuleD20, AVANTAGES } from './js/lancers.js';
import { lancer as jeter } from './js/des.js';
import { etatsDeLaNote, nomEtat, effetsEtat, coutEpuisement, iconeEtat, chargerIconesEtats } from './js/etats.js';
import { contenuReglesCompagnons } from './js/regles-compagnons.js';

const PERSONNAGES = 'https://character-service.dndbeyond.com/character/v5/character/';
// PV d'une créature, comme la fiche : CREATURE_HIT_POINTS_SET du code de la fiche (character-app 1.72.9, relevé le
// 2026-10-20 ; pas encore essayé sur une vraie fiche).
const PV_CREATURE = 'https://character-service.dndbeyond.com/character/v5/creature/hp';
const RELIRE_MS = 15000;
const CONFIG_MS = 24 * 3600 * 1000;   // le dictionnaire de D&D Beyond, gardé un jour
// Valeurs personnalisées d'une créature (« Customize » de l'onglet Extras) : characterValues de la fiche, typeId…
const VALEUR = { ca: 42, pvMax: 43, note: 47 };
const GROUPES = { 1: 'Compagnon', 2: 'Familier', 3: 'Forme sauvage', 4: 'Monture' };

const page = document.getElementById('page');
let reglages = { fiche: '', creature: null, son: true };
let dernier = null;   // { fiche brute, quand }
let enLecture = false, echec = null;   // echec : la dernière lecture a échoué (son message)
let edition = false, ecriture = false, message = null;   // PV : la case ouverte, une écriture en cours, le message d'un échec

// ───── D&D Beyond ─────

let jeton = null;   // { valeur, jusqua }
async function jetonBeyond() {
  if (jeton && Date.now() < jeton.jusqua) return jeton.valeur;
  const r = await fetch('https://auth-service.dndbeyond.com/v1/cobalt-token', { method: 'POST', credentials: 'include' }).catch(() => null);
  const j = r?.ok ? await r.json() : null;
  jeton = j?.token ? { valeur: j.token, jusqua: Date.now() + Math.max(0, (j.ttl || 300) - 60) * 1000 } : null;
  if (!jeton) throw new Error('Pas de session D&D Beyond : connectez-vous sur dndbeyond.com dans ce navigateur, puis relisez.');
  return jeton.valeur;
}

async function lireFiche(id) {
  const r = await fetch(PERSONNAGES + id, { headers: { Authorization: 'Bearer ' + await jetonBeyond() } });
  if (r.status === 401) { jeton = null; throw new Error('Session D&D Beyond expirée : relisez.'); }
  if (r.status === 403 || r.status === 404) throw new Error('Fiche introuvable, ou pas à vous : vérifiez le lien de votre personnage.');
  if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status}.`);
  const d = (await r.json())?.data;
  if (!d?.id) throw new Error('Fiche D&D Beyond illisible.');
  return d;
}

// Dictionnaire public (tailles, types, sens… pour le bloc de stats), comme le relevé de l'extension du MJ.
async function lireConfig() {
  const { config } = await chrome.storage.local.get('config');
  if (config && Date.now() - config.quand < CONFIG_MS) return config.valeur;
  const r = await fetch('https://www.dndbeyond.com/api/config/json');
  if (!r.ok) return config?.valeur || null;
  const j = await r.json();
  const liste = (l, f) => (l || []).map(f);
  const valeur = {
    tailles: liste(j.creatureSizes, x => ({ id: x.id, nom: x.name })),
    types: liste(j.monsterTypes, x => ({ id: x.id, nom: x.name })),
    alignements: liste(j.alignments, x => ({ id: x.id, nom: x.name })),
    mouvements: liste(j.movements, x => ({ id: x.id, nom: x.name })),
    sens: liste(j.senses, x => ({ id: x.id, nom: x.name })),
    carac: liste(j.stats, x => ({ id: x.id, cle: x.key })),
    etats: liste(j.conditions, x => ({ id: x.definition?.id, nom: x.definition?.name })),
    ajustements: liste(j.damageAdjustments, x => ({ id: x.id, nom: x.name, type: x.type })),
    puissances: liste(j.challengeRatings, x => ({ id: x.id, valeur: x.value, px: x.xp, maitrise: x.proficiencyBonus })),
  };
  await chrome.storage.local.set({ config: { quand: Date.now(), valeur } });
  return valeur;
}

// Valeur personnalisée d'une créature (valueId : son id) : nombre (CA, PV max) ou texte (note).
function valeurDe(d, cr, typeId) {
  const v = (d.characterValues || []).find(x => x.typeId === typeId && String(x.valueId) === String(cr.id)
    && (x.valueTypeId == null || cr.entityTypeId == null || String(x.valueTypeId) === String(cr.entityTypeId)));
  return v?.value ?? null;
}

// La créature à montrer : celle choisie, sinon le familier, sinon la première.
const creatureDe = d => {
  const l = d.creatures || [];
  return l.find(c => String(c.id) === String(reglages.creature)) || l.find(c => c.groupId === 2) || l[0] || null;
};
// PV max : le « Max HP » personnalisé, sinon celui du profil.
const pvMaxDe = (d, cr) => Number(valeurDe(d, cr, VALEUR.pvMax)) || cr.definition?.averageHitPoints || 0;

// PV changés par le joueur, comme la case des PV d'un monstre dans le widget Combat du MJ : les dégâts entament d'abord
// les PV temporaires ; les soins ne dépassent pas le maximum ; des PV temporaires remplacent les précédents. Affichés
// aussitôt, écrits sur la fiche, puis relus ; en cas d'échec, l'ancienne valeur revient, avec un message.
async function changerPv(quoi, n) {
  if (!(n > 0) || !dernier || ecriture) return;
  const d = dernier.fiche, cr = creatureDe(d);
  if (!cr) return;
  const avant = { removedHitPoints: cr.removedHitPoints || 0, temporaryHitPoints: cr.temporaryHitPoints || 0 };
  let perdus = avant.removedHitPoints, temp = avant.temporaryHitPoints;
  if (quoi === 'degats') { const t = Math.min(temp, n); temp -= t; perdus = Math.min(pvMaxDe(d, cr), perdus + n - t); }
  else if (quoi === 'soins') perdus = Math.max(0, perdus - n);
  else temp = n;
  Object.assign(cr, { removedHitPoints: perdus, temporaryHitPoints: temp });
  edition = false; message = null; ecriture = true;
  afficher();
  try {
    const envoyer = async () => fetch(PV_CREATURE, { method: 'PUT',
      headers: { Authorization: 'Bearer ' + await jetonBeyond(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ characterId: d.id, id: cr.id, removedHitPoints: perdus, temporaryHitPoints: temp }) });
    let r = await envoyer();
    if (r.status === 401) { jeton = null; r = await envoyer(); }   // jeton expiré
    if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status}.`);
    const j = await r.json().catch(() => null);
    if (j && j.success === false) throw new Error(j.message || 'D&D Beyond a refusé le changement.');
  } catch (e) {
    Object.assign(cr, avant);
    message = `PV pas écrits sur la fiche D&D Beyond : ${e.message}`;
  }
  ecriture = false;
  afficher();
  if (!message) relire();
}

// La férocité et le rampage dans la note du compagnon (« Customize », Notes), pour le MJ : la ligne
// « [Férocité (joueur) : 7] » dès que la fenêtre suit le compagnon, et « [Rampage (joueur)] » tant que le rampage dure
// (contrat : formats/note-compagnon.md du gestionnaire). La note est relue juste avant d'écrire et seules ces lignes
// changent (celle des états du MJ et le texte du joueur restent) ; vide, la note est retirée. Écritures l'une après
// l'autre, la dernière demande l'emporte ; un refus : un message, la férocité reste dans la fenêtre.
const NOTE_CREATURE = 'https://character-service.dndbeyond.com/character/v5/custom/value';
const LIGNE_RAMPAGE = /[ \t]*\[\s*Rampage\s*\(\s*joueur\s*\)\s*\][ \t]*(?:\r?\n)?/giu;
const LIGNE_FERO = /[ \t]*\[\s*F[ée]rocit[ée]\s*\(\s*joueur\s*\)\s*:\s*\d*\s*\][ \t]*(?:\r?\n)?/giu;
const RAMPAGE_PAS_NOTE = 'Férocité pas notée sur la fiche D&D Beyond (le MJ ne la voit pas)';
let rampageVoulu = null, rampageEnCours = false;   // rampageEnCours : une écriture de la note en cours
async function ecrireRampage({ fiche, creature, enRampage, valeur }) {
  const d = await lireFiche(fiche);
  const cr = (d.creatures || []).find(c => String(c.id) === String(creature));
  if (!cr) throw new Error('compagnon introuvable sur la fiche.');
  const avant = String(valeurDe(d, cr, VALEUR.note) || '');
  const note = [avant.replace(LIGNE_RAMPAGE, '').replace(LIGNE_FERO, '').replace(/\n{3,}/g, '\n\n').trim(),
    `[Férocité (joueur) : ${valeur}]`, enRampage ? '[Rampage (joueur)]' : ''].filter(Boolean).join('\n');
  if (note === avant.trim()) return;
  const cle = { characterId: d.id, typeId: VALEUR.note, valueId: String(cr.id), valueTypeId: String(cr.entityTypeId), contextId: null, contextTypeId: null, partyId: null };
  const envoyer = async () => fetch(NOTE_CREATURE, { method: note ? 'PUT' : 'DELETE',
    headers: { Authorization: 'Bearer ' + await jetonBeyond(), 'Content-Type': 'application/json' },
    body: JSON.stringify(note ? { ...cle, value: note, notes: null } : cle) });
  let r = await envoyer();
  if (r.status === 401) { jeton = null; r = await envoyer(); }   // jeton expiré
  if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status}.`);
  const j = await r.json().catch(() => null);
  if (j && j.success === false) throw new Error(j.message || 'D&D Beyond a refusé le changement.');
}
// La férocité et le rampage du compagnon tels que la fenêtre les tient (feroDe), écrits dans sa note.
async function noterRampage(cr) {
  clearTimeout(attenteNote);
  attenteNote = null;
  const x = feroDe(cr);
  rampageVoulu = { fiche: dernier?.fiche?.id || reglages.fiche, creature: cr.id, enRampage: !!x.rampage, valeur: x.valeur };
  if (rampageEnCours) return;
  rampageEnCours = true;
  afficher();
  let refuse = false;
  while (rampageVoulu) {
    const voulu = rampageVoulu;
    rampageVoulu = null;
    try { await ecrireRampage(voulu); refuse = false; if (message?.startsWith(RAMPAGE_PAS_NOTE)) message = null; }
    catch (e) { refuse = true; message = `${RAMPAGE_PAS_NOTE} : ${e.message}`; }
  }
  rampageEnCours = false;
  afficher();
  if (!refuse) relire();   // refusé : nouvel essai à la prochaine lecture (accorderRampage), pas aussitôt
}
// Une férocité qui change seule (+1, 1d4, un pouvoir) part un instant après le dernier changement : plusieurs clics, une
// écriture. Le rampage part aussitôt.
let attenteNote = null;
const noterBientot = cr => { clearTimeout(attenteNote); attenteNote = setTimeout(() => noterRampage(cr), 1500); };
// À chaque lecture de la fiche, démarrage compris : la note doit dire ce que dit la fenêtre (un rampage commencé avant
// que l'extension n'écrive la note, une version qui ne notait pas la férocité, ou une ligne perdue dans deux écritures
// croisées, est rattrapé). Un compagnon jamais suivi dans ce Chrome prend l'état de la note, sans rien écrire.
const A_LA_LIGNE_RAMPAGE = /\[\s*Rampage\s*\(\s*joueur\s*\)\s*\]/iu;
const A_LA_LIGNE_FERO = /\[\s*F[ée]rocit[ée]\s*\(\s*joueur\s*\)\s*:\s*(\d+)\s*\]/iu;
function accorderRampage(d) {
  const cr = creatureDe(d);
  if (!cr || rampageEnCours || attenteNote) return;
  const note = String(valeurDe(d, cr, VALEUR.note) || '');
  const dansLaNote = A_LA_LIGNE_RAMPAGE.test(note);
  const fero = note.match(A_LA_LIGNE_FERO);
  const x = ferocites[cr.id];
  if (!x) {
    if (dansLaNote || fero) {
      ferocites[cr.id] = { ...FERO_VIERGE, rampage: dansLaNote, valeur: fero ? Number(fero[1]) : 0 };
      chrome.storage.local.set({ ferocites });
      afficher();
    }
    return;
  }
  if (!!x.rampage !== dansLaNote || !fero || Number(fero[1]) !== x.valeur) noterRampage(cr);
}

// ───── Rendu ─────

const idDeFiche = t => /(?:characters\/)?(\d{4,})/.exec(String(t || '').trim())?.[1] || '';
// Temps depuis la dernière lecture : « à l'instant », « il y a 12 s », « il y a 3 min ».
function ilYA(quand) {
  const s = Math.max(0, Math.round((Date.now() - quand) / 1000));
  return s < 2 ? 'à l\'instant' : s < 60 ? `il y a ${s} s` : `il y a ${Math.floor(s / 60)} min`;
}
function majAge() {
  const el = page.querySelector('.fc-age');
  if (!el || !dernier) return;
  el.textContent = echec ? 'lecture impossible' : ilYA(dernier.quand);
  el.classList.toggle('est-en-echec', !!echec);
  el.dataset.bulle = echec || 'Relue sur D&D Beyond toutes les 15 s.';
}

function barrePV(nom, actuels, max, temporaires) {
  const part = max ? actuels / max : 0;
  const etat = actuels <= 0 ? 'mort' : part < 0.2 ? 'critique' : part <= 0.5 ? 'ensanglante' : null;
  const mot = { mort: 'Inconscient', critique: 'Critique', ensanglante: 'Ensanglanté' }[etat];
  const total = Math.max(max, actuels + temporaires) || 1;
  return h('div', { class: 'bn-pv', 'data-etat': etat, style: `--pv: ${(actuels / total) * 100}%; --pv-temp: ${(temporaires / total) * 100}%` },
    h('div', { class: 'bn-pv__tete' },
      h('span', { class: 'etiquette' }, 'PV', mot ? h('span', { class: 'bn-pv__etat' }, ' · ' + mot) : null),
      h('span', { class: 'bn-pv__val' }, h('b', {}, actuels), '/' + max, temporaires ? h('span', { class: 'bn-pv__temp' }, ' +' + temporaires) : null)),
    h('div', { class: 'bn-pv__barre', role: 'meter', 'aria-label': `Points de vie de ${nom}`, 'aria-valuemin': '0', 'aria-valuemax': String(max), 'aria-valuenow': String(actuels) },
      h('span', { class: 'bn-pv__plein' }), temporaires ? h('span', { class: 'bn-pv__tampon' }) : null));
}

// Un état posé par le MJ, comme dans le gestionnaire : un badge (sa tuile, son nom) ; un clic, sa fenêtre (ce qu'il coûte,
// ses effets du DRS 5.2.1). Lecture seule : seul le MJ les change.
function badgeEtat(e, nom) {
  return h('button', { type: 'button', class: 'bn-badge bn-badge--cierge cm-etat-badge', onclick: ev => ouvrirEtat(e, nom, ev.currentTarget) },
    iconeEtat({ ...e, niveau: null }), nomEtat(e));   // le niveau est dans le libellé
}
function ouvrirEtat(e, nom, depuis) {
  flottant('etat:' + e.id, {
    surtitre: `État · ${nom}`, titre: e.nom, largeur: 440, depuis,
    contenu: h('article', { class: 'cm-pile cm-etat-fiche' },
      h('div', { class: 'cm-etat-fiche__tete' }, iconeEtat(e, 'bn-etat--l'),
        h('div', { class: 'cm-pile' },
          h('p', { class: 'ui' }, e.niveau ? `Niveau ${e.niveau} : ${coutEpuisement(e.niveau)}.` : `${nom} a cet état.`),
          h('p', { class: 'ui-s cm-sourdine' }, 'Posé par le MJ.'))),
      effetsEtat(e),
      h('p', { class: 'ui-s cm-sourdine' }, `Glossaire des règles : DRS 5.2.1, p. ${e.page} (licence CC-BY-4.0).`)),
  });
}

// La case des PV : la barre (un clic l'ouvre), puis dégâts, soins, PV temporaires ; Entrée : dégâts, Échap : fermer.
function editeurPv() {
  const champ = h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '1', inputmode: 'numeric', 'aria-label': 'Points de vie',
    onkeydown: e => {
      if (e.key === 'Enter') changerPv('degats', Number(champ.value));
      if (e.key === 'Escape') { edition = false; afficher(); }
    } });
  setTimeout(() => champ.focus(), 0);
  return h('div', { class: 'fc-edition' }, champ,
    bouton('Dégâts', { classe: 'bn-btn--s bn-btn--primaire', icone: 'epee', onclick: () => changerPv('degats', Number(champ.value)) }),
    bouton('Soins', { classe: 'bn-btn--s', icone: 'coeur', onclick: () => changerPv('soins', Number(champ.value)) }),
    bouton('PV temp.', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-plus', onclick: () => changerPv('temp', Number(champ.value)) }),
    h('span', { class: 'ui-s cm-sourdine' }, 'Entrée : dégâts. Les dégâts entament d\'abord les PV temporaires.'));
}

function vueReglages(message = '') {
  const champ = h('input', { class: 'bn-input', type: 'text', value: reglages.fiche, placeholder: 'https://www.dndbeyond.com/characters/123456789', 'aria-label': 'Fiche D&D Beyond' });
  const valider = () => {
    const id = idDeFiche(champ.value);
    if (!id) { champ.setAttribute('aria-invalid', 'true'); return; }
    changerFiche(id);
  };
  champ.addEventListener('keydown', e => { if (e.key === 'Enter') valider(); });
  page.classList.remove('avec-defile');
  page.replaceChildren(h('section', { class: 'bn-carte cm-pile fc-reglages' },
    h('h1', { class: 'titre-m' }, 'Fiche du compagnon'),
    message ? h('p', { class: 'ui fc-erreur' }, icone('lu-triangle-alert'), message) : null,
    h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Fiche D&D Beyond (lien ou numéro)'), champ,
      h('span', { class: 'bn-champ__aide' }, 'Ouvrez votre personnage sur dndbeyond.com et cliquez sur l\'icône de l\'extension : elle le prend d\'elle-même.')),
    h('div', { class: 'bn-groupe' }, bouton('Afficher', { icone: 'lu-arrow-right', classe: 'bn-btn--primaire', onclick: valider }))));
  setTimeout(() => champ.focus(), 0);
}

// ───── Férocité (Flee, Mortals! : créatures compagnons, lien « Règles » de la fenêtre) ─────
// L'état du joueur, gardé dans l'extension (chrome.storage.local, par créature ; recopié sur D&D Beyond pour le MJ, dans
// la note du compagnon, la férocité et le rampage : noterRampage) :
// { valeur, rampage, ennemis (le dernier nombre choisi), aResoudre (attaque de rampage lancée : proposer le retour à 0) }.
// En début de tour, 1d4 + les ennemis à 5 ft ; à 10 ou plus, le rampage menace (le soigneur peut l'empêcher : Sagesse
// (Dressage), DD 5 + férocité) ; en rampage, attaque de signature, + la moitié de la férocité aux dégâts, puis retour à 0.
// Les pouvoirs de férocité de la fiche (« 1st Level: Crushing Jaws (2 Ferocity) ») : leur niveau (celui du soigneur) et
// leur coût sont lus dans leur nom ; ni pendant un rampage, ni sans assez de férocité.
// Règles résumées : js/regles-compagnons.js (bouton « i » de l'en-tête), avec le lien vers le chapitre de D&D Beyond.
const SEUIL_RAMPAGE = 10;
const POUVOIR = /^\s*(\d+)\s*(?:st|nd|rd|th)\s+level\s*:\s*(.+?)\s*\(\s*(\d+)\s+ferocity\s*\)/i;
const SIGNATURE = /^\s*signature attack\b/i;
let ferocites = {};   // id de la créature -> état
let reglageFero = false;   // la valeur en saisie
// Lire ne crée rien (un compagnon jamais suivi dans ce Chrome le reste : accorderRampage) ; changerFero crée l'état.
const FERO_VIERGE = { valeur: 0, rampage: false, ennemis: 0, aResoudre: false };
const feroDe = cr => ferocites[cr.id] || { ...FERO_VIERGE };
// Son état, pour sa couleur : à 0, de 1 à 9, à 10 ou plus (le rampage menace), en rampage.
const etatFero = x => (x.rampage ? 'est-rampage' : x.valeur >= SEUIL_RAMPAGE ? 'est-alerte' : x.valeur > 0 ? 'est-monte' : 'est-zero');
function changerFero(cr, changement) {
  const nouveau = !ferocites[cr.id];
  const x = (ferocites[cr.id] ||= { ...FERO_VIERGE }), avant = !!x.rampage, valeurAvant = x.valeur;
  Object.assign(x, changement(x) || {});
  x.valeur = Math.max(0, Math.round(Number(x.valeur) || 0));
  chrome.storage.local.set({ ferocites });
  afficher();
  // Pour le MJ, dans la note : le rampage aussitôt, la férocité un instant après le dernier changement.
  if (!!x.rampage !== avant) noterRampage(cr);
  else if (x.valeur !== valeurAvant || nouveau) noterBientot(cr);
}
// Niveau du soigneur (le personnage) : la somme de ses niveaux de classe ; son bonus de maîtrise est celui du compagnon.
const niveauDe = d => (d.classes || []).reduce((s, c) => s + (c.level || 0), 0) || 1;
const maitriseDe = niveau => 2 + Math.floor((Math.max(1, niveau) - 1) / 4);
// « DC 10 plus PB » : le DD compte le bonus de maîtrise du soigneur (le bloc de stats ne lit que le nombre).
const ddAvecPb = (texte, pb) => texte && texte.replace(/\bDC\s*(\d+)\s+plus\s+(?:your\s+)?(?:PB|Proficiency Bonus)\b/gi, (_, n) => `DC ${Number(n) + pb}`);
const DESCRIPTIONS = ['specialTraitsDescription', 'actionsDescription', 'bonusActionsDescription', 'reactionsDescription'];

// Une ligne sous les PV, la plus basse possible : − / valeur (un clic : la régler) / +, 1d4 + les ennemis à 5 ft ; à
// droite, le rampage (possible : le DD qui le retient et « Rampage » ; en cours : son bonus aux dégâts, puis « À 0 » une
// fois l'attaque de signature lancée, ou sa fin) et la fin du combat.
function ligneFerocite(cr, nom) {
  const x = feroDe(cr);
  const alerte = !x.rampage && x.valeur >= SEUIL_RAMPAGE;
  const regler = v => {   // Entrée ou sortie de la case, une fois (pas après Échap)
    if (!reglageFero) return;
    reglageFero = false;
    changerFero(cr, () => ({ valeur: Number(v) }));
  };
  const valeur = reglageFero
    ? h('input', { class: 'bn-input bn-input--nombre fc-fero__saisie', type: 'number', min: '0', value: String(x.valeur), 'aria-label': 'Férocité',
      onkeydown: e => { if (e.key === 'Enter') regler(e.target.value); if (e.key === 'Escape') { reglageFero = false; afficher(); } },
      onblur: e => regler(e.target.value) })
    : infobulle(h('button', { type: 'button', class: 'fc-fero__valeur', 'aria-label': `Férocité : ${x.valeur}`, onclick: () => { reglageFero = true; afficher(); } }, String(x.valeur)),
      'Un clic : la régler à la main.', { titre: 'Férocité' });
  if (reglageFero) setTimeout(() => { const s = page.querySelector('.fc-fero__saisie'); s?.focus(); s?.select(); }, 0);
  const ennemis = h('select', { class: 'bn-select fc-fero__ennemis', 'aria-label': 'Ennemis à 5 ft (vus ou entendus)', title: 'Ennemis à 5 ft (vus ou entendus)',
    onchange: e => changerFero(cr, () => ({ ennemis: Number(e.target.value) })) },
  Array.from({ length: 9 }, (_, n) => h('option', { value: String(n), selected: n === x.ennemis }, `+${n}`)));
  const lancer = async e => {   // la férocité monte quand les dés sont posés, pas avant
    const n = x.ennemis || 0, formule = n ? `1d4+${n}` : '1d4';
    const jet = jeter(formule);
    if (!jet) return;
    const des = await montrerJets([{ jet, formule }], { legende: `${nom} : férocité`, couleur: 'ultra', depuis: e.currentTarget });
    await des?.fin;
    changerFero(cr, y => ({ valeur: y.valeur + jet.total }));
  };
  const calme = () => changerFero(cr, () => ({ valeur: 0, rampage: false, aResoudre: false }));
  const finCombat = () => {   // fin du combat : il regagne autant de PV que sa férocité, qui revient à 0
    const n = x.valeur;
    calme();
    if (n > 0) changerPv('soins', n);
  };
  const bonus = Math.floor(x.valeur / 2);
  // Sur une seule ligne, quel que soit l'état : faute de place, les mots « Férocité » et « Rampage » s'effacent (CSS).
  // Quatre états, chacun sa couleur (cadre, icônes, boutons, sélecteur) : à 0, neutre ; jusqu'à 9, jaune ; à 10 ou plus,
  // orange (le rampage menace : son bouton en rose, l'étape suivante) ; en rampage, rose, dans une aura qui ondule.
  const etat = etatFero(x);
  return h('div', { class: 'fc-fero ' + etat },
    infobulle(h('span', { class: 'etiquette fc-fero__nom', tabindex: '0' }, icone('griffe', 'bn-icone--s'), h('span', { class: 'fc-fero__mot' }, 'Férocité')),
      'Flee, Mortals! : elle monte à chaque tour, se dépense en pouvoirs, et à 10 ou plus le rampage menace. Le détail : le bouton « i » en haut.', { titre: 'Férocité' }),
    bouton('', { icone: 'lu-minus', classe: 'bn-btn--s bn-btn--fantome', titre: 'Férocité −1', disabled: !x.valeur, onclick: () => changerFero(cr, y => ({ valeur: y.valeur - 1 })) }),
    valeur,
    bouton('', { icone: 'lu-plus', classe: 'bn-btn--s bn-btn--fantome', titre: 'Férocité +1', onclick: () => changerFero(cr, y => ({ valeur: y.valeur + 1 })) }),
    infobulle(bouton('1d4', { icone: 'd20', classe: 'bn-btn--s fc-fero__d4', onclick: lancer }),
      'Début de son tour (s\'il n\'est pas neutralisé) : 1d4 + les ennemis qu\'il voit ou entend à 5 ft (à droite).', { titre: 'Férocité' }),
    ennemis,
    h('span', { class: 'fc-fero__droite' },
      x.rampage ? [
        infobulle(h('span', { class: 'bn-badge bn-badge--sang fc-fero__rampage' + (rampageEnCours ? ' est-en-cours' : ''), tabindex: '0' }, icone('lu-swords'), h('span', { class: 'fc-fero__mot' }, 'Rampage'), `+${bonus}`),
          `Attaque de signature, +${bonus} dégâts si elle touche (à ajouter au jet). Noté sur la fiche D&D Beyond, pour le MJ, comme la férocité.`, { titre: 'Rampage', ton: 'sang' }),
        x.aResoudre
          ? bouton('À 0', { icone: 'lu-check', classe: 'bn-btn--s bn-btn--primaire', titre: 'L\'attaque du rampage est faite : il redevient calme, férocité à 0', onclick: calme })
          : bouton('', { icone: 'lu-x', classe: 'bn-btn--s', titre: 'Fin du rampage : férocité à 0', onclick: calme }),
      ] : alerte ? [
        infobulle(pastilleDD(5 + x.valeur), `Rampage possible (10 ou plus) : le soigneur peut l'en empêcher, Sagesse (Dressage) DD ${5 + x.valeur}.`, { titre: 'Rampage possible', ton: 'sang' }),
        bouton('Rampage', { icone: 'lu-swords', classe: 'bn-btn--s bn-btn--primaire fc-fero__vers-rampage', titre: 'Il entre en rampage (noté sur la fiche D&D Beyond, pour le MJ)', onclick: () => changerFero(cr, () => ({ rampage: true, aResoudre: false })) }),
      ] : null,
      infobulle(bouton('', { icone: 'lu-flag', classe: 'bn-btn--s bn-btn--fantome', 'aria-label': 'Fin du combat', disabled: !x.valeur && !x.rampage, onclick: finCombat }),
        'Fin du combat : il regagne autant de PV que sa férocité, qui revient à 0.', { titre: 'Fin du combat' })));
}

// La fiche, une fois rendue : chaque pouvoir de férocité reçoit, au début de sa ligne, un bouton griffe et son coût (grisé s'il n'est pas
// accessible au niveau du soigneur, indisponible sans assez de férocité ou pendant un rampage) ; ses propres jets dépensent
// la férocité (ou sont bloqués). L'attaque de signature lancée pendant un rampage propose le retour à 0.
function decorerFerocite(fiche, cr, niveau) {
  const x = feroDe(cr);
  const paragraphes = [...fiche.querySelectorAll('p.bn-stat__trait')];
  const nomDe = p => p.querySelector('strong, b')?.textContent || '';
  const signature = paragraphes.find(p => SIGNATURE.test(nomDe(p)));
  signature?.classList.add('fc-signature');
  const lancerSignature = () => page.querySelector('.fc-signature .cm-stat__attaque')?.click();
  signature?.addEventListener('click', ev => {
    if (x.rampage && ev.target.closest('.bn-dd--jet, .cm-stat__attaque')) setTimeout(() => changerFero(cr, () => ({ aResoudre: true })), 0);
  }, true);
  for (const p of paragraphes) {
    const m = POUVOIR.exec(nomDe(p));
    if (!m) continue;
    const niv = Number(m[1]), nomPouvoir = m[2].trim(), cout = Number(m[3]);
    const avecSignature = /\bsignature\b/i.test(p.textContent) && signature && p !== signature;
    const raison = niveau < niv ? `Niveau ${niv} requis (le soigneur est niveau ${niveau})`
      : x.rampage ? 'Pas pendant un rampage' : x.valeur < cout ? `Férocité insuffisante : ${cout} requise, ${x.valeur} acquise` : null;
    p.classList.add('fc-pouvoir');
    p.classList.toggle('est-inaccessible', niveau < niv);
    const depenser = () => changerFero(cr, y => ({ valeur: y.valeur - cout }));
    // Au début du pouvoir, sur sa ligne : un petit bouton griffe avec son coût (couleur de la férocité) ; s'il est
    // indisponible, la raison dans le texte, puis un point médian (le détail au survol du bouton).
    const court = niveau < niv ? `Niveau ${niv} requis` : x.rampage ? 'Impossible en Rampage' : x.valeur < cout ? `Férocité insuffisante (${x.valeur}/${cout})` : null;
    const utiliser = h('button', { type: 'button', class: `bn-btn bn-btn--s fc-pouvoir__utiliser ${etatFero(x)}`, disabled: !!raison,
      'aria-label': `${nomPouvoir} : dépenser ${cout} férocité`, onclick: () => { depenser(); if (avecSignature) setTimeout(lancerSignature, 0); } },
    icone('griffe', 'bn-icone--s'), String(cout));
    p.prepend(...[
      h('span', { class: 'fc-pouvoir__outil' }, infobulle(h('span', { class: 'fc-pouvoir__bouton', tabindex: raison ? '0' : null }, utiliser),
        raison ? `${raison}.` : `Dépenser ${cout} férocité${avecSignature ? ', puis l\'attaque de signature' : ''}.`, { titre: `${nomPouvoir} : ${cout} férocité` })),
      court ? h('span', { class: 'fc-pouvoir__raison' }, court) : null,
      court ? ' · ' : null,
    ].filter(Boolean));   // prepend() écrirait « null »
    // Ses propres jets (s'il en a) : la férocité se dépense au clic ; indisponible, le jet n'est pas lancé.
    p.addEventListener('click', ev => {
      const jet = ev.target.closest('.bn-dd--jet, .cm-stat__attaque');
      if (!jet || jet.closest('.fc-pouvoir__outil')) return;
      if (raison) { ev.stopPropagation(); ev.preventDefault(); message = `${nomPouvoir} : ${raison.toLowerCase()}.`; afficher(); return; }
      setTimeout(depenser, 0);
    }, true);
  }
}

// Dans le texte des capacités et actions : « PB » devient un petit encadré violet (au survol, sa valeur : « PB : +2 ») ;
// « 2 × PB » ou « PB × 2 » (× ou x), « PB × 2 » (au survol, ce qu'il vaut : « PB × 2 : +4 »). Les dés de dégâts
// (« 1d6+PB ») restent des boutons de jet ; « PBd6 » n'est pas touché.
const MOTIF_PB = /(\d+)\s*[×x]\s*PB\b|\bPB\s*[×x]\s*(\d+)\b|\bPB\b/g;
function encadrerPb(fiche, pb) {
  if (!Number.isInteger(pb)) return;
  const boite = (texte, bulle) => infobulle(h('span', { class: 'bn-badge bn-badge--ultra fc-pb', tabindex: '0' }, texte), bulle, { titre: 'Bonus de maîtrise' });
  for (const p of fiche.querySelectorAll('p.bn-stat__trait')) {
    const marcheur = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
    const noeuds = [];
    for (let n = marcheur.nextNode(); n; n = marcheur.nextNode()) {
      if (/\bPB\b/.test(n.data) && !n.parentElement.closest('button, .bn-dd, .fc-pouvoir__outil')) noeuds.push(n);
    }
    for (const n of noeuds) {
      const morceaux = [];
      let fin = 0;
      for (const m of n.data.matchAll(MOTIF_PB)) {
        const k = Number(m[1] || m[2]) || 1;
        morceaux.push(n.data.slice(fin, m.index),
          k > 1 ? boite(`PB × ${k}`, `PB × ${k} : ${signe(k * pb)}`) : boite('PB', `PB : ${signe(pb)}`));
        fin = m.index + m[0].length;
      }
      morceaux.push(n.data.slice(fin));
      n.replaceWith(...morceaux.filter(x => x !== ''));   // replaceWith() écrirait les chaînes vides : filtrées
    }
  }
}

// ───── Compétences ─────
// Les compétences de D&D Beyond (api/config/json, abilitySkills) : identifiant -> nom anglais, nom de la VF, caractéristique.
const COMPETENCES = {
  2: ['Athletics', 'Athlétisme', 1], 3: ['Acrobatics', 'Acrobaties', 2], 4: ['Sleight of Hand', 'Escamotage', 2], 5: ['Stealth', 'Discrétion', 2],
  6: ['Arcana', 'Arcanes', 4], 7: ['History', 'Histoire', 4], 8: ['Investigation', 'Investigation', 4], 9: ['Nature', 'Nature', 4],
  10: ['Religion', 'Religion', 4], 11: ['Animal Handling', 'Dressage', 5], 12: ['Insight', 'Intuition', 5], 13: ['Medicine', 'Médecine', 5],
  14: ['Perception', 'Perception', 5], 15: ['Survival', 'Survie', 5], 16: ['Deception', 'Tromperie', 6], 17: ['Intimidation', 'Intimidation', 6],
  18: ['Performance', 'Représentation', 6], 19: ['Persuasion', 'Persuasion', 6],
};
const CARACS = { Strength: [1, 'Force'], Dexterity: [2, 'Dextérité'], Constitution: [3, 'Constitution'], Intelligence: [4, 'Intelligence'], Wisdom: [5, 'Sagesse'], Charisma: [6, 'Charisme'] };
const ID_COMPETENCE = Object.fromEntries(Object.entries(COMPETENCES).map(([id, [en]]) => [en, Number(id)]));

// Un jet d'un d20 de la fiche, comme ceux du bloc de stats (violet ; clic droit : avantage ou désavantage).
function boutonJetD20(texte, bonus, legende) {
  const formule = formuleD20(bonus);
  const lancer = (ancre, avantage = null) => lancerVisible(formule, { legende: avantage ? `${legende} (${AVANTAGES[avantage].libelle})` : legende, couleur: 'ultra', depuis: ancre, avantage });
  return h('button', { type: 'button', class: 'bn-badge bn-dd bn-dd--jet', title: `${legende} : lancer ${formule} (clic droit : avec avantage ou désavantage)`,
    onclick: e => { e.stopPropagation(); lancer(e.currentTarget); },
    oncontextmenu: e => {
      e.preventDefault();
      e.stopPropagation();
      const ancre = e.currentTarget;
      ouvrirMenu(ancre, [['Avec avantage', 'Deux d20, le meilleur', () => lancer(ancre, 'avantage')],
        ['Avec désavantage', 'Deux d20, le moins bon', () => lancer(ancre, 'desavantage')]], 'Lancer avec avantage ou désavantage');
    } }, icone('d20'), texte);
}

// Bonus des compétences du compagnon : celles de sa fiche (skills : le bonus total, comme D&D Beyond l'affiche), sinon
// celles de son texte (skillsHtml, « Stealth +4, Perception +5 »). Identifiant -> bonus.
function bonusCompetences(def) {
  const bonus = new Map();
  for (const s of def.skills || []) if (COMPETENCES[s.skillId]) bonus.set(Number(s.skillId), (Number(s.value) || 0) + (Number(s.additionalBonus) || 0));
  if (!bonus.size && def.skillsHtml) {
    const texte = new DOMParser().parseFromString(def.skillsHtml, 'text/html').body.textContent || '';
    for (const m of texte.matchAll(/([A-Z][a-z]+(?: of [A-Z][a-z]+| [A-Z][a-z]+)?)\s*([+−-])\s*(\d+)/g)) {
      if (ID_COMPETENCE[m[1]]) bonus.set(ID_COMPETENCE[m[1]], (m[2] === '+' ? 1 : -1) * Number(m[3]));
    }
  }
  return bonus;
}

// La ligne « Compétences » du bloc de stats : chaque compétence en bouton de jet (de A à Z), après les jets de
// sauvegarde. Le bloc ne la montre que d'après skillsHtml, vide pour un familier : elle est refaite ici.
function ligneCompetences(fiche, bonus, nom) {
  const lignes = fiche.querySelector(':scope > dl.bn-stat__lignes');
  if (!lignes || !bonus.size) return;
  const boutons = [...bonus].sort((a, b) => COMPETENCES[a[0]][1].localeCompare(COMPETENCES[b[0]][1], 'fr'))
    .flatMap(([id, n], i) => [i ? ' ' : '', boutonJetD20(`${COMPETENCES[id][1]} ${signe(n)}`, n, `${nom} : ${COMPETENCES[id][1]}`)]).filter(x => x !== '');
  const ligne = h('div', {}, h('dt', {}, 'Compétences'), h('dd', {}, boutons));
  const titre = el => el.querySelector('dt')?.textContent;
  const existante = [...lignes.children].find(el => titre(el) === 'Compétences');
  const sauvegardes = [...lignes.children].find(el => titre(el) === 'Jets de sauvegarde');
  if (existante) existante.replaceWith(ligne); else if (sauvegardes) sauvegardes.after(ligne); else lignes.prepend(ligne);
}

// Dans le texte des capacités et actions : après « Wisdom (Perception) » ou « Perception (Wisdom) », un petit bouton qui
// lance ce test (le bonus de la compétence s'il l'a, sinon le modificateur de la caractéristique). Pas de bouton pour un
// test demandé à une autre créature (« DC 13 Strength (Athletics) check », le DD en pastille juste avant).
const NOMS_COMPETENCES = Object.values(COMPETENCES).map(c => c[0]).join('|'), NOMS_CARACS = Object.keys(CARACS).join('|');
const MOTIF_TEST = new RegExp(`\\b(?:(${NOMS_CARACS})\\s*\\(\\s*(${NOMS_COMPETENCES})\\s*\\)|(${NOMS_COMPETENCES})\\s*\\(\\s*(${NOMS_CARACS})\\s*\\))`, 'g');
function boutonsDesTests(fiche, def, bonus, nom) {
  const mods = Object.fromEntries((def.stats || []).map(s => [s.statId, modificateur(s.value)]));
  const bonusDu = (id, carac) => {
    const defaut = COMPETENCES[id][2];
    if (!bonus.has(id)) return mods[carac] ?? 0;
    return bonus.get(id) - (mods[defaut] ?? 0) + (mods[carac] ?? 0);   // une autre caractéristique que l'habituelle : la sienne
  };
  for (const p of fiche.querySelectorAll('p.bn-stat__trait')) {
    const marcheur = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
    const noeuds = [];
    for (let n = marcheur.nextNode(); n; n = marcheur.nextNode()) {
      MOTIF_TEST.lastIndex = 0;
      if (MOTIF_TEST.test(n.data) && !n.parentElement.closest('button, .bn-dd, .fc-pouvoir__outil')) noeuds.push(n);
    }
    for (const n of noeuds) {
      const morceaux = [];
      let fin = 0;
      MOTIF_TEST.lastIndex = 0;   // matchAll() part de lastIndex, que test() a déplacé
      for (const m of n.data.matchAll(MOTIF_TEST)) {
        const id = ID_COMPETENCE[m[2] || m[3]], carac = CARACS[m[1] || m[4]];
        const avant = n.data.slice(0, m.index);
        const pastille = !avant.trim() && n.previousSibling?.classList?.contains('bn-dd') && /DD/.test(n.previousSibling.textContent);
        const autre = pastille || /\bDC\s*\d+\s*$/i.test(avant);
        morceaux.push(n.data.slice(fin, m.index + m[0].length));
        if (!autre) {
          const b = bonusDu(id, carac[0]);
          morceaux.push(' ', boutonJetD20(signe(b), b, `${nom} : ${COMPETENCES[id][1]} (${carac[1]})`));
        }
        fin = m.index + m[0].length;
      }
      morceaux.push(n.data.slice(fin));
      n.replaceWith(...morceaux.filter(x => x !== ''));   // replaceWith() écrirait les chaînes vides : filtrées
    }
  }
}

function vueFiche(d, cfg, quand) {
  const cr = creatureDe(d);
  if (!cr) return vueReglages(`${d.name || 'Ce personnage'} n'a pas de compagnon dans ses extras sur D&D Beyond.`);
  const def = cr.definition || {};
  const nom = String(cr.name || def.name || 'Compagnon').trim();
  const max = pvMaxDe(d, cr);
  const ca = Number(valeurDe(d, cr, VALEUR.ca)) || def.armorClass || null;
  const actuels = Math.max(0, max - (cr.removedHitPoints || 0));
  const etats = etatsDeLaNote(valeurDe(d, cr, VALEUR.note));
  const image = def.largeAvatarUrl || def.avatarUrl || null;
  // Compagnon de Flee, Mortals! (des pouvoirs de férocité, une attaque de signature) : la férocité, et le bonus de maîtrise
  // de son soigneur (les « plus PB » de sa fiche).
  const texte = DESCRIPTIONS.map(k => def[k] || '').join(' ');
  const avecFerocite = /\bferocity\b/i.test(texte) || /signature attack/i.test(texte);
  const niveau = niveauDe(d);
  const pb = maitriseDe(niveau);
  const descriptions = Object.fromEntries(DESCRIPTIONS.map(k => [k, ddAvecPb(def[k], pb)]));
  const fiche = blocStats({ ...def, ...descriptions, name: nom, armorClass: ca ?? def.armorClass, averageHitPoints: max }, cfg, { image, pb });
  if (avecFerocite) decorerFerocite(fiche, cr, niveau);
  // Pas de puissance (FP, PX) pour un compagnon : son seul PB, celui du soigneur pour un compagnon de Flee, Mortals!,
  // sinon celui de son FP.
  const pbAffiche = avecFerocite ? pb : (cfg?.puissances || []).find(x => x.id === def.challengeRatingId)?.maitrise ?? pb;
  const lignes = fiche.querySelector(':scope > dl.bn-stat__lignes');
  const puissance = [...(lignes?.querySelectorAll('dt') || [])].find(dt => dt.textContent === 'Puissance')?.parentElement;
  const lignePb = h('div', {}, h('dt', {}, 'PB'), h('dd', {}, `${signe(pbAffiche)} (bonus de maîtrise)`));
  if (puissance) puissance.replaceWith(lignePb); else lignes?.append(lignePb);
  encadrerPb(fiche, pbAffiche);
  const competences = bonusCompetences(def);
  ligneCompetences(fiche, competences, nom);
  boutonsDesTests(fiche, def, competences, nom);
  // À partir des caractéristiques (puis jets de sauvegarde, compétences…, capacités, actions), la fiche défile seule :
  // le haut de la fenêtre (PV, férocité, états, puis nom, CA, PV, vitesse, initiative et le portrait) reste en vue
  // (CSS, si la fenêtre est assez haute) ; le filet sous l'initiative reste, comme limite.
  const haut = fiche.querySelector(':scope > .cm-stat__haut');
  if (haut) {
    const suite = [haut.querySelector('.cm-stat__carac')];
    for (let el = haut.nextElementSibling; el; el = el.nextElementSibling) suite.push(el);
    fiche.append(h('div', { class: 'fc-defile' }, suite.filter(Boolean)));
  }
  const choix = (d.creatures || []).length > 1 ? h('select', { class: 'bn-select fc-choix', 'aria-label': 'Compagnon',
    onchange: e => { reglages.creature = e.target.value; garder(); afficher(); } },
  d.creatures.map(c => h('option', { value: String(c.id), selected: c.id === cr.id }, String(c.name || c.definition?.name || c.id).trim()))) : null;
  const son = bouton('', { icone: reglages.son ? 'lu-volume-2' : 'lu-volume-x', titre: reglages.son ? 'Son des dés (couper)' : 'Son des dés coupé (activer)', classe: 'bn-btn--s bn-btn--fantome',
    onclick: () => { reglages.son = !reglages.son; reglagesDes.son = reglages.son; garder(); afficher(); } });
  page.classList.add('avec-defile');   // la suite de la fiche défile seule (CSS)
  page.replaceChildren(...[   // replaceChildren() écrirait « null » : les absents sont filtrés
    h('header', { class: 'fc-tete' },
      h('div', { class: 'fc-titres' },
        h('span', { class: 'surtitre' }, `${GROUPES[cr.groupId] || 'Compagnon'} ${deNom(String(d.name || '').trim().split(' ')[0])}`),
        h('h1', { class: 'titre-m' }, nom)),
      h('div', { class: 'bn-groupe fc-outils' },
        infobulle(h('span', { class: 'ui-s cm-sourdine fc-age', tabindex: '0' }, ilYA(quand)), 'Relue sur D&D Beyond toutes les 15 s.', { titre: 'Dernière lecture' }),
        bouton('', { icone: 'lu-refresh-cw', titre: 'Relire maintenant', classe: 'bn-btn--s fc-relire', disabled: enLecture, onclick: () => relire() }),
        son,
        infobulle(bouton('', { icone: 'lu-info', classe: 'bn-btn--s bn-btn--fantome', 'aria-label': 'Règles des compagnons',
          onclick: e => flottant('regles-compagnons', { surtitre: 'Flee, Mortals!', titre: 'Les créatures compagnons', largeur: 480, depuis: e.currentTarget, contenu: contenuReglesCompagnons() }) }),
          'Flee, Mortals! : les règles des créatures compagnons (férocité, rampage, pouvoirs), résumées.', { titre: 'Règles des compagnons' }),
        bouton('', { icone: 'lu-sliders-horizontal', titre: 'Changer de fiche', classe: 'bn-btn--s bn-btn--fantome', onclick: () => vueReglages() }))),
    choix,
    h('section', { class: 'cm-pile fc-etat' },
      h('button', { type: 'button', class: 'fc-pv' + (ecriture ? ' est-en-cours' : ''), 'aria-expanded': String(edition), title: 'Dégâts, soins, PV temporaires',
        onclick: () => { edition = !edition; message = null; afficher(); } }, barrePV(nom, actuels, max, cr.temporaryHitPoints || 0)),
      edition ? editeurPv() : null,
      avecFerocite ? ligneFerocite(cr, nom) : null,
      message ? h('p', { class: 'ui-s fc-erreur' }, icone('lu-triangle-alert'), message) : null,
      etats.length ? h('div', { class: 'bn-groupe cm-etats-fiche' }, etats.map(e => badgeEtat(e, nom))) : null),
    h('div', { class: 'fc-corps' }, fiche),
  ].filter(Boolean));
}

let cfgGarde = null, iconesDemandees = false;
function afficher() {
  if (!dernier) return;
  const haut = document.scrollingElement.scrollTop, suite = page.querySelector('.fc-defile')?.scrollTop ?? 0;
  vueFiche(dernier.fiche, cfgGarde, dernier.quand);
  document.scrollingElement.scrollTop = haut;
  const defile = page.querySelector('.fc-defile');
  if (defile) defile.scrollTop = suite;
}

async function relire() {
  if (!reglages.fiche) return vueReglages();
  if (enLecture || ecriture) return;
  enLecture = true;
  page.querySelector('.fc-relire')?.setAttribute('disabled', '');
  try {
    const [fiche, cfg] = await Promise.all([lireFiche(reglages.fiche), lireConfig().catch(() => cfgGarde)]);
    cfgGarde = cfg;
    dernier = { fiche, quand: Date.now() };
    echec = null;
    enLecture = false;
    afficher();
    accorderRampage(fiche);
    // Les icônes des états, lues une fois sur D&D Beyond (la page de la partie du personnage), puis gardées.
    if (!iconesDemandees) { iconesDemandees = true; chargerIconesEtats(fiche.campaign?.id).then(pretes => { if (pretes) afficher(); }); }
  } catch (e) {
    echec = e.message;
    if (!dernier) vueReglages(e.message);
  } finally {
    enLecture = false;
    page.querySelector('.fc-relire')?.removeAttribute('disabled');
    majAge();
  }
}

const garder = () => chrome.storage.local.set({ reglages });
function changerFiche(id) {
  if (id !== reglages.fiche) { reglages.fiche = id; reglages.creature = null; dernier = null; }
  garder();
  relire();
}

// ───── Démarrage ─────

activerInfobulles();
const { reglages: gardes, ferocites: feroGardees } = await chrome.storage.local.get(['reglages', 'ferocites']);
reglages = { ...reglages, ...gardes };
ferocites = feroGardees || {};
reglagesDes.son = reglages.son !== false;
const depuisLOnglet = idDeFiche(new URLSearchParams(location.search).get('fiche'));
if (depuisLOnglet) changerFiche(depuisLOnglet); else relire();
// Un nouveau clic sur l'icône depuis une autre fiche (fond.js) ; relecture régulière tant que la fenêtre est visible, pas
// pendant que le joueur saisit des PV ou la férocité ; le temps depuis la dernière lecture, à la seconde.
chrome.runtime.onMessage.addListener(m => { if (m?.type === 'fiche' && idDeFiche(m.fiche)) changerFiche(idDeFiche(m.fiche)); });
const saisieEnCours = () => edition || reglageFero || ecriture || rampageEnCours || document.activeElement?.matches?.('input, select');
setInterval(() => { if (!document.hidden && dernier && !saisieEnCours()) relire(); }, RELIRE_MS);
setInterval(majAge, 1000);
