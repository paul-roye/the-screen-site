// Lancers de dés de la fiche (attaques, dégâts, sauvegardes, tests) : ils roulent en 3D sur la fenêtre (lancerEn3d de
// des-3d.js), le résultat en très grand au centre. Même interface que app/lancers.js du gestionnaire du MJ, sans son
// historique (pas de widget Dés ici).

import { lancer } from './des.js';
import { lancerEn3d, FACES_3D, critiqueDe } from './des-3d.js';

// Réglage de la fenêtre (fenetre.js) : le son des dés.
export const reglagesDes = { son: true };

// « 1d8 + 1 », « 1d6 − 2 » (textes de D&D Beyond) -> « 1d8+1 », « 1d6-2 ».
export const formuleDe = t => String(t).replace(/[−–]/g, '-').replace(/\s+/g, '');
// Un d20 et son bonus : « 1d20+3 », « 1d20-1 », « 1d20 ».
export const formuleD20 = bonus => (bonus ? `1d20${bonus > 0 ? '+' : '-'}${Math.abs(bonus)}` : '1d20');

// Montrer des jets déjà faits (lancer() de des.js) : [{ libelle, jet, formule?, detail?, type? }]. Un seul : son total en
// grand ; plusieurs : une ligne par jet, ou en grand côte à côte avec colonnes (une attaque : le jet et ses dégâts).
export async function montrerJets(entrees, { legende = '', couleur = 'sang', depuis = null, colonnes = false } = {}) {
  const l = entrees.filter(e => e.jet);
  if (!l.length) return null;
  const des = l.flatMap(e => (e.jet.faces || []).filter(d => FACES_3D.includes(d.faces)).map(d => (d.garde === false ? { ...d, terne: true } : d)));   // l'écarté : terne
  const un = l.length === 1 ? l[0] : null;
  const enColonnes = !un && colonnes;
  const ecrit = e => e.detail || `${e.formule || e.jet.formule} : ${e.jet.detail}`;
  return lancerEn3d(des, {
    depuis: depuis?.getBoundingClientRect ? depuis.getBoundingClientRect() : depuis, son: reglagesDes.son, couleur,
    legende: un ? legende || un.libelle : legende,
    total: un?.jet.total, type: un?.type, formule: un ? ecrit(un) : null, critique: un || enColonnes ? critiqueDe(l[0].jet.faces) : null,
    colonnes: enColonnes ? l.map(e => ({ libelle: e.libelle, total: e.jet.total, type: e.type, detail: ecrit(e) })) : null,
    lignes: un || enColonnes ? null : l.map(e => ({ libelle: e.libelle, total: e.jet.total, detail: ecrit(e), critique: critiqueDe(e.jet.faces) })),
  });
}

// Un jet d'un d20 avec avantage (le meilleur de deux d20) ou désavantage (le moins bon) : les deux d20 sont dans faces,
// l'écarté avec garde: false (terne en 3D ; le critique se juge sur le gardé). avantage : 'avantage', 'desavantage', ou rien.
export const AVANTAGES = { avantage: { libelle: 'avantage', court: 'av.' }, desavantage: { libelle: 'désavantage', court: 'désav.' } };
export function jeterD20(formule, avantage = null) {
  const f = formuleDe(formule);
  if (!AVANTAGES[avantage]) return lancer(f);
  const a = lancer(f), b = lancer(f);
  if (!a || !b) return null;
  const d20 = j => j.faces.find(d => d.faces === 20)?.valeur ?? 0;
  const garde = (avantage === 'avantage' ? d20(a) >= d20(b) : d20(a) <= d20(b)) ? a : b, autre = garde === a ? b : a;
  return { ...garde, formule: `${f} (${AVANTAGES[avantage].court})`,
    faces: [...garde.faces, ...autre.faces.filter(d => d.faces === 20).map(d => ({ ...d, garde: false }))],
    detail: `${garde.detail} (${AVANTAGES[avantage].libelle} : ${d20(autre)} écarté)` };
}

// Lancer une formule et la montrer ; renvoie le jet (null si la formule n'est pas lisible). options.avantage : un d20 avec
// avantage ou désavantage (jeterD20).
export function lancerVisible(formule, options = {}) {
  const f = formuleDe(formule);
  const jet = options.avantage ? jeterD20(f, options.avantage) : lancer(f);
  if (jet) montrerJets([{ libelle: options.libelle || '', jet, formule: jet.formule || f, type: options.type }], options);
  return jet;
}
