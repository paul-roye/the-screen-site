// Petits outils DOM partagés par le tableau de bord et les widgets.
// h('div', { class: 'x', onclick: fn }, enfant, 'texte', [autres]) : jamais d'innerHTML sur des données.

const SVG = 'http://www.w3.org/2000/svg';

export function h(tag, attrs, ...enfants) {
  const el = document.createElement(tag);
  for (const [cle, val] of Object.entries(attrs || {})) {
    if (val === null || val === undefined || val === false) continue;
    if (cle.startsWith('on') && typeof val === 'function') el.addEventListener(cle.slice(2), val);
    else if (cle === 'class') el.className = val;
    else if (cle === 'style' && typeof val === 'object') Object.assign(el.style, val);
    else if (cle in el && typeof val !== 'string') el[cle] = val;
    else el.setAttribute(cle, val === true ? '' : val);
  }
  ajouter(el, enfants);
  return el;
}

function ajouter(el, enfants) {
  for (const e of enfants.flat(Infinity)) {
    if (e === null || e === undefined || e === false) continue;
    el.append(e instanceof Node ? e : document.createTextNode(String(e)));
  }
}

// Icône du sprite : thématique (bn-<nom>, design-system/icons.js) ou Lucide (lu-<nom>, app/icones-ui.js).
export function icone(nom, classe = '') {
  const svg = document.createElementNS(SVG, 'svg');
  svg.setAttribute('class', ('bn-icone ' + classe).trim());
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(SVG, 'use');
  use.setAttribute('href', '#' + (nom.startsWith('lu-') ? nom : 'bn-' + nom));
  svg.append(use);
  return svg;
}

export function bouton(texte, { icone: ic, classe = '', titre, ...attrs } = {}) {
  const seulIcone = !texte;
  return h('button', {
    type: 'button',
    class: `bn-btn ${seulIcone ? 'bn-btn--icone' : ''} ${classe}`.replace(/\s+/g, ' ').trim(),
    'aria-label': seulIcone ? titre : null,
    title: titre || null,
    ...attrs,
  }, ic ? icone(ic) : null, texte ? h('span', {}, texte) : null);
}

export function badge(texte, couleur, ic) {
  return h('span', { class: 'bn-badge' + (couleur ? ' bn-badge--' + couleur : '') }, ic ? icone(ic) : null, texte);
}

// Unités accolées au nombre (« 30 ft », « DD 12 », « 16 miles ») : espace fine insécable, jamais de retour à la ligne entre les deux.
export const FINE = ' ';

// « d’Isolde », « de Bertrand ».
export const deNom = nom => (/^[aeiouyhàâéèêîôû]/i.test(nom) ? 'd’' : 'de ') + nom;

// Un jet à faire (composant DD) : dé et difficulté dans un petit cadre. dd : nombre ou texte (« 13/14 »).
// « DD » à part (.bn-dd__mot) : un cadre vertical (dé au-dessus du nombre) peut s'en passer.
export function pastilleDD(dd, titre) {
  return h('span', { class: 'bn-badge bn-dd', title: titre || null }, icone('d20'), h('span', { class: 'bn-dd__mot' }, `DD${FINE}`), String(dd));
}

// Alerte repliée sur une ligne (titre, repère à droite : un DD, « Fatigue +1 »…), le texte à l'ouverture.
export function alerteRepliable(couleur, ic, titre, repere, texte, { ouvert = false } = {}) {
  return h('details', { class: 'bn-alerte bn-alerte--repliable' + (couleur ? ' bn-alerte--' + couleur : ''), open: ouvert },
    h('summary', {}, icone(ic), h('p', { class: 'bn-alerte__titre' }, titre), repere || null, icone('lu-chevron-down', 'bn-icone--s bn-alerte__chevron')),
    h('div', { class: 'bn-alerte__texte' }, texte));
}

export function alerte(couleur, ic, titre, texte, ...extra) {
  return h('div', { class: 'bn-alerte' + (couleur ? ' bn-alerte--' + couleur : ''), role: couleur === 'sang' ? 'alert' : null },
    icone(ic), h('p', { class: 'bn-alerte__titre' }, titre), h('div', { class: 'bn-alerte__texte' }, texte, ...extra));
}

// Onglets accessibles. onglets : [{ id, libelle, court (libellé court, facultatif), icone, rendu: () => Node }]
// Barre trop étroite : jamais de défilement. Elle se resserre (écarts), puis prend les libellés courts, puis perd les icônes.
const NIVEAUX_ONGLETS = ['est-serree', 'est-courte', 'sans-icones'];
export function onglets(etiquette, liste, actif, surChangement) {
  const barre = h('div', { class: 'bn-onglets', role: 'tablist', 'aria-label': etiquette });
  const zone = h('div', { class: 'cm-onglet-zone', role: 'tabpanel' });
  const boutons = liste.map(o => h('button', {
    class: 'bn-onglet', role: 'tab', type: 'button', 'aria-selected': 'false', title: o.court ? o.libelle : null,
    onclick: () => choisir(o.id),
    onkeydown: e => {
      const i = liste.findIndex(x => x.id === o.id);
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        const j = (i + (e.key === 'ArrowRight' ? 1 : liste.length - 1)) % liste.length;
        choisir(liste[j].id); boutons[j].focus();
      }
    },
  }, o.icone ? icone(o.icone) : null,
    o.court ? [h('span', { class: 'bn-onglet__long' }, o.libelle), h('span', { class: 'bn-onglet__court' }, o.court)] : o.libelle));
  barre.append(...boutons);
  const ajuster = new ResizeObserver(() => {
    if (!barre.isConnected) { ajuster.disconnect(); return; }   // barre redessinée par le widget
    barre.classList.remove(...NIVEAUX_ONGLETS);
    for (const n of NIVEAUX_ONGLETS) {
      if (barre.scrollWidth <= barre.clientWidth + 1) break;
      barre.classList.add(n);
    }
  });
  ajuster.observe(barre);
  function choisir(id) {
    liste.forEach((o, i) => {
      boutons[i].setAttribute('aria-selected', String(o.id === id));
      boutons[i].tabIndex = o.id === id ? 0 : -1;
    });
    zone.replaceChildren(liste.find(o => o.id === id).rendu());
    if (surChangement) surChangement(id);
  }
  choisir(liste.some(o => o.id === actif) ? actif : liste[0].id);
  return { barre, zone, choisir };
}

// Bascule (design-system, Bouton) : [[valeur, libellé, icône?], …]. surChoix(valeur) au clic.
// iconesSeules : boutons carrés à icône, le libellé au survol (une ligne serrée). repliable : le libellé s'efface quand le
// conteneur de la ligne manque de place (classe cm-bascule-repliable, règle @container de app/app.css), au survol alors.
export function bascule(etiquette, options, valeur, surChoix, { iconesSeules = false, repliable = false } = {}) {
  return h('div', { class: 'bn-bascule' + (repliable ? ' cm-bascule-repliable' : ''), role: 'group', 'aria-label': etiquette }, options.map(([val, texte, ic]) => h('button', {
    type: 'button', class: 'bn-btn bn-btn--s' + (iconesSeules && ic ? ' bn-btn--icone' : ''), 'data-valeur': String(val), 'aria-pressed': String(valeur === val),
    title: (iconesSeules || repliable) && ic ? `${etiquette} : ${texte}` : null, 'aria-label': (iconesSeules || repliable) && ic ? texte : null, onclick: () => surChoix(val),
  }, ic ? icone(ic) : null, iconesSeules && ic ? null : h('span', {}, texte))));
}

// Section titrée d'une fiche : rien si le contenu est vide.
export function section(titre, ic, ...contenu) {
  const c = contenu.flat(Infinity).filter(Boolean);
  if (!c.length) return null;
  return h('div', { class: 'cm-section' }, h('p', { class: 'etiquette cm-section__titre' }, ic ? icone(ic, 'bn-icone--s') : null, titre), ...c);
}

// Provenance en bas de fiche : « Supplément, p. 12-13 du PDF ».
export function provenance(o) {
  if (!o?.source) return null;
  const pages = o.pages_livre ? `, p. ${o.pages_livre}` : o.pages_pdf ? `, p. ${o.pages_pdf} du PDF` : '';
  return h('p', { class: 'ui-s cm-sourdine' }, o.source + pages);
}

// « original » : ce que disait le livre, replié.
export function blocOriginal(texte) {
  if (!texte) return null;
  return h('details', { class: 'cm-original-bloc' }, h('summary', { class: 'etiquette' }, 'Version d\'origine'), h('p', { class: 'ui-s' }, texte));
}

export function normaliser(t) {
  return String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

// Écarts entre sources (voir formats/README.md) : applique, conditionnel, a_trancher.
export function blocEcarts(ecarts, conditions, libelleCondition) {
  if (!ecarts || !ecarts.length) return null;
  return h('div', { class: 'cm-ecarts' }, ecarts.map(e => {
    if (e.statut === 'a_trancher') {
      return alerte('cierge', 'lu-triangle-alert', 'À trancher · ' + e.sujet, e.question || e.texte || '',
        e.original ? h('span', { class: 'cm-original' }, ' Livre : ' + e.original) : null);
    }
    const actif = e.statut === 'applique' || (e.statut === 'conditionnel' && conditions[e.condition]);
    const etat = e.statut === 'conditionnel'
      ? (actif ? badge('En vigueur', 'brume', 'lu-check') : badge('Pas encore', null))
      : null;
    // Écart en vigueur : ouvert, il change la façon de jouer. Condition pas remplie : replié.
    return h('details', { class: 'cm-ecart' + (actif ? '' : ' cm-ecart--inactif'), open: !!actif },
      h('summary', {},
        badge(e.source, e.source === 'MJ' ? 'sang' : 'ultra'),
        h('span', { class: 'cm-ecart__sujet' }, e.sujet),
        etat),
      h('p', { class: 'cm-ecart__texte' }, e.texte),
      e.statut === 'conditionnel' ? h('p', { class: 'ui-s cm-sourdine' }, 'Condition : ' + libelleCondition(e.condition) + (actif ? ' (remplie)' : ' (pas encore remplie)')) : null,
      e.original ? h('p', { class: 'ui-s cm-sourdine' }, 'Avant : ' + e.original) : null,
      e.note ? h('p', { class: 'ui-s cm-sourdine' }, e.note) : null);
  }));
}

// Distance de jeu : en pieds, l'équivalent en mètres et en cases (1 case = 5 ft) dans une infobulle ; titre : « Vitesse »…
export function distance(pieds, prefixe = '', titre = null) {
  const m = (pieds * 0.3).toLocaleString('fr-FR', { maximumFractionDigits: 1 });
  const cases = (pieds / 5).toLocaleString('fr-FR', { maximumFractionDigits: 1 });
  return infobulle(h('span', { class: 'cm-distance' }, `${prefixe}${pieds}${FINE}ft`), `${m}${FINE}m · ${cases} case${pieds > 5 ? 's' : ''}`, { titre });
}

// Infobulle (design-system, Infobulle) : au survol ou au focus de l'élément, texte et titre en option.
// Bleue pour une information ; ton 'sang' pour une info importante ou une action importante au clic. Renvoie l'élément.
export function infobulle(el, texte, { titre, ton } = {}) {
  el.dataset.bulle = texte;
  if (titre) el.dataset.bulleTitre = titre;
  if (ton) el.dataset.bulleTon = ton;
  return el;
}

// Une seule infobulle pour la page, en popover (au-dessus des dialogues), au-dessus de l'élément survolé (dessous s'il manque de place).
export function activerInfobulles() {
  const bulle = h('div', { class: 'bn-bulle', popover: 'manual', role: 'tooltip' });
  document.body.append(bulle);
  let cible = null;
  const cacher = () => {
    cible = null;
    if (bulle.matches(':popover-open')) bulle.hidePopover();
  };
  const montrer = el => {
    cible = el;
    const { bulle: texte, bulleTitre: titre, bulleTon: ton } = el.dataset;
    bulle.className = 'bn-bulle' + (ton ? ' bn-bulle--' + ton : '');
    bulle.replaceChildren(...[titre ? h('b', {}, titre) : null, h('span', {}, texte)].filter(Boolean));   // un null s'écrirait « null »
    if (!bulle.matches(':popover-open')) bulle.showPopover();
    const r = el.getBoundingClientRect(), b = bulle.getBoundingClientRect();
    const haut = r.top - b.height - 6 >= 8 ? r.top - b.height - 6 : r.bottom + 6;
    bulle.style.left = Math.round(Math.min(Math.max(8, r.left + r.width / 2 - b.width / 2), innerWidth - b.width - 8)) + 'px';
    bulle.style.top = Math.round(haut) + 'px';
  };
  const viser = e => e.target.closest?.('[data-bulle]') || null;
  document.addEventListener('pointerover', e => { const el = viser(e); if (el !== cible) (el ? montrer(el) : cacher()); });
  document.addEventListener('pointerout', e => { if (!e.relatedTarget) cacher(); });
  document.addEventListener('focusin', e => { const el = viser(e); if (el) montrer(el); });
  document.addEventListener('focusout', cacher);
  document.addEventListener('pointerdown', cacher);
  document.addEventListener('scroll', cacher, true);
}

// Bouton qui ouvre un petit menu de choix juste dessous (design-system, Menu) : [[libellé, titre, action], …].
// Popover natif : un clic ailleurs ou Échap le referment. Renvoie [bouton, menu], à placer côte à côte.
export function boutonMenu(declencheur, choix, etiquette) {
  const menu = h('div', { class: 'bn-menu', popover: 'auto', role: 'menu', 'aria-label': etiquette },
    choix.map(([lib, titre, action]) => h('button', { type: 'button', class: 'bn-menu__choix', role: 'menuitem', title: titre || null,
      onclick: () => { menu.hidePopover(); action(); } }, lib)));
  declencheur.popoverTargetElement = menu;
  declencheur.setAttribute('aria-haspopup', 'menu');
  menu.addEventListener('beforetoggle', e => {
    if (e.newState !== 'open') return;
    const r = declencheur.getBoundingClientRect();
    Object.assign(menu.style, { left: Math.round(r.left) + 'px', top: Math.round(r.bottom + 4) + 'px' });
  });
  // Ouvert : gardé dans l'écran (au-dessus du bouton s'il manque de place dessous) ; le premier choix prend le focus.
  menu.addEventListener('toggle', e => {
    declencheur.setAttribute('aria-expanded', String(e.newState === 'open'));
    if (e.newState !== 'open') return;
    const r = declencheur.getBoundingClientRect(), m = menu.getBoundingClientRect();
    if (m.bottom > innerHeight - 8) menu.style.top = Math.round(r.top - m.height - 4) + 'px';
    if (m.right > innerWidth - 8) menu.style.left = Math.round(innerWidth - m.width - 8) + 'px';
    menu.querySelector('button')?.focus();
  });
  return [declencheur, menu];
}

// Le même menu, ouvert d'un clic sur autre chose qu'un bouton de menu (un portrait) : posé dans la page sous l'élément,
// retiré à sa fermeture. classe : sa mise en page (cm-menu-etats : trois colonnes, icône et libellé).
export function ouvrirMenu(ancre, choix, etiquette, { classe = '' } = {}) {
  const [, menu] = boutonMenu(ancre, choix, etiquette);
  ancre.popoverTargetElement = null;   // l'ancre n'ouvre pas le menu d'elle-même
  if (classe) menu.classList.add(...classe.split(' '));
  menu.addEventListener('toggle', e => { if (e.newState !== 'open') menu.remove(); });
  document.body.append(menu);
  menu.showPopover();
  return menu;
}

// Jets contre la mort d'un héros à 0 PV (design-system, JetsMort) : à gauche les réussis, à droite les ratés, un crâne
// entre les deux. Stabilisé (trois réussis, ou noté sur la fiche) : le cadre en jaune, un cœur. Trois échecs : le héros est
// mort, marqueMort() à la place. jds : { succes, echecs, stabilise } d'une fiche D&D Beyond (formats/etat.md).
export function jetsContreLaMort({ succes = 0, echecs = 0, stabilise = false } = {}) {
  const stable = stabilise || succes >= 3;
  const etat = stable ? 'stabilise' : echecs >= 3 ? 'mort' : null;
  const texte = stable ? 'Stabilisé' + (succes >= 3 ? ' : trois jets contre la mort réussis' : '') : echecs >= 3 ? 'Mort : trois jets contre la mort ratés'
    : `Jets contre la mort : ${succes} réussi${succes > 1 ? 's' : ''}, ${echecs} raté${echecs > 1 ? 's' : ''}`;
  const serie = (n, sorte) => h('span', { class: `bn-jds__serie bn-jds__serie--${sorte}` }, [0, 1, 2].map(i => h('span', { class: 'bn-jds__pas' + (i < n ? ' est-fait' : '') })));
  return h('span', { class: 'bn-jds', 'data-etat': etat, role: 'img', 'aria-label': texte, title: texte },
    serie(succes, 'reussis'), icone(stable ? 'coeur' : 'crane'), serie(echecs, 'rates'));
}

// Mort (design-system, JetsMort, .bn-mort) : à la place des jets, des PV et de la CA. grand : sur une carte de personnage.
export function marqueMort({ grand = false, titre = 'Mort : trois jets contre la mort ratés' } = {}) {
  return h('span', { class: 'bn-mort' + (grand ? ' bn-mort--grand' : ''), role: 'img', 'aria-label': titre, title: titre }, icone('crane'), h('span', {}, 'Mort'), grand ? icone('crane') : null);
}

// Charges (emplacements de sorts, usages limités) : un losange par charge, vide s'il est disponible, plein s'il a servi.
// Au-delà de 6 charges : un seul losange à moitié plein, suivi du compte disponible (« 9/10 »).
export function jauge(utilises, max, etiquette, couleur = 'cierge') {
  const dispo = Math.max(0, max - utilises);
  const texte = `${etiquette} : ${dispo} disponible${dispo > 1 ? 's' : ''} sur ${max}`;
  const pas = max > 6
    ? [h('span', { class: 'cm-jauge__pas' + (dispo === 0 ? ' est-utilise' : utilises > 0 ? ' est-moitie' : '') }), h('span', { class: 'cm-jauge__compte' }, `${dispo}/${max}`)]
    : Array.from({ length: max }, (_, i) => h('span', { class: 'cm-jauge__pas' + (i < utilises ? ' est-utilise' : '') }));
  return h('span', { class: `cm-jauge cm-jauge--${couleur}`, role: 'img', 'aria-label': texte, title: texte }, pas);
}

// Fenêtre flottante (design-system, Flottant) : non modale, déplaçable par sa tête.
// Une seule fenêtre par clé : rouvrir la ramène devant et remplace son contenu. Renvoie { el, maj(contenu), fermer }.
// Une ligne de liste qui ouvre une fenêtre porte data-flottant="<clé>" (lienFlottant) : elle a .est-ouvert tant que sa
// fenêtre est ouverte.
const flottants = new Map();
let devant = 900;
// Dernier clic (ou toucher) : une fenêtre ouverte juste après se place de son côté, à mi-chemin du centre de l'écran.
let dernierClic = null;
document.addEventListener('pointerdown', e => { dernierClic = { x: e.clientX, y: e.clientY, t: performance.now() }; }, true);
const marquerLignes =(cle, ouvert) => document.querySelectorAll(`[data-flottant="${CSS.escape(cle)}"]`).forEach(e => e.classList.toggle('est-ouvert', ouvert));
export function lienFlottant(el, cle) {
  el.dataset.flottant = cle;
  el.classList.toggle('est-ouvert', flottants.has(cle));
  return el;
}
// compact : tête resserrée, petit titre, corps sans marge (une carte, une image qui doit tenir à l'écran).
// depuis : élément d'où la fenêtre semble ouverte (une ligne amenée en vue par un autre widget), à la place du dernier clic.
// plein : toute la fenêtre du navigateur, posée en haut à gauche (une vue d'ensemble), sans placement au clic.
export function flottant(cle, { surtitre, titre, contenu, largeur, compact = false, depuis = null, plein = false }) {
  const deja = flottants.get(cle);
  if (deja) { deja.maj(contenu, titre, surtitre); deja.avant(); return deja; }
  const titres = h('div', { class: 'bn-panel__titres' });
  const corps = h('div', { class: 'bn-panel__corps' });
  const tete = h('div', { class: 'bn-panel__tete' }, titres, bouton('', { icone: 'lu-x', titre: 'Fermer', classe: 'bn-btn--s bn-btn--fantome', onclick: () => fermer() }));
  const el = h('dialog', { class: 'bn-flottant' + (compact ? ' bn-flottant--compact' : '') + (plein ? ' bn-flottant--plein' : ''), 'aria-label': titre }, h('div', { class: 'bn-panel' }, tete, corps));
  if (largeur && !plein) el.style.width = `min(${largeur}px, calc(100vw - 32px))`;
  document.body.append(el);
  // Ouverte depuis un dialogue modal (fiche d'un PNJ depuis une confirmation…) : modale elle aussi, sinon elle resterait
  // derrière, inerte. Fond transparent (CSS) : on voit toujours le dialogue dessous.
  // Le dialogue refermé, elle redevient une fenêtre ordinaire, à la même place.
  const modal = document.querySelector('dialog:modal');
  if (modal) {
    el.showModal();
    modal.addEventListener('close', () => {
      if (!el.isConnected || !el.open) return;
      const { left, top } = el.style;
      el.close();
      el.show();
      Object.assign(el.style, { left, top });
    }, { once: true });
  } else el.show();
  el.addEventListener('cancel', e => { e.preventDefault(); fermer(); });
  // Position de départ : en cascade, à droite du centre.
  const n = flottants.size;
  const placer = (x, y) => {
    const r = el.getBoundingClientRect();
    el.style.left = Math.min(Math.max(8, x), innerWidth - Math.min(r.width, innerWidth) - 8) + 'px';
    el.style.top = Math.max(8, Math.min(y, innerHeight - r.height - 8)) + 'px';
  };
  const avant = () => {
    flottants.forEach(f => f.el.classList.remove('est-devant'));
    el.style.zIndex = String(++devant);
    el.classList.add('est-devant');
  };
  el.addEventListener('pointerdown', avant);
  el.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); fermer(); } });
  tete.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button, a, input, select')) return;
    const dx = e.clientX - el.offsetLeft, dy = e.clientY - el.offsetTop;
    tete.setPointerCapture(e.pointerId);
    el.classList.add('est-saisi');
    const bouger = ev => placer(ev.clientX - dx, ev.clientY - dy);
    const lacher = () => { el.classList.remove('est-saisi'); tete.removeEventListener('pointermove', bouger); tete.removeEventListener('pointerup', lacher); };
    tete.addEventListener('pointermove', bouger);
    tete.addEventListener('pointerup', lacher);
  });
  function maj(c, t = titre, st = surtitre) {
    titres.replaceChildren(...[st ? h('span', { class: 'surtitre' }, st) : null, h('h2', { class: 'titre-m' }, t)].filter(Boolean));   // un null s'écrirait « null »
    el.setAttribute('aria-label', t);
    const haut = corps.scrollTop;
    corps.replaceChildren(...[c].flat().filter(Boolean));
    corps.scrollTop = haut;
  }
  function fermer() { el.remove(); flottants.delete(cle); marquerLignes(cle, false); }
  const f = { el, maj, fermer, avant };
  flottants.set(cle, f);
  marquerLignes(cle, true);
  maj(contenu);
  // Ouverte par un clic : entre le centre de l'écran et le clic (à gauche ou à droite, selon où il a eu lieu), un peu au-dessus
  // de lui ; décalée si une autre fenêtre est déjà là. Sinon (ouverte d'elle-même) : en cascade, à droite du centre.
  const r = depuis?.isConnected ? depuis.getBoundingClientRect() : null;
  const clic = r?.height ? { x: r.left + r.width / 2, y: r.top + r.height / 2 }
    : dernierClic && performance.now() - dernierClic.t < 1500 ? dernierClic : null;
  if (plein) placer(16, 16);
  else if (clic) {
    let x = (innerWidth / 2 + clic.x) / 2 - el.offsetWidth / 2, y = clic.y - 60;
    while ([...flottants.values()].some(o => o.el !== el && Math.abs(o.el.offsetLeft - x) < 12 && Math.abs(o.el.offsetTop - y) < 12)) { x += 28; y += 28; }
    placer(x, y);
  } else placer(innerWidth / 2 - el.offsetWidth / 2 + 40 + n * 28, 80 + n * 28);
  // Contenu qui grandit après coup (image chargée, résumé ajouté) : la fenêtre se replace pour rester dans l'écran.
  const garde = new ResizeObserver(() => { if (el.isConnected) placer(el.offsetLeft, el.offsetTop); else garde.disconnect(); });
  garde.observe(el);
  avant();
  return f;
}
export const flottantOuvert = cle => flottants.get(cle) || null;

export function heure(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) + ' · ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

export function identifiant() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
