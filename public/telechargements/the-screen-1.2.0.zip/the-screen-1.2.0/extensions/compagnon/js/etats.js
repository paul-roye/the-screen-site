// États (conditions) en VF : noms et effets du glossaire du Document de référence du système 5.2.1 (DRS, Wizards of the
// Coast, licence CC-BY-4.0), distances en pieds ; identifiants de D&D Beyond. Copie des données du gestionnaire du MJ.
// Lecture de la ligne que le MJ écrit dans la note du compagnon sur D&D Beyond : « [États (MJ) : À terre, Épuisement 2] ».

import { h, distance, FINE } from './ui.js';

export const EPUISEMENT = 4;
export const NIVEAU_MAX = 6;

// gravite : ordre sur le portrait (quatre icônes au plus), le plus grave d'abord.
export const ETATS = [
  { id: 1, slug: 'blinded', nom: 'Aveuglé', court: 'Av', gravite: 8, page: 189, effets: [
    ['Incapable de voir', 'Vous ne voyez rien et ratez automatiquement tout test de caractéristique reposant sur la vue.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage, et vos jets d’attaque subissent le Désavantage.']] },
  { id: 2, slug: 'charmed', nom: 'Charmé', court: 'Ch', gravite: 10, page: 190, effets: [
    ['Ne pas nuire au charmeur', 'Vous ne pouvez pas attaquer votre « charmeur » ni le cibler avec des aptitudes ou effets magiques qui infligent des dégâts.'],
    ['Interaction avec Avantage', 'Le charmeur a l’Avantage aux tests de caractéristique d’interaction sociale avec vous.']] },
  { id: 3, slug: 'deafened', nom: 'Assourdi', court: 'As', gravite: 14, page: 188, effets: [
    ['Incapable d’entendre', 'Vous n’entendez rien et ratez automatiquement tous les tests de caractéristique qui reposent sur l’ouïe.']] },
  { id: 4, slug: 'exhaustion', nom: 'Épuisement', court: 'Ép', gravite: 6, page: 192, effets: [
    ['Niveaux d’Épuisement', 'Cet état est cumulatif. Chaque fois que vous le recevez, vous subissez 1 niveau d’Épuisement. Vous mourez quand votre niveau d’Épuisement atteint 6.'],
    ['Tests d20 affectés', 'Lorsque vous effectuez un Test d20, le résultat est réduit de 2 fois votre niveau actuel d’Épuisement.'],
    ['Vitesse réduite', 'Votre Vitesse est réduite de 5 ft × votre niveau actuel d’Épuisement.'],
    ['Suppression des niveaux d’Épuisement', 'Terminer un Repos long dissipe 1 niveau d’Épuisement. Lorsque votre niveau d’Épuisement atteint 0, l’état prend fin pour vous.']] },
  { id: 5, slug: 'frightened', nom: 'Effrayé', court: 'Ef', gravite: 9, page: 191, effets: [
    ['Effet sur les attaques et les tests de caractéristique', 'Vous subissez le Désavantage aux tests de caractéristique et aux jets d’attaque tant que la source de votre effroi est dans votre champ de vision.'],
    ['Impossible d’approcher', 'Vous ne pouvez pas vous rapprocher volontairement de la source de votre effroi.']] },
  { id: 6, slug: 'grappled', nom: 'Agrippé', court: 'Ag', gravite: 7, page: 187, effets: [
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Vous subissez le Désavantage aux jets d’attaque contre toute cible hormis l’agrippeur.'],
    ['Déplaçable', 'L’agrippeur peut vous tirer ou vous porter lorsqu’il se déplace, mais ses coûts de déplacement sont doublés, sauf si vous êtes de taille Très petite (TP) ou que votre catégorie de taille est inférieure d’au moins deux crans à la sienne.']] },
  { id: 7, slug: 'incapacitated', nom: 'Neutralisé', court: 'Ne', gravite: 5, page: 196, effets: [
    ['Inactif', 'Vous ne pouvez entreprendre ni action, ni action Bonus ni Réaction.'],
    ['Concentration brisée', 'Votre Concentration est brisée.'],
    ['Sans voix', 'Vous ne pouvez pas parler.'],
    ['Surpris', 'Si vous êtes Neutralisé au moment de jouer l’Initiative, vous subissez le Désavantage à ce jet.']] },
  { id: 8, slug: 'invisible', nom: 'Invisible', court: 'Iv', gravite: 15, page: 195, effets: [
    ['Surprise', 'Si vous êtes Invisible au moment de jouer l’Initiative, vous avez l’Avantage à ce jet.'],
    ['Dissimulé', 'Vous n’êtes pas affecté par les effets qui exigent que la cible soit vue, sauf si le créateur de l’effet vous « voit » par un biais ou un autre. Tout l’équipement que vous portez est lui aussi dissimulé.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous subissent le Désavantage, et vos jets d’attaque ont l’Avantage. Si une créature vous voit par un biais ou un autre, vous ne recevez pas ce bénéfice contre elle.']] },
  { id: 9, slug: 'paralyzed', nom: 'Paralysé', court: 'Pa', gravite: 3, page: 196, effets: [
    ['Neutralisé', 'Vous subissez l’état Neutralisé.'],
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.'],
    ['Coups critiques automatiques', 'Tout jet d’attaque qui vous touche est un Coup critique si l’assaillant qui la porte se trouve dans un rayon de 5 ft.']] },
  { id: 10, slug: 'petrified', nom: 'Pétrifié', court: 'Pé', gravite: 2, page: 197, effets: [
    ['Transformé en substance inanimée', 'Vous êtes transformé, ainsi que les objets non magiques que vous portez, en une substance inanimée et dense (généralement de la pierre). Votre poids est décuplé et vous n’êtes plus soumis au vieillissement.'],
    ['Neutralisé', 'Vous subissez l’état Neutralisé.'],
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Résistance aux dégâts', 'Vous avez la Résistance à tous les dégâts.'],
    ['Immunité contre le poison', 'Vous avez l’Immunité contre l’état Empoisonné.']] },
  { id: 11, slug: 'poisoned', nom: 'Empoisonné', court: 'Em', gravite: 11, page: 192, effets: [
    ['Effet sur les attaques et les tests de caractéristique', 'Vous subissez le Désavantage aux jets d’attaque et aux tests de caractéristique.']] },
  { id: 12, slug: 'prone', nom: 'À terre', court: 'At', gravite: 12, page: 187, effets: [
    ['Déplacement limité', 'Vos seules possibilités de déplacement sont ramper ou vous relever en dépensant la moitié de votre Vitesse (arrondie à l’inférieur), ce qui met un terme à l’état. Si votre Vitesse est de 0, vous ne pouvez pas vous relever.'],
    ['Effet sur les attaques', 'Vous subissez le Désavantage aux jets d’attaque. Un jet d’attaque contre vous reçoit l’Avantage si l’assaillant se trouve dans un rayon de 5 ft de vous. Sans cela, ce jet d’attaque subit le Désavantage.']] },
  { id: 13, slug: 'restrained', nom: 'Entravé', court: 'En', gravite: 6.5, page: 192, effets: [
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage, et vos jets d’attaque subissent le Désavantage.'],
    ['Effet sur les jets de sauvegarde', 'Vous subissez le Désavantage aux jets de sauvegarde de Dextérité.']] },
  { id: 14, slug: 'stunned', nom: 'Étourdi', court: 'Ét', gravite: 4, page: 192, effets: [
    ['Neutralisé', 'Vous subissez l’état Neutralisé.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.']] },
  { id: 15, slug: 'unconscious', nom: 'Inconscient', court: 'Ic', gravite: 1, page: 194, effets: [
    ['Inerte', 'Vous subissez les états À terre et Neutralisé, et laissez choir tout ce que vous teniez. Lorsque cet état prend fin, vous êtes toujours À terre.'],
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Coups critiques automatiques', 'Tout jet d’attaque qui vous touche est un Coup critique si l’assaillant qui la porte se trouve dans un rayon de 5 ft.'],
    ['Dénué de conscience', 'Vous n’avez pas conscience de ce qui vous entoure.']] },
];
const PAR_ID = new Map(ETATS.map(e => [e.id, e]));
export const ETATS_PAR_NOM = [...ETATS].sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));

// État d'une fiche relevée ({ id, nom, niveau } de etat/beyond.json ; les relevés d'avant la version 1.5.0 de l'extension
// n'ont que le nom) → { ...état, niveau }.
export function etatDe(e) {
  const x = PAR_ID.get(e?.id) || ETATS.find(y => y.nom === e?.nom);
  return x ? { ...x, niveau: x.id === EPUISEMENT ? e.niveau || 1 : null } : null;
}
// États d'une fiche, du plus grave au moins grave.
export const etatsDe = f => (f?.etats || []).map(etatDe).filter(Boolean).sort((a, b) => a.gravite - b.gravite);
export const nomEtat = e => (e.niveau ? `${e.nom} ${e.niveau}` : e.nom);

// Effets d'un état, en liste : distances en pieds (mètres et cases au survol).
const avecDistances = t => t.split(/(\d+) ft/).map((x, i) => (i % 2 ? distance(Number(x)) : x));
export function effetsEtat(e) {
  return h('dl', { class: 'cm-etat-effets' }, e.effets.flatMap(([titre, texte]) => [h('dt', { class: 'ui' }, titre), h('dd', { class: 'texte' }, avecDistances(texte))]));
}

// Épuisement : ce que coûte le niveau, en une ligne.
export const coutEpuisement = n => `−${2 * n} aux tests d20, Vitesse −${5 * n}${FINE}ft`;

// ───── Icônes des états : celles de Maps (le VTT de D&D Beyond), comme le gestionnaire ─────
// Œuvres de D&D Beyond : l'extension ne les contient pas, elle les lit dans le navigateur du joueur, comme le fait
// scripts/import-etats/ du gestionnaire. La page de la partie (www.dndbeyond.com/games/<campagne>, avec la session du
// joueur) liste les morceaux de code de Maps (media.dndbeyond.com) ; l'un d'eux contient la table des icônes, un SVG par
// état (clés = slug). Les SVG sont relus élément par élément (formes et attributs de dessin seuls, couleur du texte),
// rangés en symboles (#ddb-etat-<slug>) dans un sprite caché, et gardés 30 jours (chrome.storage.local) ; un échec n'est
// réessayé qu'au bout de 6 h. Sans elles, l'abréviation du nom.
const NS = 'http://www.w3.org/2000/svg';
const FORMES = new Set(['svg', 'g', 'path', 'circle', 'ellipse', 'rect', 'polygon', 'polyline', 'line']);
const ATTRIBUTS = new Set(['d', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'width', 'height', 'points', 'fill', 'fill-rule',
  'clip-rule', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'transform', 'opacity', 'fill-opacity', 'stroke-opacity']);
const GARDE_ICONES = 30 * 24 * 3600 * 1000, REESSAI_ICONES = 6 * 3600 * 1000;
const MORCEAU = /https:\/\/media\.dndbeyond\.com\/games\/_next\/static\/chunks\/[^"'\s\\]+\.js/g;
const disponibles = new Set();
let chargementIcones = null;

function copiePropre(source) {
  const el = document.createElementNS(NS, source.localName);
  for (const a of source.attributes) {
    if (!ATTRIBUTS.has(a.name)) continue;
    const v = (a.name === 'fill' || a.name === 'stroke') && a.value !== 'none' ? 'currentColor' : a.value;
    if (/url\(|javascript:/i.test(v)) continue;
    el.setAttribute(a.name, v);
  }
  for (const c of source.children) if (FORMES.has(c.localName) && c.localName !== 'svg') el.append(copiePropre(c));
  return el;
}
// Chaîne JavaScript entre apostrophes : ses échappements (\n, \', \uXXXX…) décodés.
const decoder = s => s.replace(/\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)/g, (_, e) =>
  e[0] === 'n' ? '\n' : e[0] === 't' ? '\t' : e[0] === 'r' ? '\r' : /^[ux]/.test(e) && e.length > 1 ? String.fromCharCode(parseInt(e.slice(1), 16)) : e);

async function lireIconesSurBeyond(campagne) {
  const page = await fetch(`https://www.dndbeyond.com/games/${campagne}`, { credentials: 'include' }).then(r => (r.ok ? r.text() : ''));
  const morceaux = [...new Set(page.match(MORCEAU) || [])];
  for (const url of morceaux) {
    const code = await fetch(url).then(r => (r.ok ? r.text() : '')).catch(() => '');
    if (!/blinded:[\w$]+\('<svg/.test(code)) continue;
    const icones = {};
    for (const m of code.matchAll(/([a-z]+):[\w$]+\('(<svg(?:[^'\\]|\\.)*)'\)/g)) {
      if (ETATS.some(e => e.slug === m[1]) && !icones[m[1]]) icones[m[1]] = decoder(m[2]).trim();
    }
    if (Object.keys(icones).length >= 10) return icones;
  }
  return null;
}

// Une fois par fenêtre ; rend vrai si des icônes sont prêtes (afficher à nouveau pour s'en servir).
export function chargerIconesEtats(campagne) {
  chargementIcones ||= (async () => {
    const { iconesEtats: garde } = await chrome.storage.local.get('iconesEtats');
    let icones = garde?.icones && Date.now() - garde.quand < GARDE_ICONES ? garde.icones : null;
    if (!icones && campagne && !(garde?.echec && Date.now() - garde.echec < REESSAI_ICONES)) {
      icones = await lireIconesSurBeyond(campagne).catch(() => null);
      await chrome.storage.local.set({ iconesEtats: icones ? { quand: Date.now(), icones } : { ...garde, echec: Date.now() } });
    }
    icones ||= garde?.icones || null;   // gardées depuis plus de 30 jours : mieux que rien
    if (!icones) return false;
    const sprite = document.createElementNS(NS, 'svg');
    sprite.setAttribute('aria-hidden', 'true');
    sprite.style.display = 'none';
    for (const e of ETATS) {
      const texte = icones[e.slug];
      if (typeof texte !== 'string') continue;
      const svg = new DOMParser().parseFromString(texte, 'image/svg+xml').documentElement;
      if (svg?.localName !== 'svg' || !svg.getAttribute('viewBox')) continue;
      const symbole = document.createElementNS(NS, 'symbol');
      symbole.id = 'ddb-etat-' + e.slug;
      symbole.setAttribute('viewBox', svg.getAttribute('viewBox'));
      for (const c of svg.children) if (FORMES.has(c.localName) && c.localName !== 'svg') symbole.append(copiePropre(c));
      sprite.append(symbole);
      disponibles.add(e.slug);
    }
    document.body.append(sprite);
    return disponibles.size > 0;
  })().catch(() => false);
  return chargementIcones;
}

// Tuile d'un état (composant Etat de la charte, comme dans le gestionnaire) : l'icône de D&D Beyond, sinon son
// abréviation ; Épuisement : le niveau en exposant.
export function iconeEtat(e, classe = '') {
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'bn-etat__svg');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(NS, 'use');
  use.setAttribute('href', '#ddb-etat-' + e.slug);
  svg.append(use);
  return h('span', { class: ('bn-etat ' + classe).trim(), 'data-etat': e.slug },
    disponibles.has(e.slug) ? svg : h('span', { class: 'bn-etat__court', 'aria-hidden': 'true' }, e.court),
    e.niveau ? h('sup', { class: 'bn-etat__niveau' }, e.niveau) : null);
}

// ───── Note du compagnon (formats/note-compagnon.md du gestionnaire) ─────
// Une ligne « [États (MJ) : À terre, Épuisement 2] » n'importe où dans la note ; noms comparés sans casse, accents ni
// espaces ; « Épuisement N » donne le niveau (1 à 6) ; un nom inconnu est ignoré. Rend les états, du plus grave au moins grave.
const sansAccents = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, '');
const PAR_CLE = new Map(ETATS.map(e => [sansAccents(e.nom), e]));
export function etatsDeLaNote(note) {
  const m = /\[\s*[ÉE]tats\s*\(MJ\)\s*:([^\]]*)\]/iu.exec(String(note || ''));
  if (!m) return [];
  const vus = new Map();
  for (const brut of m[1].split(',')) {
    const t = brut.trim();
    const niv = /^(.*?)\s*(\d+)\s*$/.exec(t);
    const e = PAR_CLE.get(sansAccents(niv ? niv[1] : t)) || PAR_CLE.get(sansAccents(t));
    if (!e) continue;
    const niveau = e.id === EPUISEMENT ? Math.min(NIVEAU_MAX, Math.max(1, Number(niv?.[2]) || 1)) : null;
    vus.set(e.id, { ...e, niveau });
  }
  return [...vus.values()].sort((a, b) => a.gravite - b.gravite);
}
