// Lancer de dés en 3D, dessiné sur toute la page : un canvas par-dessus le tableau, qui laisse passer les clics.
// Le résultat est tiré avant (aleatoire() de app/des.js). La trajectoire est simulée d'abord (rebonds, bords de l'écran,
// chocs entre dés), puis l'orientation est intégrée à rebours depuis la pose finale, face du résultat vers le haut :
// le dé roule et s'arrête de lui-même sur la bonne face, sans saut.
// Monde : x, y en px CSS de la fenêtre, z la hauteur au-dessus de la page ; caméra au-dessus du centre, perspective légère.
// lancerEn3d([{ faces: 4|6|8|10|12|20, valeur, libelle?, terne? }], { depuis: DOMRect, son, total, formule, legende, lignes,
//   couleur }) -> { fin: Promise (dés arrêtés), arreter() }. Un nouveau lancer efface le précédent.
// Les dés roulent dans le bas de la page ; posés, le résultat s'affiche en très grand au centre (façon Baldur's Gate 3) :
// legende au-dessus (« Morsure : jet d'attaque »), total, formule et détail dessous ; ou lignes ([{ libelle, total,
// detail, critique? }], plusieurs résultats : l'initiative). couleur : jeton de la charte du résultat (sang ; ultra pour un
// monstre). critique : 'reussite' (un d20 qui fait 20 : or et violet chatoyants, étincelles) ou 'echec' (un 1 : cadre
// éteint, secousse) ; voir critiqueDe().
// Copie adaptée à la fenêtre du joueur (extensions/compagnon, retour du MJ du 2026-10-20 : « lancer le dé au milieu de la
// fenêtre visible, pour le voir ») : les dés visent le milieu de la fenêtre visible (pas le bas de la page), sur toute sa
// largeur (pas de menu rapide) ; le résultat se pose au-dessus d'eux (style.css). Le reste comme dans le gestionnaire.

import { h, icone } from './ui.js';

const PHI = (1 + Math.sqrt(5)) / 2;
const DT = 1 / 60;
const G = 3200;              // px/s²
const CAMERA = 1500;         // hauteur de la caméra (px)
const DUREE_MAX = 5;         // s
const AFFICHAGE = 15000;     // ms : les dés et le résultat restent 15 s (demande du MJ, 2026-10-20 ; 6 s avant), un clic ou Échap les efface avant

// ───── Vecteurs et quaternions ([w, x, y, z]) ─────
const plus = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const moins = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const fois = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const scal = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const vect = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norme = a => Math.hypot(a[0], a[1], a[2]);
const unite = a => fois(a, 1 / (norme(a) || 1));
const auHasard = () => unite([Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5]);

const qMul = (a, b) => [
  a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
  a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
  a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
  a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]];
const qAxe = (axe, angle) => { const u = unite(axe), s = Math.sin(angle / 2); return [Math.cos(angle / 2), u[0] * s, u[1] * s, u[2] * s]; };
const qUnite = q => { const n = Math.hypot(...q); return q.map(c => c / n); };
function qTourner(q, v) {
  const u = [q[1], q[2], q[3]];
  const t = fois(vect(u, v), 2);
  return plus(plus(v, fois(t, q[0])), vect(u, t));
}
// Rotation qui amène le vecteur unitaire a sur b.
function qDe(a, b) {
  const c = scal(a, b), axe = vect(a, b);
  if (norme(axe) < 1e-6) return c > 0 ? [1, 0, 0, 0] : qAxe(Math.abs(a[0]) < 0.9 ? vect(a, [1, 0, 0]) : vect(a, [0, 1, 0]), Math.PI);
  return qAxe(axe, Math.atan2(norme(axe), c));
}

// ───── Solides (rayon circonscrit 1) ─────
// groupes : sommets de chaque face, dans le désordre ; ils sont rangés autour de la face, normale vers l'extérieur.
function solide(sommets, groupes) {
  const r = Math.max(...sommets.map(norme));
  const S = sommets.map(s => fois(s, 1 / r));
  const faces = groupes.map(g => {
    const c = fois(g.reduce((a, i) => plus(a, S[i]), [0, 0, 0]), 1 / g.length);
    const n0 = unite(c);
    const plat = i => { const d = moins(S[i], c); return moins(d, fois(n0, scal(d, n0))); };
    const e1 = unite(plat(g[0])), e2 = vect(n0, e1);
    const idx = [...g].sort((i, j) => Math.atan2(scal(plat(i), e2), scal(plat(i), e1)) - Math.atan2(scal(plat(j), e2), scal(plat(j), e1)));
    let n = unite(vect(moins(S[idx[1]], S[idx[0]]), moins(S[idx[2]], S[idx[0]])));
    if (scal(n, c) < 0) { idx.reverse(); n = fois(n, -1); }
    return { idx, n, c };
  });
  return { S, faces, rayonIn: Math.min(...faces.map(f => scal(f.n, S[f.idx[0]]))) };
}

function tetraedre() {
  return solide([[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]]);
}
function cube() {
  const S = [];
  for (const x of [-1, 1]) for (const y of [-1, 1]) for (const z of [-1, 1]) S.push([x, y, z]);
  const faces = [];
  for (let a = 0; a < 3; a++) for (const s of [-1, 1]) faces.push(S.map((p, i) => (p[a] === s ? i : -1)).filter(i => i >= 0));
  return solide(S, faces);
}
function octaedre() {
  const faces = [];
  for (const i of [0, 1]) for (const j of [2, 3]) for (const k of [4, 5]) faces.push([i, j, k]);
  return solide([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], faces);
}
// Trapézoèdre pentagonal : deux couronnes décalées à ±e, pointes à ±hp (faces planes : hp = e (1 + cos 36°) / (1 − cos 36°)).
function d10() {
  const e = 0.105, c36 = Math.cos(Math.PI / 5), hp = e * (1 + c36) / (1 - c36);
  const S = [[0, 0, hp], [0, 0, -hp]];
  for (let k = 0; k < 5; k++) {
    S.push([Math.cos(2 * Math.PI * k / 5), Math.sin(2 * Math.PI * k / 5), e]);
    S.push([Math.cos(2 * Math.PI * (k + 0.5) / 5), Math.sin(2 * Math.PI * (k + 0.5) / 5), -e]);
  }
  const U = k => 2 + 2 * (k % 5), L = k => 3 + 2 * (k % 5);
  const faces = [];
  for (let k = 0; k < 5; k++) faces.push([0, U(k), L(k), U(k + 1)], [1, L(k), U(k + 1), L(k + 1)]);
  return solide(S, faces);
}
function icosaedre() {
  const S = [];
  for (const a of [-1, 1]) for (const b of [-1, 1]) S.push([0, a, b * PHI], [a, b * PHI, 0], [b * PHI, 0, a]);
  const voisins = (i, j) => Math.abs(norme(moins(S[i], S[j])) - 2) < 1e-6;
  const faces = [];
  for (let i = 0; i < 12; i++) for (let j = i + 1; j < 12; j++) for (let k = j + 1; k < 12; k++)
    if (voisins(i, j) && voisins(j, k) && voisins(i, k)) faces.push([i, j, k]);
  return { S, faces };
}
// Dodécaèdre : le dual de l'icosaèdre (un sommet par face de l'icosaèdre, une face par sommet).
function dodecaedre() {
  const ico = icosaedre();
  const S = ico.faces.map(f => fois(plus(plus(ico.S[f[0]], ico.S[f[1]]), ico.S[f[2]]), 1 / 3));
  return solide(S, ico.S.map((_, i) => ico.faces.map((f, j) => (f.includes(i) ? j : -1)).filter(j => j >= 0)));
}

// texte : hauteur des chiffres (rayon du dé = 1) ; taille : rayon relatif ; sommets : chiffres aux pointes (d4).
export const FACES_3D = [4, 6, 8, 10, 12, 20];   // dés qui roulent en 3D (un d100 : deux d10)
const TYPES = {
  4: { fabriquer: tetraedre, taille: 1.3, texte: 0.42, sommets: true },
  6: { fabriquer: cube, taille: 0.92, texte: 0.62, arete: true },
  8: { fabriquer: octaedre, taille: 1.08, texte: 0.5 },
  10: { fabriquer: d10, taille: 1.05, texte: 0.4 },
  12: { fabriquer: dodecaedre, taille: 1.05, texte: 0.4 },
  20: { fabriquer: () => { const i = icosaedre(); return solide(i.S, i.faces); }, taille: 1.1, texte: 0.34 },
};
const modeles = new Map();

// Faces opposées : valeurs de somme n + 1, comme un vrai dé. Chiffres posés à plat sur la face (d4 : un par pointe).
function modele(faces) {
  if (modeles.has(faces)) return modeles.get(faces);
  const t = TYPES[faces];
  const sol = t.fabriquer();
  const { S } = sol;
  const etiquettes = sol.faces.map(() => []);
  const pose = [];   // valeur -> { d : direction vers le haut quand elle sort, haut : sens de lecture }
  if (t.sommets) {
    sol.faces.forEach((f, i) => f.idx.forEach(s => {
      const haut = unite(moins(S[s], f.c));
      etiquettes[i].push({ p: plus(f.c, fois(moins(S[s], f.c), 0.58)), haut, n: f.n, valeur: s + 1 });
    }));
    S.forEach((s, i) => { pose[i + 1] = { d: unite(s), haut: null }; });
  } else {
    const libres = sol.faces.map((_, i) => i);
    const valeurs = [];
    for (let k = 1; libres.length; k++) {
      const i = libres.shift();
      const j = libres.reduce((m, x) => (scal(sol.faces[x].n, sol.faces[i].n) < scal(sol.faces[m].n, sol.faces[i].n) ? x : m), libres[0]);
      libres.splice(libres.indexOf(j), 1);
      valeurs[i] = k; valeurs[j] = faces + 1 - k;
    }
    sol.faces.forEach((f, i) => {
      // Sens de lecture : vers le milieu d'une arête (d6), sinon vers la pointe la plus éloignée (la pointe du d10).
      const vise = t.arete ? fois(plus(S[f.idx[0]], S[f.idx[1]]), 0.5)
        : S[f.idx.reduce((m, s) => (norme(moins(S[s], f.c)) > norme(moins(S[m], f.c)) + 1e-6 ? s : m), f.idx[0])];
      const haut = unite(moins(vise, f.c));
      etiquettes[i].push({ p: t.arete ? f.c : plus(f.c, fois(haut, -0.04)), haut, n: f.n, valeur: valeurs[i] });
      pose[valeurs[i]] = { d: f.n, haut };
    });
  }
  const m = { ...sol, etiquettes, pose, type: t };
  modeles.set(faces, m);
  return m;
}

// Pose finale : la valeur vers le haut (+z), lisible (le haut des chiffres vers le haut de l'écran, à peu près).
function poseFinale(m, valeur) {
  const { d, haut } = m.pose[valeur];
  const aligne = qDe(d, [0, 0, 1]);
  let lacet = Math.random() * 2 * Math.PI;
  if (haut) {
    const u = qTourner(aligne, haut);
    lacet = -Math.PI / 2 - Math.atan2(u[1], u[0]) + (Math.random() - 0.5) * 0.5;
  }
  return qUnite(qMul(qAxe([0, 0, 1], lacet), aligne));
}

// ───── Trajectoires ─────
// Les dés visent le bas de la page : le haut du centre reste au résultat.
function simuler(des, zone, depart) {
  const cx = zone.x0 + (zone.x1 - zone.x0) * (0.35 + 0.3 * Math.random());
  const cy = zone.y0 + (zone.y1 - zone.y0) * (0.5 + 0.14 * Math.random());   // le milieu de la fenêtre visible, sous le résultat
  const cap = Math.atan2(cy - depart[1], cx - depart[0]);
  const dist = Math.hypot(cx - depart[0], cy - depart[1]);
  const etats = des.map((d, i) => {
    const decale = (i - (des.length - 1) / 2) * d.rc * 1.2;   // en ligne, en travers du lancer
    const angle = cap + (Math.random() - 0.5) * 0.45;
    const vitesse = (dist * 0.75 + 100) * (0.85 + Math.random() * 0.3);
    return {
      p: [depart[0] - Math.sin(cap) * decale, depart[1] + Math.cos(cap) * decale],
      v: [Math.cos(angle) * vitesse, Math.sin(angle) * vitesse],
      z: 90 + Math.random() * 110, vz: 200 + Math.random() * 350,
      w: fois(auHasard(), 13 + Math.random() * 9),
      sol: false, arret: false, rc: d.rc, rRoule: d.rRoule,
    };
  });
  const images = [etats.map(e => ({ x: e.p[0], y: e.p[1], z: e.z }))];
  const rotations = etats.map(() => []);
  const chocs = [];
  const choc = (f, force) => { if (force > 0.04) chocs.push({ f, force: Math.min(1, force) }); };
  const N = Math.round(DUREE_MAX / DT);
  for (let f = 0; f < N; f++) {
    const fin = f > N * 0.75;   // trop long : on freine fort
    for (const [i, e] of etats.entries()) {
      let w = [0, 0, 0];
      if (!e.sol) {
        e.vz -= G * DT;
        e.z += e.vz * DT;
        if (e.z <= 0) {
          e.z = 0;
          if (-e.vz > 220) {
            choc(f, -e.vz / 1400);
            e.vz = -e.vz * 0.38;
            e.v = [e.v[0] * 0.78, e.v[1] * 0.78];
            e.w = fois(auHasard(), Math.hypot(...e.v) / e.rRoule * 0.8 + 5);
          } else { e.vz = 0; e.sol = true; }
        }
        w = e.w;
      } else if (!e.arret) {
        const s = Math.hypot(...e.v);
        const ns = Math.max(0, s - (s * (fin ? 6 : 1.7) + 150) * DT);
        if (ns < 6) { e.v = [0, 0]; e.arret = true; }
        else e.v = [e.v[0] * ns / s, e.v[1] * ns / s];
        w = fois([-e.v[1], e.v[0], 0], 0.85 / e.rRoule);   // roule sur la page : ω = z × v / r
      }
      e.p = [e.p[0] + e.v[0] * DT, e.p[1] + e.v[1] * DT];
      // Bords de l'écran.
      if (e.p[0] < zone.x0 + e.rc) { e.p[0] = zone.x0 + e.rc; if (e.v[0] < 0) { choc(f, -e.v[0] / 2500); e.v[0] *= -0.55; } }
      if (e.p[0] > zone.x1 - e.rc) { e.p[0] = zone.x1 - e.rc; if (e.v[0] > 0) { choc(f, e.v[0] / 2500); e.v[0] *= -0.55; } }
      if (e.p[1] < zone.y0 + e.rc) { e.p[1] = zone.y0 + e.rc; if (e.v[1] < 0) { choc(f, -e.v[1] / 2500); e.v[1] *= -0.55; } }
      if (e.p[1] > zone.y1 - e.rc) { e.p[1] = zone.y1 - e.rc; if (e.v[1] > 0) { choc(f, e.v[1] / 2500); e.v[1] *= -0.55; } }
      rotations[i].push(w);
    }
    // Chocs entre dés (même masse) : ils s'écartent et échangent leur élan le long de la normale.
    for (let i = 0; i < etats.length; i++) for (let j = i + 1; j < etats.length; j++) {
      const a = etats[i], b = etats[j];
      const dx = b.p[0] - a.p[0], dy = b.p[1] - a.p[1], d = Math.hypot(dx, dy), min = a.rc + b.rc;
      if (d >= min || d === 0 || Math.abs(a.z - b.z) > min) continue;
      const nx = dx / d, ny = dy / d, ecart = (min - d) / 2;
      a.p = [a.p[0] - nx * ecart, a.p[1] - ny * ecart];
      b.p = [b.p[0] + nx * ecart, b.p[1] + ny * ecart];
      const rel = (a.v[0] - b.v[0]) * nx + (a.v[1] - b.v[1]) * ny;
      if (rel <= 0) continue;
      const k = 0.8 * rel;
      a.v = [a.v[0] - nx * k, a.v[1] - ny * k];
      b.v = [b.v[0] + nx * k, b.v[1] + ny * k];
      for (const e of [a, b]) if (e.sol && Math.hypot(...e.v) > 6) e.arret = false;
      choc(f, rel / 2500);
    }
    images.push(etats.map(e => ({ x: e.p[0], y: e.p[1], z: e.z })));
    if (etats.every(e => e.sol && e.arret)) break;
  }
  return { images, rotations, chocs };
}

// À rebours depuis la pose finale : q(f) = R(ω(f) dt)⁻¹ q(f + 1).
function orienter(rotations, finale) {
  const q = new Array(rotations.length + 1);
  q[rotations.length] = finale;
  for (let f = rotations.length - 1; f >= 0; f--) {
    const w = rotations[f], a = norme(w) * DT;
    const r = a > 1e-9 ? qAxe(w, -a) : [1, 0, 0, 0];
    q[f] = qMul(r, q[f + 1]);
    if (f % 30 === 0) q[f] = qUnite(q[f]);
  }
  return q;
}

// ───── Son : un petit claquement par choc ─────
let audio = null;
function claquer(force) {
  try {
    audio ??= new AudioContext();
    const duree = 0.045, n = Math.round(audio.sampleRate * duree);
    const buf = audio.createBuffer(1, n, audio.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n) ** 4;
    const src = audio.createBufferSource();
    src.buffer = buf;
    const filtre = audio.createBiquadFilter();
    filtre.type = 'bandpass';
    filtre.frequency.value = 1600 + Math.random() * 2400;
    filtre.Q.value = 1.4;
    const g = audio.createGain();
    g.gain.value = 0.06 + force * 0.5;
    src.connect(filtre).connect(g).connect(audio.destination);
    src.start();
  } catch { /* pas de son possible */ }
}

// ───── Lancer ─────
let courant = null;

// Un jet de d20 seul (attaque, sauvegarde, test, initiative) : 'reussite' sur un 20 naturel, 'echec' sur un 1, sinon null.
// des : [{ faces, valeur, garde? }] ; un d20 écarté (avantage) ne compte pas.
export function critiqueDe(des) {
  const d20 = (des || []).filter(d => d.faces === 20 && d.garde !== false);
  if (d20.length !== 1) return null;
  return d20[0].valeur === 20 ? 'reussite' : d20[0].valeur === 1 ? 'echec' : null;
}

// colonnes ([{ libelle, total, type?, detail }]) : deux résultats en grand côte à côte (une attaque : le jet et ses
// dégâts), critique : celui du premier. type : sous le total, le type de dégâts (« perforants », « 11 perforants + 13
// nécrotiques »).
export function lancerEn3d(jets, { depuis, son = true, total, type, formule, legende, lignes, colonnes, couleur = 'sang', critique = null } = {}) {
  courant?.arreter();
  const css = getComputedStyle(document.documentElement);
  const jeton = nom => css.getPropertyValue(nom).trim();
  // Le chiffre sorti sur le dé : la couleur du résultat ; or sur une réussite critique, gris éteint sur un échec critique.
  const teinte = critique === 'reussite' ? 'soleil' : critique === 'echec' ? 'fane' : couleur;
  const couleurs = {
    corps: jeton('--trait'), arete: jeton('--trait-fort'), texte: jeton('--os'), terne: jeton('--fane'),
    resultat: jeton(`--${teinte}`) || jeton('--sang'), halo: jeton(`--halo-${teinte}`) || (critique === 'reussite' ? jeton('--soleil') : 'transparent'), police: jeton('--font-ui'),
  };

  const L = innerWidth, H = innerHeight, dpr = devicePixelRatio || 1;
  const base = Math.max(48, Math.min(84, Math.min(L, H * 1.4) / 21));   // deux fois la taille d'avant (demande du MJ, 2026-10-20)
  const zone = { x0: 24, y0: 24, x1: L - 24, y1: H - 24 };   // toute la fenêtre visible (pas de menu rapide ici)
  const des = jets.map(j => {
    const m = modele(j.faces);
    const R = base * m.type.taille;
    return { ...j, m, R, rc: R * 0.82, rRoule: R * m.rayonIn * 1.15, libelle: j.libelle || (v => (j.faces === 10 ? String(v % 10) : String(v))) };
  });
  const r = depuis || { left: L / 2, top: H / 2, width: 0, height: 0 };
  const depart = [Math.min(zone.x1 - 60, Math.max(zone.x0 + 60, r.left + r.width / 2)), Math.min(zone.y1 - 60, Math.max(zone.y0 + 60, r.top + r.height / 2))];
  const { images, rotations, chocs } = simuler(des, zone, depart);
  des.forEach((d, i) => { d.q = orienter(rotations[i], poseFinale(d.m, d.valeur)); });
  const N = images.length - 1;

  const canvas = h('canvas', { class: 'cm-des3d__toile', width: Math.round(L * dpr), height: Math.round(H * dpr) });
  // Étincelles d'une réussite critique, posées autour du cadre (en % de sa taille), chacune avec son décalage.
  const ETINCELLES = [[-4, 12], [102, 8], [-6, 70], [104, 64], [18, -10], [80, -12], [30, 104], [70, 106]];
  const bulle = h('div', { class: 'cm-des3d__bulle', 'data-couleur': couleur, 'data-critique': lignes?.length ? null : critique, hidden: true },
    !lignes?.length && critique === 'reussite' ? ETINCELLES.map(([x, y], i) => {
      const e = icone('lu-sparkles', 'cm-des3d__etincelle');
      e.style.left = `${x}%`; e.style.top = `${y}%`; e.style.animationDelay = `${(i * 0.21).toFixed(2)}s`;
      return e;
    }) : null,
    legende ? h('span', { class: 'cm-des3d__legende' }, legende) : null,
    !lignes?.length && critique ? h('span', { class: 'cm-des3d__critique' }, icone(critique === 'reussite' ? 'lu-sparkles' : 'crane'),
      critique === 'reussite' ? 'Réussite critique' : 'Échec critique', icone(critique === 'reussite' ? 'lu-sparkles' : 'crane')) : null,
    lignes?.length ? h('div', { class: 'cm-des3d__lignes' }, lignes.map(l => h('div', { class: 'cm-des3d__ligne', 'data-critique': l.critique || null },
      h('span', { class: 'cm-des3d__libelle' }, l.libelle), h('b', { class: 'cm-des3d__nombre' }, String(l.total)), l.detail ? h('span', { class: 'cm-des3d__detail' }, l.detail) : h('span'))))
      : colonnes?.length ? h('div', { class: 'cm-des3d__colonnes' }, colonnes.map(c => h('div', { class: 'cm-des3d__colonne' },
        h('span', { class: 'cm-des3d__titre' }, c.libelle), h('b', { class: 'cm-des3d__total' }, String(c.total)),
        c.type ? h('span', { class: 'cm-des3d__type' }, c.type) : null,
        c.detail ? h('span', { class: 'cm-des3d__formule' }, c.detail) : null)))
      : h('span', { class: 'cm-des3d__total' }, String(total ?? '')),
    !lignes?.length && !colonnes?.length && type ? h('span', { class: 'cm-des3d__type' }, type) : null,
    formule ? h('span', { class: 'cm-des3d__formule' }, formule) : null);
  const voile = h('div', { class: 'cm-des3d', 'aria-hidden': 'true' }, canvas, bulle);
  document.body.append(voile);
  const ctx = canvas.getContext('2d');
  const cam = [L / 2, H / 2, CAMERA];
  const proj = p => { const k = CAMERA / (CAMERA - p[2]); return [cam[0] + (p[0] - cam[0]) * k, cam[1] + (p[1] - cam[1]) * k]; };

  function dessiner(f, pose) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, L, H);
    const img = images[f];
    // Ombres, plus pâles et décalées quand le dé est en l'air. Noir et blanc ne servent qu'à la lumière (ombres, ombrage,
    // reflets, en opacité) : les couleurs des dés viennent des jetons de la charte.
    ctx.fillStyle = '#000';
    des.forEach((d, i) => {
      const { x, y, z } = img[i];
      ctx.globalAlpha = 0.55 * Math.max(0.15, 1 - z / 300);
      ctx.beginPath();
      ctx.ellipse(x + z * 0.25 + d.R * 0.12, y + z * 0.35 + d.R * 0.18, d.R * (0.95 + z / 500), d.R * (0.85 + z / 500), 0, 0, 2 * Math.PI);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    const ordre = des.map((d, i) => i).sort((a, b) => img[a].z - img[b].z);
    for (const i of ordre) {
      const d = des[i], q = d.q[f], { x, y, z } = img[i];
      const centre = [x, y, z + d.R * d.m.rayonIn];
      const monde = s => plus(centre, fois(qTourner(q, s), d.R));
      const P = d.m.S.map(s => proj(monde(s)));
      const terne = pose && d.terne;
      d.m.faces.forEach((face, fi) => {
        const n = qTourner(q, face.n);
        const vers = moins(cam, monde(face.c));
        const face2cam = scal(n, unite(vers));
        if (face2cam <= 0) return;
        ctx.beginPath();
        face.idx.forEach((s, k) => (k ? ctx.lineTo(...P[s]) : ctx.moveTo(...P[s])));
        ctx.closePath();
        ctx.globalAlpha = 1;
        ctx.fillStyle = couleurs.corps;
        ctx.fill();
        // Lumière en haut à gauche : ombre sur les faces qui s'en détournent, reflet sur celles qui lui font face.
        const lum = scal(n, LUMIERE);
        ctx.fillStyle = '#000';
        ctx.globalAlpha = Math.max(0, 0.5 - 0.5 * lum) + (terne ? 0.4 : 0);   // dé écarté (avantage) : assombri
        ctx.fill();
        const reflet = Math.max(0, scal(n, MI_CHEMIN)) ** 24;
        if (reflet > 0.01) { ctx.fillStyle = '#fff'; ctx.globalAlpha = reflet * 0.22; ctx.fill(); }
        ctx.globalAlpha = terne ? 0.5 : 1;
        ctx.strokeStyle = couleurs.arete;
        ctx.lineWidth = 1.2;
        ctx.lineJoin = 'round';
        ctx.stroke();
        // Chiffres, transformés dans le plan de la face (approximation affine de la perspective).
        // Les faces du d4 sont très inclinées : ses chiffres restent lisibles plus longtemps.
        const lisible = d.m.type.sommets ? Math.min(1, Math.max(0, (face2cam - 0.05) / 0.2)) : Math.min(1, Math.max(0, (face2cam - 0.18) / 0.35));
        if (!lisible) return;
        for (const e of d.m.etiquettes[fi]) {
          const p = monde(e.p);
          const haut = qTourner(q, e.haut);
          let droite = qTourner(q, vect(e.haut, e.n));
          const P0 = proj(p), Pu = proj(plus(p, haut));
          let Pr = proj(plus(p, droite));
          let a = [Pr[0] - P0[0], Pr[1] - P0[1]];
          const c = [P0[0] - Pu[0], P0[1] - Pu[1]];
          if (a[0] * c[1] - a[1] * c[0] < 0) a = [-a[0], -a[1]];   // jamais en miroir
          ctx.setTransform(dpr * a[0], dpr * a[1], dpr * c[0], dpr * c[1], dpr * P0[0], dpr * P0[1]);
          const sorti = pose && e.valeur === d.valeur;
          const taille = d.m.type.texte * d.R;
          ctx.font = `700 ${taille.toFixed(1)}px ${couleurs.police}`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.globalAlpha = lisible * (terne ? 0.6 : 1);
          ctx.fillStyle = sorti && !terne ? couleurs.resultat : terne ? couleurs.terne : couleurs.texte;
          ctx.shadowColor = sorti && !terne ? couleurs.halo : 'transparent';
          ctx.shadowBlur = sorti && !terne ? 12 * dpr : 0;
          const texte = d.libelle(e.valeur);
          ctx.fillText(texte, 0, 0);
          // 6 et 9 soulignés, comme sur les vrais dés.
          if ((texte === '6' || texte === '9') && d.faces >= 10) ctx.fillRect(-taille * 0.22, taille * 0.42, taille * 0.44, taille * 0.07);
          ctx.shadowBlur = 0;
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        }
        ctx.globalAlpha = 1;
      });
    }
  }

  let resoudre;
  const fin = new Promise(r => { resoudre = r; });
  let raf = 0, minuterie = 0, debut = performance.now(), dernier = -1, arrete = false, pose = false;
  function image(t) {
    const f = Math.min(N, Math.floor((t - debut) / 1000 / DT));
    if (son) for (const c of chocs) if (c.f > dernier && c.f <= f) { claquer(c.force); break; }
    dernier = f;
    pose = f >= N;
    dessiner(f, pose);
    if (!pose) { raf = requestAnimationFrame(image); return; }
    bulle.hidden = false;   // le résultat, en grand au centre (CSS), au-dessus des dés posés
    resoudre();
    minuterie = setTimeout(arreter, AFFICHAGE);
  }
  function arreter() {
    if (arrete) return;
    arrete = true;
    cancelAnimationFrame(raf);
    clearTimeout(minuterie);
    resoudre();
    document.removeEventListener('pointerdown', surClic, true);
    document.removeEventListener('keydown', surTouche, true);
    voile.classList.add('est-efface');
    setTimeout(() => voile.remove(), 300);
    if (courant === lancer) courant = null;
  }
  // Un clic ou Échap efface les dés posés ; pendant qu'ils roulent, seul Échap les arrête.
  const surClic = () => { if (pose) arreter(); };
  const surTouche = e => { if (e.key === 'Escape') arreter(); };
  document.addEventListener('pointerdown', surClic, true);
  document.addEventListener('keydown', surTouche, true);
  raf = requestAnimationFrame(t => { debut = t; image(t); });
  const lancer = { fin, arreter };
  courant = lancer;
  return lancer;
}

const LUMIERE = unite([-0.45, -0.6, 1]);
const MI_CHEMIN = unite(plus(LUMIERE, [0, 0, 1]));
