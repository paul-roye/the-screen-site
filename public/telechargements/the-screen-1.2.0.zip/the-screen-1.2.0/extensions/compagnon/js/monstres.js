// Fiche d'un monstre de D&D Beyond (monster-service, via l'extension), au format du composant Bloc de stats de la charte.
// Libellés traduits d'après le dictionnaire de D&D Beyond (commande « config » de l'extension). Les textes des capacités
// restent ceux de D&D Beyond (anglais), nettoyés : paragraphes, gras, italique, listes et formules de dés seulement.
// Jets à lancer d'un clic (composant DD, variante violette bn-dd--jet ; dés en 3D, résultat en violet : app/lancers.js) :
// bonus d'attaque et dégâts des capacités, jets de sauvegarde, initiative. Les DD des capacités en pastille, comme sur
// les cartes de personnage.

import { h, icone, distance, pastilleDD, deNom, ouvrirMenu } from './ui.js';
import { lancerVisible, montrerJets, formuleD20, formuleDe, jeterD20, AVANTAGES } from './lancers.js';
import { lancer } from './des.js';
import { critiqueDe } from './des-3d.js';

const TAILLES = { Tiny: 'TP', Small: 'P', Medium: 'M', Large: 'G', Huge: 'TG', Gargantuan: 'Gig', 'Medium or Small': 'M ou P' };
const TYPES = {
  Aberration: 'Aberration', Beast: 'Bête', Celestial: 'Céleste', Construct: 'Créature artificielle', Dragon: 'Dragon', Elemental: 'Élémentaire',
  Fey: 'Fée', Fiend: 'Fiélon', Giant: 'Géant', Humanoid: 'Humanoïde', Monstrosity: 'Créature monstrueuse', Ooze: 'Vase', Plant: 'Plante', Undead: 'Mort-vivant',
};
const ALIGNEMENTS = {
  'Lawful Good': 'loyal bon', 'Neutral Good': 'neutre bon', 'Chaotic Good': 'chaotique bon', 'Lawful Neutral': 'loyal neutre', Neutral: 'neutre',
  'Chaotic Neutral': 'chaotique neutre', 'Lawful Evil': 'loyal mauvais', 'Neutral Evil': 'neutre mauvais', 'Chaotic Evil': 'chaotique mauvais',
  Unaligned: 'sans alignement', 'Any Alignment': 'tout alignement',
};
const MOUVEMENTS = { Walk: '', Burrow: 'creusement', Climb: 'escalade', Fly: 'vol', Swim: 'nage' };
const SENS = { Blindsight: 'vision aveugle', Darkvision: 'vision dans le noir', Tremorsense: 'perception des vibrations', Truesight: 'vision véritable' };
const CARAC = { STR: 'For', DEX: 'Dex', CON: 'Con', INT: 'Int', WIS: 'Sag', CHA: 'Cha' };
const CARAC_LONG = { STR: 'Force', DEX: 'Dextérité', CON: 'Constitution', INT: 'Intelligence', WIS: 'Sagesse', CHA: 'Charisme' };
const CARAC_EN = { Strength: 'Force', Dexterity: 'Dextérité', Constitution: 'Constitution', Intelligence: 'Intelligence', Wisdom: 'Sagesse', Charisma: 'Charisme' };
const DEGATS = {
  Bludgeoning: 'contondants', Piercing: 'perforants', Slashing: 'tranchants', Lightning: 'foudre', Thunder: 'tonnerre', Poison: 'poison', Cold: 'froid',
  Radiant: 'radiants', Fire: 'feu', Necrotic: 'nécrotiques', Acid: 'acide', Psychic: 'psychiques', Force: 'force',
};
const ETATS = {
  Blinded: 'aveuglé', Charmed: 'charmé', Deafened: 'assourdi', Exhaustion: 'épuisement', Frightened: 'effrayé', Grappled: 'agrippé',
  Incapacitated: 'neutralisé', Invisible: 'invisible', Paralyzed: 'paralysé', Petrified: 'pétrifié', Poisoned: 'empoisonné', Prone: 'à terre',
  Restrained: 'entravé', Stunned: 'étourdi', Unconscious: 'inconscient',
};
const COMPETENCES = {
  Acrobatics: 'Acrobaties', 'Animal Handling': 'Dressage', Arcana: 'Arcanes', Athletics: 'Athlétisme', Deception: 'Tromperie', History: 'Histoire',
  Insight: 'Intuition', Intimidation: 'Intimidation', Investigation: 'Investigation', Medicine: 'Médecine', Nature: 'Nature', Perception: 'Perception',
  Performance: 'Représentation', Persuasion: 'Persuasion', Religion: 'Religion', 'Sleight of Hand': 'Escamotage', Stealth: 'Discrétion', Survival: 'Survie',
};
// Sections de la fiche : champ de D&D Beyond, titre.
const SECTIONS = [
  ['specialTraitsDescription', 'Traits'], ['actionsDescription', 'Actions'], ['bonusActionsDescription', 'Actions bonus'],
  ['reactionsDescription', 'Réactions'], ['legendaryActionsDescription', 'Actions légendaires'], ['mythicActionsDescription', 'Actions mythiques'],
  ['lairDescription', 'Repaire'],
];

export const modificateur = v => Math.floor((v - 10) / 2);
export const signe = n => (n >= 0 ? '+' : '−') + Math.abs(n);

// HTML de D&D Beyond -> nœuds sûrs (jamais d'innerHTML) : p, em, strong, b, i, br, listes ; une formule de dés en .des.
// Le reste est aplati en texte.
const PERMIS = new Set(['P', 'EM', 'STRONG', 'B', 'I', 'BR', 'UL', 'OL', 'LI']);
const MUETS = new Set(['SCRIPT', 'STYLE', 'TEMPLATE', 'NOSCRIPT', 'IFRAME', 'OBJECT']);
export function htmlSur(html) {
  const copier = n => {
    if (n.nodeType === Node.TEXT_NODE) return document.createTextNode(n.textContent);
    if (n.nodeType !== Node.ELEMENT_NODE || MUETS.has(n.tagName)) return [];
    const enfants = [...n.childNodes].flatMap(copier);
    if (n.tagName === 'SPAN' && n.hasAttribute('data-dicenotation')) return h('span', { class: 'des' }, enfants);
    if (n.tagName === 'P') return h('p', { class: 'bn-stat__trait' }, enfants);
    if (PERMIS.has(n.tagName)) return h(n.tagName.toLowerCase(), {}, enfants);
    return enfants;
  };
  return [...new DOMParser().parseFromString(String(html || ''), 'text/html').body.childNodes].flatMap(copier);
}

// ───── Jets à lancer ─────

// Un bouton de jet (composant DD, variante bn-dd--jet) : le dé, puis le bonus ou la formule ; un clic lance en 3D.
// legende : ce qui se lance (« Morsure : jet d'attaque »), au-dessus du résultat et dans l'historique du widget Dés.
// jet : « attaque » ou « degats » (avec son libellé), pour lancer l'attaque entière d'un clic sur son nom (attaqueEntiere).
// Légende, rôle et libellé sont lus au clic : typerDegats() peut les compléter après coup.
function boutonJet(texte, formule, legende, { jet = null, libelle = null } = {}) {
  return h('button', {
    type: 'button', class: 'bn-badge bn-dd bn-dd--jet',
    title: `${legende} : lancer ${formuleDe(formule)}` + (estD20(formuleDe(formule)) ? ' (clic droit : avec avantage ou désavantage)' : ''),
    'data-jet': jet, 'data-formule': formuleDe(formule), 'data-legende': legende, 'data-libelle': libelle,
    onclick: e => {
      e.stopPropagation();
      const d = e.currentTarget.dataset;
      lancerVisible(d.formule, { legende: d.legende, couleur: 'ultra', depuis: e.currentTarget, type: d.jet === 'degats' ? typeDegats(d.libelle) : null });
    },
    oncontextmenu: e => {
      const d = e.currentTarget.dataset;
      if (!estD20(d.formule)) return;   // dégâts : pas d'avantage
      menuAvantage(e, (avantage, ancre) => lancerVisible(d.formule, { legende: `${d.legende} (${AVANTAGES[avantage].libelle})`, couleur: 'ultra', depuis: ancre, avantage }));
    },
  }, icone('d20'), texte);
}
// Clic droit sur un jet d'un d20 (attaque, sauvegarde, test, initiative, nom d'une attaque) : avec avantage ou désavantage
// (demande du MJ, 2026-10-20). lancerAvec(avantage, ancre) : 'avantage' ou 'desavantage', et l'élément cliqué, d'où partent
// les dés (l'évènement est fini quand le menu répond).
const estD20 = formule => /^1d20([+-]\d+)?$/.test(String(formule || ''));
function menuAvantage(e, lancerAvec) {
  e.preventDefault();
  e.stopPropagation();
  const ancre = e.currentTarget;
  ouvrirMenu(ancre, [
    ['Avec avantage', 'Deux d20, le meilleur', () => lancerAvec('avantage', ancre)],
    ['Avec désavantage', 'Deux d20, le moins bon', () => lancerAvec('desavantage', ancre)],
  ], 'Lancer avec avantage ou désavantage');
}
// « Dégâts perforants » -> « perforants » ; « Dégâts » (type inconnu) -> null.
const typeDegats = libelle => String(libelle || '').replace(/^Dégâts ?/, '') || null;
const boutonAttaque = (bonus, nom) => boutonJet(bonus, formuleD20(Number(bonus.replace('−', '-'))), `${nom} : jet d'attaque`, { jet: 'attaque', libelle: 'Jet d\'attaque' });

const premiereMajuscule = t => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase();
// Des dés de dégâts, entre parenthèses ou non (« (1d6 + 2) Piercing damage », « 1d4 + 2 plus PB Piercing damage ») : un
// bouton. « plus PB » (« plus your Proficiency Bonus » : le bonus de maîtrise, celui du maître pour un compagnon) entre
// dans le bouton, « 1d4+2+PB », et dans le jet (ctx.pb). m : [, dés, plus PB, « Type damage », type].
const PLUS_PB = String.raw`(\s+plus\s+(?:your\s+)?(?:PB|Proficiency Bonus))?`;
const DES_DEGATS = String.raw`(\d+d\d+(?:\s*[+−-]\s*\d+)?)`;
const SUITE_DEGATS = String.raw`(\s+([A-Za-z]+)\s+damage)?`;
function boutonDegats(m, nom, ctx) {
  const des = m[1].replace(/\s+/g, ''), plusPb = !!m[2], pb = ctx?.pb;
  const formule = plusPb && Number.isInteger(pb) ? `${des}${pb < 0 ? '' : '+'}${pb}` : des;
  const type = m[4] ? DEGATS[premiereMajuscule(m[4])] : null;
  const texte = des + (plusPb ? '+PB' : '');
  const b = boutonJet(texte, formule, m[3] ? `${nom} : dégâts` : `${nom} : ${texte}`, m[3] ? { jet: 'degats', libelle: `Dégâts${type ? ` ${type}` : ''}` } : {});
  if (plusPb) b.title += Number.isInteger(pb) ? ` (PB ${signe(pb)})` : ' (PB inconnu : pas compté)';
  return b;
}
// Dans le texte d'une capacité : « +4 to hit », « Attack Roll: +4 », des dés de dégâts, « DC 13 ». Le jet d'attaque des
// fiches 2024 (« Melee Attack Roll: +4 ») suit souvent un élément en italique : traité à part, en tête du texte qui le
// suit (jouerTexte). Entre deux règles, la plus tôt dans le texte l'emporte (« (1d6 + 2) » : celle des parenthèses).
const REGLES = [
  { re: /([+−-]\d+)(?= to hit)/, fait: (m, nom) => [boutonAttaque(m[1], nom)] },
  { re: /(Attack(?: Roll)?:\s*)([+−-]\d+)/, fait: (m, nom) => [m[1], boutonAttaque(m[2], nom)] },
  { re: new RegExp(String.raw`\(` + DES_DEGATS + String.raw`\)` + PLUS_PB + SUITE_DEGATS, 'i'), fait: (m, nom, sv, ctx) => ['(', boutonDegats(m, nom, ctx), ')', m[3] || ''] },
  { re: new RegExp(String.raw`\b` + DES_DEGATS + PLUS_PB + SUITE_DEGATS, 'i'), fait: (m, nom, sv, ctx) => [boutonDegats(m, nom, ctx), m[3] || ''] },
  { re: /DC (\d+)/, fait: (m, nom, sauvegarde) => [pastilleDD(m[1], sauvegarde ? `Jet de sauvegarde ${deNom(sauvegarde)}` : `DD de ${nom}`)] },
];

// avant : le texte du paragraphe qui précède ce nœud (« Melee Attack Roll: » en italique, même dans un autre élément).
// ctx : { pb } (le bonus de maîtrise des « plus PB »).
function jouerTexte(noeud, nom, sauvegarde, avant = '', ctx = {}) {
  let reste = noeud.textContent;
  const sortie = [];
  const attaque = /attack(?: roll)?:\s*$/i.test(avant) && /^(\s*)([+−-]\d+)/.exec(reste);
  if (attaque) {
    sortie.push(attaque[1], boutonAttaque(attaque[2], nom));
    reste = reste.slice(attaque[0].length);
  }
  while (reste) {
    let mieux = null;
    for (const r of REGLES) { const m = r.re.exec(reste); if (m && (!mieux || m.index < mieux.m.index)) mieux = { m, r }; }
    if (!mieux) { sortie.push(reste); break; }
    sortie.push(reste.slice(0, mieux.m.index), ...mieux.r.fait(mieux.m, nom, sauvegarde, ctx));
    reste = reste.slice(mieux.m.index + mieux.m[0].length);
  }
  if (sortie.length === 1 && sortie[0] === noeud.textContent) return;
  noeud.replaceWith(...sortie.filter(x => x !== ''));
}

// Le type d'un dé de dégâts écrit hors du texte de sa formule (« (1d8 + 3) » dans un élément, « Piercing damage » dans le
// suivant, ou le type dans un lien) : lu dans les mots qui suivent le bouton, jusqu'au jet suivant. Un nom de type de
// dégâts en tête (« Piercing », « fire »), ou « damage » (type inconnu : « Dégâts »).
const TYPE_QUI_SUIT = new RegExp(`^[)\\s]*(?:(${Object.keys(DEGATS).join('|')})\\b|(?:[A-Za-z]+\\s+)?damage\\b)`, 'i');
function typerDegats(p, nom) {
  const suite = [];   // les boutons de jet et les textes du paragraphe, dans l'ordre
  const parcours = document.createTreeWalker(p, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  while (parcours.nextNode()) {
    const n = parcours.currentNode;
    if (n.nodeType === Node.ELEMENT_NODE) { if (n.matches('button[data-formule]')) suite.push(n); continue; }
    if (!n.parentElement?.closest('button')) suite.push(n.textContent);
  }
  suite.forEach((b, i) => {
    if (typeof b === 'string' || b.dataset.jet || !/d/.test(b.dataset.formule)) return;
    let apres = '';
    for (let j = i + 1; j < suite.length && typeof suite[j] === 'string' && apres.length < 80; j++) apres += suite[j];
    const m = TYPE_QUI_SUIT.exec(apres);
    if (!m) return;
    const type = m[1] ? DEGATS[premiereMajuscule(m[1])] : null;
    Object.assign(b.dataset, { jet: 'degats', libelle: `Dégâts${type ? ` ${type}` : ''}`, legende: `${nom} : dégâts` });
    b.title = `${nom} : dégâts${type ? ` ${type}` : ''} : lancer ${b.dataset.formule}`;
  });
}

// L'attaque entière d'une capacité, d'un clic sur son nom : le jet d'attaque et les dégâts du « Hit: » (ceux joints par
// « plus » ; pas ceux d'une alternative « or », ni ceux d'une sauvegarde plus loin), en grand côte à côte ; plusieurs
// types de dégâts s'additionnent (« 10 perforants + 14 nécrotiques »). Sur un 20 naturel, les dés de dégâts sont doublés.
function attaqueEntiere(p, nom) {
  const attaque = p.querySelector('[data-jet="attaque"]');
  if (!attaque) return;
  const degats = [];
  let apresHit = false, fini = false, entre = '', cumul = '';
  const parcours = document.createTreeWalker(p, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  while (!fini && parcours.nextNode()) {
    const n = parcours.currentNode;
    if (n.nodeType === Node.ELEMENT_NODE) {
      if (apresHit && n.dataset?.jet === 'degats') {
        if (degats.length && !/\bplus\b/i.test(entre)) fini = true; else degats.push(n);
        entre = '';
      }
      continue;
    }
    if (n.parentElement?.closest('[data-jet]')) continue;   // le texte d'un bouton
    const t = n.textContent;
    if (!apresHit) {   // « <em>Hit:</em> » comme « <em>Hit</em>: »
      cumul += t;
      const i = cumul.search(/Hit:/i);
      if (i >= 0) { apresHit = true; entre = cumul.slice(i + 4); fini = /\.(\s|$)/.test(entre); }
      continue;
    }
    if (/\.(\s|$)/.test(t)) fini = true;   // fin de la phrase du « Hit: »
    entre += t;
  }
  const nomEl = p.querySelector('strong, b');
  if (!nomEl) return;
  // avantage, ancre : depuis le clic droit (menuAvantage).
  const lancerTout = (e, avantage = null, ancre = null) => {
    e.stopPropagation();
    const jetAttaque = jeterD20(attaque.dataset.formule, avantage);
    if (!jetAttaque) return;
    const critique = critiqueDe(jetAttaque.faces) === 'reussite';
    const entrees = [{ libelle: 'Attaque', jet: jetAttaque, formule: jetAttaque.formule }];
    const jets = degats.map(d => {
      const formule = critique ? d.dataset.formule.replace(/(\d+)d(\d+)/g, (_, n, f) => `${2 * n}d${f}`) : d.dataset.formule;
      return { type: typeDegats(d.dataset.libelle), formule, jet: lancer(formule) };
    }).filter(x => x.jet);
    const doubles = critique ? ' · dés doublés' : '';
    // Sous le total des dégâts, leur type (« perforants ») ; plusieurs types : chacun avec son total.
    if (jets.length === 1) entrees.push({ libelle: 'Dégâts', type: jets[0].type, jet: jets[0].jet, formule: jets[0].formule, detail: `${jets[0].formule} : ${jets[0].jet.detail}${doubles}` });
    else if (jets.length) {
      entrees.push({ libelle: 'Dégâts', formule: jets.map(x => x.formule).join('+'),
        type: jets.map(x => [x.jet.total, x.type].filter(Boolean).join(' ')).join(' + '),
        detail: jets.map(x => `${x.formule} : ${x.jet.detail}`).join(' · ') + doubles,
        jet: { total: jets.reduce((s, x) => s + x.jet.total, 0), faces: jets.flatMap(x => x.jet.faces || []), formule: jets.map(x => x.formule).join('+') } });
    }
    const av = AVANTAGES[avantage] ? ` (${AVANTAGES[avantage].libelle})` : '';
    montrerJets(entrees, { legende: (entrees.length > 1 ? nom : `${nom} : jet d'attaque`) + av, couleur: 'ultra', depuis: ancre || e.currentTarget, colonnes: true });
  };
  const titre = degats.length ? `${nom} : attaque et dégâts d'un clic (clic droit : avec avantage ou désavantage)` : `${nom} : jet d'attaque d'un clic (clic droit : avec avantage ou désavantage)`;
  Object.assign(nomEl, { tabIndex: 0, title: titre, onclick: e => lancerTout(e), onkeydown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); lancerTout(e); } },
    oncontextmenu: e => menuAvantage(e, (avantage, ancre) => lancerTout(e, avantage, ancre)) });
  nomEl.setAttribute('role', 'button');
  nomEl.classList.add('cm-stat__attaque');
}

// Les paragraphes d'une section (traits, actions…) : leurs jets deviennent des boutons, leurs DD des pastilles. Le nom de la
// capacité (son premier gras) sert de légende, et lance l'attaque entière quand elle en est une ; une sauvegarde nommée dans
// le paragraphe titre la pastille du DD.
function jouable(noeuds, ctx = {}) {   // ctx : { pb }, voir jouerTexte
  for (const p of noeuds) {
    if (!(p instanceof Element)) continue;
    const nom = (p.querySelector('strong, b')?.textContent || '').replace(/[.:]\s*$/, '').trim() || 'Jet';
    const sauvegarde = CARAC_EN[/(Strength|Dexterity|Constitution|Intelligence|Wisdom|Charisma) Saving Throw/.exec(p.textContent)?.[1]] || null;
    // Un élément sans intérêt (dés de D&D Beyond dans un span) laisse des textes voisins séparés : réunis d'abord.
    p.normalize();
    const textes = [];
    const parcours = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
    while (parcours.nextNode()) textes.push(parcours.currentNode);
    let avant = '';
    for (const t of textes) { const texte = t.textContent; jouerTexte(t, nom, sauvegarde, avant, ctx); avant += texte; }
    typerDegats(p, nom);
    attaqueEntiere(p, nom);
  }
  return noeuds;
}

// Libellés du dictionnaire de D&D Beyond (cfg : commande « config » de l'extension).
const nomDe = (cfg, liste, id) => (cfg?.[liste] || []).find(x => x.id === id)?.nom;
function alignement(nom) {
  if (!nom) return '';
  const generalement = nom.startsWith('Typically ');
  const base = nom.replace(/^Typically /, '');
  return (generalement ? 'généralement ' : '') + (ALIGNEMENTS[base] || base);
}
const traduireCompetences = t => String(t || '').replace(/[A-Z][a-z]+(?: of [A-Z][a-z]+| [A-Z][a-z]+)?/g, m => COMPETENCES[m] || m);

// Ligne « Mort-vivant de taille M, chaotique mauvais ».
export function typeDe(m, cfg) {
  const type = nomDe(cfg, 'types', m.typeId), taille = nomDe(cfg, 'tailles', m.sizeId);
  return [[TYPES[type] || type, taille ? `de taille ${TAILLES[taille] || taille}` : ''].filter(Boolean).join(' '), alignement(nomDe(cfg, 'alignements', m.alignmentId))].filter(Boolean).join(', ');
}

// « Mort-vivant M » : type et taille en court (lignes de la recherche de monstres).
export function typeCourt(typeId, sizeId, cfg) {
  const type = nomDe(cfg, 'types', typeId), taille = nomDe(cfg, 'tailles', sizeId);
  return [TYPES[type] || type, TAILLES[taille] || taille].filter(Boolean).join(' ');
}

export function puissanceDe(m, cfg) {
  return (cfg?.puissances || []).find(x => x.id === m.challengeRatingId) || null;
}
const fp = v => (v === 0.125 ? '1/8' : v === 0.25 ? '1/4' : v === 0.5 ? '1/2' : String(v));
export const libellePuissance = p => (p ? `FP ${fp(p.valeur)}` : '');

// image : l'illustration du monstre, à droite du nom et des premières valeurs.
export function blocStats(m, cfg, { image = null, pb = null } = {}) {   // pb : le bonus de maîtrise des « plus PB » (sinon celui du FP)
  const p = puissanceDe(m, cfg);
  const carac = Object.fromEntries((m.stats || []).map(s => [s.statId, s.value]));
  const cleCarac = id => (cfg?.carac || []).find(x => x.id === id)?.cle;
  const ligne = (dt, ...dd) => {
    const contenu = dd.flat().filter(x => x !== null && x !== undefined && x !== '');
    return contenu.length ? h('div', {}, h('dt', {}, dt), h('dd', {}, contenu)) : null;
  };
  const joindre = (morceaux, sep = ', ') => morceaux.flatMap((x, i) => (i ? [sep, x] : [x]));

  const vitesses = (m.movements || []).map(x => {
    const n = nomDe(cfg, 'mouvements', x.movementId);
    const lib = MOUVEMENTS[n] ?? n ?? '';
    return h('span', {}, lib ? `${lib} ` : '', distance(x.speed), x.notes ? ` ${x.notes}` : '');
  });
  const sauvegardes = (m.savingThrows || []).map(s => {
    const v = carac[s.statId];
    if (v === undefined || !p) return null;
    const cle = cleCarac(s.statId), bonus = modificateur(v) + p.maitrise + (s.bonusModifier || 0);
    return boutonJet(`${CARAC[cle] || s.statId} ${signe(bonus)}`, formuleD20(bonus), `Jet de sauvegarde ${deNom(CARAC_LONG[cle] || cle)}`);
  }).filter(Boolean);
  const initiative = m.initiativeBonus ?? (carac[2] !== undefined ? modificateur(carac[2]) : 0);   // 2014 : la Dextérité
  const ajustements = type => (m.damageAdjustments || []).map(id => (cfg?.ajustements || []).find(a => a.id === id)).filter(a => a?.type === type).map(a => DEGATS[a.nom] || a.nom);
  const immunitesEtats = (m.conditionImmunities || []).map(id => nomDe(cfg, 'etats', id)).filter(Boolean).map(n => ETATS[n] || n);
  const sens = [
    ...(m.senses || []).map(s => { const n = nomDe(cfg, 'sens', s.senseId); return `${SENS[n] || n || ''} ${s.notes || ''}`.trim(); }),
    m.passivePerception != null ? `Perception passive ${m.passivePerception}` : null,
  ].filter(Boolean);
  const langues = [m.languageDescription, m.languageNote].map(x => String(x || '').trim()).filter((x, i, l) => x && l.indexOf(x) === i).join(' ; ');

  // Une caractéristique : un clic (ou Entrée) fait son test, d20 + modificateur, en violet.
  const testCarac = s => {
    const cle = cleCarac(s.statId), mod = modificateur(s.value), formule = formuleD20(mod), legende = `Test ${deNom(CARAC_LONG[cle] || cle)}`;
    const lancerTest = e => { e.stopPropagation(); lancerVisible(formule, { legende, couleur: 'ultra', depuis: e.currentTarget }); };
    return h('div', { class: 'cm-stat__carac-jet', role: 'button', tabindex: '0', title: `${legende} : lancer ${formule} (clic droit : avec avantage ou désavantage)`,
      onclick: lancerTest, onkeydown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); lancerTest(e); } },
      oncontextmenu: e => menuAvantage(e, (avantage, ancre) => lancerVisible(formule, { legende: `${legende} (${AVANTAGES[avantage].libelle})`, couleur: 'ultra', depuis: ancre, avantage })) },
      h('dt', {}, CARAC[cle] || s.statId),
      h('dd', {}, String(s.value), h('span', {}, icone('d20', 'bn-icone--s'), signe(mod))));
  };
  // En tête : le nom, le type, les premières valeurs et les caractéristiques (Force à Charisme, sur deux lignes) à gauche,
  // l'image du monstre à droite, sur toute leur hauteur.
  return h('article', { class: 'bn-stat cm-stat' },
    h('div', { class: 'cm-stat__haut' + (image ? ' avec-image' : '') },
      h('div', { class: 'cm-stat__tete' },
        h('header', {},
          h('h3', { class: 'bn-stat__nom' }, m.name),
          h('p', { class: 'bn-stat__type' }, typeDe(m, cfg))),
        h('hr', { class: 'bn-filet bn-filet--sang' }),
        h('dl', { class: 'bn-stat__lignes' },
          ligne('Classe d\'armure', String(m.armorClass ?? '?'), m.armorClassDescription ? ` ${m.armorClassDescription.trim()}` : ''),
          ligne('Points de vie', String(m.averageHitPoints ?? '?'), m.hitPointDice?.diceString ? [' (', h('span', { class: 'des' }, m.hitPointDice.diceString), ')'] : ''),
          ligne('Vitesse', joindre(vitesses)),
          ligne('Initiative', boutonJet(signe(initiative), formuleD20(initiative), 'Initiative'))),
        h('hr', { class: 'bn-filet bn-filet--sang' }),
        h('dl', { class: 'bn-stat__carac cm-stat__carac' }, (m.stats || []).map(testCarac))),
      image ? h('div', { class: 'cm-stat__image' }, h('img', { src: image, alt: '', referrerpolicy: 'no-referrer' })) : null),
    h('hr', { class: 'bn-filet bn-filet--sang' }),
    h('dl', { class: 'bn-stat__lignes' },
      ligne('Jets de sauvegarde', joindre(sauvegardes, ' ')),
      ligne('Compétences', traduireCompetences(m.skillsHtml && new DOMParser().parseFromString(m.skillsHtml, 'text/html').body.textContent)),
      ligne('Vulnérabilités', ajustements(3).join(', ')),
      ligne('Résistances', ajustements(1).join(', ')),
      ligne('Immunités', [...ajustements(2), ...immunitesEtats].join(', ')),
      ligne('Sens', sens.join(', ')),
      ligne('Langues', langues),
      ligne('Puissance', p ? `${libellePuissance(p)} (${p.px.toLocaleString('fr-FR')} PX ; bonus de maîtrise ${signe(p.maitrise)})` : '')),
    SECTIONS.filter(([cle]) => String(m[cle] || '').trim()).map(([cle, titre]) => [
      cle === 'specialTraitsDescription' ? h('hr', { class: 'bn-filet bn-filet--sang' }) : h('h4', { class: 'bn-stat__section' }, titre),
      jouable(htmlSur(m[cle]), { pb: Number.isInteger(pb) ? pb : p?.maitrise ?? null }),
    ]),
    m.url ? h('p', { class: 'ui-s cm-sourdine cm-stat__source' }, h('a', { class: 'bn-lien', href: m.url, target: '_blank', rel: 'noopener' }, 'Fiche sur D&D Beyond'), m.isLegacy ? ' · version 2014' : '') : null);
}
