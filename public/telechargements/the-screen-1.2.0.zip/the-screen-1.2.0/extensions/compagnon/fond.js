// Extension « Fiche du compagnon » : tâche de fond. Un clic sur l'icône ouvre la fenêtre de la fiche (fenetre.html), ou
// la ramène devant si elle est déjà ouverte. Sur une page de personnage de D&D Beyond (dndbeyond.com/characters/<id>),
// la fenêtre prend ce personnage.

const LARGEUR = 560, HAUTEUR = 860;

chrome.action.onClicked.addListener(async onglet => {
  const fiche = /dndbeyond\.com\/characters\/(\d+)/.exec(onglet?.url || '')?.[1] || null;
  const { fenetre } = await chrome.storage.session.get('fenetre');
  if (fenetre) {
    try {
      await chrome.windows.update(fenetre, { focused: true });
      if (fiche) chrome.runtime.sendMessage({ type: 'fiche', fiche }).catch(() => {});
      return;
    } catch { /* fenêtre fermée entre-temps */ }
  }
  const w = await chrome.windows.create({ url: chrome.runtime.getURL('fenetre.html') + (fiche ? `?fiche=${fiche}` : ''), type: 'popup', width: LARGEUR, height: HAUTEUR });
  await chrome.storage.session.set({ fenetre: w.id });
});

chrome.windows.onRemoved.addListener(async id => {
  const { fenetre } = await chrome.storage.session.get('fenetre');
  if (fenetre === id) await chrome.storage.session.remove('fenetre');
});
