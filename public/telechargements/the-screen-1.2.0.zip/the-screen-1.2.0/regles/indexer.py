"""Index des règles D&D 2024 : découpe les PDF du SRD 5.2.1 (anglais et français) en passages, puis les vectorise.

Usage (depuis regles/) :  uv run indexer.py            reconstruit l'index si un PDF ou le modèle a changé
                          uv run indexer.py --force    le reconstruit dans tous les cas

Les PDF sont lus dans sources/ (hors dépôt). L'index va dans regles/index/ (hors dépôt, refait sur chaque poste) :
  passages.json   un passage par entrée : id, langue, source, page, chemin des titres, texte
  sections.json   le texte entier de chaque section (une section = ce qui suit un titre jusqu'au titre suivant)
  vecteurs.npy    un vecteur normalisé par passage, dans l'ordre de passages.json
  manifeste.json  PDF lus (taille, date) et modèle d'embeddings : sert à savoir s'il faut reconstruire

Découpe : les titres se reconnaissent à leur police (GillSans SemiBold ou Bold, 10,5 pt et plus) ; leur taille donne leur
niveau. Chaque passage est préfixé du chemin de ses titres (« Rules Glossary > Grappled [Condition] ») : la recherche
trouve ainsi une règle par son nom même quand le texte ne le répète pas. Une section longue est coupée en passages
d'environ TAILLE caractères qui se chevauchent de CHEVAUCHEMENT, sur une fin de phrase ou un espace.
"""

import json
import os
import re
import sys
import time
from pathlib import Path

os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")  # cache du modèle d'embeddings sans liens symboliques (Windows)

import numpy as np
import pymupdf

RACINE = Path(__file__).resolve().parent
SOURCES = RACINE.parent / "sources"
INDEX = RACINE / "index"
MODELES = RACINE / "modeles"  # cache du modèle d'embeddings (hors dépôt)
MODELE_EMBEDDINGS = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"  # multilingue : question en français, passages en deux langues

# Livres indexés : fichier dans sources/, langue, nom court affiché avec la page.
LIVRES = [
    {"fichier": "FR_SRD_CC_v5.2.1.pdf", "langue": "fr", "source": "DRS 5.2.1"},
    {"fichier": "SRD_CC_v5.2.1.pdf", "langue": "en", "source": "SRD 5.2.1"},
]
TAILLE = 1200
CHEVAUCHEMENT = 200
TITRE_MIN = 10.5   # taille de police à partir de laquelle une ligne en GillSans gras est un titre
PIED_DE_PAGE = 735  # ordonnée au-delà de laquelle tout est pied de page (titre du document, numéro de page)
PROFIL = 14.8      # taille du nom d'un profil de créature (monstre, invocation)


def est_titre(ligne: dict) -> bool:
    spans = [s for s in ligne["spans"] if s["text"].strip()]
    return bool(spans) and all(
        "GillSans" in s["font"] and ("SemiBold" in s["font"] or "Bold" in s["font"]) and s["size"] >= TITRE_MIN
        for s in spans)


def lignes_du_livre(chemin: Path):
    """Rend (page, y, taille, texte, titre?) pour chaque ligne du PDF, dans l'ordre de lecture des blocs."""
    with pymupdf.open(chemin) as doc:
        for numero, page in enumerate(doc, start=1):
            for bloc in page.get_text("dict")["blocks"]:
                for ligne in bloc.get("lines", []):
                    texte = "".join(s["text"] for s in ligne["spans"]).replace("­", "")
                    if not texte.strip() or ligne["bbox"][1] > PIED_DE_PAGE:
                        continue
                    taille = max(s["size"] for s in ligne["spans"] if s["text"].strip())
                    yield numero, round(ligne["bbox"][3]), round(taille, 1), texte, est_titre(ligne)


def coller(texte: str, ligne: str, meme_rangee: bool) -> str:
    """Ajoute une ligne au texte d'une section : cellules d'une même rangée de tableau séparées par « | », mots coupés
    en fin de ligne recollés, nouveau paragraphe sur une tabulation."""
    if not texte:
        return ligne.strip()
    if meme_rangee:
        return texte + " | " + ligne.strip()
    if ligne.startswith("\t") or " | " in texte.rsplit("\n", 1)[-1]:  # nouveau paragraphe, ou rangée suivante d'un tableau
        return texte + "\n" + ligne.strip()
    if re.search(r"[a-zà-ÿ]-$", texte) and re.match(r"[a-zà-ÿ]", ligne):
        return texte[:-1] + ligne.strip()
    return texte + " " + ligne.strip()


def sections_du_livre(livre: dict) -> list[dict]:
    pile = []        # titres ouverts : [(taille, titre)]
    sections = []
    courante = None
    dernier = None   # (page, y) de la ligne précédente

    def ouvrir(page):
        nonlocal courante
        courante = {"chemin": [t for _, t in pile], "page": page, "pages": [(0, page)], "texte": ""}
        sections.append(courante)

    for page, y, taille, texte, titre in lignes_du_livre(SOURCES / livre["fichier"]):
        if titre:
            texte = " ".join(texte.split())
            # Un titre sur deux lignes : la seconde complète le titre ouvert juste avant, s'il n'a encore rien reçu.
            if pile and pile[-1][0] == taille and courante and not courante["texte"] and courante["chemin"][-1:] == [pile[-1][1]]:
                pile[-1] = (taille, pile[-1][1] + " " + texte)
                courante["chemin"][-1] = pile[-1][1]
            else:
                # Le nom d'un profil de créature (14,8 pt) n'a jamais de sous-titres : le titre suivant le ferme, même plus
                # petit (le sort qui suit un profil d'invocation n'en est pas une partie).
                if pile and pile[-1][0] == PROFIL:
                    pile.pop()
                while pile and pile[-1][0] < taille + 1:  # à 1 pt près, même niveau (certains titres sont rétrécis pour tenir)
                    pile.pop()
                pile.append((taille, texte))
                ouvrir(page)
            dernier = None
            continue
        if courante is None:
            ouvrir(page)
        if courante["pages"][-1][1] != page:
            courante["pages"].append((len(courante["texte"]), page))
        meme_rangee = dernier is not None and dernier == (page, y)
        courante["texte"] = coller(courante["texte"], texte, meme_rangee)
        dernier = (page, y)
    return [s for s in sections if len(s["texte"]) >= 40]


def page_a(section: dict, position: int) -> int:
    page = section["page"]
    for debut, p in section["pages"]:
        if debut <= position:
            page = p
    return page


def couper(texte: str) -> list[tuple[int, str]]:
    """Coupe un texte en morceaux de TAILLE caractères au plus, qui se chevauchent ; rend (position, morceau)."""
    morceaux, debut = [], 0
    while debut < len(texte):
        fin = min(debut + TAILLE, len(texte))
        if fin < len(texte):
            zone = texte[debut + TAILLE // 2:fin]
            coupe = max(zone.rfind(". "), zone.rfind("\n"))
            if coupe == -1:
                coupe = zone.rfind(" ")
            if coupe != -1:
                fin = debut + TAILLE // 2 + coupe + 1
        morceaux.append((debut, texte[debut:fin].strip()))
        if fin >= len(texte):
            break
        suivant = texte.find(" ", fin - CHEVAUCHEMENT)
        debut = suivant + 1 if 0 <= suivant < fin else fin
    return morceaux


def manifeste_attendu() -> dict:
    return {
        "modele": MODELE_EMBEDDINGS, "taille": TAILLE, "chevauchement": CHEVAUCHEMENT, "version": 1,
        "livres": [{**l, "octets": (SOURCES / l["fichier"]).stat().st_size,
                    "modifie": int((SOURCES / l["fichier"]).stat().st_mtime)} for l in LIVRES if (SOURCES / l["fichier"]).exists()],
    }


def index_a_jour() -> bool:
    try:
        return json.loads((INDEX / "manifeste.json").read_text(encoding="utf-8")) == manifeste_attendu()
    except (OSError, ValueError):
        return False


def construire() -> None:
    from fastembed import TextEmbedding

    manifeste = manifeste_attendu()
    if not manifeste["livres"]:
        sys.exit(f"Aucun PDF des règles dans {SOURCES} (attendus : {', '.join(l['fichier'] for l in LIVRES)}).")
    debut = time.perf_counter()
    passages, sections = [], []
    for livre in LIVRES:
        if not (SOURCES / livre["fichier"]).exists():
            print(f"  absent, ignoré : {livre['fichier']}")
            continue
        lues = sections_du_livre(livre)
        for section in lues:
            sid = f"{livre['langue']}-{len(sections)}"
            sections.append({"id": sid, "langue": livre["langue"], "source": livre["source"], "page": section["page"],
                             "chemin": section["chemin"], "texte": section["texte"]})
            for position, morceau in couper(section["texte"]):
                passages.append({"id": f"{sid}-{position}", "section": sid, "langue": livre["langue"], "source": livre["source"],
                                 "page": page_a(section, position), "chemin": section["chemin"], "texte": morceau})
        print(f"  {livre['fichier']} : {len(lues)} sections")
    print(f"{len(passages)} passages ; vectorisation ({MODELE_EMBEDDINGS}, téléchargé au premier lancement)…")
    modele = TextEmbedding(MODELE_EMBEDDINGS, cache_dir=str(MODELES))
    textes = [" > ".join(p["chemin"]) + "\n" + p["texte"] for p in passages]
    vecteurs = np.array(list(modele.embed(textes, batch_size=64)), dtype=np.float32)
    vecteurs /= np.linalg.norm(vecteurs, axis=1, keepdims=True)

    INDEX.mkdir(exist_ok=True)
    (INDEX / "passages.json").write_text(json.dumps(passages, ensure_ascii=False), encoding="utf-8")
    (INDEX / "sections.json").write_text(json.dumps(sections, ensure_ascii=False), encoding="utf-8")
    np.save(INDEX / "vecteurs.npy", vecteurs)
    (INDEX / "manifeste.json").write_text(json.dumps(manifeste, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Index écrit dans {INDEX} ({len(passages)} passages, {time.perf_counter() - debut:.0f} s).")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if "--force" in sys.argv or not index_a_jour():
        construire()
    else:
        print("Index à jour.")
