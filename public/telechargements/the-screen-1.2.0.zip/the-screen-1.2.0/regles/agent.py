"""Agent de règles (Strands) : répond aux questions du MJ d'après le SRD 5.2.1, en cherchant dans l'index.

Fournisseur et modèle : clé « regles » de poste.json (propre au poste, voir poste.exemple.json) :
  fournisseur   « ollama » (modèle local, par défaut) ou « anthropic » (clé dans ANTHROPIC_API_KEY ou regles/.env)
  modele        ollama : « qwen3:4b-instruct-2507-q4_K_M » par défaut ; anthropic : « claude-haiku-5-5 » par défaut
  hote_ollama   adresse du serveur Ollama (http://127.0.0.1:11435 par défaut : l'instance propre au service, voir plus bas)
  ollama_dedie  vrai par défaut : si personne ne répond à hote_ollama, le service lance sa propre instance d'Ollama à
                cette adresse, avec le GPU intégré (Vulkan), et l'arrête en s'arrêtant. Faux : utiliser l'Ollama du poste
                tel qu'il est réglé (mettre alors hote_ollama à http://localhost:11434).
  gpu           « integre » (par défaut) : l'instance propre active le GPU intégré (Vulkan) ; « dedie » : elle laisse
                Ollama prendre la carte graphique (CUDA pour une NVIDIA) et ignorer le GPU intégré.
  port          port du service de règles (8736 par défaut)

Le GPU intégré (Intel Graphics des processeurs Core Ultra) lit le prompt ~20 fois plus vite que le processeur seul
(560 contre 26 tokens/s mesurés le 2026-10-15, Qwen3 4B) : c'est l'essentiel du temps de réponse, les passages faisant
quelque 2 000 tokens. Ollama l'ignore d'office (OLLAMA_VULKAN et OLLAMA_IGPU_ENABLE) : l'instance propre l'active sans
toucher aux réglages d'Ollama du poste. Un poste avec une carte graphique (le PC de bureau : RTX 5070 et Radeon intégrée)
règle « gpu » à « dedie », sans quoi Vulkan pourrait charger le modèle sur le GPU intégré.
"""

import json
import os
import re
from pathlib import Path

from strands import Agent, tool
from strands.agent.conversation_manager import SlidingWindowConversationManager

RACINE = Path(__file__).resolve().parent
DEFAUTS = {
    "fournisseur": "ollama",
    "modele": None,
    "hote_ollama": "http://127.0.0.1:11435",
    "ollama_dedie": True,
    "gpu": "integre",
    "port": 8736,
    "contexte": 8192,   # fenêtre de contexte demandée à Ollama (le défaut d'Ollama est trop court pour les passages)
}
SECTION_ENTIERE = 2500   # caractères : en deçà, chercher_regles rend la section entière plutôt que le passage
MODELES_PAR_DEFAUT = {"ollama": "qwen3:4b-instruct-2507-q4_K_M", "anthropic": "claude-haiku-5-5"}

CONSIGNES = """Tu es l'arbitre des règles de Donjons & Dragons 2024 (« D&D 5.5 », Document de référence du système 5.2.1)
auprès d'un MJ francophone, pendant la partie : il lui faut une réponse juste, vite.

- Chaque question arrive avec des passages des règles trouvés d'office. Ne réponds que d'après des passages, jamais de
  mémoire : les règles de 2024 diffèrent de celles de 2014.
- Si ces passages ne répondent pas à toute la question, cherche avec l'outil chercher_regles, avec les mots de la règle
  (« Lutte », « attaque d'opportunité », « Chute ») plutôt que la question entière, puis en anglais au besoin (langue
  « en » : « Grappled »). Une règle tient souvent en plusieurs entrées (un état, et l'action qui le provoque ou y met
  fin) : une recherche par partie de la question. Un passage coupé se lit en entier avec lire_section.
- Les règles comptent en pieds (1,5 m = 5 pieds) : convertis une distance donnée en mètres avant d'appliquer la règle.
- Réponds en français, en prose, avec les termes officiels de la VF tels qu'écrits dans les passages : d'abord une phrase
  seule sur sa ligne qui tranche la question (oui ou non, la valeur, l'effet), puis, au besoin, un court paragraphe de
  deux à quatre phrases pour les conditions et les exceptions utiles. 80 mots au plus, sans liste, ni intertitre, ni
  introduction, ni conclusion qui répète la réponse.
- Résume la règle toi-même : ne renvoie pas le MJ à un passage, un encadré ou un tableau pour la lire. Les passages
  consultés s'affichent sous ta réponse, inutile de les décrire.
- Cite la source de chaque règle entre crochets dans la phrase qu'elle appuie, telle que donnée avec le passage :
  [DRS p. 187] ou [SRD p. 182]. Jamais de citation seule sur une ligne.
- Si la règle n'est pas dans le SRD (une partie du Manuel des joueurs n'y figure pas), dis-le clairement.
  Si tu interprètes ou complètes ce que disent les passages, dis-le (« Interprétation : … ») ; sinon, n'en ajoute pas.
"""


def lire_config() -> dict:
    config = dict(DEFAUTS)
    fichier = RACINE.parent / "poste.json"
    if fichier.exists():
        # Comme scripts/poste.ps1 : un chemin Windows écrit tel quel (D:\Images) n'est pas du JSON valide.
        texte = re.sub(r'\\(\\|")?', lambda m: m.group(0) if m.group(1) else "\\\\", fichier.read_text(encoding="utf-8-sig"))
        try:
            config.update(json.loads(texte).get("regles") or {})
        except ValueError as e:
            print(f"poste.json illisible, réglages par défaut : {e}")
    config["modele"] = config["modele"] or MODELES_PAR_DEFAUT.get(config["fournisseur"])
    return config


def cle_anthropic() -> str | None:
    if os.environ.get("ANTHROPIC_API_KEY"):
        return os.environ["ANTHROPIC_API_KEY"]
    env = RACINE / ".env"
    if env.exists():
        for ligne in env.read_text(encoding="utf-8").splitlines():
            if ligne.strip().startswith("ANTHROPIC_API_KEY="):
                return ligne.split("=", 1)[1].strip().strip('"')
    return None


def creer_modele(config: dict):
    if config["fournisseur"] == "anthropic":
        from strands.models.anthropic import AnthropicModel

        return AnthropicModel(client_args={"api_key": cle_anthropic()}, model_id=config["modele"], max_tokens=1500,
                              params={"temperature": 0.2})
    from strands.models.ollama import OllamaModel

    return OllamaModel(config["hote_ollama"], model_id=config["modele"], temperature=0.2, max_tokens=700,
                       keep_alive="30m", options={"num_ctx": int(config["contexte"])})


def bloc_passage(p: dict) -> str:
    source = "DRS" if p["langue"] == "fr" else "SRD"
    return f"[{source} p. {p['page']}] {' > '.join(p['chemin'])} (section {p['section']})\n{p['texte']}"


def chercher(index, requete: str, langue: str | None, consultes: list, nombre: int = 4) -> str:
    """Passages trouvés, en texte pour le modèle ; une section courte (entrée du glossaire, sort) vient entière : le
    modèle n'a pas à la relire avec lire_section."""
    passages = index.chercher(requete, langue, nombre=nombre)
    consultes.extend(passages)
    blocs = []
    for p in passages:
        s = index.section(p["section"])
        blocs.append(bloc_passage({**p, "texte": s["texte"]} if s and len(s["texte"]) <= SECTION_ENTIERE else p))
    return "\n\n---\n\n".join(blocs) or "Aucun passage trouvé."


def message_question(index, question: str, precedente: str | None, consultes: list) -> str:
    """La question, avec les passages trouvés d'office : un petit modèle local oublie parfois de chercher avant de
    répondre, et cela lui épargne un aller-retour. Une question de suite (« et s'il est à terre ? ») cherche avec la
    précédente."""
    requete = f"{precedente} {question}" if precedente and len(question) < 80 else question
    return f"Question du MJ : {question}\n\nPassages trouvés d'office :\n\n{chercher(index, requete, 'fr', consultes)}"


def creer_agent(index, config: dict, consultes: list) -> Agent:
    """Un agent par conversation ; `consultes` reçoit les passages que ses outils ont rendus (sources affichées)."""

    @tool
    def chercher_regles(requete: str, langue: str = "fr") -> str:
        """Cherche les passages des règles de D&D 2024 les plus proches d'une requête.

        Args:
            requete: mots de la règle cherchée, par exemple « Agrippé état effets » ou « attaque d'opportunité ».
            langue: « fr » pour le DRS en français (par défaut), « en » pour le SRD anglais.
        """
        return chercher(index, requete, langue if langue in ("fr", "en") else None, consultes)

    @tool
    def lire_section(section: str) -> str:
        """Lit en entier une section des règles dont un passage a été trouvé (texte coupé, tableau, liste).

        Args:
            section: identifiant de la section, donné avec le passage, par exemple « fr-1234 ».
        """
        s = index.section(section)
        if not s:
            return f"Section inconnue : {section}"
        consultes.append({**s, "section": s["id"], "texte": s["texte"][:600]})
        texte = s["texte"] if len(s["texte"]) <= 6000 else s["texte"][:6000] + " […]"
        return bloc_passage({**s, "section": s["id"], "texte": texte})

    return Agent(
        model=creer_modele(config),
        system_prompt=CONSIGNES,
        tools=[chercher_regles, lire_section],
        conversation_manager=SlidingWindowConversationManager(window_size=8),
        callback_handler=None,
    )
