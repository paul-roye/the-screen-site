"""Recherche dans l'index des règles (construit par indexer.py) : hybride, sans LLM.

Deux classements fusionnés par rangs réciproques (RRF) :
  - sémantique : la question est vectorisée par le même modèle que les passages, plus proches voisins au cosinus ;
  - lexical : BM25 sur les mots sans accents, qui trouve un terme exact (« Agrippé », « Opportunity Attack ») que le
    sémantique noie parfois.
Tout tient en mémoire (quelques milliers de passages) : une recherche prend quelques millisecondes après le chargement.
"""

import json
import math
import re
import unicodedata
from collections import Counter

import numpy as np

from indexer import INDEX, MODELES, MODELE_EMBEDDINGS

MOTS_VIDES = set("""
le la les un une des du de d l et ou a au aux en dans sur pour par avec sans ce cet cette ces se sa son ses vous votre vos
il elle ils elles on qui que quoi dont est sont etre ne pas plus peut peuvent si y the of and or to in on for with
by is are be an as at it its this that your you can from if when any not
quand comment quel quelle quels quelles combien passe fait faire what how does do happen
personnage joueur creature character
""".split())


def mots(texte: str) -> list[str]:
    texte = unicodedata.normalize("NFKD", texte.lower())
    texte = "".join(c for c in texte if not unicodedata.combining(c))
    resultat = []
    for m in re.findall(r"[a-z0-9]+", texte):
        if m in MOTS_VIDES or len(m) < 2:
            continue
        if len(m) > 4 and m.endswith("s"):  # pluriel grossier, dans les deux langues
            m = m[:-1]
        resultat.append(m)
    return resultat


class Index:
    def __init__(self):
        from fastembed import TextEmbedding

        self.passages = json.loads((INDEX / "passages.json").read_text(encoding="utf-8"))
        self.sections = {s["id"]: s for s in json.loads((INDEX / "sections.json").read_text(encoding="utf-8"))}
        self.vecteurs = np.load(INDEX / "vecteurs.npy")
        self.modele = TextEmbedding(MODELE_EMBEDDINGS, cache_dir=str(MODELES))
        self.langues = np.array([p["langue"] for p in self.passages])
        # BM25 : le chemin des titres compte comme le texte (un titre est souvent le mot cherché).
        self.docs = [Counter(mots(" ".join(p["chemin"]) + " " + p["texte"])) for p in self.passages]
        self.longueurs = np.array([sum(d.values()) for d in self.docs], dtype=np.float32)
        self.longueur_moyenne = float(self.longueurs.mean())
        self.titres = [set(mots(p["chemin"][-1])) if p["chemin"] else set() for p in self.passages]
        # Rareté d'un mot parmi les titres de section (« personnage » en est plein, « agrippe » non).
        sections_vues = {p["section"]: t for p, t in zip(self.passages, self.titres)}
        dans_titres = Counter(m for t in sections_vues.values() for m in t)
        self.idf_titre = {m: math.log(len(sections_vues) / f) for m, f in dans_titres.items()}
        presence = Counter(m for d in self.docs for m in d)
        n = len(self.docs)
        self.idf = {m: math.log(1 + (n - f + 0.5) / (f + 0.5)) for m, f in presence.items()}
        self.postings: dict[str, list[int]] = {}
        for i, d in enumerate(self.docs):
            for m in d:
                self.postings.setdefault(m, []).append(i)

    def _bm25(self, requete: str, k1=1.2, b=0.75) -> np.ndarray:
        scores = np.zeros(len(self.docs), dtype=np.float32)
        for m in set(mots(requete)):
            idf = self.idf.get(m)
            if idf is None:
                continue
            for i in self.postings[m]:
                f = self.docs[i][m]
                scores[i] += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * self.longueurs[i] / self.longueur_moyenne))
        return scores

    def chercher(self, requete: str, langue: str | None = None, nombre: int = 5) -> list[dict]:
        """Les `nombre` passages les plus pertinents, dans une langue (« fr », « en ») ou les deux (None)."""
        vecteur = np.array(next(iter(self.modele.query_embed(requete))), dtype=np.float32)
        semantique = self.vecteurs @ (vecteur / np.linalg.norm(vecteur))
        lexical = self._bm25(requete)
        masque = np.ones(len(self.passages), bool) if not langue else self.langues == langue
        # Titre : part des mots du titre de la section présents dans la requête, pondérée par leur rareté. « Agrippé »
        # trouve « Agrippé [État] » avant les profils de monstres qui citent l'état à chaque attaque.
        demandes = set(mots(requete))
        titre = np.array([sum(self.idf_titre.get(m, 0) for m in t & demandes) / (1 + len(t - demandes)) if t & demandes else 0
                          for t in self.titres], dtype=np.float32)
        fusion = np.zeros(len(self.passages), dtype=np.float32)
        for scores, poids in ((semantique, 1.0), (lexical, 1.0), (titre, 1.0)):
            candidats = np.where(masque & (scores > 0))[0]
            ordre = candidats[np.argsort(-scores[candidats])][:60]
            fusion[ordre] += poids / (60 + np.arange(1, len(ordre) + 1))
        meilleurs = [i for i in np.argsort(-fusion)[:nombre * 3] if fusion[i] > 0]
        # Pas deux morceaux de la même section : le premier suffit, lire_section donne le reste.
        vus, resultat = set(), []
        for i in meilleurs:
            p = self.passages[i]
            if p["section"] in vus:
                continue
            vus.add(p["section"])
            resultat.append({**p, "score": round(float(fusion[i]) * 1000, 1)})
            if len(resultat) == nombre:
                break
        return resultat

    def section(self, identifiant: str) -> dict | None:
        """Une section entière ; un id de passage (« fr-12-1180 ») donne sa section."""
        sid = re.sub(r"^([a-z]{2}-\d+).*$", r"\1", identifiant.strip())
        return self.sections.get(sid)


if __name__ == "__main__":
    import sys
    import time

    sys.stdout.reconfigure(encoding="utf-8")
    t = time.perf_counter()
    index = Index()
    print(f"chargé en {time.perf_counter() - t:.1f} s")
    for question in sys.argv[1:] or ["Que se passe-t-il quand on est agrippé ?", "attaque d'opportunité", "concentration dégâts jet de sauvegarde"]:
        t = time.perf_counter()
        resultats = index.chercher(question)
        print(f"\n# {question} ({(time.perf_counter() - t) * 1000:.0f} ms)")
        for r in resultats:
            print(f"  [{r['source']} p.{r['page']}] {' > '.join(r['chemin'])} ({r['score']})")
