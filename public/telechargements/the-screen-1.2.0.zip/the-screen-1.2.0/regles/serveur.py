"""Service de règles du gestionnaire : recherche dans le SRD 5.2.1 et agent Strands, sur http://localhost:8736/.

Lancé par lancer.ps1 quand l'assistant est installé (« outils/Installer l'assistant de règles.cmd »), ou à la main depuis regles/ :
    uv run serveur.py

  GET  /etat                     index chargé, fournisseur, modèle, modèle disponible ou non (et pourquoi)
  GET  /recherche?q=…&langue=fr  passages les plus proches, sans LLM
  GET  /section/<id>             une section entière
  POST /question                 { question, conversation } → flux SSE : outil, texte, sources, fin | erreur
  POST /oublier                  { conversation } : la conversation repart de zéro
N'écoute que sur localhost ; seule la page du gestionnaire (localhost:8735 ou un autre port local) peut l'appeler.
"""

import asyncio
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from collections import OrderedDict
from contextlib import asynccontextmanager

os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")  # cache du modèle d'embeddings sans liens symboliques (Windows)

import uvicorn
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, StreamingResponse
from starlette.routing import Route

from agent import cle_anthropic, creer_agent, lire_config, message_question
from indexer import LIVRES, index_a_jour

CONFIG = lire_config()
INDEX = None
CONVERSATIONS: "OrderedDict[str, dict]" = OrderedDict()   # id -> { agent, consultes, verrou }, les 8 dernières


def ollama_repond() -> bool:
    try:
        with urllib.request.urlopen(CONFIG["hote_ollama"].rstrip("/") + "/api/version", timeout=1):
            return True
    except OSError:
        return False


def chemin_ollama() -> str:
    return shutil.which("ollama") or os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe")


def lancer_ollama() -> "subprocess.Popen | None":
    """Instance d'Ollama propre au service, sur le GPU choisi par « gpu » (voir agent.py) ; None si une instance répond
    déjà ou si Ollama n'est pas installé. Le modèle est chargé d'avance : la première question n'attend pas son chargement."""
    if CONFIG["fournisseur"] != "ollama" or not CONFIG["ollama_dedie"] or ollama_repond():
        return None
    exe = chemin_ollama()
    if not os.path.exists(exe):
        print("Ollama introuvable : l'installer depuis https://ollama.com (ou régler regles.fournisseur dans poste.json).")
        return None
    hote = CONFIG["hote_ollama"].split("://", 1)[-1].rstrip("/")
    env = os.environ | {"OLLAMA_HOST": hote, "OLLAMA_KEEP_ALIVE": "30m"}
    if CONFIG["gpu"] == "integre":
        env |= {"OLLAMA_VULKAN": "1", "OLLAMA_IGPU_ENABLE": "1"}
    processus = subprocess.Popen([exe, "serve"], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    for _ in range(60):
        if ollama_repond():
            break
        time.sleep(0.5)
    print(f"Ollama lancé sur {hote} ({'GPU intégré' if CONFIG['gpu'] == 'integre' else 'carte graphique'}).")

    def prechauffer():
        corps = json.dumps({"model": CONFIG["modele"], "keep_alive": "30m", "options": {"num_ctx": int(CONFIG["contexte"])}}).encode()
        try:
            urllib.request.urlopen(urllib.request.Request(CONFIG["hote_ollama"].rstrip("/") + "/api/generate", corps,
                                                          {"Content-Type": "application/json"}), timeout=300).read()
        except OSError:
            pass
    threading.Thread(target=prechauffer, daemon=True).start()
    return processus


def mise_a_jour_ollama() -> bool:
    """Vrai pendant une mise à jour d'Ollama (OllamaSetup.exe, puis OllamaSetup.tmp) : la relancer bloquerait ses fichiers."""
    if os.name != "nt":
        return False
    try:
        sortie = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=10,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
    except (OSError, subprocess.SubprocessError):
        return False
    return "ollamasetup" in sortie.lower()


def surveiller_ollama(instance: dict, arret: threading.Event):
    """L'instance propre peut mourir sous le service : l'application Ollama du poste, lancée avec Windows, installe ses
    mises à jour en fermant tous les ollama.exe. Relancée dès qu'elle ne répond plus, une fois la mise à jour finie."""
    while not arret.wait(15):
        if ollama_repond() or mise_a_jour_ollama():
            continue
        if not os.path.exists(chemin_ollama()):
            return
        print("Ollama ne répond plus : relance.")
        instance["processus"] = lancer_ollama() or instance["processus"]


def disponibilite_modele() -> tuple[bool, str]:
    if CONFIG["fournisseur"] == "anthropic":
        return (True, "") if cle_anthropic() else (False, "Clé ANTHROPIC_API_KEY absente (variable d'environnement ou regles/.env).")
    try:
        with urllib.request.urlopen(CONFIG["hote_ollama"].rstrip("/") + "/api/tags", timeout=2) as r:
            noms = [m["name"] for m in json.load(r).get("models", [])]
    except OSError:
        return False, f"Ollama ne répond pas ({CONFIG['hote_ollama']}) : est-il lancé ?"
    if CONFIG["modele"] not in noms and CONFIG["modele"] + ":latest" not in noms:
        return False, f"Modèle {CONFIG['modele']} absent d'Ollama : ollama pull {CONFIG['modele']}"
    return True, ""


def resume_passage(p: dict) -> dict:
    return {k: p[k] for k in ("section", "langue", "source", "page", "chemin")} | {"extrait": p["texte"][:280]}


async def etat(_: Request):
    pret, raison = await asyncio.to_thread(disponibilite_modele)
    return JSONResponse({
        "index": INDEX is not None, "index_a_jour": index_a_jour(), "passages": len(INDEX.passages) if INDEX else 0,
        "fournisseur": CONFIG["fournisseur"], "modele": CONFIG["modele"], "modele_pret": pret, "raison": raison,
        "livres": {l["langue"]: l["fichier"] for l in LIVRES},   # PDF servis par le gestionnaire sous sources/
    })


async def recherche(req: Request):
    q = req.query_params.get("q", "").strip()
    if not q:
        return JSONResponse({"erreur": "Paramètre q vide."}, status_code=400)
    langue = req.query_params.get("langue") or None
    nombre = min(int(req.query_params.get("n", 6)), 20)
    passages = await asyncio.to_thread(INDEX.chercher, q, langue, nombre)
    return JSONResponse([resume_passage(p) | {"texte": p["texte"], "score": p["score"]} for p in passages])


async def section(req: Request):
    s = INDEX.section(req.path_params["id"])
    return JSONResponse(s) if s else JSONResponse({"erreur": "Section inconnue."}, status_code=404)


def conversation(identifiant: str) -> dict:
    if identifiant not in CONVERSATIONS:
        consultes = []
        CONVERSATIONS[identifiant] = {"agent": creer_agent(INDEX, CONFIG, consultes), "consultes": consultes,
                                       "verrou": asyncio.Lock(), "precedente": None}
        while len(CONVERSATIONS) > 8:
            CONVERSATIONS.popitem(last=False)
    CONVERSATIONS.move_to_end(identifiant)
    return CONVERSATIONS[identifiant]


def sse(evenement: str, donnees) -> str:
    return f"event: {evenement}\ndata: {json.dumps(donnees, ensure_ascii=False)}\n\n"


async def question(req: Request):
    corps = await req.json()
    texte = str(corps.get("question", "")).strip()[:2000]
    conv = conversation(str(corps.get("conversation") or "defaut")[:64])
    if not texte:
        return JSONResponse({"erreur": "Question vide."}, status_code=400)

    async def flux():
        debut = time.perf_counter()
        async with conv["verrou"]:
            conv["consultes"].clear()
            try:
                message = await asyncio.to_thread(message_question, INDEX, texte, conv["precedente"], conv["consultes"])
                conv["precedente"] = texte
                yield sse("sources", [resume_passage(p) for p in conv["consultes"]])
                async for ev in conv["agent"].stream_async(message):
                    if "data" in ev and ev["data"]:
                        yield sse("texte", {"t": ev["data"]})
                    elif "message" in ev and ev["message"].get("role") == "assistant":
                        # Message du modèle terminé : ses appels d'outils, entrée complète (pendant le flux, elle est partielle).
                        for bloc in ev["message"].get("content", []):
                            if "toolUse" in bloc:
                                yield sse("outil", {"nom": bloc["toolUse"]["name"], "entree": bloc["toolUse"]["input"]})
                    elif "message" in ev and ev["message"].get("role") == "user":
                        # Résultats d'outils renvoyés au modèle : les passages consultés sont connus.
                        yield sse("sources", [resume_passage(p) for p in conv["consultes"]])
            except Exception as e:  # le flux SSE est déjà ouvert : l'erreur part dans le flux
                yield sse("erreur", {"message": f"{type(e).__name__} : {e}"})
                return
        yield sse("sources", [resume_passage(p) for p in conv["consultes"]])
        yield sse("fin", {"duree": round(time.perf_counter() - debut, 1)})

    return StreamingResponse(flux(), media_type="text/event-stream", headers={"Cache-Control": "no-store"})


async def oublier(req: Request):
    corps = await req.json()
    CONVERSATIONS.pop(str(corps.get("conversation") or "defaut"), None)
    return JSONResponse({"ok": True})


@asynccontextmanager
async def demarrage(_):
    global INDEX
    from recherche import Index

    t = time.perf_counter()
    ollama = {"processus": await asyncio.to_thread(lancer_ollama)}
    arret = threading.Event()
    if CONFIG["fournisseur"] == "ollama" and CONFIG["ollama_dedie"]:
        threading.Thread(target=surveiller_ollama, args=(ollama, arret), daemon=True).start()
    INDEX = await asyncio.to_thread(Index)
    print(f"Index chargé : {len(INDEX.passages)} passages en {time.perf_counter() - t:.1f} s ; "
          f"{CONFIG['fournisseur']} · {CONFIG['modele']}")
    try:
        yield
    finally:
        arret.set()
        if ollama["processus"]:
            ollama["processus"].terminate()


app = Starlette(
    routes=[
        Route("/etat", etat), Route("/recherche", recherche), Route("/section/{id}", section),
        Route("/question", question, methods=["POST"]), Route("/oublier", oublier, methods=["POST"]),
    ],
    middleware=[Middleware(CORSMiddleware, allow_origin_regex=r"http://(localhost|127\.0\.0\.1)(:\d+)?",
                           allow_methods=["GET", "POST"], allow_headers=["Content-Type"])],
    lifespan=demarrage,
)

if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if not index_a_jour():
        sys.exit("Index des règles absent ou périmé : lancer « uv run indexer.py » depuis regles/.")
    uvicorn.run(app, host="127.0.0.1", port=int(CONFIG["port"]), log_level="warning")
