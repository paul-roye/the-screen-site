﻿# Installe l'assistant de règles (widget Règles) sur ce poste : environnement Python, index des PDF, modèle local.
# Usage : double-clic sur « outils/Installer l'assistant de règles.cmd » (à relancer sans risque : ce qui est fait est sauté).
#
# 1. uv (gestionnaire Python d'Astral) : proposé à l'installation s'il manque ; il installe lui-même le bon Python.
# 2. Dépendances (regles/.venv) puis index des PDF du SRD 5.2.1 rangés dans sources/ (regles/index/, ~5 min la 1re fois).
# 3. Fournisseur réglé par « regles » de poste.json (ollama par défaut) : Ollama doit être installé (https://ollama.com),
#    le modèle est téléchargé (~2,5 Go). Avec « anthropic » : rappel de la clé à mettre dans regles/.env.
# Ensuite, « Lancer le gestionnaire.cmd » démarre le service de règles avec le gestionnaire.
$ErrorActionPreference = 'Stop'
$dossier = $PSScriptRoot
$racine = Split-Path $dossier -Parent

function Etape([string]$texte) { Write-Host ''; Write-Host "» $texte" -ForegroundColor Magenta }

Etape 'uv (Python)'
$uv = Get-Command uv -ErrorAction SilentlyContinue
if (-not $uv) {
    Write-Host 'uv est absent. Il s''installe pour l''utilisateur, sans droits administrateur (https://docs.astral.sh/uv/).'
    if ((Read-Host 'L''installer maintenant ? (O/n)') -match '^[nN]') { Write-Host 'Abandon.'; exit 1 }
    Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression
    $env:Path = "$env:USERPROFILE\.local\bin;$env:Path"
    $uv = Get-Command uv -ErrorAction Stop
}
Write-Host "uv : $($uv.Source)"

Etape 'Dépendances'
Push-Location $dossier
try {
    & $uv.Source sync
    if ($LASTEXITCODE) { throw 'uv sync a échoué.' }

    Etape 'Index des règles (PDF de sources/)'
    & $uv.Source run indexer.py
    if ($LASTEXITCODE) { throw 'L''indexation a échoué.' }

    Etape 'Modèle'
    $config = (& $uv.Source run python -c 'import json, agent; print(json.dumps(agent.lire_config()))') | ConvertFrom-Json
    if ($config.fournisseur -eq 'anthropic') {
        if (-not $env:ANTHROPIC_API_KEY -and -not (Select-String -Path (Join-Path $dossier '.env') -Pattern '^ANTHROPIC_API_KEY=' -Quiet -ErrorAction SilentlyContinue)) {
            Write-Host "Mettre la clé dans $dossier\.env, une ligne : ANTHROPIC_API_KEY=sk-ant-…" -ForegroundColor Yellow
        } else { Write-Host "Anthropic : $($config.modele), clé présente." }
    } else {
        $ollama = (Get-Command ollama -ErrorAction SilentlyContinue).Source
        if (-not $ollama) { $ollama = "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe" }
        if (-not (Test-Path $ollama)) {
            Write-Host 'Ollama est absent : l''installer depuis https://ollama.com/download (OllamaSetup.exe), puis relancer ce script.' -ForegroundColor Yellow
            Start-Process 'https://ollama.com/download'
            exit 1
        }
        # ollama pull parle à un serveur Ollama : celui du poste s'il tourne, sinon une instance le temps du téléchargement.
        $temporaire = $null
        try { Invoke-RestMethod http://127.0.0.1:11434/api/version -TimeoutSec 2 | Out-Null }
        catch { $temporaire = Start-Process $ollama -ArgumentList 'serve' -WindowStyle Hidden -PassThru; Start-Sleep 3 }
        try {
            & $ollama pull $config.modele
            if ($LASTEXITCODE) { throw "Téléchargement du modèle $($config.modele) échoué." }
        } finally { if ($temporaire) { Stop-Process -Id $temporaire.Id -Force -ErrorAction SilentlyContinue } }
    }
} finally { Pop-Location }

Write-Host ''
Write-Host 'Assistant de règles installé. « Lancer le gestionnaire.cmd » le démarre ; ajouter le widget Règles au tableau.' -ForegroundColor Green
