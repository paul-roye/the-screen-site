@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\indexer-images\indexer-images.ps1"
pause
