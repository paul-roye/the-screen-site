@echo off
rem Importe une annee de meteo reelle d une ville (Open-Meteo) dans data/meteo.json d une campagne.
rem Exemple : Importer la meteo.cmd -Ville Carcassonne -Annee 2009 -Pays FR -Campagne ma-campagne
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\import-meteo\importer-meteo.ps1" %*
pause
