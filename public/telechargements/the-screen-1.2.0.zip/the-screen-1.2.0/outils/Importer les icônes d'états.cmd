@echo off
rem Importe les icones des etats (Aveugle, Empoisonne, Epuisement...) depuis le code public de Maps, le VTT de D&D Beyond,
rem dans icones-beyond\etats.json (hors depot), lu par le widget Personnages. A relancer si D&D Beyond change ses icones.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\import-etats\importer-icones-etats.ps1"
pause
