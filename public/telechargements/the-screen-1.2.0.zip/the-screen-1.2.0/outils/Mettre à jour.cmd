@echo off
rem Met a jour votre gestionnaire avec cette version : lancez-le depuis le dossier decompresse de la NOUVELLE version,
rem puis choisissez le dossier de votre gestionnaire actuel. Vos campagnes et poste.json ne sont pas touches ;
rem l'ancienne version est sauvegardee dans anciennes-versions\ de votre gestionnaire.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\mettre-a-jour.ps1" %*
pause
