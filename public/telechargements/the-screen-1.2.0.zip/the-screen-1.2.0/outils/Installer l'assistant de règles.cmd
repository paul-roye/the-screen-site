@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\regles\installer.ps1"
pause
