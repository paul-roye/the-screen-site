@echo off
rem Campagne : celle par défaut (poste.json), ou en argument : « Importer la musique.cmd » -Campagne <id>
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\import-musique\importer-musique.ps1" %*
pause
