@echo off
rem Importe les images de la campagne par defaut (sources de son manifeste : livre D&D Beyond, Homebrewery, dossier du MJ), puis les indexe.
rem Une autre campagne : "Importer les images.cmd" -Campagne <id>. Se regle et se lance aussi depuis le gestionnaire (fenetre Campagne, onglet Images).
rem Premier lancement sur un poste : demande ou ranger la bibliotheque (poste.json). Relancer reprend la ou il s'etait arrete.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\import-images\importer-images.ps1" %*
pause
