@echo off
rem Campagne : celle par défaut (poste.json), ou en argument : « Importer le wiki.cmd » -Campagne <id>
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\scripts\import-wiki\importer-wiki.ps1" %*
pause
