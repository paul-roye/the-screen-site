﻿# Régénère tokens.css à partir de tokens.json et vérifie les contrastes texte/fond.
# Usage : powershell -ExecutionPolicy Bypass -File .\build-tokens.ps1
param(
    [string]$Source = (Join-Path $PSScriptRoot 'tokens.json'),
    [string]$Out = (Join-Path $PSScriptRoot 'tokens.css')
)
$ErrorActionPreference = 'Stop'
$t = [IO.File]::ReadAllText($Source, [Text.Encoding]::UTF8) | ConvertFrom-Json
$themes = @($t.color.themes | ForEach-Object { $_.id })
$first = $themes[0]

function Get-Val($tok, $theme) {
    if ($tok.value -is [string]) { return $tok.value }
    $v = $tok.value.$theme
    if (-not $v) { $v = $tok.value.$first }
    return $v
}
function Css-Val($v) {
    if ($v -match '^\{(.+)\}$') { return "var(--$($Matches[1]))" }
    return $v
}

$sb = New-Object Text.StringBuilder
[void]$sb.AppendLine("/* $($t.name) — generated from tokens.json */")

foreach ($theme in $themes) {
    $sel = if ($theme -eq $first) { ":root, [data-theme=`"$theme`"]" } else { "[data-theme=`"$theme`"]" }
    [void]$sb.AppendLine("$sel {")
    foreach ($tok in $t.color.tokens) {
        if ($theme -ne $first -and $tok.value -is [string]) { continue }
        [void]$sb.AppendLine("  --$($tok.name): $(Css-Val (Get-Val $tok $theme));")
    }
    foreach ($tok in $t.shadow.tokens) {
        if ($theme -ne $first -and $tok.value -is [string]) { continue }
        [void]$sb.AppendLine("  --$($tok.name): $(Get-Val $tok $theme);")
    }
    [void]$sb.AppendLine("}")
}

[void]$sb.AppendLine(":root {")
foreach ($fam in 'spacing', 'radius') {
    foreach ($tok in $t.$fam.tokens) { [void]$sb.AppendLine("  --$($tok.name): $($tok.value);") }
}
foreach ($p in $t.type.families.PSObject.Properties) { [void]$sb.AppendLine("  --font-$($p.Name): $($p.Value);") }
[void]$sb.AppendLine("}")

foreach ($g in $t.type.groups) {
    foreach ($s in $g.styles) {
        $fam = if ($s.family) { $s.family } else { $g.family }
        $decl = @("font-family: var(--font-$fam)", "font-size: $($s.fontSize)", "line-height: $($s.lineHeight)", "font-weight: $($s.fontWeight)")
        if ($s.letterSpacing) { $decl += "letter-spacing: $($s.letterSpacing)" }
        if ($s.fontStyle) { $decl += "font-style: $($s.fontStyle)" }
        [void]$sb.AppendLine(".$($s.name) { $($decl -join '; '); }")
    }
}
[IO.File]::WriteAllText($Out, $sb.ToString(), (New-Object Text.UTF8Encoding $false))
Write-Host "tokens.css écrit ($Out)"

# --- Contrastes (WCAG 2) ---
function Lum($hex) {
    $h = $hex.TrimStart('#'); if ($h.Length -eq 3) { $h = -join ($h.ToCharArray() | ForEach-Object { "$_$_" }) }
    $c = 0, 2, 4 | ForEach-Object {
        $x = [Convert]::ToInt32($h.Substring($_, 2), 16) / 255
        if ($x -le 0.03928) { $x / 12.92 } else { [Math]::Pow(($x + 0.055) / 1.055, 2.4) }
    }
    return 0.2126 * $c[0] + 0.7152 * $c[1] + 0.0722 * $c[2]
}
$byName = @{}; foreach ($tok in $t.color.tokens) { $byName[$tok.name] = $tok }
$pairs = @(
    @('os', 'void', 4.5), @('os', 'crypte', 4.5), @('os', 'pierre', 4.5), @('os', 'pierre-haute', 4.5),
    @('cendre', 'crypte', 4.5), @('cendre', 'pierre', 4.5), @('cendre', 'pierre-haute', 4.5),
    @('fane', 'crypte', 4.5), @('fane', 'pierre', 4.5),
    @('sang', 'void', 4.5), @('sang', 'pierre', 4.5), @('ultra', 'pierre', 4.5), @('brume', 'pierre', 4.5),
    @('cierge', 'pierre', 4.5), @('soleil', 'pierre', 4.5), @('mousse', 'pierre', 4.5),
    @('sur-accent', 'sang', 4.5), @('sur-accent', 'ultra', 4.5), @('sur-accent', 'brume', 4.5), @('sur-accent', 'cierge', 4.5),
    @('os-clair', 'sang-profond', 4.5), @('encre', 'velin', 4.5),
    @('trait-fort', 'crypte', 3), @('trait-fort', 'pierre', 3), @('focus', 'pierre', 3), @('focus', 'void', 3),
    @('fac-zarovich', 'pierre', 3), @('fac-vistani', 'pierre', 3), @('fac-argynvost', 'pierre', 3),
    @('fac-plume', 'pierre', 3), @('fac-matinal', 'pierre', 3), @('fac-loups', 'pierre', 3)
)
$fails = 0
foreach ($theme in $themes) {
    foreach ($p in $pairs) {
        $a = Lum (Get-Val $byName[$p[0]] $theme); $b = Lum (Get-Val $byName[$p[1]] $theme)
        $r = ([Math]::Max($a, $b) + 0.05) / ([Math]::Min($a, $b) + 0.05)
        if ($r -lt $p[2]) { $fails++; Write-Warning ("{0,-10} {1} sur {2} : {3:N2}:1 (min {4})" -f $theme, $p[0], $p[1], $r, $p[2]) }
    }
}
if ($fails -eq 0) { Write-Host "Contrastes : $($pairs.Count * $themes.Count) paires OK" }
