Carte du jeu de Tarokka, face visible ou cachée, pour préparer et jouer le tirage de Madame Eva : `.bn-tarokka`.

**Le consommateur fournit** : `data-suite` (`epees`, `etoiles`, `pieces`, `glyphes` ou `haut` pour le haut jeu), un `<span class="bn-tarokka__cadre">`, le rang en chiffres romains (`.bn-tarokka__rang`, « Maître » pour le 10, rien pour le haut jeu), l'emblème `<svg class="bn-tarokka__embleme">`, le nom (`.bn-tarokka__nom`) et la couleur (`.bn-tarokka__suite`).

| Couleur | `data-suite` | Néon | Icône |
| --- | --- | --- | --- |
| Épées | `epees` | `sang` | `epee` |
| Étoiles | `etoiles` | `ultra` | `etoile` |
| Pièces | `pieces` | `cierge` | `piece` |
| Glyphes | `glyphes` | `brume` | `glyphe` |
| Haut jeu | `haut` | `soleil` | `tarokka` |

- Face cachée : `.bn-tarokka--dos` (motif losangé sur `sang-profond`, emblème `chauve-souris`). Si la carte se retourne au clic, utiliser un `<button>` avec `aria-label`.
- Miniature : `.bn-tarokka--mini` (18px de large, même ratio), l'emblème seul (12px), sans cadre, rang, nom ni couleur ; face cachée avec `.bn-tarokka--dos` (fond `sang-profond` uni). Pour rappeler un tirage dans un en-tête de widget. `.est-trouve` lui donne une auréole d'or (`soleil`, `drop-shadow` qui suit les coins coupés) : objet trouvé, allié recruté. Le nom de la carte va dans `title` et `aria-label`.
- Ratio 5:8, 172px de large, coupe `coupe-m`. La carte peut rétrécir (`width: 100%` dans une colonne) jusqu'à 80px environ : marges, rang, emblème, nom et couleur suivent sa largeur (nom de 21px à 12px, emblème de 56px à 34 % de la largeur) ; le nom garde la hauteur de deux lignes, pour que l'emblème et la couleur restent alignés d'une carte à l'autre.
- Le `surtitre` d'une place réserve deux lignes et se cale contre la carte : les cartes d'une même rangée s'alignent même si un libellé passe à la ligne.
- Tirage : `.bn-tirage` contenant des `.bn-tirage__place`, chacune avec un `surtitre` (« Le Tome », « Le Symbole sacré », « L'Épée solaire », « L'Allié », « Strahd ») au-dessus de la carte.
