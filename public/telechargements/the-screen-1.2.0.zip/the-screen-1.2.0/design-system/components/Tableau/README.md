Tableau de données dense pour PNJ, inventaire, journal de séance : `.bn-table` dans un `.bn-table-wrap`.

**Le consommateur fournit** : un `<table>` avec `<thead>` et `<tbody>`, la classe `num` sur les cellules numériques (alignées à droite), éventuellement `.bn-table__nom` + `.bn-table__sous` pour une cellule sur deux lignes.

- En-têtes en `etiquette` (capitales, `cendre`), collants en haut lors du défilement.
- Chiffres tabulaires partout.
- Ligne sélectionnée : `aria-selected="true"` sur le `<tr>` (fond `pierre-haute`).
- PNJ mort : classe `est-mort` sur le `<tr>` (nom barré d'un trait `sang`, texte `fane`), plus un badge « Mort ».
- Le conteneur défile horizontalement sur mobile ; ne jamais réduire la police.
