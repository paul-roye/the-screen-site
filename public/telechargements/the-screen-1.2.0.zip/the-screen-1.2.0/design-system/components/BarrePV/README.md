Jauge de points de vie avec PV temporaires et état nommé : `.bn-pv`.

**Le consommateur fournit** : `--pv` (pourcentage restant) et `--pv-temp` (pourcentage de PV temporaires) en style inline, `data-etat`, les valeurs dans `.bn-pv__val`, et sur `.bn-pv__barre` un `role="meter"` avec `aria-valuemin`, `aria-valuemax`, `aria-valuenow` et `aria-label`.

| `data-etat` | Seuil | Couleur | Mot à afficher |
| --- | --- | --- | --- |
| (absent) | > 50 % | `brume` | — |
| `ensanglante` | ≤ 50 % | `soleil` | « Ensanglanté » |
| `critique` | < 20 % | `sang`, pulse | « Critique » |
| `mort` | 0 | `fane` | « Mort » |

- PV temporaires : segment `ultra` après les PV, valeur en `.bn-pv__temp` (« +5 »).
- `.bn-pv--mini` : version compacte pour le suivi d'initiative.
- L'état se calcule dans l'application ; le CSS ne fait que l'afficher.
