Une ligne d'une frise de campagne : un jalon entre deux étapes, ou une piste (un fil à faire reparaître) : `.bn-jalon`, dans une liste `.bn-jalons`.

**Le consommateur fournit** : un élément `.bn-jalon` cliquable (son détail s'ouvre dans une [fenêtre flottante](../Flottant/README.md), jamais déplié dans la liste ; `.est-ouvert` tant qu'elle l'est), avec :

1. `.bn-jalon__icone` : l'icône du type (16px), son nom en `title` ;
2. `.bn-jalon__nom` : le nom dans un `<button class="bn-jalon__bouton">` (pour le clavier), puis en option des `.bn-jalon__meta` (« · 2 h 30 de marche », une icône et un nombre) et un `.bn-jalon__declencheur` sous le nom (« Le lendemain matin… », italique, icône d'horloge) ;
3. en option, un badge à droite (statut, personnage).

- Statut par modificateur : `--a-venir` (en `cendre`), `--suivant` (texte `os`, icône `cierge`), `--en-cours` (encadré `soleil` sur `pierre-haute`, sans néon : le néon reste à l'étape en cours ; plusieurs peuvent l'être), `--passe` et `--termine` (voilés, icône `brume`).
- Piste : `.bn-jalon--piste`, icône `ultra` (Lucide `waypoints`), `brume` une fois terminée. Sous une étape, son rappel est plus discret : `.bn-jalon--rappel` (lignes basses, nom en 13px, voilée à venir).
- Liste : `.bn-jalons` (lignes serrées, 2px) ; dans la frise du déroulé, entre deux étapes, `.bn-jalons--frise` : en retrait, un filet pointillé à gauche.
- Au survol, le nom passe en `os`. Le nom ouvert est en `sang` (classe `.cm-ouvre` du gestionnaire).

Dans le gestionnaire : `vueJalon()` et `lignePiste()` de `app/widgets/deroule.js`, rappels de l'onglet Trame d'Ici (`app/widgets/ici.js`).
