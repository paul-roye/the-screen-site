Icône thématique en sprite SVG : `<svg class="bn-icone"><use href="#bn-<nom>"/></svg>`.

**Le consommateur fournit** : le chargement de `icons.js` (une fois par page, il injecte le sprite), le nom de l'icône, et soit `aria-hidden` implicite (icône à côté d'un texte), soit un `aria-label` sur le bouton parent (icône seule).

- Couleur héritée (`currentColor`) : l'icône prend la couleur du texte qui l'entoure.
- Tailles : `.bn-icone--s` 16, défaut 20, `.bn-icone--l` 28, `.bn-icone--xl` 40.
- En JavaScript : `BN.icone('cierge', { taille: 20, titre: 'Lumière' })` renvoie le SVG ; `BN.icones` liste les 42 noms.
- Noms : chauve-souris, crocs, goutte, cierge, corbeau, cercueil, tarokka, chateau, brume, soleil, lune, crane, pieu, loup, d20, epee, bouclier, coeur, sablier, lettre, cle, carte, epingle, oeil, potion, coupe-vin, ambre, griffe, livre, porte, etoile, piece, glyphe ; pour le haut jeu du Tarokka et sa table : croix-tarokka (la croix de la lecture), amulette, coeur-brise, couronne, cachot, fantome, hache, fer-cheval, marionnette.
- Les icônes génériques d'interface viennent de Lucide (même grille 24, trait 1.5).
