Champ de formulaire avec libellé, aide et erreur : `.bn-champ` autour d'un `.bn-input`, `.bn-select` ou `.bn-textarea`.

**Le consommateur fournit** : un `<label class="bn-champ">` contenant `<span class="bn-champ__label">`, le contrôle avec un `id` stable, puis au choix `.bn-champ__aide` ou `.bn-champ__erreur`.

- Champs à angle droit, fond `pierre-haute`, bordure `trait-fort`.
- `.bn-input--nombre` : 88px centré, chiffres tabulaires (PV, CA, initiative).
- `.bn-textarea` écrit en Spectral : c'est de la prose (notes de séance).
- Erreur : `aria-invalid="true"` sur le contrôle + `.bn-champ__erreur` avec l'icône `crane`, message qui dit quoi faire.
- Plusieurs champs sur une ligne : `.bn-ligne-champs` (passe à la ligne seul).
- Cases à cocher : `<input type="checkbox" class="bn-case">`.
