Au bout d'un texte qui renvoie au déroulé (une étape de la quête personnelle d'un héros) : l'icône du jalon ou de la piste, qui l'ouvre dans le déroulé, et son statut en petit : `.bn-lien-deroule`.

**Le consommateur fournit** : `<span class="bn-lien-deroule">` avec un `<button class="bn-lien-jalon">` (l'icône du jalon ou de la piste, 16px, en `ultra` ; son nom en [infobulle](../Infobulle/README.md), `aria-label` « Ouvrir … dans le Déroulé »), puis `<span class="bn-statut-deroule bn-statut-deroule--<statut>">` : « à venir » en `cendre`, « en cours » en `soleil`, « terminé » en `brume` précédé d'une coche.

- Le tout reste sur une ligne (`white-space: nowrap`), collé au texte.
- Renvoi introuvable (un jalon ou une piste absent des données) : `<span class="bn-lien-introuvable" tabindex="0">` avec un triangle d'alerte en `sang`, l'explication en infobulle rouge.
- `.bn-lien-jalon` seul (sans statut) sert aussi après un nom.

Dans le gestionnaire : onglet Quête de la fiche d'un héros (`app/widgets/personnages.js`).
