Outil posé sur le tableau de bord du MJ, déplaçable et redimensionnable : `.bn-widget` dans une `.bn-grille`.

**Le consommateur fournit** : la grille (`app/grille.js` calcule et pose `left`, `top`, `width`, `height`), et pour chaque widget une `<section class="bn-panel bn-widget">` avec :

- `.bn-widget__tete` : un bouton `.bn-widget__poignee` (icône Lucide `grip-vertical`, `aria-label` « Déplacer … »), un `.bn-widget__titres` (`surtitre` puis `h2.bn-widget__titre`), un `.bn-widget__resume` (facultatif, voir plus bas), des `.bn-widget__actions` en `.bn-btn--s` ;
- `.bn-widget__corps` : le contenu, qui défile seul ;
- `.bn-widget__redim` : la poignée de redimensionnement, dans le coin coupé en bas à droite.

- Un widget est un panneau (`coupe-l`, fond `crypte`) : ne pas y imbriquer de `.bn-panel`, utiliser des `.bn-carte`.
- Pendant le glisser, `.est-saisi` donne la bordure `sang` et le halo ; un `.bn-grille__fantome` en pointillés `sang` montre où le widget va tomber. C'est le seul élément qui luit à ce moment-là.
- `.bn-widget--compact` : petit outil qui tient sur 2 colonnes (minuteur, convertisseur). En-tête d'une ligne sans surtitre, titre en 18px, écarts verticaux réduits (les marges latérales restent celles d'un widget normal) ; ses commandes vont dans le corps, pas dans l'en-tête. Un widget le demande par `compact: true` dans sa définition.
- `.est-reduit` : le widget ne garde que son titre, sans surtitre (1 rangée) ; le corps et le coin disparaissent. Bouton chevron `aria-expanded` dans l'en-tête, ou double-clic sur l'en-tête. La hauteur dépliée est gardée.
- `.bn-widget__resume` : ce que le widget rappelle dans son en-tête, même réduit (étape en cours, cartes du tirage, heure de jeu). Il prend la place libre entre le titre et les actions, séparé par un filet `trait`, et remplace le surtitre. Deux lignes au plus, qui tiennent dans la rangée d'un widget réduit : une `surtitre` (12px, sans capitales dans le résumé) puis le texte (14px `os`), chacune coupée en « … ». Vide : il disparaît. `data-quand="reduit"` : seulement quand le widget est réduit. Cliquable (aller à l'élément en cours) : un `button.bn-widget__resume-bouton` qui contient les deux lignes ; au survol, la seconde passe en `sang`.
- `.bn-grille--verrou` masque poignées, coin et bouton de fermeture (`.bn-widget__fermer`) : disposition figée pour jouer, aucun widget ne peut être retiré par erreur.
- `.bn-grille--pile` (écran étroit) : les widgets s'empilent dans l'ordre de lecture, sans glisser.
- Clavier : poignée focalisée, flèches pour déplacer, Maj + flèches pour redimensionner.
- Titre en Grenze Gotisch 23px, une icône de la bibliothèque en `cendre` devant.
