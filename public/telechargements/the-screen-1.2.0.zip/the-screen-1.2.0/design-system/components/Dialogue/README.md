Fenêtre modale par-dessus l'écran (choisir un outil, régler la campagne, consulter l'état des données) : `<dialog class="bn-dialogue">` ouvert avec `showModal()`.

**Le consommateur fournit** : un `aria-label` sur le `<dialog>`, et à l'intérieur un seul `.bn-panel` avec `.bn-panel__tete` (titres + bouton Fermer `.bn-btn--s.bn-btn--fantome`, icône Lucide `x` ; toujours sur une ligne, un titre long passe à la ligne), `.bn-panel__corps` et un `.bn-panel__pied` facultatif.

- Largeur 560px au plus (`.bn-dialogue--large` : 860px, pour un catalogue ou une fiche longue) ; le corps défile si le contenu dépasse.
- Fond assombri et légèrement flouté (`void` à 72 %). Ombre `ombre-panneau` : c'est un élément qui flotte.
- Échap ou un clic sur le fond ferme le dialogue.
- Pas de lueur sur le panneau : le dialogue n'est pas l'élément actif, son bouton principal l'est.
- Une question en pied de corps (« Les héros se rendent-ils à … ? » quand on change d'étape) : `.bn-aller`, séparée du reste par un filet `trait`, l'intitulé en `etiquette` puis les choix en boutons radio, le plus prudent coché d'office (« Pas maintenant »).
