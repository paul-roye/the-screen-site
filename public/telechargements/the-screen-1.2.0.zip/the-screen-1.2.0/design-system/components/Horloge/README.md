Horloge de campagne : jour, date du calendrier, moment de la journée, météo et heure de jeu : `.bn-horloge`. Avec elle, la fenêtre du jour (`.bn-jour`) et la météo d'un créneau (`.bn-meteo`, `.bn-rappel-meteo`).

**Le consommateur fournit** : `data-moment` (`aube`, `jour`, `crepuscule` ou `nuit`), l'astre `<svg class="bn-horloge__astre">` (`soleil` le jour, `lune` la nuit, `cierge` à l'aube et au crépuscule), un `.bn-horloge__textes` (les lignes du jour), en option l'heure de jeu `.bn-horloge__heure`, seule ou avec la météo dans un `.bn-horloge__droite`, et la liste `.bn-horloge__phases` de quatre `<li>` dont le moment courant porte `aria-current="true"`.

- Nuit : `ultra` lumineux. Jour : `soleil`. Aube et crépuscule : `cierge`.
- L'heure reste en `os` : seul l'astre et le moment courant prennent la couleur du moment.
- Le moment se lit par le mot surligné, pas seulement par la couleur.
- L'heure peut être un `<button>` (régler l'horloge d'un clic) : sans cadre ni icône, elle s'allume au survol (`sang`).
- À placer en haut de l'écran de séance : c'est le rappel que la nuit vient toujours.

**Le bandeau complet** (widget Horloge) : à gauche, serrées, les lignes du jour ; à droite, en grand, la météo et l'heure dans `.bn-horloge__droite`, sur toute la hauteur de ces lignes. Les lignes du jour, dans `.bn-horloge__textes` :

1. `.bn-horloge__jour` : « JOUR 1 · Lundi 6 octobre · 1009 », sur une ligne. Le jour de campagne et les points en `surtitre` (points `aria-hidden`) ; la date du calendrier en `<button class="bn-horloge__date">` (souligné pointillé ; au survol, une ligne en [infobulle](../Infobulle/README.md) : le résumé du jour et sa divinité ; un clic ouvre la fenêtre du jour, et la date garde `.est-ouvert`, en `sang`, tant qu'elle est ouverte) ; puis l'année, point compris, dans `.bn-horloge__an` : `.surtitre.bn-horloge__annee`, « Calendrier classique » en infobulle.
2. L'ambiance en `titre-m` (« Nuit noire »).
3. Le détail, `.ui-s.bn-horloge__detail` en `cendre` : le lever ou le coucher du soleil en icône Lucide (`sunrise`, `sunset`, en `cierge`) dans `.bn-horloge__soleil` (« dans 1 h », l'heure exacte en infobulle), « · », puis la lune dans `.bn-horloge__lune` (icône de lune et « dans 18 j » : la pleine lune, l'icône le dit ; la phase en infobulle). Jamais « Coucher du soleil » en toutes lettres.
4. En option, le jour marqué du jour ou des deux semaines à venir : `.bn-horloge__marque` (étoile, nom coupé en « … » dans `.bn-horloge__marque-nom`, puis « dans 3 j » ou « : aujourd'hui »), le texte du jour en infobulle. Étoile `cierge`, `sang` pour un jour spécial (`data-type="special"` : anniversaire du comte, mariage maudit, infobulle rouge) ; `data-jour` le jour même, nom en `os`.

`.bn-horloge__droite` porte la météo `.bn-meteo.bn-horloge__meteo` (l'icône du ciel sur deux lignes, la température en `os`, le texte dessous en `cendre`), puis l'heure. La météo rétrécit en premier : son texte se coupe en « … ».

Le bloc ne s'élargit pas pour son contenu (`container-type: inline-size`) : un débordement se mesure. Le consommateur pose une disposition et garde la première qui tient (rien ne déborde, la température entière, quelques lettres du texte de la météo, la date entière), mesurée à chaque rendu et quand le widget change de taille, sans seuil fixe (`ajusterBandeau()` de `app/widgets/horloge.js`). La météo reste à gauche de l'heure tant que possible (demande du MJ, 2026-10-22) ; dès qu'elle n'est plus en grand, l'icône du ciel (20px) est sur la ligne de la température, le texte dessous :

| Disposition | Classes | Rendu |
| --- | --- | --- |
| Côte à côte | `.bn-horloge--cote` | la météo (icône de 48px, température en 24px, texte en 15px) à gauche de l'heure en 60px |
| Serrée | `.bn-horloge--serre` | la météo en petit à gauche de l'heure en 44px ; plus d'année sur la ligne du jour |
| … sans texte | `.bn-horloge--serre.bn-horloge--sans-texte` | la météo sans son texte (au survol), l'icône au-dessus de la température |
| L'une au-dessus de l'autre | `.bn-horloge--pile` | l'heure en 44px au-dessus de la météo, calées à droite |
| Date dessous | `.bn-horloge--jour-empile` (avec l'une des précédentes) | la date sous « JOUR 1 », sans point, coupée en « … » si sa colonne est trop étroite |
| Étroite | `.bn-horloge--etroit` (avec l'une des précédentes) | la colonne de gauche rétrécit (ambiance et détail passent sur deux lignes s'il le faut), ambiance en 20px, date en 14px, heure en 36px |

Ordre essayé par le widget : côte à côte ; serrée ; serrée, date dessous ; serrée sans texte, date dessous ; la même, étroite ; l'une au-dessus de l'autre ; avec la date dessous ; puis étroite (la date peut s'y couper).

Sans disposition : la météo (icône de 26px) à gauche de l'heure en 36px.

**Plus simple** : sans météo, l'heure directement dans `.bn-horloge`. L'astre occupe alors trois lignes à gauche, la date courte (« Jour 7 ») puis l'ambiance au milieu, l'heure (30px) à droite des deux, et la ligne de détail sous l'ambiance et l'heure : chaque ligne garde toute la place, sans retour à la ligne. Sans heure : l'astre, puis les lignes du jour.

**Fenêtre du jour** : un clic sur la date ouvre une [fenêtre flottante](../Flottant/README.md) (surtitre « Jour 1 · 1009 du calendrier classique », titre « Lundi 6 octobre »). Son contenu, `.bn-jour`, donne l'essentiel d'abord dans `.bn-jour__essentiel` : équivalent et signification en `ui-l`, la divinité `.bn-jour__divinite` (icône `cierge`), le résumé du jour en `texte`, le jour marqué du jour `.bn-jour__marque` (étoile, `sang` si `data-type="special"`, nom en gras), la saison et la lune en `ui-s` discret. Puis, repliés (`<details>`) : le jour en détail (sens, coutumes, étymologie, encadré « Pour le MJ, ne pas lire ») et le calendrier classique (présentation, mois, semaine en `.bn-jour__semaine` : nom, équivalent, divinité, le jour en cours en `sang` avec `aria-current="true"` ; lune, saisons, jours marqués à venir, année).

**Météo** (`vueMeteo()` et `rappelMeteo()` de `app/calendrier.js`) :

- `.bn-meteo` : la météo d'un créneau sur une ligne, icône du ciel `.bn-meteo__ciel` en `brume`, texte `.bn-meteo__texte` en `os` coupé en « … », température `.bn-meteo__temp` (« −3 à 1 °C », espace fine insécable avant « °C »). Le résumé du jour et le ciel « dans le monde » en infobulle. Icônes Lucide : la précipitation d'abord (`cloud-drizzle`, `cloud-rain`, `cloud-rain-wind`, `cloud-hail`, `cloud-snow`, `snowflake` pour la forte neige), sinon le ciel (`cloud`, `cloudy`, `cloud-fog`) ; jamais de soleil, un ciel toujours voilé le reste : `cloud-moon` pour un ciel dégagé la nuit.
- `.bn-rappel-meteo` : rappel discret hors de l'horloge (Trajets, Rencontres) quand le créneau a du brouillard, de la forte neige ou du verglas. Icône `bn-icone--s` et mots (« Brouillard · Forte neige ») en `brume`, focalisable (`tabindex="0"`), le détail en infobulle. Un rappel, rien d'automatique : le MJ juge du terrain difficile.
