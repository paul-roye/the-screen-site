Barre d'onglets en capitales avec soulignement néon : `.bn-onglets` contenant des `.bn-onglet`.

**Le consommateur fournit** : `role="tablist"` et un `aria-label` sur le conteneur, des `<button role="tab">` avec `aria-selected`, et la logique de bascule des panneaux.

- L'onglet actif passe en `os` avec un trait `sang` lumineux de 2px.
- Deux mots au plus par onglet ; une icône 16px facultative ; le nombre d'éléments de l'onglet en petit après le libellé, facultatif (`.bn-onglet__compte`, « PNJ 7 » ; `compte` de `onglets()`).
- Jamais de défilement ni de retour à la ligne : une barre trop étroite se resserre d'elle-même (`onglets()` de `app/ui.js` mesure). D'abord les écarts (`.est-serree`), puis les libellés courts (`.est-courte` : un onglet peut porter `.bn-onglet__long` et `.bn-onglet__court`, « Édition » / « Édit »), enfin les icônes (`.sans-icones`).
- Usages typiques : fiche de PNJ (Résumé, Relations, Secrets, Apparitions), chapitres du module, jours de la campagne.
