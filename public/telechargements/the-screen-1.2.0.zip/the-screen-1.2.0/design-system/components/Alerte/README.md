Message encadré pour un rappel de MJ, un danger ou une confirmation : `.bn-alerte`.

**Le consommateur fournit** : une icône `.bn-icone`, un `.bn-alerte__titre` (court, en capitales par le CSS) et un `.bn-alerte__texte` (une ou deux phrases).

| Variante | Classe | Exemple |
| --- | --- | --- |
| Information (défaut) | `.bn-alerte` | « Le comte observe : un corbeau suit le groupe. » |
| Danger | `.bn-alerte--sang` | « Mirelle a été mordue deux fois. » |
| Avertissement | `.bn-alerte--cierge` | « Coucher du soleil dans 1 h. » |
| Confirmation | `.bn-alerte--brume` | « Séance 12 enregistrée. » |

- Bordure complète de la couleur, fond `*-voile`, texte en `os`.
- Repliable : `<details class="bn-alerte bn-alerte--repliable …">`, repliée d'office sur une ligne. Le `<summary>` contient l'icône, le `.bn-alerte__titre`, un repère à droite (un [DD](../DD/README.md), un badge comme « Fatigue +1 ») puis le chevron `.bn-alerte__chevron` (Lucide `chevron-down`, retourné à l'ouverture) ; le `.bn-alerte__texte` suit. Pour un rappel qui reste affiché longtemps (marche forcée, repos long en retard) : l'essentiel se lit replié.
- Une alerte = un fait et sa conséquence. Pas d'excuses, pas de points d'exclamation.
