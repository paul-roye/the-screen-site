Bloc de statistiques de créature au format D&D 5e : `.bn-stat` (un `<article>`).

**Le consommateur fournit** : `.bn-stat__nom` et `.bn-stat__type` dans un `<header>`, des `.bn-filet.bn-filet--sang` entre les blocs, un `<dl class="bn-stat__lignes">` (CA, PV, vitesse, sauvegardes, sens, langues, puissance), un `<dl class="bn-stat__carac">` de six caractéristiques (valeur puis modificateur en `<span>`), des `<p class="bn-stat__trait">` commençant par `<b>Nom.</b>`, et des `<h4 class="bn-stat__section">` (Actions, Réactions, Actions légendaires).

- Nom en Grenze Gotisch `sang` avec halo ; libellés en Barlow `sang` ; texte en Spectral.
- Formules de dés en `<span class="des">` (JetBrains Mono, `ultra`).
- Distances en pieds (30 ft), mètres et cases au survol, comme partout dans l'interface.
- Six caractéristiques sur une ligne, trois par ligne sous 480px.
- Largeur maximale 560px : un bloc se lit comme une page du Manuel des monstres.
