Conteneur principal d'un écran, à grands coins coupés : `.bn-panel`, avec `.bn-panel__tete`, `.bn-panel__corps` et `.bn-panel__pied` facultatif. Pour un élément plus petit dans un panneau : `.bn-carte`.

**Le consommateur fournit** : dans la tête, un `.bn-panel__titres` (un `surtitre` puis un `titre-m`) et des actions `.bn-btn--s` ; le contenu dans le corps.

- Fond `crypte`, bordure `trait`, coupe `coupe-l`.
- `.bn-panel--actif` : bordure `sang` et halo, pour le panneau qui exige l'attention (le combat en cours). Un seul par écran.
- `.bn-panel--magie` : bordure `ultra`, pour un effet magique ou une scène de rituel.
- `.bn-carte` : fond `pierre`, angle droit, bordure `trait` ; devient cliquable en `<a>` ou `<button>` (la bordure s'éclaircit au survol). Pour les PNJ, lieux, objets dans une grille.
- Ne pas imbriquer deux panneaux : à l'intérieur, utiliser des cartes.
