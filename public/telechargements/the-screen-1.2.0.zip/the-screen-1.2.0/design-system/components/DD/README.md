Un jet à faire, dé et difficulté dans un petit cadre coupé : `.bn-badge.bn-dd`.

**Le consommateur fournit** : l'icône `d20` puis le texte « DD 12 » (ou « DD 13/14 » pour plusieurs classes de lanceur), « DD » et le nombre séparés par une espace fine insécable (U+202F) : ils ne se séparent jamais ; « DD » dans un `.bn-dd__mot`, qu'un cadre vertical (dé au-dessus du nombre, cartes de personnage étroites) peut masquer. Et un `title` qui dit quel jet (« Jet de sauvegarde de Constitution de chaque héros ; échec : 1 niveau d'épuisement »).

- C'est un badge (`coupe-s`, 22px de haut) : bordure `trait-fort`, texte `os`, dé en `cierge`, chiffres tabulaires.
- Partout où le gestionnaire annonce un DD : dans une phrase, dans un bouton (« Marcher 1 h de plus » suivi du DD du jet qu'il entraîne), en repère d'une [alerte repliable](../Alerte/README.md), sur une carte de personnage (DD des sorts).
- Plusieurs jets à la suite : une pastille par DD.
- **Jet à lancer** (`.bn-dd--jet`, sur un `<button>`) : même pastille, bordure et dé en `ultra`, le bonus (« +4 ») ou la formule (« 1d6+2 ») à la place de « DD 12 » ; au survol, pleine `ultra`. Un clic fait rouler les dés (fiches de monstres : attaques, dégâts, sauvegardes, initiative ; le résultat s'affiche en `ultra`). Son `title` dit quel jet (« Morsure : jet d'attaque : lancer 1d20+4 »).
