Carte d'un lieu, en tête du widget Ici : sa description, son nom, ses sous-lieux et où sont les héros : `.bn-carte.bn-lieu`, resserrée (petites marges, lignes rapprochées, titre en 24px).

**Le consommateur fournit**, dans la [carte](../Panneau/README.md) :

1. `.bn-lieu__haut` : la description en `surtitre` (coupée en « … » sur une ligne), puis le repère « Les héros sont ici » (un [badge](../Badge/README.md) `.bn-lieu__ici`, resserré) à droite. Si la description ne tient pas sur une ligne avec lui, le consommateur pose `.est-repere-bas` sur la carte et déplace le repère en bas à droite : la description reprend toute la largeur, sur plusieurs lignes.
2. Dans un sous-lieu : `<button class="bn-lien bn-lieu__remonter">` au-dessus du titre (le nom du lieu entier, flèche vers le haut).
3. Le titre en `titre-m`, avec en option `.bn-lieu__tarokka` (l'icône du Tarokka quand la lecture place quelque chose ici).
4. `.bn-lieu__sous` : les sous-lieux en puces, `<button class="bn-badge bn-lieu__sous-lieu">` (icône 13px, texte en casse normale) ; un clic y descend. Celui où sont les héros porte `.est-ici` (bleu `brume`, l'épingle).
5. `.bn-lieu__bas` : la ligne du bas (dernière venue, « dans … » avec `.bn-lieu__dans`, le repère quand il est en bas), masquée quand elle est vide.

- Les héros sont dans ce lieu : la carte porte `.est-ici`, bordure `brume`.
- Les [onglets](../Onglets/README.md) qui suivent la carte (PNJ, Rencontres, Objets, Trame, Lieu) sont collés à elle par le gestionnaire.

Dans le gestionnaire : la carte du lieu de `app/widgets/ici.js` (placement du repère : `placerRepere()`).
