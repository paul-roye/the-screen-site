Un état d'un personnage (Aveuglé, Empoisonné, Épuisement…) : son icône dans une petite tuile sombre, `.bn-etat`, bordure et icône `cierge` (ce qui gêne le héros sans le mettre à terre). Le niveau de l'Épuisement en exposant, dans une pastille pleine.

**Le consommateur fournit** : l'icône (`<svg>` en `currentColor`) ou, à défaut, l'abréviation du nom dans `.bn-etat__court` (« Em », « Ép ») ; le niveau dans `<sup class="bn-etat__niveau">` ; le nom de l'état dans l'infobulle ou le libellé qui accompagne la tuile (la tuile seule est `aria-hidden` ou porte un `aria-label`). Dans le gestionnaire : `iconeEtat(etat, classe)` de `app/etats.js`, avec les icônes de D&D Beyond importées sur le poste (`icones-beyond/etats.json`, hors dépôt) ou l'abréviation.

| Classe | Taille | Usage |
| --- | --- | --- |
| `.bn-etat--s` | 18 px | dans un badge, un menu, une ligne |
| `.bn-etat` | 24 px (`--etat`) | sur un portrait |
| `.bn-etat--l` | 44 px | en tête de la fenêtre d'un état |

- Sur le portrait d'une carte de personnage, le consommateur règle `--etat` selon le nombre d'états (un seul plus grand ; au plus deux de front et quatre en tout) ; le fond presque opaque garde l'icône lisible sur l'image.
- Le néon reste discret (halo `cierge` léger) : la tuile signale, elle n'est pas l'élément actif.
- Les effets de l'état (texte long) s'ouvrent au clic, dans une fenêtre, jamais en infobulle.

**Encombrement** (règle variante de D&D Beyond), posé à côté des états sur le portrait : la même tuile, avec l'icône Lucide `weight`.

| Classe | Couleur | Sens |
| --- | --- | --- |
| `.bn-etat--encombre` | `cierge` (orange) | encombré (vitesse −10 ft) |
| `.bn-etat--lourd` | `sang` (rose), halo léger | lourdement encombré (vitesse −20 ft, désavantages) |

Dans le gestionnaire : `tuileEncombrement(fiche, nom)` de `app/etats.js`.
