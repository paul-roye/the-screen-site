Un petit choix qui s'ouvre sous un bouton, pour garder une ligne de commandes courte : le « + » de l'horloge ouvre +10 min, +30 min, +1 h, +4 h : `.bn-menu`.

**Le consommateur fournit** : le bouton déclencheur (souvent `.bn-btn--s.bn-btn--icone`, avec un `title` qui liste les choix), puis `<div class="bn-menu" popover="auto" role="menu">` avec un `<button class="bn-menu__choix" role="menuitem">` par choix. Dans le gestionnaire, `boutonMenu(bouton, choix, etiquette)` de `app/ui.js` relie les deux (`popovertarget`) et place le menu.

- Popover natif : un clic ailleurs ou Échap le referment, sans code. Il s'ouvre juste sous le bouton (au-dessus s'il manque de place), le premier choix prend le focus ; un choix fait son action et referme le menu.
- Surface `crypte`, bordure `trait-fort`, `ombre-panneau`. Choix en puces `pierre`, chiffres tabulaires ; au survol, bordure `sang`.
- Un menu qui choisit un état (le filtre par personnage du Déroulé) marque le choix en cours : `role="menuitemradio"` et `aria-checked="true"`, bordure et texte `sang` avec son halo ; il prend le focus à l'ouverture. Dans `boutonMenu()`, quatrième élément du choix : une fonction relue à chaque ouverture.
- Choix courts, sur une ligne (« +30 min ») ; au-delà de six, ce n'est plus un menu mais une liste dans le widget.
