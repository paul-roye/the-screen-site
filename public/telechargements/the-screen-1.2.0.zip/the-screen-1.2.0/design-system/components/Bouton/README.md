Bouton à coins coupés pour toute action : `.bn-btn` sur un `<button>` ou un `<a>`.

**Le consommateur fournit** : le libellé (verbe d'abord), une icône facultative `<svg class="bn-icone"><use href="#bn-…"/></svg>` avant le libellé, un `aria-label` si le bouton n'a qu'une icône.

| Variante | Classe | Quand |
| --- | --- | --- |
| Secondaire | `.bn-btn` | Actions courantes. |
| Primaire | `.bn-btn--primaire` | L'action principale de l'écran, une seule visible à la fois (« Tour suivant », « Lancer le combat »). |
| Magie | `.bn-btn--magie` | Lancer un sort, effet magique. |
| Danger | `.bn-btn--danger` | Tuer, supprimer, retirer du combat. |
| Fantôme | `.bn-btn--fantome` | Annuler, actions tertiaires dans une barre d'outils. |
| Petit | `.bn-btn--s` | En-têtes de panneau, lignes de tableau. |
| Icône | `.bn-btn--icone` | Carré 40px (32px avec `--s`). |

- Grouper avec `.bn-groupe` (flex, écart `space-2`).
- `disabled` ou `aria-disabled="true"` éteint la lueur.
- Ne jamais mettre deux primaires côte à côte.
- **Bascule** (choix entre deux ou trois états, « Jour / Nuit ») : des `.bn-btn--s` dans un `.bn-bascule` (`role="group"`), chacun avec `aria-pressed`. L'état enfoncé prend la bordure `sang` sur fond voilé, sans halo ; les autres passent en `cendre`.
