Liste d'ordre de combat, une ligne par combattant, tour en cours illuminé : `.bn-init` (un `<ol>`) contenant des `.bn-init__ligne`.

**Le consommateur fournit**, par ligne : `data-camp` (`pj`, `allie` ou `ennemi`), `.bn-init__score` (initiative), `.bn-init__qui` avec `.bn-init__nom` et `.bn-init__meta` (commençant par `.bn-init__camp`, puis badges de condition, actions légendaires, concentration), `.bn-init__ca` (icône `bouclier` + valeur) et une `.bn-pv.bn-pv--mini`.

- Tour en cours : `aria-current="true"` sur la ligne (bordure `sang`, `lueur-sang`, score en néon). Une seule ligne à la fois.
- Portraits : `.bn-init--portraits` sur la liste, et un `.bn-init__portrait` (image, sinon une initiale ou une icône) juste après le score.
- Combattant hors de combat : classe `est-mort` (ligne atténuée, nom barré).
- Héros mort (trois jets contre la mort ratés) : classe `est-decede` (portrait éteint, nom barré), le repère `.bn-mort` (JetsMort) à la place de la CA et des PV ; il ne joue plus.
- Héros à terre (0 PV) : classe `est-inconscient` (voile `sang`, nom en `sang`, sans cadre : un cadre `sang` désigne le tour en cours), ses jets contre la mort (JetsMort) à la place de `.bn-init__ca`.
- Le camp se lit par le mot (« PJ », « Allié », « Ennemi ») et un losange de couleur : `brume`, `cierge`, `sang`.
- Sous 560px, la jauge de PV passe sous le nom.
- Placer la liste dans un `.bn-panel--actif` avec « Tour suivant » en bouton primaire dans la tête.
