Jets contre la mort d'un héros à 0 PV, dans un petit cadre : `.bn-jds`. À gauche les réussis, à droite les ratés, trois losanges chacun, un crâne entre les deux. Chaque série se remplit depuis le crâne vers le bord.

**Le consommateur fournit** : deux `.bn-jds__serie` (`--reussis` puis `--rates`) de trois `.bn-jds__pas`, `est-fait` sur les premiers (autant que de jets faits : le CSS met le premier losange de chaque série contre le crâne), l'icône `crane` entre les deux (`coeur` s'il est stabilisé), `data-etat` au besoin, et `role="img"` avec un `aria-label` qui dit le compte (« Jets contre la mort : 1 réussi, 2 ratés »). Dans le gestionnaire : `jetsContreLaMort({ succes, echecs, stabilise })` de `app/ui.js`.

| `data-etat` | Quand | Rendu |
| --- | --- | --- |
| (absent) | à terre, jets en cours | cadre et voile `sang`, crâne `sang` |
| `stabilise` | stabilisé | cadre et voile `soleil`, cœur `soleil` |
| `mort` | trois échecs | fond `sang-profond`, crâne `os` |

- Réussis en `soleil` (jaune clair, la lumière divine ; demande du MJ, 2026-10-20), ratés en `sang`, avec un halo léger ; un losange vide est un simple contour.
- Il prend la place de la CA quand un héros tombe : dans l'ordre de combat (Initiative, ligne `est-inconscient`) et sur une carte de personnage.
- Stabilisé : trois jets réussis, ou l'état noté sur la fiche ; `jetsContreLaMort()` passe alors `data-etat="stabilise"` d'office.
- **Mort** (trois échecs) : plus de cadre de jets, ni de PV, ni d'état « Inconscient » : le repère `.bn-mort` (crâne et « Mort », fond `sang-profond`, bordure et halo `sang`) à leur place, `.bn-mort--grand` sur une carte de personnage (sa barre de PV, ses valeurs et ses pouvoirs disparaissent). Dans l'ordre de combat, la ligne `est-decede` (portrait éteint, nom barré) : le héros ne joue plus. Dans le gestionnaire : `marqueMort({ grand })` de `app/ui.js`.
