Encadré de texte à lire à voix haute aux joueurs : `.bn-alire` (un `<figure>`).

**Le consommateur fournit** : un `<figcaption class="bn-alire__label">` (icône `livre` + « À lire à voix haute ») et un ou plusieurs `<p>`.

- Spectral 19/30 sur `pierre` : lisible d'un coup d'œil pendant la séance.
- Quatre équerres `sang` aux coins au lieu d'une bordure complète.
- 72 caractères par ligne au plus ; trois paragraphes au plus.
- Uniquement pour ce que le MJ lit tel quel. Les notes de MJ restent en `texte` dans une carte.
- Le texte doit être le vôtre ou un résumé : ne pas recopier les encadrés du livre.
