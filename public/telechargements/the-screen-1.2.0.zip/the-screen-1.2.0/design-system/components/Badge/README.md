Étiquette courte à coins coupés pour un état, une condition ou une faction : `.bn-badge`.

**Le consommateur fournit** : un mot ou deux (« Charmé », « Ensanglanté », « Hostile »), une icône facultative en tête.

- Couleurs : `--sang` (danger, hostile, blessure), `--ultra` (magie, charme, concentration), `--brume` (stable, allié, réussite), `--cierge` (avertissement, poison, peur), `--soleil` (sacré, plein soleil). Sans modificateur : neutre, en `cendre`.
- `--plein` : aplat du néon et texte `sur-accent`, pour un seul badge fort par ligne (« Boss »).
- Faction : `.bn-badge--faction` avec `style="--fac: var(--fac-vistani)"` et un `<span class="bn-badge__point"></span>` avant le nom.
- Le mot porte le sens ; la couleur ne fait que le confirmer.
- Conditions D&D en français : À terre, Agrippé, Assourdi, Aveuglé, Charmé, Effrayé, Empoisonné, Entravé, Étourdi, Incapable d'agir, Inconscient, Invisible, Paralysé, Pétrifié, Épuisement 1–6.
