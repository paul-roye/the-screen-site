Lettre manuscrite d'un personnage ou handout papier : `.bn-lettre` (un `<article>`).

**Le consommateur fournit** : `.bn-lettre__salut`, un `.bn-lettre__corps` en paragraphes, une `.bn-lettre__signature` contenant le nom puis `<span class="bn-lettre__titre">` (« Seigneur de Valombre »).

- Papier `velin` et `encre` identiques dans les deux thèmes : c'est un objet de la fiction.
- Salutation et signature en écriture manuscrite (`--font-script` : 1805 Austerlitz Script installée localement, repli Pinyon Script).
- Corps en Spectral italique pour rester lisible. `.bn-lettre--manuscrite` passe le corps en script : trois lignes au plus.
- `ombre-panneau` et grain de papier ; à afficher seule, centrée, sur fond `void`.
- Rédiger ses propres lettres ; ne pas recopier les handouts du livre.
