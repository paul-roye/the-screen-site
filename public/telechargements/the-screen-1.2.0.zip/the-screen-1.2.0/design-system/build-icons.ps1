﻿# Génère, depuis icons/icons.json : icons/<nom>.svg, le sprite icons.svg et icons.js.
# Usage : powershell -ExecutionPolicy Bypass -File .\build-icons.ps1
#         ... -InkDir <dossier> -Ink '#ff2d6f'   (copies à encre fixe, pour <img> ou outils externes)
param(
    [string]$InkDir,
    [string]$Ink = '#ff2d6f'
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$utf8 = New-Object Text.UTF8Encoding $false
$icons = [IO.File]::ReadAllText((Join-Path $root 'icons\icons.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json
$names = @($icons.PSObject.Properties | ForEach-Object Name)
$g = 'fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"'

$symbols = foreach ($n in $names) {
    $body = $icons.$n
    $file = "<svg xmlns=`"http://www.w3.org/2000/svg`" width=`"24`" height=`"24`" viewBox=`"0 0 24 24`" $g>$body</svg>`n"
    [IO.File]::WriteAllText((Join-Path $root "icons\$n.svg"), $file, $utf8)
    if ($InkDir) {
        New-Item -ItemType Directory -Force -Path $InkDir | Out-Null
        [IO.File]::WriteAllText((Join-Path $InkDir "$n.svg"), $file.Replace('currentColor', $Ink), $utf8)
    }
    "<symbol id=`"bn-$n`" viewBox=`"0 0 24 24`"><g $g>$body</g></symbol>"
}
$sprite = "<svg xmlns=`"http://www.w3.org/2000/svg`" style=`"display:none`">`n" + ($symbols -join "`n") + "`n</svg>`n"
[IO.File]::WriteAllText((Join-Path $root 'icons.svg'), $sprite, $utf8)

# icons.js : injecte le sprite dans la page (fonctionne aussi en file://, contrairement à <use href="icons.svg#...">)
$js = @"
/* Barovie Néon — icônes. Généré par build-icons.ps1, ne pas éditer à la main. */
(function () {
  var sprite = $(ConvertTo-Json $sprite -Compress);
  var names = $(ConvertTo-Json $names -Compress);
  function inject() {
    if (document.getElementById('bn-sprite')) return;
    var holder = document.createElement('div');
    holder.id = 'bn-sprite';
    holder.hidden = true;
    holder.innerHTML = sprite;
    document.body.insertBefore(holder, document.body.firstChild);
  }
  if (document.body) inject(); else document.addEventListener('DOMContentLoaded', inject);
  /* BN.icone('cierge', { taille: 20, titre: 'Lumière' }) -> chaîne SVG à insérer */
  function icone(nom, opts) {
    opts = opts || {};
    var t = opts.taille || 20;
    var a11y = opts.titre ? 'role="img" aria-label="' + opts.titre + '"' : 'aria-hidden="true"';
    return '<svg class="bn-icone ' + (opts.classe || '') + '" width="' + t + '" height="' + t + '" ' + a11y + '><use href="#bn-' + nom + '"/></svg>';
  }
  window.BN = window.BN || {};
  window.BN.icones = names;
  window.BN.icone = icone;
})();
"@
[IO.File]::WriteAllText((Join-Path $root 'icons.js'), $js, $utf8)
Write-Host "$($names.Count) icônes générées"
