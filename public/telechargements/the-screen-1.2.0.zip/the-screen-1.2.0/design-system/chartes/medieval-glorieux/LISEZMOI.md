# Charte Médiéval glorieux

Bannières, or et azur : une campagne de chevalerie, de tournois et de cours royales (la campagne témoin, par exemple). Deux thèmes comme Barovie Néon : **Nuit** (bleu nuit héraldique, ivoire et or) et **Parchemin** (vélin clair, encre bleue).

- Mêmes composants `bn-*` que Barovie Néon, mêmes noms de jetons (ils servent de rôles : `sang` est l'accent et le danger, ici le rouge de gueules ; `soleil` l'or ; `brume` l'azur ; `mousse` le sinople).
- **Pas de néon** : le titre est gravé d'or et ne grésille pas, les lueurs deviennent un éclat doux en Nuit et disparaissent en Parchemin.
- **Coins droits** (`coupe-*` à 0) au lieu de la coupe de cercueil ; un liseré d'or en haut des panneaux.
- Polices : Cinzel (titres, capitales romaines), Alegreya Sans (interface), EB Garamond (lecture), JetBrains Mono (dés), Pinyon Script (lettres). Google Fonts, chargées par `charte.css`.

Fichiers : `tokens.json` (la source), `tokens.css` (généré : `powershell -ExecutionPolicy Bypass -File design-system\build-tokens.ps1 -Source design-system\chartes\medieval-glorieux\tokens.json -Out design-system\chartes\medieval-glorieux\tokens.css`, qui vérifie aussi les contrastes), `charte.css` (polices et effets). Une campagne la choisit par `"charte": "medieval-glorieux"` dans son manifeste.
