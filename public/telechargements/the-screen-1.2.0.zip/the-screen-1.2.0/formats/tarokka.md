# `data/tarokka.json` — format 1

Le jeu de Tarokka et la lecture de madame Éva. Lu par le widget **Tarokka**.

Conventions communes (enveloppe, provenance, écarts, identifiants) : [README.md](README.md).

## Le cas de la campagne : tirage préparé

Le MJ prépare la lecture avant la séance : une carte prévue par place, les deux paquets rangés dans l'ordre (l'ordre est donné par un écart de `deroulement`). Il n'y a pas de tirage au hasard.

- `places[].significations` ne contient **que les cartes prévues** : une par place, plus une éventuelle carte de secours qui donne le même résultat (l'allié : l'Artefact, et le Donjon en secours).
- Chaque signification porte la prophétie à lire, `a_lire`, **fournie par l'export** (rédigée par l'agent IA de campagne d'après les décisions du MJ, jamais recopiée du livre).
- **Règle de lecture** : quand une place n'a de significations que pour une partie de son paquet (moins de 40 pour le jeu commun, moins de 14 pour le haut jeu), ce sont ses cartes prévues, dans l'ordre du tableau. La première est posée d'office ; les suivantes sont des cartes de secours, que le MJ sélectionne en un clic au moment de la révélation. L'ordre des `significations` compte donc.
- Le tirage s'affiche ainsi dès l'ouverture, sans rien saisir, face cachée ; un clic retourne une carte, un autre ouvre sa prophétie (encadré « À lire à voix haute ») dans une fenêtre.
- Si une autre carte a été posée à la table, le MJ la note dans l'onglet Édition (enregistré dans `etat/tarokka.json`) ; elle prime sur la carte prévue.
- Une carte notée qui n'a pas de signification n'est **pas une erreur** : le widget affiche « Carte non prévue » et rappelle la ou les cartes prévues pour la place.

Le format accepte aussi d'autres façons de mener la lecture : significations complètes pour les 54 cartes (tirage au hasard), résultat fixé lu quelle que soit la carte (`resultat_fixe`), idées de prophétie à composer (`idee_prophetie`, `lectures_focos`), tirages personnels. Ces champs sont facultatifs ; ils sont décrits plus bas.

## Vue d'ensemble

```json
{
  "schema": 1,
  "jeu": "tarokka",
  "titre": "Le Tarokka de madame Éva",
  "genere_le": "2026-10-09",
  "avertissement": "…",
  "priorite_sources": ["MJ", "FOCoS", "CoS-VF"],
  "sources": { "CoS-VF": { "nom": "…", "fiche": "…" } },
  "deroulement": { },
  "cartes": [ ],
  "places": [ ]
}
```

Facultatifs au premier niveau : `conditions`, `couleurs`, `tirages_personnels`.

Le widget a quatre onglets : **Tirage** (`places`), **Joueurs** (`tirages_personnels`), **Édition** (cartes réellement posées, validation) et **Déroulement**. Le déroulement est **calculé** d'après le tirage (cartes prévues, ou notées dans Édition) : ordre des deux paquets (lecture principale, puis tirages personnels, un personnage après l'autre dans l'ordre de `personnages`), cartes de secours à part, croix de la lecture (places 1 à gauche, 2 en haut, 3 à droite, 4 en bas, 5 au centre, d'après `ordre`) et étapes. Une grande fenêtre (« La table de madame Éva ») montre les cartes à leur place, en croix ou par joueur.

## `deroulement` (conseillé)

Comment mener la lecture. L'onglet Déroulement affiche `resume`, puis ce qu'il calcule d'après le tirage ; les `etapes` sont repliées sous « Selon le livre », les écarts sous « Décisions et écarts ».

| Champ | Type | Contenu |
|---|---|---|
| `resume` | chaîne | Deux ou trois phrases. |
| `etapes` | chaînes | Étapes dans l'ordre (séparer les paquets, poser les cartes, les retourner…), telles que le livre les donne. |
| `source`, `fiche`, `pages_livre`, `ecarts` | | Comme partout. Pour un tirage préparé, un écart `MJ` au statut `applique` donne l'ordre des paquets et la carte de secours. |

## `cartes` (obligatoire)

Les 54 cartes, même si seules quelques-unes sont prévues : la saisie les propose toutes.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Jeu commun : `<couleur>-<rang>` (`epees-1` … `epees-9`, `epees-maitre`). Haut jeu : le nom VF sans article (`brumes`, `homme-brise`). |
| `nom` | oui | Nom VF avec article (« L'Homme brisé »). |
| `nom_vo` | conseillé | Nom anglais (« Broken One »), pour s'y retrouver avec les illustrations. |
| `paquet` | oui | `commun` ou `haut`. |
| `suite` | oui | `epees`, `etoiles`, `pieces`, `glyphes` ; `null` pour le haut jeu. |
| `rang` | oui | `1` à `9` (nombre) ou `"maitre"` ; `null` pour le haut jeu. |
| `icone` | non | Haut jeu : une icône de la charte pour l'emblème (`brume`, `corbeau`, `oeil`, `loup`…, liste dans `design-system/icons/icons.json`). Sinon l'emblème `tarokka`. |
| `image` | non | Chemin de l'illustration depuis la racine du gestionnaire, par ex. `images-library/Curse of Strahd/Illustrations/23-appendix-e-the-tarokka-deck/21-011.mists.png`. Plus affichée par le widget (le MJ préfère le visuel de carte de la charte) ; sert à la bibliothèque d'images. |
| `description` | non | Une phrase : ce que montre ou symbolise la carte. |
| `carte_a_jouer` | non | Équivalent dans un jeu classique (« As de pique », « Joker 1 »). |
| `source`, `fiche` | oui | |

## `places` (obligatoire)

Les places de la lecture, dans l'ordre où madame Éva pose les cartes.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | `tome`, `symbole`, `epee`, `allie`, `strahd`. Stable : les cartes notées dans `etat/` s'y réfèrent, même si le libellé change. |
| `ordre` | oui | 1, 2, 3… |
| `nom` | oui | Libellé au-dessus de la carte (« Le Livre de Strahd », « Le Symbole sacré », « L'Épée solaire », « L'Allié », « Strahd »). |
| `paquet` | oui | Paquet dont sort la carte : `commun` ou `haut`. La saisie ne propose que ces cartes. |
| `role` | conseillé | Une phrase : ce que cette place révèle. Affichée pendant la saisie. |
| `libelle_suivi` | non | Case à cocher affichée avec la révélation : « Trouvé », « Trouvée », « Recruté ». Sans ce champ, pas de case. |
| `regles` | non | Chaîne ou tableau de chaînes : règles propres à la place. |
| `source`, `fiche`, `pages_livre`, `ecarts` | oui | Écarts qui touchent la place entière (affichés repliés). |
| `significations` | oui | Les cartes prévues pour cette place (tirage préparé), ou toutes les cartes possibles (tirage au hasard). Au moins une. |
| `resultat_fixe` | non | Variante « résultat lu quelle que soit la carte » (voir plus bas). |
| `lectures_focos` | non | Idées de Fleshing Out pour composer une prophétie (voir plus bas). |

### `places[].significations[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `carte` | oui | `id` d'une carte du bon `paquet`. Une seule entrée par carte et par place. Deux entrées à la même place = carte prévue et carte de secours ; dans ce cas, le `titre` de la seconde le dit (« … (carte de secours) »). |
| `titre` | oui | Le résultat en quelques mots, affiché en grand (« Au fond du bassin du Soleil blanc », « Rudolph Van Richten »). |
| `texte` | oui | Pour le MJ : où exactement, comment le trouver, à quelle condition. Trois phrases au plus. |
| `a_lire` | oui pour un tirage préparé | La prophétie de madame Éva, à lire telle quelle. Paragraphes séparés par une ligne vide (`\n\n`), trois au plus. Affichée dans l'encadré « À lire à voix haute ». |
| `lieu` | non | Lieu lisible (« Krezk, bassin du Soleil blanc »). |
| `zone` | non | Code de zone du livre (`"S4"`, `"K85"`). |
| `renvois` | non | Chaînes : où lire la suite (« Chap. 8, le village de Krezk »). |
| `idee_prophetie` | non | L'idée de la prophétie, quand elle n'est pas rédigée en `a_lire`. |
| `options` | non | Carte à deux résultats (A ou B) : `[{ id: "A", titre, lieu, zone, texte }]`. Le MJ en retient un dans le widget. |
| `pages_livre` | non | |
| `source`, `fiche`, `ecarts` | oui | Tirage préparé : `source` vaut `MJ`, `ecarts` est vide. |

## Champs facultatifs pour d'autres façons de mener la lecture

### `places[].resultat_fixe`

Résultat choisi par le MJ et lu **quelle que soit la carte** (« tirage rapide » de Fleshing Out). Présent, il prime sur `significations` : c'est lui que la carte révèle.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `titre` | oui | Affiché en grand et sur la face de la carte. |
| `texte` | oui | Pour le MJ. |
| `lieu`, `zone` | non | |
| `idee_prophetie` | conseillé | L'idée que madame Éva doit faire passer. |
| `consequences` | non | Ce que ce choix change pour la campagne. |
| `cartes_coherentes` | non | `id` des cartes qui disent la même chose. Si l'une d'elles est notée, le widget affiche « La carte coïncide ». |
| `source`, `fiche`, `date` | oui | |

### `places[].lectures_focos`

`{ usage, pnj: [{ nom, idee }], lieux: [{ nom, idee }], source, fiche, pages_pdf }`. Affiché replié ; l'entrée dont le `nom` apparaît dans le résultat fixé est marquée « Retenu ».

### `couleurs`

`[{ id, nom, domaine?, carte_a_jouer? }]`, `id` parmi `epees`, `etoiles`, `pieces`, `glyphes`. Sans ce tableau, le gestionnaire utilise Épées, Étoiles, Pièces, Glyphes et Haut jeu. `carte_a_jouer` (« Piques ») s'affiche dans l'onglet Déroulement.

### `tirages_personnels`

Les tirages personnels de Fleshing Out : après la lecture principale, deux cartes pour chaque personnage, lectures préparées par le MJ. Absent, l'onglet Joueurs le dit simplement.

Tirage préparé : chaque lecture donne sa `carte`, la carte rangée dans le paquet pour elle ; l'ordre complet des paquets (lecture principale, puis tirages personnels) est donné par l'écart `MJ` de `deroulement`. Une même carte ne sert qu'une fois en tout, lecture principale et cartes de secours comprises.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | oui | Comment se déroulent ces tirages. |
| `cartes` | oui | Les emplacements tirés pour chaque personnage : `[{ id, ordre, nom, paquet, role }]`, par ex. `tourment` (jeu commun) et `voie` (haut jeu). |
| `conseils` | non | Chaînes. |
| `personnages` | oui | Un objet par personnage joueur (ci-dessous). Tableau vide tant que les lectures ne sont pas prêtes. |
| `source`, `fiche`, `pages_pdf`, `ecarts` | oui | |

`tirages_personnels.personnages[]` :

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | L'`id` du personnage dans `personnages.json` (`isolde`, `bertrand-de-vauclair`…). Stable. |
| `nom` | oui | Nom du personnage. |
| `joueur` | non | Prénom du joueur, affiché en surtitre. |
| `quete` | conseillé | Une phrase : le tourment ou la quête personnelle. |
| `lectures` | oui | Objet dont les clés sont les `id` de `tirages_personnels.cartes`. Chaque lecture : `titre` (obligatoire), `carte` (facultatif : `id` d'une carte du paquet de l'emplacement ; affichée sur la face au lieu de « Fixé »), `texte`, `a_lire` ou `idee_prophetie`, `lieu`, `zone`, `ecarts`. Une lecture absente reste une carte grisée. |
| `source`, `fiche`, `ecarts` | oui | |

## Exemple réduit

Contenu factice, pour la forme seulement : une place avec sa carte prévue et une carte de secours.

```json
{
  "schema": 1,
  "jeu": "tarokka",
  "titre": "Le Tarokka de madame Éva",
  "genere_le": "2026-10-09",
  "avertissement": "Fichier généré par l'agent IA de campagne. Ne pas le modifier à la main.",
  "priorite_sources": ["MJ", "FOCoS", "CoS-VF"],
  "sources": { "MJ": { "nom": "Décisions du MJ", "fiche": "campagne/Decisions-du-MJ.md" } },
  "deroulement": {
    "resume": "…", "etapes": ["…"], "source": "CoS-VF", "fiche": "…",
    "ecarts": [{ "source": "MJ", "fiche": "…", "sujet": "Cartes préparées d'avance", "texte": "Ordre des paquets : …", "original": "Paquets mélangés.", "statut": "applique" }]
  },
  "cartes": [
    { "id": "artefact", "nom": "L'Artefact", "nom_vo": "Artifact", "paquet": "haut", "suite": null, "rang": null, "source": "CoS-VF", "fiche": "…" },
    { "id": "donjon", "nom": "Le Donjon", "nom_vo": "Donjon", "paquet": "haut", "suite": null, "rang": null, "source": "CoS-VF", "fiche": "…" }
  ],
  "places": [
    {
      "id": "allie", "ordre": 4, "nom": "L'Allié", "paquet": "haut", "role": "…", "libelle_suivi": "Recruté",
      "source": "CoS-VF", "fiche": "…", "ecarts": [],
      "significations": [
        { "carte": "artefact", "titre": "…", "texte": "…", "lieu": "…", "zone": "…",
          "a_lire": "Premier paragraphe.\n\nSecond paragraphe.", "source": "MJ", "fiche": "…", "ecarts": [] },
        { "carte": "donjon", "titre": "… (carte de secours)", "texte": "…",
          "a_lire": "…", "source": "MJ", "fiche": "…", "ecarts": [] }
      ]
    }
  ]
}
```

## Contrôles faits par le gestionnaire

À l'ouverture, le bouton **Données** signale :

- `schema` différent de 1 (fichier refusé) ou `jeu` différent de `tarokka` ;
- `cartes` ou `places` vide ;
- carte au `paquet` ou à la `suite` inconnus ;
- signification qui vise une carte inexistante, ou une carte d'un autre paquet que celui de la place, ou deux fois la même carte ;
- `resultat_fixe` sans `titre`, ou carte cohérente inexistante ;
- tirages personnels : emplacements absents, personnage sans `id` ou `nom` ou en double, lecture dont la clé n'est pas un emplacement, `carte` inexistante ou d'un autre paquet que l'emplacement, carte prévue deux fois (lecture principale et tirages personnels) ;
- écart au statut inconnu, `conditionnel` sans `condition`, `a_trancher` sans `question`.

Une carte sans signification à une place n'est pas un problème de format : le widget affiche « Carte non prévue » si elle est notée.
