# `data/factions.json` — format 1

Les factions, peuples et groupes de la campagne : la cour du roi, ses agents, les marchands nomades, un ordre de chevalerie, la noblesse, une meute de loups-garous… Référentiel commun : [pnj.json](pnj.md) (champ `factions`) et [connaissances.json](connaissances.md) (champ `factions` des groupes) y renvoient par `id`.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, `decision_mj`, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | conseillé | Ce que contient le fichier. |
| `types` | oui | `{ "<id de type>": "Libellé" }` : `puissance`, `reseau`, `peuple`, `organisation`, `meute`, `rang`, `culte`, `assemblee`. |
| `factions` | oui | Voir ci-dessous. |

### `factions[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `nom` | oui | `id` stable, cité par `pnj.json` et `connaissances.json`. |
| `type` | oui | Une clé de `types`. |
| `description` | oui | Qui en fait partie, ce qu'elle veut, comment elle pèse sur l'intrigue. |
| `secret` | non | `true` : la faction elle-même est un secret de campagne (une société secrète). Le MJ la voit ; ne jamais la montrer côté joueurs, et la masquer par défaut (badges des PNJ compris) tant que le MJ ne demande pas à la voir. |
| `couleur` | non | La couleur de sa pastille : un jeton de la charte (`fac-zarovich`, `cierge`, `ultra`…). Sans elle, le manifeste de la campagne peut en donner une (`couleurs_factions`, voir [campagne.md](campagne.md)) ; sinon la pastille reste neutre. Facultatif, ajouté le 2026-10-24 : le format ne change pas. |
| `lieux` | oui | `id` de [lieux.json](lieux.md) où elle est présente (tableau vide si elle est partout ou nulle part de précis). |
| `original`, `decision_mj` | non | Voir [README.md](README.md). |
| `source`, `fiche` | oui | |

Les **membres** ne sont pas listés ici : ce sont les PNJ dont `factions` contient l'`id` de la faction. Un PNJ peut appartenir à plusieurs factions (la vieille diseuse : `nomades` et `societe-secrete`).

## Ce que peut faire un widget

Widget **Factions** : par type, description, lieux, membres triés par `rang` (fiche du PNJ au clic) ; case « Afficher les factions secrètes ». Widget **PNJ** : filtre « Faction », badge de faction sur chaque PNJ. **Qui sait quoi** : dans le détail d'un groupe, ses factions et leurs membres qui ont des `savoirs` (« À qui demander »). Pastilles de couleur (`--fac-*` de la charte) pour les factions qui en ont une (`couleur`, ou `couleurs_factions` du manifeste) ; cendre pour les autres.

## Contrôles

`id` uniques ; `type` connu ; chaque `lieux[]` existe dans `lieux.json` ; chaque faction citée par `pnj.json` ou `connaissances.json` existe ici.
