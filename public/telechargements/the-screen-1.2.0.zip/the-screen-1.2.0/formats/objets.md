# `data/objets.json` — format 1

Les objets que les héros peuvent trouver ou recevoir pendant la campagne : objets magiques, équipement notable, trésors (gemmes, objets d'art), documents (lettres, journaux, cartes), clés. Lu par le module des objets (`app/objets.js`) : widget **Objets**, et les fenêtres des lieux (widget **Ici**), des jalons et des étapes (**Déroulé**) et des rencontres (préparation d'une rencontre). Le **Déroulé** alerte quand on termine un jalon ou une étape dont des objets n'ont pas été donnés.

Pour chaque objet, le MJ le relie à un objet de D&D Beyond (recherche dans le catalogue, d'après `nom_en`) ou le garde en objet personnalisé, puis le **donne** : il va dans l'inventaire D&D Beyond d'un héros ou dans celui du groupe (extension `extensions/mj/`). Ce qu'en fait le MJ (retouches, objet de D&D Beyond choisi, dons) va dans `etat/objets.json` ([etat.md](etat.md)) ; ce fichier n'est jamais modifié.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, `decision_mj`, pas d'`ecarts`).

## Ce qu'il faut y mettre (règle de contenu)

- **Toute la campagne** : chaque source (le livre, un supplément, les décisions du MJ), lieu par lieu et rencontre par rencontre. Les butins des rencontres scénarisées (`butin` de `rencontres-aleatoires.json`), les trésors des lieux (zones du livre), les récompenses des PNJ, les objets des quêtes, les documents à lire ou à remettre.
- **Un objet par chose qu'on peut donner** : l'Épée du serment, la lettre du bourgmestre, une potion de soins. Plusieurs exemplaires identiques au même endroit : un seul objet et sa `quantite` (« 3 potions de soins »). Un lot hétéroclite (« six tas de trésor ») se découpe en objets quand chacun compte ; sinon un seul objet « Trésor de … », avec le détail dans `description`.
- **Pas les pièces de monnaie** (pc, pa, pe, po, pp) : elles restent dans le `butin` des rencontres et dans les textes. Gemmes, bijoux et objets d'art, si : ce sont des objets (`genre` `tresor`, `valeur`).
- **Pas les babioles** (`babioles.json`), sauf une babiole précise que le livre place à un endroit.
- Ce qui ne sert qu'au décor et qu'on ne peut pas emporter n'est pas un objet.
- Avec le module Tarokka (*Curse of Strahd*), les objets de la lecture : à l'endroit que donne la **lecture préparée** (`tarokka.json`), avec `tarokka`. Le gestionnaire ne relit pas ce lieu dans `tarokka.json` : si la lecture préparée change, réexporter aussi `objets.json`.
- Les objets des quêtes personnelles des héros : avec `personnage`, et toujours un `jalon`, une `etape` ou une `rencontre` (le moment où ils doivent être remis).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | non | Ce que contient le fichier, et ce qui manque encore. |
| `genres` | non | Libellé de chaque `genre` utilisé, s'il faut l'expliquer (`{ "document": "Lettres, journaux, cartes" }`). |
| `objets` | oui | Voir ci-dessous. Tableau, dans l'ordre de la campagne de préférence. |

### `objets[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant stable (`epee-du-serment`, `lettre-du-bourgmestre`). Plusieurs objets du même nom à des endroits différents : un `id` chacun (`potion-de-soins-moulin`, `potion-de-soins-manoir`). |
| `nom` | oui | Le nom officiel de la VF (« Épée du serment »), ou un nom court et clair pour un objet sans nom (« Lettre du baron à sa sœur »). |
| `nom_en` | conseillé | Le nom **anglais**, tel que D&D Beyond le nomme quand l'objet y existe (« Sun Blade », « Potion of Healing (Greater) », « Rope », « Longsword, +1 », « Elixir of Health » ; règles 2024 de préférence : « Crossbow, Hand », « Leather », « Plate, +2 », « Hooded Lantern », « Stone of Good Luck (Luckstone) »), sinon le nom anglais du livre ou du supplément (« Letter from the Baron to his Sister »). C'est lui que le gestionnaire cherche dans le catalogue de D&D Beyond. Jamais le nom d'un objet **générique** que D&D Beyond n'ajoute pas tel quel, mais sa variante : « Silvered Dagger » (pas « Silvered Weapon »), « Gray Bag of Tricks », « Scroll of Protection (Undead) ». |
| `nom_joueurs` | non | Le nom que voient les joueurs tant qu'ils ne savent pas ce qu'est l'objet (« Garde d'épée en platine »). Pour un objet dont la nature est un secret que le texte de D&D Beyond dévoilerait (Épée solaire, objet maudit…) : le MJ le donne d'abord en objet personnalisé (`nom_joueurs`, `description`), puis l'objet de D&D Beyond quand les héros l'ont identifié. |
| `beyond` | oui | `true` : l'objet existe dans le catalogue de D&D Beyond sous `nom_en` (équipement du Manuel des joueurs, objet magique du Guide du maître, objet du livre de l'aventure) ; le gestionnaire le cherche d'office. `false` : objet propre à la campagne (lettre, clé, trésor unique, objet d'un supplément), ajouté en objet personnalisé. |
| `genre` | oui | `magique`, `equipement` (armes, armures, outils, matériel, potions ordinaires…), `tresor` (gemme, bijou, objet d'art), `document` (lettre, journal, carte, livre), `cle` ou `autre`. |
| `rarete` | non | Pour un objet magique, l'un des cinq niveaux du SRD en VF, toujours au masculin : `courant`, `peu courant`, `rare`, `très rare`, `légendaire` (« peu courant » même pour une lance). |
| `harmonisation` | non | `true` : il demande un lien (harmonisation). |
| `maudit` | non | `true` : l'objet est maudit (le détail dans `effets`). |
| `quantite` | non | Nombre d'exemplaires, en chaîne de dés (`"1"`, `"3"`, `"2d4"`). Absent : 1. |
| `poids` | non | Poids d'**un** exemplaire, en **livres**, nombre **entier** (D&D Beyond refuse les décimales pour un objet personnalisé) : `0` pour une lettre, `3`, `10`. Le livre VF donne des kg : 1 lb = 0,5 kg, donc kg × 2, arrondi à l'entier le plus proche. Sert à l'objet personnalisé de D&D Beyond. Absent : D&D Beyond n'en compte pas. |
| `valeur` | non | Ce qu'il vaut, tel qu'on l'annonce (`"250 po"`, `"750 po pièce"`). |
| `cout` | non | Valeur marchande d'**un** exemplaire, en **po**, nombre **entier** (`25`, `750`) : le coût de l'objet personnalisé sur D&D Beyond. Pour les objets propres à la campagne (`beyond: false`) qui se vendent ; absent pour un objet sans prix (lettre, clé, objet de quête, âme…). Une valeur inférieure à 1 po compte pour 1. Pour un lot (« Trésor de … »), la valeur du lot entier. |
| `cout_estime` | non | `true` : `cout` est une estimation, la source ne donne pas de prix. Barème : objet magique au prix du Guide du maître 2024 selon sa rareté (courant 100, peu courant 400, rare 4 000, très rare 40 000, légendaire 200 000 po) ; équipement au prix du Manuel des joueurs ; trésor au barème des objets d'art et des gemmes ; grimoire au prix de copie de ses sorts. |
| `description` | oui | Ce que les héros voient, ou lisent, en le trouvant : **lisible aux joueurs**, rien de secret. C'est le texte qui part sur D&D Beyond pour un objet personnalisé. Pour un document, son contenu résumé (ou le texte à lire du MJ, s'il en a un). |
| `effets` | non | Pour le MJ : propriétés, charges, malédiction, ce que l'objet fait vraiment. Résumé reformulé, jamais recopié. |
| `note_mj` | non | Pour le MJ : son rôle dans l'intrigue, à qui le remettre, ce qu'il révèle, quand le sortir. |
| `obtention` | non | Comment on l'obtient, en une phrase (« Sur le corps du brigand », « Récompense du bourgmestre s'ils ramènent sa fille », « Dans le coffre piégé, Perception DD 15 »). |
| `lieu` | non | `id` du lieu de `lieux.json` où il se trouve. Tout objet qu'on trouve sur place en a un. |
| `sous_lieu` | non | `id` d'un sous-lieu de `lieu` (une maison d'Aurval, un niveau du château). |
| `etapes` | non | Depuis le 2026-11-05. `id` d'étapes de `deroule-campagne.json` où l'objet se trouve, quand plusieurs étapes partagent son lieu et qu'il ne suit pas sa pièce. Rarement utile : les `sous_lieux` des étapes suffisent d'ordinaire ([deroule-campagne.md](deroule-campagne.md)). |
| `rencontre` | non | `id` de `rencontres_scenarisees[]` de [rencontres-aleatoires.json](rencontres-aleatoires.md) : l'objet fait partie de son butin (et alors son `lieu` est celui de la rencontre, s'il y en a un). |
| `jalon` | non | `id` d'un jalon de [deroule-campagne.json](deroule-campagne.md) : l'objet se trouve ou se reçoit pendant ce jalon (une récompense, un objet de quête). |
| `etape` | non | `id` d'une étape de [deroule-campagne.json](deroule-campagne.md), pour un objet qui tient à l'étape sans tenir à un jalon précis (une récompense de fin d'étape). Un objet rattaché à un jalon n'a pas besoin de `etape` : le gestionnaire la déduit du jalon. |
| `pnj` | non | `id` d'un PNJ de [pnj.json](pnj.md) qui le porte, le garde ou le donne. |
| `personnage` | non | `id` d'un personnage de [personnages.json](personnages.md) : l'objet tient à sa quête personnelle. |
| `tarokka` | non | `id` d'une place de [tarokka.json](tarokka.md) (`tome`, `symbole`, `epee`) : l'objet de cette place ; `lieu` et `sous_lieu` sont ceux que donne la lecture préparée. |
| `wiki` | non | Voir [README.md](README.md) : sa page sur le wiki des joueurs, s'il en a une. |
| `original`, `decision_mj` | non | Voir [README.md](README.md) : ce que disait le livre quand une source plus haute ou le MJ l'ont changé (un objet retiré, déplacé, remplacé). |
| `source`, `fiche` | oui | |
| `pages_pdf`, `pages_livre` | non | Où lire le détail. |

Au moins un rattachement parmi `lieu`, `rencontre`, `jalon`, `etape` et `pnj` : sans lui, le gestionnaire ne le montre que dans le widget Objets (avertissement du bouton **Données**). Un objet de quête personnelle (`personnage`) a toujours un `jalon`, une `etape` ou une `rencontre`.

Un objet important pour la suite (objet du Tarokka, objet de quête, récompense, document qui relance l'intrigue) se rattache de préférence à un `jalon` ou à une `rencontre`, en plus de son `lieu` : c'est ce qui déclenche l'alerte de fin de jalon. Un trésor ordinaire peut n'avoir que son `lieu`.

Exemple :

```json
{
  "id": "lance-de-sang",
  "nom": "Lance de sang",
  "nom_en": "Blood Spear",
  "beyond": true,
  "genre": "magique",
  "rarete": "peu courant",
  "harmonisation": true,
  "poids": 3,
  "description": "Une lance à la hampe noircie, dont la pointe semble toujours humide de sang.",
  "effets": "Lance +2 pour le PJ choisi par l'esprit de Kavan ; quand elle réduit une créature à 0 PV, son porteur gagne 2d6 PV temporaires.",
  "note_mj": "Kavan la donne au plus digne des PJ ; les autres peuvent la manier sans le bonus.",
  "obtention": "L'esprit de Kavan la remet au PJ qu'il a choisi.",
  "lieu": "colline-d-antan",
  "sous_lieu": "cairns-de-la-colline-d-antan",
  "rencontre": "livre-lance-de-kavan",
  "source": "LIVRE",
  "fiche": "reference/livre-annexe-tresors.md",
  "pages_livre": "223"
}
```

## Ce que fait le gestionnaire

- **Widget Objets** : tous les objets, dans l'ordre de la campagne (premier jalon ou première étape qui les concerne), avec une recherche (nom VF ou anglais), un filtre par état (à donner, donnés) et « + Objet » pour en créer un.
- **Ici** : les objets du lieu (au lieu général, ceux de ses sous-lieux compris ; dans un sous-lieu, les siens), et ceux des PNJ qui s'y trouvent. **Déroulé** : ceux d'un jalon, dans sa fenêtre. **Rencontres** : ceux d'une rencontre scénarisée, dans sa fenêtre de préparation, sous son butin.
- Un clic sur un objet ouvre sa fenêtre : ce que voient les joueurs, les effets et la note pour le MJ, où et comment le trouver ; l'objet de D&D Beyond (cherché d'après `nom_en` quand `beyond` est vrai) ou l'objet personnalisé (nom, description, note, poids en livres) ; « Donner » à un héros ou au groupe, avec la quantité. Un objet du catalogue de D&D Beyond est renommé dans l'inventaire du héros : par défaut son `nom` (le nom VF de la campagne), ou `nom_joueurs` tant qu'il n'est pas identifié ; le MJ peut changer ce nom, ou garder le nom anglais de D&D Beyond.
- **Alerte de fin** : quand le MJ termine un jalon, le Déroulé liste les objets **pas encore donnés** qui s'y rattachent (`jalon`, ou `rencontre` citée dans les `rencontres` du jalon) et demande confirmation. Quand il termine une étape : ceux de ses jalons et ceux qui portent son `etape` ; en plus, repliés, ceux qui ne sont rattachés qu'à un `lieu` de l'étape et restent sur place. Le MJ peut terminer quand même : l'objet reste « à donner ».
- Les objets que le MJ crée dans le gestionnaire (rattachés à un lieu, un jalon, une étape, une rencontre) sont dans `etat/objets.json`, pas dans ce fichier : si l'un mérite d'y figurer, il le dit à l'agent.

## Contrôles faits par le gestionnaire

- `id` uniques ; `nom`, `description`, `genre`, `beyond`, `source` présents ; `genre` parmi ceux de la liste ; `beyond` booléen ; `nom_en` présent quand `beyond` est vrai ; `poids` et `cout` nombres entiers positifs ou nuls ; `quantite` lisible (dés ou nombre).
- `lieu` et `sous_lieu` dans `lieux.json` (le sous-lieu sous ce lieu), `rencontre` dans `rencontres_scenarisees[]`, `jalon` et `etape` dans `deroule-campagne.json`, `pnj` dans `pnj.json`, `personnage` dans `personnages.json`, `tarokka` parmi les places de `tarokka.json`.
- Avertissement : un objet sans `lieu`, `rencontre`, `jalon`, `etape` ni `pnj` ; un objet avec `personnage` sans `jalon`, `etape` ni `rencontre`.
