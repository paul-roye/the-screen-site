# `data/noms.json` — format 1

Prénoms et noms de famille de la campagne (ceux de son monde), pour nommer un PNJ improvisé. Lu par le widget **Noms**.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `prenoms.masculins` | oui | Chaînes, au moins une. |
| `prenoms.feminins` | oui | Chaînes, au moins une. |
| `familles` | oui | `[{ masculin, feminin }]` : les deux formes du nom de famille, identiques quand le nom ne s'accorde pas (`Barthos` / `Barthos`, `Petrovich` / `Petrovna`). |
| `usage` | conseillé | Comment tirer un nom. Affiché sous le générateur. |
| `notes` | non | `[{ texte, source, fiche }]` : conventions de nommage (patronymes…). Affichées repliées. |
| `source`, `fiche`, `pages_livre` | oui | Provenance des listes. |

## Ce que fait le widget

- Tire un prénom du genre choisi (ou au hasard), puis un nom de famille accordé au même genre.
- Permet de relancer le prénom seul ou le nom seul, et de retenir le nom avec une note (« l'aubergiste du gué »).
- Garde l'historique des noms tirés dans `etat/noms.json` (voir [etat.md](etat.md)). Un nom retenu n'est plus proposé.

## Contrôles faits par le gestionnaire

`prenoms.masculins`, `prenoms.feminins` et `familles` présents et non vides ; chaque famille a ses deux formes.
