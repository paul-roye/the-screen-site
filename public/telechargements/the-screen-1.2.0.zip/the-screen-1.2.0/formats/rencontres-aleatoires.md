# `data/rencontres-aleatoires.json` — format 3

Procédure, tables de jour et de nuit avec leurs sous-tables, fiches des rencontres et rencontres scénarisées. Lu par le widget **Rencontres**.

**Format 3** : les règles qui changent le tirage (un guide qui connaît les sentiers, une escorte…) sont des **modificateurs** de la procédure (`procedure.modificateurs[]`).

Conventions communes (enveloppe, provenance, écarts, identifiants, dés) : [README.md](README.md). Ce format décrit le fichier exporté le 2026-10-15 ; il en est la référence.

**Format 2 (2026-10-15)** : tables principales sur `1d20+1d12`, **sous-tables** (une ligne peut renvoyer à une autre table au lieu d'une fiche, et faire un tirage dans un autre fichier), lignes à plage de jets (`jet_max`). Changement incompatible avec le format 1 : une option de ligne n'a plus forcément de `rencontre`. Les `id` des rencontres du format 1 sont inchangés. Ce qui change est marqué **(format 2)** ci-dessous ; le reste est celui du format 1.

## `procedure` (obligatoire)

| Champ | Contenu | Usage dans le widget |
|---|---|---|
| `intervalle_minutes` | `60` (décision du MJ ; 30 dans le livre) | Libellé du bouton « Tester · 1 h » ; nombre de tests prévus par le widget Trajets. |
| `quand` | Phrase | Règles, onglet Tables. |
| `plafond` | `{ rencontres, fenetre_heures, regle }` | Jauge de la fenêtre de 12 h ; le test est bloqué au plafond. |
| `test` | `{ de: "1d20", seuil: { route, nature }, regle }` | Rencontre si le jet atteint le seuil du terrain choisi. |
| `tirage` | `{ de, tables: { jour, nuit }, alternative }` | `de` vaut `"1d20+1d12"` **(format 2)** ; `tables` donne l'`id` de la table principale selon le moment. |
| `modificateurs[]` **(format 3)** | `{ id, nom, court?, condition?, regle, terrains?, tirage?, neutralise? }` | Une case du contexte par modificateur (`court` en libellé, `nom`, `condition` et `regle` en infobulle), aussi dans le dialogue du passage du temps. Cochée, dans un des `terrains` (tous s'il n'y en a pas), le tirage se fait avec `tirage` au lieu du dé de la table (un jet sans ligne donne « pas de rencontre »). Une fiche dont `neutralise_par` cite son `id` affiche « Pas de menace » et sa `regle`. Par exemple : `guide` (« Guide », terrain `nature`, `1d20`). |
| `carrefours[]` | `{ zone, nom, regle }` | Règles, onglet Tables. |
| `ecarts[]` | Écarts sur la procédure (« Un test par heure », MJ), au format commun de [README.md](README.md). | Affichés sous les règles du tirage, onglet Tables. |

## `tables[]` (obligatoire)

| Champ | Contenu |
|---|---|
| `id` | Les tables principales sont référencées par `procedure.tirage.tables` ; les sous-tables par `options[].table`. |
| `role` **(format 2)** | `"principale"` (table de jour, table de nuit) ou `"sous-table"`. Une sous-table n'est jamais tirée directement : seulement depuis une ligne d'une autre table. |
| `nom`, `de`, `source`, `fiche`, `ecarts[]` | `ecarts` au format commun ([README.md](README.md)), affichés sous la table dans l'onglet Tables. |
| `usage` **(format 2)**, facultatif | Sous-table : d'où elle est appelée et comment la jouer (une phrase). |
| `lignes[]` | `{ jet, jet_max?, options[] }`. `jet` est un entier ; `jet_max` **(format 2)**, facultatif, fait de la ligne une plage (`jet` à `jet_max` inclus). Les plages ne se chevauchent pas. Un jet sans ligne (1 au `1d20` seul d'un modificateur) donne « pas de rencontre ». |
| `lignes[].options[]` | `{ rencontre?, table?, tirage_externe?, creatures[], poids }`. Plusieurs options : tirage pondéré par `poids`. **Exactement un** de `rencontre` ou `table` **(format 2)**. |
| `options[].rencontre` | `id` d'une fiche de `rencontres[]`. |
| `options[].table` **(format 2)** | `id` d'une table de rôle `sous-table` du même fichier : le gestionnaire lance son `de`, prend la ligne obtenue et la résout de la même façon (récursif ; une sous-table peut en appeler une autre, jamais elle-même ni une table principale). `creatures` est alors vide : ce sont celles de la ligne de la sous-table qui comptent. Si toutes les options de la ligne obtenue sont retirées (uniques déjà sorties), relancer dans la sous-table, comme pour une table principale. |
| `options[].tirage_externe` **(format 2)**, facultatif | `{ jeu, table }` : un tirage de plus, dans la table `table` (son `id`) du fichier `data/<jeu>.json`, qui porte des `lignes[]` à `jet` / `jet_max` (aujourd'hui `babioles.json`). Le gestionnaire lance le `de` de cette table et affiche la ligne obtenue (nom, texte, note du MJ) avec la rencontre ; pour une babiole, il ouvre sa fiche flottante comme le widget Babioles et la note dans les babioles données de la séance. Va avec `rencontre` (la fiche reste celle de la rencontre). |
| `options[].creatures[]` | `{ nom, nom_en?, quantite, note_mj? }`. `quantite` en notation de dés, lancée automatiquement. Tableau vide pour une trouvaille, un piège ou un renvoi à une sous-table. `nom_en` (facultatif, 2026-10-19) : voir plus bas « Nom anglais des créatures ». `note_mj` (facultatif, 2026-10-22) : même section. |

Tables exportées le 2026-10-15 : `table-jour` et `table-nuit` (principales, 2 à 32) ; sous-tables `sous-table-gens-de-la-route` (1d8, depuis les roturiers de jour), `sous-table-babioles` (1d4, tirage externe dans `babioles.json` : `babioles-avancees` ou `babioles-du-livre`), `sous-table-squelettes` (1d10) et `sous-table-revenants` (1d10). Les probabilités de `1d20+1d12` : 5 % par valeur de 13 à 21, puis décroissantes vers 2 et vers 32 (0,4 %).

## `rencontres[]` (obligatoire)

Toujours présents :

| Champ | Contenu |
|---|---|
| `id`, `nom` | |
| `type` | `creatures`, `trouvaille` ou `piege` (badge). |
| `en_voyage_seulement` | `true` : rien ne se passe si la case « À l'arrêt » est cochée (non compté dans le plafond). |
| `unique` | `true` : ne sort qu'une fois. Quand elle sort (aussi dans une sous-table), sa fiche demande au MJ s'il la cache des tables et la marque « rencontrée » (2026-10-15 ; avant : retirée d'office). Le MJ doit aussi pouvoir la **marquer « rencontrée »** lui-même, sans tirage, et revenir dessus : une unique jouée hors tirage ne sort plus, mais reste visible dans les tables **(demande du MJ, 2026-10-15 ; état dans `etat/rencontres.json`, voir [etat.md](etat.md))**. |
| `comment_jouer` | Texte principal de la fiche. |
| `tests[]` | Chaînes. |
| `sous_table` | `null`, ou `{ de, lignes: [{ jet: "1-2" \| "6", resultat }] }` : une sous-table **de texte** propre à la fiche (cadavre, sépulture, signe gravé), lancée automatiquement. À ne pas confondre avec les sous-tables de `tables[]`, qui ont des fiches et des créatures par ligne. |
| `renvois[]` | Chaînes. |
| `source`, `fiche`, `pages_livre`, `ecarts[]` | |

Facultatifs : `profil` (chaîne), `evitable` (chaîne), `effets[]`, `variantes[]` (une est suggérée au hasard), `suivi` (chaîne : bouton « Noter le suivi »), `retirer_si` (chaîne : bouton « Retirer des tables »), `neutralise_par[]` (`id` de modificateurs de la procédure, `"guide"` : alerte « Pas de menace » si sa case est cochée), `creatures_secondaires[]` (`{ nom, nom_en?, quantite, declencheur, note_mj? }`).

## `rencontres_scenarisees[]` (facultatif)

`{ id, nom, trajet, niveau, creatures[] ({ nom, nom_en?, quantite, note_mj? }), comment_jouer, butin?, si?: [{ condition, effet, creatures[] }], meme_que_livre?, source, fiche, pages_pdf ou pages_livre }`. Onglet Hors tables.

Champs facultatifs ajoutés le 2026-10-10 : `de` et `vers` (`id` de lieux de `lieux.json`, pour une rencontre de trajet ; `vers` seul quand le départ est libre), `lieu` (`id` du lieu, pour une rencontre sur place, par exemple à la tour du passeur ; avec `de` et `vers`, le point du trajet où elle a lieu, par exemple un carrefour). L'onglet Hors tables affiche « départ → arrivée » (ou « Vers … »), suivi du lieu s'il y en a un, sinon le libellé `trajet` ; il range les rencontres dans l'ordre de la campagne (premier jalon du déroulé qui les cite, celles qu'aucun jalon ne cite à la fin), avec le badge de sa source (« Supplément », « Livre ») et les pages, et un lien « Voir dans le déroulé ». Les rencontres scénarisées viennent d'un supplément (`source: "SUPP"`) ou du livre (`"LIVRE"`, zones hors chapitres), ou sont créées pour la campagne et validées par le MJ (`"MJ"`, badge « MJ »). Le déroulé (`deroule-campagne.json`, `jalons[].rencontres`) les place dans la chronologie. Une `quantite` non lançable (« 6 à 10 », « 2 ou 3 ») est affichée telle quelle.

Champ facultatif ajouté le 2026-10-13 : **`sous_lieu`**, `id` d'un sous-lieu de `lieu` dans [lieux.json](lieux.md) (une maison d'Aurval, un niveau du château). Le format reste en version 1 : les outils ignorent ce champ tant qu'ils ne le connaissent pas.

Champ facultatif ajouté le 2026-11-05 : **`etapes`**, `id` d'étapes de `deroule-campagne.json` où la rencontre se joue, quand plusieurs étapes partagent son lieu et qu'elle ne suit pas sa pièce. Rarement utile : les `sous_lieux` des étapes et les jalons qui la citent suffisent d'ordinaire ([deroule-campagne.md](deroule-campagne.md)). Le format ne change pas de version : les outils ignorent ce champ tant qu'ils ne le connaissent pas.

Champ facultatif ajouté le 2026-10-14 : **`original`** (chaîne), ce que fait le livre quand une source plus haute (un supplément) ou le MJ ont changé la rencontre, comme pour les fichiers « déjà arbitrés ». À afficher replié. Le format reste en version 1 : les outils ignorent ce champ tant qu'ils ne le connaissent pas. Affiché depuis le 2026-10-14, replié (« Version d'origine »), dans la fiche de la rencontre (fenêtre « Ouvrir » et widget Combat, « Comment la jouer »).

Depuis le 2026-10-19, une rencontre scénarisée se **prépare et se joue dans le gestionnaire** (`app/rencontres-mj.js`, widget Combat) : un clic sur elle ouvre un menu (Ouvrir, Lancer, Marquer terminée). Sa préparation (monstres de D&D Beyond, nombres, noms) et son statut vont dans `etat/rencontres-mj.json` ; le fichier n'est jamais modifié.

Champ facultatif ajouté le 2026-11-07 : **`pnj`** dans un élément de `creatures[]` (rencontres scénarisées, `si[].creatures[]`), `id` d'un PNJ de [pnj.json](pnj.md), ou tableau d'`id` pour plusieurs créatures du même élément. En fin de combat, le gestionnaire propose de marquer ces PNJ morts s'ils sont tombés. Sans lui, il les reconnaît au nom donné à la créature dans la préparation, ou aux noms entre parenthèses (« guenaude (Aline, Berthe) »). Le format ne change pas de version.

### Nom anglais des créatures (champ facultatif, 2026-10-19)

**`nom_en`** dans chaque élément de `creatures[]` (rencontres scénarisées, `si[].creatures[]`, `options[].creatures[]` des tables, `creatures_secondaires[]`) : le nom anglais du profil, tel que D&D Beyond le nomme (« Zombie », « Dire Wolf », « Vampire Spawn »). Le gestionnaire relie chaque créature, une fois, à un monstre de D&D Beyond (les livres choisis pour la campagne, onglet « Livres D&D Beyond » de la fenêtre Campagne, et les homebrews du MJ ; un homebrew au nom plus long que `nom_en`, « Flesh Mound (Walter) (from the supplement PDF) », se trouve aussi : la recherche demande chaque mot de `nom_en`, pas le nom exact) ; avec `nom_en`, la recherche est déjà faite. Sans lui, le MJ tape le nom. Le format reste en version 2.

**`note_mj`** (facultatif, 2026-10-22), dans les mêmes éléments : une note pour le MJ sur le profil de D&D Beyond de la créature, une phrase ou deux (« Nom 2024 ; Grick Alpha en 2014. », « Pas de profil sur D&D Beyond… Profil proche : Hell Hound. »). Une note qui commence par « À vérifier » signale un profil choisi d'office par l'agent, à relire. Le gestionnaire la montre sous la créature, sans clic (préparation d'une rencontre, fiche d'un tirage, renforts, « Comment la jouer » du widget Combat), « À vérifier » en pastille orange. Comme `nom_en`, elle se retrouve par le nom VF : une même créature reçoit la même note partout, sauf note propre à une rencontre (elle prime alors dans cette rencontre).

### Rattachement des rencontres scénarisées (règle de contenu, 2026-10-13)

| Rencontre | Champs | Où le gestionnaire la montre |
|---|---|---|
| **De trajet** | `de` et `vers` (et `lieu` seulement pour un point du trajet, un carrefour par exemple) | Sur **le jalon de ce trajet** dans le déroulé (`jalons[].rencontres`). Jamais rattachée au lieu d'arrivée |
| **Sur place** | `lieu`, et `sous_lieu` si elle a lieu dans une partie du lieu ; sans `de` ni `vers` | Au lieu lui-même : le widget Ici l'affiche quand les héros y sont (au lieu général, avec celles de tous ses sous-lieux ; dans un sous-lieu, celles de ce sous-lieu). Un jalon qui se joue sur place peut aussi la citer |

**Quelles rencontres** : **toutes**, celles de chaque source de la campagne (le livre, un supplément).
- Chacune dit ce qui change par rapport au livre : le supplément qui modifie, remplace (« Remplace le tertre errant du livre… ») ou ajoute.
- Les rencontres du livre qu'une source plus haute **retire** sont regroupées, par lieu (ou sous-lieu), dans une entrée « Rencontres du livre retirées par le supplément », à ne jouer que si le MJ revient au livre.
- Un lieu dont les rencontres se trouvent en des endroits distincts **se découpe en sous-lieux** dans `lieux.json` (une maison d'Aurval ; « Niveau 1 » pour un lieu imposant comme un château), et chaque rencontre y est rattachée.

**Ordre de l'onglet Hors tables** : premier jalon du déroulé qui cite la rencontre ; sinon, pour une rencontre sur place, première étape dont les `lieux` contiennent son `lieu` ; les autres à la fin.

## `trouvailles_sans_danger` (facultatif)

`{ usage, exemples[], source, fiche, pages_pdf }`. Onglet Hors tables.

## `points_en_attente[]` (facultatif)

`{ sujet, fiche, impact }` : décisions du MJ encore ouvertes, affichées en alerte dans l'onglet Tables.

## Contrôles faits par le gestionnaire

`schema` (2) et `jeu`, présence de `procedure` et `tables` ; `procedure.tirage.tables` vise des tables de rôle `principale` ; chaque `options[]` a exactement un de `rencontre` (qui existe dans `rencontres[]`) ou `table` (qui existe, de rôle `sous-table`, sans boucle) ; `jet_max` ≥ `jet` et plages sans chevauchement dans une table ; `tirage_externe` vise une table existante de `data/<jeu>.json` ; écarts valides (statut, `condition`, `question`) ; `id` uniques des rencontres scénarisées, et leurs `de`, `vers` et `lieu` présents dans `lieux.json`, un `sous_lieu` parmi les sous-lieux de `lieu`. Avertissement pour une rencontre qui a `vers` sans qu'aucun jalon de trajet du déroulé la cite, et pour une sous-table qu'aucune ligne n'appelle.
