# `data/deroule-campagne.json` — format 2

La trame de la campagne : arcs, étapes indicatives, **jalons** (les moments précis) et **pistes** (les fils de fond à disséminer). Lu par le widget **Déroulé**, et aussi par les widgets **Ici** et **Personnages**.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, `decision_mj`, pas d'`ecarts`).

## Ce qui change par rapport au format 1 (2026-10-13)

- **Les étapes sont indicatives.** L'ordre est conseillé, rien n'est imposé : on peut sauter une étape, la laisser inachevée, y revenir. Arriver à une étape ouvre ses jalons et ses pistes, même si des étapes d'avant sont sautées.
- **Rien ne déplace les héros.** Démarrer une étape, commencer ou terminer un jalon ne change pas le lieu des héros : le widget *demande* s'ils s'y rendent.
- `jalons[].apres` devient **`jalons[].etape`** : l'étape qui ouvre le jalon.
- **`jalons[].lieu`** et **`sous_lieu`** (où le jalon se joue) se séparent de **`jalons[].lieux`** (autres lieux concernés, simples liens).
- **Nouveaux champs :** `etapes[].fin` (obligatoire), `etapes[].pistes_attendues`, `jalons[].declencheur`, le type de jalon `evenement`, et le tableau **`pistes`**. Jalons et pistes peuvent aussi porter `original` (ce que fait le livre) et `pages_pdf` ou `pages_livre` (où lire le détail). `vers` sert aussi à une amorce qui envoie les PJ ailleurs.
- **Trajets :** un trajet n'est un jalon que s'il porte des rencontres prévues ou des événements. Un trajet simple se prépare dans le widget Trajets.
- **Pistes des personnages :** celles de l'ancien champ `personnages.json` → `pistes` sont ici, avec `personnage` (voir [personnages.md](personnages.md), format 2).

## Les trois éléments

| Élément | Ce que c'est | Statut, dans `etat/deroule.json` |
|---|---|---|
| **Étape** | Un repère dans le récit, indicatif. Arriver à une étape ouvre ses jalons et ses pistes | à venir, en cours, terminée |
| **Jalon** | Un moment précis : une rencontre prévue (non aléatoire), un événement, une amorce, une halte, ou un trajet qui porte des rencontres | à venir, en cours, terminé |
| **Piste** | Un rappel ou un fil de fond, à garder en tête et à faire reparaître sur plusieurs étapes, lieux ou trajets (les corbeaux qui suivent les PJ, les cauchemars d'un PJ) | à venir, commencée, terminée |

Une quête personnelle enchaîne des jalons (les moments à ne pas manquer) et des pistes (ce qu'on dissémine) : voir `secrets[].etapes` dans [personnages.md](personnages.md).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | non | La trame en une ou deux phrases. |
| `progression` | non | `{ texte, niveau_max, original }` : comment se gagnent les niveaux. |
| `arcs` | oui | Voir ci-dessous. |
| `etapes` | oui | Voir ci-dessous. |
| `jalons` | oui | Voir ci-dessous. Tableau vide possible. |
| `pistes` | oui | Voir ci-dessous. Tableau vide possible. |
| `types_jalons` | oui | Libellé de chaque `type` de jalon : `{ "trajet": "Trajet", "rencontre": "Rencontre", "evenement": "Événement", "amorce": "Amorce", "halte": "Halte (lieu secondaire)" }`. |
| `niveaux_du_livre` | non | `{ texte, source, fiche, pages_livre }` : comment lire le `niveau_livre` des lieux de `lieux.json`. |
| `notes` | non | Chaînes. |
| `lieux` | non | **Retiré** de l'export (10/10/2026) : noms, zones, chapitres et niveaux du livre sont dans [lieux.json](lieux.md), qui fait foi. |
| `source`, `fiche`, `pages_pdf` | oui | |

### `arcs[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `ordre`, `nom` | oui | |
| `niveaux` | oui | `{ min, max }`, nombres. |
| `resume` | conseillé | |
| `lieux` | oui | `id` de lieux de `lieux.json`. |
| `etapes` | oui | `id` des étapes de l'arc, dans l'ordre conseillé. |
| `source`, `fiche` | oui | |

### `etapes[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `ordre`, `nom` | oui | `ordre` unique, de 1 à N : l'ordre **conseillé**, qui range les étapes dans la frise. Il ne contraint rien. |
| `arc` | oui | `id` de l'arc. |
| `lieux` | oui | `id` de lieux de `lieux.json` où se joue l'étape (tableau vide possible). **Indicatifs** : démarrer l'étape ne déplace pas les héros, le widget propose de s'y rendre. |
| `sous_lieux` | non | Depuis le 2026-11-05. `id` de sous-lieux de ses `lieux` : les pièces où se joue l'étape. **À donner quand une autre étape cite le même lieu** (la maison, puis son sous-sol) : le gestionnaire range alors dans chaque étape les PNJ, les rencontres et les objets de ses pièces, pour l'arbre de l'étape et pour ce qui reste à faire. Sans ce champ, il le déduit des jalons (ceux qui citent l'élément, puis ceux qui se passent dans sa pièce) ; ce qu'il ne peut rattacher à aucune étape reste montré dans toutes les étapes du lieu. Un sous-lieu peut être cité par plusieurs étapes. |
| `niveau_groupe` | oui | Niveau du groupe pendant l'étape. |
| `niveau_atteint` | non | Niveau atteint à la fin de l'étape, quand elle en fait gagner un. |
| `description` | oui | Ce qui se passe, en résumé. Les moments précis sont des jalons, pas des phrases de la description. |
| `fin` | oui | Ce qui marque la fin de l'étape, voir ci-dessous. |
| `pistes_attendues` | non | Pistes qui devraient déjà être commencées quand on arrive à l'étape, voir ci-dessous. |
| `tarokka` | non | Ce que la lecture du Tarokka place ici, voir ci-dessous. |
| `original`, `decision_mj` | non | Voir [README.md](README.md). |
| `source`, `fiche` | oui | |

### `etapes[].fin`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `texte` | oui | Ce qui marque la fin de l'étape, en une phrase : « Le bourgmestre est enterré et le groupe part pour le port avec sa fille. » |
| `jalons_cles` | non | `id` de jalons. Quand ils sont tous terminés, le widget propose de marquer l'étape terminée. |

### `etapes[].pistes_attendues[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `piste` | oui | `id` d'une piste de `pistes[]`. |
| `texte` | oui | Pourquoi elle devrait déjà être commencée, en une ligne. |

### `etapes[].tarokka`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `place` | ou `places` | `id` d'une place de [tarokka.json](tarokka.md) : `tome`, `symbole`, `epee`, `allie` ou `strahd`. |
| `places` | ou `place` | Plusieurs places (l'étape de la lecture elle-même a les cinq). |
| `texte` | oui | Résumé. La carte et la prophétie viennent de `tarokka.json`. |
| `source`, `fiche` | oui | |

### `jalons[]`

Un jalon est un moment précis de la trame. Il appartient à l'étape qui l'ouvre. Il ne fait pas gagner de niveau et n'a pas de `tarokka`.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant stable, unique parmi les jalons et les pistes. |
| `etape` | oui | `id` de l'étape qui **ouvre** le jalon : arriver à cette étape le rend accessible, même si des étapes d'ordre inférieur sont sautées ou inachevées. Remplace `apres` du format 1. |
| `rang` | oui | Ordre parmi les jalons de la même étape : 1, 2, 3… |
| `type` | oui | Voir « Types de jalons ». |
| `nom` | oui | Titre court. |
| `description` | oui | Ce qui se passe. |
| `declencheur` | non | Quand le jalon arrive, si ce n'est pas l'arrivée à un lieu : « Le lendemain matin, après une nuit au manoir », « Après l'enterrement, jamais avant ». |
| `lieu` | non | `id` du lieu de `lieux.json` où le jalon se joue (un lieu, jamais un sous-lieu). Le widget propose aux héros de s'y rendre, sans les déplacer ; le widget Ici montre le jalon quand les héros y sont. Tout jalon qui se joue sur place en a un. |
| `sous_lieu` | non | `id` d'un sous-lieu de `lieu` (`eglise-d-aurval`). |
| `lieux` | non | **Autres** lieux concernés : lieu évoqué, point de passage d'un trajet. De simples liens, sans proposition de déplacement. |
| `de`, `vers` | non | `id` de lieux de `lieux.json` : départ et arrivée d'un trajet. `vers` sert aussi à une **amorce** qui envoie les PJ ailleurs : c'est sa destination (« Le port sans vin » → le pressoir du gué). Dans les deux cas, le widget propose de préparer le trajet dans le widget Trajets. |
| `trajets` | non | `id` de trajets de [temps-de-voyage.json](temps-de-voyage.md), dans l'ordre du voyage (un trajet peut être parcouru dans un sens ou dans l'autre). Ils doivent se suivre, de `de` jusqu'à `vers` : le widget en déduit l'itinéraire, la distance et la durée totales. Pour **une seule route**. |
| `variantes` | non | Pour **plusieurs routes possibles** (à la place de `trajets`) : `[{ nom, de?, trajets[] }]`. `de` remplace celui du jalon pour cette variante ; `vers` est commun. Chaque variante suit la même règle que `trajets`. |
| `itineraire_libre` | non | `true` : **pas de route unique**, les joueurs tracent la leur. Ni `trajets` ni `variantes` ; les destinations vont dans `vers` ou `lieux`. |
| `rencontres` | non | `id` de `rencontres_scenarisees[]` de [rencontres-aleatoires.json](rencontres-aleatoires.md) prévues pendant ce jalon : pour un trajet, ses rencontres de route ; sur place, celles qui font le jalon. |
| `pnj` | non | `id` de PNJ de [pnj.json](pnj.md) concernés. |
| `facultatif` | non | `true` : le groupe peut ne pas passer par là. |
| `personnage` | non | `id` d'un personnage de [personnages.json](personnages.md) : le jalon appartient à la **quête personnelle** de ce PJ. Le nom du PJ n'est pas répété dans `nom`. |
| `original`, `decision_mj` | non | Voir [README.md](README.md). `original` : ce que fait le livre quand une source plus haute (un supplément) ou le MJ l'ont changé (le MJ joue avec le livre : le gestionnaire dit ce qui change). |
| `source`, `fiche` | oui | |
| `pages_pdf`, `pages_livre` | non | Où lire le détail : pages du PDF d'un supplément ou du livre. Sert surtout pour un gros lieu, dont les rencontres ne sont pas reprises dans `rencontres-aleatoires.json`. |

### Types de jalons

| `type` | Ce que c'est |
|---|---|
| `trajet` | Un voyage d'un lieu à un autre, **seulement s'il porte des rencontres prévues ou des événements**. Un trajet simple n'est pas un jalon. |
| `rencontre` | Une rencontre prévue, non aléatoire : combat ou face-à-face. |
| `evenement` | Une scène qui arrive à un moment donné : funérailles, visite, révélation. |
| `amorce` | Une accroche qui lance une suite : une demande, un indice, une rumeur. |
| `halte` | Un lieu secondaire, facultatif. |

### `pistes[]`

Une piste est un rappel ou un fil de fond : on la commence, on la fait reparaître ici et là, on la termine quand elle ne sert plus.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant stable, unique parmi les pistes et les jalons. |
| `nom` | oui | Titre court. |
| `etape` | oui | `id` de l'étape qui ouvre la piste. |
| `description` | oui | Ce qu'il faut garder en tête, et comment la jouer. |
| `debut` | oui | `{ texte, jalon? }` : quand la commencer. Avec `jalon`, le widget propose de commencer la piste quand ce jalon est commencé ou terminé. |
| `fin` | oui | `{ texte, jalon? }` : quand elle ne sert plus. Avec `jalon`, le widget propose de la terminer quand ce jalon est terminé. |
| `manifestations` | non | `[{ texte, etape?, jalon?, lieu?, trajet?, id? }]` : où et comment la faire reparaître (« résurgences » dans l'interface). `id` (facultatif, depuis le 2026-11-05) : un identifiant stable d'un export à l'autre, unique dans la piste ; le MJ coche les résurgences jouées, et sans `id` le gestionnaire les reconnaît à leur texte : une résurgence dont le texte est réécrit redevient « pas jouée ». À donner dès qu'un texte déjà exporté est retouché. Une résurgence déjà cochée ou remarquée garde son suivi quand elle reçoit son `id`, pourvu que son texte ne change pas dans le même export : donner les `id` d'abord, retoucher les textes à un export suivant. Jamais `debut` ni `fin` : le gestionnaire s'en sert pour les remarques du MJ sur le début et la fin de la piste. Un renvoi au plus par manifestation (aucun : manifestation libre). `etape`, `jalon` : `id` du déroulé ; `lieu` : `id` de `lieux.json` ; `trajet` : `id` de `temps-de-voyage.json`. |
| `personnage` | non | `id` d'un personnage de [personnages.json](personnages.md) : la piste appartient à la quête personnelle de ce PJ. |
| `facultatif` | non | `true` : une piste qu'on peut ne pas jouer. |
| `lieux` | non | `id` de lieux concernés. |
| `pnj` | non | `id` de PNJ concernés. |
| `rencontres` | non | `id` de `rencontres_scenarisees[]` liées. |
| `original`, `decision_mj` | non | Voir [README.md](README.md). |
| `source`, `fiche` | oui | |
| `pages_pdf`, `pages_livre` | non | Comme pour les jalons. |

## Ce que fait le widget

- **Frise par arc.** Chaque étape montre son ordre, son nom, le niveau du groupe (et le niveau gagné), ses lieux avec le niveau conseillé par le livre, sa description et sa fin (`fin.texte`).
- **Statut des étapes et des jalons**, dans `etat/deroule.json` (voir [etat.md](etat.md)) : à venir, en cours, terminé. Plusieurs étapes peuvent être en cours. Aucune n'est marquée terminée d'office, et le statut d'une étape ne dépend pas de son `ordre`.
- **Démarrer une étape** ouvre ses jalons et ses pistes, et alerte pour chaque `pistes_attendues` encore à venir (avec son `texte`).
- **Aucun déplacement automatique.** Démarrer une étape, commencer ou terminer un jalon ne déplace pas les héros. Si l'élément a un lieu, le widget demande « Les héros se rendent-ils à … ? », avec l'option de préparer le trajet dans le widget Trajets. Ce lieu est : `lieux` pour une étape ; `lieu` pour un jalon ; `vers` pour un trajet ou une amorce qui envoie ailleurs.
- **Fin d'une étape** : quand tous ses `jalons_cles` sont terminés, le widget propose de marquer l'étape terminée.
- **Jalons** sous leur étape, par `rang`, avec une icône par `type`, le badge « Facultatif » et le `declencheur`. Déplié :
  - `description` ;
  - `lieu` (et `sous_lieu`), lien vers le wiki s'il existe ; `vers` d'une amorce ;
  - `original` replié, et les pages (`pages_pdf`, `pages_livre`) où lire le détail ;
  - pour un trajet : `de` → `vers` (ou l'itinéraire lieu par lieu le long des `trajets`), la distance et la durée de marche totales, calculées comme le widget Trajets au rythme normal ;
  - les rencontres citées (fiche de l'onglet Hors tables du widget Rencontres), les PNJ, les autres `lieux` ;
  - `decision_mj`.
- **Personnage** : un jalon ou une piste avec `personnage` porte une icône PJ suivie du nom du personnage (`nom_court`, sinon `nom`), qui ouvre sa fiche dans le widget Personnages. Le widget peut filtrer la frise et les pistes par personnage. Le Déroulé est un outil du MJ : rien n'est masqué.
- **Pistes** : une liste à part, « À garder en tête », par groupes (à jouer maintenant, à décider, en veille, à venir, terminées), en tableau (tags, départ, résurgences, fin), les pistes des joueurs d'abord ; les textes de `debut` et `fin` dans sa vue détaillée seulement. Dépliée, une piste montre `description`, `debut`, `fin` et ses `manifestations` avec leurs liens. Quand son `debut.jalon` est commencé ou terminé, le widget propose de la commencer ; quand son `fin.jalon` est terminé, de la terminer. Une piste apparaît aussi, en rappel discret, sous l'étape qui l'ouvre.
- **Ouverture ciblée** : un jalon ou une piste peut être ouvert depuis un autre widget (lien d'une étape de quête de `personnages.json`, `secrets[].etapes[].jalon` ou `.piste`). Le widget fait défiler jusqu'à lui et le déplie.
- **Widget Ici** : il montre au lieu actuel des héros les jalons dont `lieu` est ce lieu, et les manifestations des pistes commencées dont `lieu` est ce lieu.

## Contrôles faits par le gestionnaire

- **Identifiants :** `id` uniques (arcs, étapes, jalons, pistes ; un jalon et une piste ne partagent pas un `id`) ; `ordre` des étapes uniques.
- **Arcs :** chaque arc cite des étapes et des lieux connus et a des `niveaux` numériques.
- **Étapes :** un arc connu, un `niveau_groupe` numérique, des lieux présents dans `lieux.json`, un `fin.texte` ; des `fin.jalons_cles` qui désignent des jalons ; des `pistes_attendues` qui désignent des pistes ; chaque `tarokka` a une `place` ou des `places` qui existent dans `tarokka.json`.
- **Jalons :**
  - une `etape` connue et un `type` connu (l'un des cinq ci-dessus, ou une clé de `types_jalons`) ;
  - un `lieu`, des `lieux`, `de` et `vers` présents dans `lieux.json`, et un `sous_lieu` parmi les sous-lieux de `lieu` ;
  - des `trajets` (ou ceux de chaque variante) présents dans `temps-de-voyage.json` et qui se suivent de `de` à `vers` ; pas de `trajets` ni de `variantes` avec `itineraire_libre` ;
  - un jalon de type `trajet` sans `rencontres` ni `description` d'événement : avertissement ;
  - des `rencontres` présentes dans `rencontres-aleatoires.json` (`rencontres_scenarisees`), des `pnj` présents dans `pnj.json`, un `personnage` présent dans `personnages.json`.
- **Pistes :**
  - une `etape` connue, un `debut.texte` et un `fin.texte` ;
  - des `debut.jalon` et `fin.jalon` qui désignent des jalons ;
  - des manifestations qui ont au plus un renvoi, et dont les renvois existent (étape, jalon, lieu de `lieux.json`, trajet de `temps-de-voyage.json`) ;
  - des `lieux`, `pnj`, `rencontres` et `personnage` présents dans leurs fichiers.
- **Fichier visé non chargé :** quand le fichier d'une référence n'est pas chargé, le contrôle donne un avertissement seulement.
