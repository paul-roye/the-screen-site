# `data/connaissances.json` — format 2

Qui sait quoi : pour chaque **intrigue secrète** de la campagne (où reposent trois reliques, qui sert le traître…), ce que chaque groupe en sait ; et ce que tout le monde sait ou croit (le savoir commun des habitants). Lu par le widget **Qui sait quoi** ; les intrigues donnent aussi leur nom aux `savoirs` des PNJ ([pnj.md](pnj.md)).

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, pas d'`ecarts`).

**Format 2** : une grille par intrigue secrète (`intrigues[]`), et le savoir commun (`savoir_commun`).

## `intrigues[]` (obligatoire, vide s'il n'y en a pas)

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `nom` | oui | `reliques`, « Les trois reliques ». L'`id` est celui des `savoirs` des PNJ et des `elements_intrigue` de `babioles.json`. |
| `court` | conseillé | Nom court du filtre du widget PNJ (« Reliques »). |
| `icone` | non | Icône de la charte (`glyphe` par défaut). |
| `resume` | conseillé | À quoi sert la grille. |
| `valeurs` | non | Libellé de `oui`, `non`, `partiel`. |
| `sujets` | oui | `[{ id, nom, court?, icone?, description }]` : les colonnes de la grille. `court` (conseillé, 2026-10-25) : le nom en un ou deux mots, en tête de colonne (« Sanctuaires », « Lien au roi ») ; sinon `nom`, coupé. `icone` (conseillé) : l'icône de la colonne quand le widget est étroit, le nom d'une icône de la charte (`design-system/icons/icons.json` : `ambre`, `epingle`, `chateau`, `glyphe`, `coupe-vin`…) ou d'une icône générique (`lu-` suivi de son nom dans `app/icones-ui.js` : `lu-sparkles`, `lu-map`…) ; sans icône, ou si elle n'existe pas, les initiales des deux premiers mots de `court` (« Emplacement des sanctuaires » : ES). |
| `groupes` | oui | Les lignes, voir ci-dessous. |
| `chaine_d_informateurs` | non | `{ texte, etapes[] }` : l'ordre type dans lequel les PJ apprennent. |
| `regle` | non | Une règle à rappeler (« Les Dames ne révèlent rien avant d'être restaurées »). |
| `source`, `fiche`, `pages_pdf` | oui | |

### `intrigues[].groupes[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `nom` | oui | |
| `court` | conseillé | Le nom du groupe en un ou deux mots, dans la grille (« Noblesse », « Gardiens de la plume », « L'abbé ») ; le nom complet est au survol et dans le détail. Sans lui, `nom`, coupé s'il est trop long (2026-10-25). |
| `exemples` | non | PNJ représentatifs. |
| `factions` | non | `id` de [factions.json](factions.md) que le groupe recouvre (« Loups-garous et peuple de la forêt » : `loups-garous`, `peuple-de-la-foret`). Permet d'aller du groupe aux PNJ membres, et de là à ceux qui ont un `savoirs` pour cette intrigue. |
| `sait` | oui | `{ "<id de sujet>": "oui" \| "non" \| "partiel" }`, une valeur pour **chaque** sujet. |
| `explication` | oui | Ce que le groupe sait au juste ; affichée au clic sur la ligne ou une case. |
| `ajustements` | non | `{ "<id de sujet>": { valeur_source, source_initiale, decision, source: "MJ", fiche, date } }` : quand le MJ a tranché une contradiction de la source (`source_initiale`, une source de la campagne : `SUPP`), qui disait `valeur_source`. `sait` porte déjà la valeur retenue ; la case est marquée « MJ ». |
| `source`, `fiche` | oui | |

## `savoir_commun` (facultatif)

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | conseillé | |
| `themes` | oui | `[{ id, nom }]` : par exemple `roi`, `dangers`, `pays`, `foi`, `superstitions`, `prejuges`. |
| `elements` | oui | `[{ theme, texte, croyance_fausse?, note?, original?, source, fiche }]`. `croyance_fausse: true` : ce que les gens croient à tort (mis en évidence) ; `note` : ce qu'il en est vraiment, pour le MJ. |
| `source`, `fiche`, `pages_pdf`, `pages_livre` | oui | |

## Ce que fait le widget

- Un onglet par intrigue : grille groupes × sujets, compacte (2026-10-25) : sujets par leur nom court, ou leur icône quand le widget est étroit ; une pastille par case (pleine : oui, à moitié : en partie, petit rond creux : non) ; légende dessous, `valeurs` au survol. Un clic sur une case ou un groupe ouvre dans une fenêtre flottante l'explication, les exemples et les décisions du MJ. Le `resume`, la chaîne d'informateurs et la règle sont repliés sous « À propos de cette grille ». Le détail d'un groupe montre aussi ses `factions` et « À qui demander » : les PNJ de ces factions qui ont un `savoirs` pour cette intrigue, du VIP au mineur, avec ce qu'ils savent et leur fiche. Chaîne d'informateurs et règle en dessous.
- Onglet **Savoir commun** (liste compacte depuis le 2026-10-25) : le thème dans une liste (avec le nombre d'éléments), « Fausses » qui bascule ; les éléments groupés par thème, une ligne chacun (sa source au survol), une croyance fausse en rouge avec un crâne et sa `note` dessous (« En vérité : … »), la version du livre repliée ; `resume` replié en bas.
- Rien n'est enregistré dans `etat/`.

## Contrôles faits par le gestionnaire

`intrigues` est un tableau ; au moins une intrigue ou un `savoir_commun` ; `id` uniques (intrigues, sujets, groupes, thèmes) ; chaque intrigue a un `nom` ; chaque groupe a une valeur `oui`, `non` ou `partiel` pour chaque sujet et aucun sujet inconnu (dans `sait` comme dans `ajustements`) ; chaque élément a un `texte` et un thème connu ; chaque `factions[]` d'un groupe existe dans `factions.json`.
