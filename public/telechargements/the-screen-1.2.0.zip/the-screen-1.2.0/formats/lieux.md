# `data/lieux.json` — format 1

Le référentiel commun des lieux : chaque `id` de lieu cité dans un autre fichier de `data/` (`pnj.json`, `marchands.json`, `temps-de-voyage.json`, `deroule-campagne.json`, `occupants-maisons.json`…) doit exister ici. Le gestionnaire y prend le nom, la zone et le niveau de chaque lieu ; les autres fichiers ne listent que les `id` dont ils ont besoin.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, `decision_mj`, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | non | Ce que contient le fichier. |
| `types` | oui | Libellé de chaque type : `{ "ville": "Ville", "village": "Village", "campement": "Campement", "chateau": "Château", "batiment": "Bâtiment", "ruines": "Ruines", "site": "Site", "carrefour": "Carrefour", "porte": "Porte", "lac": "Lac" }`. |
| `lieux` | oui | Voir ci-dessous. |
| `source`, `fiche`, `pages_livre` | oui | Provenance du fichier entier. |

### `lieux[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant commun à tous les fichiers (`port-d-aurval`). Stable. |
| `nom` | oui | Nom VF (« Port d'Aurval »). |
| `type` | oui | Une clé de `types`. |
| `zone` | non | Code de la carte du livre : une lettre (`E`), ou une zone précise pour un lieu situé dans un autre (`E7` pour la Funeste demeure). |
| `situe_dans` | non | `id` du lieu qui le contient (le manoir des Brumes est dans le port d'Aurval). Un lieu situé dans un autre se rejoint depuis lui : il n'a pas de trajet propre. |
| `chapitre_livre` | non | Chapitre du livre (`"3"`, `"annexe B"`). |
| `niveau_livre` | non | `{ min, max }` : niveau conseillé par le livre (table « Zones par niveau »). Le widget Déroulé l'affiche à côté du niveau du groupe. |
| `sous_lieux` | non | `[{ id, nom, zone? }]` : les parties du lieu, voir « Sous-lieux » ci-dessous. Les `id` sont uniques dans tout le fichier, lieux et sous-lieux confondus : un lieu dont l'unique sous-lieu porterait le même `id` que lui n'a pas de `sous_lieux` ici (`pnj.json` peut le garder). |
| `wiki` | non | `{ id, url }` : la page du lieu sur le wiki des joueurs (voir « Liens vers le wiki » dans [README.md](README.md)). |
| `original`, `decision_mj` | non | Voir [README.md](README.md). |
| `source`, `fiche` | oui | |

## Sous-lieux (précisé le 2026-10-13)

- Un sous-lieu est une **partie d'un lieu** : un bâtiment ou un coin (l'auberge du Cerf blanc, à Aurval), un quartier, ou un **niveau** pour un lieu imposant (« Niveau 1 » d'un château, le sous-sol du manoir des Brumes).
- Un lieu se découpe en sous-lieux dès qu'il a des **rencontres, des PNJ, des marchands ou des jalons** en des endroits distincts. Décision du MJ : toutes les rencontres sont dans les données, chacune rattachée à son lieu et, au besoin, à son sous-lieu.
- Un seul niveau de découpage : un sous-lieu n'a pas de sous-lieux. Pour un lieu à plusieurs bâtiments et plusieurs niveaux, chaque niveau d'un bâtiment est un sous-lieu du lieu (« Maison de Redressement, souterrain »).
- `nom` est le nom du sous-lieu seul (« Auberge du Cerf blanc ») ; le gestionnaire l'affiche avec celui du lieu (« Aurval – Auberge du Cerf blanc »).
- Ce fichier est le **référentiel des sous-lieux** : tout sous-lieu cité ailleurs (`pnj.json`, `marchands.json`, `rencontres-aleatoires.json`, `deroule-campagne.json`) existe ici.
- À ne pas confondre avec un lieu **situé dans** un autre (`situe_dans`) : le manoir des Brumes est un lieu à part entière, dans le port d'Aurval, avec ses propres sous-lieux.

### Ce que fait le widget Ici (décision du MJ, 2026-10-13)

- **Au lieu général**, il montre l'information du lieu, la liste de ses sous-lieux (et des lieux situés dedans) pour y descendre, et **tout ce qui s'y rattache, sous-lieux compris** : PNJ, rencontres, jalons, marchands.
- **Dans un sous-lieu**, la vue se réduit à ce sous-lieu. On remonte au lieu en un clic.

## Contrôles faits par le gestionnaire

- Dans ce fichier : `types` présent ; `id` uniques, lieux et sous-lieux confondus ; chaque lieu a un `nom` et un `type` connu de `types` ; `situe_dans` désigne un autre lieu du fichier.
- Dans les autres fichiers : chaque lieu cité (`pnj.json`, `marchands.json`, `temps-de-voyage.json`, `deroule-campagne.json`, `occupants-maisons.json`, `rencontres-aleatoires.json`) existe ici ; chaque sous-lieu cité est un sous-lieu de son lieu ; les `aussi` de `pnj.json` désignent un lieu ou un sous-lieu d'ici.
