# Note d'un compagnon : les états posés par le MJ, la férocité et le rampage notés par le joueur

**Contrat entre le gestionnaire (MJ) et l'extension du joueur `extensions/compagnon/`** (fiche du compagnon d'un héros : son familier, son compagnon animal). Ce n'est pas un fichier de `data/` : c'est une ligne écrite dans la fiche D&D Beyond du personnage, seul lien entre les deux outils (l'extension du joueur ne lit rien du gestionnaire).

D&D Beyond ne pose pas d'état sur une créature (familier, compagnon). Le MJ pose ceux du compagnon dans le gestionnaire (`etat/etats-creatures.json`, voir [etat.md](etat.md)) ; le gestionnaire les recopie dans la **note de la créature** sur la fiche, où l'extension du joueur les lit.

## Où

- Fiche D&D Beyond du maître, onglet Extras, la créature (son `id` sur D&D Beyond), « Customize », champ **Notes**.
- Dans la fiche brute (`character-service…/character/v5/character/<id>`) : la ligne de `characterValues` dont `typeId` vaut **47** (`CREATURE_NOTES`), `valueId` l'`id` de la créature (en texte) et `valueTypeId` son `entityTypeId` (en texte) ; la note est dans `value`. Pas de ligne : pas de note.
- Écrite comme la fiche le fait : `PUT https://character-service.dndbeyond.com/character/v5/custom/value` `{ characterId, typeId: 47, value, notes: null, valueId, valueTypeId, contextId: null, contextTypeId: null, partyId: null }` (relevé dans le code de la fiche, character-app 1.72.9, le 2026-10-20).

## Format

Une ligne, n'importe où dans la note (le gestionnaire la met à la fin) :

```
[États (MJ) : À terre, Épuisement 2]
```

- Entre `[États (MJ) :` et `]` : les états, séparés par des virgules, du plus grave au moins grave.
- Noms de la VF, ceux du glossaire du DRS 5.2.1 (les 15 de `app/etats.js`) : Agrippé, À terre, Assourdi, Aveuglé, Charmé, Effrayé, Empoisonné, Entravé, Épuisement, Étourdi, Inconscient, Invisible, Neutralisé, Paralysé, Pétrifié. L'**Épuisement** est suivi de son niveau (1 à 6) : « Épuisement 2 ».
- Sans état : pas de ligne (le gestionnaire la retire).
- Le reste de la note appartient au joueur : le gestionnaire ne touche qu'à sa ligne (il la remplace, ou l'ajoute à la fin, après un saut de ligne).

## Lecture (extension du joueur)

- Chercher `[États (MJ) : … ]` (sans tenir compte de la casse ni des espaces autour du deux-points) ; découper sur les virgules.
- Comparer chaque nom aux 15 sans tenir compte de la casse, des accents ni des espaces ; « Épuisement N » donne le niveau N (1 si absent, au plus 6). Un nom inconnu est ignoré.
- Les états affichés au joueur sont en lecture seule : seul le MJ les change, dans le gestionnaire.

## Qui écrit

- Le gestionnaire, à chaque changement d'un état du compagnon (Personnages : carte, fiche ; Combat), par l'extension du MJ (commande `etats-creature`, version 1.6.0, `extensions/mj/LISEZMOI.md`), un instant après le dernier changement. 
- Sur D&D Beyond, la note reste modifiable à la main : un état changé là n'est pas relu par le gestionnaire (`etat/etats-creatures.json` fait foi) et sera remplacé au prochain changement fait dans le gestionnaire.

## Rampage : la ligne du joueur (2026-10-20)

Une seconde ligne, dans la même note, écrite par l'**extension du joueur**, présente tant que le compagnon est en rampage (règles des compagnons de Flee, Mortals!) :

```
[Rampage (joueur)]
```

- Écrite quand le joueur met le compagnon en rampage, retirée quand le rampage prend fin (dans l'extension, avec la session du joueur, par la même requête `PUT …/character/v5/custom/value`, ou `DELETE` si la note devient vide).
- Chacun ne touche qu'à sa ligne : l'extension du joueur relit la note juste avant d'écrire et garde la ligne `[États (MJ) : …]` ; le gestionnaire garde de même la ligne du joueur quand il réécrit la sienne. Deux écritures au même instant peuvent faire perdre une ligne : elle revient au prochain changement de celui qui l'écrit.
- Lecture par le gestionnaire : l'extension du MJ (version 1.6.2) note `rampage: true` pour la créature dans son relevé (`beyond.json`, voir [etat.md](etat.md)) ; le MJ le voit dans Combat (ligne du compagnon) et Personnages (carte et fiche du compagnon). Recherche sans tenir compte de la casse ni des espaces : `[Rampage (joueur)]`.
## Férocité : la ligne du joueur (2026-10-21)

Depuis l'extension du joueur 1.8.0, une troisième ligne dans la même note, écrite par elle dès que sa fenêtre suit le compagnon :

```
[Férocité (joueur) : 7]
```

- Un entier (0 ou plus), la férocité telle que la fenêtre la tient (elle reste gardée dans l'extension, `chrome.storage.local` ; la ligne en est la copie pour le MJ). Écrite avant `[Rampage (joueur)]`, à la fin de la part du joueur.
- Mise à jour un instant (1,5 s) après le dernier changement de férocité (plusieurs clics, une écriture), aussitôt avec un changement de rampage ; à chaque lecture de la fiche (toutes les 15 s), réécrite si elle diffère de la fenêtre. Même requête et mêmes garde-fous que le rampage (note relue juste avant, seules les lignes du joueur changent).
- Un Chrome qui n'a jamais suivi ce compagnon prend la férocité de la note, sans écrire.
- Lecture par le gestionnaire : l'extension du MJ (version 1.7.2) note `ferocite` (le nombre, ou `null` sans la ligne) pour la créature dans son relevé ; Personnages l'affiche sur la carte du compagnon (mode Étendu, à la place des ressources d'un héros) et dans sa fiche (section « Férocité », sous les caractéristiques), dans la couleur de son état comme dans l'extension : gris à 0, jaune de 1 à 9, orange à 10 ou plus (le DD du test qui retient le rampage, 5 + férocité), rose en rampage (bonus de l'attaque de signature, moitié de la férocité). Recherche sans tenir compte de la casse, des accents ni des espaces : `[Férocité (joueur) : N]`.
