# `data/meteo.json` — format 2

**Format 2.**

La météo jour par jour de la campagne, en quatre créneaux de six heures. La campagne choisit la sienne dans la fenêtre Campagne (onglet « Campagne », section « Le temps » ; `meteo` du manifeste, [campagne.md](campagne.md)) : **une météo fournie par le gestionnaire** (`modeles/meteos/<id>.json`, liste dans `modeles/meteos/index.json` : **Carcassonne 2009-2010**, chaud et tempéré ; **Tallinn 2009-2010**, froid et tempéré ; deux années civiles réelles chacune, 2009 et 2010), **la météo importée** (`data/meteo.json` : écrite par `outils/Importer la météo.cmd`, ou par l'IA de la campagne), ou **aucune**.

Deux sortes de fichiers (`type`) :

- `campagne` (par défaut ; une météo déjà posée sur le calendrier de la campagne) : chaque jour porte sa date au calendrier de la campagne et son `jour_campagne` ;
- `releve` (2026-10-24) : des années réelles d'une vraie ville, datées seulement par `date_reelle` (365 jours par an, sans 29 février ; deux années civiles pour les météos fournies, 2009 et 2010, `debut_reel` et `fin_reelle` au premier niveau). Le gestionnaire les pose sur la campagne, jour pour jour (`meteoSurCampagne()` de `app/calendrier.js` ; décision du MJ, 2026-10-24) : avec un calendrier, l'année du jour de campagne 1 prend la première année du relevé, son 1er jour le 1er janvier, son 100e jour le 10 avril (un départ au 279e jour de l'année du calendrier prend le 6 octobre 2009 de Tallinn) ; la deuxième année de la campagne prend la seconde année du relevé (le relevé se cale sur le 1er du mois d'équivalent `janvier` : Janenvar, Martel, janvier) ; sans calendrier, à partir de `debut_reel` du manifeste (`MM-JJ` dans la première année ; le premier jour du relevé par défaut). Au bout du relevé, on repart à son début : la deuxième année suit la première, la troisième reprend la première. Tous les calendriers ayant 365 jours, un mois réel tombe toujours sur le même mois de la campagne. C'est la forme des météos fournies et de ce qu'écrit **`outils/Importer la météo.cmd`** (`scripts/import-meteo/importer-meteo.ps1 -Ville <ville> -Annee <année> [-Mois 10] [-Annees 2] [-Pays FR] -Campagne <id>` : Open-Meteo, archives historiques ERA5, gratuit, sans clé, CC BY 4.0, toute ville depuis 1940 ; deux années civiles par défaut, du 1er janvier de `-Annee` au 31 décembre de la suivante ; écrit `data/meteo.json` de la campagne, refuse d'en écraser un sans `-Remplacer` ; `-Sortie` pour une météo fournie de `modeles/meteos/`). Un relevé a en plus `lieu { nom, region, pays, latitude, longitude, fuseau }` ; ses créneaux ont `releve` (« Open-Meteo, codes WMO 61, 63 »). Le ciel se tire de la nébulosité (moins de 20 % : dégagé ; 50 % : peu nuageux ; 85 % : nuageux ; au-delà : couvert ; brouillard selon le code), la précipitation d'un créneau des codes de l'OMS (deux heures sur six au moins), son texte du code le plus fréquent. Lu par l'Horloge (`app/horloge.js` ; calculs et affichage : `app/calendrier.js`), pour Trajets, Rencontres et le prompt de fin de session.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`). `sources.releve` donne le site d'où viennent les relevés.

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `calendrier` | oui | Le fichier de calendrier dont les dates sont tirées (`data/calendrier.json`). |
| `correspondance` | oui | `regle` (texte), `mois[] { mois, annee, reel }` (mois du calendrier ↔ mois réel), `jours_reels_non_utilises[]` (dates réelles `AAAA-MM-JJ` laissées de côté parce que le mois du calendrier est plus court). |
| `creneaux[]` | oui | Les quatre créneaux : `{ id, debut, fin }` (`nuit` 00:00-06:00, `matin` 06:00-12:00, `apres-midi` 12:00-18:00, `soir` 18:00-24:00). |
| `unites` | oui | `{ temperature: "°C", humidite: "%" }`. |
| `types_ciel` | oui | Pour chaque état du ciel (`degage`, `peu_nuageux`, `nuageux`, `couvert`, `nuages_bas`, `brouillard`) : `nom`, `dans_le_monde` (facultatif : comment le décrire dans le monde de la campagne ; sous un ciel toujours voilé, par exemple). |
| `types_precipitation` | oui | Libellé de chaque précipitation : `bruine`, `pluie`, `averses`, `verglacante`, `neige`, `neige_forte`. |
| `regle_du_monde` | non | `{ texte, source, fiche }` : ce que le monde de la campagne fait à la météo réelle (un ciel toujours voilé, par exemple). Le ciel toujours voilé lui-même est un réglage du manifeste (`reglages.ciel_voile`, [campagne.md](campagne.md)). |
| `type` | non | `campagne` (par défaut) ou `releve` (voir plus haut). |
| `jours[]` | oui | Un jour par date couverte, dans l'ordre. Voir ci-dessous. |

### Un jour

| Champ | Contenu |
|---|---|
| `mois`, `jour`, `annee` | Date au calendrier de la campagne (`mois` = `id` de `calendrier.json`). Absents d'un relevé. |
| `jour_campagne` | Jour de campagne de l'Horloge (`etat/horloge.json`), 1 = le premier jour de la campagne . Peut être 0 ou négatif pour les jours d'avant l'arrivée. Absent d'un relevé. |
| `date_reelle` | Date du relevé, `AAAA-MM-JJ`. |
| `min`, `max` | Températures extrêmes du jour, °C. |
| `gel` | `true` si le minimum est à 0 °C ou moins. |
| `ciel` | État du ciel de la journée (matin et après-midi : le plus fréquent, le plus sombre en cas d'égalité). Clé de `types_ciel`. |
| `precipitations[]` | Précipitations du jour, clés de `types_precipitation` (vide s'il n'y en a pas). |
| `resume` | Une phrase pour le MJ : « Brouillard ; pluie faible le matin ; bruine l'après-midi. 2 à 12 °C. » |
| `creneaux[]` | Quatre créneaux : `creneau` (`id` de `creneaux`), `debut`, `fin`, `max`, `min` (°C), `ciel`, `precipitation` (clé ou `null`), `texte` (en français), `humidite`, `releve` (texte d'origine, en anglais). Les créneaux absents du relevé ont été complétés d'après leurs voisins. |

## Ce qu'en fait le gestionnaire

- Horloge : le `texte` du créneau en cours sur la ligne du ciel, sous la date (« Bruine, brouillard » ; demande du MJ du 2026-10-24 : la ligne disait « Ciel gris, sans soleil » quand il pleuvait), le `resume` du jour et le créneau en infobulle ; à côté de l'heure, l'icône du ciel et la température `min` à `max` du créneau, avec `types_ciel[].dans_le_monde` en infobulle (« En Aurval : … », d'après le vocabulaire du manifeste). Sans météo, la ligne dit le moment (« Plein jour », « Nuit de pleine lune »). Réduite, l'icône du ciel à côté de l'heure (et la température si la place le permet). Avec `ciel_voile`, jamais d'icône de soleil (un ciel dégagé ou peu nuageux se dessine en nuage, la nuit en nuage et lune ; sinon soleil, soleil voilé, lune), et une icône de brume au bout de la ligne du ciel : `regle_du_monde.texte` et ce que donne le ciel du moment (`dans_le_monde`) en infobulle, à dire à la table.
- Annonce en haut du tableau quand la précipitation ou le brouillard (`ciel` : `brouillard`) change entre le créneau de départ et celui d'arrivée d'un passage du temps (« Il se met à neiger ; le brouillard se lève »). Pas pour un réglage de l'horloge.
- Trajets et Rencontres : un rappel discret quand le créneau en cours a du brouillard (visibilité), de la forte neige (`neige_forte`) ou de la pluie verglaçante (`verglacante`) ; le MJ juge du terrain difficile, rien n'est appliqué.
- Prompt de fin de session : le `resume` du jour et le créneau en cours.
- Un jour sans entrée dans `jours[]` n'a pas de météo : rien n'est affiché.

## Contrôles faits par le gestionnaire

Chaque jour a une date qui existe dans `calendrier.json` et le bon `jour_campagne` ; quatre créneaux, dans l'ordre de `creneaux` ; `ciel` et `precipitation` (du jour et de chaque créneau) connus de `types_ciel` et `types_precipitation` ; `min` ≤ `max`.
