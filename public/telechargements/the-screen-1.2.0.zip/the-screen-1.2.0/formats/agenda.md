# `data/agenda.json` — format 1

L'**agenda** de la campagne (2026-10-25) : des entrées datées au calendrier de la campagne, un nom et des détails. Ce qui arrive un jour précis : une fête de village, un délai (« La princesse doit être en sécurité avant… »), le passage d'une caravane, un rendez-vous. Facultatif : sans lui, l'agenda ne montre que ce que le MJ y écrit. Écrit par l'agent IA de la campagne ; lu par l'Horloge (bouton « Agenda » de son en-tête : le calendrier de l'année, et la fenêtre du jour) et par le prompt de fin de session.

À ne pas confondre avec [jours-marques.md](jours-marques.md) : un jour marqué revient chaque année (une fête, un anniversaire) ; une entrée d'agenda a lieu une fois, à une date.

Le MJ ajoute, modifie ou retire des entrées dans le gestionnaire : une surcouche dans `etat/agenda.json` ([etat.md](etat.md)), que le prompt de fin de session donne à l'agent pour qu'il la reprenne dans ce fichier.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## `entrees[]` (obligatoire, vide s'il n'y en a pas)

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Unique, stable d'un export à l'autre (une retouche du MJ s'y rattache). Jamais `mj-…` (réservé aux entrées du MJ). |
| `date` | oui, ou `jour_campagne` | `{ annee, mois, jour }` au calendrier de la campagne : `mois` est un `id` de mois du calendrier choisi (`marpenoth`, `octobre`…). |
| `jour_campagne` | à défaut de `date` | Le jour de campagne (1 : le jour du départ), quand c'est plus simple que la date (« trois jours après le départ »). |
| `nom` | oui | Quelques mots (« Festival du Soleil éclatant »). |
| `details` | conseillé | Ce qui se passe, ce que le MJ doit préparer. |
| `secret` | non | `true` : pour le MJ seul (le gestionnaire est l'outil du MJ, mais le prompt de session le signale). |
| `alertes` | non | `{ jour_meme, avant }` : quand prévenir le MJ (une fenêtre s'ouvre quand l'Horloge arrive sur ce jour-là). `jour_meme` : `true` d'office ; `avant` : des nombres de jours (`[7, 1]` : une semaine avant et la veille). Absent : le jour même seulement. |
| `source`, `fiche` | conseillé | Provenance. |

Une entrée dont le mois n'existe pas dans le calendrier choisi ne s'affiche pas.

## Ce que fait le gestionnaire

- Horloge, bouton « Agenda » (icône de calendrier) : le calendrier de l'année en cours, mois par mois (aujourd'hui en rouge, les jours passés estompés, les jours marqués d'une étoile, les jours d'agenda d'un point orange) ; on navigue de l'année du départ de la campagne à cinq ans au-delà de l'année en cours. Un clic sur une date : ses jours marqués, ses entrées d'agenda (modifier, retirer) et « Ajouter ». En dessous, les prochaines entrées.
- Alertes : quand l'Horloge passe à un nouveau jour (en avançant, pas en annulant), une fenêtre liste les entrées dont c'est le jour (`jour_meme`) ou dont le jour approche (`avant`), avec leurs détails et « Voir dans l'agenda ». Le MJ les règle pour chaque entrée dans la fenêtre d'une date (« Le jour même », « N jours avant », plusieurs).
- Fenêtre du jour de l'Horloge : les entrées du jour.
- Prompt de fin de session : les entrées de chaque jour de jeu, celles des deux semaines à venir, et les retouches du MJ à reprendre.

## Contrôles faits par le gestionnaire

`entrees` est un tableau ; `id` uniques, jamais `mj-…` ; chaque entrée a un `nom` et une `date` (`annee` et `jour` entiers, `mois` texte) ou un `jour_campagne` entier.
