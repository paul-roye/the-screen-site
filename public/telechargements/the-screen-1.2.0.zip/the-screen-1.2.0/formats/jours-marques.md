# `data/jours-marques.json` — format 1

Les fêtes et anniversaires **propres à la campagne** (l'anniversaire d'un PNJ, une fête de village, la date d'un événement de l'histoire), ajoutés au calendrier qu'elle a choisi ([calendrier.md](calendrier.md) : fourni par le gestionnaire ou importé). Facultatif : sans lui, l'Horloge montre les jours marqués du calendrier seul. Écrit par l'IA de la campagne (2026-10-24).

Inutile pour ce que le calendrier fourni donne déjà (les équinoxes, les solstices, et les fêtes propres à un calendrier fourni).

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `jours_marques[]` | oui | Comme dans un calendrier : `id` (unique, et différent de ceux du calendrier), `mois` (un `id` de mois du calendrier choisi : `marpenoth`, `octobre`…), `jour`, `type`, `nom`, `texte` (une ou deux phrases, montrées en infobulle et dans la fenêtre du calendrier ; rien de secret), `depuis` (facultatif : année de l'événement d'origine, pour « 429e anniversaire »), `tous_les` (facultatif : les années multiples de ce nombre seulement), `note`, `source`, `fiche`. |
| `types_jours_marques` | non | Libellés des types propres à ce fichier ; `equinoxe`, `solstice`, `special` (en rouge dans l'Horloge) et `fete` sont connus d'office. |

Un jour dont le mois n'existe pas dans le calendrier choisi ne s'affiche pas (changer de calendrier en cours de campagne demande de réécrire ce fichier).

## Contrôles faits par le gestionnaire

`id` uniques ; `nom`, `mois` et `jour` présents ; `type` connu.
