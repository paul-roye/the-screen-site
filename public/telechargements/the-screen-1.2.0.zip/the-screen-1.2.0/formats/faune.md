# `data/faune.json` — format 1

Les animaux de la campagne par milieu, pour décrire une forêt ou un marais et tirer une bête au hasard. Lu par le widget **Faune**.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `milieux` | oui | `[{ id, nom, predateurs[], gibier[], oiseaux[], autres[] }]`. Les quatre listes sont des chaînes au pluriel (« loups »), toujours présentes, vides si besoin. Au moins une des trois premières non vide. |
| `animaux_domestiques` | non | `{ elevage[], compagnie_et_travail[] }`, chaînes. |
| `poissons` | non | Chaînes. |
| `notes` | non | Chaînes : ce qu'il faut savoir (« Les meutes de loups sont la menace la plus commune »). |
| `source`, `fiche`, `pages_pdf` | oui | Provenance du fichier entier. |

## Ce que fait le widget

Choix du milieu, listes par catégorie, et tirage au hasard d'un prédateur, d'un gibier, d'un oiseau ou d'un « autre ». Rien n'est enregistré dans `etat/`.

## Contrôles faits par le gestionnaire

`milieux` non vide, `id` uniques ; chaque milieu a ses quatre listes, et au moins un prédateur, un gibier ou un oiseau.
