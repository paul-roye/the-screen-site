# Calendriers — format 2

Un calendrier donne une date au jour de campagne de l'Horloge (`etat/horloge.json`, champ `jour`). Lu par l'Horloge et le prompt de fin de session (`app/horloge.js` ; calculs : `app/calendrier.js`). La campagne choisit le sien dans la fenêtre Campagne (onglet « Campagne », section « Le temps » ; `calendrier` du manifeste, [campagne.md](campagne.md)) :

- **un calendrier fourni par le gestionnaire** (`modeles/calendriers/<id>.json`, au format ci-dessous ; le Classique est calculé par `app/calendrier.js`) : **Classique** (`classique`), **Barovien** (`barovien` : pour *Curse of Strahd*, avec ses fêtes), **Royaumes oubliés** (`royaumes-oublies` : le calendrier de Harptos). Sa date de départ (le jour de campagne 1) est dans le manifeste, avec celle qu'il conseille (`debut_conseille`) ;
- **un calendrier importé** : `data/calendrier.json`, écrit par l'IA de la campagne pour un monde qui a le sien ;
- **aucun** : le jour de campagne seul (« Jour 12 »).

Les fêtes et anniversaires propres à une campagne (l'anniversaire d'un PNJ, une fête locale) ne demandent pas un calendrier à soi : ils vont dans `data/jours-marques.json` ([jours-marques.md](jours-marques.md)), ajouté au calendrier choisi.

**Format 2 (2026-10-24)** : toutes les années ont **365 jours** (décision du MJ : les météos réelles fournies ont des années de 365 jours, sans 29 février, et se posent ainsi sans décalage) ; la date de départ vient du manifeste (`debut_campagne` et `exemples` deviennent facultatifs) ; la semaine peut avoir d'autres jours que sept ; jours de fête hors des mois, lune qui ne suit pas les mois, crédits. Un calendrier au format 1 (le Barovien de 368 jours) n'est plus lu : il se refait à 365 jours (le Barovien fourni l'a été : Aprylla, Augul et Dekenvar perdent leur 29e jour).

**Les textes sont ceux du fichier.** Tout ce que l'Horloge dit du calendrier vient de lui : le sens d'un jour, sa divinité, ses coutumes, la présentation, la règle de la lune, les notes des mois et de l'année, les jours marqués, les crédits. Un champ facultatif absent n'est pas remplacé par un texte du gestionnaire : la ligne disparaît (un calendrier sans divinités n'affiche pas « Sans divinité »). Un calendrier de monde inventé a donc intérêt à remplir `presentation`, `lune.regle`, les `resume` et `sens` des jours, les `texte` des jours marqués. Exemples complets : `modeles/calendriers/barovien.json` (textes des jours) et `royaumes-oublies.json` (fêtes, dizaines, lune à cycle).

Un calendrier importé suit les conventions de [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `titre` | `titre` oui | Le nom du calendrier (« Calendrier d'Aurval ») : l'Horloge dit « l'année 1009 du calendrier d'Aurval ». |
| `credits` | non | `{ texte, url }` : d'où vient le calendrier (montré en bas de la fenêtre du calendrier, avec le lien). |
| `presentation` | non | Le calendrier en trois ou quatre phrases courtes, sans secret, qu'on peut lire aux joueurs. |
| `annee` | oui | `{ jours, premier_jour { annee, jour_semaine }, suffixe, note }` : `jours` vaut **365** ; le jour de la semaine du premier jour de l'année `premier_jour.annee` (`id` de `semaine`) ; `suffixe` (facultatif) : ce qui suit l'année dans une date (« CV » : « 3 Marpenoth 1492 CV ») ; `note`. |
| `debut_conseille` | non | `{ annee, mois, jour, texte }` : le départ proposé par la fenêtre Campagne, et pourquoi (« On conseille le premier jour de la Moisson… »). |
| `debut_campagne` | non | `{ annee, mois, jour }` : la date du jour de campagne 1, pour un calendrier importé quand le manifeste n'en donne pas. Le manifeste l'emporte. |
| `semaine[]` | oui | Les jours du cycle, dans l'ordre (sept chez la plupart, dix pour les dizaines de Harptos) : `id`, `ordre`, `nom` (graphie du calendrier : « Jour-du-Roi », ou en minuscules pour des noms communs : « lundi »), et, facultatifs, `equivalent` (lundi…), `signification`, `divinite` (`{ nom, culte }`, ou `null` pour un jour sans divinité), `resume`, `sens`, `secret_mj`, `coutumes[]`, `etymologie`, `decision_mj { texte }`. Voir « Textes d'un jour » ci-dessous. |
| `semaine_nom` | non | Le nom du cycle, s'il n'est pas « semaine » (« dizaine »). |
| `semaine_dans_la_date` | non | `false` : la date ne dit pas le jour du cycle (« 3 Marpenoth », pas « troisième jour 3 Marpenoth »). |
| `semaine_note` | non | Remarque sur l'ensemble de la semaine. |
| `mois[]` | oui | Les mois dans l'ordre : `id`, `ordre`, `nom`, `jours`, `equivalent` (le mois réel, en français : `octobre` ; il sert à poser une météo réelle sur la campagne, [meteo.md](meteo.md) : le mois d'équivalent `janvier` reçoit le 1er janvier des météos fournies), `note`. Un **jour de fête hors des mois** (Harptos : Herbeverte, entre Tarsakh et Mirtul) est un « mois » d'un jour avec `fete: true` : la date dit son nom seul (« Herbeverte 1492 CV ») et il ne compte pas dans le rang des mois. La somme des `jours` vaut `annee.jours`. |
| `saisons[]` | oui | `{ id, nom, debut { mois, jour } }` : une saison va de son début à la veille du début de la suivante. |
| `lune` | oui | `regle` (le texte de la fenêtre du calendrier), puis **l'une des deux** règles : `pleine_lune { jour_du_mois }` (pleine le même jour de chaque mois : le Barovien, le 1er) et `phases[] { id, nom, du, au }` en jours du mois ; ou `cycle { jours, pleine { annee, mois, jour } }` (une lunaison de `jours` jours, 29.53 sur Terre, 30.4375 pour Séluné, et une date de pleine lune) et `phases[]` en âge de la lune, en jours depuis la pleine lune. |
| `jours_marques[]` | oui | Jours qui reviennent chaque année : `id`, `mois`, `jour`, `type` (clé de `types_jours_marques`), `nom`, `texte`, `depuis` (année de l'événement d'origine, facultatif : le numéro d'anniversaire vaut année − `depuis`), `tous_les` (facultatif : ne revient que les années multiples de ce nombre ; la Rencontre des boucliers, tous les quatre ans), `note`. Pour contrôle, dans un calendrier importé : `jour_semaine_735`, `premier_jour_campagne`, `anniversaire_numero`. |
| `types_jours_marques` | oui | Libellé de chaque type : `equinoxe`, `solstice`, `special` (en rouge dans l'Horloge), `fete`… |
| `exemples[]` | non | Conversions de contrôle d'un calendrier importé : `{ jour_campagne, annee, mois, jour, jour_semaine }`. Le gestionnaire doit retrouver les mêmes. |

### Textes d'un jour de la semaine

L'Horloge montre le jour en une ligne au survol de la date, puis le détail dans une fenêtre. Les textes doivent donc être courts et séparer ce qui se dit à la table de ce que seul le MJ sait.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | conseillé | Une phrase, **100 caractères au plus**, sans secret : ce que le jour représente pour les habitants. « Jour de saint Andral, gardien des seuils : on garde sa porte close après la nuit tombée. » Sans lui, l'Horloge prend la première phrase de `sens`. |
| `sens` | non | Ce que le jour représente du point de vue des habitants, ce qui peut se dire à la table : **deux ou trois phrases, 350 caractères au plus**, sans secret de campagne. |
| `secret_mj` | non | Ce que seul le MJ sait du jour ou de sa divinité : une à trois phrases. Tout secret va ici, jamais dans `sens` ni `resume`. |

## Les calendriers fournis

- **Classique** : douze mois, du lundi au dimanche (le 1er janvier tombe le même jour que dans le vrai calendrier), sans année bissextile ; lune de 29,53 jours ; saisons, équinoxes et solstices.
- **Barovien** : d'après « A detailed calendar for Barovia based on moon and… » de Leguan1001 (https://www.reddit.com/user/leguan1001/), sur r/CurseofStrahd (Reddit : https://www.reddit.com/r/CurseofStrahd/comments/1bb9lq2/a_detailed_calendar_for_barovia_based_on_moon_and/), ramené à 365 jours : treize mois de 28 jours, Bošenvar en a 29 ; chaque mois commence à la pleine lune ; textes des jours d'après *Fleshing Out Curse of Strahd*. Avec les fêtes et anniversaires de l'aventure ; départ conseillé la veille d'une pleine lune (l'auteur de cet outil vous le recommande : la première nuit des héros tombe sous la pleine lune).
- **Royaumes oubliés** : le calendrier de Harptos, d'après « Calendriers des Royaumes oubliés » (Wikimonde : https://plus.wikimonde.com/wiki/Calendriers_des_Royaumes_oubli%C3%A9s) : douze mois de trente jours en trois dizaines, cinq fêtes hors des mois, Calendrier des Vaux (CV), saisons de la cinquième édition, Séluné (30,4375 jours ; repère du gestionnaire : pleine à l'Hiver fatal 1492 CV). La Rencontre des boucliers, en principe un 366e jour tous les quatre ans après la Longue nuit, se fête ici le premier jour d'Éléasis, les années multiples de quatre.

Le fichier du Barovien a été tiré du calendrier d'une campagne pilote (format 1).

## Calculs

- **Date du jour de campagne N** : partir de la date de départ et avancer de N − 1 jours, mois par mois ; après le dernier jour de l'année, le premier de l'année suivante. Un jour de campagne inférieur à 1 recule de la même façon.
- **Jour de la semaine** : nombre de jours écoulés depuis le premier jour de `annee.premier_jour.annee`, modulo la longueur de `semaine`, à partir de `annee.premier_jour.jour_semaine`.
- **Lune** : phase d'après le jour du mois (`pleine_lune`) ou l'âge de la lune (`cycle`). Pleine lune trois nuits : la veille, la nuit même et le lendemain. **Le calendrier est la seule source de la lune** (décision du MJ, 2026-10-13).

## Ce qu'en fait le gestionnaire

- Horloge : « Jour 1 · Lundi 6 octobre · 1009 » (le jour de campagne, la date, l'année). Au survol de la date, une ligne : `nom`, `equivalent` (s'il diffère du nom), `signification`, `resume` et `divinite` (« Sans divinité » seulement si d'autres jours en ont une). Un clic ouvre la fenêtre du jour : l'essentiel (équivalent et signification, divinité, `resume`, jour marqué du jour, saison, lune), puis, repliés, « <jour> en détail » (s'il a des textes : `sens`, `coutumes`, `etymologie`, et `secret_mj` et `decision_mj` dans un encadré « Pour le MJ, ne pas lire ») et « Le <calendrier> » (`presentation`, le mois ou la fête et sa `note`, la semaine (ou `semaine_nom`), `semaine_note`, `lune.regle`, les saisons, les jours marqués à venir, `annee.note`, `credits`). Le jour marqué du jour, ou à venir dans les 14 jours (« Solstice d'hiver dans 3 j », `texte` en infobulle, rouge pour un jour `special`).
- Réglage de l'horloge : la date sous le jour de campagne saisi.
- Prompt de fin de session : la date et le jour marqué du jour à côté du jour de campagne.

## Contrôles faits par le gestionnaire (calendrier importé)

`annee.jours` vaut 365 ; `semaine` non vide, aux `id` uniques ; `mois` non vide, `jours` entier, et leur somme égale `annee.jours` ; `lune.cycle`, s'il existe, a `jours` et une date `pleine` qui existe ; `debut_campagne` (s'il existe), `jours_marques[]` et `saisons[].debut` désignent des dates qui existent ; `annee.premier_jour.jour_semaine` existe dans `semaine` ; chaque `jours_marques[].type` existe dans `types_jours_marques` ; les `exemples` se recalculent à l'identique, ainsi que les champs « pour contrôle » des jours marqués. Pour un jour qui a un `resume` : `resume` de 120 caractères au plus, `sens` de 400 au plus.
