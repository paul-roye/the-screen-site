# `etat/` — ce que le gestionnaire enregistre

Écrit par les outils, jamais par l'agent IA de campagne (qui peut le lire pour savoir où en est la campagne). Chaque fichier se réfère aux `id` de `data/`. Il survit au remplacement de `data/`, à condition que les `id` ne changent pas.

- Écriture par `lancer.ps1` (requête `PUT etat/<nom>.json`), uniquement dans `etat/`.
- Avant d'écraser un fichier, le serveur garde la première version du jour dans `etat/sauvegardes/AAAA-MM-JJ/<nom>.json`. Pour revenir en arrière : arrêter le serveur, recopier la sauvegarde dans `etat/`.
- Chaque fichier porte `schema` (format, 1 pour tous) et `maj` (date ISO de la dernière écriture).
- On peut lire ou corriger ces fichiers à la main, serveur arrêté.

## `tableau.json`

| Champ | Contenu |
|---|---|
| `theme` | `nuit` ou `parchemin`. |
| `verrou` | `true` : disposition figée (poignées masquées). |
| `mode_hors_combat` | Facultatif : le dernier mode choisi parmi `exploration`, `ville` et `voyage`, celui du premier bouton pendant une rencontre. |
| `widgets_ville[]`, `widgets_voyage[]` | Dispositions des modes Ville et Voyage, comme `widgets_rencontre` (`null` ou absentes tant que le mode n'a pas été ouvert : la disposition recommandée). |
| `widgets_rencontre[]` | Disposition du mode Rencontre, même forme que `widgets[]` ; `null` tant que le mode n'a pas été ouvert (il prend alors la disposition recommandée de `modeles/dispositions.json`, qui reprend les widgets uniques déjà ouverts). Un widget présent dans les deux modes a la même `cle` dans les deux listes : c'est le même widget, qui change de place. |
| `widgets[]` | Disposition du mode Exploration. `{ cle, type, x, y, w, h }` : grille de 12 colonnes, rangées de 40 px. `type` : `personnages`, `combat`, `ici`, `horloge`, `tarokka`, `rencontres`, `deroule`, `pnj`, `factions`, `trajets`, `marchands`, `objets`, `connaissances`, `images`, `noms`, `babioles`, `maisons`, `faune`, `des`, `minuteur`, `convertisseur` (liste `WIDGETS` de `app/main.js`). Widget réduit : `reduit: true` et `hPlein` (hauteur à retrouver en le dépliant), `h` vaut alors 1. Réglages du widget propres au mode, facultatifs : `reglages` (`personnages` : `{ affichage: "basique" | "etendu" }`, l'étendu par défaut). |

## `demarrage.json`

L'aide de démarrage d'une nouvelle campagne (`aideDemarrage()` de `app/main.js`, 2026-10-25) : écrit par le serveur à la création de la campagne (`{ "schema": 1, "montrer": true }`), elle s'ouvre à chaque ouverture de la campagne tant que `montrer` est vrai ; « Ne plus montrer » le passe à `false`. Une campagne sans ce fichier ne la voit jamais.

| Champ | Contenu |
|---|---|
| `schema` | `1`. |
| `montrer` | `true` : l'aide s'ouvre à l'ouverture de la campagne. |

## `campagne.json`

| Champ | Contenu |
|---|---|
| `conditions` | Plus utilisé depuis le 2026-10-23 (onglet « Conditions » retiré de la fenêtre Campagne) : `{ "<condition>": true }`, faits de campagne qui activaient les écarts `conditionnel`. Gardé tel quel dans un fichier existant ; le gestionnaire ne s'en sert plus. |
| `livres_beyond` | Facultatif (2026-10-21, `app/livres-beyond.js`, onglet « Livres D&D Beyond » de la fenêtre Campagne) : les livres de D&D Beyond où chercher les monstres et les objets. `{ sources: [{ id (id de source de D&D Beyond), sigle, titre }], partenaires (objets du contenu partenaire débloqué, vrai par défaut), homebrew (objets homebrew de la campagne, vrai par défaut), homebrew_monstres (monstres de la collection homebrew du MJ dans la recherche des rencontres, vrai par défaut, extension 1.11.0) }`. Absent : Curse of Strahd, Flee, Mortals!, Monster Manual, Dungeon Master's Guide et Player's Handbook 2024, Ravenloft: The Horrors Within. |
| `regles_fiches` | Facultatif (2026-10-21, onglet « Fiches D&D Beyond » de la fenêtre Campagne ; lu par l'extension du MJ à chaque relevé, depuis 1.11.0) : `{ epuisement_homebrew (vrai par défaut : objets « Exhaustion Level » tenus à jour ; l'objet doit être dans la collection du MJ, vérifié ; jusqu'à 1.15.1, imposait aussi l'encombrement « variante »), encombrement_homebrew (vrai par défaut ; depuis 1.16.0 : objets « Encumbered » et « Heavily Encumbered » tenus à jour, l'un des deux équipé selon l'état du héros avec les seuils de la campagne, aucun sinon ; impose l'encombrement « Use Encumbrance » (sans effet sur la vitesse : les objets la réduisent) ; les objets doivent être dans la collection du MJ, vérifié ; décochée, ils sont retirés des fiches ; de 1.12.0 à 1.15.1 : un seul objet « Heavily Encumbered », id 12111887, avec la variante imposée, retiré des fiches depuis), encombrement_seuils (facultatif, depuis 1.16.0 : `{ encombre, lourd }`, les seuils en multiples de la Force, 5 et 10 par défaut ; un seuil lourd qui n'est pas au-dessus de l'autre vaut le double de celui-ci), homebrew (vrai par défaut : contenu homebrew autorisé, imposé aux fiches), pieces (faux par défaut : les pièces comptent dans le poids porté, imposé aux fiches) }`. |
| `plugins` | Facultatif (2026-11-02, `app/plugins.js`, onglet « Plugins » de la fenêtre Campagne) : les réglages de chaque plugin, `{ "<id>": { actif, … } }`. `actif` : le plugin démarre avec la page. Le reste est propre au plugin : voir [plugins.md](plugins.md) (The Table : `adresse`, `jeton`, `combats`, `effets`, `joueurs`, `joueurs_table`, `version`). |
| `difficulte` | Facultatif (2026-10-22, `app/difficulte.js`) : `{ actif, compagnons, roles }`. `actif` (vrai par défaut, 2026-10-23, onglet « Rencontres » de la fenêtre Campagne) : la difficulté selon *Flee, Mortals!* est affichée (préparation, lignes de rencontre, widget Combat, rôles des monstres) ; faux : rien de tout cela. `roles` (vrai par défaut, 2026-10-23, sous-option de `actif`) : rôles des monstres (choix dans la préparation, conseils, sbires et solos dans le calcul) ; faux : aucun rôle, les `groupes[].role` déjà notés sont gardés mais ignorés. `compagnons` (vrai par défaut, décision du MJ du 2026-10-22) : pour la difficulté selon *Flee, Mortals!*, un compagnon (créature d'une fiche, un familier) compte dans le budget comme un personnage de 2 niveaux de moins que son maître, 1 au moins, mais pas pour le plafond de FP ; faux : il ne compte pas. Case de la préparation d'une rencontre et du détail de la difficulté (widget Combat). |

## `tarokka.json`

| Champ | Contenu |
|---|---|
| `tirage` | Cartes notées par le MJ à la table : `{ "<id de place>": "<id de carte>" }`, par ex. `{ "tome": "glyphes-3", "allie": "artefact" }`. Une place sans carte notée n'a rien à révéler (sauf `resultat_fixe`). |
| `tirage_personnel` | Cartes des tirages personnels notées par le MJ quand elles diffèrent des cartes prévues : `{ "<id du personnage>": { "<id d'emplacement>": "<id de carte>" } }`, par ex. `{ "isolde": { "voie": "brumes" } }` (onglet Édition). Absent : les cartes prévues (`lectures[].carte`) s'appliquent. |
| `options` | `{ "<id de place>:<id de carte>": "A" }` : option retenue pour une carte à deux résultats. |
| `date_tirage` | Date ISO de la dernière saisie modifiée. |
| `tirage_valide` | Date ISO à laquelle le MJ a validé le tirage (onglet Édition), tirages personnels compris. Absent : pas encore validé. Une fois validé, les cartes ne se changent plus sans « Forcer la modification » ; toutes les cartes (onglets, table, miniatures de l'en-tête) montrent leur face. |
| `suivi` | `{ "<id de place>": true }` : objet trouvé, allié recruté. |
| `notes` | `{ "<id de place>": "texte" }` ; pour une carte d'un tirage personnel, la clé `perso:<id du personnage>:<id d'emplacement>`. |

Les cartes retournées ne sont jamais enregistrées : tant que le tirage n'est pas validé, tout est caché à chaque ouverture.

## `noms.json`

| Champ | Contenu |
|---|---|
| `genre` | Dernier choix : `m`, `f` ou `hasard`. |
| `historique[]` | `{ id, quand, genre: "m" \| "f", prenom, famille, retenu, note }`, du plus ancien au plus récent, 200 au plus (les noms retenus ne sont jamais retirés d'office). Relancer le prénom ou le nom remplace le dernier tirage tant qu'il n'est pas retenu. |

## `babioles.json`

Écrit par le widget Babioles (`data/babioles.json`, voir [babioles.md](babioles.md)), par le bloc `maj-etat` (champ `babioles`, voir [maj-etat.md](maj-etat.md)) et par Rencontres : une rencontre qui fait trouver une babiole (`tirage_externe` de `rencontres-aleatoires.json`) la tire comme le widget (sans ligne vierge, sans babiole déjà donnée si `ecarter_distribuees`), l'ajoute à `historique` et ouvre sa fenêtre ; depuis le 2026-10-15, elle n'est plus ajoutée d'office à `distribuees` : le MJ la donne (« Donner », la note proposée est « Trouvée lors d'une rencontre aléatoire (Jour 2, 14 h). »).

| Champ | Contenu |
|---|---|
| `table` | `id` de la dernière table choisie. |
| `ecarter_distribuees` | Booléen, `true` par défaut : le tirage écarte les babioles déjà données. |
| `distribuees` | `{ "<id de ligne>": { quand, a, note } }` : babioles données aux personnages. `quand` : date ISO (date et heure depuis le widget, `AAAA-MM-JJ` de la séance depuis le bloc `maj-etat`). `a` : `id` d'un personnage de `personnages.json`, `"groupe"`, ou `""` si non précisé. `note` : texte libre (où, comment). `beyond` (facultatif, 2026-10-15) : `{ quand, a, objet }`, l'objet personnalisé créé dans l'inventaire D&D Beyond du personnage ou du groupe (`a`) par « Donner » (`objet` : son `id` de D&D Beyond) ; présent, « Modifier » ne le recrée pas. « Reprendre » retire l'entrée (l'objet reste sur D&D Beyond). |
| `historique[]` | Les tirages, du plus ancien au plus récent, 100 au plus : `{ id, quand, table, ligne, jet }` (`ligne` : `id` de ligne ; `jet` : résultat du dé). Une ligne choisie dans la liste, sans dé, n'y est pas notée. |

Les `id` de ligne sont stables (voir [README.md](README.md)) : un `id` de `distribuees` absent de `data/babioles.json` est gardé tel quel et signalé par le widget, jamais effacé d'office.

## `trajets.json`

| Champ | Contenu |
|---|---|
| `itineraire[]` | `id` de lieux de `temps-de-voyage.json`, dans l'ordre : départ, puis chaque lieu atteint. Deux lieux qui se suivent sont reliés par un trajet direct. Aussi écrit au départ d'un trajet démarré depuis le Déroulé (« Partir » du dialogue de départ ; sans le widget Horloge, « Démarrer le trajet » l'écrit seul). |
| `unite` | `miles` ou `km`. |
| `rythme` | `lent`, `normal` ou `rapide`. Aussi écrit par « Partir » du dialogue de départ d'un trajet, où il se choisit. |
| `monture` | Booléen. |
| `carte` | La carte de **l'atelier** (celle que le MJ prépare dans le widget) : son `id` dans l'index de la bibliothèque d'images ([images.md](images.md)), toujours la version MJ (la version joueurs est envoyée d'après `paire`), ou `null`. L'ouvrir ne change rien à l'écran des joueurs. |
| `arrive` | Présent quand les héros ont fait cet itinéraire (« Démarrer le trajet ») : `{ quand, jour, minute }` (date ISO, et l'heure de jeu d'arrivée si l'horloge a avancé). Effacé dès que l'itinéraire change. |

## `ici.json`

Où sont les héros. Écrit par le widget **Ici**, par « Arriver » du widget Trajets et par le bloc `maj-etat` (champ `lieu`, voir [maj-etat.md](maj-etat.md)). Tant que le fichier n'existe pas, le lieu actuel et les lieux visités viennent du `groupe` de `data/personnages.json` ; ensuite le gestionnaire fait foi.

| Champ | Contenu |
|---|---|
| `lieu` | `id` du lieu de [lieux.json](lieux.md) où sont les héros (jamais un sous-lieu), ou `null`. |
| `sous_lieu` | `id` d'un sous-lieu de `lieu` dans `lieux.json` (l'auberge du Cerf blanc à Aurval), ou `null`. |
| `visites[]` | Arrivées, de la plus ancienne à la plus récente : `{ lieu, quand, jour, minute, trajet }`. `quand` : date ISO, ou `AAAA-MM-JJ` de la séance depuis le bloc `maj-etat` ; absent pour les lieux repris de `personnages.json`. `jour`, `minute` : l'heure de jeu de l'arrivée, quand l'horloge était sur le tableau. `trajet` : `id` du trajet (`trajets[]`) pendant lequel elle a été notée. Un même lieu peut revenir plusieurs fois. |
| `trajets[]` | Ajouté le 2026-10-12. Trajets faits, pour l'historique : `{ id, itineraire[], atteints, debut, fin, marche, marche_depuis_repos, fini, quand }`. Notés à la fin d'un trajet mené dans l'Horloge (`fini: true`), quand on l'arrête en route (`fini: false`), ou par « Arriver » du widget Trajets sans horloge (sans `debut` ni `fin`). `debut`, `fin` : `{ jour, minute }` ; `marche` : minutes de marche ; `marche_depuis_repos` : marche depuis le dernier campement du trajet. La marche depuis le dernier repos long (marche forcée) additionne celle des trajets terminés depuis, d'après `repos_long` de `horloge.json`. |
| `notes` | `{ "<id de lieu>": "texte" }` : notes du MJ sur un lieu. |
| `onglet` | Onglet affiché dans le widget (2026-10-22) : `pnj` (d'office), `rencontres`, `objets`, `trame` ou `lieu`. Changé seulement par un clic : un lieu qui n'a pas cet onglet s'ouvre sur le premier. Remplace `ouverts[]` (blocs dépliés d'avant les onglets), retiré au premier changement d'onglet. L'historique des déplacements (onglet Lieu, replié) est une seule liste (2026-10-14) : arrivées et trajets mêlés dans l'ordre où ils se sont passés, le plus récent en haut (un trajet juste avant la première arrivée qu'il a notée). On y corrige le lieu actuel (sans noter d'arrivée), et chaque ligne se retire d'un clic, sans confirmation (« Annuler » la remet tant que le widget n'est pas rechargé) : une arrivée seule, ou un trajet seul (ses arrivées restent ; la marche depuis le dernier repos long ne le compte plus). L'heure ne change pas ; si la dernière arrivée part, le lieu actuel redevient celui de l'arrivée d'avant, sauf s'il a été corrigé depuis. |

Le widget Ici consulte un lieu ou l'un de ses sous-lieux sans déplacer les héros : descendre dans un sous-lieu ne change pas `sous_lieu`. « Les héros arrivent ici » le fait (dans le lieu où ils sont déjà, sans noter d'arrivée) ; au lieu général, une croix à côté de leur sous-lieu les en fait sortir (`sous_lieu` à `null`). Un `sous_lieu` qui n'est plus un sous-lieu de `lieu` dans `lieux.json` est ignoré.

## `horloge.json`

Temps de jeu. Écrit par le widget **Horloge**, par « Démarrer le trajet » du widget Trajets et par le bloc `maj-etat` (champ `horloge`). Calculs : `app/horloge.js` (date, lune et météo : `app/calendrier.js`, d'après le calendrier et la météo de la campagne) ; passage du temps avec tests de rencontre : `app/passage.js`.

| Champ | Contenu |
|---|---|
| `jour` | Jour de campagne, 1 ou plus (jour 1 : le début de la campagne). |
| `minute` | Heure de jeu en minutes depuis minuit (0 à 1439) : 1335 pour 22 h 15. Jour 1, 8 h tant que le MJ ne l'a pas réglée. |
| `repos_long` | `{ jour, minute }` : fin du dernier repos long (bouton « Repos long », ou réglage), ou `null` s'il n'est pas noté. Au-delà de 24 h sans repos long, le widget alerte : « Fatigue +1 » (décision du MJ, 2026-10-12). |
| `reglages` | `{ lever, coucher }` : lever et coucher du soleil en minutes (6 h et 20 h). La date, l'année et la lune viennent du calendrier de la campagne : les anciens champs `annee`, `pleine_lune` et `cycle_lune` sont retirés du fichier à la lecture. |
| `activites[]` | Activités en cours, menées heure par heure : la dernière est celle qu'on mène (un repos long « Camper » se pose sur un trajet, qui reprend ensuite). Chacune : `id`, `type` (`voyage`, `repos`, `attente`), `titre`, `total` et `fait` (minutes de marche, de repos ou d'attente), `dehors` (minutes passées dehors depuis le dernier test de rencontre), `sans_aleatoires` (facultatif, 2026-10-31 : vrai, pas de test de rencontre aléatoire pendant l'activité ; choisi au départ d'un trajet ou dans sa fenêtre, repris par un campement posé dessus), `debut { jour, minute }`, `journal[]` (40 dernières lignes : `{ quand, moment, texte, id, rencontre, arrivee, forcee, dd }` ; `forcee` : fin d'une heure de marche forcée, `dd` : le DD de son jet ; `id` : entrée du journal de `rencontres.json`). Trajet : `itineraire[]` (`id` de lieux), `etapes[]` (minutes de marche cumulées jusqu'à chaque lieu après le départ), `atteints` (lieux déjà atteints), `marche_jour` (marche depuis le dernier repos long, trajets d'avant compris), `marche_report` (la part des trajets d'avant, au départ), `marche_propre` (marche de ce trajet depuis son dernier campement). Repos : `repos` (`long`), `interruptions` (1 h de plus chacune). Attente : `arret` (à l'arrêt ou en marche). |
| `journal[]` | Chaque changement, du plus ancien au plus récent (200 au plus) : `{ quand, avant: { jour, minute }, apres: { jour, minute }, motif }`, `repos_avant` (le `repos_long` d'avant) pour un repos long, `activite { id, pas }` pour une heure d'activité. `motif` : « +1 h », « Repos court » (1 h), « Repos long » (8 h), « Attendre l'aube », « Réglage », « Correction de l'heure », « Trajet vers X (3 h / 6 h) », « … · pause : +10 min », « Séance du AAAA-MM-JJ ». « Annuler » revient à `avant` de la dernière entrée (au repos long d'avant, et défait l'heure de l'activité en cours) et la retire. Une ligne peut aussi être retirée seule : l'heure ne change pas. |

Le moment de la journée se déduit des réglages : aube et crépuscule une heure de part et d'autre du lever et du coucher du soleil. Rencontres prend la table de jour du lever au coucher du soleil, tant que le widget Horloge est sur le tableau.

Faire passer une heure ou plus (boutons de l'Horloge, repos, « Démarrer le trajet », `app/passage.js`) : si les héros sont dehors (`terrain` de `rencontres.json` : route ou nature), un dialogue récapitule l'heure (« Corriger l'heure » rattrape un oubli). Une heure au plus : le test de l'heure, puis le temps passe d'un coup. Plus long, ou un trajet : une activité en cours (`activites`), menée heure par heure dans l'Horloge ; entre deux heures, on ajoute une pause (+10 min, +30 min, +1 h, repos court) sans que l'activité avance ; « Jusqu'à la prochaine rencontre » enchaîne les heures et s'arrête à une rencontre, à la fin, ou après 8 h de marche depuis le dernier repos long. Au-delà (marche forcée), l'Horloge propose « Marcher 1 h de plus » et « Finir le trajet » (s'il reste 4 h au plus) avec le DD des jets : à la fin de chaque heure **pleine** au-delà de 8 h, jet de sauvegarde de Constitution DD 10 + 1 par heure au-delà de 8 h (échec : un niveau d'épuisement), noté au journal de l'activité ; un bout d'heure ne donne pas de jet. La marche depuis le dernier repos long reprend celle des trajets terminés depuis (historique, `ici.json`). Un repos long se termine sur l'heure ronde suivante (21 h 20 + 8 h : 6 h). Chaque heure pleine passée dehors (marche ou pause) donne un test, au milieu de cette heure, sur la table de jour ou de nuit. À l'abri, le temps passe sans dialogue (sauf pour un trajet). L'arrivée estimée d'un trajet sans halte compte des journées de 8 heures de marche (20 h de marche : 2 jours et 4 heures). Annonces en haut du tableau : la nuit tombe (passage de la table de jour à celle de nuit), plus de 24 h sans repos long, fin d'un trajet ou d'un repos, le temps change (précipitation ou brouillard différents entre le créneau de départ et celui d'arrivée, `data/meteo.json`).

## `images.json`

| Champ | Contenu |
|---|---|
| `etiquettes` | `{ "<id d'image>": { categorie, lieux, pnj, sans_lieux, sans_pnj } }` : étiquettes posées par le MJ dans la fenêtre d'une image (widget Images, Ici, fiche d'un PNJ), toutes facultatives. `categorie` : la catégorie qu'il a choisie, à la place de la déduite. `lieux` (`id` de lieux), `pnj` (`id` de PNJ) : ajoutés aux déduits ; `sans_lieux`, `sans_pnj` : déduits qu'il a retirés. `id` d'image : celui de `images-library/index.json` ; déductions : voir [images.md](images.md). |

## `minuteur.json`

| Champ | Contenu |
|---|---|
| `duree` | Durée totale du compte en cours, en millisecondes : somme des ajouts (+1′, +5′…). Sert à la barre. `0` après une remise à zéro. |
| `fin` | Heure de fin (ms depuis 1970) si le minuteur tourne, sinon `null`. Un ajout en marche la repousse. |
| `reste` | Temps restant en pause (ms), `0` quand le temps est écoulé, `null` sinon. |
| `son` | Booléen. |

## `des.json`

Widget Dés : la sélection en cours et ses réglages. Les derniers jets (historique) restent en mémoire, le temps de la page, sans être écrits (2026-10-24 ; `EN_MEMOIRE` de `app/etat.js`, ignorés à la lecture d'un ancien fichier).

| Champ | Contenu |
|---|---|
| `choix` | `{ "<faces>": nombre }` : dés choisis, par ex. `{ "20": 2, "6": 1 }` (faces : 4, 6, 8, 10, 12, 20, 100). Un dé à 0 n'y figure pas. |
| `mod` | Modificateur ajouté au total, de −30 à +30. |
| `avantage` | `normal`, `avantage` ou `desavantage` : chaque d20 est lancé deux fois, le meilleur (ou le pire) est gardé. |
| `anime` | Booléen, `true` d'office : les dés roulent en 3D sur la page (jamais si le système demande moins d'animations). |
| `son` | Booléen : claquement des dés en 3D. |
| `historique[]` | Plus écrit depuis le 2026-10-24 (en mémoire seulement, même forme). Les 30 derniers jets, du plus ancien au plus récent : `{ quand, choix, mod, avantage, formule, total, des: [{ faces, valeur, garde }] }`. `garde: false` : le d20 écarté par l'avantage. Un d100 est une seule valeur (1 à 100). Un jet fait ailleurs (`app/lancers.js`, depuis le 2026-10-20 : initiative, nombre de monstres, fiche d'un monstre) n'a pas de `choix` ni d'`avantage` (pas de relance), mais un `motif` (« Initiative · Goule », « Bite : jet d'attaque »). |

## `regles.json`

Widget Règles (questions au service de règles, `regles/`) : la conversation en cours. La mémoire de l'agent est dans le service (jusqu'à son arrêt) ; ces échanges ne servent qu'à l'affichage.

| Champ | Contenu |
|---|---|
| `conversation` | Identifiant de la conversation, passé au service : l'agent garde le fil des questions précédentes. « Nouvelle conversation » en tire un autre et vide `echanges`. |
| `recherche_seule` | Booléen : les passages trouvés, sans modèle (instantané). Vaut aussi d'office quand le modèle est indisponible. |
| `echanges[]` | Les 40 derniers, du plus ancien au plus récent : `{ id, quand, question, mode, reponse, recherches, sources, duree, erreur }`. `mode` : `agent` ou `recherche` ; `reponse` : texte de l'agent (Markdown léger, citations `[DRS p. 187]`) ; `recherches` : requêtes de l'agent à l'outil de recherche ; `sources[]` : `{ section, langue, source, page, chemin, extrait }` (`section` : identifiant dans l'index, `fr-1167`) ; `duree` en secondes ; `erreur` ou `null`. |

## `musique.json`

Widget Musique (base : `musique/pistes.json`, voir [musique.md](musique.md)). Le volume n'y est pas : il est propre au poste (gardé dans le navigateur).

| Champ | Contenu |
|---|---|
| `boucle` | Booléen, `true` d'office : une piste finie reprend au début. Ne vaut pas pour les thèmes de la campagne et des héros, jamais en boucle. |
| `piste` | `id` YouTube de la dernière piste choisie (celle que « Lancer » reprend), ou `null`. Peut être celle d'un thème. |
| `favoris` | `id` YouTube des pistes favorites, dans l'ordre où elles ont été ajoutées. |
| `corrections` | `{ "<id YouTube>": { ajouter[], retirer[] } }` : étiquettes retouchées à la main dans le widget (le crayon d'une ligne), seulement l'écart à `musique/pistes.json` ; une piste revenue à l'import n'y est plus. Appliquées par le widget par-dessus chaque import ; une étiquette qui n'existe plus est ignorée, et l'import signale une retouche qui ne vise plus rien. |

## `convertisseur.json`

| Champ | Contenu |
|---|---|
| `regle` | `jeu` (0,3 m par pied, 1,5 m pour 5 pieds) ou `exacte` (0,3048 m). |
| `pieds` | Dernière valeur saisie, en pieds. |

## `pnj.json`

| Champ | Contenu |
|---|---|
| `pnj` | `{ "<id de PNJ>": { rencontre, rang, etat, note } }`, seulement pour les PNJ suivis. `rencontre` : booléen. `rang` : `vip`, `majeur` ou `mineur`, présent seulement quand le MJ a changé le rang du fichier (puce VIP / M / m). `important` (booléen, ancien bouton étoile) peut rester dans un ancien fichier : il compte tant que `rang` n'est pas noté, et disparaît au premier changement de rang. `etat` : `vivant`, `mort`, `mort-vivant`, `disparu` ou `absent`, prime à l'affichage sur le `statut` du fichier. `note` : texte libre. Écrit aussi depuis la fiche d'un tenancier (widget Marchands). |

## `marchands.json`

| Champ | Contenu |
|---|---|
| `ville` | `id` du lieu filtré, ou `""` pour toutes les villes. Ignoré tant que `suivre_zone` vaut `true` et que le lieu des héros a des marchands. |
| `suivre_zone` | `true` (par défaut) : la liste montre les marchands du lieu où sont les héros (`ici.json`, ou le lieu qui le contient), s'il en a. |
| `tri` | `nom` ou `prix` : ordre des articles dans la fiche d'un marchand. |
| `panier[]` | `{ id, marchand, nom, prix_pc, qte }` pour un article d'une liste ; `{ id, libre: true, nom, prix_pc, prix, qte }` pour une ligne libre (`prix` : le montant saisi, `"25 po"`). |

## `personnages.json`

N'est plus écrit depuis le 2026-10-10 (le widget Personnages n'a plus de mode simplifié ou détaillé : les fiches s'ouvrent en fenêtres flottantes). Un ancien fichier peut rester, il est ignoré.

## `etats-creatures.json`

États des créatures des héros (familier, compagnon : `creatures[]` de `beyond.json`), posés par le MJ dans Personnages (carte, fiche) ou Combat (2026-10-20). D&D Beyond ne pose pas d'état sur une créature : ceux-ci ne sont que dans le gestionnaire, et ceux des héros restent sur leurs fiches D&D Beyond (`etats` de `beyond.json`). Ce fichier fait foi ; depuis la version 1.6.0 de l'extension, ils sont aussi recopiés dans la note de la créature sur D&D Beyond, pour l'extension du joueur (voir [note-compagnon.md](note-compagnon.md)).

| Champ | Contenu |
|---|---|
| `schema` | `1`. |
| `creatures` | `{ "<id de la créature>": [{ id, nom, niveau }] }` : `id` de la créature dans les extras de D&D Beyond ; chaque état comme dans `beyond.json` (`id` de D&D Beyond, 1 à 15 ; `niveau` : celui de l'Épuisement, sinon `null`). Une créature sans état n'a pas d'entrée. |

## `agenda.json`

La surcouche du MJ sur l'agenda de la campagne (`data/agenda.json`, [agenda.md](agenda.md) ; 2026-10-25) : ce qu'il ajoute, modifie ou retire dans le calendrier de l'année (bouton « Agenda » de l'Horloge, `app/agenda.js`). Le prompt de fin de session la donne à l'agent IA, pour qu'il la reprenne dans le fichier.

| Champ | Contenu |
|---|---|
| `schema` | `1`. |
| `entrees` | `{ "<id>": { date, nom, details, alertes, quand } }` (`alertes` : `{ jour_meme, avant[] }`, comme dans [agenda.md](agenda.md)) : `id` d'une entrée du fichier (sa retouche, par-dessus) ou `mj-…` (une entrée créée par le MJ). `date` : `{ annee, mois, jour }` au calendrier de la campagne ; `details` : texte ou `null` ; `quand` : date ISO de la retouche. |
| `retirees` | `id` des entrées du fichier que le MJ a retirées (le fichier ne change pas). |

## `lore.json`

Le lore et les secrets des personnages retouchés par le MJ (onglets Lore et Secret de leur fiche, `app/lore.js`, 2026-10-24), par-dessus `data/personnages.json` ([personnages.md](personnages.md), « Lore »). Le prompt de fin de session les donne à l'IA ; une retouche que le fichier dit de nouveau à l'identique est retirée au chargement.

| Champ | Contenu |
|---|---|
| `schema` | `1`. |
| `personnages` | `{ "<id de personnages.json>": { "<champ>": { valeur, quand }, secrets?: { liste: [{ sujet, texte }], quand } } }`. `<champ>` : `accroche`, `apparence`, `personnalite`, `origine` (`valeur` : un texte), `motivations`, `allegeances` (des chaînes), `objets_notables` (`[{ nom, texte }]`) ; `quand` : date ISO de la retouche. `secrets` remplace la liste des secrets sans `etapes` (ceux en étapes, les quêtes, restent ceux du fichier). Un personnage sans retouche n'a pas d'entrée. |

## `beyond.json`

Relevé des feuilles D&D Beyond, affiché par le widget Personnages. Écrit toutes les 30 s par l'extension Chrome `extensions/mj/` (voir `extensions/mj/LISEZMOI.md`), avec la session D&D Beyond du navigateur (les fiches de la campagne sont privées), tant que le gestionnaire répond. Le résumé est calculé par `extensions/mj/resumer.js`, que le gestionnaire importe aussi. Seul le résumé est gardé, jamais la fiche brute.

| Champ | Contenu |
|---|---|
| `campagne` | `{ id, nom }` : la campagne D&D Beyond (`https://www.dndbeyond.com/campaigns/<id>`). |
| `groupe` | L'inventaire du groupe de la campagne (party inventory, depuis la version 1.7.0 de l'extension), ou `null` : `{ argent { pp, po, pe, pa, pc }, objets[] { id, definition, nom, quantite, perso }, releve_le }`. `perso` : un objet personnalisé, dont `definition` est l'`id` de l'objet créé par un héros (`objets_perso` de sa fiche, avec sa note). |
| `fiches` | `{ "<id D&D Beyond>": résumé }`, un par personnage assigné à un joueur. |
| `source` | `extension`. |
| `extension`, `extension_id` | Version de l'extension, et son identifiant Chrome : le gestionnaire s'adresse directement à elle pour les monstres de D&D Beyond (rencontres du MJ, widget Combat) et les objets (Babioles), voir `extensions/mj/LISEZMOI.md`. |
| `alertes[]` | Depuis la version 1.11.0 : ce que l'extension ne peut pas régler seule sur une fiche, `{ fiche, nom, joueur, type, objet?, texte }` ; `type` : `epuisement-collection`, `encombre-collection` ou `lourd-collection` (depuis 1.16.0 ; `encombrement-collection` de 1.12.0 à 1.15.1) (l'objet homebrew, « Exhaustion Level », « Encumbered » ou « Heavily Encumbered », nommé dans `objet`, absent de la collection du MJ, pour toute la campagne : `fiche` nul ; aucun essai sur les fiches), `epuisement-objet`, `encombre-objet` ou `lourd-objet` (`encombrement-objet` avant 1.16.0) (des exemplaires que D&D Beyond a refusé d'ajouter à une fiche), `homebrew-desactive` (contenu homebrew désactivé sur une fiche, quand l'option qui l'impose est décochée) ou `reglage-refuse` (un réglage de fiche que D&D Beyond a refusé). Recalculé à chaque relevé ; affiché, replié, dans le widget Personnages. |
| `maj` | Date ISO du dernier relevé : le widget affiche le temps écoulé et le signale au-delà de 2 min. |

Un résumé : `id`, `nom` (tel que sur D&D Beyond), `joueur` (pseudo), `url`, `avatar`, `niveau`, `classes[] { nom, niveau, sous_classe }`, `espece`, `historique` (en VF pour les historiques connus, sinon le nom anglais), `pv { actuels, max, temporaires }`, `ca`, `initiative`, `vitesses { marche, vol?, nage?, escalade?, fouissement? }` (en pieds ; réduites par l'encombrement, depuis la version 1.9.1), `encombrement { regle, etat, malus, porte, seuils { encombre, lourd, capacite }, double }` (depuis la version 1.9.1, calculé comme la fiche : `regle` `variante`, `standard` ou `aucune`, le réglage de la fiche, ou `campagne` (depuis 1.16.0 : encombrement par les objets homebrew, avec `encombrement_seuils` de `regles_fiches`, quel que soit le réglage de la fiche) ; `etat` `null`, `encombre`, `lourd` ou `surcharge` (standard, au-delà de la capacité : sans effet sur la vitesse) ; `malus` 10 ou 20 ft en variante (0 avec `campagne` : la vitesse est déjà réduite par l'objet équipé) ; `porte` en livres ; `seuils` en livres, 5, 10 et 15 × la Force (avec `campagne`, les multiples de la campagne pour les deux premiers), doublés quand `double` : créature Grande ou Carrure puissante, un modificateur `carrying-capacity` / `large`), `maitrise`, `caracteristiques { for, dex, con, int, sag, cha }` (chacune `{ valeur, mod, test, avantage_test, desavantage_test, sauvegarde, maitrise_sauvegarde }` ; `test` : bonus d'un test de la caractéristique, demi-maîtrise et bonus des tests compris, avec avantage ou désavantage sur tous ses tests, depuis la version 1.13.0), `passives { perception, intuition, investigation }`, `competences` (depuis la version 1.13.0 : `{ "<clé>": { bonus, maitrise, avantage, desavantage } }` pour les dix-huit compétences, clé anglaise de D&D Beyond (`stealth`, `animal-handling`…, table `COMPETENCES` de `extensions/mj/resumer.js`), `maitrise` `maitrise`, `expertise`, `demi` ou `null` ; `desavantage` aussi pour la Discrétion sous une armure qui la gêne), `vision_dans_le_noir` (pieds ou `null`), `sorts[] { classe, carac, dd, attaque }`, `emplacements[] { niveau, max, utilises }`, `pacte { niveau, max, utilises }` ou `null`, `usages[] { nom, utilises, max, recuperation }` (noms en anglais, comme sur la fiche), `objets_magiques[] { nom, rarete, quantite, equipe, harmonisation, harmonise }` (objets magiques ou de rareté au-dessus de « commun », du plus rare au plus commun ; sans les objets « Exhaustion Level » de l'Épuisement, depuis la version 1.10.0, ni « Heavily Encumbered », depuis la version 1.12.0, ni « Encumbered », depuis la version 1.16.0 ; ces objets ne sont pas non plus dans `objets_equipes`), `objets_equipes[] { nom, quantite, type }` (le reste de ce qui est équipé : armes, armure, bouclier… ; `type` : `arme`, `armure`, `équipement` ou `null` ; depuis la version 1.5.2 de l'extension), `objets_perso[] { id, nom, quantite, note }` (ses objets personnalisés, depuis la version 1.7.0 de l'extension : une babiole donnée par le gestionnaire porte en note « identifiant : <id de la ligne> » ; un objet rangé dans l'inventaire du groupe y reste listé : voir `groupe.objets`), `etats[] { id, nom, niveau }` (`id` de D&D Beyond, 1 à 15, depuis la version 1.5.0 de l'extension ; `niveau` : celui de l'Épuisement), `jets_contre_la_mort { succes, echecs, stabilise }`, `inspiration`, `argent { pp, po, pe, pa, pc }`, `creatures[]`, `modifie_le` (dernière modification sur D&D Beyond), `releve_le`.

Une créature (onglet Extras de la fiche : familier, compagnon, monture…) : `id`, `nom`, `groupe` (`familier`, `compagnon`, `forme sauvage`, `monture` ou `créature`), `actif`, `pv { actuels, max, temporaires }`, `ca`, `vitesses` (pieds), `passives { perception, intuition }`, `caracteristiques` (chacune `{ valeur, mod }`), `competences` (depuis la version 1.13.0 : comme celles d'un héros, `bonus` du profil, sinon le modificateur, `maitrise` `maitrise` ou `null`). `profil` (depuis la version 1.14.0) : son profil tel que D&D Beyond le donne, avec les champs d'un monstre de `monster-service` (`name`, `stats`, `armorClass`, `hitPointDice`, `movements`, `skills`, `skillsHtml`, `senses`, descriptions des traits, actions, actions bonus et réactions en HTML, `typeId`, `sizeId`, images…) : la fiche du compagnon dans Personnages en bloc de stats (`app/fiche-compagnon.js`). `pv.max` et `ca` : ceux personnalisés sur la fiche (« Customize » de la créature : « Max HP », « Armor Class ») quand il y en a, sinon ceux de son profil (depuis la version 1.5.1 de l'extension). `rampage` (depuis la version 1.6.2) : vrai quand sa note porte la ligne `[Rampage (joueur)]`, écrite par l'extension du joueur (voir [note-compagnon.md](note-compagnon.md)). `ferocite` (depuis la version 1.7.2) : le nombre de sa ligne `[Férocité (joueur) : 7]` (extension du joueur 1.8.0), ou `null` sans elle.

CA, PV max, caractéristiques et passives des personnages sont **recalculés** depuis la fiche brute (D&D Beyond ne les stocke pas) ; vérifiés sur de vraies fiches, familier compris. Un objet magique ou une règle exotique peut faire diverger le calcul : la fiche D&D Beyond fait foi.

Le widget relie une fiche à un personnage de `data/personnages.json` par l'identifiant du lien `liens.feuille`, sinon par le premier mot du nom. Une créature est reliée à un compagnon (`role: "compagnon"`, `compagnon_de`) par son nom, ou d'office s'il n'y a qu'un compagnon et qu'une créature ; une créature sans compagnon dans les données s'affiche quand même, sous son nom D&D Beyond.

## `rencontres-mj.json`

Rencontres préparées, lancées et jouées dans le gestionnaire (`app/rencontres-mj.js`), et le combat en cours (widget **Combat**, mode Rencontre). Depuis le 2026-10-19 ; remplace `combat.json` (une rencontre de l'outil de D&D Beyond, abandonné : le MJ joue en ligne dans Maps, sur table avec le gestionnaire).

| Champ | Contenu |
|---|---|
| `rencontres[]` | Une entrée par rencontre touchée dans le gestionnaire (voir plus bas). Une rencontre prévue des données n'en a pas tant qu'on ne l'a ni préparée, ni lancée, ni marquée terminée. |
| `correspondances` | `{ "<nom VF normalisé>": { monstre, nom } }` : la créature des données (`creatures[].nom`, en minuscules et sans accents) reliée une fois à un monstre de D&D Beyond (`monstre` : son `id`, `nom` : son nom anglais) ; sert à toutes les rencontres. |
| `combat` | Le combat lancé, ou `null` (voir plus bas). |

Une rencontre :

| Champ | Contenu |
|---|---|
| `id` | Rencontre prévue : l'`id` de `rencontres_scenarisees[]` (`rencontres-aleatoires.json`). Créée par le MJ : `mj-…` ; lancée depuis un tirage : `al-…`. |
| `origine` | `prevue` (texte dans les données, jamais supprimée), `creee` (créée dans le gestionnaire), `aleatoire` (lancée depuis un tirage du widget Rencontres) ou `maison` (2026-10-25 : lancée depuis une table d'occupants des maisons, widgets Maisons et Ici ; ni journal ni plafond des rencontres aléatoires). |
| `maison` | Maison : `{ table, lieu, de, jet, ligne, resultat, detail, comment_jouer, quand }`, le jet dans `occupants-maisons.json` d'où elle vient. Son `id` : `ma-…`. |
| `nom`, `note` | Créée ou aléatoire : son nom ; créée : la note du MJ (comment la jouer). |
| `rattachement` | Créée ou aléatoire : `{ jalon }`, `{ etape }` (`id` du déroulé), `{ lieu, sous_lieu }` (`id` de `lieux.json`), `{ de, vers }` (trajet en cours au tirage), ou `{}`. Une rencontre prévue est rattachée par les données (`lieu`, `de`/`vers`, `jalons[].rencontres`). |
| `tirage` | Aléatoire : `{ entree (id du journal de rencontres.json), rencontre (id de la fiche), moment, horloge, quand, jets (texte des jets), variante }`. |
| `brouillon` | Aléatoire, le temps de sa préparation (2026-10-25) : `true` entre « Lancer » sur la fiche du tirage et « Lancer le combat » ; le tirage n'est pas encore au journal. Fenêtre fermée avant, ou page rechargée : la rencontre est retirée. |
| `creatures[]` | Aléatoire : les créatures du tirage, `{ nom, nom_en?, note_mj?, quantite (formule), total }`. |
| `groupes[]` | Les monstres : `{ cle, monstre (id D&D Beyond), nom_beyond, nom (nom du groupe, celui de la créature des données s'il y en a une), quantite, formule (des données, relançable), creature (nom VF de la créature reliée), noms[] (nom propre de chaque créature, facultatif), ca, pv, fp, init (bonus d'initiative), avatar, role }`. CA, PV, FP et initiative sont relevés sur la fiche D&D Beyond à l'ajout. `role` (2026-10-22, facultatif) : le rôle de *Flee, Mortals!* (`embusque`, `artillerie`, `brute`, `controleur`, `meneur`, `soutien`, `sbire`, `tirailleur`, `soldat`, `solo`), deviné à l'ajout (sous-type du monstre sur D&D Beyond, « Solo », « Minion », « Brute »…, ou son étiquette ; sinon trait « Minion » : `sbire` ; « Villain Actions » : `solo`), ou à « Relire D&D Beyond » s'il n'en a pas, ou choisi dans la préparation ; `sbire` et `solo` changent le calcul de la difficulté (`app/difficulte.js`). |
| `difficulte` | Facultatif (2026-10-22) : `{ niveau (triviale, facile, standard, difficile, extreme), points (0, 1, 2, 4, 8) }`, la difficulté selon *Flee, Mortals!* notée quand la rencontre démarre et quand elle se termine ; compte dans les points de la journée d'aventure (rencontres commencées depuis le dernier repos long). |
| `statut` | Absent : à jouer. `en-cours` (démarrée), `terminee`. |
| `debut`, `fin` | `{ horloge ({ jour, minute } si l'Horloge est sur le tableau), quand (date ISO) }`. Une rencontre marquée terminée par le bloc `maj-etat` (`rencontres.terminees`) : `fin` `{ quand }`, la date de la séance seule (`AAAA-MM-JJ`). |
| `remarque` | Remarque du MJ : en la marquant terminée, ou à tout moment depuis la ligne ou la fenêtre de la rencontre (2026-11-05 : aussi sur une rencontre pas jouée, une trouvaille, une scène sans combat ; une rencontre des données prend alors son entrée). Reprise dans le prompt de fin de session, avec les rencontres jouées depuis le dernier envoi, ou à part pour celles qui ne le sont pas. |
| `remarque_maj` | Facultatif (2026-11-01) : date ISO de sa dernière modification. Une remarque modifiée depuis le dernier envoi fait revenir la rencontre dans le prompt de fin de session. |
| `bilan` | Facultatif (2026-10-23) : l'état de fin d'un combat mené dans le widget **Combat**, noté en la marquant terminée. `{ round, monstres[] { nom, pv, pv_max, mort, etats? (noms) }, heros[] { nom, pv, pv_max, a_terre, mort? } }` (héros et compagnons présents, d'après `beyond.json` à ce moment). Retiré par « Rouvrir ». Affiché sur la ligne de la rencontre (Déroulé, historique du widget Combat), dans sa fenêtre, et repris dans le prompt de fin de session. |
| `creee` | Date ISO. |

Le combat lancé (`combat`) : `{ rencontre (id), phase (prete, en-cours, combat), round, tour (clé du combattant dont c'est le tour), monstres[], heros }`. `monstres[]` suit les groupes de la rencontre (qui restent modifiables) : `{ cle (<groupe>:<rang>), groupe, monstre, nom (« Goule B » ou son nom propre), ca, bonus, init, pv, pv_max, pv_temp, etats? }` ; `etats` (2026-10-20, absent s'il n'en a pas) : ses états posés dans le widget Combat, `[{ id, nom, niveau }]` comme ceux des héros dans `beyond.json`. `heros` : `{ "pj:<id de fiche>" | "cr:<id de fiche>:<id de créature>": { init, absent } }` ; les PV et la CA des héros et de leurs compagnons sont lus sur leurs fiches (`beyond.json`). Ordre : initiative décroissante ; à égalité, les héros, leurs compagnons, puis les monstres dans l'ordre de la rencontre. Initiative : un d20 par type de monstre (même `monstre`), un par compagnon ; les héros donnent la leur. Un monstre à 0 PV passe son tour.

## `objets.json`

Objets à trouver et à donner (`app/objets.js` : widget **Objets**, Ici, Déroulé, préparation des rencontres). Depuis le 2026-10-21.

| Champ | Contenu |
|---|---|
| `objets` | `{ "<id>": entrée }`. Objet des données : l'`id` de `objets.json` ([objets.md](objets.md)), une entrée seulement s'il a été retouché, relié ou donné. Créé par le MJ : `mj-…`. |

Une entrée :

| Champ | Contenu |
|---|---|
| `cree` | `true` : objet créé dans le gestionnaire (pas dans `objets.json`). Il porte alors `nom`, `genre` (ceux de [objets.md](objets.md)), `rattachement` et `creee` (date ISO). |
| `rattachement` | Créé : `{ lieu, sous_lieu }` (`id` de `lieux.json`), `{ jalon }`, `{ etape }` (`id` du déroulé), `{ rencontre, lieu?, sous_lieu? }` (`id` d'une rencontre prévue ou créée, `rencontres-mj.json`), ou `{}`. |
| `nom`, `description`, `poids` | Objet personnalisé : le nom, la description pour les joueurs et le poids en livres (nombre entier, ou `null` ; D&D Beyond refuse les décimales) envoyés à D&D Beyond. Pour un objet des données, présents seulement s'ils ont été retouchés (sinon `nom_joueurs`, à défaut `nom`, puis `description` et `poids` de `objets.json`) ; le nom affiché dans le gestionnaire reste celui des données. |
| `cout` | Objet personnalisé : sa valeur marchande retouchée (po entières, ou `null`), envoyée comme coût à D&D Beyond ; absente : `cout` de `objets.json`. |
| `nom_beyond` | Objet du catalogue : le nom que le MJ lui donne dans l'inventaire D&D Beyond (l'extension le renomme). Absent : `nom_joueurs` tant que l'objet n'est pas identifié, sinon `nom` des données (le nom de l'objet créé par le MJ). Vide (`""`) : « Garder le nom anglais », aucun renommage. |
| `commentaire` | La note de l'objet sur D&D Beyond (« Notes » de l'objet dans l'inventaire), pour les deux sortes d'objets. |
| `quantite` | Le nombre d'exemplaires tiré quand `objets.json` le donne en dés (`"1d4"`) ; ou, depuis le 2026-10-30, le nouveau total quand le MJ en donne plus que prévu (les dons déjà faits plus le nouveau). |
| `beyond` | L'objet du catalogue de D&D Beyond choisi : `{ cle ("<id>:<entityTypeId>"), id, type (entityTypeId), nom, genre, rarete, magique, harmonisation, poids, avatar, sigle (livres), legacy, ajoutable?, auto? }`, ou `null`. `ajoutable: false` : objet générique (« Silvered Weapon »), que D&D Beyond n'ajoute pas tel quel ; la fenêtre propose ses variantes. `auto: true` (2026-10-23) : choisi d'office par la fenêtre, parce que le nom anglais désigne un seul objet des livres choisis (nom exact, sinon mêmes mots dans un autre ordre, sans quantité entre parenthèses ; 2024 avant 2014, livre avant homebrew). `null` : le MJ a retiré le lien, rien n'est plus choisi d'office. |
| `personnalise` | `true` : donné en objet personnalisé, même si `beyond` est rempli ; `false` : en objet du catalogue. Absent : d'après `objets.json` (`beyond: false` ou `nom_joueurs` → personnalisé), sinon le catalogue. |
| `dons[]` | Chaque don : `{ a ("groupe" ou id de `personnages.json`), quantite, horloge ({ jour, minute } si l'Horloge est sur le tableau), quand (date ISO), beyond?, identification? }`. `beyond` : `{ objet (id de l'objet créé dans l'inventaire D&D Beyond), type (son entityTypeId), catalogue (booléen), nom? (objet du catalogue : le nom écrit sur D&D Beyond, absent s'il garde son nom anglais ou si le renommage a échoué) }`, absent quand le don n'est que noté ; `objet` et `type` servent à « Renommer sur D&D Beyond ». `retrait` (2026-10-23) : `{ horloge, quand }`, l'annulation du don est demandée aux joueurs (retirer l'objet de leur inventaire D&D Beyond) ; le MJ la confirme ensuite (le don est retiré) ou garde le don (`retrait` retiré). `identification: true` : l'objet de D&D Beyond donné aux mêmes mains après l'objet personnalisé d'un objet à `nom_joueurs`, une fois identifié ; il ne compte pas dans la quantité donnée. « Annuler » un don le retire d'ici seulement : l'inventaire D&D Beyond se corrige sur la fiche. Un don noté par le bloc `maj-etat` (`objets.donner`) : `{ a, quantite, quand }`, `quand` étant la date de la séance seule (`AAAA-MM-JJ`), sans `beyond`. Repris dans le prompt de fin de session (dons depuis le dernier envoi). |

## `beyond-demande.json`

Demande de relevé des détails, écrite par le widget Personnages (bouton d20, « Relever les détails »). L'extension la lit à chaque relevé.

| Champ | Contenu |
|---|---|
| `details` | Date ISO de la demande. |
| `traite` | Date ISO à laquelle l'extension l'a traitée (`null` tant qu'elle ne l'a pas fait). Une demande est en attente si `details` est plus récent que `traite`. |

## `beyond-details.json`

Détails des fiches D&D Beyond, relevés **à la demande** (quand les joueurs remanient leurs fiches) par l'extension : depuis le widget (`beyond-demande.json`) ou le bouton « Relever les détails » de la fenêtre de l'extension. Calculés par `detailler()` de `extensions/mj/resumer.js`, sur les fiches lues au relevé courant. Textes en anglais, tels que sur la fiche, convertis du HTML en texte (paragraphes, listes « - »).

| Champ | Contenu |
|---|---|
| `maj` | Date ISO du relevé. |
| `fiches` | `{ "<id D&D Beyond>": détails }`. |

Détails d'une fiche : `id`, `nom`, `espece { nom, description, traits[] { nom, description }, options[] { nom, description } }` (sans taille, vitesse ni augmentations de caractéristiques), `historique { nom (VF si connue), nom_original, resume, description, aptitude { nom, description } }`, `dons[] { nom, description, categorie }` (sans les dons techniques que D&D Beyond cache), `classes[] { nom, niveau, sous_classe { nom, description } }`, `options_de_classe[] { nom, description }` (manifestations occultes, pactes…), `apparence`, `personnalite { traits, ideaux, liens, defauts, apparence }`, `notes { histoire, allies, ennemis, organisations, possessions, biens, autres }` (champs vides omis), `modifie_le`, `releve_le`.

Le widget les affiche repliés dans la fiche de chaque personnage (« Origines ») et les copie en Markdown pour l'agent IA de campagne.

## `deroule.json`

Suivi du déroulé (`deroule-campagne.json`, format 2) : étapes, jalons et pistes. Écrit par le widget **Déroulé** et par le bloc `maj-etat` (champ `deroule`) ; lu par Ici, Personnages et la fin de session. Code partagé : `app/trame.js`.

| Champ | Contenu |
|---|---|
| `etape` | `id` de l'**étape de référence** : la dernière démarrée (résumé de l'en-tête du Déroulé, « Étape suivante », prompt de fin de session), ou `null`. Changé le 2026-10-14 : les étapes sont indicatives, `etape` ne dit plus rien des autres étapes (celles d'ordre inférieur ne sont pas « passées ») ; plusieurs étapes peuvent être en cours (`suivi`). |
| `jalon` | Ancien champ (un seul jalon en cours) : à la lecture, il devient un jalon en cours dans `suivi`, puis disparaît. |
| `suivi` | Ajouté le 2026-10-12, `pistes` le 2026-10-14. `{ etapes: { "<id>": { debut, fin } }, jalons: { … }, pistes: { … } }` (dates ISO). Sans entrée : à venir ; `debut` sans `fin` : en cours (une piste : commencée) ; `fin` : terminé. Sur un élément terminé, `valide` (facultatif, 2026-11-01, date ISO) : le MJ a confirmé que tout est bon, même s'il reste quelque chose (`app/restes.js`) ; retiré quand il est rouvert. `debut` est posé la première fois que l'élément est démarré, mis en cours ou commencé ; `fin` quand le MJ le termine (bouton, cases d'une confirmation, bloc `maj-etat`) ; terminer un élément jamais commencé pose aussi `debut`. Plusieurs étapes, jalons et pistes peuvent être en cours. « Plus en cours » (« Plus commencée ») retire l'entrée ; « Rouvrir » retire `fin`. Rien n'est terminé d'office. `resurgences` (2026-11-05) : `{ "<id de piste>": { "<clé>": { jouee (date ISO), texte (le début du texte, pour s'y retrouver) } } }`, les résurgences que le MJ a cochées jouées ; la clé est l'`id` de la manifestation, sinon une empreinte de son texte (elle tient à un réordonnancement, pas à une réécriture : un texte réécrit redevient « pas jouée »). |

| `remarques` | Facultatif (2026-11-02) : remarques du MJ sur le déroulé. `{ etapes: { "<id>": { texte, maj } }, jalons: { … }, pistes: { … } }` (`maj` : date ISO). À part de `suivi` : une remarque ne change pas le statut et survit à « Plus en cours ». Reprise dans le prompt de fin de session quand elle a changé depuis le dernier envoi. `resurgences` (2026-11-05) : `{ "<id de piste>": { "<clé>": { texte, maj, de (le début du texte de la résurgence) } } }`, la remarque du MJ sur une résurgence, jouée ou non ; même clé que `suivi.resurgences`. Les clés réservées `debut` et `fin` portent la remarque sur le début et la fin de la piste. |

Démarrer une étape (bouton « Démarrer » d'une étape, « Étape suivante ») en fait l'étape de référence et la marque en cours. Une confirmation s'ouvre quand il y a quelque chose à dire : les PNJ de l'étape de l'en-tête (si elle est en cours) pas encore vus (leurs lieux et ceux de ses jalons, sauf morts, disparus, absents ; bouton « Vu » sur place), ce qui n'est pas terminé (elle, les étapes sautées dans l'ordre conseillé, leurs jalons : cases **décochées**, à cocher si c'est fait), les `pistes_attendues` de la nouvelle étape encore à venir (avec « Commencer »), et « Les héros se rendent-ils à … ? ».

**Aucun déplacement automatique.** Démarrer une étape, commencer ou terminer un jalon ne change pas `ici.json` : le widget demande si les héros se rendent au lieu de l'élément (`lieux` d'une étape, avec le `sous_lieu` de son premier jalon pas encore terminé dans ce lieu ; `lieu` et `sous_lieu` d'un jalon, sinon `vers` d'un trajet ou d'une amorce) : « Pas maintenant » (d'office), « Ils arrivent à … » (arrivée notée, voir `ici.json` ; dans le même lieu, seul le sous-lieu change), ou « Ils partent vers … » (l'itinéraire du jalon, sinon le plus court depuis le lieu des héros : le dialogue de départ du trajet s'ouvre, puis le trajet se mène dans l'Horloge et s'écrit dans `trajets.json` au départ). Après un jalon commencé ou terminé, la même fenêtre propose aussi de commencer les pistes dont il est le `debut.jalon`, de terminer celles dont il est le `fin.jalon`, et de terminer les étapes dont tous les `fin.jalons_cles` sont faits.

**Migration du format 2** (à la première ouverture avec un `deroule-campagne.json` au format 2, puis à chaque ouverture, sans effet quand il n'y a plus rien à faire) : une entrée de `suivi.jalons` dont l'`id` est devenu une piste passe dans `suivi.pistes`, mêmes dates (`pistes-vers-le-temple-d-ambre` devient `semer-le-temple-d-ambre`). Une annonce le dit. Un `id` de `suivi` (ou `etape`) qui n'existe plus ni en étape, ni en jalon, ni en piste reste dans le fichier : le bouton **Données** le signale et permet de le retirer.

## `rencontres.json`

| Champ | Contenu |
|---|---|
| `contexte` | `{ moment: "jour" \| "nuit", terrain: "abri" \| "route" \| "nature", modificateurs: { <id>: true }, a_l_arret }`. `moment` suit l'horloge quand le widget Horloge est sur le tableau (changé à chaque lever et coucher du soleil ; le MJ peut le changer entre-temps). `terrain` : où sont les héros ; `abri` (en ville, à l'intérieur) : pas de test quand le temps passe. Partagé avec le widget Horloge ; mis à jour à l'arrivée dans un lieu (ville, cité, village, château, bâtiment… : abri ; carrefour, porte, pont, col : route ; ailleurs : nature). `modificateurs` : les cases cochées des modificateurs de la procédure (`procedure.modificateurs` de `rencontres-aleatoires.json`, un guide par exemple). |
| `fenetre` | `{ debut, rencontres }` : sans horloge, fenêtre de 12 h en temps réel et nombre de rencontres comptées (bouton « Nouvelle fenêtre »). Avec l'horloge, le plafond compte les rencontres numérotées du journal dans les 12 dernières heures de jeu. |
| `journal[]` | Tests et rencontres qui ont eu lieu, du plus ancien au plus récent (300 au plus). Voir ci-dessous. Depuis le 2026-10-25, une rencontre tirée sans test (dé d'une ligne, « Rencontre ») n'y entre que lancée ou notée ; un test y entre toujours, sa rencontre `proposee` jusque-là. Annulée (widget Combat), supprimée, ou sa ligne effacée : son numéro et sa place dans le plafond sont rendus (`compteurs`), la ligne d'un test reste avec sa rencontre `ecartee`. |
| `retirees[]` | `id` de rencontres **cachées des tables** (changé le 2026-10-15) : le dé est relancé s'il tombe dessus (dans une table principale comme dans une sous-table), et elles restent affichées, grisées, dans l'onglet Tables. N'importe quelle rencontre : œil de sa ligne dans l'onglet Tables, « Cacher des tables » de sa fiche (cavalier détruit, rencontre devenue sans objet dans le scénario) ; le même œil la remet. |
| `rencontrees[]` | Ajouté le 2026-10-15. `id` des rencontres **uniques rencontrées** (case « Rencontrée » de l'onglet Tables et de leur fiche). Une unique qui sort n'est plus retirée d'office : sa fiche demande « la cacher des tables ? » ; « Cacher · rencontrée » la pose ici et dans `retirees[]`, décocher « Rencontrée » l'enlève des deux. Rencontrée ou cachée : elle ne sort plus. Absent (état d'avant) : les uniques de `retirees[]`. |
| `compteurs` | `{ "<id de rencontre>": n }` : nombre de fois où elle est sortie (le corbeau-garou change à la 2e). |
| `suivis[]` | `{ id, rencontre, texte, depuis, resolu }` : suites à jouer (filature des loups-garous, escorte des corbeaux). |

Une entrée de `journal` : `id`, `quand`, `horloge` (`{ jour, minute }`, l'heure de jeu, quand le widget Horloge est sur le tableau), `type` (`test`, `rencontre`, `evenement` : un événement de campagne ajouté comme rencontre, avec `evenement { id, nom }` et son `numero`, [evenements.md](evenements.md) ; `espions` dans les entrées de l'ancien bouton Espions, retiré le 2026-10-24), le contexte du moment (`moment`, `terrain`, `modificateurs` : les `id` des modificateurs cochés, `a_l_arret`), puis selon le cas `test { jet, seuil, reussi }`, `tirages[]`, `rencontre`, `quantites[] { nom, nom_en?, note_mj?, formule, total }` (`nom_en` et `note_mj` recopiés de la créature des données), `tirage_externe`, `sous_table { formule, total, resultat }`, `variante`, `numero` (seulement une fois qu'elle a eu lieu), `proposee` (2026-10-25 : la rencontre d'un test réussi, pas encore lancée ni notée ; ni numéro, ni place dans le plafond, ni babiole notée), `ecartee` (la rencontre d'un test que le MJ a écartée, ou annulée après coup : elle n'a pas eu lieu), `sans_effet`, `retiree_auto` (avant le 2026-10-15 : unique retirée d'office par ce tirage), `unique_gardee` (le MJ a répondu « La garder » à la question de sa fiche), `aucune`, `note`.

- `tirages[]` (depuis le format 2 de `rencontres-aleatoires.json`, 2026-10-15) : la chaîne des jets d'une seule rencontre, la table principale d'abord, puis chaque sous-table où elle a mené. Chaque jet : `{ table, formule, total, detail, relances?, force? }`. `table` : `id` de la table de `rencontres-aleatoires.json` ; `formule` : le dé lancé (`1d20+1d12`, `1d20` avec un modificateur, `1d10` dans une sous-table) ; `total` et `detail` (`"15 + 8"`) : le jet retenu, `total` à `null` si toutes les relances sont tombées sur des rencontres retirées ; `relances[]` : `{ total, detail, rencontres[] }`, les jets d'avant tombés sur une ligne dont tout était retiré (`id` des rencontres ou des sous-tables de la ligne) ; `force: true` : ligne choisie dans l'onglet Tables (« Tirer cette ligne ») au lieu d'un jet, `total` est alors le premier jet de la ligne. La rencontre finale est `rencontre`, avec ses `quantites`.
- `tirage_externe` (idem) : l'objet tiré dans un autre fichier de `data/` par l'option de la ligne (une babiole) : `{ jeu, table, formule, jet, id, nom, texte, note_mj, donnee? }`, la ligne tirée recopiée telle qu'elle était dans `data/<jeu>.json` (`id` : son `id` de ligne). `donnee: true` (avant le 2026-10-15) : la babiole a été notée dans `distribuees` de `babioles.json` par ce tirage. Depuis, une babiole tirée n'est plus donnée d'office : seule sa fenêtre s'ouvre, et le MJ la donne (« Donner »). `{ jeu, table, absent: true }` si la table visée est introuvable, `aucune: true` s'il n'y a plus rien à tirer (tout est déjà donné).
- Entrées d'avant le format 2 : `table` (la table principale), `tirage { formule, total, detail }` (un seul jet) et `relances[] { jet, rencontre }` à la place de `tirages[]`. Elles restent lisibles : les outils lisent `tirages[]`, sinon ces trois champs.

## `ecran-joueurs.json`

Plugin Écran des joueurs (`app/plugins/ecran-joueurs.js`, voir [plugins.md](plugins.md)), format 2 (2026-11-05 ; le format 1, du 2026-11-02, est repris au chargement : `affichage`, `image`, `mode` et `diffusion` deviennent `ecran`). Écrit par la page du MJ seule ; la page joueurs ne lit que le canal.

| Champ | Contenu |
|---|---|
| `carte` | `id` de la carte affichée dans l'index de la bibliothèque d'images ([images.md](images.md)), toujours la version MJ (la version joueurs est envoyée d'après `paire`), ou `null`. |
| `mode` | `direct` (défaut : ce que montre le widget est ce que voient les joueurs) ou `preparation` (le MJ prépare dans le widget ; les joueurs gardent `diffusion`). |
| `ecran` | Ce que voient les joueurs : `{ base ("tableau" : le tableau des joueurs, vivant ; "carte" : la carte `carte`, en direct), carte (id, ou null), gele (vrai : l'écran garde `instantane`, la carte telle qu'elle était quand le MJ l'a gelée, le temps de la retoucher), instantane (la carte de la scène, [plugins.md](plugins.md), ou null), image ({ chemin, legende, rotation? (0, 90, 180, 270 ; absente : 90 si l'image est plus haute que large, sinon 0), largeur?, hauteur? (lues au chargement pour une image hors de la bibliothèque) } : une image diffusée par-dessus, ou null : la retirer rend la base) }`. « Diffuser » met la carte de l'atelier à l'écran ; quand `ecran.carte` est la carte de l'atelier et que l'écran n'est pas gelé, chaque geste part aux joueurs. |
| `rotations` | `{ "<id d'image>": 0 | 90 | 180 | 270 }` : la rotation du fond du tableau, par image (absente : 90 pour une image plus haute que large, sinon 0). |
| `cartes` | `{ "<id>": { echelle { px_case, origine_x, origine_y } | null (calibrage : pixels par case, coin de case d'origine), zoom ("pouce", "ecran" ou un nombre : k fois l'échelle de base), rotation (0, 90, 180, 270), cadrage { x, y } (centre du cadre des joueurs, px de la carte), brouillard { base ("cache" | "revele"), formes[] }, grille } }`, créée au premier affichage d'une carte, gardée (le brouillard d'une carte à demi explorée reste). Formes, en px de la version MJ : `{ op ("revele" | "cache"), type: "rect", x, y, w, h }`, `{ op, type: "trait", points [[x, y]…], largeur, forme? ("carre" | "rond" : des empreintes le long du chemin ; absente : un trait rond continu), aimante? (vrai : une empreinte par case, points aux centres des cases) }`, `{ op, type: "cercle", cx, cy, r }` (tracé depuis son centre), `{ op, type: "polygone", points }`. Les formes sont peintes nettes, dans l'ordre (recacher défait révéler) ; le brouillard entier est flouté au rendu (`adouci` du plugin, [plugins.md](plugins.md)) ; un `adouci` d'anciennes formes est ignoré. Annotations, px de la version MJ, vues des joueurs aussi : `terrains [{ type ("difficile" | "feu" | "glace" | "vegetation" | "arcane" | "ombre"), forme (comme une forme du brouillard, sans `op`) }]`, `jetons [{ type ("porte" | "piege" | "coffre" | "repere" | "corps" | "lumiere" | "passage"), variante? (piège : "pics" | "fosse" | "feu" | "fleches" | "gaz" | "lame" | "poison"), x, y }]` (le centre, une case de large), `mesures [{ type ("distance" | "cone" | "cube" | "cylindre" | "emanation" | "ligne" | "sphere"), x1, y1, x2, y2 }]` (de l'origine au point glissé : longueur, rayon, côté). Une carte disparue de l'index est ignorée. |
| `tableau` | `{ fond_defaut (id d'image, ou null), fonds { "<id de lieu>": "<id d'image>" }, rotation? (0, 90, 180, 270 : le tableau tourné, indépendamment de son fond ; absente : la rotation par défaut du plugin) }` : le fond du tableau des joueurs, celui du sous-lieu des héros, sinon de leur lieu, sinon celui de la campagne. |

## `session.json`

Écrit par le bouton **Session** (fin de session, voir [maj-etat.md](maj-etat.md)).

| Champ | Contenu |
|---|---|
| `dernier_export` | Date ISO du dernier prompt copié ou téléchargé (« Avant l'analyse ») : le prompt suivant ne liste que ce qui est arrivé depuis (arrivées dans un lieu, temps de jeu écoulé, rencontres tirées et jouées, noms retenus, babioles et objets donnés) ; les origines des personnages ne sont jointes d'office que si elles ont été relevées depuis. |
| `historique[]` | `{ quand, session, resume, changements }` : chaque bloc `maj-etat` appliqué, du plus ancien au plus récent (50 au plus). |
