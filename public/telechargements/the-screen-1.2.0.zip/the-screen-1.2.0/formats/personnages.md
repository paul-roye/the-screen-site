# `data/personnages.json` — format 2

Les personnages joueurs, leurs compagnons et l'état du groupe. Lu par le widget **Personnages**. Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

Ce fichier est **le lore des personnages pour le gestionnaire** (onglets Lore et Secret de leurs fiches) : l'IA de la campagne l'écrit d'après ses sources (le wiki importé, `wiki/wiki-complet.md`, si la campagne en a un ; les documents du MJ) ; le gestionnaire ne lit pas le texte du wiki. Le MJ peut retoucher le lore et les secrets dans le gestionnaire : ses retouches (`etat/lore.json`, [etat.md](etat.md)) s'affichent par-dessus ce fichier, et le prompt de fin de session les donne à l'IA pour qu'elle les reprenne ici (voir « Lore » plus bas).

Valeur de `source` propre à ce fichier : `"Wiki"` (la fiche du joueur sur le wiki), en plus des sources de la campagne (`"MJ"`…).

## Ce qui change par rapport au format 1 (2026-10-13)

- **`personnages[].pistes` est retiré.** Les pistes de campagne d'un personnage sont désormais des pistes du déroulé avec `personnage` ([deroule-campagne.md](deroule-campagne.md), `pistes[]`). Le widget Personnages les y retrouve.
- **`secrets[].etapes[]`** : une étape de quête renvoie à un `jalon` **ou** à une `piste` du déroulé. Une quête personnelle enchaîne ainsi des moments précis (jalons) et des fils à disséminer (pistes).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | non | Ce que contient le fichier. |
| `groupe` | oui | Le groupe (ci-dessous). |
| `personnages` | oui | Personnages joueurs et compagnons (ci-dessous), dans l'ordre d'affichage voulu. |

### `groupe`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `nom` | oui | Nom du groupe (« Un groupe de héros »). |
| `niveau` | non | Entier : le niveau donné par le MJ à l'agent. **Valeur de secours** : quand le gestionnaire lit les feuilles D&D Beyond, le niveau lu (écrit dans `etat/`) l'emporte. Absent tant que le MJ ne l'a pas donné. |
| `etape` | non | `id` d'une étape de `deroule-campagne.json` (`funeste-demeure-etages`). |
| `lieu_actuel` | non | `id` d'un lieu de `lieux.json`. |
| `lieux_visites` | oui | `id` de lieux de `lieux.json`, dans l'ordre de visite. Tableau vide possible. |
| `pnj_rencontres` | oui | `id` de PNJ de `pnj.json` que les joueurs ont rencontrés ou connaissent (par une lettre, par exemple). Indicatif : le suivi coché par le MJ dans `etat/pnj.json` reste la référence en jeu. |
| `documents` | oui | Documents trouvés : `[{ id, nom, resume, wiki? }]`. Tableau vide possible. |
| `import_wiki` | si wiki | Date et heure (ISO 8601) du dernier import du wiki pris en compte par l'agent, copiée de `wiki.json` → `importe_le`. Le widget peut signaler qu'un import plus récent n'a pas encore été traité. |
| `wiki` | non | Page du groupe sur le wiki : `{ id, url }`. |
| `journal` | non | Page du journal de bord sur le wiki : `{ id, url }`. |
| `source`, `fiche` | oui | |

### `personnages[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant stable (`isolde`, `bertrand-de-vauclair`). |
| `nom` | oui | Nom complet. |
| `nom_court` | non | Prénom ou surnom pour les listes (« Bertrand »). |
| `role` | oui | `personnage` ou `compagnon`. |
| `compagnon_de` | si compagnon | `id` du personnage. |
| `joueur` | non | Prénom du joueur, si le MJ le donne. |
| `classe`, `race` | oui | Noms en français (« Occultiste », « Tieffelin »). `race` peut valoir « Inconnue ». |
| `historique` | non | Historique D&D (« Noble »). |
| `portrait` | non | Image du personnage : un chemin depuis le dossier de la campagne (`images/isolde.webp`) ou une adresse (`https://…`). Voir « Portrait » plus bas. |
| `accroche` | oui | Une ligne : qui il est à la table. |
| `apparence` | conseillé | Quelques phrases. Rien de secret. |
| `personnalite` | conseillé | Quelques phrases. Rien de secret. |
| `origine` | conseillé | Ce que **tous les joueurs** savent de son passé. Rien de secret. |
| `motivations` | non | Chaînes. |
| `objets_notables` | non | `[{ nom, texte }]` : objets qui comptent pour l'histoire. Rien de secret. |
| `allegeances` | non | Chaînes (« Ordre du Gantelet », « Tyr »). |
| `secrets` | oui | `[{ sujet, texte, etapes? }]` : ce qui est masqué sur le wiki (balises spoiler), et ce que le MJ décide sans le dire aux joueurs. Connu du MJ, pas des autres joueurs. Tableau vide possible. `etapes` : voir « `secrets[].etapes` » plus bas. |
| `pistes` | — | **Retiré au format 2** : voir `pistes[]` avec `personnage` dans [deroule-campagne.md](deroule-campagne.md). |
| `liens` | oui | `{ wiki?: { id, url }, feuille?: url }` : la page du wiki, et la feuille de personnage (D&D Beyond, `https://www.dndbeyond.com/characters/<numéro>`). Une entrée absente signifie « pas encore connue ». Le numéro de la feuille sert au gestionnaire pour lire niveau et points de vie. |
| `source`, `fiche` | oui | `"Wiki"` et `campagne/Personnages-joueurs.md`. |

### `secrets[].etapes` (facultatif)

Pour un secret qui se lit comme une suite d'étapes (la quête personnelle d'un personnage, par exemple « Déroulé de la quête personnelle » d'Isolde).

| Champ | Obligatoire | Contenu |
|---|---|---|
| `numero` | oui | Entier, 1 à N : l'ordre d'affichage. |
| `texte` | oui | Ce qui se passe à cette étape. Une à trois phrases. |
| `jalon` | non | `id` d'un jalon de [deroule-campagne.json](deroule-campagne.md) : un moment précis de la trame. |
| `piste` | non | `id` d'une piste de [deroule-campagne.json](deroule-campagne.md) : un fil à disséminer. Une étape renvoie à un `jalon` **ou** à une `piste`, pas aux deux. |

Affichage : quand `etapes` est présent, le widget affiche **une liste numérotée** (par `numero`) **à la place de** `texte`. `texte` reste rempli (la même liste, une étape par ligne, « 1. … ») pour un outil qui ne connaît pas encore `etapes`. Chaque étape qui a un `jalon` ou une `piste` porte un lien qui ouvre le widget Déroulé sur cet élément (déplié), avec une icône qui distingue jalon et piste, et son statut (à venir, en cours ou commencée, terminé). Un `jalon` ou une `piste` introuvable : avertissement, l'étape s'affiche sans lien.

## Les pistes d'un personnage

Elles sont dans `deroule-campagne.json` → `pistes[]`, avec `personnage`. Le widget Personnages les liste dans la fiche du personnage (nom, statut, lien vers le Déroulé), à côté de ses secrets.

## Portrait

Le gestionnaire (Personnages, Combat, Tarokka) prend, dans l'ordre : `portrait` ; sinon le portrait que l'import du wiki a téléchargé (`wiki/wiki.json`, page `liens.wiki.id`, `portrait.fichier`, pour une campagne qui a un wiki et une catégorie des héros : [campagne.md](campagne.md)) ; sinon, pour un personnage joueur, l'avatar de sa feuille D&D Beyond ; sinon une initiale. Champ facultatif, ajouté au format 2 sans changer de numéro (2026-10-24).

## Lore

`accroche`, `apparence`, `personnalite`, `origine`, `motivations`, `allegeances`, `objets_notables` et `secrets` (hors ceux en `etapes`) sont l'onglet Lore et l'onglet Secret de la fiche. Le MJ les retouche dans le gestionnaire (« Modifier ») : la retouche est gardée dans `etat/lore.json` et affichée à la place du champ, un crayon orange le signale. Le prompt de fin de session la donne à l'IA (« Lore retouché par le MJ ») : à reprendre ici, dans le même champ, au prochain export. Dès que le fichier dit la même chose (aux espaces près), le gestionnaire oublie la retouche. Une retouche du MJ fait foi sur le wiki.

## Secrets

- Le gestionnaire est l'outil du MJ seul : `secrets` et les pistes d'un personnage s'affichent **sans masquage** ni clic supplémentaire (décision du MJ).
- L'agent ne met **aucun** texte secret ailleurs que dans `secrets` (ni dans `origine`, ni dans `apparence`) : ces champs peuvent servir à des textes montrés aux joueurs.

## Contrôles attendus du gestionnaire

- **Identifiants et rôles :** `id` uniques ; `role` connu ; chaque `compagnon_de` désigne un `personnage`.
- **Étapes de quête :** dans chaque `secrets[].etapes`, des `numero` entiers uniques ; pas à la fois `jalon` et `piste` ; des `jalon` et des `piste` présents dans `deroule-campagne.json`.
- **Groupe :** `groupe.etape` existe dans `deroule-campagne.json`, `groupe.lieu_actuel` et `groupe.lieux_visites` dans `lieux.json`, `groupe.pnj_rencontres` dans `pnj.json`.
- **Liens vers le wiki :** chaque `liens.wiki.id` existe dans `wiki/wiki.json` (avertissement seulement).
- **Références non trouvées :** pour les étapes de quête, et quand le fichier visé n'est pas chargé, le contrôle donne un avertissement seulement.
