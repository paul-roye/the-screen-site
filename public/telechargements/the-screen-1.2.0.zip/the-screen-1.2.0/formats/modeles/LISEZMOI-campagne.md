# Dossier de la campagne

Créé par le gestionnaire de campagne (accueil, « Nouvelle campagne »). Il s'ouvre sous `http://localhost:8735/<id de la campagne>/`.

- `manifeste.json` : les réglages de la campagne (titre, charte, vocabulaire, liens…), modifiables dans le gestionnaire (bouton **Campagne**, onglet « Campagne »). Format : `formats/campagne.md`.
- `data/` : les données de jeu, à produire par une IA d'après `data/LISEZMOI.md` et les fiches de `formats/`.
- `etat/` : ce que le gestionnaire enregistre pendant les séances (`etat/LISEZMOI.md`).
- Facultatifs : `wiki/` (import du wiki vvd.world, si la campagne en a un), `musique/` (pistes d'ambiance), `carte.json` (carte des trajets), `images-library/` (la bibliothèque d'images, hors dépôt git, importée depuis la fenêtre Campagne, onglet « Images »), `bibliotheque.json` (règles de la bibliothèque d'images, `formats/images.md`), `sources/` (les livres et PDF de la campagne, hors dépôt git).

Seul ce dossier est propre à la campagne. Le reste du gestionnaire est commun à toutes les campagnes et ne se modifie pas (voir `AGENTS.md` à la racine).
