# État de la campagne : écrit par le gestionnaire

Ce dossier est **écrit par le gestionnaire de campagne** pendant les séances : où sont les héros, l'heure de jeu, le déroulé suivi, les rencontres tirées, les objets donnés, la disposition du tableau… Format : `formats/etat.md` du gestionnaire.

- **Le gestionnaire fait foi** pour l'avancée de la campagne.
- **Une IA n'écrit jamais ici.** Elle rend ses changements dans un bloc `maj-etat` (`formats/maj-etat.md`), que le MJ colle dans le bouton **Session** du gestionnaire ; chaque changement lui est montré avant d'être appliqué.
- Le MJ peut corriger un fichier à la main, **serveur arrêté**, en suivant `formats/etat.md`. Le serveur garde la première version du jour de chaque fichier dans `sauvegardes/AAAA-MM-JJ/`.
- Les fichiers se réfèrent aux `id` de `data/` : un `id` renommé dans les données laisse ici un renvoi orphelin (signalé par le bouton Données).
