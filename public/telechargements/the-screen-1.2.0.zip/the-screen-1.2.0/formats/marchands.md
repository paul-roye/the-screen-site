# `data/marchands.json` — format 1

Ce qu'on achète dans le monde de la campagne, marchand par marchand, et à quel prix. Lu par le widget **Marchands**.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | non | Ce que contient le fichier. |
| `monnaies` | oui | Valeur de chaque pièce en pièces de cuivre : `{ "pc": 1, "pa": 10, "pe": 50, "po": 100, "pp": 1000 }`. Sert aux conversions du panier. |
| `conseil` | non | Conseil de mise en scène. |
| `vins` | non | `[{ nom, qualite }]` : les vins du pays, cités dans les cartes des tavernes. |
| `marchands` | oui | Voir ci-dessous. |

### `marchands[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `nom` | oui | L'`id` est celui du sous-lieu dans `pnj.json` quand il existe (`eau-bleue`). Les noms sans traduction VF restent en version originale. |
| `type` | oui | « magasin général », « taverne »… (badge). |
| `lieu` | oui | `id` du lieu commun à tous les fichiers (`aurval`) : sert au filtre par ville. |
| `zone`, `emplacement` | non | Code de zone du livre ; où le trouver en ville. |
| `tenanciers` | oui | `id` de PNJ de `pnj.json` (tableau vide si personne). Le widget ouvre leur fiche au clic. |
| `description` | oui | Ce qu'on voit en entrant. |
| `a_jouer` | non | Comment jouer le marchand. |
| `regle_de_prix` | si pas d'articles | Ce qu'il vend et à quel prix par rapport au Manuel des joueurs, quand il n'y a pas de liste. |
| `marchandage` | non | S'il marchande, et comment. |
| `articles` | oui | Voir ci-dessous ; tableau vide quand `regle_de_prix` suffit. |
| `services` | non | Chaînes. |
| `original`, `source`, `fiche`, `pages_pdf` / `pages_livre` | | Voir [README.md](README.md). |

### `marchands[].articles[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `nom` | oui | |
| `prix` | oui | Le prix tel qu'on l'annonce (`"5 po"`, `"pas à vendre"`). |
| `prix_pc` | si à vendre | Le même en pièces de cuivre (nombre) : tri et panier. Absent, l'article ne peut pas aller dans le panier. |
| `categorie` | non | « boisson », « repas », « hébergement »… : les articles d'un marchand sont regroupés par catégorie. |
| `note` | non | Précision affichée sous l'article. |

## Ce que fait le widget

- Filtre par ville (d'après `lieu`), recherche d'un article, tri par nom ou par prix.
- Fiche de chaque marchand ; un clic sur un tenancier ouvre sa fiche de PNJ (avec son suivi de campagne).
- Panier : articles des listes, plus des lignes libres (libellé, montant, pièce) pour les marchands sans liste. Total rendu en po, pa et pc, et en pc. Le panier est gardé dans `etat/marchands.json` (voir [etat.md](etat.md)).

## Contrôles faits par le gestionnaire

`monnaies` avec au moins `pc`, `pa`, `po` en nombres ; `id` de marchands uniques ; chaque marchand a un `lieu` et soit des articles, soit une `regle_de_prix` ; chaque article a un `nom`, un `prix`, et un `prix_pc` numérique quand il est présent.
