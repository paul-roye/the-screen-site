# `musique/` — musique d'ambiance, format 1

La musique d'ambiance du widget **Musique** : des pistes de playlists YouTube, étiquetées par thème, lieu, PNJ et faction pour les retrouver vite en séance.

Ce n'est **pas** un export de l'agent IA de campagne, ni l'état d'un outil :

- `musique/sources.json` est tenu à la main (ou par Claude) : les playlists, les vidéos écartées, les étiquettes et les mots-clés qui les posent ;
- `musique/pistes.json` en est tiré par `scripts/import-musique/importer-musique.ps1` (`outils/Importer la musique.cmd`). **Ne pas le modifier à la main** : il est réécrit à chaque import.

Les deux sont versionnés. Relancer l'import quand une playlist s'est enrichie, ou après avoir changé `sources.json` (les durées déjà connues sont reprises : seules les vidéos nouvelles sont interrogées).

## `sources.json`

| Champ | Contenu |
|---|---|
| `schema`, `jeu` (`musique-sources`), `titre`, `avertissement` | Enveloppe. |
| `playlists[]` | Dans l'ordre d'affichage. `id` de la playlist YouTube (`PL…`, ou `OLAK…` pour un album), `auteur` (la chaîne : « FaboMusic »), `nom` (court, celui de la playlist : « Curse of Strahd », « Combats légers » ; sans `auteur`, `nom` est pris pour la chaîne, comme avant), `qualite` facultatif (`moindre` : signalé dans la liste), `etiquettes[]` facultatif (posées sur toutes ses pistes : `theme:combat` pour une playlist de combats), `exclure[]` : `{ id, pourquoi }`, les vidéos à ne pas reprendre (compilations, albums complets, doublons ; l'exclusion vaut pour cette playlist seule). Une vidéo présente dans plusieurs playlists n'est gardée qu'une fois, dans la première ; les suivantes vont dans son `aussi` et lui donnent leurs `etiquettes`. |
| `themes[]` | Les mini-boutons du widget, jamais en boucle. `id` : `ouverture` et `fin` (début et fin de séance), ou `pj:<id de personnages.json>` pour le thème d'un héros. `video` : l'identifiant YouTube (11 caractères, après `watch?v=`), ou `null` tant qu'il n'est pas choisi. Pour la campagne : `nom` et `icone` (icône de la charte : `chateau`, `cercueil`…). Un héros n'a besoin que de `id` et `video` : le widget prend son nom et son initiale dans `personnages.json`, et montre aussi les héros absents de la liste (grisés). |
| `etiquettes[]` | `{ id, nom, groupe? }`, dans l'ordre des menus. `id` : `<catégorie>:<identifiant>`, catégorie `theme`, `lieu`, `pnj` ou `faction`. Pour `lieu`, `pnj` et `faction`, l'identifiant est celui de `data/` ([lieux.json](lieux.md), [pnj.json](pnj.md), [factions.json](factions.md)) quand il existe ; sinon un identifiant libre (`pnj:le-passeur`, `lieu:mont-gris`). `nom` : court, pour une petite étiquette (« Isolde », « Le passeur »). `groupe` (thèmes seulement) : le groupe du menu Thème (`Action`, `Ambiance`, `Personnages`, `Lieux`, `Peuples`, `Moments`), dans l'ordre où il paraît la première fois. |
| `bruit[]` | Facultatif : les noms de l'aventure que les titres YouTube répètent (`["curse of strahd"]`), ôtés du nom court des pistes (expressions régulières .NET, sans tenir compte de la casse). |
| `regles[]` | `{ motif, etiquettes[] }` : une expression régulière (.NET, sans tenir compte de la casse) cherchée dans le titre YouTube ; chaque piste dont le titre correspond reçoit les étiquettes. Un sous-lieu se donne avec son lieu (`lieu:aurval` et `lieu:cerf-blanc`). |
| `pistes` | `{ "<id YouTube>": { nom, ajouter[], retirer[], note } }`, tout facultatif : corriger une piste après les règles (nom affiché, étiquettes en plus ou en moins, note pour le MJ en français, montrée au survol). |

Ordre des étiquettes d'une piste : les règles, les `etiquettes` de ses playlists, ses `ajouter` ; puis, si elle n'a toujours aucun lieu, le lieu de chacun de ses PNJ (`lieu` de [pnj.json](pnj.md) : où on le croise d'abord) ; enfin ses `retirer` (qui peuvent ôter ce lieu). Le lieu ainsi posé doit être déclaré dans `etiquettes`.

**Thèmes** : généralistes, pour servir aussi à d'autres campagnes et à des playlists qui ne sont pas propres à Curse of Strahd ; chaque piste en a au moins un. Les thèmes de lieu disent l'ambiance d'un lieu, pas son architecture : `ville`, `village`, `taverne` (taverne et échoppe : un intérieur vivant), `demeure` (maison, manoir, tour habitée), `chateau` (forteresse, cour, salle du trône), `donjon` (souterrain, cryptes, temple oublié : le lieu qu'on explore), `ruines`, `nature`, `neige` (neige et froid), `desert`, `mer`, `repos` (feu de camp). `sons` (groupe Ambiance) marque les ambiances sonores sans musique (pluie, taverne, marché). Un lieu effrayant prend aussi `horreur` (la Funeste demeure : `demeure` et `horreur`) ; un lieu saint, `sacre`.

Le script signale une étiquette utilisée sans être déclarée, une exclusion ou un réglage de piste qui ne vise plus rien, et liste les pistes sans thème. Il lit `data/pnj.json` (paramètre `-Pnj`) s'il existe : sans lui, les pistes des PNJ ne reçoivent pas de lieu. Il lit aussi `etat/musique.json` (paramètre `-Etat`) pour signaler les retouches du widget qui visent une vidéo disparue ou une étiquette qui n'existe plus ; il ne les applique pas (`pistes.json` reste le résultat de l'import, ce qui permet au widget de « Rétablir »).

## `pistes.json`

| Champ | Contenu |
|---|---|
| `schema`, `jeu` (`musique`), `titre`, `genere_le`, `avertissement` | Enveloppe habituelle. |
| `sources[]` | `{ id, nom, auteur?, titre, pistes, qualite? }` : chaque playlist, son titre sur YouTube (vide pour un album) et le nombre de ses pistes gardées (celles qui ont une autre playlist pour `source` comprises). |
| `themes[]` | Ceux de `sources.json`, avec `titre` et `duree` (secondes) lus sur YouTube quand `video` est donné. |
| `etiquettes[]` | `{ id, nom, groupe?, pistes }` : celles de `sources.json`, avec le nombre de pistes qui les portent. |
| `pistes[]` | Une par vidéo, dans l'ordre des playlists. `id` (YouTube, 11 caractères), `nom` (court : le titre sans « Unofficial Curse of Strahd Soundtrack », « 1h Loop », « NO AI », le genre de la playlist…), `titre` (complet), `duree` (secondes), `source` (`id` de la première playlist qui la contient), `aussi[]` facultatif (les autres), `etiquettes[]` (triées comme `etiquettes`), `note` facultative. |

## Chaque campagne a sa musique ; paquets par défaut

`musique/` est dans le dossier de chaque campagne (`campagnes/<id>/musique/`), importé par `outils/Importer la musique.cmd -Campagne <id>`.

À la création d'une campagne (accueil, « Nouvelle campagne », section « Musique »), des cases ajoutent des **paquets par défaut** : `modeles/musique/<paquet>/sources.json` et `pistes.json`, listés dans `modeles/musique/paquets.json` (`{ id, nom, description, playlists, pistes, genre? }`). La page les fusionne (`app/musique-paquets.js` : playlists, étiquettes et règles réunies, une vidéo de deux paquets gardée une fois, avec l'autre playlist en `aussi`) et le serveur écrit le résultat dans `musique/` de la nouvelle campagne ; `sources.json` y garde `paquets` (les paquets d'origine). Ensuite, c'est la musique de la campagne : on l'importe et on la retouche comme celle de toute campagne.

| Paquet | Contenu | Coché d'office |
|---|---|---|
| `fantasy` (« Fantasy médiévale ») | FaboMusic (combats légers, batailles, combats en boucle, forêts elfiques, tavernes et échoppes) et Bardify (combats, ambiances sonores, événements, villes et villages, donjons et cryptes, tavernes, voyages) | toujours |
| `curse-of-strahd` | Les trois bandes originales non officielles de Curse of Strahd (Supernova Collective, FaboMusic, MAB Music), les notes du MJ sur leurs pistes, et les thèmes de début et de fin de séance | genre Curse of Strahd |

Les paquets ne gardent que les étiquettes `theme:` (déclarations, règles, retouches de `pistes`) : les `lieu:`, `pnj:` et `faction:` de la campagne d'origine renvoient à ses données, qu'une nouvelle campagne n'a pas, même une autre campagne de Curse of Strahd (ses `id` viennent de son IA). Ils se posent ensuite au crayon d'une piste, ou dans `sources.json`. Pas de thèmes de héros (`pj:`) : le widget montre les héros de la campagne, grisés, à choisir. Le paquet Fantasy n'a pas les notes du MJ (elles parlent de Curse of Strahd) ni les thèmes de séance (à choisir).

Les paquets sont **tirés de la musique d'une campagne de l'auteur du gestionnaire** par son script de mainteneur (qui la lit sans la changer). Ne pas modifier les paquets à la main : ils sont réécrits à chaque version.

## Ce que fait le widget

- Un clic sur une piste la lance (le son seul : le lecteur YouTube est caché), en boucle d'office ; un autre clic l'arrête. Le corps du widget montre la piste choisie, son état et la boucle.
- L'en-tête, même réduit, sur une seule ligne : « Lancer / Arrêter » (petit), les mini-boutons des thèmes (la campagne avec l'icône de `themes`, puis les héros : icône de personnage et initiale, en violet, grisés sans thème ; un clic lance le thème, sans boucle, un autre l'arrête) et le volume (l'icône coupe le son, le curseur règle). Quand la place manque, l'en-tête se resserre d'un cran à la fois, mesuré : le titre ne garde que son icône, puis le curseur du volume passe dans une petite fenêtre ouverte par l'icône, puis les héros ne gardent que leur initiale, puis les écarts de l'en-tête se resserrent. Widget déplié, à droite de l'en-tête, le bouton des filtres (Lucide `sliders-horizontal`) masque la recherche et les filtres (choix propre au poste, gardé dans le navigateur), orange quand ils cachent un filtre actif. Vérifié dans un widget de 4 colonnes (2026-10-21, avec ce bouton et la poignée de déplacement) : à 1600 px (430 px de large), le titre et le volume se replient ; à 1280 px (403 px), tous les crans.
- Filtres : recherche (nom, titre YouTube, note, playlists, nom des étiquettes : « cerf blanc » trouve « White Stag Inn »), puis des boutons icônes qui ouvrent chacun une palette de puces (avec le nombre de pistes ; le menu reste ouvert pour enchaîner) : **Thème** (par `groupe`, cumulables : Combat et Boss), **Lieu** (« Ici » en tête : le lieu où sont les héros, widget Ici, son sous-lieu d'abord ; les lieux sans leurs sous-lieux, qui paraissent sous le lieu choisi), **PNJ / Factions** et **Auteurs / Playlists** (deux vues du même menu : ses onglets, ou un nouveau clic sur le bouton quand il est ouvert), favoris (l'étoile au bout d'une ligne, gardés dans `etat/musique.json`). Un seul lieu, PNJ, faction, auteur ou playlist à la fois : en choisir un autre remplace le premier. Clic sur une étiquette d'une ligne : le même filtre.
- Une ligne : le nom et la durée, puis le lieu (le sous-lieu à la place de son lieu), les PNJ, les factions (cachées quand un PNJ ou un lieu du même nom les porte), les thèmes, et l'auteur à droite ; au survol du nom, le titre YouTube, la note et les autres playlists.
- **Retouche à la main** : le crayon au bout d'une ligne (au survol ; bleu et toujours visible sur une piste retouchée) ouvre la palette de toutes les étiquettes de `pistes.json`, celles de la piste enfoncées ; un clic en ajoute ou en retire une, un point orange marque l'écart à l'import, « Rétablir » le défait. Gardé dans `corrections` de `etat/musique.json` ([etat.md](etat.md)), pas dans `sources.json` : la retouche survit aux imports. Pour une correction qui doit valoir dans toute campagne (ou par une règle), `pistes` et `regles` de `sources.json` restent le bon endroit.
- **Pistes cachées** : l'étiquette `theme:cachee` (« Cachée », groupe `Liste` ; le widget l'ajoute si `sources.json` ne la déclare pas) retire une piste de la liste et des nombres des menus, sauf quand on filtre sur elle (menu Thème › Liste › Cachée). Elle se pose par « Cacher » en tête de la palette de retouche (« Montrer » l'enlève), ou dans `sources.json`. Une piste cachée encore affichée (juste cachée, ou filtre « Cachée ») a son nom barré.
- YouTube ne permet ni la lecture du son seul ni le choix de la qualité : le lecteur fait 200 × 200 px (en dessous, YouTube refuse de lire) et YouTube choisit lui-même (360p ou 480p en général).
