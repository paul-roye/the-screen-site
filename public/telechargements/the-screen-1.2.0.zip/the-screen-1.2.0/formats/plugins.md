# Plugins et événements du gestionnaire

Un **plugin** relie le gestionnaire à un appareil ou à un service extérieur : The Table (le ruban LED autour de la table de jeu), demain un éclairage, un écran, un bot. Il s'active campagne par campagne dans la fenêtre Campagne, onglet « Plugins », et se coupe de même ; ses réglages sont gardés dans `etat/campagne.json` (`plugins`, voir [etat.md](etat.md)). Ce n'est pas un export de l'agent IA de campagne, et un plugin ne lit ni n'écrit `data/`.

Un plugin n'est pas un **module de campagne** (`app/modules.js`, `modules` du manifeste) : un module est une mécanique de jeu propre à une campagne (le Tarokka), choisie à sa création, avec ses données ; un plugin est une connexion, sans données, qu'on active ou coupe quand on veut. Les deux apportent des widgets et des contributions aux emplacements des widgets hôtes.

Code : `app/plugins.js` (registre, démarrage, onglet), `app/plugins/<id>.js` (chaque plugin), `app/evenements.js` (les événements).

## Les événements du gestionnaire

Le gestionnaire émet des **événements** quand quelque chose se passe à la table (`emettre(nom, detail)` de `app/evenements.js`) ; un plugin les écoute (`ecouter(nom, fn)`, `'*'` pour tous). Un événement est une information, jamais une commande : l'émetteur ne sait pas qui écoute, et un écouteur qui plante n'arrête rien. Les derniers événements se voient dans l'onglet Plugins (« Derniers événements du gestionnaire »).

Un nouvel événement s'ajoute à `EVENEMENTS` de `app/evenements.js` **et** ici. Un champ peut s'ajouter à un détail sans rien casser ; un champ retiré ou changé de sens se note ici, avec la date.

| Événement | Quand | `detail` |
|---|---|---|
| `combat:etat` | À chaque changement du combat mené dans le widget Combat (lancé, initiative, démarré, tour, round, PV, renforts, terminé, annulé), et au montage du widget. | `{ combat }` ; `combat` : `null` quand il n'y a plus de combat, sinon `{ rencontre (id), nom, lieu (texte, ou null), phase ("prete", "en-cours", "combat"), round, tour (clé du combattant dont c'est le tour, en phase combat), ordre[] }`. `ordre[]` : les héros et monstres présents, dans l'ordre des tours (un compagnon agit avec son maître : pas dans l'ordre) : `{ cle, type ("pj" ou "monstre"), nom, perso (id de personnages.json, ou null), fiche (id de la fiche D&D Beyond d'un héros), monstre (id du monstre D&D Beyond), init, pv { actuels, max } (null : fiche non relevée), hors_combat (monstre à 0 PV, héros mort) }`. |
| `combat:pv` | Dégâts, soins ou PV temporaires appliqués dans le widget Combat (monstre, héros ou compagnon). | `{ cle, type ("pj", "compagnon", "monstre"), nom, perso, quoi ("degats", "soins", "temp"), montant, pv { actuels, max, temporaires } }` (les PV après). |
| `rencontre:demarree` | Une rencontre est notée en cours (« Démarrer »). | `{ id, nom }` |
| `rencontre:terminee` | Une rencontre est marquée terminée. | `{ id, nom, remarque, bilan }` (`bilan` : l'état de fin du combat, voir `rencontres-mj.json` dans [etat.md](etat.md), ou null). |
| `rencontre:annulee` | Une rencontre lancée est annulée (« Annuler » du widget Combat). | `{ id, nom }` |
| `lieu:arrivee` | Les héros arrivent dans un lieu ou un sous-lieu (Ici, trajets, Déroulé). | `{ lieu (id du lieu), sous_lieu (id, ou null), nom, type (type du lieu, ou null), quand { jour, minute } (heure de jeu, ou null), trajet (id, ou null) }` |
| `horloge:changement` | L'heure de jeu change (passage du temps, réglage à la main, repos, annulation). | `{ avant { jour, minute }, apres { jour, minute }, moment, moment_avant ("aube", "jour", "crepuscule", "nuit"), motif, repos_long (un repos long se termine) }` |
| `des:resultat` | Un lancer de dés fait dans le gestionnaire : widget Dés, initiative, jets des fiches de monstres, jets des héros. | `{ legende, couleur ("sang" ; "ultra" pour un monstre), jets[] { libelle (le héros, le monstre, l'attaque…), formule, total, critique ("reussite" pour un 20 naturel, "echec" pour un 1, sinon null) } }` |
| `mode:change` | Le tableau change de mode. | `{ mode ("exploration", "ville", "voyage", "rencontre") }` |

Les événements `document` du gestionnaire (`cm:annonce`, `cm:mode`, `cm:voir-…`) sont des commandes entre widgets, pas des événements pour les plugins.

## Écrire un plugin

`app/plugins/<id>.js` exporte par défaut :

```js
export default {
  id: 'mon-plugin', titre: 'Mon plugin', icone: 'lu-plug',
  description: 'Ce qu\'il fait, en une phrase (onglet Plugins, fenêtre Outil).',
  defauts: { actif: false, adresse: '…' },      // ses réglages par défaut ; `actif` : faux
  widgets: [ { type: 'mon-widget', plugin: 'mon-plugin', … } ],   // ses widgets (forme de app/widgets/rencontres.js), grisés quand il est inactif
  emplacements: { combatEntete: () => element },                  // ses contributions aux widgets hôtes (EMPLACEMENTS de app/modules.js)
  async demarrer(ctx) { … },     // actif : poser ses écouteurs (ctx.ecouter), ouvrir sa connexion
  arreter() { … },               // coupé : tout défaire (les écouteurs posés par ctx.ecouter le sont déjà)
  reglages(ctx) { return element; },   // ses réglages dans l'onglet Plugins, sous l'interrupteur (actif ou non)
};
```

`ctx` : `{ etat, donnees, dialogue, reglages: { lire(), ecrire(patch), surChangement(fn) }, ecouter(nom, fn) }`. `reglages.lire()` rend les défauts complétés par `etat/campagne.json` ; `ecrire` y enregistre et prévient `surChangement`. Le plugin s'inscrit dans `PLUGINS` de `app/plugins.js`.

Règles : jamais de fenêtre bloquante pendant la partie (une annonce, un point d'état) ; un appareil absent n'arrête rien ; rien de la campagne en dur ; ses textes en français ; sa ligne d'aide dans `app/aide.js`.

## Plugin The Table

`app/plugins/the-table.js`. Le boîtier ESP32 qui pilote le ruban LED autour de la table de jeu (API HTTP + JSON, réseau local, firmware 0.2.0 ; contrat machine dans `mainteneur/the-table/api/` : OpenAPI, JSON Schema, exemples, faux boîtier `fake-the-table.py` et test de conformité). Le gestionnaire est servi en `http://localhost`, donc rien ne bloque ses appels vers `http://the-table.local`.

Réglages (`plugins["the-table"]` de `etat/campagne.json`) : `actif`, `adresse` (`http://the-table.local` par défaut), `jeton` (en-tête `X-Token` sur les écritures, si un jeton est réglé sur la table), `combats` (piloter The Table pendant les combats, vrai par défaut), `effets` (effets lumineux, vrai par défaut), `joueurs` (`{ "<id de personnage>": "<id du joueur sur The Table>" }`, la correspondance réglée à la main ; sans entrée, par le nom), `joueurs_table` (les joueurs installés, relevés par « Tester » : `[{ id, name, present, seat }]`), `version` (firmware lu au dernier test).

- **Combat** (`combat:etat`) : en phase combat, l'instantané complet (`POST /api/combat` : `source` « The Screen », `round`, `current`, `lease_s` 900, `combatants[]` dans l'ordre des tours, `id` stable (`pj-<fiche>`, `m-<empreinte de la clé>`), `name`, `kind` `pc` ou `monster`, `player` quand il est réglé), fusionné à 150 ms, renvoyé seulement s'il change ; échec : gardé et réessayé toutes les 5 s. Battement de cœur toutes les 60 s ; `GET /api/combat` toutes les 10 s pour voir une reprise de la main (`mode` `local`, ou une autre `source`) : annonce, point orange, et plus rien d'envoyé avant « Reconnecter ». Plus de combat (terminé, annulé, remis à zéro, page fermée) : `{ "active": false }`. Au démarrage, un combat « The Screen » resté sur la table sans combat ici est terminé. Un monstre à 0 PV ou un héros mort sort de l'instantané (sauf celui dont c'est le tour) ; un compagnon n'y est pas (il agit avec son maître).
- **Effets** (`combat:pv`, `des:resultat`, `POST /api/overlay`) : dégâts d'un héros → `dmg` sur sa place, soins → `heal` ; 20 naturel d'un héros (jets des fiches, jets de groupe) → `crit` sur sa place ; 20 naturel d'un monstre (jets de sa fiche, en violet) → `dmg` sur toute la table. La place : le joueur réglé, sinon celui de même nom, sinon le combattant envoyé.
- **Widget The Table** (compact) : le point d'état, « Reconnecter » ou « Réessayer », les ambiances lues sur la table (`GET /api/scenes`, `POST /api/scenes/{id}/activate`, l'ambiance en cours relue toutes les 15 s), les quatre effets sur toute la table.
- **Point d'état** dans l'en-tête de Combat (emplacement `combatEntete`) : gris (pas de combat, combat pas commencé, combats non pilotés), vert (synchronisée), orange (la table ne répond pas, ou le MJ a repris la main), rouge (jeton ou envoi refusé). Un clic ouvre la fenêtre The Table.
- Ce que le plugin ne touche jamais : les réglages, le Wi‑Fi, la ventilation, l'installation de la table (`PUT /api/seats`), les tours en mode local (`POST /api/turn`).

## Plugin Écran des joueurs

`app/plugins/ecran-joueurs.js`, rendu partagé `app/projection.js`, tableau des joueurs `app/tableau-joueurs.js`, page `joueurs.html` + `app/joueurs.js`. Étude : `mainteneur/etudes/ecran-joueurs.md`. Une seconde fenêtre du gestionnaire (`joueurs.html`, servie sous l'adresse de la campagne), ouverte par la page du MJ sur l'écran choisi (Window Management API de Chrome : `getScreenDetails()`, puis `window.open(…, 'popup,fullscreen,left=…,top=…,width=…,height=…')`, permission demandée une fois ; sans plein écran direct, un clic dans la fenêtre ou F11), pilotée par un canal du navigateur : `BroadcastChannel('the-screen:joueurs:<id de la campagne>')`. La page joueurs n'écrit jamais rien.

Messages du canal : `etat` (MJ → joueurs : la scène entière, à chaque changement et en réponse à `bonjour`), `ping` (MJ → joueurs : `{ x, y }` en px de carte, éphémère), `fermer` (MJ → joueurs), `bonjour` (joueurs → MJ : la page s'ouvre), `ecran` (joueurs → MJ : `{ largeur, hauteur, plein_ecran }`, `innerWidth` et `innerHeight` de la fenêtre, à l'ouverture et à chaque changement : la projection du MJ prend ces proportions, le point d'état dit le plein écran), `aurevoir`.

La scène (`sceneCourante()` du plugin, rendue par `monterProjection()` de `app/projection.js`) : `{ affichage ('tableau' | 'carte' | 'image' | 'mire'), titre, sous_titre, rotation, ecran { largeur_pouces, rapport }, carte { id, titre, chemin (la version joueurs), largeur, hauteur, echelle { px_case, origine_x, origine_y } | null, zoom ('pouce' | 'ecran' | nombre), rotation, cadrage { x, y }, brouillard { base ('cache' | 'revele'), formes[] }, grille }, image { chemin, legende, rotation }, tableau (résumé joueurs : `resumeJoueurs()` de `app/tableau-joueurs.js`, plus `fond` (chemin), `rotation` (le tableau) et `fond_rotation` (le fond, dessiné par la projection sous le tableau, tourné de son côté)) }`. La page joueurs reçoit la scène de **l'écran** (`ecran` de l'état : le tableau, la carte diffusée, en direct ou gelée, ou une image par-dessus), pas celle de l'atelier du widget (la carte que le MJ prépare, `sceneCourante()`) : `sceneJoueurs()`. Les cases de 1 pouce : la page joueurs calcule `innerWidth / largeur_pouces` px CSS par pouce, quels que soient la mise à l'échelle de Windows et le zoom de Chrome ; l'échelle de la carte est `(px par pouce) / px_case`. Le cadre des joueurs, en px de carte, ne dépend que de la dalle et du rapport de la fenêtre.

Réglages de campagne (`plugins["ecran-joueurs"]` de `etat/campagne.json`) : `actif`, `rotation_defaut` (0, 90, 180, 270), `grille_defaut`, `tableau` (le tableau des joueurs sans carte, vrai par défaut), `seuils { ensanglante (50), critique (25) }` (% des PV). `magnetisme` (les formes du brouillard aimantées à la grille, faux par défaut), `pinceau_forme` (`carre` par défaut, ou `rond`), `pinceau_cases` (1), `adouci` (le bord flouté du brouillard, en fraction de case, un quinzième par défaut : les formes sont peintes nettes, puis le brouillard entier est flouté). Réglages du poste (`localStorage`, clé `cm:ecran-joueurs`, onglet « Ce poste ») : `ecran` (le `label` de l'écran, Window Management API), `largeur_pouces` (la dalle). État de la campagne : `etat/ecran-joueurs.json` (voir [etat.md](etat.md)).

- **Widget Écran des joueurs** : le point d'état (fermée, ouverte sans plein écran, plein écran ; un clic ouvre, clic droit ferme), le choix de la carte (d'abord celles du lieu des héros, sous-lieux compris, puis par lieu ; la version joueurs est envoyée, « Version MJ » pour la projection seule), Tableau, les outils (déplacer le cadre, ping, rotation par quarts de tour, échelle, grille, calibrer : deux clics à N cases ; révéler ou recacher en rectangle, au pinceau, en polygone ; tout révéler, tout cacher, annuler), la projection (carte entière, cadre orange, dehors en sourdine, brouillard translucide), les informations (échelle, cadre en cases, alertes).
- **Tableau des joueurs** (`resumeJoueurs()`, calculé côté MJ et envoyé) : le fond (`tableau.fonds[lieu]` ou `tableau.fond_defaut` de l'état, choisi dans la fenêtre d'une image, emplacement `imageActions`), l'ambiance (`ambianceDe()` : le moment pour les joueurs — aube, matin, après-midi, crépuscule, nuit —, la météo du créneau (icône du ciel, texte, température), et la nuit la lune : nom, `avancement` du cycle depuis la pleine lune (0 pleine, 0,5 nouvelle, pour la dessiner), `visibilite` selon le ciel : `visible`, `voilee` (nuageux, ou le ciel toujours voilé du monde), `cachee` (couvert, nuages bas, brouillard, précipitation)), et par héros : prénom, `lignes` (espèce, classe, sous-classe, origine : les données de la campagne, la fiche à défaut), portrait, santé en mots (`santeDe()` : En forme au-dessus du seuil ensanglanté, Ensanglanté, Critique, À terre avec les jets contre la mort, Mort), états (`etats[]` de la fiche) et encombrement, équipement porté (`objets_equipes[]`, objets magiques équipés), compagnons (créatures de la fiche, états de `etat/etats-creatures.json`) ; l'inventaire commun (`groupe` du relevé). Ni niveau ni inspiration (retours du MJ, 2026-11-03). Relu toutes les 5 s tant que le tableau est affiché ; suit `lieu:arrivee` (le fond) et `etat/horloge.json` (l'ambiance).
- **Images** : `brancherEcranJoueurs()` de `app/ui.js` (bouton « Écran des joueurs » dans `afficherEnGrand()`), emplacement `imageActions` dans la fenêtre d'une image (montrer, comme carte, fond pour un lieu, fond par défaut).
- Ce que le plugin n'envoie jamais : la version MJ d'une carte, les PV en chiffres, un objet non équipé, une étiquette, un lieu, un PNJ, une note du MJ.
