# Bibliothèque d'images : `images-library/index.json` (index local, format 2) et `bibliotheque.json` (règles de la campagne)

La bibliothèque d'images d'une campagne : un dossier du poste, avec **un sous-dossier par source** (un livre, un homebrew, les images du MJ…). Lue par le widget **Images**, par Ici (onglet Lieu) et par la fiche d'un PNJ (`app/bibliotheque.js`).

- Son dossier est propre au poste **et** à la campagne : `campagnes/<id>/images-library/` ; pour le ranger ailleurs, `bibliotheques` de `poste.json` (`{ "<id>": "<dossier>" }`), ou `bibliotheque` pour la campagne par défaut (voir [campagne.md](campagne.md)). Le serveur la sert toujours sous l'adresse `images-library/` de la campagne : les chemins ci-dessous et les `id` restent les mêmes d'un poste à l'autre.
- Elle n'est pas versionnée (`images-library/` est dans `.gitignore`). Ses **sources** sont dans le manifeste de la campagne, qui suit d'un poste à l'autre : sur un poste neuf, « Tout importer » (fenêtre Campagne, onglet « Images ») ou `outils/Importer les images.cmd` la refait (ci-dessous).

Deux fichiers la décrivent : l'**index**, écrit par un script, qui ne dit que ce que montrent les fichiers, sans rien supposer de la campagne ; les **règles** de la campagne, facultatives, pour ce que les fichiers ne disent pas. La page déduit de l'un et l'autre la source, la catégorie et les lieux de chaque image.

## Sources d'images : `images.sources` du manifeste

Une liste, réglée dans la fenêtre Campagne (onglet « Images », `app/config-images.js`) ou à la main dans `manifeste.json`. Chaque source remplit **son dossier** de la bibliothèque :

| Champ | Contenu |
|---|---|
| `type` | `beyond` (un livre de D&D Beyond que le MJ possède), `homebrewery` (des documents publics de homebrewery.naturalcrit.com) ou `dossier` (les images du MJ, qu'il range lui-même). |
| `dossier` | Le dossier de la source dans la bibliothèque : un nom simple, sans `/` ni `\` (« Manuel des joueurs »), propre à chaque source. C'est aussi son nom dans le filtre « Source » du widget Images. |
| `adresse` | `beyond` : la page d'accueil du livre (`https://www.dndbeyond.com/sources/dnd/phb-2024`). |
| `pages` | `homebrewery` : les adresses de partage des documents (`https://homebrewery.naturalcrit.com/share/…`), un par chapitre de préférence. |
| `cartes` | `homebrewery`, facultatif : les adresses des images qui sont des cartes sans que leur titre le dise ; elles vont dans `Cartes`. |

**Import** : `scripts/import-images/importer-images.ps1` (lancé par le serveur, `<campagne>/import-images.json`, boutons « Importer » et « Tout importer » ; ou `outils/Importer les images.cmd [-Campagne <id>]`), une source après l'autre, puis l'index. Relancé, il ne retélécharge pas ce qui est déjà là. Journal : `.import-journal.txt` de la bibliothèque, montré dans l'onglet ; date du dernier import d'une source : `.importe-le` de son dossier.

- **Livre D&D Beyond** : sa liste d'images d'abord, `.liste-beyond.txt` de son dossier, une ligne par image (`page|carte (0/1)|url|libellé`). « Relever le livre » la fait faire par l'extension du MJ (commande `images-livre`, depuis 1.15.0 : chaque page du livre, toutes les 4 à 8 s, avec la session du MJ ; quelques minutes), puis lance le téléchargement. Sans liste relevée, celle fournie avec le gestionnaire pour ce livre, s'il y en a une (`scripts/dndbeyond_image_scraper/listes/<livre>.txt`, `<livre>` : la fin de l'adresse ; aujourd'hui `cos`, pour *Curse of Strahd*). Rangement : `Cartes/<page> - <fichier>` et `Illustrations/<page>/<fichier>`.
- **Homebrewery** : chaque document lu, ses images rangées dans `<chapitre>/` (« Ch.03 - Le Port d'Aurval », sinon le titre du document), nommées d'après leur section ; les cartes dans `<chapitre>/Cartes/`.
- **Mes images** : rien à télécharger ; « Ouvrir » ouvre son dossier dans l'Explorateur, « Importer » indexe.

## `images-library/index.json` — l'index, format 2

Écrit par `scripts/indexer-images/indexer-images.ps1`, que `lancer.ps1` lance en arrière-plan à chaque démarrage, pour toutes les bibliothèques du poste (ou à la main : `outils/Indexer les images.cmd` ; `-Bibliotheque <dossier>` pour une seule ; s'il n'y en a aucune, le script demande le dossier de la bibliothèque par défaut, aussi avec `-Configurer`). Seules les images nouvelles ou modifiées sont retraitées. Ce n'est ni un export de l'IA de campagne ni l'état d'un outil : ne pas le modifier à la main.

| Champ | Contenu |
|---|---|
| `schema` (`2`), `jeu` (`images`), `titre`, `genere_le`, `avertissement` | Enveloppe habituelle. |
| `images[]` | Une entrée par image (`.jpg`, `.jpeg`, `.png`, `.webp`), ci-dessous. |

### `images[]`

| Champ | Contenu |
|---|---|
| `id` | Empreinte du chemin dans la bibliothèque (12 caractères hexadécimaux). Stable tant que l'image ne change pas de place : `etat/images.json` s'y réfère. |
| `chemin` | Chemin depuis la campagne (`images-library/Manuel des joueurs/Cartes/…`). |
| `dossier` | Dossier dans la bibliothèque. |
| `titre` | Tiré du nom de fichier, sans numéros de tête ni `-player` (« White stag inn », « Isolde », « Jouer le rôle »). Un module de campagne peut en donner un autre (le Tarokka : le nom VF de la carte). |
| `joueurs` | `true` pour la version joueurs d'une carte (nom en `-player`). |
| `paire` | `id` de l'autre version (MJ ou joueurs) de la même image, ou `null`. |
| `largeur`, `hauteur`, `octets` | Dimensions et poids de l'image d'origine. |
| `miniature` | Chemin de la miniature (360 px de large par défaut, `largeur_miniature` de `poste.json`) dans `images-library/.miniatures/`. |

Format 1 (jusqu'au 2026-10-26) : avec `source`, `categorie` et `lieu`, calculés par le script avec des règles propres à une campagne. La page les ignore et les déduit elle-même : un index au format 1 marche encore, jusqu'au prochain lancement qui le réécrit.

## `bibliotheque.json` — les règles de la campagne, format 1

Dans le dossier de la campagne (`campagnes/<id>/bibliotheque.json`, à côté du manifeste), tenu à la main, versionné. **Facultatif** : sans lui, la page déduit tout de l'organisation des dossiers et des noms des lieux. Modifié, il s'applique au rechargement de la page, sans réindexer.

| Champ | Contenu |
|---|---|
| `schema` | `1`. |
| `note` | Facultatif : pour qui le lit. |
| `categories` | Facultatif : catégories en plus de celles du gestionnaire, `{ "<clé>": "<libellé>" }` ou `{ "<clé>": { "nom", "icone" } }` (`icone` : une icône de la charte, ou Lucide en `lu-…`). |
| `chemins[]` | Facultatif : règles d'après le chemin de l'image, `{ contient, categorie?, lieu? }`. `contient` : un texte cherché dans le chemin dans la bibliothèque, en minuscules, sans accents, avec des `/` (`"/cartes/"`, `"the-port-of-aurval"`). `categorie` : une clé de catégorie ; `lieu` : un `id` de [lieux.json](lieux.md). Pour la catégorie, puis pour le lieu, la **première** règle qui s'applique l'emporte : les plus précises d'abord. |

## Ce que la page déduit

- **Source** : le dossier de premier niveau de l'image, sous son nom (« Manuel des joueurs ») ; une image à la racine de la bibliothèque n'a pas de source. Ce n'est pas un code de `sources` du manifeste (les sources des données).
- **Catégorie** : celle choisie par le MJ, sinon la première règle de `chemins` qui en donne une, sinon `carte` pour une image rangée dans un dossier `Cartes`, `Carte`, `Maps`, `Map`, `Plans` ou `Plan`, sinon `illustration`. Catégories du gestionnaire : `carte`, `illustration`, `creature`, `tresor`, `document`, `encart` ; un module de campagne peut en ajouter (le Tarokka : `tarokka`, emplacement `imagesCategories` de `app/modules.js`), comme `categories` des règles.
- **Lieux** : la première règle de `chemins` qui en donne un, sinon les lieux dont **tous** les mots du nom (ou de l'`id`) sont dans le chemin, dossier de la source mis à part (« Mes dessins/Cité d'Aurval/Palais royal.png » : le Palais royal). Le plus précis l'emporte : un sous-lieu sur son lieu, « Port d'Aurval » sur « Aurval ».
- **PNJ** : d'après le nom du fichier et les noms et alias de [pnj.json](pnj.md) (« isolde » → Dame Isolde de Vauclair) ; le ou les PNJ qui partagent le plus de mots avec lui.
- Rien de tout cela n'est écrit : les déductions suivent les exports et les règles.

## Ce que fait le widget

- Filtres : source, catégorie, lieu, PNJ, recherche par titre ; regroupement par lieu, par source ou par catégorie ; versions joueurs des cartes masquées par défaut (accessibles depuis la version MJ).
- Sur chaque vignette, en bas à gauche : l'icône de sa catégorie, une épingle si elle a un lieu, des crocs si elle a un PNJ (ce qui manque se voit d'un coup d'œil) ; le détail au survol.
- Un clic ouvre l'image dans une fenêtre flottante : version joueurs, image en grand, catégorie, lieux et PNJ.
- **Étiquettes du MJ**, gardées dans `etat/images.json` (voir [etat.md](etat.md)) : catégorie choisie, lieux et PNJ ajoutés, et déduits retirés (une déduction fausse se retire d'un clic).
