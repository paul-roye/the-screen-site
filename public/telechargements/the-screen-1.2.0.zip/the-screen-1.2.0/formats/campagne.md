# `campagnes/<id>/manifeste.json` — le manifeste d'une campagne, format 1

Tenu à la main (ou réglé dans le gestionnaire), **pas un export** de l'agent IA de campagne : il dit au gestionnaire ce qui est propre à une campagne (son titre, sa charte, plus tard ses modules, son vocabulaire…). Lu par `lancer.ps1` (liste des campagnes, dossiers) et par `app/campagne.js` (au démarrage de la page).

## Une campagne, un dossier, une adresse

```
campagnes/<id>/
  manifeste.json   ce fichier
  data/            les données de jeu (formats/<jeu>.md), générées par l'agent IA de la campagne
  etat/            ce que le gestionnaire enregistre (formats/etat.md)
  wiki/            l'import du wiki de la campagne, s'il y en a un (formats/wiki.md)
  musique/         ses pistes (formats/musique.md), s'il y en a
  carte.json       sa carte des trajets, s'il y en a une
  bibliotheque.json  les règles de sa bibliothèque d'images, s'il en faut (formats/images.md)
```

- `<id>` : minuscules, chiffres et tirets (`aurval`, `temoin`). Il ne peut pas reprendre le nom d'un dossier commun (`app`, `data`, `etat`, `design-system`…).
- La campagne s'ouvre sous `http://localhost:8735/<id>/`. Toutes les lectures relatives de la page (`data/…`, `etat/…`, `wiki/…`, `musique/…`, `manifeste.json`, `carte.json`, `bibliotheque.json`) vont au dossier de la campagne ; le reste (`app/`, `design-system/`, `icones-beyond/`, `sources/`…) est commun à toutes.
- La racine (`http://localhost:8735/`) rouvre la dernière campagne ouverte sur ce navigateur, sinon les liste (`accueil.html`) ; `/?choisir` les liste toujours (bouton « Changer de campagne » de l'en-tête, visible quand il y en a plusieurs).
- Une adresse **sans** campagne (`http://localhost:8735/etat/beyond.json`, l'extension du MJ réglée sur `http://localhost:8735`) va à la **campagne par défaut** : `campagne` de `poste.json`, sinon celle dont les dossiers sont à la racine, sinon la première. Pour qu'une extension relève une autre campagne, régler son adresse sur celle de la campagne (`http://localhost:8735/temoin`).
- La bibliothèque d'images (`images-library/`) est propre au poste **et** à la campagne : `campagnes/<id>/images-library/` (hors dépôt) ; pour la ranger ailleurs, `bibliotheques` de `poste.json` (`{ "<id>": "<dossier>" }`), ou `bibliotheque` pour la campagne par défaut. Au lancement, toutes les bibliothèques du poste sont indexées ; ce que les noms de fichiers ne disent pas (sources, catégories, lieux) va dans `bibliotheque.json` de la campagne, facultatif (voir [images.md](images.md)).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `schema` | oui | `1`. |
| `id` | oui | Le nom du dossier. |
| `titre` | oui | Le titre de la campagne : en-tête du gestionnaire, onglet du navigateur, accueil (« Les Bannières d'Aurval »). |
| `sous_titre` | non | Une ligne sous le titre dans l'accueil (« La Chute des Brumes »). |
| `icone` | non | Icône de la charte (`design-system/icons/<nom>.svg`) : onglet du navigateur et accueil. `d20` par défaut. |
| `charte` | non | La charte de la campagne : `barovie-neon` (défaut). |
| `theme` | non | Thème de départ de la charte : `nuit` (défaut) ou `parchemin`. Le MJ le change ensuite dans l'en-tête (gardé dans `etat/tableau.json`). |
| `dossiers_a_la_racine` | non | `true` : `data/`, `etat/`, `wiki/` et `musique/` sont à la racine du gestionnaire, pas dans le dossier de la campagne. Plus utilisé (les premières campagnes, avant les dossiers de campagne). |
| `modules` | non | Les modules de campagne à charger (`app/modules/<id>.js`) : `["tarokka"]`. Une mécanique propre à une campagne, avec son widget, ses données et ce qu'elle ajoute aux autres outils (voir `app/modules.js`). **Le Tarokka ne fonctionne qu'avec une campagne Curse of Strahd** : le formulaire le dit, et avertit s'il est coché pour une campagne d'un autre genre. |
| `sources` | non | Les sources des données (`source` d'un élément, `priorite_sources` des fichiers) : `{ "<id>": { "court", "nom", "couleur", "mj" } }`. `court` : le libellé des badges et des filtres (« Livre », « Supplément ») ; `couleur` : un ton de badge de la charte (`ultra`…) ; `mj` : `true` pour les décisions du MJ (pas un livre : absent du filtre des images). Une source absente garde son identifiant. |
| `vocabulaire` | non | Les mots du monde de la campagne, pour les textes de l'interface : `monde` (« le royaume d'Aurval »), `de_monde` (« d'Aurval »), `dans_le_monde` (« en Aurval »), `habitant` (« Aurvalien »), `habitants`. Un surtitre qui en a besoin (« Bêtes {de_monde} ») disparaît quand le mot manque ; un texte prend une tournure neutre. |
| `reglages` | non | Réglages de la campagne. `ciel_voile` : `true` pour un ciel toujours voilé (jamais d'icône de soleil dans la météo ; l'Horloge le rappelle d'une icône, la `regle_du_monde` de la météo en infobulle, à dire à la table). `plafond_rencontres` : `{ rencontres, heures }`, « pas plus de 2 rencontres toutes les 12 heures de jeu », à la place du `plafond` de `rencontres-aleatoires.json` (absent : celui-là). `evenements` : `true` pour le bouton des événements de campagne du widget Rencontres ([evenements.md](evenements.md) ; sans `data/evenements.json`, rien ne s'affiche). Les deux se règlent dans la fenêtre Campagne, section « Rencontres », et à la création (les événements cochés d'office pour Curse of Strahd). |
| `calendrier` | non | Le calendrier de l'Horloge ([calendrier.md](calendrier.md)). `{ type: "modele", modele, debut: { annee, mois, jour } }` : un calendrier fourni, `classique`, `barovien` ou `royaumes-oublies` (`modeles/calendriers/`, le Classique calculé par le gestionnaire), et la date du jour de campagne 1 (`mois` : un `id` de ses mois ; la fenêtre Campagne propose le départ conseillé du calendrier). `{ type: "importe" }` : `data/calendrier.json`, écrit par l'IA de la campagne (sa date de départ, ou `debut` ici). `{ type: "aucun" }` : le jour de campagne seul (« Jour 12 »). Tous ont 365 jours. Les jours marqués propres à la campagne (`data/jours-marques.json`, [jours-marques.md](jours-marques.md)) s'y ajoutent. Absent : le calendrier importé s'il existe. Anciens noms encore lus : `classique` (= modèle `classique`), `fichier` (= `importe`). |
| `meteo` | non | La météo de l'Horloge ([meteo.md](meteo.md)). `{ type: "modele", modele }` : une météo fournie, `carcassonne-2009-2010` (chaud et tempéré, le défaut d'une campagne de genre Classique) ou `tallinn-2009-2010` (froid et tempéré, le défaut d'une campagne Curse of Strahd) : les années 2009 et 2010 réelles, de `modeles/meteos/`, la première année de la campagne sur 2009, la deuxième sur 2010, puis de nouveau 2009 (liste : `index.json`). `{ type: "importe" }` : `data/meteo.json`, écrit par `outils/Importer la météo.cmd` ou par l'IA de la campagne. `{ type: "aucune" }`. `debut_reel` (`MM-JJ`, facultatif, sans calendrier seulement) : le jour de la première année du relevé qui fait la météo du jour de campagne 1. Absent : la météo importée si elle existe. Ancien nom encore lu : `fichier` (= `importe`). |
| `couleurs_factions` | non | Couleur de pastille de chaque faction : `{ "<id de factions.json>": "<jeton de la charte>" }` (`fac-zarovich`, `cierge`…). Le champ `couleur` d'une faction dans `factions.json` l'emporte. Sans couleur, la pastille reste neutre. |
| `livres_beyond` | non | Les livres de D&D Beyond où chercher monstres et objets tant que le MJ n'en a pas choisi d'autres (fenêtre Campagne) : `[{ id, sigle, titre }]`. Par défaut : les livres de règles 2024. |
| `wiki` | non | `{ url, categorie_heros? }` : le wiki publié de la campagne (vvd.world), **facultatif**. Son import (onglet « Campagne » de la fenêtre Campagne, ou `outils/Importer le wiki.cmd -Campagne <id>`) est une source pour l'IA de la campagne ([wiki.md](wiki.md)). `categorie_heros` : la catégorie du wiki où sont les fiches des héros (« Héros ») ; l'import marque ces pages comme personnages joueurs et télécharge leurs portraits ; sans elle, ni l'un ni l'autre. Sans `wiki`, le gestionnaire ne lit pas `wiki/` et ne montre ni liens vers le wiki ni ses portraits ; l'onglet Lore des fiches marche de même (il lit `personnages.json`). |
| `beyond` | non | `{ url, id }` : la campagne sur D&D Beyond (`https://www.dndbeyond.com/campaigns/<id>`), où sont les fiches des héros. |
| `images` | non | `{ sources: [{ type, dossier, adresse?, pages?, cartes? }] }` : d'où viennent les images de sa bibliothèque, chacune dans son dossier ; réglées et importées dans la fenêtre Campagne, onglet « Images ». Voir [images.md](images.md), « Sources d'images ». |
| `genre` | non | `classique` ou `curse-of-strahd`, choisi à la création. Il pré-règle la charte, le ciel voilé, le vocabulaire, les sources, les livres de D&D Beyond et les modules (`GENRES` de `app/config-campagne.js`) : Curse of Strahd donne la charte Barovie Néon, le ciel voilé, le vocabulaire de la Barovie, le module Tarokka et les livres *Curse of Strahd* et *Ravenloft: The Horrors Within*. |
| `projet_claude` | — | **Retiré le 2026-10-25** (le nom de l'agent n'était lu nulle part ; la fiche d'état était citée par le prompt de fin de session, qui dit maintenant à l'IA de tenir l'état de la campagne comme elle l'entend). La fenêtre Campagne l'efface à l'enregistrement. |

## Fichier `carte.json`

La carte des trajets (widget Trajets), tenue à la main, propre à une image : `{ schema: 1, note, image, largeur, hauteur, points, traces }`. `image` : son adresse (en général sous `images-library/`) ; `largeur`, `hauteur` : ses dimensions en pixels ; `points` : `{ "<id de lieu>": [x, y] }` en % de la largeur et de la hauteur ; `traces` : `{ "<de>--<vers>": [[x, y]…] }`, les points intermédiaires de la route dessinée, dans l'ordre des `id` de `temps-de-voyage.json` (sans les deux bouts ; un trajet sans tracé est une ligne droite). Sans `carte.json`, Trajets se passe de carte.

## Régler et créer une campagne depuis le gestionnaire

- **Campagne ouverte** : bouton **Campagne** de l'en-tête, onglet « Campagne » (`app/config-campagne.js`) : titre, sous-titre, icône, charte, thème, vocabulaire, ciel voilé, campagne D&D Beyond, le temps (calendrier, sa date de départ, météo, et comment mettre les siens), wiki (case à cocher, adresse, catégorie des héros, et « Importer le wiki » : le serveur lance l'import en arrière-plan, `<campagne>/import-wiki.json`, et la fenêtre montre la date du dernier import et ce qu'il affiche pendant qu'il tourne). « Enregistrer » écrit `manifeste.json` (`PUT manifeste.json`, `lancer.ps1`) et recharge la page. `id`, `dossiers_a_la_racine` et `modules` ne s'y changent pas (le serveur refuse) : ils engagent les dossiers et les données.
- **Nouvelle campagne** : accueil (`http://localhost:8735/?nouvelle`, ou la carte « Nouvelle campagne » de la liste) : les mêmes réglages, plus l'identifiant (le dossier), le genre et les modules. Le serveur (`POST /campagnes.json`) crée `campagnes/<id>/` avec `manifeste.json`, `data/` et `etat/`, et y copie les guides de `formats/modeles/` : `LISEZMOI.md` (le dossier), `data/LISEZMOI.md` (**les instructions pour l'IA qui produira les données**), `etat/LISEZMOI.md`. Section « Musique » : les paquets de musique par défaut cochés (Fantasy médiévale toujours, Curse of Strahd pour ce genre ; [musique.md](musique.md), « Paquets par défaut »), fusionnés par la page et écrits dans `musique/` de la campagne.

## Scripts d'import

`outils/Importer le wiki.cmd` et `outils/Importer la musique.cmd` prennent la campagne par défaut, ou celle passée en argument : `-Campagne <id>` (wiki : `wiki.url` du manifeste, écrit dans `wiki/` de la campagne ; musique : `musique/sources.json` de la campagne).

## Contrôles

- `lancer.ps1` ignore un dossier sans `manifeste.json`, ou dont le manifeste n'est pas du JSON valide (avertissement dans la console du serveur).
- Sans manifeste lisible, la page prend les valeurs par défaut (titre « The Screen »).
