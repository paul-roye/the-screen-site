# `data/occupants-maisons.json` — format 1

Qui se trouve dans une maison quelconque, par lieu. Lu par le widget **Maisons**.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## `tables[]` (obligatoire)

Une table par lieu.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant de la table (en général celui du lieu). |
| `lieu` | oui | `{ id, nom, zone }` : le lieu, avec les `id` communs à tous les fichiers. |
| `de` | oui | Dé à lancer, `"1d20"`. |
| `usage` | conseillé | Pour quelles maisons la table vaut (et lesquelles en sont exclues). |
| `ambiance` | non | Une ou deux phrases sur le lieu. |
| `lignes` | oui | Voir ci-dessous. Les lignes couvrent tout le dé, sans trou ni chevauchement. |
| `original` | non | La table du livre, quand elle a changé. |
| `source`, `fiche`, `pages_pdf` / `pages_livre` | oui | |

### `tables[].lignes[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `jet` | oui | Chaîne : `"1-3"`, `"7-20"` ou une seule valeur `"1"`. |
| `resultat` | oui | Le résultat en quelques mots, affiché en grand. |
| `detail` | non | Ce que voient les PJ, comment réagissent les occupants. |
| `creatures` | oui | `[{ nom, quantite, nom_en?, note_mj? }]`, quantité en notation de dés (`"1d8-1"`), lancée automatiquement. Tableau vide si personne ou si la source ne donne pas de nombre. `nom_en` (conseillé, 2026-10-25) : le nom anglais du profil de D&D Beyond (« Commoner », « Swarm of Rats »), pour trouver le monstre quand la rencontre est lancée ; `note_mj` (facultatif) : ce que le MJ doit savoir de ce profil. Comme les créatures de [rencontres-aleatoires.md](rencontres-aleatoires.md) : une créature déjà reliée à son monstre (même nom VF) est reprise d'office. |
| `comment_jouer` | non | Si ça tourne à la rencontre : comment la jouer (ce que veulent les occupants, ce qui les fait fuir…). Affiché dans la préparation de la rencontre lancée. |
| `source_detail` | non | Source du détail, quand elle diffère de celle de la table. |

## Ce que fait le widget

Choix du lieu, jet du dé, affichage du résultat avec les quantités déjà lancées (relançables une à une). Une ligne qui a des créatures peut **lancer une rencontre** (2026-10-25, décision du MJ : toute ligne, c'est lui qui juge) : « Lancer » ouvre la préparation (monstres reliés à leur nombre tiré, difficulté), puis « Lancer le combat » la charge dans le widget Combat. Elle est gardée dans `etat/rencontres-mj.json` (origine `maison`, rattachée au lieu), à part des rencontres aléatoires : ni journal du widget Rencontres, ni plafond. Les jets eux-mêmes ne sont pas enregistrés.

## Contrôles faits par le gestionnaire

`tables` non vide ; chaque table a un `lieu.id`, un `de` lisible et des lignes qui couvrent tout le dé sans trou ni chevauchement ; chaque quantité est lisible en notation de dés.
