# Bloc `maj-etat` — format 1

Ce que l'agent IA de campagne rend au gestionnaire après l'analyse d'une séance : les changements à apporter à l'état de la campagne (`etat/`). Ce n'est pas un fichier de `data/` : c'est un bloc JSON à la fin d'une réponse de l'agent, que le MJ colle dans le gestionnaire.

## Le circuit

1. **Avant l'analyse** : bouton **Session** du gestionnaire, onglet « Avant l'analyse ». Il produit un prompt Markdown (à copier ou télécharger) : l'état noté pendant les séances (étape de référence, étapes et jalons en cours, pistes commencées, étapes, jalons et pistes terminés, lieu des héros et arrivées notées depuis le dernier envoi, notes du MJ sur les lieux, horloge avec la date, la lune, le jour marqué et la météo, dernier repos long, activité en cours (trajet, repos, attente) et temps de jeu écoulé depuis le dernier envoi, PNJ rencontrés, états et rangs changés en jeu, notes, Tarokka avec les tirages personnels, rencontres uniques rencontrées et cachées des tables, suites à jouer, rencontres tirées depuis le dernier envoi, rencontres jouées depuis le dernier envoi (menées dans le widget Combat ou marquées terminées, avec leurs monstres et la remarque du MJ : `etat/rencontres-mj.json`)), les personnages tels que relevés sur D&D Beyond (`etat/beyond.json` : niveau, PV, états, inspiration, ressources, objets magiques, bourse, familier, inventaire commun du groupe), les noms retenus au widget Noms depuis le dernier envoi, les babioles données depuis le dernier envoi (widget Babioles : nom ou texte, à qui, note), les objets donnés depuis le dernier envoi (`etat/objets.json` : à qui, ajoutés ou non sur D&D Beyond, sous quel nom, identifiés), le dernier itinéraire du widget Trajets (à confirmer), les écarts avec `data/personnages.json` (étape, lieu actuel et lieux visités, PNJ rencontrés, niveau, liens de feuille et historiques manquants), ce format, et en option les origines des personnages (`etat/beyond-details.json`, jointes d'office quand elles ont changé depuis le dernier envoi). Le MJ le donne à l'agent avec les retours de séance récupérés du wiki.
2. **L'agent analyse.** **Le gestionnaire fait foi** pour l'avancée : l'agent part de cet état, pose ses questions au MJ quand un point est incertain, met à jour ses fiches (et `groupe` de `personnages.json` au prochain export), puis termine sa réponse par **un seul** bloc ```json au format ci-dessous.
3. **Après l'analyse** : onglet « Après l'analyse ». Le MJ colle la réponse (entière, ou seulement le bloc) ; le gestionnaire liste chaque changement (avant → après), le MJ décoche ce qu'il refuse, puis applique. La page se recharge. Une copie du jour de chaque fichier reste dans `etat/sauvegardes/`.

## Contenu

Tout est facultatif sauf l'en-tête : l'agent n'écrit **que ce que la séance a changé**. Les `id` sont ceux de `data/`. Un `id` inconnu est ignoré et signalé au MJ.

| Champ | Contenu | Effet dans `etat/` |
|---|---|---|
| `schema`, `jeu` | `1`, `"maj-etat"`. | |
| `session` | Date de la séance analysée, `AAAA-MM-JJ`. | Date des notes ajoutées ; historique. |
| `resume` | Une ou deux phrases sur la séance. | Historique (`session.json`). |
| `deroule.etape` | `id` d'une étape de `deroule-campagne.json` démarrée pendant la séance, ou `null`. Les étapes sont indicatives (format 2 du déroulé) : plusieurs peuvent être en cours, et démarrer une étape ne termine pas les autres. | `deroule.json` `etape`, l'étape de référence ; elle compte comme en cours dans `suivi` (`debut`, `fin` retirée). |
| `deroule.jalon` | `id` d'un jalon à marquer en cours (changé le 2026-10-12 : plusieurs jalons peuvent être en cours, et ils ne changent pas l'étape). | `deroule.json` `suivi.jalons` (`debut`, `fin` retirée). |
| `deroule.pistes` | Ajouté le 2026-10-14. `id` de pistes (`pistes[]` du déroulé) à marquer commencées. | `deroule.json` `suivi.pistes` (`debut`, `fin` retirée). |
| `deroule.termines` | Ajouté le 2026-10-12, pistes acceptées le 2026-10-14. `id` d'étapes, de jalons ou de pistes faits ou finis pendant la séance. Avant d'appliquer, le gestionnaire signale les objets pas encore donnés des jalons et des étapes terminés (sauf ceux que le bloc donne, `objets.donner`). | `deroule.json` `suivi` (`fin`, et `debut` s'il manque). |
| `lieu.actuel` | `id` de `lieux.json` où sont les héros à la fin de la séance. Un sous-lieu est accepté : le lieu devient son lieu, et le sous-lieu est retenu. | `ici.json` `lieu` (et `sous_lieu`) ; une arrivée ajoutée à `visites`, datée de `session` et de l'heure de `horloge` si elle est donnée. |
| `lieu.sous_lieu` | `id` d'un sous-lieu du lieu (nouveau ou actuel), ou `null`. | `ici.json` `sous_lieu`. |
| `lieu.visites` | `id` de lieux (pas de sous-lieux) traversés en chemin. | Ajoutés à `ici.json` `visites` avant l'arrivée, s'ils n'y sont pas déjà. |
| `horloge.jour` | Jour de campagne, entier de 1 ou plus. | `horloge.json` `jour` ; noté au journal (« Séance du … »). |
| `horloge.heure` | Heure de jeu, `"HH:MM"`. | `horloge.json` `minute`. Un seul des deux champs peut être donné : l'autre ne change pas. |
| `pnj.<id>.rencontre` | Booléen. | `pnj.json` `rencontre`. |
| `pnj.<id>.etat` | `vivant`, `mort`, `mort-vivant`, `disparu`, `absent`, ou `""` pour revenir à l'état du fichier. Un état égal à celui de `pnj.json` revient aussi à « comme le fichier ». | `pnj.json` `etat`. |
| `pnj.<id>.rang` | `vip`, `majeur` ou `mineur`. | `pnj.json` `rang` (effacé s'il égale le rang du fichier). |
| `pnj.<id>.note` | Texte. | **Ajouté** à la suite des notes, précédé de `[session]`. Rien n'est effacé. |
| `tarokka.tirage` | `{ "<place>": "<id de carte>" \| null }` : carte réellement tirée à la table. | `tarokka.json` `tirage`. |
| `tarokka.suivi` | `{ "<place>": true \| false }` : objet trouvé, allié recruté. | `tarokka.json` `suivi`. |
| `tarokka.notes` | `{ "<place>": "texte" }`. | Ajouté à la suite, daté. |
| `rencontres.retirer` | `id` de rencontres **des tables** (`rencontres[]`, sous-tables comprises) à cacher : une unique jouée hors du widget (elle y apparaît cochée « Rencontrée »), un cavalier détruit, une rencontre devenue sans objet… | `rencontres.json` `retirees` ; pour une unique, aussi `rencontrees` (2026-10-15). |
| `rencontres.remettre` | `id` de rencontres à remettre dans les tables. | Retirées de `retirees` et de `rencontrees`. |
| `rencontres.suivis_resolus` | `id` des suites à jouer listées dans le prompt. | `rencontres.json` `suivis[].resolu`. |
| `rencontres.terminees` | Ajouté le 2026-10-21. `{ "<id>": "remarque" \| "" }` : rencontres prévues (`rencontres_scenarisees[]` de `rencontres-aleatoires.json`) ou créées par le MJ (`mj-…`) jouées sans être marquées terminées dans le gestionnaire (en ligne, dans Maps), avec ce qui s'est passé. Une rencontre des tables est refusée (voir `rencontres.retirer`). | `rencontres-mj.json` : `statut` `terminee`, `fin.quand` (la date `session`), `remarque` (gardée si vide) ; le combat lancé de cette rencontre est effacé. |
| `babioles.distribuer` | `{ "<id de ligne>": { "a": "<id de personnage>" \| "groupe" \| "", "note": "texte" } }` : babioles de `babioles.json` données en séance sans passer par le widget. `a` : `id` de `personnages.json`, `"groupe"`, ou `""` si on ne sait pas à qui. Une ligne `a_remplir` est refusée. | `babioles.json` `distribuees` (date : `session`) ; remplace une distribution déjà notée. |
| `babioles.remettre` | `id` de babioles notées données par erreur. | Retirées de `babioles.json` `distribuees`. |
| `objets.donner` | Ajouté le 2026-10-21. `{ "<id d'objet>": { "a": "<id de personnage>" \| "groupe", "quantite": 1 } }` : objets de `objets.json` (ou créés par le MJ, `mj-…`) trouvés ou reçus en séance sans être donnés dans le gestionnaire. `quantite` : 1 d'office. | Un don ajouté à `objets.json` `objets.<id>.dons` (date : `session`), **noté seulement** : rien n'est ajouté sur D&D Beyond (le MJ peut encore le faire depuis la fenêtre de l'objet). Un objet déjà donné aux mêmes mains est listé décoché. |

Tant que `deroule-campagne.json` n'est pas lisible (absent, ou pas encore au format 2), le champ `deroule` est ignoré, et le gestionnaire le dit.

`conditions` (faits de campagne, `{ "reliques_reunies": true }`) est retiré le 2026-10-23 : le gestionnaire ne note plus de conditions, le MJ juge lui-même des écarts `conditionnel`. Une clé `conditions` reçue est ignorée, et le gestionnaire le dit.

## Exemple

```json
{
  "schema": 1,
  "jeu": "maj-etat",
  "session": "2026-10-11",
  "resume": "Les PJ sortent de la Funeste demeure et ramènent Rose et Épine au repos.",
  "deroule": { "etape": "port-d-aurval", "jalon": "le-passeur-suit-les-pj", "pistes": ["arc-isolde-cauchemars"], "termines": ["route-du-gue"] },
  "lieu": { "actuel": "sang-sur-les-vignes" },
  "horloge": { "jour": 2, "heure": "21:30" },
  "pnj": {
    "bourgmestre-aldric": { "rencontre": true },
    "maitre-gaspard": { "rencontre": true, "note": "Leur a demandé d'escorter sa fille jusqu'au port." }
  },
  "tarokka": { "suivi": { "tome": false } },
  "rencontres": { "retirer": [], "suivis_resolus": [], "terminees": { "le-pendu-du-gue": "Jouée en ligne dans Maps ; ce qui s'est passé." } },
  "babioles": { "distribuer": { "osselet-grave": { "a": "isolde", "note": "Sur l'autel de l'église." } } },
  "objets": { "donner": { "lettre-du-bourgmestre": { "a": "groupe" } } }
}
```

## Pas encore dans ce format

- **Niveau, PV, inventaire D&D Beyond, origines des personnages** : le gestionnaire les relit lui-même sur D&D Beyond (extension). Ils n'ont pas à revenir par ce bloc : le prompt les donne à l'agent, qui les reporte dans ses fiches et dans `personnages.json` (`groupe.niveau`, `liens.feuille`, `historique`…) au prochain export. Un objet trouvé passe par `objets.donner` (le don est noté dans le gestionnaire), pas par l'inventaire.
- **Documents trouvés** : le gestionnaire les tient depuis le 2026-10-21 comme objets (`objets.json`, genre `document`, ou créés par le MJ), donnés par `objets.donner` ; `groupe` de `personnages.json` les garde encore côté agent.
- **Tirages personnels du Tarokka** : le prompt les donne, mais `tarokka` ne vise que les places de la lecture principale ; ils se notent dans le widget.
- **Lieux visités** : le gestionnaire les tient depuis le 2026-10-11 (widget Ici, `etat/ici.json`) ; le prompt signale ceux qui manquent à `groupe.lieux_visites` et un `lieu_actuel` différent.
