# `data/temps-de-voyage.json` — format 1

Distances entre les lieux de la campagne. Lu par le widget **Trajets**, qui en déduit les temps de marche et les jours.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Règle de calcul (décision du MJ)

- Temps de marche = miles / vitesse. Au rythme normal : 24 miles par jour, soit 3 miles par heure.
- **Terrain difficile : temps de marche doublé**, et c'est tout.
- Jours de voyage = temps de marche / 8 heures.
- Le rythme (lent 18, rapide 30 miles par jour) et la monture (+4 miles par jour) changent la vitesse.

Les durées et les jours ne sont donc **pas** des données : le fichier donne les distances et le terrain, le gestionnaire calcule.

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `echelle` | oui | `{ hexagone_en_miles, texte, original, source, fiche }` : l'échelle retenue (1 hexagone = 1 mile). |
| `calcul` | non | `{ texte, original, source, fiche, date }` : la règle de calcul du MJ en clair, affichée dans les règles du widget. |
| `lieux` | non | À retirer : les lieux reliés se déduisent des `trajets`, et leurs noms et zones viennent de [lieux.json](lieux.md). Encore lu à défaut, sous la forme `[{ id, nom, zone }]` ou `["id", …]`. |
| `trajets` | oui | Les tronçons directs, voir ci-dessous. |
| `regles` | oui | Règles de voyage, voir ci-dessous. |
| `conseil` | non | Conseil de mise en scène. |
| `source`, `fiche`, `pages_pdf` | oui | |

### `trajets[]`

Chaque trajet vaut **dans les deux sens**.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | `<de>--<vers>`. |
| `de`, `vers` | oui | `id` de deux `lieux`. |
| `hexagones`, `miles` | oui | Nombres. |
| `terrain_difficile` | oui | Booléen : le temps de marche est doublé. |
| `source`, `fiche`, `decision_mj` | non | Pour un trajet ajouté ou fixé par le MJ (le lac Gris depuis Aurval). Le widget marque le tronçon « Distance MJ ». |

`de` et `vers` sont des `id` de [lieux.json](lieux.md), qui donne les noms et les zones. Un lieu `situe_dans` un autre (la Funeste demeure) n'a pas de trajet : on le rejoint depuis son lieu.

### `regles[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | `journee`, `rythme-lent`, `rythme-rapide`, `terrain-difficile`, `monture`, `vehicule`, `marche-forcee`, `sans-repos-long`… |
| `texte` | oui | La règle en une phrase, affichée dans la liste. |
| `miles_par_jour` | pour `journee`, `rythme-lent`, `rythme-rapide` | Nombre : vitesse du rythme (24, 18, 30). Sans lui pour `journee`, le gestionnaire prend 24. |
| `miles_en_plus` | pour `monture` | Nombre (4). |
| `detail` | non | Explication plus longue, affichée dans l'aide « Marcher plus de 8 h ? » pour `marche-forcee` et `sans-repos-long`. |

## Ce que fait le widget

- On choisit un départ, puis chaque tronçon parmi les trajets directs qui partent du dernier lieu atteint (pas de calcul de chemin, à la demande du MJ).
- Par tronçon et au total : distance en miles ou en km (1 mile = 1,609 km), temps de marche, jours de 8 heures ; un tronçon de plus de 8 heures est signalé.
- Tests de rencontre : un par intervalle de `procedure.intervalle_minutes` de `rencontres-aleatoires.json`, sur le temps de marche.
- L'itinéraire, l'unité, le rythme et la monture sont gardés dans `etat/trajets.json` (voir [etat.md](etat.md)).

## Contrôles faits par le gestionnaire

`trajets` et `regles` non vides ; chaque trajet relie deux lieux de `lieux.json`, avec un nombre pour `miles` et un booléen pour `terrain_difficile`.
