# `wiki/` — import du wiki de campagne, format 1

Écrit par `scripts/import-wiki/importer-wiki.ps1` à partir du wiki publié de la campagne (vvd.world), lancé depuis le gestionnaire (fenêtre Campagne, onglet « Campagne », « Importer le wiki ») ou par `outils/Importer le wiki.cmd`. Il ne suppose rien de l'organisation du wiki : toutes les pages publiées sont lues ; seule la catégorie des héros (`wiki.categorie_heros` du manifeste, facultative, [campagne.md](campagne.md)) marque les personnages joueurs et leurs compagnons et fait télécharger leurs portraits. Ce n'est **pas** un export de l'agent IA de campagne, et ce n'est pas l'état d'un outil : c'est une copie du wiki, refaite à chaque import. On ne la modifie pas à la main ; on corrige le wiki, puis on relance l'import.

Destinataires :

- **l'IA de la campagne** (son agent IA) reçoit `wiki-complet.md` (et `changements.md` après une séance) : c'est une **source**, qu'elle traduit dans les fichiers de `data/` (le lore des personnages dans `personnages.json`, les PNJ, l'état de la campagne) ;
- **le gestionnaire** n'en lit presque rien (décision du MJ, 2026-10-24) : les portraits des héros (`images/`, à défaut d'un `portrait` dans `personnages.json`), la date de l'import (`importe_le`, pour signaler un import pas encore traité) et l'existence des pages citées par `liens.wiki.id` (bouton Données). Le texte des pages ne s'affiche plus dans le gestionnaire : l'onglet Lore des fiches montre `personnages.json`.

| Fichier | Contenu |
|---|---|
| `wiki.json` | Toutes les pages, structurées (ci-dessous). |
| `wiki-complet.md` | Toutes les pages en Markdown, précédées des conventions et d'un sommaire. |
| `changements.md` | Différences avec l'import précédent. |
| `images/<media>.<ext>` | Portraits des héros (`.webp` en général). |
| `historique/<AAAA-MM-JJ_HHmm>/` | Les trois fichiers ci-dessus tels qu'ils étaient avant un import qui a changé quelque chose. Le nom du dossier est la date de cet import-là. |

## Conventions du Markdown

- `<secret>…</secret>` : passage masqué sur le wiki (balise spoiler). Le MJ le connaît ; les joueurs (ou les autres joueurs, sur une fiche de personnage) ne l'ont pas encore découvert. **Ne jamais le révéler aux joueurs.**
- `[[Nom]]` : lien vers la page « Nom » du wiki. `[[Nom|texte]]` : le lien affiche « texte » mais mène à la page « Nom » (le wiki garde le texte saisi à la création du lien).
- Chaque page commence par `## Nom`, une ligne *catégorie · lien vers le wiki*, puis ses propriétés en liste. Les blocs de la fiche sont en `###`, leurs intertitres en `####` et au-delà.
- Deux pages peuvent porter le même nom (une carte et un lieu « Aurval ») : la ligne de catégorie les distingue.

## `wiki.json`

```json
{
  "schema": 1,
  "jeu": "wiki",
  "titre": "La Chute des Brumes",
  "source": "https://exemple.vvd.world/u/…",
  "importe_le": "2026-10-09T15:22:43+02:00",
  "avertissement": "…",
  "import_precedent": "2026-10-02T23:10:00+02:00",
  "personnages": ["<id>", "…"],
  "compagnons": ["<id>"],
  "categories": [ { "nom": "Lieu", "parente": "…", "pages": ["<id>"] } ],
  "changements": { "ajoutees": ["<id>"], "modifiees": ["<id>"], "retirees": [ { "id", "nom", "categorie" } ] },
  "pages": [ ]
}
```

| Champ | Contenu |
|---|---|
| `importe_le` | Date et heure de l'import (ISO 8601, heure locale). |
| `import_precedent` | Facultatif : date de l'import auquel `changements` se compare. Absent au premier import. |
| `personnages` | `id` des personnages joueurs, dans l'ordre alphabétique. |
| `compagnons` | `id` des héros cités par un autre héros dans ses propriétés (familier…). |
| `categories` | Catégories présentes, dans l'ordre des pages. `parente` si la catégorie est une sous-catégorie (Village › Lieu). |
| `changements` | Par rapport à l'import précédent. Une page est « modifiée » quand son `markdown` a changé. |
| `pages` | Toutes les pages publiées : personnages, compagnons, puis par catégorie et par nom. |

### Une page

| Champ | Toujours | Contenu |
|---|---|---|
| `id` | oui | Identifiant du wiki (UUID). Stable : c'est lui qu'il faut retenir dans `etat/`. |
| `slug`, `url` | oui | Adresse de la page sur le wiki. |
| `nom` | oui | Nom de la page. |
| `nature` | oui | `fiche`, `carte`, `chronologie` ou `canevas`. |
| `categorie` | oui | Type de la fiche sur le wiki (`Héros`, `PNJ`, `Lieu`, `Village`…), ou `Carte`, `Chronologie`, `Canevas`. |
| `categorie_parente` | non | Catégorie mère (`Lieu` pour `Village`). |
| `role` | héros | `personnage` (joueur) ou `compagnon`. |
| `compagnon_de` | compagnon | `id` des héros qui le citent. |
| `alias` | fiche | Autres noms (tableau, parfois vide). |
| `proprietes` | fiche | `{ nom, type, valeur }`. `type` `string` : `valeur` est une chaîne. `type` `reference` : `valeur` est un tableau de `{ page, nom }`. Les propriétés vides sont omises. |
| `portrait` | non | Image principale de la fiche : `{ media, url, fichier }`. `fichier` (chemin depuis `wiki/`, par ex. `images/<media>.webp`) n'existe que pour les héros, dont le portrait est téléchargé. |
| `blocs` | fiche | Contenu de la fiche (ci-dessous). |
| `image` | carte | Fond de la carte : `{ media, url }`. |
| `lieux` | carte | `{ nom, description?, page?, forme }` ; `forme` : `epingle` ou `zone`. |
| `ages`, `evenements` | chronologie | `{ nom, debut, fin, debut_ms }` et `{ nom, date, date_ms, description? }`, triés. `date` est lisible (« 1358 CV ») ; `_ms` sert au tri. |
| `textes` | canevas | Textes trouvés sur le canevas. |
| `liens` | oui | `id` des pages citées (mentions, propriétés, épingles). Une page non publiée peut y figurer. |
| `secrets` | oui | Nombre de passages secrets de la page. |
| `markdown` | oui | La page en Markdown (conventions ci-dessus), telle qu'elle apparaît dans `wiki-complet.md`. |
| `empreinte` | oui | Empreinte du `markdown`, pour repérer les pages modifiées. |
| `erreur` | non | Présent si le contenu de la page n'a pas pu être lu. |

### Blocs d'une fiche

| `type` | Champs |
|---|---|
| `texte` | `titre?`, `contenu` : tableau de nœuds. |
| `image` | `titre?`, `image { media, url }`, `legende?`. |
| `renvoi` | `titre?`, `nature` (`map`, `timeline`…), `page?` : carte ou chronologie intégrée. |

Nœuds de `contenu` :

| `type` | Champs |
|---|---|
| `paragraphe` | `segments` |
| `titre` | `niveau` (1 à 6), `segments` |
| `liste` | `ordonnee` (booléen), `elements` : tableau d'éléments, chacun un tableau de nœuds. |
| `citation` | `contenu` : tableau de nœuds. |
| `tableau` | `lignes` : tableau de lignes, chaque ligne un tableau de cellules, chaque cellule un tableau de nœuds. |
| `code` | `texte` |
| `image` | `url`, `legende` |
| `separateur` | — |
| `autre` | `nature` (type d'origine), `texte` : élément inconnu, gardé en texte brut. |

Un **segment** est un morceau de texte : `{ "texte": "…" }`, plus, seulement s'ils sont vrais ou présents :

| Champ | Sens |
|---|---|
| `secret` | Passage masqué sur le wiki (voir plus haut). Un lien ou un saut de ligne pris entre deux passages secrets est secret aussi. |
| `gras`, `italique`, `souligne`, `barre`, `code` | Mise en forme. |
| `lien` | Adresse d'un lien externe. |
| `page` | `id` de la page citée (mention) ; `texte` est le texte du lien. |
| `saut` | Saut de ligne (`texte` vaut `"\n"`). |

## Faire évoluer ce format

Comme les autres fiches (voir [README.md](README.md)) : un champ facultatif en plus ne change pas `schema` ; un changement incompatible l'augmente, dans le script et dans les outils qui lisent `wiki.json`.
