# `data/evenements.json` — format 1

Les **événements de campagne** du widget Rencontres (2026-10-25) : ce qui peut arriver aux héros en chemin sans être une rencontre tirée sur une table. Par exemple, des espions qui les suivent (corbeaux, loups) et ce qui se passe selon qu'ils les repèrent ou non. Facultatif.

La campagne les active dans la fenêtre Campagne (onglet « Campagne », section « Rencontres », case « Événements de campagne » ; `reglages.evenements` du manifeste, [campagne.md](campagne.md)). Activés et ce fichier présent, le widget Rencontres a un bouton de plus après « Tester » et « Rencontre » : celui de l'événement (son `court`), ou « Événements » et un menu s'il y en a plusieurs. Le bouton ouvre une fenêtre : l'événement, ce que le MJ doit faire, puis deux choix :

- **Ajouter comme rencontre** : une ligne dans le journal des rencontres, qui **compte dans le plafond** (« pas plus de 2 rencontres toutes les 12 heures ») comme une rencontre tirée ;
- **Passer** : rien n'est noté (l'espion n'a pas été repéré, l'événement n'a pas lieu).

Le MJ décide, au moment où il clique : rien n'est tiré au hasard ici.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `evenements[]` | oui | Les événements, dans l'ordre du menu. Voir ci-dessous. |

### Un événement

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant stable (`espions-du-roi`). |
| `nom` | oui | Le titre de la fenêtre (« Les espions du roi »). |
| `court` | conseillé | Le libellé du bouton, **16 caractères au plus** (« Espions »). Sans lui, le nom. |
| `icone` | non | Icône du bouton et de la ligne du journal : une icône de la charte (`oeil`, `chauve-souris`, `loup`, `corbeau`…, `design-system/icons/icons.json`) ou de Lucide (`lu-eye`). |
| `resume` | conseillé | Une phrase : quand s'en servir (« Les héros voyagent hors des villages : quelque chose les observe. »). Au survol du bouton et en tête de la fenêtre. |
| `texte` | non | Ce qui se passe, quelques phrases qui peuvent se dire ou se paraphraser à la table. Rien de secret. |
| `sections[]` | non | Les règles et repères pour le MJ, dans l'ordre : `{ titre, texte?, points[]?, icone? }` (« Qui espionne », « Les repérer », « S'ils ne les repèrent pas », « Ce que le roi en tire »…). Un `texte` court ou une liste de `points` d'une phrase chacun. |
| `mj` | non | Ce que seul le MJ sait ou doit décider, dans un encadré « Pour le MJ ». |
| `piste` | non | `id` d'une piste de `deroule-campagne.json` qui en parle (« Les espions du roi ») : un lien l'ouvre dans le Déroulé. |
| `source`, `fiche` | oui | Provenance, comme ailleurs. |

## Dans le journal des rencontres

Une ligne ajoutée est de `type` `evenement` dans `etat/rencontres.json` ([etat.md](etat.md)), avec `evenement: { id, nom }` et son `numero` (le compte de cet événement) ; sa fenêtre remontre le texte de l'événement.

## Contrôles faits par le gestionnaire

`id` uniques ; `nom` présent ; `court` de 16 caractères au plus (avertissement) ; chaque section a un `titre` et un `texte` ou des `points` ; `piste` existe dans `deroule-campagne.json` (avertissement).
