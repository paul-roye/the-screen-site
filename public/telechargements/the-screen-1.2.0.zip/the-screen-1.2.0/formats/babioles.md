# `data/babioles.json` — format 2

**Format 2** : les babioles peuvent citer des **éléments d'intrigue** (`elements_intrigue`, une intrigue secrète de `connaissances.json`), par le lien `element_intrigue`. Un fichier au format 1 est converti au chargement (`app/conversions.js`) : `dame` passe dans `detail_mj`.

Tables de babioles à tirer au hasard : petits objets étranges à faire trouver aux personnages. Prévu pour un widget **Babioles** (tirage, filtre par thème ou par lien).

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `types_liens` | oui | Libellé de chaque type de lien : `lieu`, `sous_lieu`, `pnj`, `faction`, `element_intrigue`, `personnage` : seulement ceux qui servent. |
| `themes` | oui | Libellé de chaque thème (`foret`, `marais`, `aurval`…), pour filtrer. |
| `elements_intrigue` | non | Les éléments d'une intrigue secrète que les babioles citent (trois reliques, par exemple) : `[{ id, intrigue, nom, detail_mj?, pnj?, lieu?, sous_lieu? }]`. `intrigue` : `id` d'une intrigue de `connaissances.json` ; `detail_mj` : ce que seul le MJ sait (le gardien de la relique) ; `pnj` : `id` de `pnj.json` (l'identité actuelle de la Dame, secret des joueurs) ; `lieu` et `sous_lieu` : où il se trouve (le grand sanctuaire). |
| `tables` | oui | `[{ id, nom, de, usage, lignes[] }]`. `de` en notation de dés (`"1d100"`, `"1d20"`). |

### Une ligne

| Champ | Obligatoire | Contenu |
|---|---|---|
| `jet` | oui | Résultat du dé (le premier, si la ligne en couvre plusieurs), unique dans la table, de 1 à la taille du dé. |
| `jet_max` | non | Dernier résultat couvert par la ligne (`jet` 1, `jet_max` 2 : la ligne sort sur 01-02). Absent : la ligne ne couvre que `jet`. Les plages ne se chevauchent pas. |
| `id` | oui | Identifiant stable, unique dans tout le fichier. |
| `nom` | non | Nom court de l'objet. Absent des babioles du livre. |
| `theme` | non | Clé de `themes`. |
| `texte` | oui | Description, lisible aux joueurs. Chaîne vide sur une ligne à remplir. |
| `note_mj` | non | Ce que le MJ sait de l'objet. **Jamais montré aux joueurs.** |
| `lore_links` | oui | Toujours présent, vide si rien de pertinent. `[{ type, id, note? }]` : `type` est une clé de `types_liens`, `id` renvoie à `lieux.json` (`lieu`, `sous_lieu`), `pnj.json` (`pnj`), `factions.json` (`faction`), `elements_intrigue` de ce fichier (`element_intrigue`) ou `personnages.json` (`personnage`). `note` : précision libre. |
| `personnage` | table `objets-des-personnages` | `id` de `personnages.json`, ou chaîne vide. |
| `lien_personnage` | table `objets-des-personnages` | Ce qui relie l'objet à l'histoire du personnage. |
| `a_remplir` | non | `true` sur un emplacement vierge : le widget ne le tire pas. À retirer une fois la ligne remplie. |
| `source`, `fiche` | oui | Provenance. Facultatif : `pages_livre`. |

## Tables

| `id` | Dé | Contenu |
|---|---|---|
| `babioles-avancees` | 1d100 | Créations pour la campagne (intrigues secrètes, ajouts d'un supplément, lieux et PNJ). |
| `objets-des-personnages` | 1d20 | Vingt emplacements vierges pour des objets liés à l'histoire des personnages. |
| `babioles-du-livre` | 1d100 | Les cinquante babioles gothiques de l'annexe A du livre, résumées en quelques mots ; chaque ligne couvre deux résultats. |

## Ce que fait le widget Babioles

- **Tirage** : choix de la table, jet du dé de la table (`de`), ligne dont la plage `jet`..`jet_max` contient le résultat. Une ligne `a_remplir` n'est jamais tirée ; une table qui n'a que des lignes `a_remplir` est annoncée vide. Option « Écarter les babioles déjà distribuées » (cochée par défaut) : le tirage se fait parmi les lignes restantes, à chances égales par résultat de dé couvert (une ligne 81-82 a deux chances). Tirage ciblé : parmi les lignes qui passent les filtres de la liste.
- **Affichage** : `nom` et `texte` (ce qui peut être lu aux joueurs, copiable) ; `theme` en badge ; `personnage` et `lien_personnage` ; une puce par lien (`types_liens` + nom de l'élément, `note` en infobulle) qui ouvre la fiche du PNJ, du lieu ou de la faction ; un élément d'intrigue s'affiche par son `nom` et son lieu.
- **Secrets, repliés sous « MJ »** : `note_mj`, le `detail_mj` et le `pnj` de chaque élément d'intrigue lié, les liens vers une faction `secret` de `factions.json` (une société secrète). L'écran peut être vu des joueurs.
- **Parcourir** : la table entière (jet, nom ou début du texte, babioles données marquées), filtres par `theme`, type de lien, élément lié (un lieu compte aussi ses sous-lieux, les lieux `situe_dans` lui et les éléments d'intrigue qui s'y trouvent), données ou non, recherche dans `nom`, `texte` et `note_mj`.
- **Distribution** : « Donner » (à un personnage, au groupe ou sans préciser, avec une note) et « Reprendre », notés dans `etat/babioles.json` (voir [etat.md](etat.md)) par `id` de ligne. Le prompt de fin de session liste les babioles données depuis le dernier envoi ; l'agent peut en donner ou en reprendre par le bloc `maj-etat` (voir [maj-etat.md](maj-etat.md)).

`nom` ou `note_mj` à `""` (lignes vierges) valent « absent ».

## Contrôles faits par le gestionnaire

- `types_liens` (un libellé pour chacun des six types) et `themes` présents ; `theme` d'une ligne connu de `themes`.
- `elements_intrigue` : `id` uniques, `nom` présent ; `pnj` connu de `pnj.json`, `lieu` de `lieux.json`, `sous_lieu` des sous-lieux de `lieux.json`, quand ils sont là.
- `tables` non vide, `id` de table uniques, dé lisible ; `id` de ligne uniques dans tout le fichier ; `jet` et `jet_max` entiers, dans les bornes du dé, uniques et sans chevauchement de plages ; `texte` non vide sauf sur une ligne `a_remplir`.
- `lore_links` présent ; chaque `type` connu, chaque `id` présent dans le fichier visé (`lieux.json` pour `lieu`, ses `sous_lieux` pour `sous_lieu`, `pnj.json`, `factions.json`, `elements_intrigue` de ce fichier, `personnages.json`) ; `personnage` vide ou connu de `personnages.json`. Un fichier visé absent ne donne qu'un avertissement.
