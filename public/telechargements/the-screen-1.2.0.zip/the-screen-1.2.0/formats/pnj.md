# `data/pnj.json` — format 2

**Format 2** : `savoirs` dit ce que le PNJ sait de chaque intrigue secrète de `connaissances.json`.

Les PNJ de la campagne, rangés par lieu et sous-lieu. Lu par le widget **PNJ**, et par **Marchands** (fiche d'un tenancier).

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, `decision_mj`, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | non | Ce que contient le fichier. |
| `couverture` | conseillé | Les chapitres déjà couverts (une phrase), affichée repliée en bas du widget. À tenir à jour à chaque export. |
| `types_rang` | conseillé | `{ vip, majeur, mineur }` : libellé de chaque rang (voir `rang`). |
| `lieux` | oui | Voir ci-dessous. |
| `pnj` | oui | Voir ci-dessous. |

### `lieux[]`

Sert au classement du répertoire (ordre des lieux, sous-lieux, ordre des PNJ). Les noms et zones des lieux font foi dans [lieux.json](lieux.md) : ici, `nom` et `zone` ne servent qu'à défaut.

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | `id` de [lieux.json](lieux.md). |
| `nom`, `zone` | non | Redondants avec `lieux.json`. |
| `sous_lieux` | oui | `[{ id, nom, zone? }]` : bâtiments, coins ou niveaux du lieu. Au moins un ; s'il n'y en a qu'un, le widget ne l'affiche pas comme sous-titre. Ce sont les sous-lieux de [lieux.json](lieux.md), qui fait foi (mêmes `id`, voir « Sous-lieux » dans sa fiche). Un lieu sans sous-lieu dans `lieux.json` a ici un sous-lieu de même `id` que lui (`lac-gris`). |
| `pnj` | oui | `id` des PNJ du lieu, dans l'ordre d'affichage voulu. |

### `pnj[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id`, `nom` | oui | |
| `alias` | non | Autres noms (« Rose », « Gaspard le Jeune ») : la recherche les trouve. |
| `lieu`, `sous_lieu` | oui | Où le croiser d'ordinaire : un `lieux[].id` et l'un de ses `sous_lieux[].id`. |
| `etapes` | non | Depuis le 2026-11-05. `id` d'étapes de `deroule-campagne.json` où le PNJ se joue. **Une exception, rarement utile** : à donner seulement quand le PNJ ne suit pas sa pièce (croisé dans une étape qui ne couvre pas son sous-lieu). D'ordinaire, les `sous_lieux` des étapes et leurs jalons suffisent ([deroule-campagne.md](deroule-campagne.md)). |
| `aussi` | non | Autres lieux ou sous-lieux où on le croise. Chaque valeur est un lieu ou un sous-lieu de [lieux.json](lieux.md) (décision du MJ : pas seulement ceux de `pnj.lieux`). Filtré sur un lieu, le widget le montre dans « Aussi croisés ici ». |
| `profil` | oui | Bloc de stats ou nature (« Vétéran », « Fantôme »). |
| `role` | oui | Une ligne : qui il est pour l'intrigue. |
| `description` | conseillé | Comment le jouer. |
| `etat` | oui | Au début de la campagne : `vivant`, `mort`, `mort-vivant`, `disparu` ou `absent`. Sert au filtre par état et aux badges ; l'état noté en jeu (`etat/pnj.json`) prime. |
| `statut` | non | Précision libre sur l'état (« fantôme », « pendu », « captive »). Affiché comme badge et dans la fiche. |
| `important` | oui | Booléen : porte l'intrigue du lieu (filtre « Importants »). Vaut `true` quand `rang` est `vip` ou `majeur`. |
| `rang` | conseillé | Place du PNJ dans la trame (importance, pas âge) : `vip` (fil rouge de toute la campagne : le grand méchant, la princesse à protéger, le vieux mentor…), `majeur` (au cœur d'une grande étape ou d'un lieu majeur), `mineur` (rôle local ou ponctuel). Libellés dans `types_rang`. |
| `factions` | conseillé | `id` de [factions.json](factions.md) auxquelles il appartient ; tableau vide s'il n'en a pas. Une faction `secret` (une société secrète) ne s'affiche pas par défaut. |
| `savoirs` | non | Ce que ce PNJ peut apprendre aux PJ sur une intrigue secrète : `{ "<id d'intrigue de connaissances.json>": "ce qu'il sait ou peut transmettre, et à quelle condition" }` (par exemple `{ "reliques": "Sait où repose la deuxième relique, s'il est payé." }`). Réservé au MJ. Cohérent avec le groupe correspondant de [connaissances.json](connaissances.md). |
| `wiki` | non | `{ id, url }` : la page du PNJ sur le wiki des joueurs (voir « Liens vers le wiki » dans [README.md](README.md)). Plusieurs PNJ peuvent partager une page (une famille). |
| `original`, `decision_mj` | non | Voir [README.md](README.md). |
| `source`, `fiche` | oui | |

## Ce que fait le widget

Recherche (nom, alias, rôle, profil, notes du MJ), filtres par lieu, par état, par rang (VIP, VIP et majeurs, majeurs, mineurs), par faction et par savoir (le nom court de l'intrigue, « Reliques », s'il n'y en a qu'une), « Rencontrés », tri par rang (ordre de `lieux[].pnj` à rang égal). Au bout de chaque ligne : la puce de rang (VIP en puce rose néon, M en orange, m en gris ; un clic change le rang en jeu) et le bouton « Vu », qui marque un PNJ rencontré. Les factions s'affichent en petits badges, une icône repère les PNJ qui ont des `savoirs`. Les factions `secret` restent masquées tant que la case « Secrets » n'est pas cochée. Chaque PNJ s'ouvre sur sa fiche : profil, rôle, description, rang, factions (un clic filtre la liste), état et statut, ce qu'il sait de chaque intrigue (`savoirs`), alias, autres lieux, décision du MJ, version du livre, provenance. Le suivi de campagne (rencontré, état en jeu, notes) va dans `etat/pnj.json` (voir [etat.md](etat.md)) sans toucher au fichier. Les noms de lieux viennent de [lieux.json](lieux.md).

## Contrôles faits par le gestionnaire

`id` uniques (lieux, sous-lieux d'un lieu, PNJ) ; chaque PNJ a un `lieu` connu (ici et dans `lieux.json`) et un `sous_lieu` de ce lieu ; chaque `id` cité dans `lieux[].pnj` existe ; chaque PNJ est cité dans le `pnj` de son lieu ; `etat` a une des cinq valeurs ; chaque `aussi` désigne un lieu ou un sous-lieu de `lieux.json` ; `rang` vaut `vip`, `majeur` ou `mineur` ; chaque `factions[]` existe dans `factions.json` (avertissement si le fichier n'est pas chargé) ; `savoirs` est un objet de textes non vides.
