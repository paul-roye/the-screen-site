﻿# Import des icônes des états (Aveuglé, Charmé, Épuisement…) de D&D Beyond : celles de Maps, le VTT de D&D Beyond.
# La page d'une partie répond sans session (redirection vers la connexion) mais liste déjà les morceaux de code de Maps :
# celui qui contient la table des icônes d'états (un SVG par état, clés « blinded », « charmed »… = `slug` des états
# de D&D Beyond) est lu et ses SVG écrits dans icones-beyond/etats.json, lu par app/etats.js (widget Personnages).
# Œuvres de D&D Beyond : usage local, hors dépôt (.gitignore), comme images-library/. Sans ce fichier, le gestionnaire
# montre une icône de repli. À relancer si D&D Beyond change ses icônes (le nom du morceau change à chaque version de Maps).
# N'importe quelle adresse de partie fait l'affaire (celle d'une partie qui n'est pas la vôtre aussi) : sans session, la page
# renvoie toujours la même coquille, avec la liste des morceaux de code de Maps.
# Code de sortie : 0 réussi, 1 échec (rien n'est modifié).

param(
  [string]$Partie = 'https://www.dndbeyond.com/games/1',
  [string]$Sortie = (Join-Path $PSScriptRoot '..\..\icones-beyond\etats.json')
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$utf8 = New-Object Text.UTF8Encoding $false
$CLES = 'blinded', 'charmed', 'deafened', 'exhaustion', 'frightened', 'grappled', 'incapacitated', 'invisible',
  'paralyzed', 'petrified', 'poisoned', 'prone', 'restrained', 'stunned', 'unconscious'

# Corps d'une réponse, même de redirection (la page d'une partie répond 307 sans session).
function Lire([string]$url) {
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri $url -MaximumRedirection 0 -TimeoutSec 60 -ErrorAction Stop }
  catch {
    $rep = $_.Exception.Response
    if (-not $rep) { throw }
    return (New-Object IO.StreamReader($rep.GetResponseStream(), [Text.Encoding]::UTF8)).ReadToEnd()
  }
  return [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
}

# Chaîne JavaScript entre apostrophes : ses échappements (\n, \', \uXXXX…) décodés.
function Decoder([string]$s) {
  return [regex]::Replace($s, '\\(u[0-9a-fA-F]{4}|x[0-9a-fA-F]{2}|.)', {
    param($m)
    $e = $m.Groups[1].Value
    switch -CaseSensitive ($e[0]) {
      'n' { "`n" } 't' { "`t" } 'r' { "`r" }
      'u' { [string][char][Convert]::ToInt32($e.Substring(1), 16) }
      'x' { [string][char][Convert]::ToInt32($e.Substring(1), 16) }
      default { $e }
    }
  })
}

try {
  Write-Host "Lecture de $Partie..."
  $page = Lire $Partie
  $morceaux = [regex]::Matches($page, 'https://media\.dndbeyond\.com/games/_next/static/chunks/[^"''\s\\]+\.js') | ForEach-Object Value | Select-Object -Unique
  if (-not $morceaux) { throw 'La page de la partie ne liste aucun morceau de code de Maps : D&D Beyond a changé sa page ?' }
  $icones = [ordered]@{}
  $source = $null
  foreach ($u in $morceaux) {
    $code = Lire $u
    if ($code -notmatch "blinded:[\w$]+\('<svg") { continue }
    foreach ($m in [regex]::Matches($code, "(?<cle>[a-z]+):[\w$]+\('(?<svg><svg(?:[^'\\]|\\.)*)'\)")) {
      $cle = $m.Groups['cle'].Value
      if ($CLES -contains $cle -and -not $icones.Contains($cle)) { $icones[$cle] = (Decoder $m.Groups['svg'].Value).Trim() }
    }
    $source = $u
    break
  }
  if (-not $source) { throw "Aucun des $($morceaux.Count) morceaux de code de Maps ne contient la table des icônes d'états : D&D Beyond a changé son code ?" }
  $manque = $CLES | Where-Object { -not $icones.Contains($_) }
  if ($icones.Count -lt 10) { throw "Table des icônes incomplète ($($icones.Count) sur $($CLES.Count)) dans $source." }

  $valeur = [ordered]@{ schema = 1; source = $source; importe_le = (Get-Date).ToString('o'); icones = $icones }
  $dossier = Split-Path $Sortie
  if (-not (Test-Path $dossier)) { New-Item -ItemType Directory -Path $dossier | Out-Null }
  [IO.File]::WriteAllText([IO.Path]::GetFullPath($Sortie), ($valeur | ConvertTo-Json -Depth 4), $utf8)
  Write-Host "$($icones.Count) icônes d'états écrites dans $([IO.Path]::GetFullPath($Sortie))."
  if ($manque) { Write-Host "Sans icône (repli du gestionnaire) : $($manque -join ', ')." }
  exit 0
} catch {
  Write-Host "Échec : $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
