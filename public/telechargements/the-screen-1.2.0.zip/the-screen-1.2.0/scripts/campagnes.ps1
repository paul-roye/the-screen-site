﻿# Campagnes du gestionnaire (campagnes/<id>/manifeste.json, formats/campagne.md), pour les scripts d'import.
# À inclure après scripts/poste.ps1 :  $campagne = Campagne-Choisie <racine> $poste [<id>]
# Renvoie @{ id; dossier; manifeste } : `dossier` contient data/, etat/, wiki/ et musique/ de la campagne (la racine du
# gestionnaire pour une campagne `dossiers_a_la_racine`). Sans id : la campagne par défaut, comme lancer.ps1 (`campagne` de
# poste.json, sinon celle à la racine, sinon la première). Sans dossier campagnes/ : la racine, sans manifeste.

# Toutes les campagnes, par id : @{ id; dossier; manifeste; aLaRacine }.
function Campagnes-Toutes([string]$racine) {
    $liste = [ordered]@{}
    $dossier = Join-Path $racine 'campagnes'
    if (Test-Path $dossier -PathType Container) {
        foreach ($d in Get-ChildItem $dossier -Directory | Sort-Object Name) {
            $f = Join-Path $d.FullName 'manifeste.json'
            if (-not (Test-Path $f -PathType Leaf)) { continue }
            $m = [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8) | ConvertFrom-Json
            $liste[$d.Name] = @{ id = $d.Name; dossier = $(if ($m.dossiers_a_la_racine) { $racine } else { $d.FullName }); manifeste = $m; aLaRacine = [bool]$m.dossiers_a_la_racine }
        }
    }
    return $liste
}

function Campagne-Choisie([string]$racine, $poste, [string]$id) {
    $liste = Campagnes-Toutes $racine
    if ($id) {
        if (-not $liste.Contains($id)) { throw "Campagne « $id » introuvable (campagnes/$id/manifeste.json). Campagnes : $(@($liste.Keys) -join ', ')." }
        return $liste[$id]
    }
    if ($poste.campagne -and $liste.Contains($poste.campagne)) { return $liste[$poste.campagne] }
    foreach ($c in $liste.Values) { if ($c.aLaRacine) { return $c } }
    foreach ($c in $liste.Values) { return $c }
    return @{ id = $null; dossier = $racine; manifeste = $null; aLaRacine = $true }
}

# Bibliothèque d'images d'une campagne sur ce poste (formats/images.md) : campagnes/<id>/images-library\ (hors dépôt),
# sauf réglage de poste.json : `bibliotheques.<id>`, ou `bibliotheque` pour la campagne par défaut ($idDefaut).
function Bibliotheque-Campagne([string]$racine, $poste, $camp, [string]$idDefaut) {
    if ($camp.id -and $poste.bibliotheques.Contains($camp.id)) { return $poste.bibliotheques[$camp.id] }
    if ($poste.bibliotheque -and (-not $camp.id -or $camp.id -eq $idDefaut)) { return $poste.bibliotheque }
    if ($camp.aLaRacine -or -not $camp.id) { return Join-Path $racine 'images-library' }
    return Join-Path (Join-Path $racine "campagnes\$($camp.id)") 'images-library'
}

# Les bibliothèques de toutes les campagnes du poste qui existent (sans doublon), celle par défaut d'abord.
function Bibliotheques-Existantes([string]$racine, $poste) {
    $defaut = (Campagne-Choisie $racine $poste '').id
    $liste = @($poste.bibliotheque) + @((Campagnes-Toutes $racine).Values | ForEach-Object { Bibliotheque-Campagne $racine $poste $_ $defaut }) + @($poste.bibliotheques.Values)
    return @($liste | Where-Object { $_ -and (Test-Path $_ -PathType Container) } | Select-Object -Unique)
}
