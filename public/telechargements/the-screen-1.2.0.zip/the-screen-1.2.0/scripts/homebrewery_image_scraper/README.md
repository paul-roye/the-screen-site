# Images Homebrewery

Les images de documents Homebrewery publics, pour la bibliothèque d'images d'une campagne : une source `homebrewery` de son manifeste (`formats/images.md`, « Sources d'images » : `pages`, les adresses de partage, et `cartes`). Lancé par `scripts/import-images/importer-images.ps1` (fenêtre Campagne, onglet « Images », ou `outils/Importer les images.cmd`).

```powershell
powershell -ExecutionPolicy Bypass -File .\telecharger-images.ps1 -Pages <url>,<url> -OutDir <dossier> [-Cartes <url>,<url>]
```

Le script lit chaque document (un toutes les 3 à 6 s), puis récupère les images citées dans le texte et le style : Markdown, `<img>`, `url(...)`. Il les enregistre dans `<dossier>\<chapitre>\` (« Ch.03 - Le Port d'Aurval » pour un titre en « Ch.3 : … », sinon le titre du document), les cartes dans un sous-dossier `Cartes\` (titre explicite, ou image listée dans `-Cartes`). Les noms d'origine étant aléatoires (`cqp7E4B.png`), chaque image est nommée `NN - <titre de la section>`. Les doublons et les fonds de page du thème importé sont ignorés.

Relancer le script reprend là où il s'était arrêté. Les images introuvables chez leur hébergeur sont listées dans `echecs.txt`.
