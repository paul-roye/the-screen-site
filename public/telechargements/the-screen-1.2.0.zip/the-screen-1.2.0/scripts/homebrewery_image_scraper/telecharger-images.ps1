﻿# Télécharge les images de documents Homebrewery publics (leurs adresses de partage), rangées par document.
# Usage : powershell -ExecutionPolicy Bypass -File .	elecharger-images.ps1 -Pages <url>[,<url>…] -OutDir <dossier> [-Cartes <url>[,…]]
# En général lancé par scripts/import-images/importer-images.ps1 (source « homebrewery » du manifeste de la campagne).
# Chaque image est nommée d'après sa position et le titre de la section où elle apparaît
# (les noms d'origine sont aléatoires). Les fonds de page du thème et les doublons sont ignorés.
# Les cartes (titre explicite, ou adresse de l'image dans -Cartes) vont dans <document>\Cartes.
# Relancer le script reprend là où il s'était arrêté (les fichiers existants sont ignorés).
param(
    [Parameter(Mandatory)][string[]]$Pages,
    [Parameter(Mandatory)][string]$OutDir,
    [string[]]$Cartes = @(),
    [int]$MinPageDelayMs = 3000,
    [int]$MaxPageDelayMs = 6000,
    [int]$MinDelayMs = 1000,
    [int]$MaxDelayMs = 2500
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # sinon Invoke-WebRequest est très lent en PS 5.1
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Web.Extensions
$json = New-Object Web.Script.Serialization.JavaScriptSerializer
$json.MaxJsonLength = [int]::MaxValue

function Get-SafeName([string]$name, [int]$max = 80) {
    $invalid = [IO.Path]::GetInvalidFileNameChars() -join ''
    $name = ($name -replace "[$([regex]::Escape($invalid))]", ' ' -replace '\s+', ' ').Trim().TrimEnd('.')
    if ($name.Length -gt $max) { $name = $name.Substring(0, $max).Trim() }
    return $name
}

# Images d'un document : Markdown ![alt](url), <img src>, et url(...) en CSS, dans l'ordre de lecture
function Get-BrewImages([string]$text) {
    $heading = ''; $seen = @{}; $images = @()
    foreach ($line in ($text -split "`n")) {
        if ($line -match '^#{1,4}\s+(.+)') { $heading = ($Matches[1] -replace '[*_`]', '').Trim() }
        foreach ($m in [regex]::Matches($line, '!\[([^\]]*)\]\(\s*<?([^)\s>]+)|<img[^>]*src=["'']([^"'']+)|url\(\s*["'']?([^"'')\s]+)')) {
            $url = @($m.Groups[2].Value, $m.Groups[3].Value, $m.Groups[4].Value) | Where-Object { $_ } | Select-Object -First 1
            if ($url -notmatch '^https?://' -or $url -match '\.(css|ttf|otf|woff2?)(\?|$)' -or $seen[$url]) { continue }
            $seen[$url] = $true
            $images += [pscustomobject]@{ Url = $url; Heading = $heading; Alt = $m.Groups[1].Value }
        }
    }
    return $images
}

$wc = New-Object Net.WebClient
$wc.Encoding = [Text.Encoding]::UTF8
$wc.Headers['User-Agent'] = 'Mozilla/5.0'

$urls = @($Pages | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$knownMaps = @($Cartes | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$ok = 0; $skipped = 0; $failed = @(); $p = 0
foreach ($shareUrl in $urls) {
    $p++
    if ($p -gt 1) { Start-Sleep -Milliseconds (Get-Random -Minimum $MinPageDelayMs -Maximum $MaxPageDelayMs) }
    try { $html = $wc.DownloadString($shareUrl.Trim()) }
    catch { Write-Warning "Page illisible : $shareUrl ($($_.Exception.Message))"; continue }

    $m = [regex]::Match($html, '(?s)window\.__INITIAL_PROPS__ = (\{.*?\})\s*</script>')
    if (-not $m.Success) { Write-Warning "Contenu introuvable dans $shareUrl"; continue }
    $brew = $json.DeserializeObject($m.Groups[1].Value)['brew']

    # Un document par chapitre : « … Ch.3 :Le Port d'Aurval » -> « Ch.03 - Le Port d'Aurval » ; sinon son titre.
    $title = $brew['title']
    $chapter = if ($title -match 'Ch\.?\s*(\d+)\s*:?\s*(.+)$') { 'Ch.{0:00} - {1}' -f [int]$Matches[1], $Matches[2].Trim() } else { $title }
    $chapterDir = Join-Path $OutDir (Get-SafeName $chapter)

    $images = @(Get-BrewImages ($brew['text'] + "`n" + $brew['style']))
    Write-Host "  [$p/$($urls.Count)] $chapter : $($images.Count) images"

    $n = 0
    foreach ($img in $images) {
        $n++
        $isMap = $knownMaps -contains $img.Url -or
            "$($img.Heading) $($img.Alt) $($img.Url)" -match '(?i)\bmaps?\b|\bplans?\b|\bcarte d'   # « Carte du village », pas « Cartes de quête »
        $dir = if ($isMap) { Join-Path $chapterDir 'Cartes' } else { $chapterDir }
        New-Item -ItemType Directory -Force -Path $dir | Out-Null

        $ext = [IO.Path]::GetExtension(([Uri]$img.Url).AbsolutePath)
        if ($ext -notmatch '^\.(png|jpe?g|webp|gif|svg)$') { $ext = '.jpg' }
        $label = if ($img.Heading) { $img.Heading } elseif ($n -eq 1) { 'Couverture' } else { 'Sans titre' }
        $target = Join-Path $dir ('{0:00} - {1}{2}' -f $n, (Get-SafeName $label), $ext)
        if (Test-Path $target) { $skipped++; continue }

        Write-Host "  $(Split-Path $target -Leaf)"
        try {
            Invoke-WebRequest -Uri $img.Url -OutFile $target -UseBasicParsing -UserAgent 'Mozilla/5.0'
            $ok++
        } catch {
            $status = $_.Exception.Response.StatusCode.value__
            Write-Warning "  échec ($status) : $($img.Url)"
            $failed += "$chapter | $($img.Url)"
            if (Test-Path $target) { Remove-Item $target }
            if ($status -eq 429) { Write-Warning '  429 : pause de 2 minutes'; Start-Sleep -Seconds 120 }
        }
        Start-Sleep -Milliseconds (Get-Random -Minimum $MinDelayMs -Maximum $MaxDelayMs)
    }
}

Write-Host "  Terminé : $ok téléchargées, $skipped déjà présentes, $($failed.Count) échecs."
if ($failed.Count) { $failed | Set-Content -Encoding UTF8 (Join-Path $OutDir 'echecs.txt') }
