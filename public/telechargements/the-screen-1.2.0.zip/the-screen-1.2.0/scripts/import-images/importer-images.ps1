﻿# Importe les images d'une campagne dans sa bibliothèque (formats/images.md) : les sources de `images.sources` de son
# manifeste, l'une après l'autre, chacune dans son dossier de la bibliothèque, puis indexe la bibliothèque.
#   beyond       un livre de D&D Beyond : sa liste d'images, .liste-beyond.txt de son dossier (relevée par l'extension du MJ,
#                fenêtre Campagne), sinon celle fournie avec le gestionnaire pour ce livre
#                (scripts/dndbeyond_image_scraper/listes/<livre>.txt, <livre> : la fin de l'adresse du livre) ;
#   homebrewery  des documents Homebrewery publics (`pages`, et `cartes` : les images qui sont des cartes sans le dire) ;
#   dossier      les images du MJ, rangées à la main : rien à télécharger.
# Usage : powershell -ExecutionPolicy Bypass -File .\importer-images.ps1 [-Campagne <id>] [-Source <n°>] [-Journal <fichier>]
# (ou double-clic sur « outils/Importer les images.cmd » : toutes les sources de la campagne par défaut).
# Le gestionnaire le lance lui-même (fenêtre Campagne, onglet « Images ») avec -Journal : ce qu'il affiche y est aussi
# écrit, et la page le montre. Relancer reprend là où il s'était arrêté : les images déjà là ne sont pas retéléchargées.
param(
    [string]$Campagne = '',
    [int]$Source = -1,
    [string]$Journal = ''
)
$ErrorActionPreference = 'Stop'
$racine = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
. (Join-Path $racine 'scripts\poste.ps1')
. (Join-Path $racine 'scripts\campagnes.ps1')
$poste = Lire-Poste $racine
$camp = Campagne-Choisie $racine $poste $Campagne
$defaut = (Campagne-Choisie $racine $poste '').id
$biblio = Bibliotheque-Campagne $racine $poste $camp $defaut
# Poste neuf, lancé à la main : où ranger la bibliothèque de la campagne par défaut.
if (-not $Journal -and -not $poste.existe -and $camp.id -eq $defaut) {
    $biblio = Choisir-Bibliotheque $racine $biblio -Creer
    if (-not $biblio) { exit 1 }
}
if (-not (Bibliotheque-Valide $racine $biblio)) { exit 1 }
New-Item -ItemType Directory -Force $biblio | Out-Null

# Le dossier d'une source : un nom de dossier simple, dans la bibliothèque (ni chemin, ni « .. »).
function Dossier-Source($s) {
    $d = ([string]$s.dossier).Trim()
    if (-not $d -or $d -match '[\\/:*?"<>|]' -or $d.StartsWith('.')) { return $null }
    return $d
}

if ($Journal) { try { Start-Transcript -Path $Journal -Force | Out-Null } catch { } }
$verrou = $null
try { $verrou = [IO.File]::Open((Join-Path $biblio '.import-en-cours'), 'OpenOrCreate', 'ReadWrite', 'None') }
catch { Write-Host 'Un import des images est déjà en cours pour cette bibliothèque.' -ForegroundColor Red; if ($Journal) { try { Stop-Transcript | Out-Null } catch { } }; exit 1 }
try {
    Write-Host '=== Import des images ==='   # repère du journal (lancer.ps1 ne montre que ce qui suit)
    Write-Host "  Campagne : $($camp.id) · bibliothèque : $biblio"
    $sources = @($camp.manifeste.images.sources | Where-Object { $_ })
    if (-not $sources.Count) { Write-Host "  La campagne n'a pas de source d'images (« images.sources » de son manifeste, fenêtre Campagne, onglet « Images »)." }
    $indices = if ($Source -ge 0) { @($Source) } else { @(0..($sources.Count - 1) | Where-Object { $sources.Count }) }
    foreach ($n in $indices) {
        $s = $sources[$n]
        $dossier = if ($s) { Dossier-Source $s } else { $null }
        if (-not $dossier) { Write-Host "  Source n° $n inconnue ou sans dossier valide." -ForegroundColor Red; continue }
        $sortie = Join-Path $biblio $dossier
        New-Item -ItemType Directory -Force $sortie | Out-Null
        Write-Host "  --- $dossier ($($s.type))"
        try {
            switch ([string]$s.type) {
                'beyond' {
                    $liste = Join-Path $sortie '.liste-beyond.txt'
                    if (-not (Test-Path $liste)) {
                        $livre = if ($s.adresse) { ([Uri][string]$s.adresse).Segments[-1].Trim('/') } else { '' }
                        $liste = Join-Path $racine "scripts\dndbeyond_image_scraper\listes\$livre.txt"
                        if (-not $livre -or -not (Test-Path $liste)) { Write-Host "  Pas encore de liste d'images pour ce livre : « Relever le livre » d'abord (fenêtre Campagne, avec l'extension du MJ)."; continue }
                        Write-Host "  Liste fournie avec le gestionnaire ($livre)."
                    }
                    & (Join-Path $racine 'scripts\dndbeyond_image_scraper\2-telecharger-images.ps1') -List $liste -OutDir $sortie
                }
                'homebrewery' {
                    $pages = @($s.pages | Where-Object { $_ })
                    if (-not $pages.Count) { Write-Host '  Aucune page Homebrewery à lire.'; continue }
                    & (Join-Path $racine 'scripts\homebrewery_image_scraper\telecharger-images.ps1') -Pages $pages -Cartes @($s.cartes | Where-Object { $_ }) -OutDir $sortie
                }
                'dossier' { Write-Host "  Rien à télécharger : rangez vos images dans $sortie (un sous-dossier « Cartes » pour les cartes)." }
                default { Write-Host "  Type de source inconnu : « $($s.type) »." -ForegroundColor Red; continue }
            }
            [IO.File]::WriteAllText((Join-Path $sortie '.importe-le'), (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz'))
        } catch { Write-Host "  Échec : $($_.Exception.Message)" -ForegroundColor Red }
    }
    Write-Host '  --- Index'
    & (Join-Path $racine 'scripts\indexer-images\indexer-images.ps1') -Bibliotheque $biblio
    Write-Host '  Import terminé.'
} finally {
    if ($verrou) { $verrou.Dispose(); Remove-Item (Join-Path $biblio '.import-en-cours') -ErrorAction SilentlyContinue }
    if ($Journal) { try { Stop-Transcript | Out-Null } catch { } }
}
