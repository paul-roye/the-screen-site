# Import du wiki de campagne

Récupère le wiki publié de la campagne (vvd.world, adresse dans `wiki.url` du manifeste) dans `wiki/`, pour l'agent IA de campagne et pour le gestionnaire.

## Lancer

Après une séance, une fois le wiki à jour :

- double-cliquer **`outils/Importer le wiki.cmd`** ;
- ou `powershell -ExecutionPolicy Bypass -File .\scripts\import-wiki\importer-wiki.ps1`.

Comptez une vingtaine de secondes pour une trentaine de pages. Le script ne fait que lire les pages publiques du wiki, comme un navigateur, avec une courte pause entre deux pages.

Paramètres facultatifs : `-Url <adresse du wiki>`, `-Sortie <dossier>` (par défaut `wiki/`), `-CategorieHeros 'Héros'`, `-PauseMs 500`.

Code de sortie : 0 réussi, 1 échec (rien n'est modifié), 2 un autre import est déjà en cours.

## Ce qu'il produit (dans `wiki/`)

| Fichier | Pour quoi |
|---|---|
| `wiki-complet.md` | Toutes les pages en Markdown. **À donner à l'agent IA de campagne** pour mettre à jour l'état de la campagne. |
| `changements.md` | Ce qui a changé depuis l'import précédent (pages ajoutées, retirées, lignes modifiées). À donner avec le précédent après une séance. |
| `wiki.json` | Toutes les pages, structurées : lu par le gestionnaire (liste des joueurs, fiches). |
| `images/` | Portraits des héros. |
| `historique/<date>/` | Imports précédents, gardés quand quelque chose a changé. |

Le détail des champs et des conventions est dans [formats/wiki.md](../../formats/wiki.md).

## Secrets

Les passages masqués sur le wiki (balise spoiler) sont marqués `<secret>…</secret>` dans le Markdown et `"secret": true` dans le JSON : le MJ les connaît, les joueurs ne les ont pas encore découverts. Quand un secret est révélé sur le wiki (balise retirée), `changements.md` le montre.

## Joueurs et compagnons

Les pages de la catégorie **Héros** sont des personnages joueurs, sauf celles qu'un autre héros cite dans ses propriétés (le familier d'un héros, par exemple) : elles sont rangées en compagnons.

## Si l'import échoue

- « le site a peut-être changé de format » : vvd.world a modifié ses pages ; le script est à adapter (il lit les données que Next.js embarque dans chaque page : `refs`, `entityTypes`, `embeds`).
- Erreur réseau : relancer. En cas d'échec, l'import précédent reste intact.
