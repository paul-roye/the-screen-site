﻿# Importe le wiki de la campagne (site publié sur vvd.world) dans wiki/ : une source pour l'IA de la campagne
# (wiki-complet.md), qui s'en sert pour écrire les données (personnages, PNJ, lore…). Le gestionnaire n'en lit que les
# portraits des héros, en attendant que personnages.json ait les siens. Rien n'est supposé de l'organisation du wiki :
# toutes les pages publiées sont lues ; seule la catégorie des héros (`wiki.categorie_heros` du manifeste, ou
# -CategorieHeros), facultative, marque les personnages joueurs et télécharge leurs portraits.
# Usage : powershell -ExecutionPolicy Bypass -File .\importer-wiki.ps1   (ou double-clic sur « outils/Importer le wiki.cmd »)
#         ... -Campagne <id> -Url <adresse du wiki> -Sortie <dossier> -CategorieHeros <catégorie> -Journal <fichier>
# Le gestionnaire le lance lui-même (fenêtre Campagne, onglet « Campagne », bouton « Importer le wiki ») avec -Journal :
# ce qu'il affiche y est aussi écrit, et la page le montre.
# La campagne (campagnes/<id>/, formats/campagne.md ; par défaut celle de lancer.ps1) donne l'adresse du wiki (`wiki.url`
# de son manifeste) et le dossier wiki/ où écrire.
#
# Lecture seule sur le wiki : le script lit les pages publiques, comme un navigateur.
# Écrit dans wiki/ de la campagne (et nulle part ailleurs) :
#   wiki.json          toutes les pages, structurées (format : formats/wiki.md)
#   wiki-complet.md    toutes les pages en Markdown, à donner à l'agent IA de campagne
#   changements.md     ce qui a changé depuis l'import précédent
#   images/            portraits des héros
#   historique/        imports précédents (wiki.json et wiki-complet.md)
# Les passages masqués (balises spoiler du wiki) sont marqués « secret » : connus du MJ, pas encore des joueurs.
# Rien n'est écrit si une page n'a pas pu être lue : l'import précédent reste en place.
param(
    [string]$Campagne = '',
    [string]$Url = '',
    [string]$Sortie = '',
    [string]$CategorieHeros = $null,
    [string]$Journal = '',
    [int]$PauseMs = 500
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$utf8 = New-Object Text.UTF8Encoding $false
$racineGestionnaire = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
. (Join-Path $racineGestionnaire 'scripts\poste.ps1')
. (Join-Path $racineGestionnaire 'scripts\campagnes.ps1')
$laCampagne = Campagne-Choisie $racineGestionnaire (Lire-Poste $racineGestionnaire) $Campagne
if (-not $Url) { $Url = [string]$laCampagne.manifeste.wiki.url }
if (-not $Url) { Write-Host "La campagne « $($laCampagne.id) » n'a pas de wiki : ajoutez « wiki.url » à son manifeste.json, ou passez -Url." -ForegroundColor Red; exit 1 }
if (-not $Sortie) { $Sortie = Join-Path $laCampagne.dossier 'wiki' }
if (-not $PSBoundParameters.ContainsKey('CategorieHeros')) { $CategorieHeros = [string]$laCampagne.manifeste.wiki.categorie_heros }
if ($Journal) { try { Start-Transcript -Path $Journal -Force | Out-Null } catch { } }
$Url = $Url.TrimEnd('/')
$AdresseMedias = 'https://media.vvd.world/'

Add-Type -AssemblyName System.Web.Extensions
$serialiseur = New-Object Web.Script.Serialization.JavaScriptSerializer
$serialiseur.MaxJsonLength = [int]::MaxValue
$serialiseur.RecursionLimit = 1000

# Outils rapides (C#) : flux RSC de Next.js, extraction d'un objet JSON, écriture JSON indentée.
Add-Type -Language CSharp -TypeDefinition @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

public static class WikiOutils {
    // Les pages Next.js envoient leurs données dans un flux « RSC » : lignes « id:valeur ».
    // Les textes longs sont sortis à part (« id:T<longueur en octets>,<texte> ») et cités par "$id".
    public static Dictionary<string, string> TextesRsc(string s) {
        var t = new Dictionary<string, string>();
        int i = 0;
        while (i < s.Length) {
            int deux = s.IndexOf(':', i);
            if (deux < 0) break;
            string id = s.Substring(i, deux - i);
            bool hex = id.Length > 0 && id.Length <= 8;
            foreach (char c in id) if (!Uri.IsHexDigit(c)) { hex = false; break; }
            if (hex && deux + 1 < s.Length && s[deux + 1] == 'T') {
                int virgule = s.IndexOf(',', deux);
                int octets = int.Parse(s.Substring(deux + 2, virgule - deux - 2), NumberStyles.HexNumber);
                int j = virgule + 1, n = 0;
                while (j < s.Length && n < octets) {
                    char c = s[j];
                    if (char.IsHighSurrogate(c)) { n += 4; j += 2; }
                    else { n += c < 0x80 ? 1 : c < 0x800 ? 2 : 3; j++; }
                }
                t[id] = s.Substring(virgule + 1, j - virgule - 1);
                i = j;
            } else {
                int fin = s.IndexOf('\n', deux);
                i = fin < 0 ? s.Length : fin + 1;
            }
        }
        return t;
    }

    // Objet ou tableau JSON équilibré qui commence à la position i.
    public static string Objet(string s, int i) {
        int prof = 0; bool chaine = false;
        for (int j = i; j < s.Length; j++) {
            char c = s[j];
            if (chaine) { if (c == '\\') j++; else if (c == '"') chaine = false; continue; }
            if (c == '"') chaine = true;
            else if (c == '{' || c == '[') prof++;
            else if (c == '}' || c == ']') { prof--; if (prof == 0) return s.Substring(i, j - i + 1); }
        }
        return null;
    }

    // Remplace les renvois RSC dans les chaînes : "$3d" -> texte sorti à part, "$$x" -> "$x".
    public static object Resoudre(object o, Dictionary<string, string> textes) {
        var d = o as IDictionary<string, object>;
        if (d != null) {
            foreach (var k in new List<string>(d.Keys)) d[k] = Resoudre(d[k], textes);
            return d;
        }
        var a = o as object[];
        if (a != null) { for (int i = 0; i < a.Length; i++) a[i] = Resoudre(a[i], textes); return a; }
        var s = o as string;
        if (s != null && s.Length > 1 && s[0] == '$') {
            if (s[1] == '$') return s.Substring(1);
            string id = s.Substring(1);
            if (textes.ContainsKey(id)) return textes[id];
        }
        return o;
    }

    public static string Ecrire(object o) { var sb = new StringBuilder(); Valeur(sb, o, 0); sb.Append('\n'); return sb.ToString(); }

    static void Valeur(StringBuilder sb, object o, int n) {
        var pso = o as System.Management.Automation.PSObject; if (pso != null) o = pso.BaseObject;
        if (o == null) { sb.Append("null"); return; }
        if (o is string) { Chaine(sb, (string)o); return; }
        if (o is bool) { sb.Append((bool)o ? "true" : "false"); return; }
        if (o is int || o is long || o is double || o is decimal || o is float) { sb.Append(Convert.ToString(o, CultureInfo.InvariantCulture)); return; }
        var d = o as IDictionary;
        if (d != null) {
            if (d.Count == 0) { sb.Append("{}"); return; }
            sb.Append("{\n"); int i = 0;
            foreach (DictionaryEntry e in d) {
                sb.Append(' ', 2 * (n + 1)); Chaine(sb, e.Key.ToString()); sb.Append(": "); Valeur(sb, e.Value, n + 1);
                if (++i < d.Count) sb.Append(','); sb.Append('\n');
            }
            sb.Append(' ', 2 * n).Append('}'); return;
        }
        var l = o as IEnumerable;
        if (l != null) {
            var elts = new List<object>(); foreach (var x in l) elts.Add(x);
            if (elts.Count == 0) { sb.Append("[]"); return; }
            bool simples = true; foreach (var x in elts) if (x is IDictionary || (x is IEnumerable && !(x is string))) simples = false;
            if (simples) { sb.Append('['); for (int i = 0; i < elts.Count; i++) { if (i > 0) sb.Append(", "); Valeur(sb, elts[i], n); } sb.Append(']'); return; }
            sb.Append("[\n");
            for (int i = 0; i < elts.Count; i++) { sb.Append(' ', 2 * (n + 1)); Valeur(sb, elts[i], n + 1); if (i < elts.Count - 1) sb.Append(','); sb.Append('\n'); }
            sb.Append(' ', 2 * n).Append(']'); return;
        }
        Chaine(sb, o.ToString());
    }

    static void Chaine(StringBuilder sb, string s) {
        sb.Append('"');
        foreach (char c in s) {
            switch (c) {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default: if (c < 0x20) sb.AppendFormat("\\u{0:x4}", (int)c); else sb.Append(c); break;
            }
        }
        sb.Append('"');
    }
}
'@

function Liste { , (New-Object Collections.Generic.List[object]) }
function Dico { [ordered]@{} }

# ───── Lecture du wiki ─────

$client = New-Object Net.WebClient
$client.Encoding = $utf8

function Telecharger([string]$adresse) {
    for ($essai = 1; ; $essai++) {
        try {
            $client.Headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) gestionnaire-de-campagne/1.0'
            $client.Headers['Accept-Language'] = 'fr'
            return $client.DownloadString($adresse)
        } catch {
            $code = $_.Exception.InnerException.Response.StatusCode.value__
            if ($essai -ge 3 -or $code -eq 404) { throw "lecture impossible de $adresse ($($_.Exception.InnerException.Message))" }
            $attente = if ($code -eq 429) { 30 } else { 3 * $essai }
            Write-Host "    nouvel essai dans $attente s…" -ForegroundColor DarkYellow
            Start-Sleep -Seconds $attente
        }
    }
}

# Page HTML -> flux RSC décodé.
function LireRsc([string]$adresse) {
    $html = Telecharger $adresse
    $sb = New-Object Text.StringBuilder
    foreach ($m in [regex]::Matches($html, 'self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)')) {
        [void]$sb.Append($serialiseur.DeserializeObject($m.Groups[1].Value))
    }
    if (-not $sb.Length) { throw "pas de données dans $adresse (le site a peut-être changé de format)" }
    $titre = if ($html -match '<title>([^<]*)</title>') { [Net.WebUtility]::HtmlDecode($Matches[1]) -replace '\s*·\s*vvd\s*$', '' } else { '' }
    @{ rsc = $sb.ToString(); titre = $titre }
}

# Valeur JSON associée à la première clé "nom" du flux.
function Champ([string]$rsc, [string]$nom) {
    $i = $rsc.IndexOf('"' + $nom + '":{')
    if ($i -lt 0) { return $null }
    $serialiseur.DeserializeObject([WikiOutils]::Objet($rsc, $i + $nom.Length + 3))
}

# ───── Contenu (ProseMirror) -> blocs simplifiés ─────
# Segment : { texte, gras, italique, souligne, barre, code, lien, page, saut, secret }

$script:refs = @{}   # id -> { nom, slug }
$script:liens = $null

function Segments($contenu) {
    $segs = Liste
    foreach ($n in @($contenu)) {
        if ($n -isnot [Collections.IDictionary]) { continue }
        $s = Dico
        switch ($n['type']) {
            'text' { $s.texte = [string]$n['text'] }
            'mention' {
                $id = $n['attrs']['id']
                $s.texte = if ($n['attrs']['label']) { [string]$n['attrs']['label'] } elseif ($script:refs[$id]) { $script:refs[$id].nom } else { '?' }
                $s.page = $id
                if (-not $script:liens.Contains($id)) { $script:liens.Add($id) }
            }
            'hardBreak' { $s.texte = "`n"; $s.saut = $true }
            default { $s.texte = TexteBrut $n }
        }
        if (-not $s.texte) { continue }   # (un « continue » dans un switch ne sort que du switch)
        foreach ($mk in @($n['marks'])) {
            if ($mk -isnot [Collections.IDictionary]) { continue }
            switch ($mk['type']) {
                'bold' { $s.gras = $true }
                'italic' { $s.italique = $true }
                'underline' { $s.souligne = $true }
                'strike' { $s.barre = $true }
                'code' { $s.code = $true }
                'blur' { $s.secret = $true }
                'spoiler' { $s.secret = $true }
                'link' { if ($mk['attrs']['href']) { $s.lien = [string]$mk['attrs']['href'] } }
            }
        }
        $segs.Add($s)
    }
    # Un lien ou un saut de ligne pris entre deux passages secrets est secret aussi
    # (le wiki n'applique pas la balise aux mentions).
    for ($i = 1; $i -lt $segs.Count - 1; $i++) {
        $s = $segs[$i]
        if (-not $s.secret -and ($s.page -or $s.saut -or -not $s.texte.Trim()) -and $segs[$i - 1].secret -and $segs[$i + 1].secret) { $s.secret = $true }
    }
    # Fusion des segments voisins de même mise en forme.
    $fusion = Liste
    foreach ($s in $segs) {
        $prec = if ($fusion.Count) { $fusion[$fusion.Count - 1] } else { $null }
        if ($prec -and -not $prec.page -and -not $s.page -and -not $prec.saut -and -not $s.saut -and (Forme $prec) -eq (Forme $s)) { $prec.texte += $s.texte }
        else { $fusion.Add($s) }
    }
    , $fusion
}
function Forme($s) { ($s.Keys | Where-Object { $_ -ne 'texte' } | Sort-Object | ForEach-Object { "$_=$($s[$_])" }) -join ';' }

function TexteBrut($n) {
    if ($n -is [Collections.IDictionary]) {
        if ($n['type'] -eq 'text') { return [string]$n['text'] }
        if ($n['type'] -eq 'mention') { return [string]$n['attrs']['label'] }
        if ($n['type'] -eq 'hardBreak') { return "`n" }
        $sep = if ($n['type'] -in 'paragraph', 'heading', 'listItem') { "`n" } else { '' }
        return ((@($n['content']) | ForEach-Object { TexteBrut $_ }) -join '') + $sep
    }
    if ($n -is [object[]]) { return ($n | ForEach-Object { TexteBrut $_ }) -join '' }
    ''
}

function Noeuds($contenu) {
    $l = Liste
    foreach ($n in @($contenu)) {
        if ($n -isnot [Collections.IDictionary]) { continue }
        $b = Dico
        switch ($n['type']) {
            'paragraph' { $b.type = 'paragraphe'; $b.segments = Segments $n['content'] }
            'heading' { $b.type = 'titre'; $b.niveau = [int]$n['attrs']['level']; $b.segments = Segments $n['content'] }
            { $_ -in 'bulletList', 'orderedList', 'taskList' } {
                $b.type = 'liste'; $b.ordonnee = $n['type'] -eq 'orderedList'
                $elts = Liste
                foreach ($li in @($n['content'])) { if ($li -is [Collections.IDictionary]) { $elts.Add((Noeuds $li['content'])) } }
                $b.elements = $elts
            }
            'blockquote' { $b.type = 'citation'; $b.contenu = Noeuds $n['content'] }
            'codeBlock' { $b.type = 'code'; $b.texte = TexteBrut $n['content'] }
            'horizontalRule' { $b.type = 'separateur' }
            'image' { $b.type = 'image'; $b.url = [string]$n['attrs']['src']; $b.legende = [string]$n['attrs']['alt'] }
            'table' {
                $b.type = 'tableau'; $lignes = Liste
                foreach ($tr in @($n['content'])) {
                    $cellules = Liste
                    foreach ($td in @($tr['content'])) { $cellules.Add((Noeuds $td['content'])) }
                    $lignes.Add($cellules)
                }
                $b.lignes = $lignes
            }
            default {
                $t = (TexteBrut $n).Trim()
                if ($t) { $b.type = 'autre'; $b.nature = [string]$n['type']; $b.texte = $t }
            }
        }
        if (-not $b.type) { continue }
        if ($b.type -in 'paragraphe', 'titre' -and -not ($b.segments | Where-Object { $_.texte.Trim() })) { continue }
        $l.Add($b)
    }
    , $l
}

function Image($media) {
    if (-not $media) { return $null }
    $i = Dico; $i.media = [string]$media; $i.url = $AdresseMedias + $media; $i
}

# ───── Blocs simplifiés -> Markdown ─────

function Envelopper([string]$t, [string]$avant, [string]$apres) {
    if (-not $t.Trim()) { return $t }
    $debut = $t.Length - $t.TrimStart().Length; $fin = $t.Length - $t.TrimEnd().Length
    $t.Substring(0, $debut) + $avant + $t.Trim() + $apres + $t.Substring($t.Length - $fin)
}
function MdSegment($s) {
    if ($s.page) {
        # [[Page]] ou [[Page|texte affiché]] quand le texte du lien diffère du nom de la page.
        $cible = if ($script:refs[$s.page]) { $script:refs[$s.page].nom } else { $s.texte }
        return $(if ($cible -eq $s.texte) { "[[$cible]]" } else { "[[$cible|$($s.texte)]]" })
    }
    if ($s.saut) { return "  `n" }
    $t = $s.texte
    if ($s.code) { $t = Envelopper $t '`' '`' }
    if ($s.lien) { $t = Envelopper $t '[' "]($($s.lien))" }
    if ($s.barre) { $t = Envelopper $t '~~' '~~' }
    if ($s.souligne) { $t = Envelopper $t '_' '_' }
    if ($s.italique) { $t = Envelopper $t '*' '*' }
    if ($s.gras) { $t = Envelopper $t '**' '**' }
    $t
}
function MdSegments($segs) {
    $sb = New-Object Text.StringBuilder
    $dansSecret = $false
    foreach ($s in $segs) {
        if ([bool]$s.secret -ne $dansSecret) { [void]$sb.Append($(if ($s.secret) { '<secret>' } else { '</secret>' })); $dansSecret = [bool]$s.secret }
        [void]$sb.Append((MdSegment $s))
    }
    if ($dansSecret) { [void]$sb.Append('</secret>') }
    $sb.ToString().Trim()
}
function MdNoeuds($noeuds, [int]$decalage) {
    $sortie = Liste
    foreach ($b in $noeuds) {
        switch ($b.type) {
            'paragraphe' { $sortie.Add((MdSegments $b.segments)) }
            'titre' { $sortie.Add(('#' * [Math]::Min(6, $decalage + [Math]::Max(1, $b.niveau - 2))) + ' ' + (MdSegments $b.segments)) }   # niveaux 1 à 3 -> ####
            'liste' {
                $num = 0
                $lignes = foreach ($e in $b.elements) {
                    $num++
                    $puce = if ($b.ordonnee) { "$num. " } else { '- ' }
                    $texte = (MdNoeuds $e $decalage) -join "`n"
                    $puce + ($texte -replace "`n", "`n  ")
                }
                $sortie.Add(($lignes -join "`n"))
            }
            'citation' { $sortie.Add(('> ' + (((MdNoeuds $b.contenu $decalage) -join "`n`n") -replace "`n", "`n> "))) }
            'code' { $sortie.Add("``````n$($b.texte.TrimEnd())`n``````") }
            'separateur' { $sortie.Add('---') }
            'image' { $sortie.Add("![$($b.legende)]($($b.url))") }
            'tableau' {
                $lignes = foreach ($tr in $b.lignes) { '| ' + (($tr | ForEach-Object { ((MdNoeuds $_ $decalage) -join ' ') -replace "`n", ' ' }) -join ' | ') + ' |' }
                if ($lignes.Count) {
                    $cols = $b.lignes[0].Count
                    $lignes = @($lignes[0], ('|' + (' --- |' * $cols))) + @($lignes | Select-Object -Skip 1)
                }
                $sortie.Add(($lignes -join "`n"))
            }
            'autre' { $sortie.Add($b.texte) }
        }
    }
    , $sortie
}

function CompterSecrets($o) {
    $n = 0
    if ($o -is [Collections.IDictionary]) {
        if ($o.Contains('segments')) {
            $dans = $false
            foreach ($s in $o.segments) { if ($s.secret -and -not $dans) { $n++ }; $dans = [bool]$s.secret }
        }
        foreach ($v in $o.Values) { if ($v -is [Collections.IEnumerable] -and $v -isnot [string]) { $n += CompterSecrets $v } }
    } elseif ($o -is [Collections.IEnumerable] -and $o -isnot [string]) {
        foreach ($x in $o) { $n += CompterSecrets $x }
    }
    $n
}

# ───── Dates des chronologies ─────

function DateChrono($ms, $cal) {
    if ($null -eq $ms) { return '' }
    $ms = [double]$ms
    if ($cal -and $cal['mode'] -eq 'custom' -and $cal['months']) {
        $mois = @($cal['months'])
        $annee = ($mois | ForEach-Object { [double]$_['days'] } | Measure-Object -Sum).Sum
        $jours = [Math]::Floor($ms / 86400000)
        $a = [Math]::Floor($jours / $annee); $reste = $jours - $a * $annee
        $m = 0; while ($m -lt $mois.Count - 1 -and $reste -ge $mois[$m]['days']) { $reste -= $mois[$m]['days']; $m++ }
        $suffixe = if ($cal['afterLabel']) { ' ' + $cal['afterLabel'] } else { '' }
        # Premier ou dernier jour de l'année : l'année suffit.
        if (($m -eq 0 -and $reste -eq 0) -or ($m -eq $mois.Count - 1 -and $reste -eq $mois[$m]['days'] - 1)) { return "$a$suffixe" }
        return "$($reste + 1) $($mois[$m]['name']) $a$suffixe"
    }
    [DateTimeOffset]::FromUnixTimeMilliseconds([long]$ms).ToString('yyyy-MM-dd')
}

# ───── Une page ─────

function LirePage($ref, $doc, $types) {
    $script:liens = New-Object Collections.Generic.List[string]
    $p = Dico
    $p.id = $ref['id']; $p.slug = $ref['slug']; $p.nom = $ref['name']; $p.url = "$Url/$($ref['slug'])"
    $p.nature = switch ($ref['type']) { 'card' { 'fiche' } 'map' { 'carte' } 'timeline' { 'chronologie' } 'canvas-v2' { 'canevas' } default { $ref['type'] } }
    $type = if ($ref['entityTypeId']) { $types[$ref['entityTypeId']] } else { $null }
    $p.categorie = if ($type) { $type['name'] } else { switch ($p.nature) { 'carte' { 'Carte' } 'chronologie' { 'Chronologie' } 'canevas' { 'Canevas' } default { 'Sans catégorie' } } }
    if ($type -and $type['parentTypeId'] -and $types[$type['parentTypeId']]) { $p.categorie_parente = $types[$type['parentTypeId']]['name'] }

    if (-not $doc) { $p.erreur = 'Contenu introuvable dans la page.'; return $p }

    if ($p.nature -eq 'fiche') {
        $entete = @($doc['content']) | Where-Object { $_['type'] -eq 'cardHeader' } | Select-Object -First 1
        $corps = @($doc['content']) | Where-Object { $_['type'] -eq 'contentBody' } | Select-Object -First 1
        $a = if ($entete) { $entete['attrs'] } else { @{} }
        $p.alias = @(@($a['aliases']) | Where-Object { $_ })
        $props = Liste
        foreach ($pr in @($a['properties'])) {
            if ($pr -isnot [Collections.IDictionary]) { continue }
            $v = $pr['value']
            $o = Dico; $o.nom = [string]$pr['name']; $o.type = [string]$pr['type']
            if ($pr['type'] -eq 'reference') {
                $vals = Liste
                foreach ($id in @($v)) {
                    if (-not $id) { continue }
                    $r = Dico; $r.page = $id; $r.nom = if ($script:refs[$id]) { $script:refs[$id].nom } else { '(page non publiée)' }
                    $vals.Add($r)
                    if (-not $script:liens.Contains($id)) { $script:liens.Add($id) }
                }
                if (-not $vals.Count) { continue }
                $o.valeur = $vals
            } else {
                if ($null -eq $v -or "$v".Trim() -eq '') { continue }
                $o.valeur = if ($v -is [object[]]) { (@($v) -join ', ') } else { "$v".Trim() }
            }
            $props.Add($o)
        }
        $p.proprietes = $props
        if ($a['avatar']) { $p.portrait = Image $a['avatar'] }

        $blocs = Liste
        $sections = if ($corps) { @($corps['attrs']['sections']) } else { @() }
        foreach ($sec in $sections) {
            if ($sec -isnot [Collections.IDictionary]) { continue }
            foreach ($bl in @($sec['blocks'])) {
                if ($bl -isnot [Collections.IDictionary]) { continue }
                $b = Dico
                $titre = if ($bl['title'] -and -not $bl['titleHidden']) { ([string]$bl['title']).Trim() } else { '' }
                if ($titre) { $b.titre = $titre }
                switch ($bl['type']) {
                    'text' {
                        $b.type = 'texte'
                        $b.contenu = if ($bl['content'] -is [object[]]) { Noeuds $bl['content'] } else { Liste }
                    }
                    'media' { $b.type = 'image'; $b.image = Image $bl['mediaId']; if ($bl['caption']) { $b.legende = [string]$bl['caption'] } }
                    default {
                        $b.type = 'renvoi'; $b.nature = [string]$bl['type']
                        foreach ($k in 'documentId', 'mapId', 'timelineId', 'linkedDocumentId') { if ($bl[$k]) { $b.page = $bl[$k] } }
                    }
                }
                if ($b.type -eq 'texte' -and -not $b.contenu.Count) { continue }
                $blocs.Add($b)
            }
        }
        $p.blocs = $blocs
    }
    elseif ($p.nature -eq 'carte') {
        if ($doc['background'] -and $doc['background']['mediaId']) { $p.image = Image $doc['background']['mediaId'] }
        $lieux = Liste
        foreach ($x in @($doc['pins']) + @($doc['zones'])) {
            if ($x -isnot [Collections.IDictionary] -or -not $x['label']) { continue }
            $l = Dico; $l.nom = [string]$x['label']
            if ($x['description']) { $l.description = [string]$x['description'] }
            if ($x['linkedDocumentId']) { $l.page = $x['linkedDocumentId']; if (-not $script:liens.Contains($l.page)) { $script:liens.Add($l.page) } }
            $l.forme = if ($x['vertices']) { 'zone' } else { 'epingle' }
            $lieux.Add($l)
        }
        $p.lieux = $lieux
    }
    elseif ($p.nature -eq 'chronologie') {
        $cal = $doc['calendar']
        $ages = Liste
        foreach ($x in @($doc['ages'])) {
            if ($x -isnot [Collections.IDictionary]) { continue }
            $e = Dico; $e.nom = [string]$x['label']; $e.debut = DateChrono $x['startMs'] $cal; $e.fin = DateChrono $x['endMs'] $cal; $e.debut_ms = $x['startMs']
            $ages.Add($e)
        }
        $p.ages = @($ages | Sort-Object { [double]$_.debut_ms })
        $evts = Liste
        foreach ($x in @($doc['events'])) {
            if ($x -isnot [Collections.IDictionary]) { continue }
            $e = Dico; $e.nom = [string]$x['label']; $e.date = DateChrono $x['dateMs'] $cal; $e.date_ms = $x['dateMs']
            if ($x['description']) { $e.description = [string]$x['description'] }
            $evts.Add($e)
        }
        $p.evenements = @($evts | Sort-Object { [double]$_.date_ms })
    }
    elseif ($p.nature -eq 'canevas') {
        $textes = Liste
        foreach ($r in @($doc['records'].Values)) {
            if ($r -isnot [Collections.IDictionary] -or $r['typeName'] -ne 'shape') { continue }
            $t = if ($r['props']['richText']) { TexteBrut $r['props']['richText'] } else { [string]$r['props']['text'] }
            if ($t.Trim()) { $textes.Add($t.Trim()) }
        }
        $p.textes = $textes
    }
    $p.liens = @($script:liens)
    $p
}

function MdPage($p) {
    $md = New-Object Collections.Generic.List[string]
    $md.Add("## $($p.nom)")
    $cat = $p.categorie
    if ($p.categorie_parente) { $cat = "$($p.categorie_parente) › $cat" }
    if ($p.role -eq 'personnage') { $cat += ' · personnage joueur' }
    if ($p.role -eq 'compagnon') { $cat += ' · compagnon de ' + (($p.compagnon_de | ForEach-Object { "[[$($script:refs[$_].nom)]]" }) -join ', ') }
    $md.Add("*$cat* · [page du wiki]($($p.url))")
    $infos = New-Object Collections.Generic.List[string]
    if ($p.alias) { $infos.Add('- Aussi appelé : ' + ($p.alias -join ', ')) }
    foreach ($pr in $p.proprietes) {
        $v = if ($pr.type -eq 'reference') { ($pr.valeur | ForEach-Object { "[[$($_.nom)]]" }) -join ', ' } else { $pr.valeur }
        $infos.Add("- $($pr.nom) : $v")
    }
    if ($p.portrait) { $infos.Add('- ' + $(if ($p.categorie -in $CategorieHeros, 'PNJ') { 'Portrait' } else { 'Image' }) + ' : ' + $(if ($p.portrait.fichier) { $p.portrait.fichier } else { $p.portrait.url })) }
    if ($p.image) { $infos.Add("- Image : $($p.image.url)") }
    if ($infos.Count) { $md.Add(($infos -join "`n")) }
    if ($p.erreur) { $md.Add("> Import incomplet : $($p.erreur)") }
    foreach ($b in $p.blocs) {
        if ($b.titre) { $md.Add("### $($b.titre)") }
        switch ($b.type) {
            'texte' { foreach ($x in (MdNoeuds $b.contenu 3)) { $md.Add($x) } }
            'image' { $md.Add("![$($b.legende)]($($b.image.url))") }
            'renvoi' {
                $quoi = switch ($b.nature) { 'map' { 'carte intégrée' } 'timeline' { 'chronologie intégrée' } default { "$($b.nature) intégré" } }
                $md.Add("*($quoi" + $(if ($b.page -and $script:refs[$b.page]) { " : [[$($script:refs[$b.page].nom)]]" } else { '' }) + ')*')
            }
        }
    }
    if ($p.lieux.Count) {
        $md.Add('### Lieux sur la carte')
        $md.Add((($p.lieux | ForEach-Object {
            $n = if ($_.page -and $script:refs[$_.page]) { MdSegment @{ page = $_.page; texte = $_.nom } } else { $_.nom }
            "- $n" + $(if ($_.description) { " : $($_.description)" } else { '' })
        }) -join "`n"))
    }
    if ($p.ages.Count) { $md.Add('### Âges'); $md.Add((($p.ages | ForEach-Object { "- $($_.nom) : $($_.debut) → $($_.fin)" }) -join "`n")) }
    if ($p.evenements.Count) {
        $md.Add('### Événements')
        $md.Add((($p.evenements | ForEach-Object { "- **$($_.date)** · $($_.nom)" + $(if ($_.description) { " : $($_.description)" } else { '' }) }) -join "`n"))
    }
    if ($p.textes.Count) { $md.Add('### Notes'); $md.Add((($p.textes | ForEach-Object { "- " + ($_ -replace "`n", ' ') }) -join "`n")) }
    $md -join "`n`n"
}

function DateLisible($iso) {
    try { ([DateTimeOffset]::Parse($iso)).ToLocalTime().ToString('dddd d MMMM yyyy à HH \h mm') } catch { [string]$iso }
}

function Empreinte([string]$t) {
    $h = [Security.Cryptography.SHA256]::Create()
    -join ($h.ComputeHash($utf8.GetBytes($t)) | Select-Object -First 12 | ForEach-Object { $_.ToString('x2') })
}

# ───── Import ─────

$Sortie = [IO.Path]::GetFullPath($Sortie)
New-Item -ItemType Directory -Force -Path $Sortie | Out-Null
$verrou = $null
try { $verrou = [IO.File]::Open((Join-Path $Sortie '.import-en-cours'), 'OpenOrCreate', 'ReadWrite', 'None') }
catch { Write-Host 'Un import du wiki est déjà en cours.' -ForegroundColor Red; exit 2 }

try {
    $debut = Get-Date
    Write-Host ''
    Write-Host '  Import du wiki de campagne' -ForegroundColor Magenta
    Write-Host "  $Url" -ForegroundColor Cyan
    Write-Host ''

    $accueil = LireRsc $Url
    $refsBrutes = Champ $accueil.rsc 'refs'
    $types = Champ $accueil.rsc 'entityTypes'
    if (-not $refsBrutes -or -not $types) { throw "La page d'accueil ne contient pas la liste des pages (le site a peut-être changé de format)." }
    foreach ($r in $refsBrutes.Values) { $script:refs[$r['id']] = @{ nom = $r['name']; slug = $r['slug'] } }
    $aLire = @($refsBrutes.Values | Sort-Object { $_['name'] })
    Write-Host "  « $($accueil.titre) » : $($aLire.Count) pages publiées."

    $pages = Liste
    $n = 0
    foreach ($ref in $aLire) {
        $n++
        Write-Host ("  [{0,2}/{1}] {2}" -f $n, $aLire.Count, $ref['name'])
        Start-Sleep -Milliseconds $PauseMs
        $page = LireRsc "$Url/$($ref['slug'])"
        $embeds = Champ $page.rsc 'embeds'
        $doc = if ($embeds) { $embeds[$ref['id']] } else { $null }
        if ($doc) { $doc = [WikiOutils]::Resoudre($doc, [WikiOutils]::TextesRsc($page.rsc)) }
        $p = LirePage $ref $doc $types
        if ($p.erreur) { Write-Host "         $($p.erreur)" -ForegroundColor DarkYellow }
        $pages.Add($p)
    }

    # Héros : personnages joueurs, sauf ceux qu'un autre héros cite dans ses propriétés (familier, monture…).
    $heros = if ($CategorieHeros) { @($pages | Where-Object { $_.categorie -eq $CategorieHeros }) } else { @() }
    if (-not $CategorieHeros) { Write-Host '  Pas de catégorie des héros (wiki.categorie_heros du manifeste) : ni héros marqués ni portraits téléchargés.' -ForegroundColor DarkGray }
    foreach ($h in $heros) {
        $maitres = @($heros | Where-Object { $_.id -ne $h.id -and ($_.proprietes | Where-Object { $_.type -eq 'reference' -and ($_.valeur | Where-Object { $_.page -eq $h.id }) }) })
        if ($maitres.Count) { $h.role = 'compagnon'; $h.compagnon_de = @($maitres | ForEach-Object { $_.id }) }
        else { $h.role = 'personnage' }
    }

    # Portraits des héros.
    $dossierImages = Join-Path $Sortie 'images'
    New-Item -ItemType Directory -Force -Path $dossierImages | Out-Null
    foreach ($h in $heros) {
        if (-not $h.portrait) { continue }
        $existant = Get-ChildItem $dossierImages -Filter "$($h.portrait.media).*" -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $existant) {
            Write-Host "  Portrait de $($h.nom)"
            $tmp = Join-Path $dossierImages "$($h.portrait.media).tmp"
            try {
                $client.Headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) gestionnaire-de-campagne/1.0'
                $client.DownloadFile($h.portrait.url, $tmp)
                $type = $client.ResponseHeaders['Content-Type']
                $ext = switch -Wildcard ($type) { 'image/png*' { '.png' } 'image/jpeg*' { '.jpg' } 'image/gif*' { '.gif' } 'image/avif*' { '.avif' } default { '.webp' } }
                Move-Item -Force $tmp (Join-Path $dossierImages "$($h.portrait.media)$ext")
                $existant = Get-Item (Join-Path $dossierImages "$($h.portrait.media)$ext")
            } catch {
                Write-Host "    portrait non téléchargé : $($_.Exception.Message)" -ForegroundColor DarkYellow
                Remove-Item $tmp -ErrorAction SilentlyContinue
            }
        }
        if ($existant) { $h.portrait.fichier = "images/$($existant.Name)" }
    }

    # Markdown, secrets et empreinte de chaque page.
    foreach ($p in $pages) {
        $p.secrets = CompterSecrets $p.blocs
        $p.markdown = MdPage $p
        $p.empreinte = Empreinte $p.markdown
    }

    # Ordre : héros, puis par catégorie et par nom.
    $ordre = { if ($_.role -eq 'personnage') { 0 } elseif ($_.role -eq 'compagnon') { 1 } else { 2 } }
    $pages = @($pages | Sort-Object $ordre, { $_.categorie_parente + '/' + $_.categorie }, { $_.nom })

    # Comparaison avec l'import précédent.
    $fichierJson = Join-Path $Sortie 'wiki.json'
    $avant = $null
    if (Test-Path $fichierJson) {
        try { $avant = $serialiseur.DeserializeObject([IO.File]::ReadAllText($fichierJson, $utf8)) }
        catch { Write-Host "  Import précédent illisible, il sera remplacé : $($_.Exception.Message)" -ForegroundColor DarkYellow }
    }
    $ancien = @{}
    if ($avant) { foreach ($q in @($avant['pages'])) { $ancien[$q['id']] = $q } }
    $ajoutees = Liste; $modifiees = Liste; $retirees = Liste
    foreach ($p in $pages) {
        if (-not $ancien.ContainsKey($p.id)) { $ajoutees.Add($p.id) }
        elseif ($ancien[$p.id]['empreinte'] -ne $p.empreinte) { $modifiees.Add($p.id) }
    }
    $nouveauxIds = @{}; foreach ($p in $pages) { $nouveauxIds[$p.id] = $true }
    foreach ($q in $ancien.Values) { if (-not $nouveauxIds[$q['id']]) { $r = Dico; $r.id = $q['id']; $r.nom = $q['nom']; $r.categorie = $q['categorie']; $retirees.Add($r) } }
    $aChange = ($ajoutees.Count + $modifiees.Count + $retirees.Count) -gt 0

    $maintenant = (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz')
    $wiki = Dico
    $wiki.schema = 1
    $wiki.jeu = 'wiki'
    $wiki.titre = $accueil.titre
    $wiki.source = $Url
    $wiki.importe_le = $maintenant
    $wiki.avertissement = 'Fichier généré par scripts/import-wiki/importer-wiki.ps1 depuis le wiki de la campagne. Ne pas modifier à la main : corriger le wiki, puis relancer l''import.'
    if ($avant) { $wiki.import_precedent = $avant['importe_le'] }
    $wiki.personnages = @($pages | Where-Object { $_.role -eq 'personnage' } | ForEach-Object { $_.id })
    $wiki.compagnons = @($pages | Where-Object { $_.role -eq 'compagnon' } | ForEach-Object { $_.id })
    $cats = Liste
    foreach ($g in ($pages | Group-Object { $_.categorie })) {
        $c = Dico; $c.nom = $g.Name
        if ($g.Group[0].categorie_parente) { $c.parente = $g.Group[0].categorie_parente }
        $c.pages = @($g.Group | ForEach-Object { $_.id })
        $cats.Add($c)
    }
    $wiki.categories = $cats
    $ch = Dico; $ch.ajoutees = $ajoutees; $ch.modifiees = $modifiees; $ch.retirees = $retirees
    $wiki.changements = $ch
    $wiki.pages = $pages

    # ───── Fichiers ─────

    $jour = DateLisible $maintenant

    $conventions = @'
Conventions :

- `<secret>…</secret>` : passage masqué sur le wiki (balise spoiler). Le MJ le connaît ; les joueurs (ou les autres joueurs, sur une fiche de personnage) ne l'ont pas encore découvert. Ne jamais le révéler aux joueurs.
- `[[Nom]]` : lien vers une autre page du wiki.
- Le wiki raconte la campagne telle que la table la vit : il peut s'écarter du livre.
'@
    $complet = New-Object Collections.Generic.List[string]
    $complet.Add("# Wiki « $($accueil.titre) »")
    $complet.Add("Import du $jour, depuis $Url.  `nFichier généré par ``scripts/import-wiki/importer-wiki.ps1`` : ne pas le modifier à la main.")
    $complet.Add($conventions.Trim())
    $sommaire = foreach ($g in ($pages | Group-Object { if ($_.role -eq 'personnage') { 'Personnages joueurs' } elseif ($_.role -eq 'compagnon') { 'Compagnons' } else { $_.categorie } })) {
        "- **$($g.Name)** : " + (($g.Group | ForEach-Object { $_.nom }) -join ', ')
    }
    $complet.Add("## Sommaire`n`n" + ($sommaire -join "`n"))
    foreach ($p in $pages) { $complet.Add('---'); $complet.Add($p.markdown) }
    $texteComplet = ($complet -join "`n`n") + "`n"

    $chg = New-Object Collections.Generic.List[string]
    $chg.Add('# Changements du wiki')
    if (-not $avant) { $chg.Add("Premier import ($jour) : rien à comparer.") }
    else {
        $chg.Add("Import du $jour, comparé à l'import du $(DateLisible $avant['importe_le']).")
        if (-not $aChange) { $chg.Add('Aucun changement.') }
        if ($ajoutees.Count) { $chg.Add("## Pages ajoutées ($($ajoutees.Count))`n`n" + (($ajoutees | ForEach-Object { $id = $_; $q = $pages | Where-Object { $_.id -eq $id }; "- [[$($q.nom)]] ($($q.categorie))" }) -join "`n")) }
        if ($retirees.Count) { $chg.Add("## Pages retirées ou dépubliées ($($retirees.Count))`n`n" + (($retirees | ForEach-Object { "- $($_.nom) ($($_.categorie))" }) -join "`n")) }
        if ($modifiees.Count) {
            $chg.Add("## Pages modifiées ($($modifiees.Count))")
            $chg.Add('Lignes retirées (-) et ajoutées (+). Un secret révélé apparaît comme une ligne `<secret>` retirée et la même ligne, sans balise, ajoutée.')
            foreach ($id in $modifiees) {
                $q = $pages | Where-Object { $_.id -eq $id }
                $l1 = @(([string]$ancien[$id]['markdown']) -split "`n" | Where-Object { $_.Trim() })
                $l2 = @($q.markdown -split "`n" | Where-Object { $_.Trim() })
                $diff = @(Compare-Object $l1 $l2 -CaseSensitive -SyncWindow ([Math]::Max($l1.Count, $l2.Count)))
                $lignes = @($diff | Where-Object { $_.SideIndicator -eq '<=' } | ForEach-Object { '- ' + $_.InputObject }) +
                          @($diff | Where-Object { $_.SideIndicator -eq '=>' } | ForEach-Object { '+ ' + $_.InputObject })
                $chg.Add("### $($q.nom)`n`n``````diff`n" + ($lignes -join "`n") + "`n``````")
            }
        }
    }
    $texteChangements = ($chg -join "`n`n") + "`n"

    # Archive de l'import précédent (s'il y a du nouveau), puis écriture.
    if ($avant -and $aChange) {
        $horo = try { ([DateTimeOffset]::Parse($avant['importe_le'])).ToString('yyyy-MM-dd_HHmm') } catch { (Get-Item $fichierJson).LastWriteTime.ToString('yyyy-MM-dd_HHmm') }
        $archive = Join-Path $Sortie "historique\$horo"
        New-Item -ItemType Directory -Force -Path $archive | Out-Null
        foreach ($f in 'wiki.json', 'wiki-complet.md', 'changements.md') { if (Test-Path (Join-Path $Sortie $f)) { Copy-Item -Force (Join-Path $Sortie $f) $archive } }
    }
    $ecrire = {
        param($nomFichier, $texte)
        $cible = Join-Path $Sortie $nomFichier
        [IO.File]::WriteAllText("$cible.tmp", $texte, $utf8)
        Move-Item -Force "$cible.tmp" $cible
    }
    & $ecrire 'wiki.json' ([WikiOutils]::Ecrire($wiki))
    & $ecrire 'wiki-complet.md' $texteComplet
    & $ecrire 'changements.md' $texteChangements

    # ───── Bilan ─────
    $secrets = 0; foreach ($p in $pages) { $secrets += $p.secrets }
    Write-Host ''
    Write-Host ("  Terminé en {0:N0} s : {1} pages, {2} passages secrets." -f ((Get-Date) - $debut).TotalSeconds, $pages.Count, $secrets) -ForegroundColor Green
    Write-Host ('  Personnages : ' + (($pages | Where-Object { $_.role -eq 'personnage' } | ForEach-Object { $_.nom }) -join ', '))
    $comp = @($pages | Where-Object { $_.role -eq 'compagnon' })
    if ($comp.Count) { Write-Host ('  Compagnons  : ' + (($comp | ForEach-Object { $_.nom }) -join ', ')) }
    if (-not $avant) { Write-Host '  Premier import.' }
    elseif ($aChange) { Write-Host "  Depuis l'import précédent : $($ajoutees.Count) ajoutée(s), $($modifiees.Count) modifiée(s), $($retirees.Count) retirée(s). Détail : changements.md" -ForegroundColor Cyan }
    else { Write-Host "  Aucun changement depuis l'import précédent." }
    $incompletes = @($pages | Where-Object { $_.erreur })
    if ($incompletes.Count) { Write-Host ("  À vérifier : " + (($incompletes | ForEach-Object { $_.nom }) -join ', ')) -ForegroundColor DarkYellow }
    Write-Host "  Dossier : $Sortie"
    Write-Host ''
} catch {
    Write-Host ''
    Write-Host "  Import interrompu : $($_.Exception.Message)" -ForegroundColor Red
    Write-Host '  Rien n''a été modifié dans wiki/.' -ForegroundColor Red
    Write-Host ''
    exit 1
} finally {
    if ($verrou) { $verrou.Dispose(); Remove-Item (Join-Path $Sortie '.import-en-cours') -ErrorAction SilentlyContinue }
    if ($Journal) { try { Stop-Transcript | Out-Null } catch { } }
}
