﻿# Indexe les bibliothèques d'images du poste pour le widget Images : écrit index.json et des miniatures dans .miniatures\
# de chaque bibliothèque (format : formats/images.md). Seules les images nouvelles ou modifiées sont retraitées.
# Usage : powershell -ExecutionPolicy Bypass -File .\scripts\indexer-images\indexer-images.ps1 [-Bibliotheque <dossier>] [-Configurer] [-Silencieux]
# Sans -Bibliotheque : celles de toutes les campagnes du poste (scripts/campagnes.ps1, Bibliotheque-Campagne).
# -Configurer (ou aucune bibliothèque sur le poste) : demande le dossier de celle de la campagne par défaut, enregistré dans
# poste.json s'il n'est pas celui de la campagne.
# Lancé en arrière-plan par lancer.ps1 au démarrage du gestionnaire.
# L'index ne dit que ce que montrent les fichiers (chemin, titre, dimensions, version joueurs) : il ne suppose aucune
# campagne. Source, catégorie et lieu se déduisent dans la page, avec les règles de la campagne (bibliotheque.json).
param(
    [string]$Bibliotheque,
    [int]$LargeurMiniature,
    [switch]$Configurer,
    [switch]$Silencieux
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$racine = Split-Path (Split-Path $PSScriptRoot)          # le dossier du gestionnaire
. (Join-Path $racine 'scripts\poste.ps1')
. (Join-Path $racine 'scripts\campagnes.ps1')
$poste = Lire-Poste $racine
if (-not $LargeurMiniature) { $LargeurMiniature = $poste.largeur_miniature }
$utf8 = New-Object Text.UTF8Encoding $false
function Dire($m) { if (-not $Silencieux) { Write-Host $m } }

# Les bibliothèques à indexer : celle demandée, sinon toutes celles du poste qui existent.
if ($Bibliotheque) { $dossiers = @(Resoudre-Chemin (Get-Location).Path $Bibliotheque) }
else {
    $campDefaut = Campagne-Choisie $racine $poste ''
    $defaut = Bibliotheque-Campagne $racine $poste $campDefaut $campDefaut.id
    if ($Configurer -or -not (Test-Path $defaut -PathType Container)) {
        if (-not $Silencieux -and ($Configurer -or -not (Bibliotheques-Existantes $racine $poste).Count)) {
            if (-not $Configurer) { Write-Host "Bibliothèque d'images introuvable : $defaut" -ForegroundColor Yellow }
            $defaut = Choisir-Bibliotheque $racine $defaut
            if ($defaut) { Write-Host "Relancer le gestionnaire pour qu'il serve ce dossier." }
        } else { $defaut = $null }
    }
    $dossiers = @(@($defaut) + @(Bibliotheques-Existantes $racine $poste) | Where-Object { $_ -and (Test-Path $_ -PathType Container) } | Select-Object -Unique)
}
if (-not $dossiers.Count) { exit $(if ($Silencieux) { 0 } else { 1 }) }   # lancé par lancer.ps1 : rien à indexer sur ce poste

# « 03-002.isolde » -> « Isolde » ; « map-05.02-white-stag-inn-player » -> « White stag inn » ; « 02 - Jouer le rôle » -> « Jouer le rôle »
function Titre($base) {
    $t = $base -replace '^.* - map-[\d.]+[-.]', '' -replace '^\d+[-.]\d+\.', '' -replace '^\d+\s*-\s*', '' -replace '-player$', ''
    $t = ($t -replace '[-_.]+', ' ').Trim()
    if (-not $t) { $t = $base }
    return $t.Substring(0, 1).ToUpper() + $t.Substring(1)
}
function Empreinte($texte) {
    $md5 = [Security.Cryptography.MD5]::Create()
    -join ($md5.ComputeHash($utf8.GetBytes($texte.ToLower())) | Select-Object -First 6 | ForEach-Object { $_.ToString('x2') })
}

function Indexer([string]$Bibliotheque) {
    if (-not (Bibliotheque-Valide $racine $Bibliotheque)) { return }
    if (-not (Test-Path $Bibliotheque -PathType Container)) { Write-Host "Dossier introuvable : $Bibliotheque" -ForegroundColor Red; return }
    Dire "Bibliothèque : $Bibliotheque"
    $dossierMini = Join-Path $Bibliotheque '.miniatures'
    $fichierIndex = Join-Path $Bibliotheque 'index.json'
    New-Item -ItemType Directory -Force $dossierMini | Out-Null

    # Ancien index : on garde les dimensions des images inchangées (lire une image de 10 Mo coûte cher).
    $ancien = @{}
    if (Test-Path $fichierIndex) {
        try { ([IO.File]::ReadAllText($fichierIndex, [Text.Encoding]::UTF8) | ConvertFrom-Json).images | ForEach-Object { $ancien[$_.id] = $_ } } catch { }
    }

    $fichiers = @(Get-ChildItem $Bibliotheque -Recurse -File -Include *.jpg, *.jpeg, *.png, *.webp | Where-Object { $_.FullName -notlike "$dossierMini*" })
    $images = New-Object System.Collections.ArrayList
    $n = 0; $nouveaux = 0
    foreach ($f in $fichiers) {
        $n++
        $rel = $f.FullName.Substring($Bibliotheque.Length + 1)
        $id = Empreinte $rel
        $ext = $f.Extension.ToLower()
        $mini = "$id" + $(if ($ext -eq '.png') { '.png' } else { '.jpg' })
        $cheminMini = Join-Path $dossierMini $mini
        $prec = $ancien[$id]
        $l = $null; $hh = $null
        if ($prec -and $prec.octets -eq $f.Length -and (Test-Path $cheminMini)) { $l = $prec.largeur; $hh = $prec.hauteur }
        elseif ($ext -ne '.webp') {
            try {
                $img = [Drawing.Image]::FromFile($f.FullName)
                $l = $img.Width; $hh = $img.Height
                $lm = [Math]::Min($LargeurMiniature, $l); $hm = [int][Math]::Round($hh * $lm / $l)
                $bmp = New-Object Drawing.Bitmap $lm, $hm
                $g = [Drawing.Graphics]::FromImage($bmp)
                $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                $g.DrawImage($img, 0, 0, $lm, $hm)
                if ($ext -eq '.png') { $bmp.Save($cheminMini, [Drawing.Imaging.ImageFormat]::Png) }
                else {
                    $codec = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object MimeType -eq 'image/jpeg'
                    $par = New-Object Drawing.Imaging.EncoderParameters 1
                    $par.Param[0] = New-Object Drawing.Imaging.EncoderParameter ([Drawing.Imaging.Encoder]::Quality), ([long]82)
                    $bmp.Save($cheminMini, $codec, $par)
                }
                $g.Dispose(); $bmp.Dispose(); $img.Dispose()
                $nouveaux++
                Dire ("  [{0}/{1}] {2}" -f $n, $fichiers.Count, $rel)
            } catch { Dire "  Illisible : $rel ($($_.Exception.Message))"; $mini = $null }
        } else { $mini = $null }
        $base = [IO.Path]::GetFileNameWithoutExtension($f.Name)
        $entree = [ordered]@{
            id = $id
            chemin = 'images-library/' + ($rel -replace '\\', '/')
            dossier = (Split-Path $rel -Parent) -replace '\\', '/'
            titre = Titre $base
            joueurs = [bool]($base -match '-player$')
            largeur = $l
            hauteur = $hh
            octets = $f.Length
            miniature = $(if ($mini) { 'images-library/.miniatures/' + $mini } else { $null })
        }
        [void]$images.Add($entree)
    }

    # Version joueurs d'une carte : relier les deux versions (même nom sans « -player »).
    $parCle = @{}
    foreach ($i in $images) { $parCle[(($i.chemin -replace '-player(\.\w+)$', '$1') -replace '\.\w+$', '').ToLower() + '|' + $i.joueurs] = $i }
    foreach ($i in $images) {
        $cle = (($i.chemin -replace '-player(\.\w+)$', '$1') -replace '\.\w+$', '').ToLower()
        $autre = $parCle[$cle + '|' + (-not $i.joueurs)]
        $i['paire'] = $(if ($autre) { $autre.id } else { $null })
    }

    # Miniatures orphelines (image retirée de la bibliothèque).
    $gardees = @($images | ForEach-Object { if ($_.miniature) { Split-Path $_.miniature -Leaf } })
    Get-ChildItem $dossierMini -File | Where-Object { $gardees -notcontains $_.Name } | Remove-Item

    $index = [ordered]@{
        schema = 2
        jeu = 'images'
        titre = 'Bibliothèque d''images'
        genere_le = (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz')
        avertissement = 'Index local écrit par scripts/indexer-images/indexer-images.ps1. Ne pas modifier à la main : relancer le script.'
        images = $images
    }
    [IO.File]::WriteAllText($fichierIndex, ($index | ConvertTo-Json -Depth 5), $utf8)
    Dire "$($images.Count) images indexées, $nouveaux miniatures faites."
}

foreach ($d in $dossiers) { Indexer $d }
