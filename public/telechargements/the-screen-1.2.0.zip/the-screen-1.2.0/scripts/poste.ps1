﻿# Réglages propres au poste : poste.json à la racine du gestionnaire (hors dépôt, modèle : poste.exemple.json).
# À inclure par « . (Join-Path <racine> 'scripts\poste.ps1') », puis : $poste = Lire-Poste <racine>
#
# Champs (tous facultatifs) :
#   bibliotheque       dossier de la bibliothèque d'images de la campagne par défaut, pour la ranger ailleurs ; absolu, relatif
#                      à la racine, variables %USERPROFILE%, %OneDrive%… admises. Par défaut, chaque campagne a la sienne,
#                      campagnes\<id>\images-library\. Toujours servie sous l'adresse images-library/ de la campagne.
#   largeur_miniature  largeur des miniatures du widget Images, en pixels (360 par défaut).
#   port               port du gestionnaire (http://localhost:<port>/), 8735 par défaut ; -Port de lancer.ps1 l'emporte.
#                      Pas 8736 (assistant de règles, ou son `regles.port`). Changé : régler aussi l'adresse du gestionnaire
#                      dans l'extension du MJ (sa fenêtre), qui écrit les relevés D&D Beyond.
#   regles             réglages de l'assistant de règles (fournisseur, modèle…), lus par regles/agent.py, pas par ce script.
#   campagne           id de la campagne par défaut (dossier de campagnes/) : celle des adresses sans campagne, dont l'extension
#                      du MJ réglée sur http://localhost:8735. Par défaut : celle dont les dossiers sont à la racine, sinon la première par ordre alphabétique.
#   bibliotheques      bibliothèque d'images de chaque campagne : { "<id>": "<dossier>" }, chemins comme `bibliotheque`.
#                      Sans entrée : `bibliotheque` pour la campagne par défaut s'il est réglé, sinon campagnes\<id>\images-library\
#                      (scripts/campagnes.ps1, Bibliotheque-Campagne).
#   mainteneur         true : le poste du mainteneur, qui développe le gestionnaire (pas d'avertissement « gestionnaire
#                      modifié » quand le code ne correspond plus à version.json, voir scripts/version.ps1).

function Lire-Poste([string]$racine) {
    $poste = [ordered]@{ bibliotheque = ''; largeur_miniature = 360; port = 8735; campagne = ''; bibliotheques = @{}; mainteneur = $false; fichier = (Join-Path $racine 'poste.json'); existe = $false }
    if (Test-Path $poste.fichier) {
        # Un chemin Windows écrit tel quel (D:\Images) n'est pas du JSON valide : les \ seuls sont doublés.
        $texte = [regex]::Replace([IO.File]::ReadAllText($poste.fichier, [Text.Encoding]::UTF8), '\\(\\|")?', { param($m) if ($m.Groups[1].Success) { $m.Value } else { '\\' } })
        try { $lu = $texte | ConvertFrom-Json }
        catch { Write-Warning "poste.json illisible, réglages par défaut ($($poste.fichier)) : $($_.Exception.Message)"; $lu = $null }
        $poste.existe = $true
        if ($lu.bibliotheque) { $poste.bibliotheque = [string]$lu.bibliotheque }
        if ($lu.largeur_miniature) { $poste.largeur_miniature = [int]$lu.largeur_miniature }
        if ($lu.campagne) { $poste.campagne = [string]$lu.campagne }
        if ($lu.mainteneur -eq $true) { $poste.mainteneur = $true }
        if ($lu.bibliotheques) { foreach ($p in $lu.bibliotheques.PSObject.Properties) { $poste.bibliotheques[$p.Name] = Resoudre-Chemin $racine ([string]$p.Value) } }
        if ($lu.port) { $poste.port = [int]$lu.port }
    }
    if ($poste.bibliotheque) { $poste.bibliotheque = Resoudre-Chemin $racine $poste.bibliotheque }
    return $poste
}

function Resoudre-Chemin([string]$racine, [string]$chemin) {
    $chemin = [Environment]::ExpandEnvironmentVariables($chemin.Trim().Trim('"'))
    if (-not [IO.Path]::IsPathRooted($chemin)) { $chemin = Join-Path $racine $chemin }
    return [IO.Path]::GetFullPath($chemin).TrimEnd('\')
}

# Demande le dossier de la bibliothèque de la campagne par défaut (Entrée : $defaut) et le renvoie (chemin complet) ; un
# autre dossier que $defaut est enregistré dans poste.json (`bibliotheque`).
# -Creer : le dossier peut ne pas exister encore (import sur un poste neuf), il est créé.
function Choisir-Bibliotheque([string]$racine, [string]$defaut, [switch]$Creer) {
    Write-Host "Dossier de la bibliothèque d'images sur ce poste (un sous-dossier par source : livre, homebrew, vos images)."
    Write-Host "Chemin absolu ou relatif au gestionnaire, %USERPROFILE% admis. Entrée seule : $defaut"
    $saisi = (Read-Host 'Dossier').Trim().Trim('"')
    if (-not $saisi) { $saisi = $defaut }
    $dossier = Resoudre-Chemin $racine $saisi
    if (-not (Bibliotheque-Valide $racine $dossier)) { return $null }
    if (-not (Test-Path $dossier -PathType Container)) {
        if (-not $Creer) { Write-Host "Dossier introuvable : $dossier" -ForegroundColor Red; return $null }
        New-Item -ItemType Directory -Force $dossier | Out-Null
    }
    if ($dossier -ne (Resoudre-Chemin $racine $defaut)) {
        Ecrire-Poste $racine 'bibliotheque' $saisi
        Write-Host "Enregistré dans poste.json : $dossier" -ForegroundColor Green
    }
    return $dossier
}

# La bibliothèque ne peut pas être le dossier du gestionnaire ni un dossier qui le contient (l'indexeur y écrirait
# index.json et .miniatures\, et indexerait tout le gestionnaire).
function Bibliotheque-Valide([string]$racine, [string]$dossier) {
    $r = [IO.Path]::GetFullPath($racine).TrimEnd('\') + '\'
    if ($r.StartsWith($dossier.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
        Write-Host "Refusé : $dossier est le dossier du gestionnaire ou le contient. Choisir le dossier des images (par ex. $(Join-Path $racine 'images-library'))." -ForegroundColor Red
        return $false
    }
    return $true
}

# Enregistre un champ dans poste.json en gardant les autres.
function Ecrire-Poste([string]$racine, [string]$champ, $valeur) {
    $fichier = Join-Path $racine 'poste.json'
    $contenu = [ordered]@{}
    if (Test-Path $fichier) {
        $lu = [IO.File]::ReadAllText($fichier, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($p in $lu.PSObject.Properties) { $contenu[$p.Name] = $p.Value }
    }
    $contenu[$champ] = $valeur
    [IO.File]::WriteAllText($fichier, ($contenu | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
}
