﻿# Met à jour un gestionnaire installé avec cette version-ci (le dossier décompressé d'une nouvelle version, d'où le script
# est lancé : outils/Mettre à jour.cmd). Le dossier installé reste où il est (l'extension du MJ, chargée depuis lui, garde
# son identifiant) ; seuls les fichiers du gestionnaire y changent (ceux de l'empreinte, scripts/version.ps1, plus
# version.json et LISEZMOI.md) : ceux de la nouvelle version sont copiés, ceux qu'elle n'a plus sont retirés.
# Jamais touchés : campagnes/ (sauf les fichiers de la campagne témoin, jamais son état), poste.json, sources/,
# icones-beyond/, l'assistant de règles installé (regles/.venv, index, modeles), les polices de design-system/fonts/.
# L'ancienne version est d'abord copiée dans anciennes-versions/<version>-<date>/ du dossier installé.
# Depuis la 1.0.0 : la bibliothèque d'images de la campagne par défaut, à la racine (images-library/) sans réglage de
# poste.json, passe dans le dossier de cette campagne (campagnes/<id>/images-library/), où la cherche la 1.1.0.
# Usage : outils/Mettre à jour.cmd [-Dossier <gestionnaire installé>] [-Oui]   (-Oui : sans questions, pour les essais)
param([string]$Dossier = '', [switch]$Oui)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$nouvelle = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\')
. (Join-Path $nouvelle 'scripts\version.ps1')
. (Join-Path $nouvelle 'scripts\poste.ps1')
. (Join-Path $nouvelle 'scripts\campagnes.ps1')
$lireVersion = { param($r) $f = Join-Path $r 'version.json'; if (Test-Path $f) { [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8) | ConvertFrom-Json } }
$vN = & $lireVersion $nouvelle
if (-not $vN.version) { throw "Pas de version.json dans $nouvelle : ce dossier n'est pas une version officielle." }
function Confirmer([string]$question) {
    if ($Oui) { return $true }
    return (Read-Host "$question (o/n)") -match '^\s*o'
}
function Arreter([string]$texte) { Write-Host ''; Write-Host $texte -ForegroundColor Yellow; exit 1 }

Write-Host "Mise à jour vers The Screen $($vN.version)"
Write-Host ''

# Le gestionnaire installé : demandé dans une fenêtre de choix de dossier (ou tapé, si elle ne s'ouvre pas).
if (-not $Dossier) {
    Write-Host 'Choisissez le dossier de votre gestionnaire actuel (celui qui contient « Lancer le gestionnaire.cmd » et campagnes\).'
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dlg = New-Object Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Le dossier de votre gestionnaire actuel (avec « Lancer le gestionnaire.cmd » et campagnes\)'
        $dlg.ShowNewFolderButton = $false
        if ($dlg.ShowDialog() -ne 'OK') { Arreter 'Aucun dossier choisi : rien n''a changé.' }
        $Dossier = $dlg.SelectedPath
    } catch { $Dossier = Read-Host 'Dossier du gestionnaire actuel' }
}
$install = [IO.Path]::GetFullPath($Dossier.Trim('"')).TrimEnd('\')
if (-not (Test-Path (Join-Path $install 'lancer.ps1')) -or -not (Test-Path (Join-Path $install 'campagnes') -PathType Container)) {
    Arreter "$install n'est pas un gestionnaire (pas de lancer.ps1 ni de dossier campagnes\) : rien n'a changé."
}
if ($install -eq $nouvelle) {
    Arreter "C'est le dossier de la nouvelle version elle-même. Décompressez la nouvelle version dans un autre dossier (Téléchargements…), lancez son outils\Mettre à jour.cmd, et choisissez votre gestionnaire actuel."
}
$vA = & $lireVersion $install
$avant = if ($vA.version) { $vA.version } else { 'sans-version' }
Write-Host "Gestionnaire actuel : $install (version $avant)"
if ($vA.version -and ([version]$vA.version -gt [version]$vN.version)) { Arreter "Il est plus récent ($($vA.version)) que cette version ($($vN.version)) : rien n'a changé." }
if ($vA.version -and $vA.version -eq $vN.version -and (Empreinte-Gestionnaire $install) -eq $vN.empreinte) { Arreter "Il est déjà en version $($vN.version) : rien à faire." }

# Le gestionnaire ne doit pas tourner pendant la mise à jour (la fenêtre noire).
$poste = Lire-Poste $install
if (Get-NetTCPConnection -LocalPort $poste.port -State Listen -ErrorAction SilentlyContinue) {
    Arreter "Le gestionnaire tourne encore (port $($poste.port)) : fermez sa fenêtre noire, puis relancez la mise à jour."
}
# Une copie modifiée perd ses modifications (gardées dans la sauvegarde).
if ($vA.empreinte -and (Empreinte-Gestionnaire $install) -ne $vA.empreinte) {
    Write-Host "Votre gestionnaire a été modifié depuis la version $avant : ses modifications seront remplacées (elles restent dans la sauvegarde)." -ForegroundColor Yellow
    if (-not (Confirmer 'Continuer ?')) { Arreter 'Rien n''a changé.' }
} elseif (-not (Confirmer "Mettre à jour vers $($vN.version) ? Vos campagnes et vos réglages ne sont pas touchés.")) { Arreter 'Rien n''a changé.' }

# Les fichiers du gestionnaire, des deux côtés (chemins relatifs).
$extras = @('version.json', 'LISEZMOI.md')
$fichiersN = @(Fichiers-Gestionnaire $nouvelle) + @($extras | Where-Object { Test-Path (Join-Path $nouvelle $_) })
$fichiersA = @(Fichiers-Gestionnaire $install) + @($extras | Where-Object { Test-Path (Join-Path $install $_) })
$temoinN = Join-Path $nouvelle 'campagnes\temoin'
if ((Test-Path $temoinN) -and (Test-Path (Join-Path $install 'campagnes\temoin'))) {
    $fichiersN += @(Get-ChildItem $temoinN -Recurse -File | ForEach-Object { $_.FullName.Substring($nouvelle.Length + 1) } | Where-Object { $_ -notlike 'campagnes\temoin\etat\*' })
}
$hash = { param($f) (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash }
$extensionsChangees = @($fichiersN + $fichiersA | Where-Object { $_ -match '^extensions\\([^\\]+)\\' } | ForEach-Object {
    $a = Join-Path $install $_; $n = Join-Path $nouvelle $_
    if (-not (Test-Path $a) -or -not (Test-Path $n) -or (& $hash $a) -ne (& $hash $n)) { ($_ -split '\\')[1] }
} | Sort-Object -Unique)

# 1. Sauvegarde de l'ancienne version.
$sauvegarde = Join-Path $install "anciennes-versions\$avant-$(Get-Date -Format 'yyyyMMdd-HHmm')"
foreach ($rel in $fichiersA) {
    $dest = Join-Path $sauvegarde $rel
    New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
    Copy-Item -LiteralPath (Join-Path $install $rel) $dest
}
Write-Host "Ancienne version sauvegardée : $sauvegarde"

# 2. Les fichiers que la nouvelle version n'a plus, puis ceux qu'elle apporte.
$garder = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$fichiersN | ForEach-Object { [void]$garder.Add($_) }
$retires = @($fichiersA | Where-Object { -not $garder.Contains($_) })
foreach ($rel in $retires) { Remove-Item -LiteralPath (Join-Path $install $rel) -Force }
foreach ($rel in $fichiersN) {
    $dest = Join-Path $install $rel
    New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
    Copy-Item -LiteralPath (Join-Path $nouvelle $rel) $dest -Force
}
# Dossiers du gestionnaire restés vides après les retraits.
foreach ($d in $script:DossiersCode) {
    $base = Join-Path $install $d
    if (Test-Path $base) {
        Get-ChildItem $base -Recurse -Directory | Sort-Object { $_.FullName.Length } -Descending |
            Where-Object { -not (Get-ChildItem -LiteralPath $_.FullName -Force) } | ForEach-Object { Remove-Item -LiteralPath $_.FullName }
    }
}
Write-Host "$($fichiersN.Count) fichiers copiés, $($retires.Count) retirés."

# 3. La bibliothèque d'images de la campagne par défaut, à la racine jusqu'à la 1.0.0 : dans le dossier de la campagne.
$racineImages = Join-Path $install 'images-library'
if ((Test-Path $racineImages) -and -not $poste.bibliotheque) {
    $camp = Campagne-Choisie $install $poste ''
    $cible = Join-Path $camp.dossier 'images-library'
    if ($camp.id -and -not $camp.aLaRacine -and -not (Test-Path $cible)) {
        Move-Item -LiteralPath $racineImages $cible
        Write-Host "Bibliothèque d'images déplacée dans le dossier de la campagne « $($camp.id) » : $cible"
    } elseif ($camp.id -and -not $camp.aLaRacine) {
        Write-Host "La bibliothèque d'images est à la racine (images-library\), et la campagne « $($camp.id) » en a déjà une : réunissez-les à la main dans $cible." -ForegroundColor Yellow
    }
}

# 4. Vérification : le gestionnaire installé est bien la nouvelle version.
Write-Host ''
if ((Empreinte-Gestionnaire $install) -ne $vN.empreinte) {
    Write-Host "Mise à jour faite, mais le gestionnaire ne correspond pas exactement à la version $($vN.version) : la page dira « Gestionnaire modifié ». L'ancienne version est dans $sauvegarde." -ForegroundColor Yellow
    exit 1
}
Write-Host "Gestionnaire à jour : version $($vN.version)." -ForegroundColor Green
Write-Host 'Double-cliquez « Lancer le gestionnaire.cmd » dans votre gestionnaire : la version s''affiche en haut à droite.'
foreach ($e in $extensionsChangees) {
    Write-Host "L'extension extensions\$e a changé : dans Chrome, chrome://extensions, cliquez « Recharger » (flèche ronde) sur elle." -ForegroundColor Yellow
}
Write-Host 'Le dossier décompressé de la nouvelle version peut maintenant être supprimé.'
