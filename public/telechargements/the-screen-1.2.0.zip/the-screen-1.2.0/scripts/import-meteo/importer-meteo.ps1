﻿# Importe de la météo réelle d'une ville, depuis Open-Meteo (archives historiques, réanalyse ERA5 : gratuit, sans clé,
# licence CC BY 4.0), au format de data/meteo.json, type « releve » (formats/meteo.md) : quatre créneaux de six heures par
# jour (températures, ciel, précipitation, humidité, texte en français). Par défaut deux années civiles, du 1er janvier
# de -Annee au 31 décembre de l'année suivante (-Mois 1 -Annees 2 : 730 jours, sans 29 février). Le gestionnaire pose le
# relevé sur la campagne : la première année de la campagne prend la première année du relevé, jour pour jour, la
# deuxième la seconde, la troisième de nouveau la première.
# Usage : powershell -ExecutionPolicy Bypass -File .\importer-meteo.ps1 -Ville Tallinn -Annee 2009 [-Annees 2] [-Mois 1] [-Pays EE]
#         ... -Campagne <id> [-Remplacer]   écrit data/meteo.json de la campagne (refusé s'il existe, sans -Remplacer)
#         ... -Sortie <fichier>             écrit ailleurs (une météo fournie de modeles/meteos/, par exemple)
# Ensuite, dans la fenêtre Campagne (onglet « Campagne ») : Météo « Météo importée ».
# Lecture seule sur Open-Meteo : deux requêtes (la ville, puis la période heure par heure).
param(
    [Parameter(Mandatory = $true)][string]$Ville,
    [Parameter(Mandatory = $true)][int]$Annee,
    [ValidateRange(1, 12)][int]$Mois = 1,
    [ValidateRange(1, 5)][int]$Annees = 2,
    [string]$Pays = '',
    [string]$Nom = '',
    [string]$Campagne = '',
    [string]$Sortie = '',
    [switch]$Remplacer
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$utf8 = New-Object Text.UTF8Encoding $false
$racine = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))

if (-not $Sortie) {
    . (Join-Path $racine 'scripts\poste.ps1')
    . (Join-Path $racine 'scripts\campagnes.ps1')
    $c = Campagne-Choisie $racine (Lire-Poste $racine) $Campagne
    $Sortie = Join-Path $c.dossier 'data\meteo.json'
    if ((Test-Path $Sortie) -and -not $Remplacer) {
        Write-Host "La campagne « $($c.id) » a déjà une météo ($Sortie). Relancez avec -Remplacer pour l'écraser, ou -Sortie <fichier>." -ForegroundColor Red
        exit 1
    }
}
$debutReel = Get-Date -Year $Annee -Month $Mois -Day 1
$finReel = $debutReel.AddYears($Annees).AddDays(-1)
if ($Annee -lt 1940 -or $finReel -ge (Get-Date).Date.AddDays(-7)) { Write-Host "Période : de 1940 à la semaine dernière (archives d'Open-Meteo)." -ForegroundColor Red; exit 1 }

# ───── La ville ─────
$q = [uri]::EscapeDataString($Ville)
$geo = Invoke-RestMethod "https://geocoding-api.open-meteo.com/v1/search?name=$q&count=10&language=fr&format=json"
$lieux = @($geo.results | Where-Object { -not $Pays -or $_.country_code -eq $Pays })
if (-not $lieux.Count) { Write-Host "Ville introuvable : « $Ville »$(if ($Pays) { " ($Pays)" })." -ForegroundColor Red; exit 1 }
$lieu = $lieux[0]
Write-Host ("  {0} ({1}{2}) : {3}, {4}, fuseau {5}" -f $lieu.name, $(if ($lieu.admin1) { "$($lieu.admin1), " }), $lieu.country, $lieu.latitude, $lieu.longitude, $lieu.timezone)
if ($lieux.Count -gt 1) { Write-Host "  (autres villes de ce nom : $((@($lieux | Select-Object -Skip 1 | ForEach-Object { "$($_.name), $($_.country_code)" })) -join ' ; ') : précisez -Pays)" -ForegroundColor DarkGray }

# ───── La période, heure par heure ─────
$inv = [Globalization.CultureInfo]::InvariantCulture
$url = 'https://archive-api.open-meteo.com/v1/archive?latitude={0}&longitude={1}&start_date={2}&end_date={3}&hourly=temperature_2m,relative_humidity_2m,weather_code,cloud_cover&timezone={4}' -f `
    ([double]$lieu.latitude).ToString($inv), ([double]$lieu.longitude).ToString($inv), $debutReel.ToString('yyyy-MM-dd'), $finReel.ToString('yyyy-MM-dd'), [uri]::EscapeDataString($lieu.timezone)
$r = Invoke-RestMethod $url
$hh = $r.hourly
Write-Host "  $($hh.time.Count) heures relevées."

# Codes météo de l'OMS (WMO) : le texte, la précipitation (clé de types_precipitation) et l'ordre de gravité.
$TEXTES = @{ 0 = 'Ciel dégagé'; 1 = 'Quelques nuages'; 2 = 'Éclaircies'; 3 = 'Couvert'; 45 = 'Brouillard'; 48 = 'Brouillard givrant'
    51 = 'Bruine légère'; 53 = 'Bruine'; 55 = 'Bruine dense'; 56 = 'Bruine verglaçante'; 57 = 'Bruine verglaçante'
    61 = 'Pluie faible'; 63 = 'Pluie'; 65 = 'Forte pluie'; 66 = 'Pluie verglaçante'; 67 = 'Forte pluie verglaçante'
    71 = 'Neige faible'; 73 = 'Neige'; 75 = 'Forte neige'; 77 = 'Grains de neige'
    80 = 'Averses'; 81 = 'Averses'; 82 = 'Violentes averses'; 85 = 'Averses de neige'; 86 = 'Fortes averses de neige'
    95 = 'Orage'; 96 = 'Orage et grêle'; 99 = 'Orage et grêle' }
function PrecipitationDe([int]$code) {
    if ($code -in 51, 53, 55) { return 'bruine' }
    if ($code -in 56, 57, 66, 67) { return 'verglacante' }
    if ($code -in 61, 63, 65) { return 'pluie' }
    if ($code -in 80, 81, 82, 95, 96, 99) { return 'averses' }
    if ($code -in 71, 73, 77, 85) { return 'neige' }
    if ($code -in 75, 86) { return 'neige_forte' }
    return $null
}
$GRAVITE = @{ bruine = 1; pluie = 2; averses = 3; neige = 4; neige_forte = 5; verglacante = 6 }
$SOMBRE = @{ degage = 0; peu_nuageux = 1; nuageux = 2; couvert = 3; nuages_bas = 4; brouillard = 5 }
$TEXTES_CIEL = @{ degage = 'Ciel dégagé'; peu_nuageux = 'Quelques nuages'; nuageux = 'Nuageux'; couvert = 'Couvert'; brouillard = 'Brouillard' }
function CielDe([int]$code, $nuages) {
    if ($code -in 45, 48) { return 'brouillard' }
    $n = if ($null -eq $nuages) { 50 } else { [double]$nuages }
    if ($n -lt 20) { return 'degage' }
    if ($n -lt 50) { return 'peu_nuageux' }
    if ($n -lt 85) { return 'nuageux' }
    return 'couvert'
}
# Le plus fréquent d'une liste ; à égalité, le plus haut selon $ordre.
function LePlusFrequent($liste, $ordre) {
    return (@($liste) | Group-Object | Sort-Object @{ e = { $_.Count }; Descending = $true }, @{ e = { $ordre[$_.Name] }; Descending = $true } | Select-Object -First 1).Name
}
$arrondi = { param($x) [int][Math]::Round([double]$x, [MidpointRounding]::AwayFromZero) }

# Les heures, par jour (29 février écarté : le calendrier classique n'a pas d'année bissextile).
$parJour = [ordered]@{}
for ($i = 0; $i -lt $hh.time.Count; $i++) {
    $t = [string]$hh.time[$i]
    $date = $t.Substring(0, 10)
    if ($date.EndsWith('-02-29')) { continue }
    if ($null -eq $hh.temperature_2m[$i]) { continue }
    if (-not $parJour.Contains($date)) { $parJour[$date] = New-Object Collections.Generic.List[object] }
    $code = if ($null -eq $hh.weather_code[$i]) { 0 } else { [int]$hh.weather_code[$i] }
    $parJour[$date].Add([pscustomobject]@{ heure = [int]$t.Substring(11, 2); temp = [double]$hh.temperature_2m[$i]; hum = $hh.relative_humidity_2m[$i]; code = $code; ciel = (CielDe $code $hh.cloud_cover[$i]); precip = (PrecipitationDe $code) })
}

$DEFS_CRENEAUX = @(@('nuit', '00:00', '06:00', 0), @('matin', '06:00', '12:00', 6), @('apres-midi', '12:00', '18:00', 12), @('soir', '18:00', '24:00', 18))
$OU = @{ nuit = 'la nuit'; matin = 'le matin'; 'apres-midi' = "l'après-midi"; soir = 'le soir' }
$degres = { param($n) if ($n -lt 0) { "−$([Math]::Abs($n))" } else { "$n" } }
$jours = New-Object Collections.Generic.List[object]
foreach ($date in $parJour.Keys) {
    $heures = $parJour[$date]
    $creneaux = New-Object Collections.Generic.List[object]
    foreach ($def in $DEFS_CRENEAUX) {
        $hs = @($heures | Where-Object { $_.heure -ge $def[3] -and $_.heure -lt $def[3] + 6 })
        if (-not $hs.Count) { continue }
        $ciel = LePlusFrequent ($hs | ForEach-Object { $_.ciel }) $SOMBRE
        $avecPrecip = @($hs | Where-Object { $_.precip })
        $precip = $null
        if ($avecPrecip.Count -ge 2) { $precip = LePlusFrequent ($avecPrecip | ForEach-Object { $_.precip }) $GRAVITE }
        if ($precip) {
            $codes = @{}; foreach ($x in $avecPrecip | Where-Object { $_.precip -eq $precip }) { $codes[[string]$x.code] = $x.code }
            $code = [int](LePlusFrequent (@($avecPrecip | Where-Object { $_.precip -eq $precip }) | ForEach-Object { [string]$_.code }) $codes)
            $texte = $TEXTES[$code] + $(if ($ciel -eq 'brouillard') { ', brouillard' } else { '' })
        } elseif ($ciel -eq 'brouillard') {
            $texte = if (@($hs | Where-Object { $_.code -eq 48 }).Count -gt @($hs | Where-Object { $_.code -eq 45 }).Count) { 'Brouillard givrant' } else { 'Brouillard' }
        } else { $texte = $TEXTES_CIEL[$ciel] }
        $hum = @($hs | Where-Object { $null -ne $_.hum } | ForEach-Object { [double]$_.hum })
        $codesVus = (@($hs | ForEach-Object { $_.code } | Select-Object -Unique) -join ', ')
        $creneaux.Add([ordered]@{
            creneau = $def[0]; debut = $def[1]; fin = $def[2]
            max = (& $arrondi ($hs | Measure-Object temp -Maximum).Maximum); min = (& $arrondi ($hs | Measure-Object temp -Minimum).Minimum)
            ciel = $ciel; precipitation = $precip; texte = $texte
            humidite = $(if ($hum.Count) { & $arrondi (($hum | Measure-Object -Average).Average) } else { $null })
            releve = "Open-Meteo, codes WMO $codesVus"
        })
    }
    if ($creneaux.Count -ne 4) { continue }   # journée incomplète : laissée de côté
    $min = (@($creneaux | ForEach-Object { $_.min }) | Measure-Object -Minimum).Minimum
    $max = (@($creneaux | ForEach-Object { $_.max }) | Measure-Object -Maximum).Maximum
    $cielJour = LePlusFrequent (@($creneaux | Where-Object { $_.creneau -in 'matin', 'apres-midi' }) | ForEach-Object { $_.ciel }) $SOMBRE
    $precips = @($creneaux | Where-Object { $_.precipitation } | ForEach-Object { $_.precipitation } | Select-Object -Unique)
    # Résumé : ce qui tombe ou masque la vue, créneau par créneau, un même temps sur des créneaux qui se suivent réuni
    # (« neige faible le matin et l'après-midi ») ; sinon le ciel du jour.
    $groupes = New-Object Collections.Generic.List[object]
    foreach ($c in $creneaux) {
        $t = if ($c.precipitation -or $c.ciel -eq 'brouillard') { $c.texte.ToLower() } else { $null }
        if ($groupes.Count -and $groupes[$groupes.Count - 1].texte -eq $t) { $groupes[$groupes.Count - 1].ou.Add($OU[$c.creneau]) }
        else { $g = [pscustomobject]@{ texte = $t; ou = (New-Object Collections.Generic.List[string]) }; $g.ou.Add($OU[$c.creneau]); $groupes.Add($g) }
    }
    $morceaux = @($groupes | Where-Object { $_.texte } | ForEach-Object { "$($_.texte) $(if ($_.ou.Count -eq 4) { 'toute la journée' } else { $_.ou -join ' et ' })" })
    $debut = if ($morceaux.Count) { $morceaux -join ' ; ' } else { $TEXTES_CIEL[$cielJour].ToLower() }
    $temp = if ($min -eq $max) { "$(& $degres $max) °C" } else { "$(& $degres $min) à $(& $degres $max) °C" }
    $jours.Add([ordered]@{
        date_reelle = $date; min = $min; max = $max; gel = ($min -le 0); ciel = $cielJour
        precipitations = $precips
        resume = "$($debut.Substring(0, 1).ToUpper())$($debut.Substring(1)). $temp."
        creneaux = $creneaux.ToArray()
    })
}
Write-Host "  $($jours.Count) jours complets."

$sortieObj = [ordered]@{
    schema = 2; jeu = 'meteo'; type = 'releve'
    titre = "Météo réelle : $(if ($Nom) { $Nom } else { "$($lieu.name) ($($lieu.country))" }), $($debutReel.ToString('MM/yyyy')) à $($finReel.ToString('MM/yyyy'))"
    genere_le = (Get-Date).ToString('yyyy-MM-dd')
    avertissement = 'Écrit par scripts/import-meteo/importer-meteo.ps1 depuis Open-Meteo : ne pas modifier à la main, relancer l''import. Format : formats/meteo.md (relevé réel).'
    sources = [ordered]@{ releve = [ordered]@{ nom = 'Open-Meteo, archives météo historiques (réanalyse ERA5 du Copernicus Climate Change Service)'; url = 'https://open-meteo.com/'; licence = 'CC BY 4.0' } }
    lieu = [ordered]@{ nom = $lieu.name; region = $lieu.admin1; pays = $lieu.country; latitude = $lieu.latitude; longitude = $lieu.longitude; fuseau = $lieu.timezone }
    debut_reel = $debutReel.ToString('yyyy-MM-dd'); fin_reelle = $finReel.ToString('yyyy-MM-dd')
    creneaux = @($DEFS_CRENEAUX | ForEach-Object { [ordered]@{ id = $_[0]; debut = $_[1]; fin = $_[2] } })
    unites = [ordered]@{ temperature = '°C'; humidite = '%' }
    types_ciel = [ordered]@{ degage = @{ nom = 'Dégagé' }; peu_nuageux = @{ nom = 'Peu nuageux' }; nuageux = @{ nom = 'Nuageux' }; couvert = @{ nom = 'Couvert' }; nuages_bas = @{ nom = 'Nuages bas' }; brouillard = @{ nom = 'Brouillard' } }
    types_precipitation = [ordered]@{ bruine = 'Bruine'; pluie = 'Pluie'; averses = 'Averses'; verglacante = 'Pluie verglaçante'; neige = 'Neige'; neige_forte = 'Forte neige' }
    jours = $jours.ToArray()
}
New-Item -ItemType Directory -Force -Path (Split-Path $Sortie) | Out-Null
[IO.File]::WriteAllText($Sortie, (ConvertTo-Json -InputObject $sortieObj -Depth 10 -Compress) + "`n", $utf8)
Write-Host "  Écrit : $Sortie" -ForegroundColor Cyan
