﻿# Télécharge les images d'un livre de D&D Beyond listées dans un fichier (une par ligne : page|carte (0/1)|url|libellé),
# relevé par l'extension du MJ (fenêtre Campagne, « Relever le livre ») ou par 1-collecter-urls.js.
# Usage : powershell -ExecutionPolicy Bypass -File .\2-telecharger-images.ps1 -List <fichier> -OutDir <dossier>
# En général lancé par scripts/import-images/importer-images.ps1 (fenêtre Campagne, ou « outils/Importer les images.cmd »).
# Cartes -> "<OutDir>\Cartes\<page> - <nom>", autres images -> "<OutDir>\Illustrations\<page>\<nom>".
# Relancer le script reprend là où il s'était arrêté (les fichiers existants sont ignorés).
param(
    [Parameter(Mandatory)][string]$List,
    [Parameter(Mandatory)][string]$OutDir,
    [int]$MinDelayMs = 1000,
    [int]$MaxDelayMs = 2500
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # sinon Invoke-WebRequest est très lent en PS 5.1
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$lines = @(Get-Content -Encoding UTF8 $List | Where-Object { $_.Trim() -and -not $_.StartsWith('#') })
$i = 0; $ok = 0; $skipped = 0; $failed = @()
foreach ($line in $lines) {
    $i++
    $chapter, $isMap, $url, $label = $line.Split('|')
    if ($url -notmatch '^https?://') { Write-Warning "  ligne illisible : $line"; continue }
    $name = [Uri]::UnescapeDataString(([Uri]$url).Segments[-1])
    # Les pièces jointes ont souvent des noms peu parlants (carte-03, 022.jpg) : on prend le libellé.
    if ($url -match '/attachments/' -and $label -and $label -notmatch 'View') { $name = ($label -replace '[^\w\.-]+', '-').ToLower() + [IO.Path]::GetExtension($name) }

    if ($isMap -eq '1') {
        $dir = Join-Path $OutDir 'Cartes'
        $name = "$chapter - $name"
    } else {
        $dir = Join-Path (Join-Path $OutDir 'Illustrations') $chapter
    }
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $target = Join-Path $dir $name
    if (Test-Path $target) { $skipped++; continue }

    Write-Host "  [$i/$($lines.Count)] $name"
    try {
        Invoke-WebRequest -Uri $url -OutFile $target -UseBasicParsing
        $ok++
    } catch {
        $status = $_.Exception.Response.StatusCode.value__
        Write-Warning "  échec ($status) : $url"
        $failed += $url
        if (Test-Path $target) { Remove-Item $target }
        if ($status -eq 429) { Write-Warning '  429 : pause de 2 minutes'; Start-Sleep -Seconds 120 }
    }
    Start-Sleep -Milliseconds (Get-Random -Minimum $MinDelayMs -Maximum $MaxDelayMs)
}

Write-Host "  Terminé : $ok téléchargées, $skipped déjà présentes, $($failed.Count) échecs."
if ($failed.Count) { $failed | Set-Content -Encoding UTF8 (Join-Path $OutDir 'echecs.txt') }
