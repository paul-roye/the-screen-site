// Secours, sans l'extension du MJ (qui fait le même relevé : fenêtre Campagne, « Relever le livre ») :
// à coller dans la console du navigateur (F12 > Console), connecté à D&D Beyond,
// depuis la page d'accueil du livre (table des matières), par ex. :
//   https://www.dndbeyond.com/sources/dnd/<livre>
// Le script parcourt chaque chapitre lentement (4 à 8 s entre les pages),
// relève les URL des images (en privilégiant les versions pleine taille et
// les « Player Version » des cartes) puis télécharge un fichier images-livre.txt,
// à ranger sous le nom .liste-beyond.txt dans le dossier de la source (bibliothèque de la campagne).
(async () => {
  const MIN_DELAY = 4000, MAX_DELAY = 8000;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const imgRe = /\.(jpe?g|png|webp|gif)(\?.*)?$/i;

  // La page d'accueil est /sources/dnd/<livre>, mais les chapitres sont sous /sources/<livre>/
  const book = location.pathname.match(/^\/sources\/(?:dnd\/)?([^/]+)\/?$/);
  if (!book) { console.error('Ouvrez la page d\'accueil du livre (/sources/dnd/...) avant de lancer le script.'); return; }

  const pages = [...new Set([location.href, ...[...document.querySelectorAll(`a[href*="/sources/${book[1]}/"]`)]
    .map(a => a.href)].map(u => u.split('#')[0].split('?')[0]))];
  console.log(`${pages.length} pages à parcourir`);

  const found = new Map(); // url -> { url, page, label, isMap }
  let previous = null;
  const add = (url, page, label) => {
    if (!url || !imgRe.test(url) || found.has(url)) return;
    label = (label || '').trim().replace(/\s+/g, ' ');
    const file = url.split('/').pop();
    const isPlayer = /player version/i.test(label) || /-player\./i.test(file);
    // Une « Player Version » suit toujours la carte du MJ, même quand celle-ci a un nom peu parlant
    if (isPlayer && previous) previous.isMap = true;
    previous = { url, page, label, isMap: isPlayer || /(^|[-.])map/i.test(file) };
    found.set(url, previous);
  };

  for (const [i, pageUrl] of pages.entries()) {
    const slug = String(i).padStart(2, '0') + '-' + (i ? pageUrl.split('/').filter(Boolean).pop() : 'accueil');
    console.log(`[${i + 1}/${pages.length}] ${slug}`);
    let res;
    try { res = await fetch(pageUrl, { credentials: 'include' }); }
    catch (e) { console.warn('  erreur réseau, page ignorée', e); continue; }
    if (res.status === 429) { console.warn('  429 (trop de requêtes) : pause de 2 min puis arrêt'); await sleep(120000); break; }
    if (!res.ok) { console.warn(`  HTTP ${res.status}, page ignorée`); continue; }

    const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
    const root = doc.querySelector('.p-article-content, .compendium-content, article, main') || doc.body;
    const abs = href => { try { return new URL(href, pageUrl).href; } catch { return null; } };

    // 1) Liens vers des images : en général la version pleine résolution
    //    (clic sur une illustration, « View Player Version » des cartes, etc.)
    root.querySelectorAll('a[href]').forEach(a => {
      const img = a.querySelector('img');
      add(abs(a.getAttribute('href')), slug, a.textContent || img?.alt || a.title);
    });
    // 2) Images affichées qui ne sont pas déjà dans un lien pleine taille
    root.querySelectorAll('img').forEach(img => {
      const link = img.closest('a[href]');
      if (link && imgRe.test(link.getAttribute('href'))) return;
      const src = img.getAttribute('data-src') || img.getAttribute('src');
      add(abs(src), slug, img.alt || img.title);
    });

    console.log(`  total : ${found.size} images`);
    if (i < pages.length - 1) await sleep(MIN_DELAY + Math.random() * (MAX_DELAY - MIN_DELAY));
  }

  const list = [...found.values()];
  console.log(`Terminé : ${list.length} images, dont ${list.filter(x => x.isMap).length} cartes probables`);
  // Format attendu par 2-telecharger-images.ps1 : chapitre|carte (0/1)|url|libellé
  const txt = list.map(x => [x.page, x.isMap ? 1 : 0, x.url, x.label.replace(/\|/g, '/')].join('|')).join('\n');
  const blob = new Blob([txt], { type: 'text/plain' });
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: 'images-livre.txt' });
  document.body.appendChild(a); a.click(); a.remove();
})();
