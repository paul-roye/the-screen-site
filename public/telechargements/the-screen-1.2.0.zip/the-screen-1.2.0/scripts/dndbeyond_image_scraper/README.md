# Images D&D Beyond

Les images d'un livre possédé sur D&D Beyond (cartes MJ et joueurs en haute définition, illustrations, handouts), pour la bibliothèque d'images d'une campagne : une source `beyond` de son manifeste (`formats/images.md`, « Sources d'images »). En temps normal, tout se fait depuis le gestionnaire (fenêtre Campagne, onglet « Images ») : « Relever le livre » fait relever la liste par l'extension du MJ, puis le téléchargement suit (`scripts/import-images/importer-images.ps1`).

- `2-telecharger-images.ps1 -List <liste> -OutDir <dossier>` : télécharge les images de la liste (une ligne par image : `page|carte (0/1)|url|libellé`), une toutes les 1 à 2,5 s : `Cartes\` d'un côté, `Illustrations\<page>\` de l'autre. Relancer reprend là où il s'était arrêté.
- `listes/<livre>.txt` : listes fournies avec le gestionnaire, prises quand le livre n'a pas encore été relevé sur le poste (`<livre>` : la fin de l'adresse du livre). `cos.txt` : *Curse of Strahd* (222 images, 64 cartes), relevée le 2026-10-09.
- `1-collecter-urls.js` : le même relevé que l'extension, en secours : connecté à D&D Beyond, ouvrir la page d'accueil du livre, coller le script dans la console (F12). Il télécharge `images-livre.txt`, à ranger sous le nom `.liste-beyond.txt` dans le dossier de la source.

Les images servies par `media.dndbeyond.com` et `www.dndbeyond.com/attachments` ne demandent pas de connexion : seul le relevé a besoin du compte.
