﻿# Import de la musique d'ambiance : lit musique/sources.json (playlists YouTube, exclusions, étiquettes et mots-clés)
# et écrit musique/pistes.json, lu par le widget Musique. Format des deux fichiers : formats/musique.md.
# Lecture seule de YouTube, comme la page web d'une playlist (API interne youtubei, sans clé ni compte) : une requête
# par page de playlist (100 vidéos), puis une par vidéo nouvelle pour sa durée (les durées connues sont reprises).
# Code de sortie : 0 réussi, 1 échec (rien n'est modifié).
# Une musique par campagne : -Campagne <id> (campagnes/<id>/, formats/campagne.md ; par défaut celle de lancer.ps1) donne
# les dossiers musique/, data/ et etat/ ; les chemins passés en paramètre l'emportent.

param(
  [string]$Campagne = '',
  [string]$Sources = '',
  [string]$Sortie = '',
  # Les PNJ de la campagne (lieu où on les croise), pour donner un lieu aux pistes d'un PNJ qui n'en ont pas.
  [string]$Pnj = '',
  # L'état du widget : ses retouches d'étiquettes (corrections), qu'il applique lui-même ; l'import signale celles qui ne
  # visent plus rien.
  [string]$Etat = ''
)

$ErrorActionPreference = 'Stop'
$racineGestionnaire = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
. (Join-Path $racineGestionnaire 'scripts\poste.ps1')
. (Join-Path $racineGestionnaire 'scripts\campagnes.ps1')
$dossierCampagne = (Campagne-Choisie $racineGestionnaire (Lire-Poste $racineGestionnaire) $Campagne).dossier
if (-not $Sources) { $Sources = Join-Path $dossierCampagne 'musique\sources.json' }
if (-not $Sortie) { $Sortie = Join-Path $dossierCampagne 'musique\pistes.json' }
if (-not $Pnj) { $Pnj = Join-Path $dossierCampagne 'data\pnj.json' }
if (-not $Etat) { $Etat = Join-Path $dossierCampagne 'etat\musique.json' }
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$utf8 = New-Object Text.UTF8Encoding $false
$CLIENT = @{ clientName = 'WEB'; clientVersion = '2.20250101.00.00'; hl = 'en'; gl = 'US' }

function Appeler([string]$point, [hashtable]$corps) {
  $corps.context = @{ client = $CLIENT }
  $json = $corps | ConvertTo-Json -Depth 6 -Compress
  $r = Invoke-WebRequest -UseBasicParsing -Method Post -Uri "https://www.youtube.com/youtubei/v1/$($point)?prettyPrint=false" `
    -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 30
  [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
}

# Chaîne JSON relevée par une expression régulière (avec ses \" et é) : la décoder.
function Decoder([string]$s) { if (-not $s) { return '' }; return ('"' + $s + '"' | ConvertFrom-Json) }
$CHAINE = '((?:[^"\\]|\\.)*)'

# Les vidéos d'une playlist, dans l'ordre : { id, titre }, et le titre de la playlist.
function LirePlaylist([string]$liste) {
  $t = Appeler 'browse' @{ browseId = "VL$liste" }
  $titre = Decoder ([regex]::Match($t, '"pageHeaderViewModel":\{"title":\{"dynamicTextViewModel":\{"text":\{"content":"' + $CHAINE + '"').Groups[1].Value)
  $videos = New-Object System.Collections.Generic.List[object]
  for ($page = 1; $page -le 20; $page++) {
    foreach ($m in ($t -split '"lockupViewModel":\{' | Select-Object -Skip 1)) {
      $id = [regex]::Match($m, '"contentId":"([\w-]{11})"').Groups[1].Value
      $nom = Decoder ([regex]::Match($m, '"lockupMetadataViewModel":\{"title":\{"content":"' + $CHAINE + '"').Groups[1].Value)
      if ($id -and $nom) { $videos.Add([pscustomobject]@{ id = $id; titre = $nom }) }
    }
    $suite = [regex]::Match($t, '"continuationItemRenderer":\{"trigger":"CONTINUATION_TRIGGER_ON_ITEM_SHOWN","continuationEndpoint":\{.*?"continuationCommand":\{"token":"([^"]+)"').Groups[1].Value
    if (-not $suite) { break }
    $t = Appeler 'browse' @{ continuation = $suite }
  }
  return @{ titre = $titre; videos = $videos }
}

# Titre et durée (secondes) d'une vidéo.
function InfosVideo([string]$id) {
  $t = Appeler 'player' @{ videoId = $id }
  $s = [regex]::Match($t, '"lengthSeconds":"(\d+)"').Groups[1].Value
  Start-Sleep -Milliseconds 150
  return @{
    titre = Decoder ([regex]::Match($t, '"videoDetails":\{.*?"title":"' + $CHAINE + '"').Groups[1].Value)
    duree = $(if ($s) { [int]$s } else { $null })
  }
}

# Nom court : le titre sans ce que les chaînes répètent partout (« Unofficial … Soundtrack », « 1h Loop »,
# « NO AI »…). « Aurval - March of the Dead | Aurval Soundtrack | TTRPG / DnD Music [No-AI] » → « Aurval · March of the Dead ».
# Le premier morceau est le nom de la piste : gardé, sauf s'il nomme la campagne (`bruit` de sources.json : les noms de
# l'aventure que les titres répètent, « Music inspired by … »)
# ou le genre de la playlist (« Low Intensity Combat Music | Forest Skirmish » → « Forest Skirmish »).
$BRUIT = 'soundtrack|\bost\b|ttrpg|d&d|\bdnd\b|no[- ]?ai|\bloop\b|\bmusic\b|^1 ?h\b|1 hour|fan content|\bbonus\b|short theme|^ep$|full album|unreleased tracks|creative commons|\bcc by|royalty|fabomusic|pathfinder|^unofficial |tabletop|full ep|orcish shouts|growls|^orcs$'
$GENRE = '^(low(/mid)? intensity combat( music)?|combat music|(celtic & )?elven music|epic (d&d |dwarven )?battle music( mix)?|tabletop.*)$'
function NomCourt([string]$titre) {
  $t = $titre -replace '\[[^\]]*\]', '' -replace '\((?:[^)]*(?:loop|1h|alesmag|cc by)[^)]*)\)', ''
  $morceaux = @($t -split '\s+[|\-–]\s+|\s*\|\s*' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
  $gardes = for ($i = 0; $i -lt $morceaux.Count; $i++) {
    $m = $morceaux[$i]
    if ($i -eq 0 -and $m -notmatch "$CAMPAGNE$GENRE") { $m -replace '\s+background music$', '' -replace '^1[- ]hour ', '' }
    elseif ($m -notmatch "$BRUIT|$CAMPAGNE$GENRE") { $m }
  }
  $nom = (@($gardes) -join ' · ').Trim()
  if ($nom) { return $nom } else { return $titre.Trim() }
}

try {
  $src = [IO.File]::ReadAllText((Resolve-Path $Sources), $utf8) | ConvertFrom-Json
  # Les noms de l'aventure que les titres répètent (`bruit`, facultatif), en motifs suivis d'un « | », devant $GENRE.
  $CAMPAGNE = (@($src.bruit) | Where-Object { $_ } | ForEach-Object { [regex]::Escape([string]$_) + '|' }) -join ''
  $ordre = @{}; $i = 0
  foreach ($e in $src.etiquettes) { $ordre[$e.id] = $i++ }
  $regles = foreach ($r in $src.regles) { [pscustomobject]@{ motif = [regex]::new($r.motif, 'IgnoreCase'); etiquettes = @($r.etiquettes) } }
  $ajustes = @{}
  if ($src.pistes) { foreach ($p in $src.pistes.PSObject.Properties) { $ajustes[$p.Name] = $p.Value } }

  # Durées (et titres des thèmes) déjà connues : reprises de l'import précédent.
  $connues = @{}
  $themesConnus = @{}
  if (Test-Path $Sortie) {
    try {
      $avant = [IO.File]::ReadAllText((Resolve-Path $Sortie), $utf8) | ConvertFrom-Json
      foreach ($p in $avant.pistes) { if ($p.duree) { $connues[$p.id] = [int]$p.duree } }
      foreach ($t in @($avant.themes)) { if ($t.video -and $t.titre) { $themesConnus[$t.video] = @{ titre = $t.titre; duree = $t.duree } } }
    } catch { }
  }

  $avertissements = New-Object System.Collections.Generic.List[string]

  # Thèmes : la campagne (début et fin de séance) et chaque héros (pj:<id de personnages.json>), sans boucle dans le widget.
  $themes = New-Object System.Collections.Generic.List[object]
  foreach ($t in @($src.themes)) {
    if (-not $t) { continue }
    $th = [ordered]@{ id = $t.id }
    if ($t.nom) { $th.nom = $t.nom }
    if ($t.icone) { $th.icone = $t.icone }
    $th.video = $null
    if ($t.video) {
      if ($t.video -notmatch '^[\w-]{11}$') { $avertissements.Add("Thème $($t.id) : « $($t.video) » n'est pas un identifiant de vidéo YouTube (11 caractères, après watch?v=)."); $themes.Add($th); continue }
      $infos = $themesConnus[$t.video]
      if (-not $infos) { $infos = InfosVideo $t.video }
      if (-not $infos.titre) { $avertissements.Add("Thème $($t.id) : vidéo $($t.video) introuvable sur YouTube.") }
      $th.video = $t.video; $th.titre = $infos.titre; $th.duree = $infos.duree
    }
    $themes.Add($th)
  }
  # Lieu où l'on croise chaque PNJ (data/pnj.json, facultatif) : une piste d'un PNJ sans lieu reçoit le sien.
  $lieuPnj = @{}
  if ($Pnj -and (Test-Path $Pnj)) {
    try { foreach ($p in ([IO.File]::ReadAllText((Resolve-Path $Pnj), $utf8) | ConvertFrom-Json).pnj) { if ($p.lieu) { $lieuPnj[$p.id] = $p.lieu } } }
    catch { $avertissements.Add("PNJ illisibles ($Pnj) : les pistes des PNJ ne reçoivent pas de lieu.") }
  }

  # Une vidéo présente dans plusieurs playlists n'est gardée qu'une fois, dans la première : les suivantes vont dans
  # « aussi » et lui donnent leurs étiquettes. Les étiquettes se posent une fois toutes les playlists lues.
  $vues = @{}
  $listes = New-Object System.Collections.Generic.List[object]
  $pistes = New-Object System.Collections.Generic.List[object]
  foreach ($pl in $src.playlists) {
    $libelle = (@($pl.auteur, $pl.nom) | Where-Object { $_ }) -join ' · '
    Write-Host "Playlist $libelle…"
    $lu = LirePlaylist $pl.id
    if (-not $lu.videos.Count) { throw "Aucune vidéo lue dans la playlist $libelle ($($pl.id)) : YouTube a peut-être changé sa page." }
    $exclues = @{}
    foreach ($x in @($pl.exclure)) { if ($x) { $exclues[$x.id] = $true } }
    foreach ($x in $exclues.Keys) { if (-not ($lu.videos | Where-Object id -eq $x)) { $avertissements.Add("Exclusion sans effet : $x n'est plus dans la playlist $libelle.") } }
    $gardees = 0
    $lues = @{}
    foreach ($v in $lu.videos) {
      if ($exclues[$v.id] -or $lues[$v.id]) { continue }
      $lues[$v.id] = $true
      $gardees++
      $deja = $vues[$v.id]
      if ($deja) {
        if ($deja.source -ne $pl.id -and -not $deja.aussi.Contains($pl.id)) { $deja.aussi.Add($pl.id) }
        continue
      }
      $duree = $connues[$v.id]
      if (-not $duree) { $duree = (InfosVideo $v.id).duree }
      $piste = [ordered]@{ id = $v.id; nom = (NomCourt $v.titre); titre = $v.titre; duree = $duree; source = $pl.id; aussi = (New-Object System.Collections.Generic.List[string]); etiquettes = @() }
      $vues[$v.id] = $piste
      $pistes.Add($piste)
    }
    $s = [ordered]@{ id = $pl.id; nom = $pl.nom }
    if ($pl.auteur) { $s.auteur = $pl.auteur }
    $s.titre = $lu.titre; $s.pistes = $gardees
    if ($pl.qualite) { $s.qualite = $pl.qualite }
    $listes.Add($s)
    Write-Host "  $($lu.videos.Count) vidéos, $gardees gardées."
  }
  foreach ($id in $ajustes.Keys) { if (-not $vues[$id]) { $avertissements.Add("Réglage de piste sans effet : $id n'est dans aucune playlist.") } }
  $retouches = $null
  if ($Etat -and (Test-Path $Etat)) { try { $retouches = ([IO.File]::ReadAllText((Resolve-Path $Etat), $utf8) | ConvertFrom-Json).corrections } catch { } }
  if ($retouches) {
    foreach ($p in $retouches.PSObject.Properties) {
      if (-not $vues[$p.Name]) { $avertissements.Add("Retouche du widget sans effet : $($p.Name) n'est dans aucune playlist (etat/musique.json).") }
      foreach ($e in @($p.Value.ajouter)) { if ($e -and -not $ordre.ContainsKey($e)) { $avertissements.Add("Retouche du widget : étiquette « $e » qui n'existe plus ($($p.Name), etat/musique.json).") } }
    }
  }

  # Étiquettes : les règles (titre YouTube), celles des playlists, les ajouts de la piste ; puis le lieu de ses PNJ si
  # elle n'en a aucun ; enfin les retraits de la piste.
  $etiquettesListe = @{}
  foreach ($pl in $src.playlists) { $etiquettesListe[$pl.id] = @($pl.etiquettes | Where-Object { $_ }) }
  foreach ($piste in $pistes) {
    $tags = New-Object System.Collections.Generic.List[string]
    $poser = { param($e) if ($e -and -not $tags.Contains($e)) { $tags.Add($e) } }
    foreach ($r in $regles) { if ($r.motif.IsMatch($piste.titre)) { foreach ($e in $r.etiquettes) { & $poser $e } } }
    foreach ($l in @($piste.source) + @($piste.aussi)) { foreach ($e in $etiquettesListe[$l]) { & $poser $e } }
    $aj = $ajustes[$piste.id]
    if ($aj) { foreach ($e in @($aj.ajouter)) { & $poser $e } }
    if (-not ($tags | Where-Object { $_ -like 'lieu:*' })) {
      foreach ($e in @($tags | Where-Object { $_ -like 'pnj:*' })) { $l = $lieuPnj[$e.Substring(4)]; if ($l) { & $poser "lieu:$l" } }
    }
    if ($aj) {
      foreach ($e in @($aj.retirer)) { if ($e) { [void]$tags.Remove($e) } }
      if ($aj.nom) { $piste.nom = $aj.nom }
      if ($aj.note) { $piste.note = $aj.note }
    }
    foreach ($e in $tags) { if (-not $ordre.ContainsKey($e)) { $avertissements.Add("Étiquette inconnue « $e » ($($piste.titre)) : à déclarer dans etiquettes.") } }
    $piste.etiquettes = @($tags | Sort-Object { if ($ordre.ContainsKey($_)) { $ordre[$_] } else { 99999 } })
    if ($piste.aussi.Count) { $piste.aussi = @($piste.aussi) } else { $piste.Remove('aussi') }
  }

  # Une piste par ligne : un nouvel import se relit facilement dans git.
  $compact = { param($o) (ConvertTo-Json -InputObject $o -Depth 5 -Compress) -replace '\\u0027', "'" -replace '\\u0026', '&' -replace '\\u003c', '<' -replace '\\u003e', '>' }
  $etiquettes = foreach ($e in $src.etiquettes) {
    $x = [ordered]@{ id = $e.id; nom = $e.nom }
    if ($e.groupe) { $x.groupe = $e.groupe }
    $x.pistes = @($pistes | Where-Object { $_.etiquettes -contains $e.id }).Count
    $x
  }
  $texte = "{`n" +
    "  `"schema`": 1,`n  `"jeu`": `"musique`",`n  `"titre`": `"Musique d'ambiance`",`n" +
    "  `"genere_le`": `"$(Get-Date -Format 'yyyy-MM-ddTHH:mm:ss')`",`n" +
    "  `"avertissement`": `"Écrit par scripts/import-musique/importer-musique.ps1 depuis musique/sources.json : ne pas modifier à la main. Format : formats/musique.md.`",`n" +
    "  `"sources`": [`n" + (($listes | ForEach-Object { '    ' + (& $compact $_) }) -join ",`n") + "`n  ],`n" +
    "  `"themes`": [`n" + (($themes | ForEach-Object { '    ' + (& $compact $_) }) -join ",`n") + "`n  ],`n" +
    "  `"etiquettes`": [`n" + (($etiquettes | ForEach-Object { '    ' + (& $compact $_) }) -join ",`n") + "`n  ],`n" +
    "  `"pistes`": [`n" + (($pistes | ForEach-Object { '    ' + (& $compact $_) }) -join ",`n") + "`n  ]`n}`n"
  $null = $texte | ConvertFrom-Json   # vérifie que le fichier se relit
  $cible = [IO.Path]::GetFullPath($Sortie)
  [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($cible)) | Out-Null
  [IO.File]::WriteAllText("$cible.tmp", $texte, $utf8)
  Move-Item -Force "$cible.tmp" $cible

  $sans = @($pistes | Where-Object { -not ($_.etiquettes | Where-Object { $_ -like 'theme:*' }) })
  Write-Host "`n$($pistes.Count) pistes écrites dans $cible."
  if ($sans.Count) { Write-Host "Sans thème ($($sans.Count)) : $(($sans | ForEach-Object nom) -join ' ; ')" }
  foreach ($a in $avertissements) { Write-Warning $a }
  exit 0
} catch {
  Write-Host "Échec de l'import : $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
