// Faire passer le temps : attente, repos, trajet (widgets Horloge et Trajets).
// - Une heure au plus : un dialogue propose le test de rencontre si les héros sont dehors, puis le temps passe d'un coup.
// - Plus long (trajet, repos long, longue attente) dehors : une activité en cours (etat/horloge.json, activites[]), menée
//   heure par heure depuis le widget Horloge. Entre deux heures, on ajoute le temps d'une pause, d'un repos court, d'un combat ;
//   « Jusqu'à la prochaine rencontre » enchaîne les heures et s'arrête dès qu'il se passe quelque chose.
// Chaque heure pleine passée dehors (route ou nature, terrain de etat/rencontres.json) donne un test de rencontre, au milieu
// de cette heure, sur la table de jour ou de nuit (app/rencontres-moteur.js) ; sauf pour une activité « sans aléatoires »
// (`sans_aleatoires`, choisi au départ d'un trajet ou en route : seules les rencontres prévues de la route, que la fenêtre
// du trajet liste).

import { h, icone, bouton, alerte, alerteRepliable, pastilleDD, badge, bascule, identifiant, boutonMenu, FINE } from './ui.js';
import {
  etatHorloge, horlogeEnService, maintenant, enMinutes, depuisMinutes, libelleMoment, libelleDuree, lecture,
  MOMENTS_LIBELLES, tableRencontres, changer, avancer, enHHMM, depuisHHMM, annoncer, REPOS_LONG, REPOS_COURT,
  arrondiHeure, sansReposLong, VEILLE_MAX, reglagesDe, jusqua, libelleHeure, annuler, retourDe,
} from './horloge.js';
import { etatRencontres, moteurRencontres, chargerExternes, TERRAINS, terrainDuLieu } from './rencontres-moteur.js';
import { chargerLieux, nomLieu, etatIci, arriverA, noterTrajet, nettoyerHistorique } from './lieux.js';
import { etatRencontresMj, outilsRencontresMj } from './rencontres-mj.js';
import { HEURES_PAR_JOUR, RYTHMES, enMiles, enKm, enHeures, enJours, vitessesDe, milesParHeure, minutesTrajet } from './voyage.js';

const JOURNAL_ACTIVITE = 40;
export const MARCHE_JOUR = HEURES_PAR_JOUR * 60;   // une journée de voyage : 8 h de marche
export const PAUSES = [[10, '+10 min'], [30, '+30 min'], [60, '+1 h']];
const FINIR_MAX = 4 * 60;   // marche forcée : « Finir le trajet » proposé s'il reste au plus 4 h

// Marche forcée (règle) : à la fin de chaque heure pleine de marche au-delà de 8 h depuis le dernier repos long, chaque
// héros fait un JS de Constitution DD 10 + 1 par heure au-delà de 8 h ; échec : un niveau d'épuisement.
// Un bout d'heure (finir un trajet en 20 min) ne donne pas de jet.
const heuresForcees = marche => Math.max(0, Math.floor((marche - MARCHE_JOUR) / 60));
// DD des jets dus en passant de `avant` à `apres` minutes de marche (une heure pleine franchie : un jet).
export function jetsForces(avant, apres) {
  const dd = [];
  for (let k = heuresForcees(avant) + 1; k <= heuresForcees(apres); k++) dd.push(10 + k);
  return dd;
}
// Les jets d'un pas de marche forcée, en pastilles DD (ou « sans jet » : pas d'heure pleine franchie).
const pastillesJets = dd => (dd.length ? dd.map(x => pastilleDD(x, 'Jet de sauvegarde de Constitution de chaque héros ; échec : 1 niveau d\'épuisement')) : h('span', { class: 'cm-sourdine' }, 'sans jet'));

const momentLisible = (sH, t) => MOMENTS_LIBELLES[lecture({ ...sH.valeur, ...t }).moment];
export const activiteCourante = v => v.activites?.at(-1) || null;

// Ce qu'il faut pour faire passer le temps : horloge, rencontres (si data/rencontres-aleatoires.json se lit), lieux.
async function outils({ donnees, etat }) {
  const sH = await etatHorloge(etat);
  const lect = await donnees('rencontres-aleatoires');
  const sR = lect.statut === 'ok' ? await etatRencontres(etat) : null;
  const moteur = sR ? moteurRencontres(lect.donnees, sR, await chargerExternes(lect.donnees, donnees, etat)) : null;
  return { sH, sR, moteur, intervalle: moteur?.proc.intervalle_minutes || 60, lieux: await chargerLieux(donnees), sIci: await etatIci(etat, donnees) };
}

// Tests des heures pleines passées dehors pendant `minutes` (à partir de l'heure actuelle). compteur : { dehors } (minutes
// dehors depuis le dernier test), mis à jour ; l'activité elle-même pendant une activité (`sans_aleatoires` : aucun test).
// Renvoie [{ quand, moment, r }] ; r : entrée du journal de Rencontres, ou { plafond }.
function tests(o, compteur, minutes, arret) {
  const { sH, sR, moteur, intervalle } = o;
  const terrain = sR?.valeur.contexte.terrain || 'abri';
  if (!moteur || terrain === 'abri' || compteur.sans_aleatoires) { compteur.dehors = 0; return []; }
  const t0 = enMinutes(sH.valeur);
  const d0 = compteur.dehors || 0, d1 = d0 + minutes;
  const res = [];
  for (let k = 1; k * intervalle <= d1; k++) {
    const quand = depuisMinutes(t0 + k * intervalle - d0 - intervalle / 2);
    const moment = tableRencontres({ ...sH.valeur, ...quand });
    res.push({ quand, moment, r: moteur.tester({ moment, terrain, modificateurs: { ...(sR.valeur.contexte.modificateurs || {}) }, a_l_arret: arret }, quand) });
  }
  compteur.dehors = d1 % intervalle;
  return res;
}

// Ligne de journal d'activité pour un test.
const ligneTest = (o, { quand, moment, r }) => (r.plafond
  ? { quand, moment, texte: 'plafond atteint, pas de test' }
  : { quand, moment, texte: o.moteur.resume(r), id: r.id, rencontre: o.moteur.sortie(r) });

function noter(a, lignes) {
  a.journal = [...(a.journal || []), ...lignes].slice(-JOURNAL_ACTIVITE);
}

// ───── Activités en cours ─────

function empiler(sH, a) {
  sH.valeur.activites = [...(sH.valeur.activites || []), a];
  sH.enregistrer(0);
  sH.signaler();
}

function depiler(sH) {
  sH.valeur.activites = (sH.valeur.activites || []).slice(0, -1);
}

// Fin d'une activité : arrivée (trajet), repos noté (repos long), annonce.
function terminer(o, a) {
  const { sH, sR, lieux } = o;
  depiler(sH);
  const dessous = activiteCourante(sH.valeur);
  if (a.type === 'voyage') {
    noterTrajet(o.sIci, ficheTrajet(a, sH, true));
    const fin = a.itineraire.at(-1);
    const terrain = terrainDuLieu(lieux.get(fin)?.type);
    if (terrain && sR) { sR.valeur.contexte.terrain = terrain; sR.enregistrer(0); sR.signaler(); }
    document.dispatchEvent(new CustomEvent('cm:trajet-fini', { detail: { itineraire: a.itineraire, quand: maintenant(sH.valeur) } }));
    annoncer({ cle: 'activite', titre: `Arrivés à ${nomLieu(lieux, fin)}`, icone: 'epingle', couleur: 'brume', texte: `${libelleMoment(sH.valeur)}, après ${libelleDuree(a.total)} de marche.` });
  } else if (a.type === 'repos') {
    if (dessous?.type === 'voyage') { dessous.marche_jour = 0; dessous.marche_propre = 0; }   // une nouvelle journée de marche commence
    annoncer({ cle: 'activite', titre: a.repos === 'long' ? 'Repos long terminé' : 'Repos terminé', icone: 'lune', couleur: 'brume', texte: `${libelleMoment(sH.valeur)}.` });
  }
}

// Une heure (ou le reste, s'il en reste moins) de l'activité en cours. Renvoie les tests de l'heure.
let occupe = false;
async function pasActivite(o) {
  const { sH, lieux, sIci } = o;
  const a = activiteCourante(sH.valeur);
  if (!a) return [];
  const pas = Math.min(o.intervalle, a.total - a.fait);
  const t0 = enMinutes(sH.valeur);
  const res = tests(o, a, pas, a.type !== 'voyage');
  const lignes = res.map(x => ligneTest(o, x));
  const w0 = a.fait;
  a.fait += pas;
  if (a.type === 'voyage') {
    const marcheAvant = a.marche_jour || 0;
    a.marche_jour = marcheAvant + pas;
    a.marche_propre = (a.marche_propre || 0) + pas;   // marche de ce trajet depuis son dernier campement
    // Marche forcée : un jet de sauvegarde à la fin de chaque heure pleine au-delà de 8 h, au DD qui monte.
    for (const dd of jetsForces(marcheAvant, a.marche_jour)) {
      const heure = HEURES_PAR_JOUR + dd - 10;
      lignes.push({ quand: depuisMinutes(t0 + heure * 60 - marcheAvant), texte: `Fin de la ${heure}e heure de marche : jet de sauvegarde de Constitution, échec : 1 niveau d'épuisement`, dd, forcee: true });
    }
    // Lieux atteints pendant cette heure, à leur heure d'arrivée (widget Ici).
    while (a.atteints < a.etapes.length && a.etapes[a.atteints] <= a.fait) {
      const quand = depuisMinutes(t0 + a.etapes[a.atteints] - w0);
      const lieu = a.itineraire[a.atteints + 1];
      arriverA(sIci, lieux, lieu, quand, a.id);
      lignes.push({ quand, texte: `Arrivée : ${nomLieu(lieux, lieu)}`, arrivee: true });
      a.atteints++;
    }
  }
  const fini = a.fait >= a.total;
  // Fin d'un repos long : l'horloge s'arrête sur l'heure ronde la plus proche, pour repartir sur une heure sûre.
  let pasHorloge = pas;
  if (fini && a.repos === 'long') {
    pasHorloge = arrondiHeure(sH.valeur, pas);
    if (pasHorloge !== pas) lignes.push({ quand: depuisMinutes(t0 + pasHorloge), texte: `Fin du repos arrondie à ${libelleHeure(depuisMinutes(t0 + pasHorloge).minute)}` });
  }
  noter(a, lignes);
  avancer(sH, pasHorloge, `${a.titre} (${libelleDuree(a.fait)} / ${libelleDuree(a.total)})`, { reposLong: fini && a.repos === 'long', activite: { id: a.id, pas } });
  if (fini) { terminer(o, a); sH.enregistrer(0); sH.signaler(); }
  return res;
}

export async function heureSuivante(ctx) {
  if (occupe) return;
  occupe = true;
  try { await pasActivite(await outils(ctx)); } finally { occupe = false; }
}

// Heure après heure, jusqu'à une rencontre, la fin de l'activité, ou la fin d'une journée de marche (camper ?).
export async function jusquaRencontre(ctx) {
  if (occupe) return;
  occupe = true;
  try {
    const o = await outils(ctx);
    const depart = activiteCourante(o.sH.valeur);
    for (let i = 0; i < 48; i++) {
      const a = activiteCourante(o.sH.valeur);
      if (!a || a.id !== depart?.id) break;
      const marcheAvant = a.marche_jour || 0;
      const res = await pasActivite(o);
      if (res.some(x => !x.r.plafond && o.moteur.sortie(x.r))) break;
      if (a.type === 'voyage' && marcheAvant < MARCHE_JOUR && a.marche_jour >= MARCHE_JOUR) break;
    }
  } finally { occupe = false; }
}

// Marche forcée : finir le trajet d'une traite (heure par heure), sauf rencontre en chemin.
export async function jusquaLaFin(ctx) {
  if (occupe) return;
  occupe = true;
  try {
    const o = await outils(ctx);
    const depart = activiteCourante(o.sH.valeur);
    for (let i = 0; i < 48; i++) {
      const a = activiteCourante(o.sH.valeur);
      if (!a || a.id !== depart?.id) break;
      const res = await pasActivite(o);
      if (res.some(x => !x.r.plafond && o.moteur.sortie(x.r))) break;
    }
  } finally { occupe = false; }
}

// Pause pendant une activité (combat, halte, repos court) : le temps passe, l'activité n'avance pas ; dehors, chaque heure
// pleine donne un test (à l'arrêt).
export async function pause(ctx, minutes, motif) {
  if (occupe) return;
  occupe = true;
  try {
    const o = await outils(ctx);
    const a = activiteCourante(o.sH.valeur);
    if (!a) return;
    const lignes = [{ quand: maintenant(o.sH.valeur), texte: `Pause : ${motif}` }, ...tests(o, a, minutes, true).map(x => ligneTest(o, x))];
    noter(a, lignes);
    avancer(o.sH, minutes, `${a.titre} · pause : ${motif}`);
  } finally { occupe = false; }
}

// Trajet : les héros campent pour la nuit (repos long par-dessus le trajet, qui reprend ensuite). Un trajet sans rencontres
// aléatoires campe sans elles.
export async function camper(ctx) {
  const sH = await etatHorloge(ctx.etat);
  const sans = activiteCourante(sH.valeur)?.sans_aleatoires;
  empiler(sH, nouvelleActivite({ type: 'repos', repos: 'long', titre: 'Repos long', total: REPOS_LONG, debut: maintenant(sH.valeur), ...(sans ? { sans_aleatoires: true } : {}) }));
}

// Rencontres aléatoires coupées ou reprises pour l'activité en cours (un trajet où ne comptent que les rencontres prévues de
// la route). Reprises : le prochain test vient une heure pleine plus tard.
export async function basculerAleatoires(ctx) {
  const sH = await etatHorloge(ctx.etat);
  const a = activiteCourante(sH.valeur);
  if (!a) return;
  if (a.sans_aleatoires) delete a.sans_aleatoires;
  else a.sans_aleatoires = true;
  a.dehors = 0;
  noter(a, [{ quand: maintenant(sH.valeur), texte: a.sans_aleatoires ? 'Rencontres aléatoires coupées' : 'Rencontres aléatoires reprises' }]);
  sH.enregistrer(0);
  sH.signaler();
}

// Repos long interrompu (initiative, sort autre qu'un tour de magie, dégâts, 1 h d'effort) : on peut le reprendre aussitôt,
// avec 1 h de plus par interruption (règles 2024).
export async function interrompreRepos(ctx) {
  const sH = await etatHorloge(ctx.etat);
  const a = activiteCourante(sH.valeur);
  if (a?.type !== 'repos') return;
  a.interruptions = (a.interruptions || 0) + 1;
  a.total += 60;
  noter(a, [{ quand: maintenant(sH.valeur), texte: 'Interruption : le repos durera 1 h de plus' }]);
  sH.enregistrer(0);
  sH.signaler();
}

export async function arreter(ctx) {
  const sH = await etatHorloge(ctx.etat);
  const a = activiteCourante(sH.valeur);
  if (a?.type === 'voyage') {
    noterTrajet(await etatIci(ctx.etat, ctx.donnees), ficheTrajet(a, sH, false));
  }
  depiler(sH);
  sH.enregistrer(0);
  sH.signaler();
}

// Ce que l'historique garde d'un trajet (widget Ici) : itinéraire, lieux atteints, heures de départ et d'arrivée (ou d'arrêt),
// marche totale et marche depuis son dernier campement (reprise par le trajet suivant, s'il n'y a pas eu de repos long).
function ficheTrajet(a, sH, fini) {
  return { id: a.id, itineraire: a.itineraire, atteints: fini ? a.itineraire.length - 1 : a.atteints, debut: a.debut, fin: maintenant(sH.valeur),
    marche: a.fait, marche_depuis_repos: a.marche_propre ?? a.fait, fini };
}

// Marche depuis le dernier repos long, lue dans l'historique des trajets (widget Ici) : ceux qui se sont terminés depuis
// (et dans les dernières 24 h de jeu, à défaut de repos long noté), avant l'heure actuelle. Retirer un trajet de
// l'historique le retire de ce compte.
export function marcheDepuisRepos(sIci, v) {
  const maintenant_ = enMinutes(v);
  const depuis = Math.max(v.repos_long ? enMinutes(v.repos_long) : -Infinity, maintenant_ - VEILLE_MAX);
  return (sIci.valeur.trajets || []).filter(t => t.fin && enMinutes(t.fin) > depuis && enMinutes(t.fin) <= maintenant_)
    .reduce((somme, t) => somme + (t.marche_depuis_repos ?? t.marche ?? 0), 0);
}

function nouvelleActivite(champs) {
  return { id: identifiant(), fait: 0, dehors: 0, journal: [], ...champs };
}

// ───── Le dialogue ─────

// ctx : contexte des widgets ({ dialogue, donnees, etat }).
// o : { titre, motif, duree (minutes de jeu), repos ('court' ou 'long'), trajet ({ resume, itineraire, etapes } : minutes de
//       marche cumulées jusqu'à chaque lieu après le départ ; avec rythme, rythmes et calculer(rythme) → { duree, etapes,
//       resume }, le rythme se choisit dans le dialogue ; auDepart(rythme) : appelé au départ) }. Voir partirEnTrajet().
// Une heure au plus : le temps passe d'un coup. Plus long, ou un trajet : une activité menée heure par heure dans l'Horloge.
// À l'abri et hors trajet : rien à demander, le temps passe directement.
export async function passerLeTemps(ctx, o) {
  const oo = await outils(ctx);
  const { sH, sR, moteur, intervalle } = oo;
  const avecHorloge = horlogeEnService();
  const ctxR = sR?.valeur.contexte || {};
  const terrains = o.trajet ? TERRAINS.filter(([t]) => t !== 'abri') : TERRAINS;
  const choix = {
    terrain: o.trajet && (!ctxR.terrain || ctxR.terrain === 'abri') ? 'route' : (ctxR.terrain || 'abri'),
    tester: true,
    modificateurs: { ...(ctxR.modificateurs || {}) },   // cases de la procédure de rencontre (un guide…)
    arret: o.trajet ? false : o.repos ? true : !!ctxR.a_l_arret,
    corriger: false,
    debut: maintenant(sH.valeur),
    rythme: o.trajet?.rythme,
    sansAleatoires: false,   // trajet : pas de test de rencontre aléatoire, seulement les rencontres prévues de la route
  };
  const enActivite = () => !!o.trajet || (o.duree > intervalle && choix.terrain !== 'abri');

  // Trajet : un autre rythme, une autre durée (arrivée, lieux traversés, résumé).
  function changerRythme(r) {
    choix.rythme = r;
    const c = o.trajet.calculer(r);
    o.duree = c.duree;
    Object.assign(o.trajet, { etapes: c.etapes, resume: c.resume });
    rendre();
  }

  function retenirContexte() {
    if (!sR) return;
    Object.assign(sR.valeur.contexte, { terrain: choix.terrain, modificateurs: { ...choix.modificateurs }, ...(o.trajet || o.repos ? {} : { a_l_arret: choix.arret }) });
    sR.enregistrer(0);
    sR.signaler();
  }

  // D'un coup : une heure au plus, ou à l'abri.
  function dUnCoup() {
    if (enMinutes(choix.debut) !== enMinutes(sH.valeur)) changer(sH, choix.debut, 'Correction de l\'heure', { silencieux: true });
    retenirContexte();
    const compteur = { dehors: 0 };
    const duree = o.repos === 'long' ? arrondiHeure(sH.valeur, o.duree) : o.duree;   // repos long : fin à l'heure ronde
    const res = choix.tester ? tests(oo, compteur, duree, choix.arret) : [];
    avancer(sH, duree, o.motif, { reposLong: o.repos === 'long' });
    return res;
  }

  function commencer() {
    if (enMinutes(choix.debut) !== enMinutes(sH.valeur)) changer(sH, choix.debut, 'Correction de l\'heure', { silencieux: true });
    retenirContexte();
    if (o.trajet) o.trajet.auDepart?.(choix.rythme);
    const report = o.trajet ? marcheDepuisRepos(oo.sIci, sH.valeur) : 0;   // trajets faits depuis le dernier repos long
    empiler(sH, nouvelleActivite(o.trajet
      ? { type: 'voyage', titre: o.titre, total: o.duree, itineraire: o.trajet.itineraire, etapes: o.trajet.etapes, atteints: 0, marche_jour: report, marche_report: report, marche_propre: 0, debut: choix.debut,
        ...(choix.sansAleatoires ? { sans_aleatoires: true } : {}) }
      : o.repos === 'long' ? { type: 'repos', repos: 'long', titre: o.titre, total: o.duree, debut: choix.debut }
        : { type: 'attente', titre: o.titre, total: o.duree, arret: choix.arret, debut: choix.debut }));
  }

  // À l'abri, hors trajet : rien à demander.
  if (!o.trajet && (choix.terrain === 'abri' || !moteur)) { if (avecHorloge) dUnCoup(); return; }

  const zone = h('div', { class: 'cm-pile cm-passage' });
  let dlg;

  function vueChoix() {
    const fin = depuisMinutes(enMinutes(choix.debut) + (o.repos === 'long' ? arrondiHeure(choix.debut, o.duree) : o.duree));
    const dehors = choix.terrain !== 'abri';
    const champJour = h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '1', value: choix.debut.jour, 'aria-label': 'Jour' });
    const champHeure = h('input', { class: 'bn-input cm-champ-heure', type: 'time', step: '60', value: enHHMM(choix.debut.minute), 'aria-label': 'Heure' });
    const corriger = () => {
      const m = depuisHHMM(champHeure.value), j = Number(champJour.value);
      if (m === null || !(Number.isInteger(j) && j >= 1)) return;
      choix.debut = { jour: j, minute: m };
      rendre();
    };
    champJour.addEventListener('change', corriger);
    champHeure.addEventListener('change', corriger);
    const n = Math.floor(o.duree / intervalle);
    return [
      o.trajet?.resume ? h('p', { class: 'cm-lieu' }, icone('lu-route', 'bn-icone--s'), o.trajet.resume) : null,
      h('div', { class: 'bn-carte cm-passage__heures' },
        h('div', {}, h('span', { class: 'etiquette' }, 'Il est'), h('p', { class: 'ui-l' }, `${libelleMoment(choix.debut)} · ${momentLisible(sH, choix.debut)}`),
          choix.corriger ? h('div', { class: 'bn-groupe' }, champJour, champHeure) : h('button', { type: 'button', class: 'bn-lien cm-lien-bouton cm-passage__corriger', title: 'Oubli d\'avancer le temps : corriger l\'heure de départ', onclick: () => { choix.corriger = true; rendre(); } }, icone('lu-pencil'), 'Corriger l\'heure')),
        h('div', {}, h('span', { class: 'etiquette' }, o.trajet ? 'Arrivée sans halte' : 'Fin prévue'), h('p', { class: 'ui-l' }, `${libelleMoment(fin)} · ${momentLisible(sH, fin)}`),
          (() => {
            // Marche déjà faite depuis le dernier repos long (historique des trajets) : elle compte pour les 8 h.
            const deja = o.trajet ? marcheDepuisRepos(oo.sIci, { ...sH.valeur, ...choix.debut }) : 0;
            return h('p', { class: 'ui-s cm-sourdine' }, `+${libelleDuree(o.duree)}`,
              deja ? ` · déjà ${libelleDuree(deja)} de marche depuis le dernier repos long` : '',
              o.trajet && deja + o.duree > MARCHE_JOUR ? ' : plus de 8 h de marche, il faudra camper' : '');
          })())),
      // Sur une ligne : où sont les héros ; pour un trajet, le rythme (icônes seules) ; dehors, les cases de la procédure de
      // rencontre (un guide…) ; hors trajet
      // et repos, en marche ou à l'arrêt, poussé à droite. L'étiquette « Les héros sont » ne reste que pour un repos.
      h('div', { class: 'cm-contexte cm-passage__ou' }, o.repos ? h('span', { class: 'etiquette' }, 'Les héros sont') : null,
        bascule('Où sont les héros', terrains, choix.terrain, t => { choix.terrain = t; rendre(); }),
        o.trajet?.calculer && o.trajet.rythmes?.length > 1 ? bascule('Rythme', o.trajet.rythmes, choix.rythme, changerRythme, { iconesSeules: true }) : null,
        dehors ? (moteur?.proc.modificateurs || []).map(m => h('label', { class: 'cm-case', title: m.regle },
          h('input', { type: 'checkbox', class: 'bn-case', checked: !!choix.modificateurs[m.id], onchange: e => { choix.modificateurs[m.id] = e.target.checked; } }), m.nom)) : null,
        // En marche ou à l'arrêt : un seul bouton à deux états, enfoncé à l'arrêt ; un clic passe à l'autre.
        !o.trajet && !o.repos ? h('button', { type: 'button', class: 'bn-btn bn-btn--s cm-interrupteur', 'aria-pressed': String(choix.arret),
          title: choix.arret ? 'À l\'arrêt (certaines rencontres de voyage n\'ont pas lieu). Cliquer : en marche' : 'En marche. Cliquer : à l\'arrêt',
          onclick: () => { choix.arret = !choix.arret; rendre(); } },
        icone(choix.arret ? 'lu-pause' : 'lu-footprints'), h('span', {}, choix.arret ? 'À l\'arrêt' : 'En marche')) : null,
        // Trajet sans rencontres aléatoires : un bouton à deux états, enfoncé quand elles sont coupées.
        o.trajet && dehors && moteur ? boutonSansAleatoires(choix.sansAleatoires, () => { choix.sansAleatoires = !choix.sansAleatoires; rendre(); }) : null),
      o.repos ? h('p', { class: 'ui-s cm-sourdine' }, `Repos ${o.repos} : les héros sont à l'arrêt (certaines rencontres de voyage n'ont pas lieu).${o.repos === 'long' ? ' Le repos long sera noté terminé à la fin.' : ''}`) : null,
      !dehors ? h('p', { class: 'ui' }, 'À l\'abri (en ville, à l\'intérieur) : pas de rencontre aléatoire.')
        : !moteur ? alerte('cierge', 'lu-database', 'Rencontres indisponibles', 'data/rencontres-aleatoires.json est absent ou illisible.')
          : h('div', { class: 'cm-pile cm-passage__tests' },
            o.trajet && choix.sansAleatoires ? h('p', { class: 'ui' }, `Heure par heure, depuis l'Horloge, sans test de rencontre aléatoire : la fenêtre du trajet liste les rencontres prévues de la route, à lancer quand vous le voulez. Entre deux heures, ajoutez le temps d'une pause, d'un repos court ou d'un combat.`)
            : enActivite() ? h('p', { class: 'ui' }, `Heure par heure, depuis l'Horloge : un test de rencontre par heure dehors, sur la table de jour ou de nuit de cette heure. Entre deux heures, ajoutez le temps d'une pause, d'un repos court ou d'un combat.`)
              : n ? h('label', { class: 'cm-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: choix.tester, onchange: e => { choix.tester = e.target.checked; } }),
                h('span', {}, `Tester la rencontre de cette heure (table de ${tableRencontres({ ...sH.valeur, ...depuisMinutes(enMinutes(choix.debut) + intervalle / 2) }) === 'nuit' ? 'nuit' : 'jour'})`))
                : h('p', { class: 'ui-s cm-sourdine' }, 'Moins d\'une heure dehors : pas de test de rencontre.'),
            o.trajet && choix.sansAleatoires ? null : h('p', { class: 'ui-s cm-sourdine' }, `${moteur.proc.test.regle} Route : ${moteur.proc.test.seuil.route}, nature : ${moteur.proc.test.seuil.nature}. ${moteur.proc.plafond.regle}`)),
      h('div', { class: 'bn-groupe' },
        enActivite()
          ? bouton(o.trajet ? 'Partir' : 'Commencer', { classe: 'bn-btn--primaire', icone: o.trajet ? 'lu-route' : 'sablier', titre: 'Le suivi heure par heure s\'affiche dans l\'Horloge', onclick: () => { commencer(); dlg.close(); } })
          : bouton('Faire passer le temps', { classe: 'bn-btn--primaire', icone: 'sablier', onclick: () => afficherResultats(dUnCoup()) }),
        bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })),
    ];
  }

  function afficherResultats(res) {
    const lignes = res.map(x => ligneTest(oo, x));
    zone.replaceChildren(...[
      lignes.length ? listeJournal(lignes, () => dlg.close()) : h('p', { class: 'ui cm-sourdine' }, 'Pas de test de rencontre.'),
      h('p', { class: 'ui' }, h('b', {}, 'Il est maintenant '), `${libelleMoment(sH.valeur)} · ${momentLisible(sH, sH.valeur)}.`),
      h('div', { class: 'bn-groupe' }, bouton('Fermer', { classe: 'bn-btn--primaire', onclick: () => dlg.close() })),
    ].filter(Boolean));
  }

  function rendre() { zone.replaceChildren(...vueChoix().filter(Boolean)); }
  rendre();
  dlg = ctx.dialogue('Horloge · le temps passe', o.titre, zone);
}

// ───── Partir en trajet ─────

const TRAJETS_DEFAUT = { schema: 1, itineraire: [], unite: 'miles', rythme: 'normal', monture: false };

// « Démarrer le trajet » (widgets Trajets et Déroulé) : le dialogue de départ d'un itinéraire ([id, …], lieux reliés deux à
// deux par un trajet de temps-de-voyage.json). Le rythme s'y choisit et la durée le suit (monture et unité : celles du widget
// Trajets) ; « Partir » met l'itinéraire et le rythme dans etat/trajets.json et lance le trajet heure par heure dans
// l'Horloge. Renvoie false, après une annonce, quand rien ne s'ouvre (données ou itinéraire incomplets, trajet déjà en cours).
export async function partirEnTrajet(ctx, itineraire) {
  const [lect, sT, sH, lieux] = await Promise.all([ctx.donnees('temps-de-voyage'), ctx.etat('trajets', TRAJETS_DEFAUT), etatHorloge(ctx.etat), chargerLieux(ctx.donnees)]);
  const nom = id => nomLieu(lieux, id);
  const refus = (titre, texte) => { annoncer({ cle: 'trajet', titre, icone: 'lu-route', couleur: 'cierge', texte }); return false; };
  if (lect.statut !== 'ok') return refus('Temps de voyage indisponibles', 'data/temps-de-voyage.json est absent ou illisible.');
  const ts = itineraire.slice(1).map((id, i) => lect.donnees.trajets.find(t => (t.de === itineraire[i] && t.vers === id) || (t.de === id && t.vers === itineraire[i])));
  if (itineraire.length < 2 || ts.some(t => !t)) return refus('Itinéraire incomplet', `Pas de trajet direct entre deux lieux de ${itineraire.map(nom).join(' → ')}.`);
  const enCours = (sH.valeur.activites || []).find(a => a.type === 'voyage');
  if (enCours) return refus('Un trajet est déjà en cours', `${enCours.titre} : il se mène heure par heure dans l'Horloge.`);
  const vitesses = vitessesDe(lect.donnees);
  const { unite, monture } = sT.valeur;
  const miles = ts.reduce((a, t) => a + t.miles, 0);
  const chemin = itineraire.map(nom).join(' → ');
  const calculer = rythme => {
    const mph = milesParHeure(vitesses, rythme, monture);
    let cumul = 0;
    const etapes = ts.map(t => (cumul += minutesTrajet(t, mph)));
    return { duree: cumul, etapes,
      resume: `${chemin} · ${unite === 'km' ? enKm(miles) : enMiles(miles)} · ${enHeures(cumul)} de marche${cumul > HEURES_PAR_JOUR * 60 ? ` (${enJours(cumul)} en journées de 8 h)` : ''}${monture && vitesses.bonusMonture ? ' · avec monture' : ''}` };
  };
  const rythme = vitesses.parJour[sT.valeur.rythme] ? sT.valeur.rythme : 'normal';
  const c = calculer(rythme);
  await passerLeTemps(ctx, {
    titre: `Trajet vers ${nom(itineraire.at(-1))}`, motif: `Trajet : ${chemin}`, duree: c.duree,
    trajet: { itineraire: [...itineraire], etapes: c.etapes, resume: c.resume, rythme, rythmes: RYTHMES.filter(([r]) => vitesses.parJour[r]), calculer,
      auDepart: r => {
        Object.assign(sT.valeur, { itineraire: [...itineraire], rythme: r });
        delete sT.valeur.arrive;
        sT.enregistrer(0);
        sT.signaler();
        document.dispatchEvent(new CustomEvent('cm:depart-lieu', { detail: { lieu: itineraire[0] } }));   // ce qui reste au lieu quitté : app/restes.js
      } },
  });
  return true;
}

// Lignes de journal (tests, arrivées, pauses) ; « Voir » ouvre une rencontre dans le widget Rencontres.
// Arrivée dans un lieu, rencontre et marche forcée ressortent (couleur et graisse).
export function listeJournal(lignes, apresVoir) {
  return h('ol', { class: 'cm-passage__resultats' }, lignes.map(l => h('li', { class: 'cm-passage__ligne' + (l.rencontre ? ' est-rencontre' : '') + (l.arrivee ? ' est-arrivee' : '') + (l.forcee ? ' est-forcee' : '') },
    icone(l.arrivee ? 'epingle' : l.forcee ? 'lu-footprints' : l.rencontre ? 'loup' : l.moment === 'nuit' ? 'lune' : l.moment === 'jour' ? 'soleil' : 'sablier', 'bn-icone--s'),
    h('span', { class: l.rencontre || l.arrivee || l.forcee ? '' : 'cm-sourdine' }, `${l.quand ? `${libelleMoment(l.quand)} : ` : ''}${l.texte}`,
      l.dd ? [' ', pastilleDD(l.dd, 'Jet de sauvegarde de Constitution')] : null),
    // Le dialogue se ferme d'abord : la fiche (widget Rencontres) s'ouvre ensuite dans une fenêtre flottante ordinaire.
    l.rencontre ? bouton('Voir', { classe: 'bn-btn--s', icone: 'loup', titre: 'Ouvrir la fiche de la rencontre', onclick: () => { apresVoir?.(); document.dispatchEvent(new CustomEvent('cm:voir-rencontre', { detail: { id: l.id } })); } }) : null)));
}

// Boutons de repos et d'attente, picto et libellé court (« court » ; « →| ☀ aube » : jusqu'à ce moment), le détail au survol.
// Même style partout : Horloge, activité en cours ; « + », repos et « Annuler » tiennent sur une ligne (CSS).
export function boutonRepos(ic, lib, titre, onclick, jusquA = false) {
  return h('button', { type: 'button', class: 'bn-btn bn-btn--s cm-horloge__repos', title: titre, 'aria-label': titre, onclick },
    jusquA ? icone('lu-arrow-right-to-line', 'cm-horloge__fleche') : null, icone(ic), h('span', {}, lib));
}

// « + » : les durées à ajouter (+10 min, +30 min…) dans un menu qui s'ouvre dessous. choix : [[libellé, titre, action], …].
export function boutonAvancer(titre, choix) {
  const libelles = choix.map(c => c[0]).join(', ');
  const btn = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone cm-horloge__plus', title: `${titre} : ${libelles}`, 'aria-label': titre }, icone('lu-plus'));
  return boutonMenu(btn, choix, titre);
}

// « Sans aléatoires » : un seul bouton à deux états (départ d'un trajet, fenêtre de l'activité), enfoncé quand les rencontres
// aléatoires sont coupées ; un clic passe à l'autre.
function boutonSansAleatoires(sans, onclick) {
  return h('button', { type: 'button', class: 'bn-btn bn-btn--s cm-interrupteur', 'aria-pressed': String(!!sans), onclick,
    title: sans ? 'Rencontres aléatoires coupées : pas de test, seulement les rencontres prévues de la route. Cliquer : les reprendre'
      : 'Un test de rencontre aléatoire par heure dehors. Cliquer : les couper (seulement les rencontres prévues de la route)' },
  icone('d20'), h('span', {}, 'Sans aléatoires'));
}

// ───── Carte de l'activité en cours (widget Horloge) ─────

// Encarts dépliés par le MJ : ils le restent d'une heure à l'autre (la carte est redessinée à chaque pas).
const encartsOuverts = new Set();
export function garderOuvert(cle, det) {
  det.open = encartsOuverts.has(cle);
  det.addEventListener('toggle', () => { if (det.open) encartsOuverts.add(cle); else encartsOuverts.delete(cle); });
  return det;
}

// Marche forcée, repliée : le DD du jet en cours à droite (le dernier dû, sinon celui de la prochaine heure pleine).
function alerteForcee(a, marche) {
  const faits = jetsForces(MARCHE_JOUR, marche);
  const dd = faits.length ? faits.at(-1) : 11;
  const report = a.marche_report
    ? ` Ce compte reprend ${libelleDuree(a.marche_report)} de marche des trajets faits depuis le dernier repos long (historique dans le widget Ici : retirer un trajet noté par erreur le retire du compte au prochain trajet).` : '';
  return alerteRepliable('cierge', 'lu-footprints', marche > MARCHE_JOUR ? `Marche forcée : ${libelleDuree(marche - MARCHE_JOUR)} au-delà de 8 h` : '8 h de marche depuis le dernier repos long',
    pastilleDD(dd, faits.length ? 'Dernier jet de sauvegarde de Constitution dû' : 'Jet de sauvegarde de Constitution à la fin de la prochaine heure pleine'),
    (marche > MARCHE_JOUR
      ? `À la fin de chaque heure pleine au-delà de 8 h, chaque héros fait un jet de sauvegarde de Constitution, DD${FINE}10 + 1 par heure au-delà de 8 h ; échec : un niveau d'épuisement. Campez pour remettre le compte à zéro.`
      : `Campez (repos long), ou proposez aux joueurs de marcher encore : marche forcée, un jet de sauvegarde de Constitution à la fin de chaque heure pleine de plus (DD${FINE}11, puis 12…).`) + report);
}

// Plus de 24 h sans repos long, repliée : « Fatigue +1 » à droite.
export function alerteVeille(v, veille) {
  return alerteRepliable('sang', 'sablier', 'Plus de 24 h sans repos long', badge('Fatigue +1', 'sang'),
    `Dernier repos long terminé ${libelleMoment(v.repos_long)}, il y a ${libelleDuree(veille)}. Chaque héros gagne un niveau d'épuisement.`);
}

export const LIBELLES_ACTIVITE = { voyage: 'Trajet en cours', repos: 'Repos en cours', attente: 'Le temps passe' };

// annuler : le bouton « Annuler » de l'Horloge, mis au bout de la ligne des pauses.
// fenetre : la carte est le contenu d'une fenêtre flottante, qui porte déjà le type et le titre de l'activité.
export function vueActivite(ctx, a, { sH, sR, intervalle = 60, annuler = null, fenetre = false }) {
  const terrain = sR?.valeur.contexte.terrain || 'abri';
  const reste = a.total - a.fait;
  const libelleType = LIBELLES_ACTIVITE[a.type];
  const prochainLieu = a.type === 'voyage' && a.atteints < a.etapes.length ? { id: a.itineraire[a.atteints + 1], dans: a.etapes[a.atteints] - a.fait } : null;
  const nomDe = id => nomLieuCache?.get(id)?.nom || id;
  const lignes = [...(a.journal || [])].reverse().slice(0, 10);
  const marche = a.type === 'voyage' ? (a.marche_jour || 0) : 0;
  const forcee = a.type === 'voyage' && marche >= MARCHE_JOUR;   // 8 h de marche depuis le dernier repos long
  const veille = sansReposLong(sH.valeur);
  const { lever, coucher } = reglagesDe(sH.valeur);
  // Marche forcée : une heure de plus (ou le reste), finir le trajet s'il reste peu ; les DD des jets dans le bouton.
  const pasForce = Math.min(intervalle, reste);
  const btnForce = (classe, ic, libelle, dd, titre, onclick) => h('button', { type: 'button', class: `bn-btn bn-btn--s ${classe}`, title: titre, onclick },
    icone(ic), h('span', {}, libelle), pastillesJets(dd));
  const commandes = forcee
    ? [
      btnForce('bn-btn--primaire', 'lu-footprints', reste <= intervalle ? `Finir le trajet (+${libelleDuree(reste)})` : 'Marcher 1 h de plus', jetsForces(marche, marche + pasForce),
        'Marche forcée : à la fin de chaque heure pleine au-delà de 8 h, jet de sauvegarde de Constitution à ce DD pour chaque héros', () => heureSuivante(ctx)),
      reste > intervalle && reste <= FINIR_MAX ? btnForce('', 'lu-play', `Finir le trajet (+${libelleDuree(reste)})`, jetsForces(marche, marche + reste),
        'Marche forcée jusqu\'à l\'arrivée (s\'arrête en cas de rencontre) : un jet de sauvegarde à la fin de chaque heure pleine, au DD qui monte', () => jusquaLaFin(ctx)) : null,
    ]
    : [
      bouton(reste < intervalle ? `Terminer (+${libelleDuree(reste)})` : 'Heure suivante', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-arrow-right', onclick: () => heureSuivante(ctx) }),
      a.sans_aleatoires
        ? bouton(a.type === 'voyage' ? 'Jusqu\'à l\'arrivée' : 'Jusqu\'à la fin', { classe: 'bn-btn--s', icone: 'lu-play', titre: `Heure après heure, sans rencontre aléatoire ; s'arrête à la fin${a.type === 'voyage' ? ', ou après 8 h de marche' : ''}`, onclick: () => jusquaRencontre(ctx) })
        : bouton('Jusqu\'à la prochaine rencontre', { classe: 'bn-btn--s', icone: 'lu-play', titre: 'Heure après heure ; s\'arrête à la première rencontre, à l\'arrivée, ou après 8 h de marche', onclick: () => jusquaRencontre(ctx) }),
    ];
  const voyage = a.type === 'voyage' ? a : (sH.valeur.activites || []).find(x => x.type === 'voyage');
  return h('div', { class: fenetre ? 'cm-activite cm-activite--fenetre' : 'bn-carte cm-activite' },
    fenetre ? null : h('span', { class: 'surtitre' }, libelleType),
    fenetre ? null : h('p', { class: 'titre-m' }, a.titre),
    h('div', { class: 'cm-activite__barre', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(a.total), 'aria-valuenow': String(a.fait), 'aria-label': 'Avancée' },
      h('span', { style: `width: ${Math.min(100, (a.fait / a.total) * 100)}%` })),
    h('p', { class: 'ui-s' }, a.type === 'voyage'
      ? `${libelleDuree(a.fait)} de marche sur ${libelleDuree(a.total)} · depuis le dernier repos long : ${libelleDuree(marche)}${a.marche_report ? ` (dont ${libelleDuree(a.marche_report)} des trajets d'avant)` : ''}${prochainLieu ? ` · ${nomDe(prochainLieu.id)} dans ${libelleDuree(prochainLieu.dans)}` : ''}`
      : `${libelleDuree(a.fait)} sur ${libelleDuree(a.total)}${a.interruptions ? ` (${a.interruptions} interruption${a.interruptions > 1 ? 's' : ''} : +1 h chacune)` : ''}${a.repos === 'long' ? ' · fin à l\'heure ronde suivante' : ''}`),
    terrain === 'abri' ? h('p', { class: 'ui-s cm-sourdine' }, 'À l\'abri : pas de test de rencontre.')
      : h('div', { class: 'cm-contexte cm-activite__tests' },
        h('p', { class: 'ui-s cm-sourdine' }, a.sans_aleatoires ? `Dehors (${terrain === 'route' ? 'route' : 'pleine nature'}) : rencontres aléatoires coupées.`
          : `Dehors (${terrain === 'route' ? 'route' : 'pleine nature'}) : prochain test dans ${libelleDuree(intervalle - (a.dehors || 0))}.`),
        boutonSansAleatoires(a.sans_aleatoires, () => basculerAleatoires(ctx))),
    forcee ? garderOuvert('forcee', alerteForcee(a, marche)) : null,
    veille !== null && veille > VEILLE_MAX ? garderOuvert('veille', alerteVeille(sH.valeur, veille)) : null,
    h('div', { class: 'bn-groupe' }, commandes,
      a.type === 'repos' && a.repos === 'long' ? bouton('Interruption', { classe: 'bn-btn--s', icone: 'epee', titre: 'Initiative, sort autre qu\'un tour de magie, dégâts, 1 h d\'effort : le repos reprend avec 1 h de plus (règles 2024)', onclick: () => interrompreRepos(ctx) }) : null,
      bouton(a.type === 'voyage' ? 'Arrêter le trajet' : 'Arrêter', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'Fin de l\'activité, à l\'heure actuelle', onclick: () => arreter(ctx) })),
    // Pauses (« + ») et repos sur une ligne, « Annuler » au bout : le temps passe, l'activité n'avance pas
    // (sauf « Camper », repos long par-dessus le trajet).
    h('div', { class: 'cm-horloge__commandes cm-activite__pauses', role: 'group', 'aria-label': 'Pause, combat, repos' },
      boutonAvancer('Pause, combat (l\'activité n\'avance pas)', PAUSES.map(([min, lib]) => [lib, `Pause, combat : le temps passe de ${libelleDuree(min)} sans que l'activité avance`, () => pause(ctx, min, lib)])),
      boutonRepos('sablier', 'court', `Repos court : ${libelleDuree(REPOS_COURT)}, l'activité n'avance pas`, () => pause(ctx, REPOS_COURT, 'repos court')),
      a.type === 'voyage' ? boutonRepos('lune', 'long', 'Camper : repos long par-dessus le trajet, qui reprend ensuite', () => camper(ctx)) : null,
      boutonRepos('soleil', 'aube', `Attendre l'aube : jusqu'au lever du soleil, à ${libelleHeure(lever)} ; l'activité n'avance pas`, () => pause(ctx, jusqua(sH.valeur, lever), 'attendre l\'aube'), true),
      boutonRepos('cierge', 'soir', `Attendre le soir : jusqu'au coucher du soleil, à ${libelleHeure(coucher)} ; l'activité n'avance pas`, () => pause(ctx, jusqua(sH.valeur, coucher), 'attendre le soir'), true),
      annuler),
    voyage ? vuePrevues(voyage) : null,
    lignes.length ? h('div', { class: 'cm-pile cm-activite__journal' }, h('span', { class: 'etiquette' }, 'Journal'), listeJournal(lignes)) : null);
}

// Les rencontres prévues de la route (données et créées par le MJ entre deux lieux de l'itinéraire : duTrajet() de
// app/rencontres-mj.js), dans l'ordre de la route ; celles du tronçon où sont les héros en tête et marquées. Une ligne ouvre
// le menu de la rencontre (Ouvrir, Lancer, Marquer terminée…). Déplié d'office ; replié par le MJ, il le reste pour ce trajet.
const prevuesRepliees = new Set();   // id des trajets dont le MJ a replié la liste
function vuePrevues(voyage) {
  if (!rencontresCache) return null;
  const troncon = Math.min(voyage.atteints || 0, voyage.itineraire.length - 2);
  const l = rencontresCache.duTrajet(voyage.itineraire, troncon);
  if (!l.length) return null;
  const ici = l.filter(x => x.ici), ailleurs = l.filter(x => !x.ici);
  const nomDe = id => nomLieuCache?.get(id)?.nom || id;
  const restent = l.filter(x => x.vue.statut !== 'terminee').length;
  const det = h('details', { class: 'cm-repli cm-activite__prevues', open: !prevuesRepliees.has(voyage.id),
    ontoggle: e => { if (e.target.open) prevuesRepliees.delete(voyage.id); else prevuesRepliees.add(voyage.id); } },
    h('summary', { class: 'etiquette' }, `Rencontres prévues de la route (${restent ? `${restent} à jouer` : 'toutes jouées'})`),
    ici.length ? h('div', { class: 'cm-pile cm-activite__prevues-groupe' },
      h('span', { class: 'ui-s cm-sourdine' }, `Sur ce tronçon (${nomDe(voyage.itineraire[troncon])} → ${nomDe(voyage.itineraire[troncon + 1])})`),
      ici.map(x => rencontresCache.ligne(x.vue, { compacte: true }))) : null,
    ailleurs.length ? h('div', { class: 'cm-pile cm-activite__prevues-groupe' },
      h('span', { class: 'ui-s cm-sourdine' }, 'Ailleurs sur la route'),
      ailleurs.map(x => rencontresCache.ligne(x.vue))) : null);
  return det;
}

// Noms des lieux et rencontres du MJ pour la carte d'activité (chargés une fois). Renvoie les rencontres du MJ (ou null), pour
// que l'Horloge redessine la fenêtre quand l'une change (lancée, terminée).
let nomLieuCache = null;
let rencontresCache = null;
export async function preparerActivite(ctx) {
  nomLieuCache ||= await chargerLieux(ctx.donnees);
  rencontresCache ||= await outilsRencontresMj(ctx).catch(() => null);
  return rencontresCache;
}

// « Annuler » de l'Horloge (demande du MJ, 2026-10-22) : revient avant la dernière avancée du journal (annuler() de
// app/horloge.js). Ce qui s'est passé pendant ce temps (tests et rencontres tirées dans Rencontres, arrivées notées dans Ici,
// rencontres lancées depuis ces tirages) : une fenêtre le liste et propose de le défaire aussi, coché d'office.
export async function annulerAvecSuites(ctx) {
  const o = await outils(ctx);
  const { sH, sR, sIci, lieux } = o;
  const dernier = sH.valeur.journal?.at(-1);
  if (!dernier) return;
  const [de, a] = [enMinutes(dernier.avant), enMinutes(dernier.apres)].sort((x, y) => x - y);
  const dans = t => t?.jour != null && enMinutes(t) > de && enMinutes(t) <= a;
  const tirages = (sR?.valeur.journal || []).filter(e => dans(e.horloge));
  const idsTirages = new Set(tirages.map(e => e.id));
  const arrivees = (sIci.valeur.visites || []).map((x, i) => ({ x, i })).filter(({ x }) => dans(x));
  const sM = await etatRencontresMj(ctx.etat);
  const lancees = (sM.valeur.rencontres || []).filter(e => e.origine === 'aleatoire' && idsTirages.has(e.tirage?.entree));
  if (!tirages.length && !arrivees.length && !lancees.length) { annuler(sH); return; }

  const coche = (titre, lignes) => {
    const c = h('input', { type: 'checkbox', class: 'bn-case', checked: true });
    return { c, el: h('div', { class: 'cm-pile cm-annuler__bloc' },
      h('label', { class: 'cm-case' }, c, h('span', { class: 'ui' }, h('b', {}, titre))),
      h('ul', { class: 'ui-s cm-liste cm-annuler__liste' }, lignes.map(t => h('li', {}, t)))) };
  };
  const quandDe = t => (t ? libelleMoment(t) : '');
  const blocs = {
    tirages: tirages.length ? coche(`Retirer ${tirages.length > 1 ? `les ${tirages.length} tests et tirages` : 'le test'} de Rencontres`,
      tirages.map(e => `${quandDe(e.horloge)} : ${o.moteur?.resume(e) || e.type}`)) : null,
    arrivees: arrivees.length ? coche(`Retirer ${arrivees.length > 1 ? `les ${arrivees.length} arrivées` : 'l\'arrivée'} de Ici`,
      arrivees.map(({ x }) => `${quandDe(x)} : ${nomLieu(lieux, x.lieu)}`)) : null,
    lancees: lancees.length ? coche(`Supprimer ${lancees.length > 1 ? `les ${lancees.length} rencontres lancées` : 'la rencontre lancée'} depuis ${lancees.length > 1 ? 'ces tirages' : 'ce tirage'}`,
      lancees.map(e => `${e.nom}${e.statut === 'terminee' ? ' (terminée)' : e.statut === 'en-cours' ? ' (en cours)' : ''}`)) : null,
  };
  let dlg;
  const valider = () => {
    const act = activiteCourante(sH.valeur);
    const sansTirages = blocs.tirages?.c.checked, sansArrivees = blocs.arrivees?.c.checked;
    if (sansTirages) {
      const v = sR.valeur;
      for (const e of tirages) if (e.numero && e.rencontre && v.compteurs?.[e.rencontre]) v.compteurs[e.rencontre] -= 1;   // fois où elle a eu lieu
      v.journal = v.journal.filter(e => !idsTirages.has(e.id));
      sR.enregistrer(0);
      sR.signaler();
    }
    if (sansArrivees) {
      // Les lieux de l'itinéraire de l'activité en cours se rattraperont quand l'heure sera rejouée.
      if (act?.type === 'voyage') act.atteints = Math.max(0, act.atteints - arrivees.filter(({ x }) => x.trajet === act.id).length);
      nettoyerHistorique(sIci, { visites: arrivees.map(({ i }) => i) });
    }
    if (blocs.lancees?.c.checked) {
      const ids = new Set(lancees.map(e => e.id));
      sM.valeur.rencontres = sM.valeur.rencontres.filter(e => !ids.has(e.id));
      if (ids.has(sM.valeur.combat?.rencontre)) sM.valeur.combat = null;
      sM.enregistrer(0);
      sM.signaler();
    }
    // Le journal de l'activité en cours perd les lignes de cette heure (celles qu'on garde restent).
    if (act?.journal) act.journal = act.journal.filter(l => !dans(l.quand) || (l.arrivee ? !sansArrivees : l.id ? !sansTirages : false));
    annuler(sH);
    dlg.close();
  };
  dlg = ctx.dialogue('Horloge', `Annuler : ${dernier.motif}`, h('div', { class: 'cm-pile' },
    h('p', { class: 'ui' }, `L'horloge revient à ${libelleMoment(retourDe(sH.valeur))}. Pendant ce temps :`),
    Object.values(blocs).filter(Boolean).map(b => b.el),
    h('p', { class: 'ui-s cm-sourdine' }, 'Ce qui reste coché est défait ; décocher pour le garder.')),
  h('div', { class: 'bn-groupe' },
    bouton('Annuler', { classe: 'bn-btn--primaire', icone: 'lu-rotate-ccw', onclick: valider }),
    bouton('Ne rien changer', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
}
