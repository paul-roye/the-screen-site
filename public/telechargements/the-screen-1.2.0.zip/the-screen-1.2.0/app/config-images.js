// Images de la campagne : l'onglet « Images » de la fenêtre Campagne. Les sources de sa bibliothèque d'images (`images.sources`
// du manifeste, formats/images.md) : un livre de D&D Beyond, des documents Homebrewery, ou un dossier où le MJ range les
// siennes ; chacune dans son dossier de la bibliothèque du poste. Leur import : le serveur lance
// scripts/import-images/importer-images.ps1 en arrière-plan (<campagne>/import-images.json : GET son état, POST le lance),
// puis indexe la bibliothèque ; un livre de D&D Beyond se relève d'abord par l'extension du MJ (commande `images-livre`,
// depuis la version 1.15.0), qui en donne la liste d'images.

import { h, icone, bouton, alerte, ouvrirMenu } from './ui.js';
import { enregistrerManifeste } from './campagne.js';
import { demanderExtension } from './beyond.js';

const TYPES = {
  beyond: { nom: 'Livre D&D Beyond', icone: 'livre', aide: 'Les cartes et illustrations d\'un livre que vous possédez sur D&D Beyond. L\'extension du MJ relève ses images, avec votre session (quelques minutes : une page toutes les 4 à 8 s), puis elles se téléchargent.' },
  homebrewery: { nom: 'Homebrewery', icone: 'lu-external-link', aide: 'Les images de documents publics de homebrewery.naturalcrit.com (leurs adresses de partage, /share/…), rangées par document.' },
  dossier: { nom: 'Mes images', icone: 'lu-image', aide: 'Vos propres images : rangez-les dans ce dossier (« Ouvrir »), un sous-dossier « Cartes » pour les cartes ; « Importer » les indexe.' },
};

// manifeste : celui de la campagne ouverte, mis à jour sur place à l'enregistrement (le formulaire de l'onglet Campagne
// le relit ainsi tel quel).
export function contenuImages(manifeste) {
  let sources = structuredClone(manifeste.images?.sources || []);
  let modifie = false;
  const liste = h('div', { class: 'cm-pile' });
  const message = h('div');
  const etatServeur = h('p', { class: 'ui-s cm-sourdine' }, '…');
  const journal = h('pre', { class: 'cm-journal-import ui-s' });
  const repli = h('details', { class: 'cm-repli', hidden: true }, h('summary', { class: 'etiquette' }, 'Journal de l\'import'), journal);
  let serveur = null;     // dernier état lu (import-images.json)
  let releve = null;      // relevé d'un livre en cours : { n, texte }
  let attente = 0;        // après un lancement : quelques relectures de grâce, le temps que l'import démarre

  const dire = (couleur, titre, texte) => message.replaceChildren(couleur ? alerte(couleur, couleur === 'sang' ? 'lu-triangle-alert' : 'lu-info', titre, texte) : '');
  const date = d => new Date(d).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' });
  const champ = (libelle, input, aide) => h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, libelle), input,
    aide ? h('span', { class: 'ui-s cm-sourdine' }, aide) : null);
  const changer = () => { modifie = true; majBoutons(); };

  // Une source : son type, son dossier (qui la nomme dans le widget Images), ses champs propres ; dessous, son état et ses actions.
  function ligne(s, n) {
    const t = TYPES[s.type] || TYPES.dossier;
    const dossier = h('input', { class: 'bn-input', type: 'text', value: s.dossier || '', placeholder: 'Nom du dossier', oninput: e => { s.dossier = e.target.value.trim(); changer(); } });
    const propres = [];
    if (s.type === 'beyond') {
      propres.push(champ('Adresse du livre', h('input', { class: 'bn-input', type: 'url', value: s.adresse || '', placeholder: 'https://www.dndbeyond.com/sources/dnd/phb-2024', oninput: e => { s.adresse = e.target.value.trim(); changer(); } }),
        'Sa page d\'accueil sur D&D Beyond (la table des matières).'));
    } else if (s.type === 'homebrewery') {
      const lignes = (cle, ph) => h('textarea', { class: 'bn-textarea', rows: 3, placeholder: ph, oninput: e => { s[cle] = e.target.value.split('\n').map(x => x.trim()).filter(Boolean); changer(); } }, (s[cle] || []).join('\n'));
      propres.push(champ('Documents', lignes('pages', 'https://homebrewery.naturalcrit.com/share/…'), 'Une adresse de partage par ligne, un document par chapitre si possible.'));
      propres.push(h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `Cartes non signalées${s.cartes?.length ? ` (${s.cartes.length})` : ''}`),
        champ('Adresses d\'images', lignes('cartes', 'https://…/image.png'), 'Les images qui sont des cartes sans que leur titre le dise, une par ligne : elles vont dans « Cartes ».')));
    }
    const e = serveur?.sources?.[n];
    const infos = [
      e ? `${e.images} image${e.images > 1 ? 's' : ''}` : null,
      e?.importe_le ? `importé le ${date(e.importe_le)}` : e ? 'jamais importé' : null,
      s.type === 'beyond' ? (e?.liste === 'releve' ? 'liste relevée' : e?.liste === 'fournie' ? 'liste fournie avec le gestionnaire' : e ? 'livre pas encore relevé' : null) : null,
    ].filter(Boolean).join(' · ');
    const occupe = !!(serveur?.en_cours || releve || attente);
    const actions = [
      s.type === 'beyond' ? bouton('Relever le livre', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', titre: 'Relever à nouveau la liste des images du livre (extension du MJ), puis les télécharger', disabled: occupe, onclick: () => releverLivre(n) }) : null,
      bouton('Importer', { classe: 'bn-btn--s', icone: 'lu-download', titre: s.type === 'dossier' ? 'Indexer les images de ce dossier' : 'Télécharger les images qui manquent, puis indexer', disabled: occupe, onclick: () => importer(n) }),
      bouton('Ouvrir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-folder-open', titre: 'Ouvrir son dossier dans l\'Explorateur', onclick: () => ouvrir(n) }),
      bouton('', { classe: 'bn-btn--s bn-btn--fantome cm-source-images__retirer', icone: 'lu-trash-2', titre: 'Retirer cette source (ses images restent dans la bibliothèque)', onclick: () => { sources.splice(n, 1); changer(); rendre(); } }),
    ];
    return h('div', { class: 'cm-reglage cm-source-images' },
      h('p', { class: 'etiquette cm-section__titre' }, icone(t.icone, 'bn-icone--s'), t.nom),
      h('span', { class: 'ui-s cm-sourdine' }, t.aide),
      champ('Dossier', dossier, 'Son dossier dans la bibliothèque, et son nom dans le filtre « Source » du widget Images.'),
      propres,
      h('div', { class: 'bn-groupe' }, actions),
      releve?.n === n ? h('p', { class: 'ui-s' }, releve.texte) : infos ? h('p', { class: 'ui-s cm-sourdine' }, infos) : null);
  }

  const btnEnregistrer = bouton('Enregistrer les sources', { classe: 'bn-btn--primaire bn-btn--s', icone: 'lu-check', onclick: () => enregistrer().catch(e => dire('sang', 'Sources non enregistrées', e.message)) });
  const btnTout = bouton('Tout importer', { classe: 'bn-btn--s', icone: 'lu-download', titre: 'Importer toutes les sources, l\'une après l\'autre, puis indexer', onclick: () => importer(null) });
  const btnAjouter = bouton('Ajouter une source', { classe: 'bn-btn--s', icone: 'lu-plus', onclick: ev => ouvrirMenu(ev.currentTarget,
    Object.entries(TYPES).map(([type, t]) => [t.nom, t.aide, () => {
      sources.push({ type, dossier: type === 'dossier' ? 'Mes images' : '' });
      changer(); rendre();
    }]), 'Type de source') });
  function majBoutons() {
    btnEnregistrer.disabled = !modifie;
    btnTout.disabled = !sources.length || !!(serveur?.en_cours || releve || attente);
  }

  function verifier() {
    const vus = new Set();
    sources.forEach((s, i) => {
      const nom = `Source ${i + 1} (${TYPES[s.type]?.nom || s.type})`;
      if (!s.dossier || /[\\/:*?"<>|]/.test(s.dossier) || s.dossier.startsWith('.')) throw new Error(`${nom} : un nom de dossier simple, sans / ni \\ (« Manuel des joueurs »).`);
      if (vus.has(s.dossier.toLowerCase())) throw new Error(`${nom} : le dossier « ${s.dossier} » sert déjà à une autre source.`);
      vus.add(s.dossier.toLowerCase());
      if (s.type === 'beyond' && !/^https:\/\/www\.dndbeyond\.com\/sources\/(dnd\/)?[a-z0-9-]+\/?$/i.test(s.adresse || '')) throw new Error(`${nom} : l'adresse de la page d'accueil du livre (https://www.dndbeyond.com/sources/dnd/phb-2024, par exemple).`);
      if (s.type === 'homebrewery' && !(s.pages || []).length) throw new Error(`${nom} : au moins une adresse de document Homebrewery.`);
      if (s.type === 'homebrewery' && (s.pages || []).some(p => !/^https?:\/\//.test(p))) throw new Error(`${nom} : des adresses de documents (https://homebrewery.naturalcrit.com/share/…).`);
    });
  }
  async function enregistrer() {
    verifier();
    const m = { ...manifeste };
    if (sources.length) m.images = { ...(manifeste.images || {}), sources: structuredClone(sources) }; else delete m.images;
    await enregistrerManifeste(m);
    if (m.images) manifeste.images = m.images; else delete manifeste.images;
    modifie = false;
    dire(null);
    majBoutons();
    await lire();
  }

  async function lire() {
    const r = await fetch('import-images.json', { cache: 'no-store' }).then(x => (x.ok ? x.json() : null)).catch(() => null);
    if (!r) { etatServeur.textContent = 'État de l\'import inconnu (relancez le gestionnaire : son serveur est plus ancien que cette page).'; return; }
    const avant = serveur?.en_cours;
    serveur = r;
    if (attente > 0 && !r.en_cours) attente--; else if (r.en_cours) attente = 0;
    const enCours = r.en_cours || attente > 0;
    const derniere = (r.journal || []).at(-1)?.trim();
    etatServeur.replaceChildren(h('span', {}, 'Bibliothèque de la campagne sur ce poste : '), h('code', {}, r.bibliotheque),
      enCours ? h('span', {}, ` · import en cours${derniere ? ` : ${derniere}` : '…'}`) : '');
    journal.textContent = (r.journal || []).join('\n');
    repli.hidden = !r.journal?.length;
    if (avant && !r.en_cours && !attente) dire('brume', 'Import terminé', 'Rechargez la page pour voir les nouvelles images dans le widget Images.');
    rendre();
    if (enCours && racine.isConnected) setTimeout(lire, 2000);
  }

  // Les actions lisent le manifeste enregistré : des sources modifiées s'enregistrent d'abord.
  async function avantAction() {
    if (modifie) await enregistrer();
  }
  async function lancer(n, liste = '') {
    const r = await fetch(`import-images.json${n === null ? '' : `?source=${n}`}`, { method: 'POST', body: liste }).catch(() => null);
    if (!r?.ok) throw new Error(r ? await r.text() : 'Le serveur ne répond pas.');
    dire(null);
    attente = 5;
    setTimeout(lire, 1500);
    rendre();
  }
  async function importer(n) {
    try {
      await avantAction();
      const e = n === null ? null : serveur?.sources?.[n];
      if (n !== null && sources[n].type === 'beyond' && e && !e.liste) return releverLivre(n);
      await lancer(n);
    } catch (e) { dire('sang', 'Import non lancé', e.message); }
  }
  async function ouvrir(n) {
    try {
      await avantAction();
      const r = await fetch(`import-images.json?ouvrir=${n}`, { method: 'POST' });
      if (!r.ok) throw new Error(await r.text());
    } catch (e) { dire('sang', 'Dossier non ouvert', e.message); }
  }
  // Relevé d'un livre par l'extension du MJ, suivi toutes les 2 s, puis la liste au serveur, qui lance le téléchargement.
  async function releverLivre(n) {
    try {
      await avantAction();
      const adresse = sources[n].adresse;
      const suivre = async premier => {
        let r;
        try { r = premier || await demanderExtension({ type: 'images-livre', adresse, etat: true }); }
        catch (e) { releve = null; rendre(); return dire('sang', 'Relevé interrompu', e.message); }
        if (!r) { releve = null; rendre(); return dire('sang', 'Relevé interrompu', 'L\'extension ne suit plus ce relevé (rechargée ?) : relancez « Relever le livre ».'); }
        if (r.erreur) { releve = null; rendre(); return dire('sang', 'Relevé du livre impossible', r.erreur); }
        if (r.en_cours) {
          releve = { n, texte: `Relevé du livre par l'extension : page ${r.faites} sur ${r.pages || '…'}, ${r.images} image${r.images > 1 ? 's' : ''} (${r.cartes} carte${r.cartes > 1 ? 's' : ''}). Gardez cette page ouverte.` };
          rendre();
          if (racine.isConnected) setTimeout(() => suivre(), 2000);
          return;
        }
        releve = null;
        if (!r.liste) { rendre(); return dire('sang', 'Relevé du livre', 'Aucune image trouvée : vérifiez l\'adresse du livre et votre session D&D Beyond.'); }
        await lancer(n, r.liste);
      };
      let premier;
      try { premier = await demanderExtension({ type: 'images-livre', adresse }); }
      catch (e) {
        throw new Error(/inconnue/i.test(e.message) ? 'L\'extension du MJ doit être en version 1.15.0 au moins : rechargez-la dans chrome://extensions.' : e.message);
      }
      releve = { n, texte: 'Relevé du livre lancé…' };
      rendre();
      await suivre(premier);
    } catch (e) { releve = null; rendre(); dire('sang', 'Relevé non lancé', e.message); }
  }

  function rendre() {
    liste.replaceChildren(...(sources.length ? sources.map(ligne) : [h('p', { class: 'ui cm-sourdine' }, 'Aucune source d\'images : ajoutez-en une, ou rangez vos images à la main dans la bibliothèque.')]));
    majBoutons();
  }

  const racine = h('div', { class: 'cm-pile' },
    h('p', { class: 'ui-s cm-sourdine' }, 'Chaque source remplit son dossier de la bibliothèque d\'images, propre à ce poste (le widget Images la montre). Ce que les noms de fichiers ne disent pas (lieux, catégories) se règle dans bibliotheque.json de la campagne, ou image par image dans le widget Images.'),
    etatServeur,
    h('div', { class: 'bn-groupe' }, bouton('Ouvrir la bibliothèque', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-folder-open', onclick: async () => {
      const r = await fetch('import-images.json?ouvrir=bibliotheque', { method: 'POST' }).catch(() => null);
      if (!r?.ok) dire('sang', 'Dossier non ouvert', r ? await r.text() : 'Le serveur ne répond pas.');
    } })),
    liste,
    h('div', { class: 'bn-groupe' }, btnAjouter, btnEnregistrer, btnTout),
    message, repli);
  rendre();
  setTimeout(lire, 0);
  return racine;
}
