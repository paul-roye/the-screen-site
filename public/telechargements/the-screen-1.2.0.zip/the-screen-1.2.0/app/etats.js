// États (conditions) des héros : noms et effets en VF, icônes de D&D Beyond, écriture sur les fiches par l'extension.
// Identifiants et slugs de D&D Beyond (api/config/json, `conditions`) ; l'Épuisement va du niveau 1 au niveau 6.
// Effets : glossaire du Document de référence du système 5.2.1 (DRS, Wizards of the Coast, licence CC-BY-4.0), distances
// en pieds. Icônes : celles de Maps (le VTT de D&D Beyond), importées sur chaque poste par « outils/Importer les icônes d'états.cmd »
// dans icones-beyond/etats.json (hors dépôt) ; sans elles, l'abréviation du nom.
// Widget Personnages (portraits des cartes, fiche) ; réutilisable dans Combat.

import { h, icone, infobulle, distance, flottant, FINE } from './ui.js';
import { demanderExtension, lireBeyond } from './beyond.js';
import { etat } from './etat.js';

export const EPUISEMENT = 4;
export const NIVEAU_MAX = 6;

// gravite : ordre sur le portrait (quatre icônes au plus), le plus grave d'abord.
export const ETATS = [
  { id: 1, slug: 'blinded', nom: 'Aveuglé', court: 'Av', gravite: 8, page: 189, effets: [
    ['Incapable de voir', 'Vous ne voyez rien et ratez automatiquement tout test de caractéristique reposant sur la vue.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage, et vos jets d’attaque subissent le Désavantage.']] },
  { id: 2, slug: 'charmed', nom: 'Charmé', court: 'Ch', gravite: 10, page: 190, effets: [
    ['Ne pas nuire au charmeur', 'Vous ne pouvez pas attaquer votre « charmeur » ni le cibler avec des aptitudes ou effets magiques qui infligent des dégâts.'],
    ['Interaction avec Avantage', 'Le charmeur a l’Avantage aux tests de caractéristique d’interaction sociale avec vous.']] },
  { id: 3, slug: 'deafened', nom: 'Assourdi', court: 'As', gravite: 14, page: 188, effets: [
    ['Incapable d’entendre', 'Vous n’entendez rien et ratez automatiquement tous les tests de caractéristique qui reposent sur l’ouïe.']] },
  { id: 4, slug: 'exhaustion', nom: 'Épuisement', court: 'Ép', gravite: 6, page: 192, effets: [
    ['Niveaux d’Épuisement', 'Cet état est cumulatif. Chaque fois que vous le recevez, vous subissez 1 niveau d’Épuisement. Vous mourez quand votre niveau d’Épuisement atteint 6.'],
    ['Tests d20 affectés', 'Lorsque vous effectuez un Test d20, le résultat est réduit de 2 fois votre niveau actuel d’Épuisement.'],
    ['Vitesse réduite', 'Votre Vitesse est réduite de 5 ft × votre niveau actuel d’Épuisement.'],
    ['Suppression des niveaux d’Épuisement', 'Terminer un Repos long dissipe 1 niveau d’Épuisement. Lorsque votre niveau d’Épuisement atteint 0, l’état prend fin pour vous.']] },
  { id: 5, slug: 'frightened', nom: 'Effrayé', court: 'Ef', gravite: 9, page: 191, effets: [
    ['Effet sur les attaques et les tests de caractéristique', 'Vous subissez le Désavantage aux tests de caractéristique et aux jets d’attaque tant que la source de votre effroi est dans votre champ de vision.'],
    ['Impossible d’approcher', 'Vous ne pouvez pas vous rapprocher volontairement de la source de votre effroi.']] },
  { id: 6, slug: 'grappled', nom: 'Agrippé', court: 'Ag', gravite: 7, page: 187, effets: [
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Vous subissez le Désavantage aux jets d’attaque contre toute cible hormis l’agrippeur.'],
    ['Déplaçable', 'L’agrippeur peut vous tirer ou vous porter lorsqu’il se déplace, mais ses coûts de déplacement sont doublés, sauf si vous êtes de taille Très petite (TP) ou que votre catégorie de taille est inférieure d’au moins deux crans à la sienne.']] },
  { id: 7, slug: 'incapacitated', nom: 'Neutralisé', court: 'Ne', gravite: 5, page: 196, effets: [
    ['Inactif', 'Vous ne pouvez entreprendre ni action, ni action Bonus ni Réaction.'],
    ['Concentration brisée', 'Votre Concentration est brisée.'],
    ['Sans voix', 'Vous ne pouvez pas parler.'],
    ['Surpris', 'Si vous êtes Neutralisé au moment de jouer l’Initiative, vous subissez le Désavantage à ce jet.']] },
  { id: 8, slug: 'invisible', nom: 'Invisible', court: 'Iv', gravite: 15, page: 195, effets: [
    ['Surprise', 'Si vous êtes Invisible au moment de jouer l’Initiative, vous avez l’Avantage à ce jet.'],
    ['Dissimulé', 'Vous n’êtes pas affecté par les effets qui exigent que la cible soit vue, sauf si le créateur de l’effet vous « voit » par un biais ou un autre. Tout l’équipement que vous portez est lui aussi dissimulé.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous subissent le Désavantage, et vos jets d’attaque ont l’Avantage. Si une créature vous voit par un biais ou un autre, vous ne recevez pas ce bénéfice contre elle.']] },
  { id: 9, slug: 'paralyzed', nom: 'Paralysé', court: 'Pa', gravite: 3, page: 196, effets: [
    ['Neutralisé', 'Vous subissez l’état Neutralisé.'],
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.'],
    ['Coups critiques automatiques', 'Tout jet d’attaque qui vous touche est un Coup critique si l’assaillant qui la porte se trouve dans un rayon de 5 ft.']] },
  { id: 10, slug: 'petrified', nom: 'Pétrifié', court: 'Pé', gravite: 2, page: 197, effets: [
    ['Transformé en substance inanimée', 'Vous êtes transformé, ainsi que les objets non magiques que vous portez, en une substance inanimée et dense (généralement de la pierre). Votre poids est décuplé et vous n’êtes plus soumis au vieillissement.'],
    ['Neutralisé', 'Vous subissez l’état Neutralisé.'],
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Résistance aux dégâts', 'Vous avez la Résistance à tous les dégâts.'],
    ['Immunité contre le poison', 'Vous avez l’Immunité contre l’état Empoisonné.']] },
  { id: 11, slug: 'poisoned', nom: 'Empoisonné', court: 'Em', gravite: 11, page: 192, effets: [
    ['Effet sur les attaques et les tests de caractéristique', 'Vous subissez le Désavantage aux jets d’attaque et aux tests de caractéristique.']] },
  { id: 12, slug: 'prone', nom: 'À terre', court: 'At', gravite: 12, page: 187, effets: [
    ['Déplacement limité', 'Vos seules possibilités de déplacement sont ramper ou vous relever en dépensant la moitié de votre Vitesse (arrondie à l’inférieur), ce qui met un terme à l’état. Si votre Vitesse est de 0, vous ne pouvez pas vous relever.'],
    ['Effet sur les attaques', 'Vous subissez le Désavantage aux jets d’attaque. Un jet d’attaque contre vous reçoit l’Avantage si l’assaillant se trouve dans un rayon de 5 ft de vous. Sans cela, ce jet d’attaque subit le Désavantage.']] },
  { id: 13, slug: 'restrained', nom: 'Entravé', court: 'En', gravite: 6.5, page: 192, effets: [
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage, et vos jets d’attaque subissent le Désavantage.'],
    ['Effet sur les jets de sauvegarde', 'Vous subissez le Désavantage aux jets de sauvegarde de Dextérité.']] },
  { id: 14, slug: 'stunned', nom: 'Étourdi', court: 'Ét', gravite: 4, page: 192, effets: [
    ['Neutralisé', 'Vous subissez l’état Neutralisé.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.']] },
  { id: 15, slug: 'unconscious', nom: 'Inconscient', court: 'Ic', gravite: 1, page: 194, effets: [
    ['Inerte', 'Vous subissez les états À terre et Neutralisé, et laissez choir tout ce que vous teniez. Lorsque cet état prend fin, vous êtes toujours À terre.'],
    ['Vitesse 0', 'Votre Vitesse est de 0 et ne peut pas augmenter.'],
    ['Effet sur les attaques', 'Les jets d’attaque contre vous ont l’Avantage.'],
    ['Effet sur les jets de sauvegarde', 'Vous ratez automatiquement vos jets de sauvegarde de Force et de Dextérité.'],
    ['Coups critiques automatiques', 'Tout jet d’attaque qui vous touche est un Coup critique si l’assaillant qui la porte se trouve dans un rayon de 5 ft.'],
    ['Dénué de conscience', 'Vous n’avez pas conscience de ce qui vous entoure.']] },
];
const PAR_ID = new Map(ETATS.map(e => [e.id, e]));
export const ETATS_PAR_NOM = [...ETATS].sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));

// État d'une fiche relevée ({ id, nom, niveau } de etat/beyond.json ; les relevés d'avant la version 1.5.0 de l'extension
// n'ont que le nom) → { ...état, niveau }.
export function etatDe(e) {
  const x = PAR_ID.get(e?.id) || ETATS.find(y => y.nom === e?.nom);
  return x ? { ...x, niveau: x.id === EPUISEMENT ? e.niveau || 1 : null } : null;
}
// États d'une fiche, du plus grave au moins grave.
export const etatsDe = f => (f?.etats || []).map(etatDe).filter(Boolean).sort((a, b) => a.gravite - b.gravite);
export const nomEtat = e => (e.niveau ? `${e.nom} ${e.niveau}` : e.nom);

// ───── Icônes ─────
// Les SVG importés sont du code de D&D Beyond : relus élément par élément (formes et attributs de dessin seuls), puis
// rangés en symboles (#ddb-etat-<slug>) dans un sprite caché de la page.

const FORMES = new Set(['svg', 'g', 'path', 'circle', 'ellipse', 'rect', 'polygon', 'polyline', 'line']);
const ATTRIBUTS = new Set(['d', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'width', 'height', 'points', 'fill', 'fill-rule',
  'clip-rule', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'transform', 'opacity', 'fill-opacity', 'stroke-opacity']);
const NS = 'http://www.w3.org/2000/svg';
const disponibles = new Set();
let chargement = null;

function copiePropre(source) {
  const el = document.createElementNS(NS, source.localName);
  for (const a of source.attributes) {
    if (!ATTRIBUTS.has(a.name)) continue;
    // Couleurs : celle du texte (currentColor), pour suivre la couleur du composant.
    const v = (a.name === 'fill' || a.name === 'stroke') && a.value !== 'none' ? 'currentColor' : a.value;
    if (/url\(|javascript:/i.test(v)) continue;
    el.setAttribute(a.name, v);
  }
  for (const c of source.children) if (FORMES.has(c.localName) && c.localName !== 'svg') el.append(copiePropre(c));
  return el;
}

// Une fois par page ; sans fichier importé, les icônes de repli servent.
export function chargerIconesEtats() {
  chargement ||= (async () => {
    let j = null;
    try {
      const r = await fetch('icones-beyond/etats.json', { cache: 'no-store' });
      if (r.ok) j = await r.json();
    } catch { /* pas importées sur ce poste */ }
    if (!j?.icones) return false;
    const sprite = document.createElementNS(NS, 'svg');
    sprite.setAttribute('aria-hidden', 'true');
    sprite.style.display = 'none';
    for (const e of ETATS) {
      const texte = j.icones[e.slug];
      if (typeof texte !== 'string') continue;
      const svg = new DOMParser().parseFromString(texte, 'image/svg+xml').documentElement;
      if (svg?.localName !== 'svg' || !svg.getAttribute('viewBox')) continue;
      const symbole = document.createElementNS(NS, 'symbol');
      symbole.id = 'ddb-etat-' + e.slug;
      symbole.setAttribute('viewBox', svg.getAttribute('viewBox'));
      for (const c of svg.children) if (FORMES.has(c.localName) && c.localName !== 'svg') symbole.append(copiePropre(c));
      sprite.append(symbole);
      disponibles.add(e.slug);
    }
    document.body.append(sprite);
    return disponibles.size > 0;
  })();
  return chargement;
}

// Icône d'un état (de etatDe) : celle de D&D Beyond, sinon son abréviation. Épuisement : le niveau en exposant.
export function iconeEtat(e, classe = '') {
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'bn-etat__svg');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(NS, 'use');
  use.setAttribute('href', '#ddb-etat-' + e.slug);
  svg.append(use);
  return h('span', { class: ('bn-etat ' + classe).trim(), 'data-etat': e.slug },
    disponibles.has(e.slug) ? svg : h('span', { class: 'bn-etat__court', 'aria-hidden': 'true' }, e.court),
    e.niveau ? h('sup', { class: 'bn-etat__niveau' }, e.niveau) : null);
}

// Les états à poser sur un héros (fiche relevée), de A à Z, chacun avec son icône : ceux qu'il a déjà n'y sont pas,
// l'Épuisement au niveau suivant (jusqu'au 6). poser(id, niveau). Choix d'un menu (boutonMenu() ou ouvrirMenu() de
// app/ui.js) : fiche et portraits de Personnages, portraits de Combat.
export function choixEtats(f, poser) {
  const l = etatsDe(f);
  const epuise = l.find(e => e.id === EPUISEMENT)?.niveau || 0;
  return ETATS_PAR_NOM.filter(e => (e.id === EPUISEMENT ? epuise < NIVEAU_MAX : !l.some(x => x.id === e.id))).map(e => {
    const x = etatDe({ id: e.id, niveau: e.id === EPUISEMENT ? epuise + 1 : null });
    return [[iconeEtat({ ...x, niveau: null }), h('span', {}, nomEtat(x))], null, () => poser(x.id, x.niveau)];
  });
}

// Effets d'un état, en liste : distances en pieds (mètres et cases au survol).
const avecDistances = t => t.split(/(\d+) ft/).map((x, i) => (i % 2 ? distance(Number(x)) : x));
export function effetsEtat(e) {
  return h('dl', { class: 'cm-etat-effets' }, e.effets.flatMap(([titre, texte]) => [h('dt', { class: 'ui' }, titre), h('dd', { class: 'texte' }, avecDistances(texte))]));
}

// Un état nommé en anglais dans un texte (fiches de monstres : « the Poisoned condition »), par son slug de D&D Beyond.
export const etatAnglais = nom => ETATS.find(e => e.slug === String(nom || '').toLowerCase()) || null;
// Son explication en fenêtre, sans personnage à qui le poser (fiches de monstres, demande du MJ, 2026-10-25) : ses effets
// en français et la page du glossaire du DRS.
export function ouvrirEtat(e, depuis = null) {
  flottant('etat-regle:' + e.slug, { surtitre: 'État', titre: e.nom, depuis, largeur: 440, contenu: h('article', { class: 'cm-pile cm-etat-fiche' },
    h('div', { class: 'cm-etat-fiche__tete' }, iconeEtat(e, 'bn-etat--l'),
      e.id === EPUISEMENT ? h('p', { class: 'ui' }, `Par niveau : ${coutEpuisement(1)} (cumulatif).`) : null),
    effetsEtat(e),
    h('p', { class: 'ui-s cm-sourdine' }, 'Glossaire des règles : ',
      h('a', { class: 'bn-lien', href: `sources/FR_SRD_CC_v5.2.1.pdf#page=${e.page}`, target: '_blank', rel: 'noopener' }, `DRS 5.2.1, p. ${e.page}`))) });
}

// Épuisement : ce que coûte le niveau, en une ligne.
export const coutEpuisement = n => `−${2 * n} aux tests d20, Vitesse −${5 * n}${FINE}ft`;

// ───── Écriture sur la fiche D&D Beyond (extension, commandes « etat » et « inspiration ») ─────
// L'extension écrit, relève aussitôt les fiches (etat/beyond.json) et répond ; le widget relit alors le relevé.
// personnage : id de la fiche D&D Beyond (f.id du relevé).

export const poserEtat = (personnage, id, niveau = null) => demanderExtension({ type: 'etat', personnage, id, niveau }, 30000);
export const retirerEtat = (personnage, id) => demanderExtension({ type: 'etat', personnage, id, retirer: true }, 30000);
export const changerInspiration = (personnage, valeur) => demanderExtension({ type: 'inspiration', personnage, valeur: !!valeur }, 30000);

// ───── États d'une créature (familier, compagnon) : gardés dans le gestionnaire ─────
// D&D Beyond n'en pose pas sur les créatures : ceux-ci ne sont vus que du MJ (etat/etats-creatures.json, formats/etat.md :
// { schema, creatures: { "<id de la créature>": [{ id, nom, niveau }] } }). Personnages (carte, fiche) et Combat.

export const etatsCreatures = () => etat('etats-creatures', { schema: 1, creatures: {} });
// La créature (résumé du relevé) avec ses états du gestionnaire, lue comme une fiche par etatsDe().
export const avecEtats = (s, cr) => (cr ? { ...cr, etats: s.valeur.creatures?.[cr.id] || [] } : cr);
export function poserEtatCreature(s, cr, id, niveau = null) {
  const e = etatDe({ id, niveau });
  s.valeur.creatures ||= {};
  s.valeur.creatures[cr.id] = [...(s.valeur.creatures[cr.id] || []).filter(x => x.id !== id), { id, nom: e.nom, niveau: e.niveau }];
  s.enregistrer();
  s.signaler();
  partager(s, cr);
}
export function retirerEtatCreature(s, cr, id) {
  const l = (s.valeur.creatures?.[cr.id] || []).filter(x => x.id !== id);
  if (l.length) s.valeur.creatures[cr.id] = l; else delete s.valeur.creatures?.[cr.id];
  s.enregistrer();
  s.signaler();
  partager(s, cr);
}

// Recopiés sur D&D Beyond, dans la note de la créature (formats/note-compagnon.md), où l'extension du joueur les lit : un
// instant après le dernier changement (plusieurs clics, une seule écriture), par l'extension du MJ (commande
// etats-creature, version 1.6.0). La fiche du maître se retrouve dans le relevé (etat/beyond.json). Un échec ne défait
// rien ici (etat/etats-creatures.json fait foi) : une annonce, et la note sera refaite au prochain changement.
const partages = new Map();   // id de la créature -> minuterie
function partager(s, cr) {
  clearTimeout(partages.get(cr.id));
  partages.set(cr.id, setTimeout(async () => {
    partages.delete(cr.id);
    const etats = etatsDe(avecEtats(s, cr)).map(nomEtat);   // du plus grave au moins grave, « Épuisement 2 »
    try {
      const fiches = Object.entries((await lireBeyond()).fiches || {});
      const [personnage] = fiches.find(([, f]) => (f.creatures || []).some(c => String(c.id) === String(cr.id))) || [];
      if (!personnage) return;   // créature hors du relevé : rien à recopier
      await demanderExtension({ type: 'etats-creature', personnage, creature: cr.id, etats }, 30000);
    } catch (e) {
      document.dispatchEvent(new CustomEvent('cm:annonce', { detail: {
        cle: 'note-compagnon', titre: `${cr.nom || 'Compagnon'} : états pas recopiés sur D&D Beyond`,
        icone: 'lu-triangle-alert', couleur: 'sang',
        texte: /Demande inconnue/.test(e.message) ? 'L\'extension est plus ancienne que la version 1.6.0 : rechargez-la dans chrome://extensions.' : e.message } }));
    }
  }, 600));
}

// Rampage d'un compagnon (Flee, Mortals!), noté par le joueur dans la note de la créature (`rampage` du relevé,
// formats/note-compagnon.md) : une petite tuile rouge, des crocs. classe : cm-rampage--coin, sur le coin d'un portrait.
export const iconeRampage = (classe = '') => infobulle(h('span', { class: ('cm-rampage ' + classe).trim(), tabindex: '0', role: 'img', 'aria-label': 'Rampage' }, icone('crocs')),
  'Le joueur l\'a mis en rampage (extension du compagnon).', { titre: 'Rampage', ton: 'sang' });

// ───── Encombrement (règle variante de la fiche D&D Beyond, ou seuils de la campagne) ─────
// Calculé par le relevé (extensions/mj/resumer.js, `encombrement` de la fiche) comme le fait la fiche : poids porté, seuils
// de 5 × et 10 × la Force (doublés par une Carrure puissante), vitesses déjà réduites. Avec l'encombrement par les objets
// homebrew (fenêtre Campagne, onglet « Fiches D&D Beyond », extension 1.16.0), règle `campagne` : les seuils de la campagne,
// et la vitesse réduite par l'objet « Encumbered » ou « Heavily Encumbered » que l'extension équipe. Une tuile d'état sur le portrait,
// à côté des états : orange quand le héros est encombré, rose quand il l'est lourdement ; un clic ouvre l'explication.
export const ENCOMBREMENTS = {
  encombre: { nom: 'Encombré', effet: 'Vitesse −10 ft.' },
  lourd: { nom: 'Lourdement encombré', effet: 'Vitesse −20 ft ; désavantage aux tests de caractéristique, jets d\'attaque et jets de sauvegarde qui utilisent la Force, la Dextérité ou la Constitution.' },
};
// L'encombrement d'une fiche relevée, s'il gêne le héros (règle variante ou de la campagne), sinon null.
export const encombrementDe = f => (['variante', 'campagne'].includes(f?.encombrement?.regle) &&ENCOMBREMENTS[f.encombrement.etat] ? f.encombrement : null);
const livres = n => `${String(Math.round(n * 10) / 10).replace('.', ',')}${FINE}lb`;
export const resumeEncombrement = enc => `Porte ${livres(enc.porte)} : encombré au-delà de ${livres(enc.seuils.encombre)}, lourdement au-delà de ${livres(enc.seuils.lourd)}${enc.double ? ' (capacité doublée)' : ''}.`;

export function iconeEncombrement(enc, classe = '') {
  return h('span', { class: `bn-etat bn-etat--${enc.etat === 'lourd' ? 'lourd' : 'encombre'} ${classe}`.trim(), 'data-etat': 'encombrement' }, icone('lu-weight'));
}

// Fenêtre de l'encombrement d'un héros : où il en est, ce que ça coûte, la règle.
export function ouvrirEncombrement(f, nom, depuis = null) {
  const enc = encombrementDe(f);
  if (!enc) return;
  const e = ENCOMBREMENTS[enc.etat];
  flottant('encombrement:' + f.id, {
    surtitre: `Encombrement · ${nom}`, titre: e.nom, largeur: 440, depuis,
    contenu: h('article', { class: 'cm-pile cm-etat-fiche' },
      h('div', { class: 'cm-etat-fiche__tete' }, iconeEncombrement(enc, 'bn-etat--l'),
        h('div', { class: 'cm-pile' }, h('p', { class: 'ui' }, resumeEncombrement(enc)), h('p', { class: 'ui' }, h('b', {}, avecDistances(e.effet))))),
      h('p', { class: 'ui-s cm-sourdine' }, enc.regle === 'campagne'
        ? `Seuils de la campagne (fenêtre Campagne, onglet « Fiches D&D Beyond ») : l'extension équipe sur la fiche l'objet « ${enc.etat === 'lourd' ? 'Heavily Encumbered' : 'Encumbered'} », qui porte ces malus ; la vitesse des cartes est celle de la fiche. Le poids porté compte les sacs équipés et, selon la fiche, les pièces.`
        : 'Règle variante de l\'encombrement, choisie sur la fiche D&D Beyond. La vitesse des cartes est déjà réduite ; le poids porté compte les sacs équipés et, selon la fiche, les pièces.')),
  });
}

// La tuile, prête à poser (portrait, ligne de combat) : infobulle courte, un clic ouvre la fenêtre.
export function tuileEncombrement(f, nom, classe = '') {
  const enc = encombrementDe(f);
  if (!enc) return null;
  const ic = iconeEncombrement(enc, classe);
  const ouvrirCe = ev => { ev.stopPropagation(); ev.preventDefault(); ouvrirEncombrement(f, nom, ev.currentTarget); };
  Object.assign(ic, { tabIndex: 0, onclick: ouvrirCe, onkeydown: ev => { if (ev.key === 'Enter' || ev.key === ' ') ouvrirCe(ev); } });
  ic.setAttribute('role', 'button');
  ic.setAttribute('aria-label', `${ENCOMBREMENTS[enc.etat].nom} : le détail`);
  return infobulle(ic, `${ENCOMBREMENTS[enc.etat].effet.split(' ;')[0].replace(/\.$/, '')}. ${resumeEncombrement(enc)} Un clic : le détail.`, { titre: ENCOMBREMENTS[enc.etat].nom, ton: enc.etat === 'lourd' ? 'sang' : 'cierge' });
}
