// Rencontres aléatoires de la campagne : état (etat/rencontres.json), test d'une heure, tirage, journal. Partagé par le widget
// Rencontres et le passage du temps (app/passage.js : horloge, repos, trajets). Données : data/rencontres-aleatoires.json,
// format 3 : tables principales (1d20+1d12, par exemple), lignes à plage (jet à jet_max), renvois à des sous-tables
// (récursifs), tirage de plus dans un autre fichier de data/ (tirage_externe : une babiole), modificateurs de la procédure
// (procedure.modificateurs : des cases du contexte, comme un guide qui connaît les sentiers, qui changent le dé dans certains terrains).
// Chaque entrée du journal est enregistrée et signalée (s.signaler) : le widget Rencontres se redessine.
// Une rencontre tirée n'est qu'une proposition (décision du MJ, 2026-10-25) : ni numéro, ni compteur, ni plafond, ni babiole
// notée tant que le MJ ne l'a pas lancée (fenêtre de préparation, puis Combat) ou notée (une trouvaille). Le dé d'une ligne
// et « Rencontre » ne notent rien au journal (fermer la fenêtre, c'est n'avoir rien tiré) ; un test, lui, est noté (une heure
// a été testée), sa rencontre « proposee » jusqu'à ce qu'elle soit acceptée (accepter()) ou écartée (ecarter()).

import { identifiant } from './ui.js';
import { lancer, estFixe, auHasard, pondere, ligneDeTable } from './des.js';
import { enMinutes } from './horloge.js';
import { etatBabioles, tirables as babiolesTirables, tirerParmi, noterTirage } from './babioles.js';
import { reglage } from './campagne.js';

// Le plafond de rencontres de la campagne (fenêtre Campagne, `reglages.plafond_rencontres` : { rencontres, heures }) remplace
// celui des données ; la règle se dit alors en clair. Sans réglage : celui de rencontres-aleatoires.json.
export function plafondDe(procedure) {
  const r = reglage('plafond_rencontres', null);
  if (!(r?.rencontres >= 1 && r?.heures >= 1)) return procedure.plafond;
  return { rencontres: r.rencontres, fenetre_heures: r.heures,
    regle: `Pas plus de ${r.rencontres} rencontre${r.rencontres > 1 ? 's' : ''} toutes les ${r.heures} heures de jeu : au-delà, plus de test (réglage de la campagne).` };
}

const JOURNAL_MAX = 300;
const ESSAIS = 30;   // relances au plus quand le dé tombe sur des rencontres retirées

// contexte.terrain : « abri » (en ville, à l'intérieur : pas de test quand le temps passe), « route » ou « nature ».
// contexte.modificateurs : { <id de procedure.modificateurs>: true }.
export async function etatRencontres(etat) {
  const s = await etat('rencontres', {
    schema: 1,
    contexte: { moment: 'jour', terrain: 'route', modificateurs: {}, a_l_arret: false },
    fenetre: { debut: new Date().toISOString(), rencontres: 0 },
    journal: [], retirees: [], compteurs: {}, suivis: [],   // rencontrees[] : posé par moteurRencontres
  });
  const c = s.valeur.contexte;

  if (c) c.modificateurs ||= {};
  return s;
}

// Modificateurs cochés dans un contexte ou une entrée du journal (ids).
export const modificateursDe = x => [...Object.entries(x?.modificateurs && !Array.isArray(x.modificateurs) ? x.modificateurs : {}).filter(([, oui]) => oui).map(([id]) => id),
  ...(Array.isArray(x?.modificateurs) ? x.modificateurs : [])];

// Avec leur icône ; enfoncés, ils prennent leur couleur (abri : brume, route : soleil comme les trajets, nature : mousse).
// « Abri » plutôt que « À l'abri » : plus court (demande du MJ, 2026-10-23).
export const TERRAINS = [['abri', 'Abri', 'lu-house'], ['route', 'Route', 'lu-route'], ['nature', 'Nature', 'lu-leaf']];

// Où sont les héros en arrivant dans un lieu (type de lieux.json) : à l'abri en ville, sur la route à un carrefour ou une porte,
// en pleine nature ailleurs. Le MJ corrige s'il le faut.
export function terrainDuLieu(type) {
  if (['ville', 'cite', 'village', 'hameau', 'chateau', 'forteresse', 'manoir', 'abbaye', 'temple', 'batiment', 'auberge'].includes(type)) return 'abri';
  if (['carrefour', 'porte', 'pont', 'col'].includes(type)) return 'route';
  return type ? 'nature' : null;
}

// Fichiers de data/ visés par un tirage_externe (babioles.json), avec l'état des babioles : troisième argument de
// moteurRencontres. Un fichier illisible est laissé de côté (la rencontre sort, sans l'objet).
export async function chargerExternes(d, donnees, etat) {
  const jeux = new Set((d.tables || []).flatMap(t => (t.lignes || []).flatMap(l => (l.options || []).map(o => o.tirage_externe?.jeu).filter(Boolean))));
  const externes = {};
  for (const jeu of jeux) {
    const lect = await donnees(jeu);
    if (lect.statut !== 'ok') continue;
    externes[jeu] = { donnees: lect.donnees, s: jeu === 'babioles' ? await etatBabioles(etat, lect.donnees) : null };
  }
  return externes;
}

// Jets d'une entrée du journal : tirages[] (données au format 2), ou le tirage seul d'une entrée plus ancienne
// (format 1 : table, tirage, relances[] { jet, rencontre }).
export function jetsDe(e) {
  if (e.tirages) return e.tirages;
  if (!e.tirage && !e.relances?.length) return [];
  return [{ table: e.table, formule: e.tirage?.formule, total: e.tirage?.total ?? null, detail: e.tirage?.detail || '',
    ...(e.relances?.length ? { relances: e.relances.map(r => ({ total: r.jet, rencontres: String(r.rencontre || '').split(', ') })) } : {}) }];
}

// Nom de la ligne tirée dans l'autre fichier : son nom, sinon le début de son texte (babioles du livre).
export function nomExterne(x) {
  const t = x?.texte?.trim() || '';
  return x?.nom?.trim() || (t.length > 60 ? t.slice(0, 58) + '…' : t) || x?.id || '';
}

export const finLigne = l => l.jet_max ?? l.jet;
export const plageLigne = l => finLigne(l) !== l.jet ? `${l.jet}-${finLigne(l)}` : String(l.jet);

export function moteurRencontres(d, s, externes = {}) {
  const proc = { ...d.procedure, plafond: plafondDe(d.procedure) };
  const v = () => s.valeur;
  const fiches = new Map(d.rencontres.map(r => [r.id, r]));
  const tables = new Map(d.tables.map(t => [t.id, t]));
  const tableDe = moment => tables.get(proc.tirage.tables[moment]);
  // Deux listes : retirees[] (cachées des tables par le MJ, grisées, n'importe quelle rencontre) et rencontrees[] (uniques
  // jouées, case « Rencontrée »). L'une ou l'autre : la rencontre ne sort plus (le dé est relancé). Avant rencontrees[],
  // une unique sortie était posée dans retirees[] : elle y était cochée « Rencontrée ».
  v().rencontrees ||= v().retirees.filter(id => fiches.get(id)?.unique);
  const cachee = id => v().retirees.includes(id);
  const rencontree = id => v().rencontrees.includes(id);
  const retiree = id => cachee(id) || rencontree(id);
  const ligneDe = (t, total) => t.lignes.find(l => total >= l.jet && total <= finLigne(l));

  // Une option peut-elle encore sortir ? Une rencontre retirée, non ; un renvoi, si une ligne de la sous-table le peut.
  function disponible(o, vues = new Set()) {
    if (o.rencontre) return !retiree(o.rencontre);
    const st = tables.get(o.table);
    if (!st || vues.has(st.id)) return false;
    const suite = new Set(vues).add(st.id);
    return st.lignes.some(l => l.options.some(x => disponible(x, suite)));
  }
  const ligneDisponible = l => l.options.some(o => disponible(o));

  // Un jet dans une table (principale ou sous-table), relancé tant qu'il tombe sur une ligne dont tout est retiré.
  // Renvoie { etape: { table, formule, total, detail, relances? }, option } ; option null : pas de ligne pour ce jet
  // (un dé de modificateur, comme le d20 seul d'un guide, qui tombe à côté des lignes), ou tout ce que le dé a donné
  // est retiré (total null).
  function jeterDans(t, formule = t.de) {
    const relances = [];
    const etape = (jet, option) => ({ etape: { table: t.id, formule, total: jet?.total ?? null, detail: jet?.detail || '', ...(relances.length ? { relances } : {}) }, option });
    for (let essai = 0; essai < ESSAIS; essai++) {
      const jet = lancer(formule);
      const ligne = ligneDe(t, jet.total);
      if (!ligne) return etape(jet, null);
      const options = ligne.options.filter(o => disponible(o));
      if (options.length) return etape(jet, pondere(options));
      relances.push({ total: jet.total, detail: jet.detail, rencontres: ligne.options.map(o => o.rencontre || o.table) });
    }
    return etape(null, null);
  }

  // Suit les renvois aux sous-tables (un jet dans chacune) jusqu'à une rencontre. depart : { etape, option }.
  function derouler(depart) {
    const tirages = [depart.etape];
    let option = depart.option;
    for (let n = 0; option?.table && n < 10; n++) {
      const r = jeterDans(tables.get(option.table));
      tirages.push(r.etape);
      option = r.option;
    }
    return { tirages, option: option?.rencontre ? option : null };
  }

  function tirer(ctx) {
    const table = tableDe(ctx.moment);
    // Un modificateur coché qui a son dé dans ce terrain (un guide en pleine nature) remplace le dé de la table.
    const actifs = modificateursDe(ctx);
    const mod = (proc.modificateurs || []).find(m => actifs.includes(m.id) && m.tirage && (!m.terrains || m.terrains.includes(ctx.terrain)));
    const formule = mod ? mod.tirage : table.de;
    return derouler(jeterDans(table, formule));
  }

  // Une ligne choisie dans l'onglet Tables (« Tirer cette ligne »), d'une table principale ou d'une sous-table : l'une de
  // ses options encore disponibles, puis les sous-tables auxquelles elle renvoie.
  function tirerLigne(tableId, jet) {
    const t = tables.get(tableId);
    const ligne = t && ligneDe(t, jet);
    const options = ligne ? ligne.options.filter(o => disponible(o)) : [];
    return derouler({ etape: { table: tableId, formule: t?.de, total: ligne?.jet ?? jet, detail: '', force: true }, option: options.length ? pondere(options) : null });
  }

  function quantite(c) {
    // nom_en : pour trouver le monstre de D&D Beyond ; note_mj : la note du MJ sur ce profil (formats/rencontres-aleatoires.md).
    const noms = { nom: c.nom, ...(c.nom_en ? { nom_en: c.nom_en } : {}), ...(c.note_mj ? { note_mj: c.note_mj } : {}) };
    if (estFixe(c.quantite)) return { ...noms, formule: c.quantite, total: Number(c.quantite) };
    const j = lancer(c.quantite);
    return j ? { ...noms, formule: c.quantite, total: j.total, detail: j.detail } : { ...noms, formule: c.quantite, total: null };
  }

  // Tirage dans un autre fichier de data/ (option.tirage_externe) : le dé de la table visée, la ligne qui couvre le jet.
  // Babioles : jamais une ligne vierge, ni une babiole déjà donnée si « Écarter » est coché (comme le widget Babioles) ;
  // la babiole tirée est notée dans l'historique des tirages. Elle n'est pas donnée d'office : sa fiche s'ouvre, et le MJ
  // la donne (bouton « Donner »). Les entrées d'avant le 2026-10-15 ont pu la noter donnée (donnee: true).
  // noter : faux pour une proposition ; la babiole est notée quand la rencontre est acceptée (noterExterne).
  function tirerExterne(te, noter = true) {
    const ext = externes[te.jeu];
    const t = (ext?.donnees?.tables || []).find(x => x.id === te.table);
    if (!t) return { jeu: te.jeu, table: te.table, absent: true };
    const babioles = te.jeu === 'babioles' && ext.s;
    let r = null;
    if (babioles) r = tirerParmi(babiolesTirables(t, ext.s));
    else for (let essai = 0; essai < ESSAIS && !r; essai++) {
      const jet = lancer(t.de)?.total;
      const l = t.lignes.find(x => !x.a_remplir && jet >= x.jet && jet <= finLigne(x));
      if (l) r = { l, jet };
    }
    if (!r) return { jeu: te.jeu, table: te.table, formule: t.de, aucune: true };
    const res = { jeu: te.jeu, table: te.table, formule: t.de, jet: r.jet, id: r.l.id, nom: r.l.nom || '', texte: r.l.texte || '', note_mj: r.l.note_mj || '' };
    if (babioles && noter) noterExterne(res);
    return res;
  }
  // La babiole tirée, notée dans l'historique des tirages du widget Babioles.
  function noterExterne(x) {
    const ext = externes[x?.jeu];
    if (x?.jeu !== 'babioles' || !ext?.s || !x.id) return;
    const t = (ext.donnees?.tables || []).find(y => y.id === x.table);
    const l = t?.lignes.find(y => y.id === x.id);
    if (!l) return;
    noterTirage(ext.s, t.id, l, x.jet);
    ext.s.enregistrer(0);
    ext.s.signaler();
  }

  // La rencontre est proposée (proposee: true) : comptée seulement quand elle est acceptée.
  function resoudre(entree, option) {
    const f = fiches.get(option.rencontre);
    entree.rencontre = f.id;
    entree.quantites = (option.creatures || []).map(c => quantite(c));
    if (f.en_voyage_seulement && entree.a_l_arret) { entree.sans_effet = 'a_l_arret'; return entree; }
    entree.proposee = true;
    if (option.tirage_externe) entree.tirage_externe = tirerExterne(option.tirage_externe, false);
    if (f.sous_table) {
      const j = lancer(f.sous_table.de);
      entree.sous_table = { formule: f.sous_table.de, total: j.total, resultat: ligneDeTable(f.sous_table.lignes, j.total)?.resultat };
    }
    if (f.variantes?.length) entree.variante = auHasard(f.variantes);
    // Une unique qui sort n'est pas cachée d'office : sa fiche demande au MJ s'il la cache (et la marque rencontrée).
    return entree;
  }
  // Une rencontre qui a lieu : son numéro (la 2e sortie du corbeau-garou…), et elle compte dans la fenêtre du plafond.
  function compter(entree, cle) {
    v().compteurs[cle] = (v().compteurs[cle] || 0) + 1;
    entree.numero = v().compteurs[cle];
    v().fenetre.rencontres++;
  }

  function completer(e, t) {
    e.tirages = t.tirages;
    if (t.option) resoudre(e, t.option);
    else e.aucune = true;
  }

  // ctx : { moment, terrain, modificateurs, a_l_arret } ; horloge : { jour, minute } de jeu, si on la connaît.
  function nouvelleEntree(type, ctx, horloge) {
    const mods = modificateursDe(ctx);
    return { id: identifiant(), quand: new Date().toISOString(), ...(horloge ? { horloge } : {}),
      type, moment: ctx.moment, terrain: ctx.terrain, ...(mods.length ? { modificateurs: mods } : {}), a_l_arret: ctx.a_l_arret, note: '' };
  }

  function consigner(entree) {
    v().journal.push(entree);
    if (v().journal.length > JOURNAL_MAX) v().journal.splice(0, v().journal.length - JOURNAL_MAX);
    s.enregistrer(0);
    s.signaler();
    return entree;
  }

  // Plafond : « deux rencontres dans les 12 dernières heures ». Quand l'heure de jeu est connue, on compte dans le journal
  // les rencontres qui ont eu lieu (numérotées) dans les 12 heures de jeu précédentes ; sinon, le compteur de la fenêtre
  // en temps réel (bouton « Nouvelle fenêtre » du widget).
  const FENETRE = proc.plafond.fenetre_heures * 60;
  function rencontresDansFenetre(horloge) {
    if (!horloge) return v().fenetre.rencontres;
    const t = enMinutes(horloge);
    return v().journal.filter(e => e.numero && e.horloge && enMinutes(e.horloge) <= t && t - enMinutes(e.horloge) < FENETRE).length;
  }
  const plafondAtteint = horloge => rencontresDansFenetre(horloge) >= proc.plafond.rencontres;

  // Un test d'une heure. Plafond atteint : pas de test, rien n'est noté ({ plafond: true }). Réussi : sa rencontre est proposée
  // sur la même ligne du journal.
  function tester(ctx, horloge = null) {
    if (plafondAtteint(horloge)) return { plafond: true };
    const e = nouvelleEntree('test', ctx, horloge);
    const jet = lancer(proc.test.de).total;
    const seuil = proc.test.seuil[ctx.terrain] ?? proc.test.seuil.route;
    e.test = { jet, seuil, reussi: jet >= seuil };
    if (e.test.reussi) completer(e, tirer(ctx));
    return consigner(e);
  }

  // « Rencontre » : une rencontre tirée sans test. Rien n'est noté : le journal ne la prend que si elle est acceptée.
  function tirerDirect(ctx, horloge = null) {
    const e = nouvelleEntree('rencontre', ctx, horloge);
    completer(e, tirer(ctx));
    return e;
  }

  // « Tirer cette ligne » (onglet Tables) : comme « Rencontre », mais sur la ligne choisie.
  function tirerLigneChoisie(ctx, tableId, jet, horloge = null) {
    const e = nouvelleEntree('rencontre', ctx, horloge);
    completer(e, tirerLigne(tableId, jet));
    return e;
  }

  // La rencontre proposée a lieu (lancée en Combat, ou notée) : numérotée, comptée dans le plafond, babiole notée. Une
  // proposition qui n'est pas au journal (dé d'une ligne, « Rencontre ») y entre, à l'heure de jeu donnée (horloge).
  function accepter(e, horloge = null) {
    if (!e?.proposee) return e;
    delete e.proposee;
    compter(e, e.rencontre);
    noterExterne(e.tirage_externe);
    if (v().journal.includes(e)) { s.enregistrer(0); s.signaler(); return e; }
    Object.assign(e, { quand: new Date().toISOString(), ...(horloge ? { horloge } : {}) });
    return consigner(e);
  }
  // Le MJ écarte la rencontre d'un test réussi : le test reste noté, la rencontre n'a pas lieu.
  function ecarter(e) {
    delete e.proposee;
    e.ecartee = true;
    s.enregistrer(0);
    s.signaler();
  }

  // Un événement de campagne (data/evenements.json, bouton du widget Rencontres) que le MJ ajoute comme rencontre : il compte
  // dans le plafond comme une rencontre tirée (numéroté, dans la fenêtre).
  function ajouterEvenement(ev, ctx, horloge = null) {
    const e = nouvelleEntree('evenement', ctx, horloge);
    e.evenement = { id: ev.id, nom: ev.nom };
    compter(e, `evenement:${ev.id}`);
    return consigner(e);
  }

  // Une rencontre a vraiment lieu (pas un test raté, ni une rencontre sans effet à l'arrêt), ou un événement ajouté. Les lignes
  // « espions » viennent de l'ancien bouton Espions (retiré le 2026-10-24) ; elles comptent encore.
  // Proposée ou écartée : elle n'a pas (encore) eu lieu.
  const aLieu = e => e.type === 'espions' || e.type === 'evenement' || (!!e.rencontre && !e.sans_effet && !e.proposee && !e.ecartee);
  // Une rencontre est sortie (proposée ou acceptée) : sa fenêtre s'ouvre, le temps qui passe s'arrête.
  const sortie = e => aLieu(e) || !!e.proposee;

  // Résumé d'une ligne de journal : « Loups · 3 loup », « Babiole : Médaillon terni », « Test 12 (<15) » (12 au d20, il
  // fallait 15 ou plus)…
  function resume(e) {
    if (e.type === 'espions') return 'Espions';
    if (e.type === 'evenement') return e.evenement?.nom || 'Événement';
    if (e.test && !e.test.reussi) return `Test ${e.test.jet} (<${e.test.seuil})`;
    if (e.aucune) return 'Pas de rencontre';
    const f = fiches.get(e.rencontre);
    const q = (e.quantites || []).map(x => `${x.total ?? x.formule} ${x.nom}`).join(', ');
    const objet = e.tirage_externe?.id ? nomExterne(e.tirage_externe) : '';
    return (f?.nom || e.rencontre) + (objet ? ` : ${objet}` : '') + (q ? ` · ${q}` : '') + (e.sans_effet ? ' (à l\'arrêt : sans effet)' : '')
      + (e.proposee ? ' (pas encore lancée)' : e.ecartee ? ' (écartée)' : '');
  }

  // Cacher (ou remettre) une rencontre des tables ; marquer une unique rencontrée, ce qui la cache aussi (décocher la
  // remet dans les tables).
  function cacher(id, oui = !cachee(id)) {
    v().retirees = v().retirees.filter(x => x !== id);
    if (oui) v().retirees.push(id);
  }
  function marquerRencontree(id, oui = !rencontree(id)) {
    v().rencontrees = v().rencontrees.filter(x => x !== id);
    if (oui) v().rencontrees.push(id);
    cacher(id, oui);
  }

  return { proc, fiches, tables, tableDe, ligneDe, disponible, retiree, cachee, rencontree, cacher, marquerRencontree, ligneDisponible, quantite, tester, tirerDirect, tirerLigneChoisie,
    consigner, resume, aLieu, sortie, plafondAtteint, rencontresDansFenetre, externes, ajouterEvenement, accepter, ecarter };
}

// Défaire une rencontre qui a eu lieu (annulée dans Combat, supprimée, ligne effacée du journal) : son numéro, le compteur et
// la fenêtre du plafond sont rendus ; la ligne d'un test reste (l'heure a été testée), sa rencontre écartée ; une autre ligne
// est retirée du journal. s : l'état de etat/rencontres.json (etatRencontres). garderLigne : ne rendre que le compte.
export function defaireRencontre(s, id, { garderLigne = false } = {}) {
  const v = s.valeur;
  const e = v.journal.find(x => x.id === id);
  if (!e) return;
  if (e.numero) {
    const cle = e.type === 'evenement' ? `evenement:${e.evenement?.id}` : e.rencontre;
    if (v.compteurs?.[cle]) v.compteurs[cle] -= 1;
    if (!e.horloge && v.fenetre?.rencontres > 0) v.fenetre.rencontres -= 1;
    delete e.numero;
  }
  if (e.test || garderLigne) { delete e.proposee; if (e.rencontre) e.ecartee = true; }
  else v.journal = v.journal.filter(x => x !== e);
  s.enregistrer(0);
  s.signaler();
}
