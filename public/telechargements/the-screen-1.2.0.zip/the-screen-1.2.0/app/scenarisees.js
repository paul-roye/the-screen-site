// Rencontres scénarisées (rencontres-aleatoires.json, rencontres_scenarisees[]) : où elles se passent, et leur ordre dans
// la campagne d'après les jalons. Leur fiche, leur préparation et leur menu : app/rencontres-mj.js.

import { nomLieu, nomComplet } from './lieux.js';

// Où se passe la rencontre : « A → B » (de, vers), « vers B », le lieu (« Lieu – Sous-lieu » ; précisé après le trajet s'il
// y a les deux, pour un carrefour en chemin), sinon le libellé « trajet » du fichier.
export function ouScenarisee(r, lieux) {
  const trajet = r.de && r.vers ? `${nomLieu(lieux, r.de)} → ${nomLieu(lieux, r.vers)}` : r.vers ? `Vers ${nomLieu(lieux, r.vers)}` : '';
  const lieu = r.lieu ? nomComplet(lieux, r.lieu, r.sous_lieu) : '';
  return [trajet, lieu].filter(Boolean).join(' · ') || r.trajet || '';
}

// Jalons du déroulé dans l'ordre de la campagne (ordre conseillé des étapes qui les ouvrent, puis rang).
export function jalonsDansLOrdre(deroule) {
  if (!deroule?.jalons?.length) return [];
  const etapes = [...(deroule.etapes || [])].sort((a, b) => a.ordre - b.ordre).map(e => e.id);
  const place = j => etapes.indexOf(j.etape);
  return [...deroule.jalons].sort((a, b) => place(a) - place(b) || a.rang - b.rang);
}

// Map id de rencontre scénarisée -> { rang, jalon } ou { rang, etape } : le premier jalon qui la cite, dans l'ordre de la
// campagne ; sinon, pour une rencontre sur place (lieu, sans de ni vers), la première étape dont les lieux contiennent son
// lieu (après les jalons de cette étape). Les autres n'y sont pas : elles vont à la fin.
export function ordreDesScenarisees(deroule, scenarisees = []) {
  const ordre = new Map();
  const etapes = [...(deroule?.etapes || [])].sort((a, b) => a.ordre - b.ordre);
  const place = id => etapes.findIndex(e => e.id === id);
  for (const j of jalonsDansLOrdre(deroule)) {
    for (const id of j.rencontres || []) if (!ordre.has(id)) ordre.set(id, { rang: place(j.etape) * 1000 + (j.rang || 0), jalon: j });
  }
  for (const r of scenarisees) {
    if (ordre.has(r.id) || !r.lieu || r.de || r.vers) continue;
    const i = etapes.findIndex(e => (e.lieux || []).includes(r.lieu));
    if (i >= 0) ordre.set(r.id, { rang: i * 1000 + 999, etape: etapes[i] });
  }
  return ordre;
}
