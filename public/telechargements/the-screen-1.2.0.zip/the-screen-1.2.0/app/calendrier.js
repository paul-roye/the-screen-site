// Calendrier de la campagne et météo (formats/calendrier.md, formats/meteo.md) : ceux que fournit le gestionnaire
// (modeles/calendriers/, modeles/meteos/ ; le calendrier classique est calculé ici), ou ceux importés dans data/.
// Calculs sans état : date d'un jour de campagne, jour de la semaine, saison, lune, jours marqués, météo d'un créneau.
// app/horloge.js les charge et s'en sert (Horloge, Trajets, Rencontres, fin de session) ; app/donnees.js recalcule ici les
// `exemples` d'un calendrier importé. En bas : l'affichage partagé de la météo (icône, température, rappel).

import { h, icone, infobulle, FINE } from './ui.js';
import { reglage, vocabulaire } from './campagne.js';

const mod = (a, n) => ((a % n) + n) % n;

// ───── Dates ─────

// Rang d'une date dans le compte des jours : 0 = 1er Janenvar de `annee.premier_jour.annee`. null si le mois est inconnu.
export function rangDate(cal, { annee, mois, jour }) {
  const i = cal.mois.findIndex(m => m.id === mois);
  if (i < 0) return null;
  const avant = cal.mois.slice(0, i).reduce((a, m) => a + m.jours, 0);
  return (annee - cal.annee.premier_jour.annee) * cal.annee.jours + avant + jour - 1;
}

// Date d'un rang : { rang, annee, mois (élément de `mois`), jour, semaine (élément de `semaine`), sansSemaine, suffixe }.
// sansSemaine : le jour de la semaine ne se dit pas dans la date (`semaine_dans_la_date` faux : les dizaines de Harptos) ;
// suffixe : celui de l'année (« CV »).
function dateDuRang(cal, rang) {
  let reste = mod(rang, cal.annee.jours);
  let mois = cal.mois.at(-1);
  for (const m of cal.mois) {
    if (reste < m.jours) { mois = m; break; }
    reste -= m.jours;
  }
  const premier = cal.semaine.findIndex(j => j.id === cal.annee.premier_jour.jour_semaine);
  return {
    rang,
    annee: cal.annee.premier_jour.annee + Math.floor(rang / cal.annee.jours),
    mois,
    jour: reste + 1,
    semaine: cal.semaine[mod(premier + rang, cal.semaine.length)],
    sansSemaine: cal.semaine_dans_la_date === false,
    suffixe: cal.annee.suffixe || '',
  };
}

// Jour de campagne n -> date (jour 1 : `debut_campagne`, la date de départ choisie pour la campagne). Avant le jour 1, on recule de même.
export function dateDuJour(cal, n) {
  return dateDuRang(cal, rangDate(cal, cal.debut_campagne) + n - cal.debut_campagne.jour_campagne);
}

// « Lundi 6 octobre » : sans l'année, que l'Horloge montre déjà après le jour de campagne. Un jour de fête hors des
// mois (`fete`, Harptos) se dit par son nom seul (« Herbeverte ») ; sans semaine dans la date, « 3 Marpenoth ».
export const libelleDate = d => (d.mois.fete ? d.mois.nom : `${d.sansSemaine ? '' : `${d.semaine.nom} `}${d.jour} ${d.mois.nom}`);
// « Lundi 6 octobre 1009 », « 3 Marpenoth 1492 CV »
export const libelleDateComplete = d => `${libelleDate(d)} ${d.annee}${d.suffixe ? ` ${d.suffixe}` : ''}`;

// Saison d'une date : celle dont le début est passé (la dernière de l'année avant le premier début).
export function saisonDe(cal, d) {
  const an = cal.annee.premier_jour.annee;
  const debuts = (cal.saisons || [])
    .map(s => ({ s, r: rangDate(cal, { annee: an, ...s.debut }) }))
    .filter(x => x.r !== null)
    .sort((a, b) => a.r - b.r);
  const r = mod(d.rang, cal.annee.jours);
  return (debuts.filter(x => x.r <= r).at(-1) || debuts.at(-1))?.s || null;
}

// ───── Calendriers fournis (réglage `calendrier` du manifeste : formats/campagne.md) ─────

// Tous ont 365 jours (décision du MJ, 2026-10-24), ce qui pose une météo réelle sur deux ans sans décalage.
// `fichier` : modeles/calendriers/<id>.json ; le classique est calculé ici.
export const CALENDRIERS = [
  { id: 'classique', nom: 'Classique', description: 'Douze mois, du lundi au dimanche, la lune de chez nous.' },
  { id: 'barovien', nom: 'Barovien', description: 'Curse of Strahd : treize mois qui commencent à la pleine lune, une semaine entre le Seigneur matinal et les Dames, l\'anniversaire de Strahd et le mariage maudit.' },
  { id: 'royaumes-oublies', nom: 'Royaumes oubliés', description: 'Le calendrier de Harptos : douze mois de trois dizaines, cinq fêtes, le Calendrier des Vaux.' },
];
export const MODELES_CALENDRIERS = '/modeles/calendriers/';

// Les réglages du temps d'un manifeste (`calendrier`, `meteo`), aux noms d'aujourd'hui ; ceux de la première version
// (« classique », « fichier ») se lisent encore. Sans réglage : le calendrier et la météo importés, s'ils existent.
export function reglagesTemps(m = {}) {
  const c = m.calendrier || {}, x = m.meteo || {};
  const calendrier = c.type === 'classique' ? { type: 'modele', modele: 'classique', debut: c.debut }
    : c.type === 'modele' || c.type === 'aucun' ? { ...c }
      : { ...c, type: 'importe' };
  const meteo = x.type === 'modele' || x.type === 'aucune' ? { ...x } : { ...x, type: 'importe' };
  return { calendrier, meteo };
}

// Un calendrier fourni, sa date de départ posée : `debut` ({ annee, mois, jour } du manifeste), sinon le départ conseillé
// du calendrier, sinon le 1er jour de son année de référence. null s'il est introuvable.
export async function chargerModeleCalendrier(id, debut) {
  if (id === 'classique') return calendrierClassique(debut);
  const cal = await fetch(`${MODELES_CALENDRIERS}${encodeURIComponent(id)}.json`).then(r => (r.ok ? r.json() : null)).catch(() => null);
  return cal ? avecDebut(cal, debut) : null;
}
export function avecDebut(cal, debut) {
  const d = debut?.mois ? debut : cal.debut_conseille?.mois ? cal.debut_conseille : cal.debut_campagne?.mois ? cal.debut_campagne
    : { annee: cal.annee.premier_jour.annee, mois: cal.mois[0].id, jour: 1 };
  const m = cal.mois.find(x => x.id === d.mois) || cal.mois[0];
  return { ...cal, debut_campagne: { jour_campagne: 1, annee: Number.isInteger(d.annee) ? d.annee : cal.annee.premier_jour.annee, mois: m.id, jour: Math.min(Math.max(1, d.jour | 0), m.jours) } };
}

// Le calendrier classique : douze mois, semaine du lundi au dimanche, sans année bissextile (365 jours, février en a 28),
// lune de 29,53 jours, saisons, équinoxes et solstices. Rendu au format de calendrier.json, pour que tout le reste s'en
// serve comme d'un fichier. `debut` : la date du jour de campagne 1.
const MOIS_CLASSIQUES = [['janvier', 'janvier', 31], ['fevrier', 'février', 28], ['mars', 'mars', 31], ['avril', 'avril', 30],
  ['mai', 'mai', 31], ['juin', 'juin', 30], ['juillet', 'juillet', 31], ['aout', 'août', 31], ['septembre', 'septembre', 30],
  ['octobre', 'octobre', 31], ['novembre', 'novembre', 30], ['decembre', 'décembre', 31]];
const JOURS_CLASSIQUES = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
export const MOIS_DU_CALENDRIER_CLASSIQUE = MOIS_CLASSIQUES.map(([id, nom, jours]) => ({ id, nom, jours }));

export function calendrierClassique(debut = {}) {
  const annee = Number.isInteger(debut.annee) ? debut.annee : 1;
  const mois = MOIS_CLASSIQUES.some(([id]) => id === debut.mois) ? debut.mois : 'janvier';
  const jour = Math.min(Math.max(1, debut.jour | 0), MOIS_CLASSIQUES.find(([id]) => id === mois)[2]);
  // Le 1er janvier tombe le même jour de la semaine que dans le vrai calendrier (quand l'année existe).
  const premier = new Date(Date.UTC(2000, 0, 1));
  premier.setUTCFullYear(annee);
  const cal = {
    id: 'classique', titre: 'Calendrier Classique',
    presentation: 'Le calendrier de tous les jours : douze mois, une semaine du lundi au dimanche. Sans années bissextiles.',
    annee: { jours: 365, premier_jour: { annee, jour_semaine: JOURS_CLASSIQUES[(premier.getUTCDay() + 6) % 7] } },
    debut_campagne: { jour_campagne: 1, annee, mois, jour },
    semaine: JOURS_CLASSIQUES.map((id, i) => ({ id, ordre: i + 1, nom: id })),   // en minuscules, comme en français : « le lundi 9 mai »
    mois: MOIS_CLASSIQUES.map(([id, nom, jours], i) => ({ id, ordre: i + 1, nom, jours, equivalent: nom })),
    saisons: [['printemps', 'Printemps', 'mars', 21], ['ete', 'Été', 'juin', 21], ['automne', 'Automne', 'septembre', 22], ['hiver', 'Hiver', 'decembre', 21]]
      .map(([id, nom, m, j]) => ({ id, nom, debut: { mois: m, jour: j } })),
    lune: {
      regle: 'Une lunaison dure 29 jours et demi ; la pleine lune éclaire trois nuits (la veille, la nuit même et le lendemain).',
      cycle: { jours: 29.53, pleine: { annee, mois: 'janvier', jour: 11 } },
      phases: [[2, 6, 'Lune gibbeuse décroissante'], [7, 8, 'Dernier quartier'], [9, 13, 'Dernier croissant'], [14, 15, 'Nouvelle lune'],
        [16, 20, 'Premier croissant'], [21, 22, 'Premier quartier'], [23, 29, 'Lune gibbeuse croissante']].map(([du, au, nom]) => ({ du, au, nom })),
    },
    types_jours_marques: { equinoxe: 'Équinoxe', solstice: 'Solstice' },
    jours_marques: [
      ['equinoxe-printemps', 'Équinoxe de printemps', 'equinoxe', 'mars', 20, 'Le jour et la nuit ont la même durée ; les jours rallongent.'],
      ['solstice-ete', 'Solstice d\'été', 'solstice', 'juin', 21, 'Le jour le plus long de l\'année.'],
      ['equinoxe-automne', 'Équinoxe d\'automne', 'equinoxe', 'septembre', 22, 'Le jour et la nuit ont la même durée ; les nuits rallongent.'],
      ['solstice-hiver', 'Solstice d\'hiver', 'solstice', 'decembre', 21, 'La nuit la plus longue de l\'année.'],
    ].map(([id, nom, type, m, j, texte]) => ({ id, nom, type, mois: m, jour: j, texte })),
  };
  return cal;
}

// ───── Lune : le calendrier seul (décision du MJ, 2026-10-13) ─────

// Lune de la nuit qui commence le soir du jour de campagne n. Deux règles, selon le calendrier :
// - `lune.cycle` ({ jours, pleine : une date de pleine lune }) : une lunaison de `jours` jours, sans lien avec les mois ;
//   `phases[].du` et `au` sont alors l'âge de la lune, en jours depuis la pleine lune ;
// - sinon, pleine le `pleine_lune.jour_du_mois` (le 1er) de chaque mois (le calendrier Barovien), et `phases` suit le jour du mois.
// Pleine lune trois nuits : la veille, la nuit même et le lendemain.
// { nom, pleine, dans, prochaine } : dans = jours jusqu'au prochain jour de pleine lune, prochaine = sa date.
function luneDuCycle(cal, n) {
  const c = cal.lune.cycle;
  const rang = dateDuJour(cal, n).rang;
  const age = mod(rang - rangDate(cal, c.pleine), c.jours);   // jours depuis la dernière pleine lune
  const pleine = age < 1.5 || age > c.jours - 1.5;
  const dans = pleine ? 0 : Math.max(1, Math.round(c.jours - age));
  const phase = (cal.lune.phases || []).find(p => Math.floor(age) >= p.du && Math.floor(age) <= p.au);
  return { nom: pleine ? 'Pleine lune' : phase?.nom || 'Lune', pleine, dans, prochaine: dateDuJour(cal, n + dans), avancement: age / c.jours };
}

export function luneDuJour(cal, n) {
  if (cal.lune?.cycle?.jours > 0 && cal.lune.cycle.pleine) return luneDuCycle(cal, n);
  const jp = cal.lune?.pleine_lune?.jour_du_mois || 1;
  const phases = cal.lune?.phases || [];
  const pleine = [-1, 0, 1].some(k => dateDuJour(cal, n + k).jour === jp);
  let dans = 1;
  while (dans < 60 && dateDuJour(cal, n + dans).jour !== jp) dans++;
  const d = dateDuJour(cal, n);
  const jour = pleine ? jp : d.jour;
  const phase = phases.find(p => jour >= p.du && jour <= p.au);
  // avancement : la part du cycle écoulée depuis la pleine lune (0 : pleine, 0,5 : nouvelle), pour dessiner la phase.
  const cycle = d.mois?.jours || 28;
  return { nom: phase?.nom || (pleine ? 'Pleine lune' : 'Lune'), pleine, dans: pleine ? 0 : dans, prochaine: dateDuJour(cal, n + dans), avancement: mod(d.jour - jp, cycle) / cycle };
}

// ───── Jours marqués (équinoxes, solstices, fêtes et anniversaires du calendrier ou de la campagne) ─────

// Prochaine occurrence de chaque jour marqué, à partir du jour de campagne n (compris), de la plus proche à la plus lointaine.
// { jm, date, dans, numero } : dans = 0 le jour même ; numero = numéro d'anniversaire (année − `depuis`). `tous_les` : un jour
// qui ne revient que les années multiples de ce nombre (la Rencontre des boucliers, tous les quatre ans).
export function joursMarques(cal, n) {
  const d = dateDuJour(cal, n);
  return (cal.jours_marques || []).map(jm => {
    const tous = jm.tous_les > 1 ? jm.tous_les : 1;
    let an = d.annee, rang = rangDate(cal, { annee: an, mois: jm.mois, jour: jm.jour });
    if (rang === null) return null;
    while (rang < d.rang || mod(an, tous) !== 0) { an += 1; rang = rangDate(cal, { annee: an, mois: jm.mois, jour: jm.jour }); }
    const date = dateDuRang(cal, rang);
    return { jm, date, dans: rang - d.rang, numero: jm.depuis ? date.annee - jm.depuis : null };
  }).filter(Boolean).sort((a, b) => a.dans - b.dans);
}

// « Anniversaire du roi (40e) »
export const nomJourMarque = x => `${x.jm.nom}${x.numero ? ` (${x.numero}e)` : ''}`;

// ───── Météo ─────

export const NOMS_CRENEAUX = { nuit: 'Nuit', matin: 'Matin', 'apres-midi': 'Après-midi', soir: 'Soir' };
const minutesDe = t => { const [hh, mm] = String(t).split(':').map(Number); return hh * 60 + (mm || 0); };
const heureDe = t => `${minutesDe(t) / 60 | 0}${FINE}h`;

const index = new WeakMap();
// Météo du jour de campagne n : l'entrée de `jours`, ou null (jour sans météo : rien à afficher).
export function meteoDuJour(meteo, n) {
  if (meteo.jourDe) return meteo.jourDe(n);
  if (!index.has(meteo)) index.set(meteo, new Map((meteo.jours || []).map(j => [j.jour_campagne, j])));
  return index.get(meteo).get(n) || null;
}

// Un relevé réel (meteo.json de type « releve », ou une météo fournie de modeles/meteos/ : deux années civiles d'une vraie
// ville, 2009 et 2010, par date réelle) posé sur la campagne, jour après jour (décision du MJ, 2026-10-24) :
// - avec un calendrier : le premier jour du relevé (le 1er janvier) tombe le 1er du mois de même équivalent (Janenvar,
//   Martel, janvier), le dernier avant le jour de campagne 1 : l'année du jour 1 prend la première année du relevé, jour
//   pour jour (le 279e jour de l'année du calendrier prend le 6 octobre 2009), la suivante la seconde ;
// - sans calendrier : le jour 1 prend `debut` (« MM-JJ » dans la première année du relevé ; son premier jour par défaut).
// Au bout du relevé, on repart à son début : deux années de suite, puis la première de nouveau. Tous les calendriers ont
// 365 jours, comme les années du relevé (sans 29 février).
// Rend un objet qui se lit comme meteo.json (meteoDuJour, meteoA…), avec `jourDe(n)`.
export function meteoSurCampagne(releve, cal, { debut = '' } = {}) {
  const jours = [...(releve.jours || [])].sort((a, b) => a.date_reelle.localeCompare(b.date_reelle));
  if (!jours.length) return null;
  const deux = x => String(x).padStart(2, '0');
  const premier = jours[0].date_reelle;
  let ancre = 0;   // rang de calendrier, ou index du relevé, du jour de campagne 1
  if (cal) {
    const d1 = dateDuJour(cal, 1);
    const moisReel = MOIS_CLASSIQUES[Number(premier.slice(5, 7)) - 1];
    const m = cal.mois.find(x => !x.fete && sansAccents(x.equivalent) === moisReel[0]);
    const ancreDe = an => rangDate(cal, { annee: an, mois: m.id, jour: Math.min(Number(premier.slice(8, 10)), m.jours) });
    ancre = m ? (ancreDe(d1.annee) <= d1.rang ? ancreDe(d1.annee) : ancreDe(d1.annee - 1)) : d1.rang;
  } else if (/^\d{2}-\d{2}$/.test(debut || '')) {
    const i = jours.findIndex(j => j.date_reelle.slice(5) === debut);
    if (i >= 0) ancre = i;
  }
  const rangDuJour = n => (cal ? mod(dateDuJour(cal, n).rang - ancre, jours.length) : mod(ancre + n - 1, jours.length));
  return {
    ...releve,
    jourDe: n => {
      const i = sur(() => rangDuJour(n));
      return i === null || i === undefined ? null : { ...jours[i], jour_campagne: n };
    },
  };
}
const sur = f => { try { return f(); } catch { return null; } };
// « Août » -> « aout » (les `id` des mois du calendrier classique).
const sansAccents = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

// Météo à l'heure de jeu t ({ jour, minute }) : { jour, creneau, nom, plage } (jour et créneau : entrées du fichier ;
// nom : « Matin » ; plage : « 6 h – 12 h »), ou null.
export function meteoA(meteo, t) {
  const j = meteoDuJour(meteo, t.jour);
  const def = (meteo.creneaux || []).find(c => t.minute >= minutesDe(c.debut) && t.minute < minutesDe(c.fin));
  const c = def && j?.creneaux?.find(x => x.creneau === def.id);
  if (!c) return null;
  return { jour: j, creneau: c, nom: NOMS_CRENEAUX[c.creneau] || c.creneau, plage: `${heureDe(def.debut)} – ${heureDe(def.fin)}` };
}

// La météo d'un jour de campagne en texte, pour un compte rendu (fin de journée, prompt de fin de session) : le résumé du
// jour, puis chaque créneau (« Matin (6 h – 12 h) : pluie faible, 3 à 7 °C »). null : jour sans météo.
export function meteoDeLaJournee(meteo, n) {
  const j = meteoDuJour(meteo, n);
  if (!j) return null;
  const creneaux = (meteo.creneaux || []).map(def => {
    const c = j.creneaux?.find(x => x.creneau === def.id);
    return c ? `${NOMS_CRENEAUX[c.creneau] || c.creneau} (${heureDe(def.debut)} – ${heureDe(def.fin)}) : ${c.texte}, ${libelleTemperature(c.min, c.max)}` : null;
  }).filter(Boolean);
  // texte : le tout sur une ligne, le résumé sans son point final.
  return { jour: j, resume: j.resume || '', creneaux, texte: [(j.resume || '').replace(/\.\s*$/, ''), ...creneaux].filter(Boolean).join(' ; ') };
}

// −3 -> « −3 » (signe moins typographique)
const degres = n => `${n < 0 ? '−' : ''}${Math.abs(n)}`;
// « 7 °C », « −3 à 1 °C »
export const libelleTemperature = (min, max) => `${min === max ? degres(max) : `${degres(min)} à ${degres(max)}`}${FINE}°C`;

// Icône du ciel (Lucide) : la précipitation d'abord, sinon le ciel. Une campagne au ciel toujours voilé (réglage `ciel_voile`
// du manifeste) n'a jamais de soleil : un ciel dégagé y reste un nuage, la nuit il laisse deviner la lune.
const ICONES_PRECIPITATION = {
  bruine: 'lu-cloud-drizzle', pluie: 'lu-cloud-rain', averses: 'lu-cloud-rain-wind',
  verglacante: 'lu-cloud-hail', neige: 'lu-cloud-snow', neige_forte: 'lu-snowflake',
};
const ICONES_CIEL = { degage: 'lu-cloud', peu_nuageux: 'lu-cloud', nuageux: 'lu-cloudy', couvert: 'lu-cloudy', nuages_bas: 'lu-cloudy', brouillard: 'lu-cloud-fog' };
const ICONES_CIEL_CLAIR = { degage: ['lu-sun', 'lu-moon'], peu_nuageux: ['lu-cloud-sun', 'lu-cloud-moon'] };
export function iconeMeteo(c, nuit = false) {
  if (ICONES_PRECIPITATION[c.precipitation]) return ICONES_PRECIPITATION[c.precipitation];
  if (!reglage('ciel_voile', false) && ICONES_CIEL_CLAIR[c.ciel]) return ICONES_CIEL_CLAIR[c.ciel][nuit ? 1 : 0];
  if (nuit && (c.ciel === 'degage' || c.ciel === 'peu_nuageux')) return 'lu-cloud-moon';
  return ICONES_CIEL[c.ciel] || 'lu-cloud';
}

// Ce qui compte pour le jeu dans un créneau : brouillard (visibilité), forte neige ou pluie verglaçante (terrain difficile,
// au choix du MJ : rien d'automatique).
export const estBrouillard = c => c.ciel === 'brouillard';
export const estGlissant = c => c.precipitation === 'neige_forte' || c.precipitation === 'verglacante';

const DEBUT = { bruine: 'il se met à bruiner', pluie: 'il se met à pleuvoir', averses: 'des averses éclatent', verglacante: 'une pluie verglaçante tombe', neige: 'il se met à neiger', neige_forte: 'il se met à neiger fort' };
const FIN = { bruine: 'la bruine cesse', pluie: 'la pluie cesse', averses: 'les averses cessent', verglacante: 'la pluie verglaçante cesse', neige: 'la neige cesse', neige_forte: 'la neige cesse' };
const VIRAGE = { bruine: 'il ne tombe plus qu\'une bruine', pluie: 'il pleut', averses: 'des averses éclatent', verglacante: 'la pluie devient verglaçante', neige: 'il neige', neige_forte: 'il neige fort' };

// Annonce quand la précipitation ou le brouillard change entre deux créneaux (résultats de meteoA) :
// { titre, texte, icone }, ou null si rien ne change.
export function changementMeteo(meteo, avant, apres, nuit = false) {
  if (!avant || !apres) return null;
  const a = avant.creneau, b = apres.creneau;
  const morceaux = [];
  if ((a.precipitation || null) !== (b.precipitation || null)) {
    const neiges = ['neige', 'neige_forte'];
    if (neiges.includes(a.precipitation) && neiges.includes(b.precipitation)) morceaux.push(b.precipitation === 'neige_forte' ? 'la neige redouble' : 'la neige faiblit');
    else if (!a.precipitation) morceaux.push(DEBUT[b.precipitation] || `${b.precipitation}`);
    else if (!b.precipitation) morceaux.push(FIN[a.precipitation] || 'la précipitation cesse');
    else morceaux.push(VIRAGE[b.precipitation] || `${b.precipitation}`);
  }
  if (estBrouillard(a) !== estBrouillard(b)) morceaux.push(estBrouillard(b) ? 'le brouillard monte' : 'le brouillard se lève');
  if (!morceaux.length) return null;
  const titre = morceaux.join(' ; ');
  return { titre: titre.charAt(0).toUpperCase() + titre.slice(1), texte: detailMeteo(meteo, apres), icone: iconeMeteo(b, nuit) };
}

// « Matin (6 h – 12 h) : Neige faible, brouillard givrant, −3 à −1 °C. » puis ce qui compte pour le jeu.
export function detailMeteo(meteo, m) {
  const c = m.creneau;
  return [
    `${m.nom} (${m.plage}) : ${c.texte}, ${libelleTemperature(c.min, c.max)}.`,
    estBrouillard(c) ? cielDuMonde(meteo, 'brouillard') || 'Brouillard : on ne voit pas loin.' : '',
    estGlissant(c) ? `${c.precipitation === 'verglacante' ? 'Verglas' : 'Forte neige'} : terrain difficile, au choix du MJ.` : '',
  ].filter(Boolean).join(' ');
}

// Ce qu'un ciel donne dans le monde de la campagne (`types_ciel.<ciel>.dans_le_monde` de meteo.json, format 2 ; le format 1,
// ou null.
export function cielDuMonde(meteo, ciel) {
  const t = meteo.types_ciel?.[ciel];
  return t?.dans_le_monde || null;
}

// ───── Affichage partagé ─────

// Météo du créneau en cours : icône du ciel, texte, température ; le résumé du jour et le ciel dans le monde de la campagne
// (« En Aurval : … », vocabulaire du manifeste) en infobulle. options.texte : false pour l'icône et la température seules.
export function vueMeteo(meteo, m, { nuit = false, texte = true, classe = '' } = {}) {
  const c = m.creneau;
  const ciel = cielDuMonde(meteo, c.ciel);
  const ou = vocabulaire('{dans_le_monde}');
  const bulle = [m.jour.resume, ciel ? `${ou ? ou.charAt(0).toUpperCase() + ou.slice(1) : 'Dans le monde'} : ${ciel}` : ''].filter(Boolean).join(' ');
  return infobulle(h('span', { class: `bn-meteo ${classe}`.trim() },
    icone(iconeMeteo(c, nuit), 'bn-meteo__ciel'),
    texte ? h('span', { class: 'bn-meteo__texte' }, c.texte) : null,
    h('span', { class: 'bn-meteo__temp' }, libelleTemperature(c.min, c.max))),
  bulle, { titre: `${m.nom} (${m.plage}) : ${c.texte}` });
}

// Rappel discret (Trajets, Rencontres) quand le créneau en cours a du brouillard, de la forte neige ou du verglas.
export function rappelMeteo(meteo, m, { nuit = false } = {}) {
  const c = m?.creneau;
  if (!c || !(estBrouillard(c) || estGlissant(c))) return null;
  const mots = [estBrouillard(c) ? 'Brouillard' : '', c.precipitation === 'neige_forte' ? 'Forte neige' : '', c.precipitation === 'verglacante' ? 'Verglas' : ''].filter(Boolean);
  return infobulle(h('span', { class: 'bn-rappel-meteo', tabindex: '0' }, icone(iconeMeteo(c, nuit), 'bn-icone--s'), mots.join(' · ')),
    detailMeteo(meteo, m), { titre: 'Météo du moment' });
}
