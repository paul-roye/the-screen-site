// État de la campagne : fichiers etat/<nom>.json, écrits par lancer.ps1 (PUT). Voir formats/etat.md.
// const s = await etat('rencontres', { schema: 1, journal: [] }); s.valeur.journal.push(...); s.enregistrer();
// Un même fichier n'est chargé qu'une fois : tous les widgets partagent le même objet.
// s.signaler() prévient les autres abonnés (s.abonner(fn)) qu'ils doivent se redessiner.
//
// Jamais d'écrasement silencieux (demande du MJ, 2026-10-23 : sa disposition des widgets se perdait) :
// - un fichier qui n'a pas pu être lu (autre chose qu'un fichier absent) n'est jamais écrit : la page partirait des valeurs
//   par défaut (la disposition recommandée pour etat/tableau.json) et les enregistrerait par-dessus le vrai fichier ;
// - avant d'écrire, la page vérifie que le fichier n'a pas changé depuis qu'elle l'a lu ou écrit (son `maj`) : sinon un
//   autre onglet du gestionnaire (ou une autre page) l'a modifié, et cet onglet, périmé, ne l'écrase pas.
// Dans les deux cas, plus rien n'est écrit dans ce fichier depuis cette page, et une alerte demande de la recharger.

// Champs gardés en mémoire seulement, le temps de la page : jamais écrits, ignorés à la lecture (l'historique des dés :
// « Dés qui sauvegarde son historique ? Ah non merci », le MJ, 2026-10-24).
const EN_MEMOIRE = { des: ['historique'] };

const abonnes = new Set();
let derniereErreur = null;
const instances = new Map();
const bloques = new Map();   // nom -> raison : fichiers que cette page n'écrit plus (rechargement nécessaire)

export function surStatut(fn) { abonnes.add(fn); fn(derniereErreur, bloques.size > 0); }
// err : le dernier problème ; sans problème, l'alerte des fichiers bloqués reste affichée tant qu'il y en a.
function signalerErreur(err) {
  derniereErreur = err || (bloques.size ? [...bloques.values()].join(' ') : null);
  abonnes.forEach(fn => fn(derniereErreur, bloques.size > 0));
}
function bloquer(nom, raison) {
  bloques.set(nom, raison);
  signalerErreur(null);
}

export function etat(nom, defaut) {
  if (!instances.has(nom)) instances.set(nom, ouvrir(nom, defaut));
  return instances.get(nom);
}

// L'instance déjà ouverte par un widget (promesse), ou null : pour lire ou écrire un fichier sans imposer de valeur par défaut.
export function etatOuvert(nom) { return instances.get(nom) || null; }

async function ouvrir(nom, defaut) {
  const url = `etat/${nom}.json`;
  let valeur = structuredClone(defaut);
  let majConnue = null;   // `maj` du fichier tel que cette page l'a lu ou écrit (null : fichier absent)
  try {
    const r = await fetch(url, { cache: 'no-store' });
    if (r.ok) {
      const lu = await r.json();
      for (const k of EN_MEMOIRE[nom] || []) delete lu[k];
      valeur = { ...valeur, ...lu };
      majConnue = lu.maj ?? null;
    }
    else if (r.status !== 404) throw new Error(`lecture de ${url} : ${r.status}`);
  } catch (e) {
    bloquer(nom, `Lecture impossible de ${url} (${e.message}) : rien n'y sera écrit depuis cette page, pour ne pas l'écraser. Rechargez la page.`);
  }

  let minuterie = null;
  const ecouteurs = new Set();
  // Une écriture à la fois : la suivante attend que `majConnue` soit à jour (sinon elle se croirait en conflit).
  let enCours = Promise.resolve();
  const ecrire = () => (enCours = enCours.then(ecrireMaintenant));
  async function ecrireMaintenant() {
    minuterie = null;
    if (bloques.has(nom)) return;
    try {
      // Modifié ailleurs depuis ? (un autre onglet du gestionnaire) : cet onglet est périmé, il n'écrase pas.
      const r0 = await fetch(url, { cache: 'no-store' });
      if (r0.ok || r0.status === 404) {
        const surDisque = r0.ok ? ((await r0.json()).maj ?? null) : null;
        if (surDisque !== majConnue) {
          bloquer(nom, `${url} a été modifié ailleurs (un autre onglet du gestionnaire ?) depuis l'ouverture de cette page : pour ne pas l'écraser, rien n'y est plus écrit d'ici. Rechargez la page (les derniers changements faits dans cet onglet sur ce fichier seront perdus).`);
          return;
        }
      }
      valeur.maj = new Date().toISOString();
      const r = await fetch(url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(Object.entries(valeur).filter(([k]) => !(EN_MEMOIRE[nom] || []).includes(k))), null, 2),
      });
      if (!r.ok) throw new Error(await r.text());
      majConnue = valeur.maj;
      if (derniereErreur) signalerErreur(null);
    } catch (e) {
      signalerErreur(`Enregistrement impossible de ${url} : ${e.message} Vérifiez que lancer.ps1 tourne.`);
    }
  }
  return {
    get valeur() { return valeur; },
    set valeur(v) { valeur = v; },
    // Regroupe les écritures rapprochées (glisser un widget, cocher plusieurs cases).
    enregistrer(delai = 250) {
      clearTimeout(minuterie);
      minuterie = setTimeout(ecrire, delai);
    },
    // Écrit tout de suite (avant un rechargement de la page).
    async sauverMaintenant() { clearTimeout(minuterie); await ecrire(); },
    abonner(fn) { ecouteurs.add(fn); return () => ecouteurs.delete(fn); },
    signaler(source) { ecouteurs.forEach(fn => { if (fn !== source) fn(); }); },
  };
}
