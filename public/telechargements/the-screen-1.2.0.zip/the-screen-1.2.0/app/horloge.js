// Horloge de la campagne : jour de campagne et heure de jeu (etat/horloge.json, formats/etat.md).
// Partagée par le widget Horloge, Trajets (« Arriver » fait avancer l'horloge), Rencontres (table de jour ou de nuit),
// Ici (jour des arrivées) et la fin de session. Toute modification passe par changer() : journal, enregistrement, signal.
// Date au calendrier, lune et météo : calendrier et météo de la campagne, lus par chargerCalendrier() (calculs :
// app/calendrier.js). Le calendrier est la seule source de la lune et de l'année (décision du MJ, 2026-10-13).

import { HEURES_PAR_JOUR } from './voyage.js';
import { dateDuJour, saisonDe, luneDuJour, joursMarques, meteoA, changementMeteo, meteoDeLaJournee, chargerModeleCalendrier, avecDebut, meteoSurCampagne, reglagesTemps } from './calendrier.js';
import { campagneOuverte } from './campagne.js';
import { emettre } from './evenements.js';

export const MINUTES_PAR_JOUR = 24 * 60;
const JOURNAL_MAX = 200;
export const REGLAGES = { lever: 6 * 60, coucher: 20 * 60 };
const ANCIENS_REGLAGES = ['annee', 'pleine_lune', 'cycle_lune'];   // remplacés par le calendrier (2026-10-13)
export const DEPART = { jour: 1, minute: 8 * 60 };   // horloge jamais réglée
const DEFAUT = { schema: 1, ...DEPART, reglages: REGLAGES, repos_long: null, activites: [], journal: [] };
export const REPOS_COURT = 60;
export const REPOS_LONG = 8 * 60;
export const VEILLE_MAX = 24 * 60;   // au-delà sans repos long : alerte, fatigue +1 (décision du MJ, 2026-10-12)
export const MOMENTS_LIBELLES = { aube: 'aube', jour: 'jour', crepuscule: 'crépuscule', nuit: 'nuit' };

export const MOMENTS = [['aube', 'Aube'], ['jour', 'Jour'], ['crepuscule', 'Crépuscule'], ['nuit', 'Nuit']];
// Le moment, quand il n'y a pas de météo : rien sur le ciel, que la météo dit (un ciel toujours voilé se rappelle à part).
const AMBIANCE = { aube: 'L\'aube', jour: 'Plein jour', crepuscule: 'Le jour décline', nuit: 'La nuit' };

export async function etatHorloge(etat) {
  const s = await etat('horloge', DEFAUT);
  // Ancien compte global (2026-10-12) : la marche depuis le dernier repos long se lit maintenant dans l'historique des trajets.
  // Un trajet démarré avec lui ne garde que sa propre marche.
  const anciens = (s.valeur.activites || []).filter(a => a.type === 'voyage' && !('marche_report' in a));
  for (const a of anciens) { a.marche_jour = Math.min(a.marche_jour || 0, a.fait); a.marche_propre = a.marche_jour; a.marche_report = 0; }
  // Année et lune réglées à la main (jusqu'au 2026-10-13) : le calendrier les donne, les anciens champs disparaissent.
  const reglagesPerimes = ANCIENS_REGLAGES.filter(k => k in (s.valeur.reglages || {}));
  for (const k of reglagesPerimes) delete s.valeur.reglages[k];
  if (anciens.length || reglagesPerimes.length || 'marche_sans_repos' in s.valeur) { delete s.valeur.marche_sans_repos; s.enregistrer(0); }
  return s;
}

// ───── Calendrier et météo ─────

// Chargés une fois (chargerCalendrier, à attendre avant d'afficher), puis lus sans attendre par lecture() et changer().
// Selon les réglages de la campagne (`calendrier` et `meteo` du manifeste, formats/campagne.md, lus par reglagesTemps) :
// - calendrier : « aucun » (le jour de campagne seul), un calendrier fourni (« modele » : Classique, Barovien,
//   Royaumes oubliés, sa date de départ au manifeste), ou le calendrier importé data/calendrier.json (« importe », et d'office
//   quand le manifeste ne dit rien) ; les jours marqués propres à la campagne (data/jours-marques.json) s'y ajoutent ;
// - météo : « aucune », une météo fournie (« modele », modeles/meteos/ : deux années réelles d'une ville), ou la météo
//   importée data/meteo.json (« importe », et d'office). Un relevé par date réelle est posé sur la campagne (meteoSurCampagne).
// Un fichier absent ou illisible : ni date, ni lune (calendrier), ni météo.
let temps = { cal: null, meteo: null };
let chargement = null;
export const MODELES_METEO = '/modeles/meteos/';
export function chargerCalendrier(donnees) {
  chargement ||= (async () => {
    const { calendrier, meteo: rm } = reglagesTemps(campagneOuverte() || {});
    let cal = null, meteo = null;
    if (calendrier.type === 'modele') cal = await chargerModeleCalendrier(calendrier.modele, calendrier.debut);
    else if (calendrier.type === 'importe') {
      const c = await donnees('calendrier');
      cal = c.statut === 'ok' ? avecDebut(c.donnees, calendrier.debut) : null;
    }
    if (cal) {
      const j = await donnees('jours-marques');
      if (j.statut === 'ok') {
        cal = { ...cal, jours_marques: [...(cal.jours_marques || []), ...(j.donnees.jours_marques || [])],
          types_jours_marques: { ...(cal.types_jours_marques || {}), ...(j.donnees.types_jours_marques || {}) } };
      }
    }
    if (rm.type === 'modele' && rm.modele) {
      meteo = await fetch(`${MODELES_METEO}${encodeURIComponent(rm.modele)}.json`).then(r => (r.ok ? r.json() : null)).catch(() => null);
    } else if (rm.type === 'importe') { const x = await donnees('meteo'); meteo = x.statut === 'ok' ? x.donnees : null; }
    if (meteo?.type === 'releve') meteo = meteoSurCampagne(meteo, cal, { debut: rm.debut_reel });
    temps = { cal, meteo };
    return temps;
  })();
  return chargement;
}
// Un fichier mal formé ne doit pas casser l'horloge : le calcul rate, l'information manque (le bouton Données dit pourquoi).
const sur = f => { try { return f(); } catch { return null; } };

// L'horloge sert-elle en ce moment ? Seulement si le widget est sur le tableau (dans l'un ou l'autre mode) : sinon elle n'avance plus.
export const horlogeEnService = () => !!document.querySelector('.bn-widget[data-type="horloge"]');

export const reglagesDe = v => ({ ...REGLAGES, ...(v.reglages || {}) });

// { jour, minute } -> minutes depuis le début du jour 1, et l'inverse.
export const enMinutes = t => (t.jour - 1) * MINUTES_PAR_JOUR + t.minute;
export function depuisMinutes(total) {
  const t = Math.max(0, Math.round(total));
  return { jour: Math.floor(t / MINUTES_PAR_JOUR) + 1, minute: t % MINUTES_PAR_JOUR };
}
export const maintenant = v => ({ jour: v.jour, minute: v.minute });

// 1335 -> « 22 h 15 » ; 1320 -> « 22 h »
export function libelleHeure(minute) {
  const hh = Math.floor(minute / 60), mm = minute % 60;
  return mm ? `${hh} h ${String(mm).padStart(2, '0')}` : `${hh} h`;
}
// « Jour 3, 22 h 15 »
export const libelleMoment = t => `Jour ${t.jour}, ${libelleHeure(t.minute)}`;
// 1335 -> « 22:15 » (champ <input type="time">, bloc maj-etat)
export const enHHMM = minute => `${String(Math.floor(minute / 60)).padStart(2, '0')}:${String(minute % 60).padStart(2, '0')}`;
export function depuisHHMM(texte) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(texte).trim());
  if (!m || +m[1] > 23 || +m[2] > 59) return null;
  return +m[1] * 60 + +m[2];
}

// Durée de jeu : 1500 -> « 1 j 1 h », 90 -> « 1 h 30 », 10 -> « 10 min »
export function libelleDuree(minutes) {
  const m = Math.round(Math.abs(minutes));
  const j = Math.floor(m / MINUTES_PAR_JOUR), hh = Math.floor(m % MINUTES_PAR_JOUR / 60), mm = m % 60;
  const morceaux = [j ? `${j} j` : '', hh ? `${hh} h` : '', mm ? (hh ? String(mm).padStart(2, '0') : `${mm} min`) : ''].filter(Boolean);
  return (minutes < 0 ? '− ' : '') + (morceaux.join(' ') || '0 min');
}

// Moment de la journée : une heure de part et d'autre du lever et du coucher du soleil.
export function momentDe(minute, r) {
  if (minute >= r.lever - 60 && minute < r.lever + 60) return 'aube';
  if (minute >= r.lever + 60 && minute < r.coucher - 60) return 'jour';
  if (minute >= r.coucher - 60 && minute < r.coucher + 60) return 'crepuscule';
  return 'nuit';
}

// Table de rencontres : celle de nuit pendant la nuit de l'horloge (après le crépuscule, avant l'aube), sinon celle de jour.
// Décision du MJ (2026-10-12) : au crépuscule, il ne fait pas encore nuit.
export function tableRencontres(v) {
  return momentDe(v.minute, reglagesDe(v)) === 'nuit' ? 'nuit' : 'jour';
}

// Phase de la lune d'après le calendrier : celle de la nuit en cours (avant le lever du soleil, la nuit qui a commencé
// la veille), ou de la nuit qui vient quand le soleil est levé. Pleine le 1er de chaque mois, la veille et le lendemain.
// { nom, pleine, dans, prochaine } (app/calendrier.js, luneDuJour), ou null sans calendrier.
export function lune(v) {
  const nuit = v.minute < reglagesDe(v).lever ? v.jour - 1 : v.jour;
  return temps.cal ? sur(() => luneDuJour(temps.cal, nuit)) : null;
}

// Ce qu'affiche l'horloge : moment, ambiance, ce qui vient ensuite, lune ; date du calendrier et saison (null sans calendrier),
// jours marqués (`marques` : prochaine occurrence de chacun, dans = 0 le jour même) ; météo du créneau en cours (null sans relevé).
export function lecture(v) {
  const r = reglagesDe(v);
  const moment = momentDe(v.minute, r);
  const leve = v.minute >= r.lever && v.minute < r.coucher;
  const attente = leve ? r.coucher - v.minute : (r.lever - v.minute + MINUTES_PAR_JOUR) % MINUTES_PAR_JOUR;
  const l = lune(v);
  const date = temps.cal ? sur(() => dateDuJour(temps.cal, v.jour)) : null;
  return {
    moment,
    ambiance: moment === 'nuit' && l?.pleine ? 'Nuit de pleine lune' : AMBIANCE[moment],
    ensuite: `${leve ? 'Coucher' : 'Lever'} du soleil dans ${libelleDuree(attente)}`,
    soleil: { coucher: leve, dans: attente, a: leve ? r.coucher : r.lever },   // le même, pour l'afficher en icône
    lune: l,
    date,
    saison: date ? sur(() => saisonDe(temps.cal, date)) : null,
    marques: (temps.cal && sur(() => joursMarques(temps.cal, v.jour))) || [],
    meteo: temps.meteo ? sur(() => meteoA(temps.meteo, v)) : null,
  };
}

// Durée allongée pour finir sur l'heure ronde suivante (fin d'un repos long : on repart sur une heure sûre, le repos
// ne raccourcit jamais). 21 h 40 + 8 h = 5 h 40 → 6 h (8 h 20) ; 21 h 20 + 8 h → 6 h (8 h 40) ; 22 h + 8 h → 6 h.
export function arrondiHeure(v, minutes) {
  const fin = (v.minute + minutes) % 60;
  return fin ? minutes + 60 - fin : minutes;
}

// Minutes à attendre jusqu'à la prochaine fois qu'il est `minute` heures (lever du soleil…), au moins 1.
export function jusqua(v, minute) {
  return ((minute - v.minute - 1 + MINUTES_PAR_JOUR) % MINUTES_PAR_JOUR) + 1;
}

// Annonce en haut du tableau (app/main.js) : { cle, titre, texte, couleur, icone }. Une annonce de même clé remplace la précédente.
export function annoncer(detail) {
  document.dispatchEvent(new CustomEvent('cm:annonce', { detail }));
}

// Minutes écoulées depuis la fin du dernier repos long, ou null s'il n'est pas noté.
export function sansReposLong(v, t = maintenant(v)) {
  return v.repos_long ? enMinutes(t) - enMinutes(v.repos_long) : null;
}

// Placer l'horloge sur `apres` ({ jour, minute }) : noté au journal avec son motif, enregistré, signalé aux autres widgets.
// options.reposLong : un repos long se termine à `apres`. options.silencieux : pas d'annonce (réglage de l'horloge).
// options.activite : { id, pas } quand c'est une heure d'une activité en cours (app/passage.js) : « Annuler » la défait aussi.
// Annonces : la nuit tombe (passage de la table de jour à celle de nuit), plus de 24 h sans repos long, la précipitation
// ou le brouillard change (entre le créneau de départ et celui d'arrivée, data/meteo.json).
export function changer(s, apres, motif, { reposLong = false, silencieux = false, activite = null } = {}) {
  const v = s.valeur;
  const avant = maintenant(v);
  if (enMinutes(avant) === enMinutes(apres) && !reposLong) return;
  const veilleAvant = sansReposLong(v, avant);
  const tableAvant = tableRencontres(v);
  const meteoAvant = temps.meteo ? sur(() => meteoA(temps.meteo, avant)) : null;
  const entree = { quand: new Date().toISOString(), avant, apres: { jour: apres.jour, minute: apres.minute }, motif };
  if (reposLong) entree.repos_avant = v.repos_long;   // « Annuler » le rétablit
  if (activite) entree.activite = activite;
  Object.assign(v, apres);
  if (reposLong) v.repos_long = maintenant(v);
  v.journal = [...(v.journal || []), entree].slice(-JOURNAL_MAX);
  s.enregistrer(0);
  s.signaler();
  const r = reglagesDe(v);
  emettre('horloge:changement', { avant, apres: maintenant(v), moment: momentDe(v.minute, r), moment_avant: momentDe(avant.minute, r), motif, repos_long: reposLong });
  if (silencieux) return;
  if (tableAvant === 'jour' && tableRencontres(v) === 'nuit') {
    annoncer({ cle: 'nuit', titre: 'La nuit tombe', icone: 'lune',
      texte: `Fin du crépuscule (soleil couché à ${libelleHeure(r.coucher)}). ${libelleMoment(v)} : les rencontres se tirent sur la table de nuit.` });
  }
  const veille = sansReposLong(v);
  if (veille !== null && veille > VEILLE_MAX && (veilleAvant === null || veilleAvant <= VEILLE_MAX)) {
    annoncer({ cle: 'repos', titre: 'Plus de 24 h sans repos long : fatigue +1', icone: 'sablier', couleur: 'sang',
      texte: `Dernier repos long terminé ${libelleMoment(v.repos_long)}, il y a ${libelleDuree(veille)}.` });
  }
  const meteo = meteoAvant && sur(() => changementMeteo(temps.meteo, meteoAvant, meteoA(temps.meteo, v), momentDe(v.minute, r) === 'nuit'));
  if (meteo) annoncer({ cle: 'meteo', couleur: 'brume', ...meteo, texte: `${libelleMoment(v)}. ${meteo.texte}` });
  // Une journée se termine (demande du MJ, 2026-10-22) : sa météo, pour le compte rendu ; le détail dans la fenêtre du jour.
  if (temps.meteo && apres.jour > avant.jour) {
    const j = sur(() => meteoDeLaJournee(temps.meteo, avant.jour));
    if (j) annoncer({ cle: 'fin-jour', titre: `Fin du jour ${avant.jour} : la météo de la journée`, icone: 'lune', couleur: 'brume', texte: j.texte });
  }
}

export function avancer(s, minutes, motif, options) {
  changer(s, depuisMinutes(enMinutes(s.valeur) + minutes), motif, options);
}

// Retirer une ligne du journal (une avancée notée par erreur) : l'heure ne change pas, on la règle à part.
export function retirerDuJournal(s, index) {
  s.valeur.journal = (s.valeur.journal || []).filter((_, i) => i !== index);
  s.enregistrer(0);
  s.signaler();
}

export function noterReposLong(s, t = maintenant(s.valeur)) {
  s.valeur.repos_long = t;
  s.enregistrer(0);
  s.signaler();
}

// Où « Annuler » ramène l'horloge : le dernier changement du journal défait, compté depuis l'heure actuelle (l'heure
// peut ne plus être celle où il s'est terminé, si des lignes plus récentes ont été retirées du journal).
export function retourDe(v) {
  const dernier = v.journal?.at(-1);
  return dernier ? depuisMinutes(Math.max(0, enMinutes(v) - (enMinutes(dernier.apres) - enMinutes(dernier.avant)))) : null;
}

// Revenir avant le dernier changement noté au journal. Une heure de l'activité en cours est défaite aussi (les arrivées
// et les tests de rencontre de ce temps-là : annulerAvecSuites() de app/passage.js, qui propose de les retirer).
export function annuler(s) {
  const v = s.valeur;
  const dernier = v.journal?.at(-1);
  if (!dernier) return;
  Object.assign(v, retourDe(v));
  if ('repos_avant' in dernier) v.repos_long = dernier.repos_avant;
  const a = v.activites?.at(-1);
  if (dernier.activite && a?.id === dernier.activite.id) {
    a.fait = Math.max(0, a.fait - dernier.activite.pas);
    if (a.marche_jour !== undefined) a.marche_jour = Math.max(0, a.marche_jour - dernier.activite.pas);
    if (a.marche_propre !== undefined) a.marche_propre = Math.max(0, a.marche_propre - dernier.activite.pas);
  }
  v.journal = v.journal.slice(0, -1);
  s.enregistrer(0);
  s.signaler();
  const r = reglagesDe(v);
  emettre('horloge:changement', { avant: dernier.apres, apres: maintenant(v), moment: momentDe(v.minute, r), moment_avant: momentDe(dernier.apres.minute, r), motif: 'Annulation', repos_long: false });
}

// Temps de jeu écoulé pour `marche` minutes de marche (règle du MJ : journées de 8 heures de marche).
// Au-delà de 8 h, chaque journée de plus reprend le lendemain à la même heure : 20 h de marche = 2 j + 4 h.
export function dureeVoyage(marche) {
  const jour = HEURES_PAR_JOUR * 60;
  if (marche <= 0) return 0;
  const nuits = Math.floor((marche - 1) / jour);
  return nuits * MINUTES_PAR_JOUR + (marche - nuits * jour);
}
