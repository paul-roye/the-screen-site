// Signature du gestionnaire, en haut à droite de l'en-tête et de l'accueil : son auteur, sa version (version.json, scellée par
// le mainteneur : mainteneur/sceller-version.ps1) et le lien « À propos » (a-propos.html : nouveautés, à venir, bugs connus,
// aide de chaque widget), ouvert dans un nouvel onglet pour ne pas quitter le tableau. Même police que « Gestionnaire de
// campagne » (surtitre).

import { h, infobulle } from './ui.js';
import { lireVersion } from './campagne.js';

export const AUTEUR = 'Nizzren';

// campagne : l'identifiant de la campagne ouverte (la page À propos prend sa charte et son thème), ou null.
export function signature(campagne = null) {
  const version = h('span', { class: 'cm-signature__version' });
  const lien = h('a', { class: 'cm-signature__lien', href: `/a-propos.html${campagne ? `?campagne=${encodeURIComponent(campagne)}` : ''}`,
    target: '_blank', rel: 'noopener' }, 'À propos');
  const el = h('p', { class: 'surtitre cm-signature' }, `Par ${AUTEUR}`, version, h('span', { 'aria-hidden': 'true' }, ' · '), lien);
  // Une copie modifiée depuis sa version officielle : « v1.0.0+ », et pourquoi au survol.
  lireVersion().then(v => {
    if (!v?.version) return;
    const texte = h('span', { tabindex: v.modifie ? '0' : null }, `v${v.version}${v.modifie ? '+' : ''}`);
    version.replaceChildren(h('span', { 'aria-hidden': 'true' }, ' · '),
      v.modifie ? infobulle(texte, `Le code a changé depuis la version officielle ${v.version}${v.date ? ` du ${v.date.split('-').reverse().join('/')}` : ''}.`, { titre: 'Gestionnaire modifié', ton: 'cierge' }) : texte);
  });
  return el;
}
