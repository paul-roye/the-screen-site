// Dés en notation XdY+Z (formats/README.md) : "3d6", "1d4+1", "1d12+1d8", "1".
// lancer("1d12+1d8") -> { formule, total, detail: "7 + 5", des: [7, 5], faces: [{ faces: 12, valeur: 7 }, { faces: 8, valeur: 5 }] } ;
// null si la formule n'est pas lisible ("2 ou 3"). faces : chaque dé avec son type, pour le rouler en 3D (app/lancers.js).

export function aleatoire(faces) {
  const t = new Uint32Array(1);
  const limite = Math.floor(0x100000000 / faces) * faces;   // pas de biais de modulo
  do { crypto.getRandomValues(t); } while (t[0] >= limite);
  return (t[0] % faces) + 1;
}

export function lisible(formule) {
  return /^\s*[+-]?\s*(\d+d\d+|\d+)(\s*[+-]\s*(\d+d\d+|\d+))*\s*$/i.test(String(formule));
}

export function lancer(formule) {
  const f = String(formule).replace(/\s+/g, '').toLowerCase();
  if (!lisible(f)) return null;
  let total = 0;
  const des = [];
  const faces = [];
  const morceaux = [];
  for (const [, signe, terme] of f.matchAll(/([+-]?)(\d+d\d+|\d+)/g)) {
    const s = signe === '-' ? -1 : 1;
    if (terme.includes('d')) {
      const [n, cotes] = terme.split('d').map(Number);
      const jets = Array.from({ length: n }, () => aleatoire(cotes));
      des.push(...jets);
      faces.push(...jets.map(valeur => ({ faces: cotes, valeur })));
      total += s * jets.reduce((a, b) => a + b, 0);
      morceaux.push((s < 0 ? '− ' : '') + (jets.length > 1 ? '(' + jets.join(' + ') + ')' : jets[0]));
    } else {
      total += s * Number(terme);
      morceaux.push((s < 0 ? '− ' : '') + terme);
    }
  }
  return { formule: String(formule), total, des, faces, detail: morceaux.join(' + ').replace(/\+ −/g, '−') };
}

// Une seule valeur constante, sans dé : "1" -> pas la peine d'afficher un jet.
export function estFixe(formule) {
  return /^\s*\d+\s*$/.test(String(formule));
}

export function auHasard(liste) {
  return liste[aleatoire(liste.length) - 1];
}

// Tirage pondéré : [{ poids: 1, ... }, { poids: 2, ... }]
export function pondere(options) {
  const somme = options.reduce((a, o) => a + (o.poids ?? 1), 0);
  let r = aleatoire(somme);
  for (const o of options) { r -= (o.poids ?? 1); if (r <= 0) return o; }
  return options[options.length - 1];
}

// Jet d'une sous-table : lignes [{ jet: "1-2" | "6" | 3, resultat }]
export function ligneDeTable(lignes, valeur) {
  return lignes.find(l => {
    const [a, b] = String(l.jet).split('-').map(Number);
    return valeur >= a && valeur <= (b || a);
  });
}
