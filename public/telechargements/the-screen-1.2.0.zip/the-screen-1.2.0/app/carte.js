// Carte des trajets de la campagne : carte.json de son dossier (formats/campagne.md), tenu à la main. L'image, ses
// dimensions, la position de chaque lieu relié par un trajet et le tracé des routes : propres à une image, pas dans data/.
// Sans carte.json, le widget Trajets se passe de carte.

let lecture = null;

// La carte, ou null si la campagne n'en a pas.
export function chargerCarte() {
  lecture ||= fetch('carte.json', { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  return lecture;
}

// Tracé d'un trajet de a vers b (points intermédiaires, en %), ou [] s'il n'y en a pas.
export function traceEntre(carte, a, b) {
  const t = carte?.traces?.[`${a}--${b}`];
  if (t) return t;
  const r = carte?.traces?.[`${b}--${a}`];
  return r ? [...r].reverse() : [];
}
