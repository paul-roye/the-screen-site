// Grille de widgets : placement en colonnes, glisser par la poignée, redimensionner par le coin,
// les voisins se poussent vers le bas puis tout remonte (tassement vertical).
// Clavier : poignée focalisée + flèches pour déplacer, Maj + flèches pour redimensionner.

const COLONNES = 12;
const RANG = 40;           // hauteur d'une rangée, px
const LARGEUR_PILE = 900;  // en dessous : widgets empilés, pas de glisser
const REDUIT = 1;          // hauteur d'un widget réduit, en rangées (titre seul)

const chevauche = (a, b) => a.cle !== b.cle && a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
const copie = l => l.map(i => ({ ...i }));

function repousser(disposition, item) {
  for (const autre of disposition) {
    if (chevauche(item, autre)) {
      autre.y = item.y + item.h;
      repousser(disposition, autre);
    }
  }
}

function tasser(disposition) {
  const places = [];
  for (const item of [...disposition].sort((a, b) => a.y - b.y || a.x - b.x)) {
    while (item.y > 0 && !places.some(p => chevauche({ ...item, y: item.y - 1 }, p))) item.y--;
    while (places.some(p => chevauche(item, p))) item.y++;
    places.push(item);
  }
  return disposition;
}

export function creerGrille(conteneur, { surChangement }) {
  const items = new Map();   // cle -> { cle, x, y, w, h, min, el }
  let verrou = false;
  let pile = false;
  const fantome = Object.assign(document.createElement('div'), { className: 'bn-grille__fantome', hidden: true });
  conteneur.classList.add('bn-grille');
  conteneur.append(fantome);

  const gouttiere = () => parseFloat(getComputedStyle(conteneur).getPropertyValue('--space-4')) || 16;
  const colonne = () => (conteneur.clientWidth - (COLONNES - 1) * gouttiere()) / COLONNES;
  const enPx = i => {
    const g = gouttiere(), c = colonne();
    return { left: i.x * (c + g), top: i.y * (RANG + g), width: i.w * c + (i.w - 1) * g, height: i.h * RANG + (i.h - 1) * g };
  };
  const poser = (el, i) => {
    const p = enPx(i);
    Object.assign(el.style, { left: p.left + 'px', top: p.top + 'px', width: p.width + 'px', height: p.height + 'px' });
  };
  // Un widget réduit n'occupe que REDUIT rangées (son en-tête) ; hPlein garde sa hauteur dépliée.
  const disposition = () => [...items.values()].map(({ cle, x, y, w, h, min, reduit, hPlein }) => ({ cle, x, y, w, h, min, reduit, hPlein }));

  function appliquer(d, sauf) {
    for (const i of d) {
      const item = items.get(i.cle);
      Object.assign(item, { x: i.x, y: i.y, w: i.w, h: i.h, reduit: i.reduit, hPlein: i.hPlein });
      if (!pile && i.cle !== sauf) poser(item.el, item);
    }
    ordonner();
    hauteur();
  }

  function hauteur() {
    if (pile) { conteneur.style.height = ''; return; }
    const bas = Math.max(0, ...[...items.values()].map(i => i.y + i.h));
    conteneur.style.height = (bas * (RANG + gouttiere())) + 'px';
  }

  // Ordre du DOM = ordre de lecture (haut en bas, gauche à droite) : tabulation et pile restent logiques.
  function ordonner() {
    const tries = [...items.values()].sort((a, b) => a.y - b.y || a.x - b.x);
    let precedent = fantome;
    for (const i of tries) {
      if (precedent.nextSibling !== i.el) precedent.after(i.el);
      precedent = i.el;
    }
  }

  function modePile() {
    const p = conteneur.clientWidth < LARGEUR_PILE;
    if (p === pile && items.size) { if (!pile) appliquer(disposition()); return; }
    pile = p;
    conteneur.classList.toggle('bn-grille--pile', pile);
    for (const i of items.values()) {
      if (pile) i.el.removeAttribute('style'); else poser(i.el, i);
    }
    hauteur();
  }
  new ResizeObserver(() => modePile()).observe(conteneur);

  // Glisser ou redimensionner à la souris, au doigt ou au stylet.
  function saisir(cle, e, mode) {
    if (verrou || pile || e.button > 0) return;
    e.preventDefault();
    const item = items.get(cle);
    const depart = disposition();
    const p0 = enPx(item);
    const x0 = e.clientX, y0 = e.clientY;
    const g = gouttiere(), c = colonne();
    let courante = depart;
    item.el.classList.add('est-saisi');
    document.body.classList.add('est-en-glisse');
    fantome.hidden = false;
    poser(fantome, item);

    const bouger = ev => {
      const dx = ev.clientX - x0, dy = ev.clientY - y0;
      const d = copie(depart);
      const cible = d.find(i => i.cle === cle);
      if (mode === 'glisser') {
        const left = p0.left + dx, top = Math.max(0, p0.top + dy);
        Object.assign(item.el.style, { left: left + 'px', top: top + 'px' });
        cible.x = Math.min(COLONNES - cible.w, Math.max(0, Math.round(left / (c + g))));
        cible.y = Math.max(0, Math.round(top / (RANG + g)));
      } else {
        const width = Math.max(40, p0.width + dx), height = Math.max(40, p0.height + dy);
        Object.assign(item.el.style, { width: width + 'px', height: height + 'px' });
        cible.w = Math.min(COLONNES - cible.x, Math.max(item.min.w, Math.round((width + g) / (c + g))));
        cible.h = Math.max(item.min.h, Math.round((height + g) / (RANG + g)));
      }
      repousser(d, cible);
      courante = tasser(d);
      appliquer(courante, cle);
      poser(fantome, courante.find(i => i.cle === cle));
    };
    const lacher = () => {
      window.removeEventListener('pointermove', bouger);
      window.removeEventListener('pointerup', lacher);
      window.removeEventListener('pointercancel', lacher);
      item.el.classList.remove('est-saisi');
      document.body.classList.remove('est-en-glisse');
      fantome.hidden = true;
      appliquer(courante);
      surChangement(disposition());
    };
    window.addEventListener('pointermove', bouger);
    window.addEventListener('pointerup', lacher);
    window.addEventListener('pointercancel', lacher);
  }

  function auClavier(cle, e) {
    if (verrou || pile) return;
    const pas = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
    if (!pas) return;
    e.preventDefault();
    const d = disposition();
    const cible = d.find(i => i.cle === cle);
    const item = items.get(cle);
    if (e.shiftKey && cible.reduit) return;
    if (e.shiftKey) {
      cible.w = Math.min(COLONNES - cible.x, Math.max(item.min.w, cible.w + pas[0]));
      cible.h = Math.max(item.min.h, cible.h + pas[1]);
    } else {
      cible.x = Math.min(COLONNES - cible.w, Math.max(0, cible.x + pas[0]));
      // Haut / bas : échanger avec le voisin le plus proche dans la même colonne (le tassement annulerait un simple pas).
      if (pas[1]) {
        const memeColonne = i => i.cle !== cle && i.x < cible.x + cible.w && cible.x < i.x + i.w;
        const voisins = d.filter(i => memeColonne(i) && (pas[1] > 0 ? i.y >= cible.y + cible.h : i.y + i.h <= cible.y));
        const voisin = voisins.sort((a, b) => pas[1] > 0 ? a.y - b.y : b.y - a.y)[0];
        if (voisin && pas[1] > 0) { voisin.y = cible.y; cible.y = voisin.y + voisin.h; }
        else if (voisin) { cible.y = voisin.y; voisin.y = cible.y + cible.h; }
      }
    }
    repousser(d, cible);
    appliquer(tasser(d));
    surChangement(disposition());
    e.currentTarget.focus();
  }

  return {
    // differe : la disposition enregistrée, posée widget par widget (`poserTout()` ensuite). Tasser après chaque widget, dans
    // l'ordre du fichier, la faisait dériver à chaque rechargement (un widget remonté dans une place encore vide, puis
    // repoussé sous d'autres : l'Horloge et les Dés descendaient, retour du MJ du 2026-10-23).
    ajouter({ cle, x, y, w, h, min, el, reduit = false, hPlein, differe = false }) {
      const item = { cle, x, y, w: Math.min(w, COLONNES), h: reduit ? REDUIT : h, min: min || { w: 3, h: 4 }, el, reduit, hPlein: reduit ? (hPlein || h) : undefined };
      el.classList.toggle('est-reduit', reduit);
      items.set(cle, item);
      if (pile) el.removeAttribute('style');   // il revient peut-être de l'autre mode, placé en absolu
      conteneur.append(el);
      const poignee = el.querySelector('.bn-widget__poignee');
      const redim = el.querySelector('.bn-widget__redim');
      poignee?.addEventListener('pointerdown', e => saisir(cle, e, 'glisser'));
      poignee?.addEventListener('keydown', e => auClavier(cle, e));
      redim?.addEventListener('pointerdown', e => saisir(cle, e, 'redim'));
      if (differe) return;
      const d = disposition();
      repousser(d, d.find(i => i.cle === cle));
      appliquer(tasser(d));
      modePile();
    },
    // Après des `ajouter({ differe: true })` : un seul tassement, de haut en bas (une disposition enregistrée ne bouge pas ;
    // un chevauchement éventuel se résout vers le bas).
    poserTout() {
      appliquer(tasser(disposition()));
      modePile();
    },
    retirer(cle) {
      items.get(cle)?.el.remove();
      items.delete(cle);
      appliquer(tasser(disposition()));
      surChangement(disposition());
    },
    // Réduire à l'en-tête, ou déplier à la hauteur d'avant. Les voisins remontent ou se poussent.
    reduire(cle, reduit) {
      const d = disposition();
      const cible = d.find(i => i.cle === cle);
      if (!cible || !!cible.reduit === reduit) return;
      if (reduit) { cible.hPlein = cible.h; cible.h = REDUIT; }
      else { cible.h = cible.hPlein || cible.min.h; cible.hPlein = undefined; }
      cible.reduit = reduit;
      items.get(cle).el.classList.toggle('est-reduit', reduit);
      repousser(d, cible);
      appliquer(tasser(d));
      surChangement(disposition());
    },
    // Changer de disposition (mode du tableau) : sortir tous les widgets de la grille sans les détruire.
    // Renvoie leurs éléments, que l'appelant range ailleurs ; rien n'est enregistré.
    vider() {
      const els = [...items.values()].map(i => i.el);
      items.clear();
      hauteur();
      return els;
    },
    // Hauteur demandée par le widget lui-même (voir sa place dans le contenu) : en pixels, arrondie à la rangée, jamais
    // sous son minimum. Les voisins se poussent ou remontent. Sans effet sur un widget réduit ou empilé (petit écran).
    hauteurPx(cle, px) {
      const item = items.get(cle);
      if (!item || item.reduit || pile) return;
      const h = Math.max(item.min.h, Math.ceil((px + gouttiere()) / (RANG + gouttiere())));
      if (h === item.h) return;
      const d = disposition();
      const cible = d.find(i => i.cle === cle);
      cible.h = h;
      repousser(d, cible);
      appliquer(tasser(d));
      surChangement(disposition());
    },
    estReduit: cle => !!items.get(cle)?.reduit,
    // Premier emplacement libre en bas du tableau pour un widget de largeur w.
    placeLibre(w) {
      const bas = Math.max(0, ...[...items.values()].map(i => i.y + i.h));
      return { x: 0, y: bas, w };
    },
    verrouiller(v) { verrou = v; conteneur.classList.toggle('bn-grille--verrou', v); },
    disposition,
  };
}
