// Modules de campagne : une mécanique propre à une campagne (le Tarokka de Curse of Strahd), avec son interface, chargée seulement si
// le manifeste la demande (`modules`, formats/campagne.md). Voir formats/campagne.md (`modules`).
//
// Un module (app/modules/<id>.js) exporte :
//   { id, titre,
//     widgets: [...],                        ses widgets, ajoutés à « Ajouter un outil »
//     formats: { <jeu>: { schema, verifier } }, ses fichiers de data/, lus et vérifiés comme les autres (app/donnees.js)
//     champs: { <jeu>: async (d, p, autre) },   ses champs dans les fichiers des autres (etapes[].tarokka), qu'il vérifie
//     preparer: async ({ donnees, etat }),   lu une fois au démarrage, avant les widgets : ses données et son état
//     emplacements: { <nom>: fonction ou valeur } }   ce qu'il ajoute ailleurs, voir EMPLACEMENTS
//
// Les widgets hôtes ne nomment jamais un module : ils demandent ce qu'un emplacement contient (contributions()), et
// n'affichent rien quand aucun module n'y contribue.

// Les plugins (app/plugins.js : des connexions, activées dans la fenêtre Campagne) contribuent aux mêmes emplacements.
//
// Emplacements connus, et qui les appelle :
//   combatEntete({ rencontre })  bouton ou repère dans les outils de l'en-tête du widget Combat (le point d'état d'un plugin)
//   etapeRepere(etape)          petit repère sur une étape (Déroulé, en-tête de l'étape)
//   etapeBloc(etape)            bloc dans le détail d'une étape (Déroulé, Ici onglet Trame)
//   lieuRepere(lieu, etapes)    repère sur la carte d'un lieu (Ici), etapes : les étapes du déroulé
//   objetLigne(rattachement, objet)   ligne du rattachement d'un objet (Objets ; objet : celui de objets.json) : [étiquette, élément]
//   imagesCategories            { categorie: libellé ou { nom, icone } } : catégories d'images (Images)
//   imageTitre(image)           titre d'une image, ou null (Images)
//   imageSansPnj(image)         vrai : ne pas rapprocher l'image d'un PNJ (Images)
//   imageActions(image, { lieux, nomLieu, titre })   boutons dans la fenêtre d'une image (l'écran des joueurs d'un plugin)
//   sessionEtats                [noms] : ses fichiers d'etat/, lus et écrits par la fin de session
//   sessionPrompt({ etats, ligne, date })            sa section du prompt de fin de session
//   sessionExemple()            { clé: valeur } : sa part de l'exemple du bloc maj-etat
//   sessionAide()               [lignes] : l'explication de ses clés du bloc maj-etat
//   sessionAppliquer({ m, etats, liste, ignores, oui, ajouterNote, session })   ses changements du bloc maj-etat

import { pluginsActifs } from './plugins.js';

// Les modules qui existent (proposés à la création d'une campagne, accueil) : id, titre, description.
export const MODULES_DISPONIBLES = [
  {
    id: 'tarokka', titre: 'Tarokka', icone: 'tarokka', genre: 'curse-of-strahd',
    description: 'Uniquement pour une campagne Curse of Strahd : la lecture de madame Éva, ses cartes, et ce qu\'elles placent aux étapes, aux lieux et aux objets (data/tarokka.json).',
    avertissement: 'Il ne fonctionne qu\'avec une campagne Curse of Strahd. Ses données (data/tarokka.json) suivent la lecture de madame Éva et ses places (le Tome, le Symbole, l\'Épée, l\'Allié, Strahd) : il ne sert à rien dans une autre campagne.',
  },
];

const charges = [];

// Charge les modules demandés (ids du manifeste). Un module introuvable est signalé dans la console, sans bloquer la page.
export async function chargerModules(ids = []) {
  for (const id of ids) {
    if (!/^[a-z0-9-]+$/.test(id) || charges.some(m => m.id === id)) continue;
    try { charges.push((await import(`./modules/${id}.js`)).default); }
    catch (e) { console.error(`Module de campagne « ${id} » introuvable ou illisible (app/modules/${id}.js)`, e); }
  }
  return charges;
}

export const modulesCharges = () => charges;

// Prépare les modules chargés (données, état), une fois, avant le montage des widgets.
export async function preparerModules(contexte) {
  for (const m of charges) if (m.preparer) await m.preparer(contexte);
}

// Ce que les modules (et les plugins actifs) mettent à un emplacement : les résultats non vides de leurs fonctions (appelées
// avec args), ou leurs valeurs (objets, listes) quand l'emplacement n'est pas une fonction.
export function contributions(nom, ...args) {
  const r = [];
  for (const m of [...charges, ...pluginsActifs()]) {
    const e = m.emplacements?.[nom];
    if (e === undefined || e === null) continue;
    const v = typeof e === 'function' ? e(...args) : e;
    if (v !== null && v !== undefined && v !== false) r.push(v);
  }
  return r;
}

// Vérifications des champs de modules dans un fichier de data/ (app/donnees.js).
export const champsModules = jeu => charges.map(m => m.champs?.[jeu]).filter(Boolean);
