// Mode débogage (demande du MJ, 2026-10-23) : outils pour tester l'affichage, propres au navigateur (localStorage), réglés
// dans la fenêtre Campagne (onglet « Ce poste »). Largeur simulée, choisie dans le menu rapide : la page (#app) limitée à
// cette largeur, comme une fenêtre de cette taille (barre de défilement comprise), centrée, ses bords en pointillés. Les
// widgets s'y adaptent (grille, requêtes de conteneur, ResizeObserver) ; ce qui se place d'après la fenêtre elle-même
// (fenêtres flottantes, menus, infobulles, dés 3D) garde la vraie largeur.

const CLE_ACTIF = 'cm:debogage';
const CLE_LARGEUR = 'cm:debogage:largeur';

// Les largeurs du MJ (CONTEXTE.md) : PC de la table selon le zoom de Chrome, écran tactile à venir, écran fixe.
export const LARGEURS = [
  [1280, 'Table, Chrome à 100 %'],
  [1422, 'Table, Chrome à 90 %'],
  [1600, 'Table, Chrome à 80 %'],
  [1920, 'Écran tactile'],
  [2560, 'Écran fixe'],
];

const lire = cle => { try { return localStorage.getItem(cle); } catch { return null; } };
const ecrire = (cle, v) => { try { if (v == null) localStorage.removeItem(cle); else localStorage.setItem(cle, v); } catch { /* le choix vaut pour la page */ } };
const abonnes = new Set();
const prevenir = () => abonnes.forEach(f => f());

export const debogageActif = () => lire(CLE_ACTIF) === '1';
export const surDebogage = f => abonnes.add(f);
export const largeurSimulee = () => (debogageActif() && Number(lire(CLE_LARGEUR))) || null;

export function activerDebogage(oui) {
  ecrire(CLE_ACTIF, oui ? '1' : null);
  if (!oui) ecrire(CLE_LARGEUR, null);
  appliquerLargeur();
  prevenir();
}

export function simulerLargeur(largeur) {
  ecrire(CLE_LARGEUR, largeur ? String(largeur) : null);
  appliquerLargeur();
  prevenir();
}

// À l'ouverture de la page et quand la fenêtre change de taille.
export function appliquerLargeur() {
  const app = document.getElementById('app');
  if (!app) return;
  const l = largeurSimulee();
  document.documentElement.classList.toggle('cm-simulation', !!l);
  if (!l) { app.style.maxWidth = ''; delete app.dataset.largeur; return; }
  const barre = innerWidth - document.documentElement.clientWidth;
  app.style.maxWidth = (l - barre) + 'px';
  app.dataset.largeur = l > innerWidth ? `${l} px demandés : fenêtre de ${innerWidth} px seulement` : `${l} px simulés`;
}
addEventListener('resize', appliquerLargeur);
