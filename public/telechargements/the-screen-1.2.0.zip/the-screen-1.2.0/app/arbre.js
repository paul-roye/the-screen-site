// Vue en arbre (demande du MJ, 2026-11-02, à l'essai) : un élément et ses sous-éléments, en branches de gauche à droite.
// Ici, le défilement dans les deux sens est admis : l'arbre garde sa forme plutôt que de se resserrer.
// Un nœud : { id, nom, icone, detail?, ton?, ouvrir? (fonction : le nom devient un lien), groupe? (une simple rubrique,
// sans cadre), replie? (d'office), enfants?, essentiel?, compte?, action? }.
// - ton : 'fait' (bleu), 'en-cours' (rouge), 'a-jouer' (orange : à faire ici), 'alerte' (rouge appuyé : en retard),
//   'discret' (passé ou ailleurs : en sourdine).
// - essentiel : un enfant qui reste visible quand son parent est replié (ce qu'il y a à jouer) ; déplier montre tout.
// - compte : { cle, fait } pour un élément qui compte dans le carré de ses ancêtres, « faits / total » ; `cle` évite de
//   compter deux fois le même élément posé à plusieurs endroits (un PNJ sous deux jalons). Sans `compte`, il n'est pas compté.
// - action, ou actions[] : { icone, titre, actif, fn } : de petits boutons sur le nœud (une résurgence : sa remarque, sa case « jouée »).
// replies : les id des nœuds repliés à la main, gardés d'un rendu à l'autre ; pas encore de choix : `replie` du nœud.

import { h, icone } from './ui.js';

export function vueArbre(racine, choix, surChange) {
  const estReplie = n => (choix.has(n.id) ? choix.get(n.id) : !!n.replie);
  // Ce qui compte sous un nœud : chaque élément une seule fois (par sa clé), fait dès qu'un de ses exemplaires l'est.
  function comptes(n, vus = new Map()) {
    for (const e of (n.enfants || []).filter(Boolean)) {
      if (e.compte) vus.set(e.compte.cle, (vus.get(e.compte.cle) || false) || !!e.compte.fait);
      comptes(e, vus);
    }
    return vus;
  }
  const nombre = n => (n.enfants || []).filter(Boolean).reduce((a, e) => a + (e.groupe ? nombre(e) : 1 + nombre(e)), 0);

  function branche(n) {
    const enfants = (n.enfants || []).filter(Boolean);
    const replie = estReplie(n);
    const montres = replie ? enfants.filter(e => e.essentiel) : enfants;
    const vus = comptes(n);
    const total = vus.size, faits = [...vus.values()].filter(Boolean).length;
    // Le carré : « faits / total » de ce qui compte dessous ; rien à compter : le nombre d'éléments, quand ils sont repliés.
    const libelle = total ? `${faits}/${total}` : replie ? `+${nombre(n)}` : '';
    const nom = n.ouvrir
      ? h('button', { type: 'button', class: 'cm-arbre__nom cm-lien-bouton', onclick: () => n.ouvrir() }, n.nom)
      : h('span', { class: 'cm-arbre__nom' }, n.nom);
    const noeud = h('div', { class: `cm-arbre__noeud${n.groupe ? ' cm-arbre__noeud--groupe' : ''}${n.ton ? ` cm-arbre__noeud--${n.ton}` : ''}` },
      n.icone ? icone(n.icone, 'bn-icone--s') : null,
      h('span', { class: 'cm-arbre__texte' }, nom, n.detail ? h('span', { class: 'cm-arbre__detail' }, n.detail) : null),
      (n.actions || (n.action ? [n.action] : [])).map(a => h('button', { type: 'button', class: 'cm-arbre__action', 'aria-pressed': String(!!a.actif), title: a.titre, 'aria-label': a.titre,
        onclick: () => a.fn() }, icone(a.icone, 'bn-icone--s'))),
      enfants.length ? h('button', { type: 'button', class: 'cm-arbre__plier' + (total && faits === total ? ' est-complet' : ''), 'aria-expanded': String(!replie),
        title: [total ? `${faits} fait${faits > 1 ? 's' : ''} sur ${total}` : null, replie ? `Déplier : ${nombre(n)} élément${nombre(n) > 1 ? 's' : ''}` : 'Replier'].filter(Boolean).join(' · '),
        onclick: () => { choix.set(n.id, !replie); surChange(); } }, h('span', { class: 'cm-arbre__signe' }, replie ? '+' : '−'), libelle && !libelle.startsWith('+') ? h('span', {}, libelle) : libelle ? h('span', {}, libelle.slice(1)) : null) : null);
    return h('li', { class: 'cm-arbre__branche' }, noeud,
      montres.length ? h('ul', { class: 'cm-arbre__enfants' }, montres.map(branche)) : null);
  }
  return h('ul', { class: 'cm-arbre' }, branche(racine));
}
