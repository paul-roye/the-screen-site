// Plugin Écran des joueurs : une seconde fenêtre du gestionnaire (joueurs.html), en plein écran sur un autre écran (la TV
// à plat sous les figurines), que la page du MJ pilote par un canal du navigateur (BroadcastChannel). Étude :
// mainteneur/etudes/ecran-joueurs.md. Décisions du MJ du 2026-11-02 : quarts de tour, brouillard noir pur, carte entière
// avec le cadre des joueurs, grille dessinée en bascule, le tableau des joueurs sans carte.
// - La carte (bibliothèque d'images, app/bibliotheque.js : d'office celles du lieu des héros, version joueurs envoyée) à
//   1 pouce par case : la dalle est mesurée (onglet « Ce poste », propre au PC), la carte calibrée une fois (pixels par case).
//   Rotation, cadrage (le cadre glissé dans la projection), grille, brouillard de combat (formes révélées ou cachées, gardées
//   par carte), ping. État : etat/ecran-joueurs.json (formats/etat.md).
// - Sans carte : le tableau des joueurs (app/tableau-joueurs.js), un fond par lieu (fenêtre d'une image : « Fond des joueurs »,
//   suit lieu:arrivee) et les héros tels que les joueurs les voient, relus toutes les 5 s.
// - Une image en grand (afficherEnGrand de app/ui.js, fenêtre d'une image) peut aller sur l'écran des joueurs.
// Le rendu (app/projection.js) est le même ici (la projection du widget) et dans la page joueurs.
// Jamais de fenêtre bloquante : l'écran absent, la partie continue ; le point d'état le dit.

import { h, icone, bouton, alerte, infobulle, section, flottantOuvert, ouvrirMenu, brancherEcranJoueurs } from '../ui.js';
import { annoncer, etatHorloge, chargerCalendrier, lecture as lectureHorloge } from '../horloge.js';
import { campagneOuverte } from '../campagne.js';
import { chargerBibliotheque } from '../bibliotheque.js';
import { chargerLieux, nomLieu, etatIci } from '../lieux.js';
import { lireBeyond } from '../beyond.js';
import { chargerWiki } from '../wiki.js';
import { etatsCreatures } from '../etats.js';
import { monterProjection, centreDe, cadreJoueurs, ROTATIONS, TERRAINS, JETONS, PIEGES, ZONES, PX_CASE_DEFAUT, mesureContient, formeContient } from '../projection.js';
import { resumeJoueurs, rendreTableau, ambianceDe, SEUILS_DEFAUT } from '../tableau-joueurs.js';

const ID = 'ecran-joueurs';
const NOM_FENETRE = 'the-screen-joueurs';
const CLE_POSTE = 'cm:ecran-joueurs';   // localStorage : { ecran (label), largeur_pouces }
// magnetisme : les formes du brouillard s'aimantent à la grille (carte calibrée) ; pinceau_forme ('carre' | 'rond'),
// pinceau_cases (sa taille, en cases), adouci (le bord flouté du brouillard, en fraction de case, un quinzième d'office) :
// demandes du MJ, 2026-11-03.
const ADOUCI_DEFAUT = 1 / 15;
const DEFAUTS = { actif: false, rotation_defaut: 0, grille_defaut: false, tableau: true, seuils: SEUILS_DEFAUT, magnetisme: false, pinceau_forme: 'carre', pinceau_cases: 1, adouci: ADOUCI_DEFAUT };
// Deux choses séparées (refonte du 2026-11-05, le MJ se perdait entre préparation, diffusion et images) :
// - l'atelier, `carte` : la carte que le MJ prépare dans le widget (ou null) ; l'ouvrir ne change jamais l'écran ;
// - l'écran, `ecran` : ce que voient les joueurs. base : 'tableau' (le tableau des joueurs, vivant) ou 'carte' (`carte`,
//   en direct : chaque geste de l'atelier sur cette carte part aux joueurs ; `gele` : figée sur `instantane`, le temps de
//   la retoucher) ; `image` : une image diffusée par-dessus ({ chemin, legende, rotation?, largeur?, hauteur? }), qu'on
//   retire pour retrouver la base.
// rotations : par image (fond ou image montrée), 0, 90, 180 ou 270 ; d'office 90 pour une image plus haute que large.
const ECRAN_DEFAUT = { base: 'tableau', carte: null, gele: false, instantane: null, image: null };
const ETAT_DEFAUT = { schema: 2, carte: null, cartes: {}, tableau: { fond_defaut: null, fonds: {} }, rotations: {}, ecran: { ...ECRAN_DEFAUT } };
// L'état d'avant la refonte (schéma 1 : `affichage`, `image`, `mode`, `diffusion`) : l'écran garde ce que voyaient les joueurs.
function migrer(val) {
  // L'état chargé a déjà reçu les valeurs par défaut (dont `ecran`) : l'ancien schéma se reconnaît à ses propres champs.
  if (!['affichage', 'image', 'mode', 'diffusion'].some(k => k in val)) return false;
  const d = val.mode === 'preparation' ? val.diffusion?.scene || null : null;
  const aff = d ? d.affichage : val.affichage;
  const e = { ...ECRAN_DEFAUT };
  if (aff === 'carte') {
    e.base = 'carte'; e.carte = d ? d.carte?.id || null : val.carte || null;
    if (d?.carte) { e.gele = true; e.instantane = d.carte; }
  } else if (aff === 'image') e.image = (d ? d.image : val.image) || null;
  if (e.base === 'carte' && !e.carte) e.base = 'tableau';
  val.ecran = e; val.schema = 2;
  for (const k of ['affichage', 'image', 'mode', 'diffusion']) delete val[k];
  return true;
}
const RELEVE_MS = 5000;        // le tableau des joueurs suit le relevé D&D Beyond
const ENVOI_MS = 40;           // envois rapprochés fusionnés (glisser le cadre)

// ───── Réglages du poste (localStorage : la TV est celle de ce PC) ─────

export function poste() {
  try { return JSON.parse(localStorage.getItem(CLE_POSTE) || '{}') || {}; } catch { return {}; }
}
export function ecrirePoste(patch) {
  try { localStorage.setItem(CLE_POSTE, JSON.stringify({ ...poste(), ...patch })); } catch { /* le réglage vaut pour la page */ }
  redessiner();
  envoyer();
}

// ───── État du plugin ─────

let lire = () => DEFAUTS;
let ctx = null, sEtat = null, biblio = null, lieux = null, sIci = null;
let canal = null, fen = null, ecranJ = null;     // ecranJ : { largeur, hauteur, plein_ecran } dit par la page joueurs
let versionMj = false, mireActive = false;
let tableauCache = null, tableauJson = null;
let minuterieEnvoi = null, minuterieReleve = null, minuterieFenetre = null;
const surSceneFns = new Set();          // les projections du MJ (widget), redessinées à chaque changement
const surStatutFns = new Set();
const parId = () => biblio?.parId || new Map();

const imageDe = id => (id ? parId().get(id) || null : null);
function versionJoueurs(i) { if (!i || i.joueurs) return i; const p = i.paire ? parId().get(i.paire) : null; return p?.joueurs ? p : i; }
function versionMjDe(i) { if (!i || !i.joueurs) return i; const p = i.paire ? parId().get(i.paire) : null; return p && !p.joueurs ? p : i; }
const cheminDe = i => encodeURI(i.chemin);

const v = () => sEtat.valeur;
function carteEtat() { const val = v(); val.cartes ||= {}; return (val.cartes[val.carte] ||= {}); }
function changer() { sEtat.enregistrer(0); redessiner(); envoyer(); }
function redessiner() { for (const fn of surSceneFns) { try { fn(); } catch (e) { console.error(e); } } }

// Le fond du tableau des joueurs : celui du sous-lieu des héros, sinon de leur lieu, sinon celui de la campagne.
function fondCourant() {
  const t = v().tableau || {};
  const ici = sIci?.valeur || {};
  const id = (ici.sous_lieu && t.fonds?.[ici.sous_lieu]) || (ici.lieu && t.fonds?.[ici.lieu]) || t.fond_defaut || null;
  const i = versionJoueurs(imageDe(id));
  return i ? { id: i.id, chemin: cheminDe(i), titre: biblio.titre(i), pour: ici.sous_lieu && t.fonds?.[ici.sous_lieu] ? ici.sous_lieu : ici.lieu && t.fonds?.[ici.lieu] ? ici.lieu : null } : null;
}

// Les formes du brouillard, l'échelle et le cadrage sont en px de la version MJ ; la version joueurs peut être d'une autre taille.
function adapterForme(f, kx, ky) {
  if (kx === 1 && ky === 1) return f;
  const pt = ([x, y]) => [x * kx, y * ky];
  return f.type === 'rect' ? { ...f, x: f.x * kx, y: f.y * ky, w: f.w * kx, h: f.h * ky }
    : f.type === 'cercle' ? { ...f, cx: f.cx * kx, cy: f.cy * ky, r: f.r * kx }
    : f.type === 'trait' ? { ...f, points: f.points.map(pt), largeur: f.largeur * kx } : { ...f, points: f.points.map(pt) };
}
function adapter(brouillard, kx, ky) {
  if (kx === 1 && ky === 1) return brouillard;
  return { base: brouillard.base, formes: (brouillard.formes || []).map(f => adapterForme(f, kx, ky)) };
}

// Ce que toute scène porte : le titre, la rotation par défaut, l'écran des joueurs (sa dalle, son rapport).
function enveloppe() {
  const m = campagneOuverte(), r = lire(), p = poste();
  return { titre: m.titre, sous_titre: m.sous_titre || '', rotation: r.rotation_defaut || 0,
    ecran: { largeur_pouces: p.largeur_pouces > 0 ? p.largeur_pouces : null, rapport: ecranJ?.hauteur > 0 ? ecranJ.largeur / ecranJ.hauteur : null } };
}
// Une carte telle que la projection la dessine (pourMj : sa version MJ si le MJ l'a demandée, pour sa projection seule) ; null
// si elle n'est plus dans la bibliothèque.
function carteScene(id, { pourMj = false } = {}) {
  const i = imageDe(id);
  if (!i) return null;
  const r = lire();
  const e = (sEtat?.valeur || ETAT_DEFAUT).cartes?.[i.id] || {};
  const pj = versionJoueurs(i);
  const im = pourMj && versionMj ? i : pj;
  const kx = im.largeur / i.largeur, ky = im.hauteur / i.hauteur;
  const ech = e.echelle;
  return {
    id: i.id, titre: biblio.titre(i), chemin: cheminDe(im), largeur: im.largeur, hauteur: im.hauteur,
    echelle: ech?.px_case > 0 ? { px_case: ech.px_case * kx, origine_x: (ech.origine_x || 0) * kx, origine_y: (ech.origine_y || 0) * ky } : null,
    zoom: e.zoom ?? 'pouce', rotation: e.rotation ?? (r.rotation_defaut || 0),
    cadrage: e.cadrage ? { x: e.cadrage.x * kx, y: e.cadrage.y * ky } : centreDe(im),
    brouillard: { ...adapter(e.brouillard || { base: 'cache', formes: [] }, kx, ky), adouci: ech?.px_case > 0 ? ech.px_case * kx * (r.adouci ?? ADOUCI_DEFAUT) : 0 },
    grille: e.grille ?? !!r.grille_defaut,
    terrains: (e.terrains || []).filter(t => t.forme).map(t => ({ ...t, forme: adapterForme(t.forme, kx, ky) })),
    jetons: (e.jetons || []).map(j => ({ ...j, x: j.x * kx, y: j.y * ky })),
    mesures: (e.mesures || []).map(m => ({ ...m, x1: m.x1 * kx, y1: m.y1 * ky, x2: m.x2 * kx, y2: m.y2 * ky })),
    version_mj: im !== pj, sans_version_joueurs: !pj.joueurs,
  };
}
// La scène de l'atelier : la carte que le MJ prépare, pour sa projection (affichage 'vide' sans carte).
export function sceneCourante({ pourMj = false } = {}) {
  const sc = { ...enveloppe(), affichage: 'vide' };
  const c = carteScene((sEtat?.valeur || ETAT_DEFAUT).carte, { pourMj });
  if (c) { sc.affichage = 'carte'; sc.carte = c; sc.rotation = c.rotation; }
  return sc;
}
// Le tableau des joueurs (vivant : le relevé D&D Beyond) et son fond, avec leurs rotations (retour du MJ, 2026-11-03 : le
// tableau et le fond tournent chacun de leur côté ; une image plus haute que large est en portrait d'office).
function completerTableau(sc) {
  const val = v(), r = lire();
  const f = fondCourant();
  if (r.tableau === false || !tableauCache) { delete sc.tableau; return; }
  sc.tableau = { ...tableauCache, fond: f?.chemin || null, rotation: val.tableau?.rotation ?? (r.rotation_defaut || 0), fond_rotation: f ? rotationDe(f.id) : 0 };
}
const rotationDefautDe = i => (i && i.hauteur > i.largeur ? 90 : 0);
const rotationDe = id => v().rotations?.[id] ?? rotationDefautDe(imageDe(id));
// L'image montrée en grand n'est connue que par son chemin : son entrée de la bibliothèque, si elle y est, dit si elle est en portrait.
function rotationImageDefaut(image) {
  const i = biblio?.index.images.find(x => cheminDe(x) === image.chemin) || null;
  if (i) return rotationDefautDe(i);
  if (image.largeur && image.hauteur) return image.hauteur > image.largeur ? 90 : 0;
  return 0;
}
const tourner = d => ROTATIONS[(ROTATIONS.indexOf(d || 0) + 1) % 4];
function tournerTableau() { const t = (v().tableau ||= { fond_defaut: null, fonds: {} }); t.rotation = tourner(t.rotation ?? (lire().rotation_defaut || 0)); changer(); }
function tournerFond() { const f = fondCourant(); if (!f) return; (v().rotations ||= {})[f.id] = tourner(rotationDe(f.id)); changer(); }
function tournerImage() { const im = ecran().image; if (!im) return; im.rotation = tourner(im.rotation ?? rotationImageDefaut(im)); changer(); }

// ───── L'écran : ce que voient les joueurs (refonte du 2026-11-05) ─────
const ecran = () => (v().ecran ||= { ...ECRAN_DEFAUT });
// 'image' (par-dessus tout), 'carte' ou 'tableau' (aussi quand la carte de l'écran n'est plus dans la bibliothèque).
function surEcran() { const e = ecran(); return e.image?.chemin ? 'image' : e.base === 'carte' && (e.gele && e.instantane || imageDe(e.carte)) ? 'carte' : 'tableau'; }
// En direct : la carte de l'atelier est celle de l'écran, et l'écran n'est pas gelé ; chaque geste part aux joueurs.
const enDirect = () => { const e = ecran(); return e.base === 'carte' && !!v().carte && e.carte === v().carte && !e.gele; };
// Ce que reçoit la page joueurs.
function sceneJoueurs() {
  const sc = { ...enveloppe(), affichage: 'tableau' };
  if (mireActive) { sc.affichage = 'mire'; return sc; }
  if (!sEtat) return sc;
  const e = ecran();
  if (e.image?.chemin) { sc.affichage = 'image'; sc.image = { ...e.image, rotation: e.image.rotation ?? rotationImageDefaut(e.image) }; return sc; }
  if (e.base === 'carte') {
    const c = e.gele && e.instantane ? e.instantane : carteScene(e.carte);
    if (c) { sc.affichage = 'carte'; sc.carte = c; sc.rotation = c.rotation; return sc; }
  }
  completerTableau(sc);
  return sc;
}
// Diffuser : la carte de l'atelier devient l'écran, en direct (une image diffusée par-dessus est retirée).
function diffuser() {
  const val = v();
  if (!imageDe(val.carte)) return;
  Object.assign(ecran(), { base: 'carte', carte: val.carte, gele: false, instantane: null, image: null });
  changer();
  if (!fenetreVivante()) ouvrirFenetre();
}
function diffuserTableau() { Object.assign(ecran(), { ...ECRAN_DEFAUT }); changer(); }
// Geler : l'écran garde la carte telle qu'elle est, le temps de la retoucher dans l'atelier ; dégeler la rend au direct.
function basculerGel() {
  const e = ecran();
  if (e.base !== 'carte') return;
  if (e.gele) { e.gele = false; e.instantane = null; }
  else { const c = carteScene(e.carte); if (!c) return; e.instantane = JSON.parse(JSON.stringify(c)); e.gele = true; }
  changer();
}
function retirerImage() { ecran().image = null; changer(); }
// « Tableau des joueurs », « Death house », « Image · Ine ».
function nomEcran() {
  const e = ecran(), quoi = surEcran();
  if (mireActive) return 'Mire';
  if (quoi === 'image') return e.image.legende ? `Image · ${e.image.legende}` : 'Image';
  if (quoi === 'carte') return (e.gele && e.instantane ? e.instantane.titre : biblio?.titre(imageDe(e.carte))) || 'Carte';
  return 'Tableau des joueurs';
}

// ───── Canal vers la page joueurs ─────

function ouvrirCanal() {
  canal = new BroadcastChannel('the-screen:joueurs:' + (campagneOuverte().id || 'defaut'));
  canal.onmessage = e => {
    const d = e.data || {};
    if (d.type === 'bonjour') envoyer(true);
    else if (d.type === 'ecran') { ecranJ = { largeur: d.largeur, hauteur: d.hauteur, plein_ecran: !!d.plein_ecran }; majStatut(); redessiner(); envoyer(true); }
    else if (d.type === 'aurevoir') { ecranJ = null; majStatut(); }
  };
}
function envoyer(toutDeSuite = false) {
  if (!canal) return;
  clearTimeout(minuterieEnvoi);
  const faire = () => { minuterieEnvoi = null; try { canal.postMessage({ type: 'etat', scene: sceneJoueurs() }); } catch (e) { console.error('Écran des joueurs : envoi impossible', e); } };
  if (toutDeSuite) faire(); else minuterieEnvoi = setTimeout(faire, ENVOI_MS);
}

// ───── La fenêtre ─────

const fenetreVivante = () => (fen && !fen.closed) || !!ecranJ;
// code : inactif, fermee, ouverte (pas en plein écran), plein.
function codeStatut() { return !sEtat ? 'inactif' : !fenetreVivante() ? 'fermee' : ecranJ?.plein_ecran ? 'plein' : 'ouverte'; }
const STATUTS = {
  inactif: { libelle: 'Plugin désactivé', ton: 'cendre' },
  fermee: { libelle: 'Écran des joueurs fermé', ton: 'cendre' },
  ouverte: { libelle: 'Écran des joueurs ouvert, pas en plein écran', ton: 'cierge' },
  plein: { libelle: 'Écran des joueurs en plein écran', ton: 'mousse' },
};
let statutAffiche = null;
function majStatut() {
  const code = codeStatut();
  if (code === statutAffiche) return;
  statutAffiche = code;
  surStatutFns.forEach(fn => { try { fn(code); } catch (e) { console.error(e); } });
}

// Ouvrir la fenêtre sur l'écran choisi (Window Management API de Chrome : permission demandée une fois), en plein écran
// quand le navigateur le permet (« fullscreen » de window.open) ; sinon elle s'ouvre, et un clic dedans suffit.
export async function ouvrirFenetre() {
  if (fen && !fen.closed) { try { fen.focus(); } catch { /* fenêtre d'un autre écran */ } if (ecranJ) return; }
  let traits = 'popup';
  try {
    if ('getScreenDetails' in window) {
      const d = await window.getScreenDetails();
      const voulu = poste().ecran;
      const e = d.screens.find(s => s.label === voulu) || d.screens.find(s => s !== d.currentScreen && !s.isPrimary) || d.screens.find(s => s !== d.currentScreen) || d.currentScreen;
      traits = `popup,fullscreen,left=${e.availLeft},top=${e.availTop},width=${e.availWidth},height=${e.availHeight}`;
    }
  } catch (e) { console.warn(`Écrans : ${e.message} (la fenêtre s'ouvrira sur cet écran)`); }
  fen = window.open('joueurs.html', NOM_FENETRE, traits);
  if (!fen) {
    annoncer({ cle: ID, titre: 'Fenêtre des joueurs bloquée', icone: 'lu-monitor', couleur: 'cierge', texte: 'Le navigateur a bloqué l\'ouverture : autorisez les fenêtres surgissantes pour localhost, puis réessayez.' });
    return;
  }
  clearInterval(minuterieFenetre);
  minuterieFenetre = setInterval(() => { if (!fen || fen.closed) { clearInterval(minuterieFenetre); if (!ecranJ) majStatut(); } }, 2000);
  setTimeout(majStatut, 500);
}
export function fermerFenetre() {
  try { canal?.postMessage({ type: 'fermer' }); } catch { /* canal fermé */ }
  try { fen?.close(); } catch { /* pas la nôtre */ }
  fen = null; ecranJ = null;
  majStatut();
}
export const ecranOuvert = () => fenetreVivante();

// ───── Ce que le MJ affiche ─────

// Ouvrir une carte dans l'atelier : rien ne change à l'écran tant qu'elle n'est pas diffusée.
function afficherCarte(id) {
  const i = versionMjDe(imageDe(id));
  if (!i) return;
  v().carte = i.id;
  carteEtat();
  changer();
}
// Une image diffusée (l'icône de diffusion d'une image, « Montrer maintenant ») : par-dessus ce qu'il y a à l'écran, sans
// toucher à l'atelier ; « Retirer » rend ce qu'il y avait.
export function montrerImage(chemin, legende = '') {
  if (!sEtat) return;
  // Une image hors de la bibliothèque : sa taille, lue au chargement, dit si elle est en portrait.
  if (!biblio?.index.images.some(x => cheminDe(x) === chemin)) {
    const im = new Image();
    im.referrerPolicy = 'no-referrer';   // une image distante (D&D Beyond) refuse le référent
    im.onload = () => {
      const cible = ecran().image;
      if (cible?.chemin !== chemin || cible.rotation != null) return;
      cible.largeur = im.naturalWidth; cible.hauteur = im.naturalHeight;
      changer();
    };
    im.src = chemin;
  }
  ecran().image = { chemin, legende };
  changer();
  if (!fenetreVivante()) ouvrirFenetre();
}
// Le fond du tableau des joueurs : pour un lieu (null : le fond de la campagne) ; image null : retirer.
function choisirFond(lieuId, imageId) {
  const t = (v().tableau ||= { fond_defaut: null, fonds: {} });
  t.fonds ||= {};
  if (lieuId) { if (imageId) t.fonds[lieuId] = imageId; else delete t.fonds[lieuId]; }
  else t.fond_defaut = imageId || null;
  changer();
}
// Le ping part aux joueurs s'ils voient la carte de l'atelier (en direct ou gelée, sans image par-dessus).
function ping(x, y) {
  if (surEcran() !== 'carte' || ecran().carte !== v().carte) return;
  try { canal?.postMessage({ type: 'ping', x, y }); } catch { /* canal fermé */ }
}

// Le tableau des joueurs suit le relevé D&D Beyond (toutes les 5 s quand il est affiché), le lieu, le fond et l'horloge
// (météo, moment de la journée, lune : retours du MJ, 2026-11-03).
let sHorloge = null;
async function calculerTableau() {
  if (!ctx) return false;
  const [beyond, lp, wiki, sCr] = await Promise.all([lireBeyond(), ctx.donnees('personnages'), chargerWiki().catch(() => null), etatsCreatures(), chargerCalendrier(ctx.donnees).catch(() => null)]);
  sHorloge ||= await etatHorloge(ctx.etat).catch(() => null);
  let ambiance = null;
  try { if (sHorloge) ambiance = ambianceDe(sHorloge.valeur, lectureHorloge(sHorloge.valeur)); } catch (e) { console.error('Écran des joueurs : ambiance du tableau', e); }
  const t = resumeJoueurs({ beyond, personnages: lp.donnees, wiki, seuils: { ...SEUILS_DEFAUT, ...(lire().seuils || {}) }, titre: campagneOuverte().titre, etatsCreatures: sCr.valeur.creatures, ambiance });
  const json = JSON.stringify(t);
  if (json === tableauJson) return false;
  tableauJson = json; tableauCache = t;
  return true;
}
async function suivreTableau() {
  if (!sEtat || surEcran() !== 'tableau') return;   // le mini-aperçu du widget le montre aussi, fenêtre ouverte ou non
  if (await calculerTableau()) { redessiner(); envoyer(); }
}

// ───── Widget « Écran des joueurs » ─────

// Les outils (retours du MJ du 2026-11-03) : en haut, par groupes espacés, annuler et tout ; aimant ; assombrir, éclaircir ;
// les formes (pinceau, rectangle, rond, polygone) ; jeton, terrain ; distance, zone d'effet ; à droite, échelle et rotation.
// À gauche de la projection : grille, vue, calibrage, puis la main et le ping. Le type d'un jeton, d'un terrain ou d'une
// zone d'effet, la forme et la taille du pinceau, les cases du calibrage : une petite barre flottante sous le bouton.
// outil : deplacer | ping | calibrer | brouillard (mode eclaircir / assombrir / terrain, forme trait / rect / rond / polygone)
// | jeton | distance | zone. Les formes du dessin : [clé, nom, aide, icône].
const FORMES = [
  ['trait', 'Pinceau', 'Glisser ; un clic sur le bouton : carré ou rond, et sa taille en cases.', 'lu-brush'],
  ['rect', 'Rectangle', 'Glisser d\'un coin à l\'autre.', 'lu-rectangle-horizontal'],
  ['rond', 'Rond', 'Glisser depuis le centre.', 'lu-circle'],
  ['polygone', 'Polygone', 'Clics pour les sommets ; clic droit retire le dernier ; double-clic ou Entrée ferme.', 'lu-pentagon'],
];
const svgEl = (tag, attrs) => { const el = document.createElementNS('http://www.w3.org/2000/svg', tag); for (const [k, val] of Object.entries(attrs)) el.setAttribute(k, val); return el; };

function vueWidget({ corps, resume, ajusterHauteur }) {
  let outil = 'deplacer', mode = 'eclaircir', forme = 'rect', terrain = 'difficile', jeton = 'porte', piege = 'pics', zoneType = 'cone';
  let casesCalibrage = 1, calibrageA = null, trace = null, poly = null, apercuGrand = false;
  const zone = h('div', { class: 'cm-ecran__projection', tabindex: '0', 'aria-label': 'Atelier : la carte entière et le cadre des joueurs' });
  const proj = monterProjection(zone, { mode: 'mj' });
  // Ce que voient les joueurs, tel quel, aux proportions de leur fenêtre : en miniature dans le bandeau « À l'écran », ou
  // en grand sous l'atelier (un clic sur la miniature). Le même élément, déplacé de l'un à l'autre.
  const zoneJ = h('div', { class: 'cm-ecran__projection cm-ecran__projection--joueurs', 'aria-label': 'Ce que voient les joueurs, tel quel' });
  const projJ = monterProjection(zoneJ, { mode: 'joueurs' });
  const bandeau = h('div', { class: 'cm-ecran__bandeau' });
  const atelier = h('div', { class: 'cm-ecran__atelier' });
  const logeMini = infobulle(h('button', { type: 'button', class: 'cm-ecran__mini', 'aria-label': 'Ce que voient les joueurs', onclick: () => { apercuGrand = !apercuGrand; rendre(); } }),
    'Ce que voient les joueurs, tel quel. Un clic : en grand sous l\'atelier, un autre le range ici.', { titre: 'À l\'écran' });
  const logeGrande = h('div', { class: 'cm-ecran__grand', hidden: true });
  const vide = h('p', { class: 'cm-ecran__vide ui-s cm-sourdine', hidden: true }, 'Choisissez une carte à préparer : elle n\'ira à l\'écran des joueurs qu\'au clic sur « Diffuser ».');
  const barreOutils = h('div', { class: 'cm-ecran__outils' });
  const barreLaterale = h('div', { class: 'cm-ecran__laterale', role: 'toolbar', 'aria-label': 'Carte et projection' });
  barreOutils.setAttribute('role', 'toolbar'); barreOutils.setAttribute('aria-label', 'Outils de dessin et de mesure');
  const infos = h('div', { class: 'cm-ecran__infos ui-s' });
  const champCases = h('input', { class: 'bn-input cm-ecran__n', type: 'number', min: 1, max: 60, value: casesCalibrage, 'aria-label': 'Nombre de cases entre les deux clics', onchange: e => { casesCalibrage = Math.max(1, Number(e.target.value) || 1); } });
  const ecrireReglage = patch => ctx?.reglages.ecrire(patch);
  const champPinceau = h('input', { class: 'bn-input cm-ecran__n', type: 'number', min: 0.25, max: 10, step: 0.25, value: lire().pinceau_cases || 1, 'aria-label': 'Taille du pinceau, en cases', onchange: e => ecrireReglage({ pinceau_cases: Math.max(0.25, Number(e.target.value) || 1) }) });
  // Magnétisme : un point aimanté à la grille (carte calibrée) ; 'coin' : l'intersection de lignes la plus proche
  // (rectangles, polygones) ; 'case' : le centre de la case (empreintes du pinceau).
  function aimant(p, mode) {
    const e = carte()?.echelle;
    if (!lire().magnetisme || !(e?.px_case > 0)) return p;
    const q = e.px_case, ox = e.origine_x || 0, oy = e.origine_y || 0;
    const f = v => (mode === 'case' ? Math.floor(v) + 0.5 : Math.round(v));
    return { x: ox + f((p.x - ox) / q) * q, y: oy + f((p.y - oy) / q) * q };
  }
  const aimante = () => !!(lire().magnetisme && carte()?.echelle?.px_case > 0);
  // L'aperçu du pinceau (sa forme, à la taille d'une empreinte) suit le pointeur, à la place du curseur.
  let apercu = null;
  function montrerApercu(p) {
    const rond = lire().pinceau_forme === 'rond', s = (lire().pinceau_cases || 1) * pxCase(), a = aimant(p, 'case');
    if (apercu && (apercu.tagName === 'circle') !== rond) { apercu.remove(); apercu = null; }
    if (!apercu) { apercu = svgEl(rond ? 'circle' : 'rect', {}); proj.calque.append(apercu); }
    apercu.setAttribute('class', `${classeTrace()} cm-ecran__apercu`);
    apercu.setAttribute('style', styleTrace());
    if (rond) Object.entries({ cx: a.x, cy: a.y, r: s / 2 }).forEach(([k, val]) => apercu.setAttribute(k, val));
    else Object.entries({ x: a.x - s / 2, y: a.y - s / 2, width: s, height: s }).forEach(([k, val]) => apercu.setAttribute(k, val));
  }
  function cacherApercu() { apercu?.remove(); apercu = null; }

  const sceneMj = () => sceneCourante({ pourMj: true });
  const carte = () => sceneMj().carte;
  const pxCase = () => carte()?.echelle?.px_case || PX_CASE_DEFAUT;

  // ── Le choix de la carte de l'atelier : son nom, cliquable (une liste native, discrète) ; « Ici » (le lieu des héros,
  // sous-lieux compris) d'abord, puis par lieu, puis sans lieu. Choisir une carte ne change rien à l'écran des joueurs.
  function selectCartes() {
    const val = v();
    const sel = h('select', { class: 'bn-select cm-ecran__carte', 'aria-label': 'Carte de l\'atelier', onchange: e => { if (e.target.value) afficherCarte(e.target.value); } });
    if (!biblio || !lieux) { sel.disabled = true; sel.replaceChildren(h('option', { value: '' }, biblio === null && lieux ? 'Bibliothèque d\'images pas indexée' : 'Chargement…')); return sel; }
    if (!imageDe(val.carte)) sel.append(h('option', { value: '', selected: true }, 'Choisir une carte…'));
    const cartes = biblio.index.images.filter(i => i.categorie === 'carte' && !i.joueurs);
    const ici = sIci?.valeur.lieu || null;
    const dansIci = i => !!ici && biblio.lieuxDe(i).some(id => id === ici || lieux.get(id)?.parent === ici);
    const libelle = i => biblio.titre(i) + (versionJoueurs(i).joueurs ? ' · J' : '');
    const trier = l => [...l].sort((a, b) => biblio.titre(a).localeCompare(biblio.titre(b), 'fr'));
    const dIci = trier(cartes.filter(dansIci));
    // Une carte du lieu des héros est listée deux fois (« Ici », puis son lieu) : choisie une seule fois, dans « Ici ».
    const option = (i, choisie = true) => h('option', { value: i.id, selected: choisie && i.id === val.carte }, libelle(i));
    if (dIci.length) sel.append(h('optgroup', { label: `Ici : ${nomLieu(lieux, ici)}` }, dIci.map(i => option(i))));
    const parLieu = new Map();
    for (const i of cartes) { const l = biblio.lieuxDe(i)[0] || ''; if (!parLieu.has(l)) parLieu.set(l, []); parLieu.get(l).push(i); }
    const ordre = [...parLieu.keys()].sort((a, b) => (a === '' ? 1 : b === '' ? -1 : nomLieu(lieux, a).localeCompare(nomLieu(lieux, b), 'fr')));
    for (const l of ordre) sel.append(h('optgroup', { label: l ? nomLieu(lieux, l) : 'Sans lieu' }, trier(parLieu.get(l)).map(i => option(i, !dIci.includes(i)))));
    return sel;
  }

  // ── Le bandeau « À l'écran » : ce que voient les joueurs (miniature, nom) et les seules commandes de leur écran.
  const pastille = (texte, ton, aide) => infobulle(h('span', { class: 'cm-ecran__pastille', 'data-ton': ton }, texte), aide, { titre: texte });
  function peindreBandeau() {
    const e = ecran(), quoi = mireActive ? 'mire' : surEcran();
    const fond = fondCourant();
    const btn = (ic, titre, aide, onclick, attrs = {}) => infobulle(bouton('', { icone: ic, classe: 'bn-btn--s bn-btn--fantome', titre, onclick, ...attrs }), aide, { titre });
    const commandes = quoi === 'image' ? [
      btn('lu-rotate-cw', 'Tourner l\'image', `Un quart de tour de plus (${sceneJoueurs().image?.rotation || 0}°). Une image plus haute que large arrive en portrait.`, tournerImage),
      infobulle(bouton('Retirer', { icone: 'lu-x', classe: 'bn-btn--s', titre: 'Retirer l\'image', onclick: retirerImage }), `Retire l'image : l'écran retrouve ${e.base === 'carte' && surEcranSansImage() === 'carte' ? 'la carte' : 'le tableau des joueurs'}.`, { titre: 'Retirer l\'image' }),
    ] : quoi === 'carte' ? [
      btn('lu-snowflake', 'Geler l\'écran', e.gele ? 'Écran gelé : les joueurs gardent la carte telle qu\'elle était. Un clic la rend au direct, avec vos retouches.' : 'Geler : les joueurs gardent la carte telle qu\'elle est, le temps de la retoucher dans l\'atelier sans rien montrer.', basculerGel, { 'aria-pressed': String(!!e.gele) }),
      btn('lu-users', 'Tableau des joueurs', 'Remettre le tableau des joueurs à l\'écran (le fond du lieu, l\'état des héros, l\'inventaire commun). La carte reste dans l\'atelier.', diffuserTableau),
    ] : quoi === 'tableau' ? [
      btn('lu-rotate-cw', 'Tourner le tableau', `Un quart de tour de plus (${v().tableau?.rotation ?? (lire().rotation_defaut || 0)}°) : en portrait, pour une lecture depuis un petit côté de la table.`, tournerTableau),
      fond ? infobulle(bouton('', { icone: 'lu-ellipsis', classe: 'bn-btn--s bn-btn--fantome', titre: 'Fond du tableau', onclick: ev => ouvrirMenu(ev.currentTarget, [
        [`Tourner le fond (${rotationDe(fond.id)}°)`, '', tournerFond],
        ['Retirer ce fond', '', () => choisirFond(fond.pour, null)],
      ], 'Fond du tableau') }), `Fond : ${fond.titre}${fond.pour ? ` (${nomLieu(lieux, fond.pour)})` : ''}. Le tourner, indépendamment du tableau, ou le retirer. Un fond se choisit dans la fenêtre d'une image.`, { titre: 'Fond du tableau' }) : null,
    ] : [];
    logeMini.setAttribute('aria-pressed', String(apercuGrand));
    bandeau.replaceChildren(...[
      h('span', { class: 'cm-ecran__etiquette' }, 'À l\'écran'),
      logeMini,
      h('span', { class: 'cm-ecran__nom' }, nomEcran()),
      quoi === 'carte' && e.gele ? pastille('Gelée', 'brume', 'Les joueurs gardent la carte telle qu\'elle était quand vous l\'avez gelée.') : null,
      h('span', { class: 'cm-ecran__ressort' }),
      ...commandes,
    ].filter(Boolean));
  }
  // La base de l'écran, sous une image diffusée.
  const surEcranSansImage = () => { const e = ecran(); return e.base === 'carte' && (e.gele && e.instantane || imageDe(e.carte)) ? 'carte' : 'tableau'; };

  // ── L'atelier : la carte qu'on prépare (son nom ouvre la liste), où elle en est, et « Diffuser ».
  function peindreAtelier() {
    const e = ecran(), c = carte();
    const memeCarte = !!c && e.base === 'carte' && e.carte === v().carte;
    const etat = !c ? null
      : memeCarte && e.image?.chemin ? pastille('Derrière l\'image', 'cendre', 'Cette carte est à l\'écran, sous l\'image diffusée : « Retirer » la rend aux joueurs.')
        : memeCarte && e.gele ? pastille('Retouches en attente', 'brume', 'L\'écran est gelé : vos retouches partiront aux joueurs au dégel (le flocon du bandeau), ou tout de suite par « Diffuser ».')
          : memeCarte ? pastille('En direct', 'mousse', 'Les joueurs voient cette carte : chaque geste (brouillard, jetons, cadrage) part chez eux. « Geler », dans le bandeau, pour retoucher sans montrer.')
            : pastille('Pas à l\'écran', 'cierge', `Les joueurs voient : ${nomEcran()}. Préparez cette carte tranquillement (calibrage, brouillard, jetons), puis « Diffuser ».`);
    atelier.replaceChildren(...[
      h('span', { class: 'cm-ecran__etiquette' }, 'Atelier'),
      selectCartes(),
      etat,
      h('span', { class: 'cm-ecran__ressort' }),
      c && (!memeCarte || e.gele || e.image?.chemin) ? infobulle(bouton('Diffuser', { icone: 'lu-cast', classe: 'bn-btn--s bn-btn--primaire', titre: 'Diffuser cette carte', onclick: diffuser }),
        memeCarte ? 'Envoyer la carte aux joueurs telle qu\'elle est maintenant, et revenir au direct.' : 'Envoyer cette carte à l\'écran des joueurs. Vous serez alors en direct dessus.', { titre: 'Diffuser' }) : null,
    ].filter(Boolean));
  }

  // Un bouton d'outil : enfoncé quand il est l'outil en cours (ou `actif`), un clic le choisit (ou `onclick`).
  const btnOutil = (id, nom, aide, ic, { actif = outil === id, onclick = () => choisirOutil(id), style = '' } = {}) =>
    infobulle(h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome bn-btn--icone', 'data-outil': id, 'aria-pressed': String(actif), 'aria-label': nom, ...(style ? { style } : {}), onclick }, icone(ic)), aide, { titre: nom });
  function choisirOutil(id) { outil = id; annulerTrace(); zone.style.cursor = ''; peindreOutils(); }
  function choisirMode(m) { mode = m; choisirOutil('brouillard'); }
  function choisirForme(f) { forme = f; choisirOutil('brouillard'); }
  // Une petite barre flottante sous un bouton d'outil (demande du MJ, 2026-11-03 : pas une ligne d'options de plus) : les
  // types de jeton, de terrain ou de zone d'effet, la forme et la taille du pinceau, les cases du calibrage. Popover natif :
  // un clic ailleurs ou Échap la referment ; `contenu()` la remplit, et la remplit de nouveau après un choix qui la garde.
  let palette = null;
  function fermerPalette() { try { palette?.hidePopover(); } catch { /* déjà fermée */ } palette = null; }
  function ouvrirPalette(id, etiquette, contenu) {
    fermerPalette();
    const ancre = corps.querySelector(`[data-outil="${id}"]`);
    if (!ancre) return;
    const pal = h('div', { class: 'bn-menu cm-ecran__palette', popover: 'auto', role: 'toolbar', 'aria-label': etiquette });
    const remplir = () => pal.replaceChildren(...contenu(remplir).flat().filter(Boolean));
    remplir();
    pal.addEventListener('toggle', ev => { if (ev.newState !== 'open') { pal.remove(); if (palette === pal) palette = null; } });
    document.body.append(pal);
    const r = ancre.getBoundingClientRect();
    Object.assign(pal.style, { left: Math.round(r.left) + 'px', top: Math.round(r.bottom + 4) + 'px' });
    pal.showPopover();
    const m = pal.getBoundingClientRect();
    if (m.right > innerWidth - 8) pal.style.left = Math.round(innerWidth - m.width - 8) + 'px';
    if (m.bottom > innerHeight - 8) pal.style.top = Math.round(r.top - m.height - 4) + 'px';
    palette = pal;
  }
  // Un bouton de palette (un type) : enfoncé pour le choix en cours ; `couleur` : dans son rôle de couleur de la charte.
  const btnChoix = (nom, ic, actif, onclick, ton = '') => infobulle(h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome bn-btn--icone', 'aria-pressed': String(actif), 'aria-label': nom, ...(ton ? { style: `color: var(--${ton})` } : {}), onclick }, icone(`lu-${ic}`)), nom, { titre: nom });
  // Les palettes : un choix referme la palette et repeint la barre (le bouton prend l'icône du type choisi).
  const paletteJetons = () => ouvrirPalette('jeton', 'Type de jeton', remplir => [
    JETONS.map(([cle, nom, ic, ton]) => btnChoix(nom, ic, cle === jeton, () => { jeton = cle; if (cle === 'piege') { remplir(); peindreOutils(); } else { fermerPalette(); peindreOutils(); } }, ton)),
    jeton === 'piege' ? h('select', { class: 'bn-select', 'aria-label': 'Type de piège', onchange: ev => { piege = ev.target.value; fermerPalette(); } }, PIEGES.map(([cle, nom]) => h('option', { value: cle, selected: cle === piege }, nom))) : null,
  ]);
  const paletteTerrains = () => ouvrirPalette('terrain', 'Type de terrain', () => TERRAINS.map(([cle, nom, ic, ton]) => btnChoix(nom, ic, cle === terrain, () => { terrain = cle; fermerPalette(); peindreOutils(); }, ton)));
  const paletteZones = () => ouvrirPalette('zone', 'Zone d\'effet', () => ZONES.map(([cle, nom, ic]) => btnChoix(nom, ic, cle === zoneType, () => { zoneType = cle; fermerPalette(); peindreOutils(); })));
  const palettePinceau = () => ouvrirPalette('forme-trait', 'Pinceau', remplir => [
    btnChoix('Pinceau carré', 'square', lire().pinceau_forme !== 'rond', () => { ecrireReglage({ pinceau_forme: 'carre' }); remplir(); }),
    btnChoix('Pinceau rond', 'circle', lire().pinceau_forme === 'rond', () => { ecrireReglage({ pinceau_forme: 'rond' }); remplir(); }),
    h('label', { class: 'cm-ecran__champ' }, champPinceau, 'case'),
  ]);
  const paletteCalibrage = () => ouvrirPalette('calibrer', 'Calibrage', () => [h('label', { class: 'cm-ecran__champ' }, 'sur', champCases, 'cases')]);


  function peindreOutils() {
    const sc = sceneMj(), c = sc.carte;
    barreOutils.hidden = !c;
    barreLaterale.hidden = !c;
    if (!c) { fermerPalette(); return; }
    const e = carteEtat();
    const zoomLibelle = c.zoom === 'ecran' || (c.zoom === 'pouce' && !(c.echelle && sc.ecran.largeur_pouces)) ? 'Entière' : c.zoom === 'pouce' ? '1″' : `×${(+c.zoom).toFixed(2).replace(/\.?0+$/, '')}`;
    const btnZoom = infobulle(bouton(zoomLibelle, { icone: 'lu-maximize-2', classe: 'bn-btn--s bn-btn--fantome cm-ecran__zoom', titre: 'Échelle', onclick: ev => ouvrirMenu(ev.currentTarget, [
      ['1 pouce par case' + (c.echelle ? '' : ' (calibrer d\'abord)') + (sc.ecran.largeur_pouces ? '' : ' (régler l\'écran)'), '', () => { e.zoom = 'pouce'; changer(); }, () => c.zoom === 'pouce'],
      ['Carte entière', '', () => { e.zoom = 'ecran'; changer(); }, () => c.zoom === 'ecran'],
      ['Zoom + (×1,25)', '', () => zoomer(1.25)],
      ['Zoom − (÷1,25)', '', () => zoomer(1 / 1.25)],
    ], 'Échelle de la carte') }), 'L\'échelle sur l\'écran des joueurs : 1 pouce par case (figurines), la carte entière, ou libre (Zoom + et Zoom −). La molette, elle, ne zoome que votre projection.', { titre: 'Échelle' });
    const groupe = (...els) => h('span', { class: 'cm-ecran__groupe' }, els.flat().filter(Boolean));
    const td = terrainDef(), jd = JETONS.find(j => j[0] === jeton) || JETONS[0], zd = ZONES.find(z => z[0] === zoneType) || ZONES[0];
    const btnAimant = infobulle(bouton('', { icone: 'lu-magnet', classe: 'bn-btn--s bn-btn--fantome', 'aria-pressed': String(!!lire().magnetisme), titre: 'Magnétisme', disabled: !c.echelle, onclick: () => ecrireReglage({ magnetisme: !lire().magnetisme }) }),
      c.echelle ? 'Les rectangles, ronds, polygones et mesures s\'alignent sur la grille, le pinceau et les jetons case par case.' : 'Le magnétisme demande une carte calibrée.', { titre: 'Magnétisme' });
    // Un bouton de forme : la forme choisie, pour l'opération en cours (éclaircir, assombrir, terrain) ; le pinceau ouvre
    // sa palette (carré ou rond, taille).
    const btnForme = ([f, nom, aide, ic]) => btnOutil(`forme-${f}`, nom, aide, ic, { actif: dessin() && forme === f, onclick: () => { choisirForme(f); if (f === 'trait') palettePinceau(); } });
    // La ligne du haut, par groupes espacés (ordre du MJ, 2026-11-03) ; à droite, l'échelle (large) et la rotation.
    barreOutils.replaceChildren(
      groupe(
        infobulle(bouton('', { icone: 'lu-undo-2', classe: 'bn-btn--s bn-btn--fantome', titre: 'Annuler la dernière forme (Ctrl+Z)', disabled: !(e.brouillard?.formes?.length), onclick: annulerForme }), 'Retire la dernière zone éclaircie ou assombrie.', { titre: 'Annuler' }),
        infobulle(bouton('', { icone: 'lu-square', classe: 'bn-btn--s bn-btn--fantome', titre: 'Tout éclaircir', onclick: () => { e.brouillard = { base: 'revele', formes: [] }; changer(); } }), 'Plus de brouillard : toute la carte visible.', { titre: 'Tout éclaircir' }),
        infobulle(bouton('', { icone: 'lu-square-plein', classe: 'bn-btn--s bn-btn--fantome', titre: 'Tout assombrir', onclick: () => { e.brouillard = { base: 'cache', formes: [] }; changer(); } }), 'Toute la carte sous le brouillard.', { titre: 'Tout assombrir' })),
      groupe(btnAimant),
      groupe(
        btnOutil('assombrir', 'Assombrir', 'Recacher sous le brouillard, avec la forme choisie à droite.', 'lu-cloud-fog', { actif: dessin() && mode === 'assombrir', onclick: () => choisirMode('assombrir') }),
        btnOutil('eclaircir', 'Éclaircir', 'Révéler aux joueurs, avec la forme choisie à droite.', 'lu-sun', { actif: dessin() && mode === 'eclaircir', onclick: () => choisirMode('eclaircir') })),
      groupe(FORMES.map(btnForme)),
      groupe(
        btnOutil('jeton', `Jeton : ${jd[1]}`, 'Un clic sur la carte pose le jeton (porte dissimulée, piège, coffre…) ; la main le déplace ; clic droit le retire. Un clic ici : son type.', `lu-${jd[2]}`, { style: `color: var(--${jd[3]})`, onclick: () => { choisirOutil('jeton'); paletteJetons(); } }),
        btnOutil('terrain', `Terrain : ${td[1]}`, 'Marquer une zone de terrain (hachurée, avec son symbole), avec la forme choisie à gauche. Un clic ici : son type. Clic droit sur une zone : la retire.', `lu-${td[2]}`, { actif: dessin() && mode === 'terrain', style: `color: var(--${td[3]})`, onclick: () => { choisirMode('terrain'); paletteTerrains(); } })),
      groupe(
        btnOutil('distance', 'Distance', 'Glisser : la distance en pieds, mètres et cases, vue des joueurs aussi, jusqu\'à un clic droit dessus.', 'lu-ruler-dimension-line'),
        btnOutil('zone', `Zone d'effet : ${zd[1]}`, 'Glisser depuis l\'origine : la zone d\'effet (cône, cube, cylindre, émanation, ligne, sphère), vue des joueurs aussi, jusqu\'à un clic droit dessus. Un clic ici : son type.', `lu-${zd[2]}`, { onclick: () => { choisirOutil('zone'); paletteZones(); } })),
      h('span', { class: 'cm-ecran__groupe cm-ecran__groupe--droite' },
        btnZoom,
        infobulle(bouton('', { icone: 'lu-rotate-cw', classe: 'bn-btn--s bn-btn--fantome', titre: 'Tourner d\'un quart de tour', onclick: () => { e.rotation = ROTATIONS[(ROTATIONS.indexOf(c.rotation) + 1) % 4]; changer(); } }), `Rotation : ${c.rotation}°. Un clic : un quart de tour de plus.`, { titre: 'Rotation' })));
    // À gauche de la projection : la carte (grille, vue, calibrage), puis la main et le ping.
    barreLaterale.replaceChildren(
      infobulle(bouton('', { icone: 'oeil', classe: 'bn-btn--s bn-btn--fantome', 'aria-pressed': String(versionMj), titre: 'Version MJ', onclick: () => { versionMj = !versionMj; redessiner(); } }),
        versionMj ? 'La version MJ de la carte, pour vos yeux seuls : les joueurs voient leur version.' : 'Voir ici la version MJ de la carte (jamais envoyée aux joueurs).', { titre: 'Version MJ' }),
      infobulle(bouton('', { icone: 'lu-grid-3x3', classe: 'bn-btn--s bn-btn--fantome', 'aria-pressed': String(!!c.grille), titre: 'Grille', onclick: () => { e.grille = !c.grille; changer(); } }), c.echelle ? 'Dessiner la grille des cases par-dessus la carte (pour une carte sans grille).' : 'La grille demande une carte calibrée.', { titre: 'Grille' }),
      infobulle(bouton('', { icone: 'lu-locate-fixed', classe: 'bn-btn--s bn-btn--fantome', titre: 'Toute la carte / la zone projetée', onclick: () => { if (proj.estVueEntiere()) proj.ajusterVueSurCadre(); else proj.ajusterVue(); } }),
        'Un clic : la vue sur la zone projetée (le cadre des joueurs) ; un autre : toute la carte. La vue du MJ seulement : rien ne change pour les joueurs.', { titre: 'Toute la carte / la zone projetée' }),
      btnOutil('calibrer', 'Calibrer l\'échelle', 'Deux clics sur deux coins d\'une même case (ou à N cases l\'un de l\'autre : un clic ici). Zoomez d\'abord à la molette.', 'lu-ruler', { onclick: () => { choisirOutil('calibrer'); paletteCalibrage(); } }),
      h('span', { class: 'cm-ecran__sep' }),
      btnOutil('deplacer', 'Déplacer', 'Glisser le cadre des joueurs par son bord ; ailleurs, la carte sous le cadre ; un jeton pour le déplacer. Molette : zoomer la vue ; bouton droit (ou Ctrl + glisser) : faire défiler la vue.', 'lu-hand'),
      btnOutil('ping', 'Ping', 'Un clic : des ondes à cet endroit, sur les deux écrans. Avec tout outil : un clic du bouton du milieu (la molette).', 'lu-radio'));
    zone.dataset.outil = dessin() ? `${opDe()}-${forme}` : outil;
  }

  function zoomer(k) {
    const sc = sceneMj(), c = sc.carte, e = carteEtat();
    const base = typeof c.zoom === 'number' ? c.zoom : 1;
    e.zoom = Math.min(8, Math.max(0.1, base * k));
    changer();
  }

  function peindreInfos() {
    const sc = sceneMj(), c = sc.carte;
    const p = poste();
    const lignes = [];
    if (sc.affichage === 'carte' && c) {
      const k = cadreJoueurs(sc);
      if (outil === 'calibrer') lignes.push(h('span', { class: 'cm-ecran__alerte' }, icone('lu-ruler', 'bn-icone--s'), casesCalibrage > 1 ? `Calibrage : zoomez à la molette, puis deux clics sur deux coins de cases à ${casesCalibrage} cases l'un de l'autre (même ligne, ou en diagonale).` : 'Calibrage : zoomez à la molette, puis deux clics sur deux coins d\'une même case (un côté, ou la diagonale). Plus précis : « sur N cases » et deux coins plus éloignés.'));
      else if (!c.echelle) lignes.push(h('span', { class: 'cm-ecran__alerte' }, icone('lu-ruler', 'bn-icone--s'), 'Carte non calibrée : « Calibrer », deux clics sur deux coins de cases.'));
      else lignes.push(h('span', {}, `${Math.round(c.echelle.px_case)} px par case · cadre ${(k.w / c.echelle.px_case).toFixed(1).replace('.0', '')} × ${(k.h / c.echelle.px_case).toFixed(1).replace('.0', '')} cases`));
      if (c.sans_version_joueurs) lignes.push(h('span', { class: 'cm-ecran__alerte' }, icone('lu-triangle-alert', 'bn-icone--s'), 'Pas de version joueurs : les joueurs voient la carte MJ.'));
      if (versionMj) lignes.push(h('span', { class: 'cm-ecran__alerte' }, icone('oeil', 'bn-icone--s'), 'Version MJ affichée ici seulement.'));
    }
    if (!(p.largeur_pouces > 0)) lignes.push(h('span', { class: 'cm-ecran__alerte' }, icone('lu-monitor', 'bn-icone--s'), 'Taille de l\'écran non réglée (Campagne, onglet « Ce poste ») : pas de cases de 1 pouce.'));
    if (codeStatut() === 'fermee') lignes.push(h('span', {}, 'Fenêtre des joueurs fermée : un clic sur l\'écran dans l\'en-tête l\'ouvre.'));
    else if (codeStatut() === 'ouverte') lignes.push(h('span', { class: 'cm-ecran__alerte' }, 'Fenêtre ouverte mais pas en plein écran : un clic dedans.'));
    infos.replaceChildren(...lignes.flatMap((l, i) => (i ? [' · ', l] : [l])));
  }

  function peindreResume() {
    const sc = sceneMj();
    const code = codeStatut();
    // Ce que voient les joueurs ; et la carte de l'atelier quand ce n'est pas elle.
    const autre = sc.carte && !(surEcran() === 'carte' && ecran().carte === v().carte) ? ` · Atelier : ${sc.carte.titre}` : '';
    resume.replaceChildren(h('span', { class: 'cm-table__point', 'data-ton': STATUTS[code].ton, title: STATUTS[code].libelle }),
      h('span', { class: 'cm-ecran__resume' }, `${nomEcran()}${enDirect() && surEcran() === 'carte' ? ' · en direct' : ''}${autre}`));
  }

  function rendre() {
    // L'atelier : la carte qu'on prépare, entière, avec le cadre des joueurs dessus ; sans carte, une invitation à en choisir une.
    const sc = sceneMj();
    scene.hidden = !sc.carte;
    vide.hidden = !!sc.carte;
    if (sc.carte) proj.maj(sc);
    // L'écran : ce que voient les joueurs, tel quel, en miniature dans le bandeau ou en grand sous l'atelier.
    const scJ = sceneJoueurs();
    scJ.rendreTableau = rendreTableau;
    zoneJ.style.aspectRatio = String(scJ.ecran.rapport || 16 / 9);
    zoneJ.style.setProperty('--rapport', String(scJ.ecran.rapport || 16 / 9));
    const loge = apercuGrand ? logeGrande : logeMini;
    if (zoneJ.parentElement !== loge) loge.append(zoneJ);
    logeGrande.hidden = !apercuGrand;
    logeMini.classList.toggle('est-vide', apercuGrand);
    projJ.maj(scJ);
    peindreBandeau(); peindreAtelier(); peindreOutils(); peindreInfos(); peindreResume();
  }

  // ── Les gestes sur la projection : en px de carte (proj.versCarte).
  const pointsDe = t => t.points.map(p => `${p[0]},${p[1]}`).join(' ');
  function annulerTrace() { trace?.el?.remove(); trace = null; proj.apercuForme(null); proj.apercuMesure(null); poly?.el?.remove(); poly = null; calibrageA = null; zone.querySelector('.cm-ecran__repere')?.remove(); cacherApercu(); }
  function ajouterForme(f) { const e = carteEtat(); e.brouillard ||= { base: 'cache', formes: [] }; e.brouillard.formes.push(f); changer(); }
  function annulerForme() { const e = carteEtat(); if (e.brouillard?.formes?.length) { e.brouillard.formes.pop(); changer(); } }
  // L'opération du dessin : révéler, recacher, ou marquer un terrain (le mode de la barre latérale).
  const opDe = () => (mode === 'assombrir' ? 'cache' : mode === 'terrain' ? 'terrain' : 'revele');
  const dessin = () => outil === 'brouillard';
  const terrainDef = () => TERRAINS.find(t => t[0] === terrain) || TERRAINS[0];
  const classeTrace = () => `cm-ecran__trace${opDe() === 'cache' ? ' cm-ecran__trace--cache' : opDe() === 'terrain' ? ' cm-ecran__trace--terrain' : ''}`;
  const styleTrace = () => (opDe() === 'terrain' ? `color: var(--${terrainDef()[3]})` : '');
  // Une forme finie va au brouillard (révéler, recacher) ou aux terrains (le type choisi).
  function poserForme(f) {
    if (f.op !== 'terrain') { ajouterForme(f); return; }
    const { op, ...reste } = f;
    const e = carteEtat();
    (e.terrains ||= []).push({ type: terrain, forme: reste });
    changer();
  }
  const poserPolygone = pts => poserForme({ op: opDe(), type: 'polygone', points: pts.map(([x, y]) => [Math.round(x), Math.round(y)]) });
  // L'annotation sous le point p : un jeton (à moins d'une demi-case), sinon une mesure, sinon un terrain, la plus récente
  // d'abord : { liste, index } ou null. Le clic droit la retire ; la main déplace un jeton.
  function annotationSous(p) {
    const e = carteEtat(), q = pxCase();
    const js = e.jetons || [];
    for (let i = js.length - 1; i >= 0; i--) if (Math.hypot(js[i].x - p.x, js[i].y - p.y) <= q * 0.45) return { liste: 'jetons', index: i };
    const ms = e.mesures || [];
    for (let i = ms.length - 1; i >= 0; i--) if (mesureContient(ms[i], p, q)) return { liste: 'mesures', index: i };
    const ts = e.terrains || [];
    for (let i = ts.length - 1; i >= 0; i--) if (ts[i].forme && formeContient(ts[i].forme, p)) return { liste: 'terrains', index: i };
    return null;
  }
  function retirerAnnotation(a) { carteEtat()[a.liste].splice(a.index, 1); changer(); }
  // Une mesure part d'une origine aimantée (centre de case : sphère, cylindre, émanation, cône ; coin : cube, ligne,
  // distance) ; sur une carte calibrée, les zones d'effet se mesurent en cases entières (une au moins).
  const origineMesure = (p, type) => aimant(p, ['sphere', 'cylindre', 'emanation', 'cone'].includes(type) ? 'case' : 'coin');
  function finMesure(t, p) {
    const a = t.depart, q = pxCase();
    if (t.type === 'distance') return aimant(p, 'coin');
    if (!carte()?.echelle) return p;
    const n = v => Math.max(1, Math.round(Math.abs(v) / q)) * q * (v < 0 ? -1 : 1);
    if (t.type === 'cube') return { x: a.x + n(p.x - a.x), y: a.y + n(p.y - a.y) };
    const L = Math.hypot(p.x - a.x, p.y - a.y), Lc = n(L);
    return L ? { x: a.x + (p.x - a.x) * Lc / L, y: a.y + (p.y - a.y) * Lc / L } : { x: a.x + Lc, y: a.y };
  }
  const mesureDe = (t, b) => ({ type: t.type, x1: Math.round(t.depart.x), y1: Math.round(t.depart.y), x2: Math.round(b.x), y2: Math.round(b.y) });

  const saisir = ev => { try { zone.setPointerCapture(ev.pointerId); } catch { /* pointeur déjà relâché */ } };
  // Le bouton droit (ou Ctrl + bouton gauche) fait défiler la vue du MJ, quel que soit l'outil ; le bouton du milieu aussi
  // s'il glisse, sinon c'est un ping.
  let droitGlisse = false;   // le dernier bouton droit a glissé : pas un clic droit (qui retire un sommet du polygone)
  zone.addEventListener('mousedown', ev => { if (ev.button === 1) ev.preventDefault(); });   // pas de défilement automatique
  zone.addEventListener('pointerdown', ev => {
    if (!carte()) return;
    if (ev.button === 1 || ev.button === 2 || (ev.button === 0 && ev.ctrlKey)) {
      ev.preventDefault();
      trace = { outil: 'vue', p0: proj.versCarte(ev), x0: ev.clientX, y0: ev.clientY, bouge: false };
      saisir(ev);
      return;
    }
    if (ev.button !== 0) return;
    const p = proj.versCarte(ev);
    zone.focus({ preventScroll: true });
    if (outil === 'deplacer') {
      // Un jeton sous le pointeur se déplace ; près du bord du cadre des joueurs, on déplace le cadre ; ailleurs, on glisse
      // le fond sous le cadre, qui ne bouge pas à l'écran (le cadrage change, la vue suit), retour du MJ du 2026-11-03 :
      // la vue centrée sur la zone projetée s'ajuste ainsi. Le bouton droit, lui, fait défiler la vue.
      const a = annotationSous(p);
      if (a?.liste === 'jetons') trace = { outil: 'jeton', index: a.index };
      else if (presDuCadre(ev)) trace = { outil, depart: p, cadrage0: { ...(carte().cadrage) } };
      else trace = { outil: 'fond', p0: p };
      saisir(ev);
    }
    else if (outil === 'ping') { proj.ping(p.x, p.y); ping(p.x, p.y); }
    else if (outil === 'calibrer') calibrer(p);
    else if (outil === 'jeton') {
      const a = aimant(p, 'case'), e = carteEtat();
      (e.jetons ||= []).push({ type: jeton, ...(jeton === 'piege' ? { variante: piege } : {}), x: Math.round(a.x), y: Math.round(a.y) });
      changer();
    }
    else if (outil === 'distance' || outil === 'zone') {
      const type = outil === 'distance' ? 'distance' : zoneType;
      trace = { outil: 'mesure', type, depart: origineMesure(p, type) };
      proj.apercuMesure(mesureDe(trace, trace.depart)); saisir(ev);
    }
    else if (dessin() && forme === 'rect') { const a = aimant(p, 'coin'); trace = { outil: 'rect', depart: a, el: svgEl('rect', { class: classeTrace(), style: styleTrace(), x: a.x, y: a.y, width: 0, height: 0 }) }; proj.calque.append(trace.el); saisir(ev); }
    else if (dessin() && forme === 'rond') { const a = aimant(p, 'coin'); trace = { outil: 'rond', depart: a, el: svgEl('circle', { class: classeTrace(), style: styleTrace(), cx: a.x, cy: a.y, r: 0 }) }; proj.calque.append(trace.el); saisir(ev); }
    else if (dessin() && forme === 'trait') {
      // Le pinceau se voit en direct dans le brouillard (demande du MJ, 2026-11-03) ; les joueurs le reçoivent au relâchement.
      // Un terrain, lui, se trace en aperçu (polyline) jusqu'au relâchement.
      const largeur = (lire().pinceau_cases || 1) * pxCase();
      const a = aimant(p, 'case');
      trace = { outil: 'trait', points: [[a.x, a.y]], largeur, aimante: aimante() };
      if (opDe() === 'terrain') { trace.el = svgEl('polyline', { class: `${classeTrace()} cm-ecran__trace--trait`, style: styleTrace(), points: `${a.x},${a.y}`, 'stroke-width': largeur, 'stroke-linecap': lire().pinceau_forme === 'rond' ? 'round' : 'square' }); proj.calque.append(trace.el); }
      else proj.apercuForme(formeTrait(trace));
      saisir(ev);
    } else if (dessin() && forme === 'polygone') {
      if (!poly) { poly = { points: [], el: svgEl('polygon', { class: classeTrace(), style: styleTrace(), points: '' }) }; proj.calque.append(poly.el); }
      const a = aimant(p, 'coin');
      poly.points.push([a.x, a.y]);
      poly.el.setAttribute('points', pointsDe(poly));
    }
  });
  // Le pointeur est-il près du bord du cadre des joueurs (à 10 px de l'écran) ?
  function presDuCadre(ev) {
    const k = proj.cadreEcran();
    if (!k) return false;
    const r = zone.getBoundingClientRect();
    const dx = Math.abs(ev.clientX - r.left - k.cx), dy = Math.abs(ev.clientY - r.top - k.cy), tol = 10;
    return (Math.abs(dx - k.hw) <= tol && dy <= k.hh + tol) || (Math.abs(dy - k.hh) <= tol && dx <= k.hw + tol);
  }
  zone.addEventListener('pointermove', ev => {
    // Le curseur suit l'outil (app.css, data-outil) ; en ligne seulement près du bord du cadre, et l'aperçu du pinceau.
    if (outil === 'deplacer' && carte()) zone.style.cursor = trace ? 'grabbing' : presDuCadre(ev) ? 'move' : annotationSous(proj.versCarte(ev))?.liste === 'jetons' ? 'pointer' : '';
    if (dessin() && forme === 'trait' && carte()) montrerApercu(proj.versCarte(ev));
    if (!trace) return;
    if (trace.outil === 'vue') {
      if (!trace.bouge && Math.hypot(ev.clientX - trace.x0, ev.clientY - trace.y0) > 3) trace.bouge = true;
      proj.deplacerVue(trace.p0, ev);
      return;
    }
    if (trace.outil === 'fond') {
      const d = proj.glisserFond(trace.p0, ev);
      if (d) { const c0 = carte().cadrage; carteEtat().cadrage = { x: c0.x - d.x, y: c0.y - d.y }; sEtat.enregistrer(); redessiner(); envoyer(); }
      return;
    }
    const p = proj.versCarte(ev);
    if (trace.outil === 'deplacer') {
      carteEtat().cadrage = { x: trace.cadrage0.x + p.x - trace.depart.x, y: trace.cadrage0.y + p.y - trace.depart.y };
      sEtat.enregistrer(); redessiner(); envoyer();
    } else if (trace.outil === 'jeton') {
      const a = aimant(p, 'case'), j = carteEtat().jetons?.[trace.index];
      if (j) { j.x = Math.round(a.x); j.y = Math.round(a.y); redessiner(); }
    } else if (trace.outil === 'mesure') proj.apercuMesure(mesureDe(trace, finMesure(trace, p)));
    else if (trace.outil === 'rect') {
      const f = formeRect(trace, aimant(p, 'coin'));
      Object.entries({ x: f.x, y: f.y, width: f.w, height: f.h }).forEach(([k, val]) => trace.el.setAttribute(k, val));
      if (f.op !== 'terrain') proj.apercuForme(f);
    } else if (trace.outil === 'rond') {
      const f = formeRond(trace, p);
      trace.el.setAttribute('r', f.r);
      if (f.op !== 'terrain') proj.apercuForme(f);
    } else if (trace.outil === 'trait') {
      const a = aimant(p, 'case');
      const d = trace.points.at(-1);
      // Aimanté : une empreinte par case traversée ; sinon un point tous les 2 px d'écran.
      const neuf = trace.aimante ? (a.x !== d[0] || a.y !== d[1]) : Math.hypot(a.x - d[0], a.y - d[1]) * proj.echelle() >= 2;
      if (neuf) { trace.points.push([a.x, a.y]); if (trace.el) trace.el.setAttribute('points', pointsDe(trace)); else proj.apercuForme(formeTrait(trace)); }
    }
  });
  // La forme que fait le geste en cours (rectangle entre son départ et le point a ; trait du pinceau).
  const formeRect = (t, a) => ({ op: opDe(), type: 'rect', x: Math.round(Math.min(a.x, t.depart.x)), y: Math.round(Math.min(a.y, t.depart.y)), w: Math.round(Math.abs(a.x - t.depart.x)), h: Math.round(Math.abs(a.y - t.depart.y)) });
  // Le rond se trace depuis son centre (demande du MJ, 2026-11-03) ; aimanté, son rayon en cases entières.
  const formeRond = (t, p) => { const d = Math.hypot(p.x - t.depart.x, p.y - t.depart.y), q = pxCase(); return { op: opDe(), type: 'cercle', cx: Math.round(t.depart.x), cy: Math.round(t.depart.y), r: Math.round(aimante() ? Math.round(d / q) * q : d) }; };
  const formeTrait = t => ({ op: opDe(), type: 'trait', points: t.points.map(([x, y]) => [Math.round(x), Math.round(y)]), largeur: Math.round(t.largeur), forme: lire().pinceau_forme === 'rond' ? 'rond' : 'carre', ...(t.aimante ? { aimante: true } : {}) });
  zone.addEventListener('pointerup', ev => {
    if (!trace) return;
    const t = trace; trace = null;
    if (t.outil === 'vue') {
      droitGlisse = ev.button === 2 && t.bouge;
      // Un clic du bouton du milieu (la molette), sans glisser : un ping, quel que soit l'outil (demande du MJ, 2026-11-03).
      if (ev.button === 1 && !t.bouge) { proj.ping(t.p0.x, t.p0.y); ping(t.p0.x, t.p0.y); }
      return;
    }
    if (t.outil === 'deplacer' || t.outil === 'fond') { sEtat.enregistrer(0); zone.style.cursor = ''; return; }
    if (t.outil === 'jeton') { changer(); zone.style.cursor = ''; return; }
    if (t.outil === 'mesure') {
      proj.apercuMesure(null);
      const m = mesureDe(t, finMesure(t, proj.versCarte(ev)));
      if (Math.hypot(m.x2 - m.x1, m.y2 - m.y1) * proj.echelle() > 3) { const e = carteEtat(); (e.mesures ||= []).push(m); changer(); }
      return;
    }
    t.el?.remove();
    proj.apercuForme(null);
    if (t.outil === 'rect') {
      const f = formeRect(t, aimant(proj.versCarte(ev), 'coin'));
      if (f.w * proj.echelle() > 3 && f.h * proj.echelle() > 3) poserForme(f);
    } else if (t.outil === 'rond') {
      const f = formeRond(t, proj.versCarte(ev));
      if (f.r * proj.echelle() > 3) poserForme(f);
    } else if (t.outil === 'trait') poserForme(formeTrait(t));
  });
  zone.addEventListener('pointercancel', () => { trace?.el?.remove(); trace = null; proj.apercuForme(null); zone.style.cursor = ''; });
  zone.addEventListener('pointerleave', () => { if (!trace) cacherApercu(); });
  // Clic droit : retire le dernier sommet du polygone en cours (règle du MJ pour les tracés), sinon l'annotation sous le
  // pointeur (jeton, mesure, terrain), sinon la dernière mesure quand un outil de mesure est en cours ; double-clic :
  // ferme le polygone.
  zone.addEventListener('contextmenu', ev => {
    ev.preventDefault();
    if (droitGlisse) { droitGlisse = false; return; }   // un glisser du bouton droit a fait défiler la vue
    if (poly) {
      poly.points.pop();
      if (!poly.points.length) { poly.el.remove(); poly = null; } else poly.el.setAttribute('points', pointsDe(poly));
      return;
    }
    if (!carte()) return;
    const a = annotationSous(proj.versCarte(ev));
    if (a) retirerAnnotation(a);
    else if ((outil === 'distance' || outil === 'zone') && carteEtat().mesures?.length) { carteEtat().mesures.pop(); changer(); }
  });
  zone.addEventListener('dblclick', () => {
    if (!poly) return;
    const pts = poly.points.slice(0, -1);   // le double-clic a ajouté deux fois le dernier
    poly.el.remove(); poly = null;
    if (pts.length >= 3) poserPolygone(pts);
  });
  zone.addEventListener('keydown', ev => {
    if (ev.key === 'Escape') { annulerTrace(); ev.preventDefault(); }
    else if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'z') { annulerForme(); ev.preventDefault(); }
    else if (ev.key === 'Enter' && poly && poly.points.length >= 3) { const pts = poly.points; poly.el.remove(); poly = null; poserPolygone(pts); }
  });
  // Molette : la vue du MJ zoome autour du pointeur (retour du MJ, 2026-11-03) ; l'échelle des joueurs se règle dans le menu Échelle.
  zone.addEventListener('wheel', ev => { if (!carte()) return; ev.preventDefault(); proj.zoomerVue(ev.deltaY < 0 ? 1.25 : 1 / 1.25, ev); }, { passive: false });

  // Calibrage : deux clics sur deux coins de cases de la même ligne (ou colonne), à N cases l'un de l'autre.
  function calibrer(p) {
    if (!calibrageA) {
      calibrageA = p;
      const rep = svgEl('circle', { class: 'cm-ecran__repere', cx: p.x, cy: p.y, r: 6 / proj.echelle() });
      proj.calque.append(rep);
      return;
    }
    const a = calibrageA;
    const dx = Math.abs(p.x - a.x), dy = Math.abs(p.y - a.y), d = Math.hypot(dx, dy);
    annulerTrace();
    if (d < 4) return;
    // Deux coins sur une même ligne (ou colonne) : la distance ; deux coins opposés en diagonale (dx et dy du même ordre) :
    // la moyenne des deux côtés, ce qui vaut aussi pour N cases en diagonale.
    const diagonale = Math.min(dx, dy) > 0.4 * Math.max(dx, dy);
    const e = carteEtat();
    e.echelle = { px_case: (diagonale ? (dx + dy) / 2 : d) / casesCalibrage, origine_x: Math.round(a.x), origine_y: Math.round(a.y) };
    e.grille = true;
    e.zoom = 'pouce';
    outil = 'deplacer';
    changer();
  }

  const scene = h('div', { class: 'cm-ecran__scene' }, barreLaterale, zone);
  corps.replaceChildren(bandeau, atelier, barreOutils, scene, vide, logeGrande, infos);
  rendre();
  surSceneFns.add(rendre);
  surStatutFns.add(rendre);
  const offIci = sIci?.abonner(rendre);
  const off = () => { surSceneFns.delete(rendre); surStatutFns.delete(rendre); offIci?.(); };
  return { rendre, off };
}

const widget = {
  type: 'ecran-joueurs',
  titre: 'Écran des joueurs',
  icone: 'lu-monitor',
  plugin: ID,
  description: 'Ce que voient les joueurs (le bandeau « À l\'écran » : tableau des joueurs, carte diffusée, image) et l\'atelier où préparer une carte à 1 pouce par case (calibrage, cadrage, grille, brouillard de combat, jetons, mesures, ping) avant de la diffuser. Plugin Écran des joueurs (fenêtre Campagne, onglet Plugins).',
  taille: { w: 6, h: 14 },
  min: { w: 4, h: 8 },
  unique: true,
  async monter({ corps, actions, resume, ajusterHauteur }) {
    const { pluginActif, surChangementPlugins } = await import('../plugins.js');
    let vue = null;
    const rendre = () => {
      vue?.off();
      vue = null;
      if (!pluginActif(ID)) { corps.replaceChildren(alerte('cierge', 'lu-plug', 'Plugin désactivé', 'Activez le plugin Écran des joueurs dans la fenêtre Campagne, onglet Plugins.')); resume.replaceChildren(); return; }
      vue = vueWidget({ corps, resume, ajusterHauteur });
    };
    rendre();
    const off = surChangementPlugins(() => { if (corps.isConnected) rendre(); else off(); });
    actions.append(pointStatut(), bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', titre: 'Réglages du plugin : fenêtre Campagne, onglet Plugins',
      onclick: () => document.querySelector('.cm-entete__outils .bn-btn[title="Réglages de la campagne"]')?.click() }));
    return {};
  },
};

// Le point d'état (en-tête du widget) : un clic ouvre ou ramène la fenêtre des joueurs ; clic droit : la fermer.
function pointStatut() {
  const el = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome bn-btn--icone cm-plugin-statut cm-ecran-statut', onclick: () => ouvrirFenetre(),
    oncontextmenu: ev => { ev.preventDefault(); if (fenetreVivante()) fermerFenetre(); } },
    icone('lu-monitor'), h('span', { class: 'cm-plugin-statut__point', 'aria-hidden': 'true' }));
  infobulle(el, '', { titre: 'Écran des joueurs' });
  const peindre = () => {
    const code = codeStatut();
    el.dataset.statut = code;
    const texte = STATUTS[code].libelle + (code === 'fermee' ? ' · un clic l\'ouvre sur l\'écran choisi' : ' · clic droit : la fermer');
    el.setAttribute('aria-label', texte);
    el.dataset.bulle = texte;
  };
  peindre();
  const fn = () => { if (el.isConnected) peindre(); else surStatutFns.delete(fn); };
  surStatutFns.add(fn);
  return el;
}

// ───── Réglages : onglet Plugins (campagne) et onglet « Ce poste » (l'écran de ce PC) ─────

function vueReglages(c) {
  lire = c.reglages.lire;
  const ecrire = patch => { c.reglages.ecrire(patch); redessiner(); envoyer(); };
  const r = lire();
  const caseDe = (cle, titre, texte, defaut = true) => h('label', { class: 'cm-case' },
    h('input', { type: 'checkbox', class: 'bn-case', checked: r[cle] ?? defaut, onchange: e => ecrire({ [cle]: e.target.checked }) }),
    h('span', {}, h('b', {}, titre), h('br'), h('span', { class: 'ui-s cm-sourdine' }, texte)));
  const seuil = (cle, libelle) => h('label', { class: 'cm-plugin__champ' }, libelle,
    h('input', { class: 'bn-input', type: 'number', min: 1, max: 99, value: r.seuils?.[cle] ?? SEUILS_DEFAUT[cle], onchange: e => ecrire({ seuils: { ...SEUILS_DEFAUT, ...(r.seuils || {}), [cle]: Math.max(1, Math.min(99, Number(e.target.value) || SEUILS_DEFAUT[cle])) } }) }));
  const fondDefaut = sEtat ? versionJoueurs(imageDe(v().tableau?.fond_defaut)) : null;
  return h('div', { class: 'cm-pile' },
    h('p', { class: 'ui-s cm-sourdine' }, 'La taille de l\'écran des joueurs (la dalle, en pouces) se règle dans l\'onglet « Ce poste » : elle est propre à ce PC.'),
    h('div', { class: 'cm-plugin__champs' },
      h('label', { class: 'cm-plugin__champ' }, 'Rotation par défaut (une nouvelle carte, le tableau)',
        h('select', { class: 'bn-select', onchange: e => ecrire({ rotation_defaut: Number(e.target.value) }) }, ROTATIONS.map(d => h('option', { value: d, selected: d === (r.rotation_defaut || 0) }, `${d}°`))))),
    caseDe('grille_defaut', 'Grille dessinée d\'office', 'Sur une carte calibrée, la grille des cases est dessinée par-dessus (utile pour une carte sans grille). Se change carte par carte dans le widget.', false),
    caseDe('tableau', 'Tableau des joueurs', 'Sans carte, l\'écran montre le fond du lieu et les héros tels que les joueurs les voient : santé en mots, états, équipement porté, inspiration, inventaire commun. Décoché : le titre de la campagne seul.'),
    h('div', { class: 'cm-plugin__champs' }, seuil('ensanglante', '« Ensanglanté » à partir de (% des PV)'), seuil('critique', '« Critique » à partir de (% des PV)')),
    h('div', { class: 'cm-plugin__champs' },
      h('label', { class: 'cm-plugin__champ' }, 'Bord flouté du brouillard (fraction de case, 0 : net ; un quinzième d\'office)',
        h('input', { class: 'bn-input', type: 'number', min: 0, max: 1, step: 0.01, value: Math.round((r.adouci ?? ADOUCI_DEFAUT) * 100) / 100, onchange: e => ecrire({ adouci: Math.max(0, Math.min(1, Number(e.target.value) || 0)) }) }))),
    section('Fond du tableau des joueurs', 'lu-image',
      h('p', { class: 'ui-s cm-sourdine' }, fondDefaut ? ['Image de la campagne : ', h('b', {}, biblio?.titre(fondDefaut) || fondDefaut.titre), ' ', bouton('Retirer', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', onclick: ev => { choisirFond(null, null); ev.currentTarget.closest('p').textContent = 'Image de la campagne retirée : le titre seul.'; } })]
        : 'Aucune image de campagne : le titre seul. Pour en choisir une, ouvrez une image (widget Images), bouton « Écran des joueurs », « Fond par défaut ». De même, « Fond pour <lieu> » donne son fond à un lieu : l\'écran le prend quand les héros y sont.')));
}

// L'onglet « Ce poste » : l'écran à utiliser et la largeur de sa dalle ; la mire pour vérifier à la règle.
export function vueReglagesPoste() {
  const p = poste();
  const selEcran = h('select', { class: 'bn-select', 'aria-label': 'Écran des joueurs', onchange: e => ecrirePoste({ ecran: e.target.value || null }) },
    h('option', { value: '' }, p.ecran ? `${p.ecran} (réglé)` : 'Un autre écran que celui-ci (d\'office)'));
  const lister = async () => {
    try {
      const d = await window.getScreenDetails();
      selEcran.replaceChildren(h('option', { value: '' }, 'Un autre écran que celui-ci (d\'office)'),
        ...d.screens.map(s => h('option', { value: s.label, selected: s.label === p.ecran }, `${s.label || 'Écran'} · ${s.width} × ${s.height}${s === d.currentScreen ? ' (celui-ci)' : ''}${s.isPrimary ? ' (principal)' : ''}`)));
    } catch (e) { selEcran.replaceChildren(h('option', { value: '' }, `Écrans inconnus : ${e.message}`)); }
  };
  const largeur = h('input', { class: 'bn-input cm-ecran__mesure', type: 'number', min: 5, max: 200, step: 0.1, value: p.largeur_pouces || '', placeholder: '37,5', 'aria-label': 'Largeur de la dalle en pouces' });
  const diagonale = h('input', { class: 'bn-input cm-ecran__mesure', type: 'number', min: 5, max: 250, step: 0.1, value: p.largeur_pouces ? (p.largeur_pouces / (16 / Math.hypot(16, 9))).toFixed(1) : '', placeholder: '43', 'aria-label': 'Diagonale en pouces, écran 16/9' });
  const cm = h('input', { class: 'bn-input cm-ecran__mesure', type: 'number', min: 10, max: 500, step: 0.1, value: p.largeur_pouces ? (p.largeur_pouces * 2.54).toFixed(1) : '', placeholder: '95,2', 'aria-label': 'Largeur de la dalle en centimètres' });
  const poser = pouces => {
    const val = pouces > 0 ? Math.round(pouces * 100) / 100 : null;
    ecrirePoste({ largeur_pouces: val });
    largeur.value = val || ''; diagonale.value = val ? (val / (16 / Math.hypot(16, 9))).toFixed(1) : ''; cm.value = val ? (val * 2.54).toFixed(1) : '';
    resume.textContent = val ? `${Math.floor(val)} cases de 1 pouce en largeur.` : '';
  };
  largeur.addEventListener('change', () => poser(Number(largeur.value)));
  diagonale.addEventListener('change', () => poser(Number(diagonale.value) * 16 / Math.hypot(16, 9)));
  cm.addEventListener('change', () => poser(Number(cm.value) / 2.54));
  const resume = h('span', { class: 'ui-s cm-sourdine' }, p.largeur_pouces ? `${Math.floor(p.largeur_pouces)} cases de 1 pouce en largeur.` : '');
  const btnMire = bouton('Mire', { classe: 'bn-btn--s', icone: 'lu-ruler', 'aria-pressed': String(mireActive), titre: 'Afficher la mire de calibrage sur l\'écran des joueurs (un carré de 1 pouce, 10 cm, la grille)', onclick: () => {
    if (!sEtat) { annoncer({ cle: ID, titre: 'Plugin désactivé', icone: 'lu-monitor', couleur: 'cierge', texte: 'Activez le plugin Écran des joueurs (onglet Plugins) pour afficher la mire.' }); return; }
    mireActive = !mireActive;
    btnMire.setAttribute('aria-pressed', String(mireActive));
    redessiner(); envoyer();
    if (mireActive && !fenetreVivante()) ouvrirFenetre();
  } });
  return h('div', { class: 'cm-reglage' },
    h('p', { class: 'ui' }, h('b', {}, 'Écran des joueurs')),
    h('p', { class: 'ui-s cm-sourdine' }, 'L\'écran où s\'ouvre la fenêtre des joueurs (plugin Écran des joueurs), et la largeur de sa dalle, pour que les cases fassent 1 pouce sous les figurines. Propre à ce PC.'),
    h('div', { class: 'bn-groupe' }, selEcran, bouton('Lister les écrans', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-monitor', titre: 'Demander au navigateur les écrans branchés (une autorisation, une fois)', onclick: lister })),
    h('div', { class: 'cm-plugin__champs' },
      h('label', { class: 'cm-plugin__champ' }, 'Largeur de la dalle (pouces)', largeur),
      h('label', { class: 'cm-plugin__champ' }, 'ou sa diagonale, écran 16/9 (pouces)', diagonale),
      h('label', { class: 'cm-plugin__champ' }, 'ou sa largeur (cm)', cm)),
    h('div', { class: 'bn-groupe' }, btnMire, resume),
    h('p', { class: 'ui-s cm-sourdine' }, 'La mire : posez une règle sur l\'écran ; le carré doit faire 1 pouce (2,54 cm) et la grille aller jusqu\'aux bords (sinon la TV coupe l\'image : « Scan uniquement » dans ses réglages).'));
}

// ───── Emplacement imageActions : dans la fenêtre d'une image (app/bibliotheque.js) ─────

function actionsImage(i, infos) {
  if (!sEtat) return null;
  const btn = bouton('Écran des joueurs', { icone: 'lu-monitor', classe: 'bn-btn--s bn-btn--fantome', titre: 'Montrer cette image aux joueurs, ou en faire le fond de leur tableau', onclick: ev => {
    const pj = versionJoueurs(i);
    const choix = [
      ['Montrer maintenant' + (pj !== i ? ' (version joueurs)' : ''), '', () => montrerImage(cheminDe(pj), infos.titre)],
      ...infos.lieux.map(id => [`Fond pour ${infos.nomLieu(id)}`, '', () => choisirFond(id, versionMjDe(i).id), () => v().tableau?.fonds?.[id] === versionMjDe(i).id]),
      ['Fond par défaut (la campagne)', '', () => choisirFond(null, versionMjDe(i).id), () => v().tableau?.fond_defaut === versionMjDe(i).id],
    ];
    // Une carte s'ouvre dans l'atelier du widget (calibrage, brouillard) ; elle n'ira à l'écran qu'au clic sur « Diffuser ».
    if (i.categorie === 'carte') choix.splice(1, 0, ['Préparer comme carte (1 pouce par case)', '', () => afficherCarte(i.id), () => v().carte === versionMjDe(i).id]);
    ouvrirMenu(ev.currentTarget, choix, 'Écran des joueurs');
  } });
  return btn;
}

// ───── Le plugin ─────

export default {
  id: ID,
  titre: 'Écran des joueurs',
  icone: 'lu-monitor',
  description: 'Une seconde fenêtre pour les joueurs, en plein écran sur un autre écran (une TV à plat sous les figurines) : la carte du lieu à 1 pouce par case, tournée, cadrée, avec le brouillard de combat et un ping ; sans carte, le tableau des joueurs (le fond du lieu, l\'état des héros en mots, l\'inventaire commun). Le widget Écran des joueurs montre ce qu\'ils voient.',
  defauts: DEFAUTS,
  widgets: [widget],
  emplacements: {
    imageActions: actionsImage,
  },
  reglages: vueReglages,

  async demarrer(c) {
    ctx = c;
    lire = c.reglages.lire;
    sEtat = await c.etat('ecran-joueurs', ETAT_DEFAUT);
    sEtat.valeur.cartes ||= {};
    sEtat.valeur.tableau ||= { fond_defaut: null, fonds: {} };
    if (migrer(sEtat.valeur)) sEtat.enregistrer(0);   // l'état d'avant la refonte : l'écran garde ce que voyaient les joueurs
    ouvrirCanal();
    try { canal.postMessage({ type: 'qui' }); } catch { /* canal fermé */ }   // une page joueurs déjà ouverte dit sa taille
    c.reglages.surChangement(() => { redessiner(); envoyer(); });
    c.ecouter('lieu:arrivee', () => { calculerTableau().then(() => { redessiner(); envoyer(); }); });
    brancherEcranJoueurs((src, legende) => montrerImage(src, legende));
    minuterieReleve = setInterval(() => suivreTableau().catch(() => {}), RELEVE_MS);
    majStatut();
    // Les données (bibliothèque, lieux, Ici) après le démarrage de la page : les plugins démarrent avant l'en-tête et les
    // widgets, et lire data/ avant l'en-tête casserait son badge Données. Une page joueurs déjà ouverte (page du MJ rechargée)
    // reprend alors la scène.
    setTimeout(async () => {
      try {
        if (!ctx) return;
        [biblio, lieux, sIci] = await Promise.all([chargerBibliotheque(c.donnees, c.etat), chargerLieux(c.donnees), etatIci(c.etat, c.donnees)]);
        if (biblio) biblio.parId ||= new Map(biblio.index.images.map(i => [i.id, i]));
        sIci.abonner(() => { redessiner(); envoyer(); });
        await calculerTableau();
        // L'horloge change (le temps passe, la météo tourne) : le tableau suit, fenêtre ouverte ou non (le widget le montre).
        sHorloge?.abonner(() => { calculerTableau().then(ch => { if (ch) { redessiner(); envoyer(); } }).catch(() => {}); });
        redessiner();
        envoyer(true);
      } catch (e) { console.error('Écran des joueurs : chargement', e); }
    }, 0);
  },
  arreter() {
    clearInterval(minuterieReleve); clearInterval(minuterieFenetre); clearTimeout(minuterieEnvoi);
    brancherEcranJoueurs(null);
    try { canal?.close(); } catch { /* déjà fermé */ }
    canal = null; sEtat = null; ctx = null; ecranJ = null; mireActive = false; tableauCache = tableauJson = null;
    flottantOuvert('plugin:ecran-joueurs')?.fermer();
    majStatut();
  },
};
