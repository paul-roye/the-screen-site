// Agenda de la campagne (demande du MJ, 2026-10-25) : des entrées datées au calendrier de la campagne, un nom et des détails
// (une fête de village, un délai, un rendez-vous). Données : data/agenda.json (formats/agenda.md, facultatif,
// écrit par l'agent IA de campagne). Le MJ ajoute, modifie ou retire des entrées dans le gestionnaire (calendrier de l'année,
// bouton de l'Horloge) : une surcouche gardée dans etat/agenda.json (formats/etat.md). Une entrée du fichier retouchée garde
// son id ; une entrée créée par le MJ a un id `mj-…` ; une entrée du fichier retirée va dans `retirees`. Le prompt de fin de
// session donne la surcouche à l'agent, pour qu'il la reprenne dans le fichier.

import { identifiant } from './ui.js';
import { rangDate } from './calendrier.js';

// Les entrées en vigueur : celles du fichier (moins les retirées, avec les retouches du MJ par-dessus), puis celles du MJ.
// origine : « donnees » ou « mj » ; retouchee : une entrée du fichier que le MJ a modifiée. surcouche : etat/agenda.json.
export function fusionnerAgenda(fichier = [], surcouche = {}) {
  const ret = surcouche.retirees || [], sur = surcouche.entrees || {};
  const l = fichier.filter(e => !ret.includes(e.id)).map(e => (sur[e.id]
    ? { ...e, ...sur[e.id], id: e.id, origine: 'donnees', retouchee: true } : { ...e, origine: 'donnees' }));
  for (const [id, x] of Object.entries(sur)) if (!fichier.some(e => e.id === id)) l.push({ ...x, id, origine: 'mj' });
  return l;
}

// Rang d'une entrée dans le compte des jours du calendrier (rangDate) : par sa date, ou par son jour de campagne.
export function rangAgenda(cal, e) {
  if (e.date) return rangDate(cal, e.date);
  if (Number.isInteger(e.jour_campagne)) return rangDate(cal, cal.debut_campagne) + e.jour_campagne - cal.debut_campagne.jour_campagne;
  return null;
}

// Les alertes d'une entrée (demande du MJ, 2026-10-25) : une fenêtre prévient le MJ quand l'Horloge arrive sur le jour même
// (coché d'office) et/ou N jours avant (plusieurs). Absentes : le jour même seulement.
export const alertesDe = e => ({ jour_meme: e?.alertes?.jour_meme ?? true, avant: [...new Set((e?.alertes?.avant || []).filter(n => Number.isInteger(n) && n > 0))].sort((a, b) => b - a) });

export async function chargerAgenda(donnees, etat) {
  const lect = await donnees('agenda');
  const fichier = lect.statut === 'ok' ? lect.donnees.entrees || [] : [];
  const s = await etat('agenda', { schema: 1, entrees: {}, retirees: [] });
  const v = () => s.valeur;
  v().entrees ||= {};
  v().retirees ||= [];
  const duFichier = id => fichier.find(e => e.id === id) || null;
  const entrees = () => fusionnerAgenda(fichier, v());

  const enregistrer = () => { s.enregistrer(0); s.signaler(); };
  // Ajouter (sans id) ou modifier une entrée ; date : { annee, mois, jour } au calendrier de la campagne ; alertes : alertesDe().
  function ecrire(id, { date, nom, details, alertes }) {
    const cle = id || 'mj-' + identifiant();
    v().entrees[cle] = { date, nom: nom.trim(), details: details?.trim() || null, alertes: alertesDe({ alertes }), quand: new Date().toISOString() };
    enregistrer();
    return cle;
  }
  // Retirer : une entrée du MJ disparaît ; une entrée du fichier est écartée (le fichier ne change pas).
  function retirer(id) {
    if (duFichier(id) && !v().retirees.includes(id)) v().retirees.push(id);
    delete v().entrees[id];
    enregistrer();
  }
  // Revenir au texte du fichier (retouche abandonnée), ou remettre une entrée du fichier écartée.
  function revenir(id) {
    delete v().entrees[id];
    v().retirees = v().retirees.filter(x => x !== id);
    enregistrer();
  }

  const duRang = (cal, rang) => entrees().filter(e => rangAgenda(cal, e) === rang);
  const retirees = () => fichier.filter(e => v().retirees.includes(e.id));

  return { s, entrees, ecrire, retirer, revenir, rangDe: rangAgenda, duRang, retirees, duFichier, fichierPresent: lect.statut === 'ok' };
}
