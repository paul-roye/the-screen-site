// Lore des personnages : ce que l'IA de la campagne a mis dans data/personnages.json (accroche, apparence, personnalité,
// origine, motivations, allégeances, objets notables ; secrets), et les retouches du MJ, gardées dans etat/lore.json
// (formats/etat.md) par-dessus, jusqu'à ce que l'IA les reprenne : le prompt de fin de session les lui donne, et une
// retouche que le fichier dit de nouveau à l'identique disparaît. Un MJ sans IA écrit ainsi tout le lore lui-même.
// Le gestionnaire ne lit pas le wiki pour cela : l'import du wiki est une source pour l'IA, pas pour lui.
// Lu par le widget Personnages (onglets Lore et Secret de la fiche) et la fin de session (app/session.js).

import { h, bouton, alerte } from './ui.js';

// [champ de personnages.json, libellé, genre (ligne, texte, liste, objets), icône]
export const CHAMPS_LORE = [
  ['accroche', 'Accroche', 'ligne', null],
  ['apparence', 'Apparence', 'texte', 'oeil'],
  ['personnalite', 'Personnalité', 'texte', 'coeur'],
  ['origine', 'Origine', 'texte', 'livre'],
  ['motivations', 'Motivations', 'liste', 'etoile'],
  ['allegeances', 'Allégeances', 'liste', 'bouclier'],
  ['objets_notables', 'Objets notables', 'objets', 'cle'],
];

export async function etatLore(etat) {
  const s = await etat('lore', { schema: 1, personnages: {} });
  s.valeur.personnages ||= {};
  return s;
}

// Valeur comparable d'un champ (espaces et listes vides ignorés).
const norme = v => JSON.stringify(Array.isArray(v) ? v.map(x => (typeof x === 'string' ? x.trim() : { nom: x.nom?.trim(), texte: x.texte?.trim() })).filter(x => (typeof x === 'string' ? x : x.nom || x.texte))
  : typeof v === 'string' ? v.trim() : v ?? '');
const vide = v => norme(v) === '""' || norme(v) === '[]';
const secretsSimples = p => (p.secrets || []).filter(x => !Array.isArray(x.etapes) || !x.etapes.length);

// Le lore d'un personnage tel qu'il s'affiche : { champs: { <champ>: valeur }, retouches: Set, secrets: [{ sujet, texte }],
// secretsRetouches } (les secrets en étapes, quêtes personnelles, restent ceux du fichier).
export function loreDe(p, s) {
  const r = s?.valeur.personnages?.[p.id] || {};
  const champs = {}, retouches = new Set();
  for (const [cle] of CHAMPS_LORE) {
    if (r[cle] && 'valeur' in r[cle]) { champs[cle] = r[cle].valeur; retouches.add(cle); } else champs[cle] = p[cle];
  }
  return { champs, retouches, secrets: r.secrets ? r.secrets.liste : secretsSimples(p), secretsRetouches: !!r.secrets };
}

// Retouches devenues inutiles (le fichier dit désormais la même chose) : retirées. Vrai si l'état a changé.
export function nettoyerLore(s, personnages) {
  let change = false;
  for (const p of personnages || []) {
    const r = s.valeur.personnages[p.id];
    if (!r) continue;
    for (const [cle] of CHAMPS_LORE) if (r[cle] && norme(r[cle].valeur) === norme(p[cle])) { delete r[cle]; change = true; }
    if (r.secrets && norme(r.secrets.liste.map(x => `${x.sujet} : ${x.texte}`)) === norme(secretsSimples(p).map(x => `${x.sujet} : ${x.texte}`))) { delete r.secrets; change = true; }
    if (!Object.keys(r).length) { delete s.valeur.personnages[p.id]; change = true; }
  }
  return change;
}

// Champ <-> texte du formulaire : une ligne par élément pour une liste, « Nom : texte » pour un objet.
const versTexte = (genre, v) => (genre === 'liste' ? (v || []).join('\n') : genre === 'objets' ? (v || []).map(o => `${o.nom}${o.texte ? ` : ${o.texte}` : ''}`).join('\n') : v || '');
const depuisTexte = (genre, t) => {
  const lignes = t.split('\n').map(x => x.trim()).filter(Boolean);
  if (genre === 'liste') return lignes;
  if (genre === 'objets') return lignes.map(l => { const i = l.indexOf(' : '); return i < 0 ? { nom: l, texte: '' } : { nom: l.slice(0, i).trim(), texte: l.slice(i + 3).trim() }; });
  return genre === 'ligne' ? t.replace(/\s+/g, ' ').trim() : t.trim();
};

// Fenêtre « Modifier le lore » : un champ par section, prérempli du lore affiché. Enregistrer : une retouche pour chaque
// champ qui diffère du fichier ; « Revenir au texte de l'IA » : les retire toutes.
export function ouvrirEditionLore(p, s, dialogue, surFin) {
  const l = loreDe(p, s);
  const champs = CHAMPS_LORE.map(([cle, libelle, genre]) => {
    const attrs = { class: genre === 'ligne' ? 'bn-input' : 'bn-textarea', 'aria-label': libelle };
    const el = genre === 'ligne' ? h('input', { ...attrs, type: 'text', value: versTexte(genre, l.champs[cle]) })
      : h('textarea', { ...attrs, rows: genre === 'texte' ? 4 : 3 }, versTexte(genre, l.champs[cle]));
    return { cle, genre, el, bloc: h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, libelle,
      l.retouches.has(cle) ? ' (retouché)' : ''), el,
      genre === 'liste' ? h('span', { class: 'ui-s cm-sourdine' }, 'Une par ligne.') : genre === 'objets' ? h('span', { class: 'ui-s cm-sourdine' }, 'Un par ligne : « Nom : ce qu\'il a de notable ».') : null) };
  });
  let dlg;
  const enregistrer = () => {
    const r = { ...(s.valeur.personnages[p.id] || {}) };
    const quand = new Date().toISOString();
    for (const c of champs) {
      const v = depuisTexte(c.genre, c.el.value);
      if (norme(v) === norme(p[c.cle]) || (vide(v) && vide(p[c.cle]))) delete r[c.cle];
      else r[c.cle] = { valeur: v, quand };
    }
    if (Object.keys(r).length) s.valeur.personnages[p.id] = r; else delete s.valeur.personnages[p.id];
    s.enregistrer(0); s.signaler(); dlg.close(); surFin?.();
  };
  const revenir = () => {
    const r = { ...(s.valeur.personnages[p.id] || {}) };
    for (const [cle] of CHAMPS_LORE) delete r[cle];
    if (Object.keys(r).length) s.valeur.personnages[p.id] = r; else delete s.valeur.personnages[p.id];
    s.enregistrer(0); s.signaler(); dlg.close(); surFin?.();
  };
  dlg = dialogue(p.nom, 'Modifier le lore', h('div', { class: 'cm-pile' },
    h('p', { class: 'ui-s cm-sourdine' }, 'Ce que les joueurs peuvent savoir du personnage. Vos retouches s\'affichent par-dessus le texte de data/personnages.json ; la fin de session les donne à votre agent IA de campagne, si vous en avez un, pour qu\'il les reprenne.'),
    champs.map(c => c.bloc)),
    h('div', { class: 'bn-groupe' },
      bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: enregistrer }),
      l.retouches.size ? bouton('Revenir au texte du fichier', { classe: 'bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: revenir }) : null), { large: true });
}

// Fenêtre « Modifier les secrets » : une ligne par secret (sujet, texte), ajout et retrait. Les secrets en étapes (quêtes
// personnelles) ne s'y changent pas.
export function ouvrirEditionSecrets(p, s, dialogue, surFin) {
  const l = loreDe(p, s);
  const liste = h('div', { class: 'cm-pile' });
  const ligne = (x = { sujet: '', texte: '' }) => {
    const sujet = h('input', { class: 'bn-input', type: 'text', value: x.sujet, placeholder: 'Sujet', 'aria-label': 'Sujet' });
    const texte = h('textarea', { class: 'bn-textarea', rows: 2, placeholder: 'Ce que le MJ sait et que les joueurs ignorent', 'aria-label': 'Secret' }, x.texte);
    const el = h('div', { class: 'cm-secret-edition' }, sujet, texte,
      bouton('', { icone: 'lu-x', titre: 'Retirer ce secret', classe: 'bn-btn--s bn-btn--fantome', onclick: () => el.remove() }));
    el.lire = () => ({ sujet: sujet.value.trim(), texte: texte.value.trim() });
    return el;
  };
  liste.append(...l.secrets.map(ligne));
  let dlg;
  const ecrire = secrets => {
    const r = { ...(s.valeur.personnages[p.id] || {}) };
    if (secrets === null) delete r.secrets; else r.secrets = { liste: secrets, quand: new Date().toISOString() };
    if (Object.keys(r).length) s.valeur.personnages[p.id] = r; else delete s.valeur.personnages[p.id];
    s.enregistrer(0); s.signaler(); dlg.close(); surFin?.();
  };
  const enregistrer = () => {
    const secrets = [...liste.children].map(el => el.lire()).filter(x => x.sujet || x.texte).map(x => ({ sujet: x.sujet || 'Secret', texte: x.texte }));
    ecrire(norme(secrets.map(x => `${x.sujet} : ${x.texte}`)) === norme(secretsSimples(p).map(x => `${x.sujet} : ${x.texte}`)) ? null : secrets);
  };
  dlg = dialogue(p.nom, 'Modifier les secrets', h('div', { class: 'cm-pile' },
    alerte('ultra', 'lu-eye-off', 'Pour le MJ seul', 'Ce que le MJ sait du personnage et que les autres joueurs ignorent. Les secrets en étapes (quête personnelle) viennent du fichier et ne se changent pas ici.'),
    liste, bouton('Ajouter un secret', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-plus', onclick: () => liste.append(ligne()) })),
    h('div', { class: 'bn-groupe' },
      bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: enregistrer }),
      l.secretsRetouches ? bouton('Revenir aux secrets du fichier', { classe: 'bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: () => ecrire(null) }) : null), { large: true });
}

// Pour le prompt de fin de session : les retouches du MJ, à reprendre dans personnages.json. [] s'il n'y en a pas.
export function retouchesEnMarkdown(personnages, s) {
  const l = [];
  for (const p of personnages || []) {
    const r = s?.valeur.personnages?.[p.id];
    if (!r) continue;
    l.push(`- **${p.nom}** (\`${p.id}\`) :`);
    for (const [cle, libelle, genre] of CHAMPS_LORE) {
      if (!r[cle]) continue;
      const v = r[cle].valeur;
      l.push(`  - \`${cle}\` (${libelle}) : ${genre === 'liste' ? v.map(x => `« ${x} »`).join(', ') || '(vide)' : genre === 'objets' ? v.map(o => `${o.nom}${o.texte ? ` : ${o.texte}` : ''}`).join(' ; ') || '(vide)' : v.replace(/\n+/g, ' ') || '(vide)'}`);
    }
    if (r.secrets) l.push(`  - \`secrets\` (sans les quêtes en étapes) : ${r.secrets.liste.map(x => `**${x.sujet}** : ${x.texte.replace(/\n+/g, ' ')}`).join(' ; ') || '(aucun)'}`);
  }
  return l;
}
