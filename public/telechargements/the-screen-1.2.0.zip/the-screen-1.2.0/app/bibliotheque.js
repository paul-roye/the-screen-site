// Bibliothèque d'images : index (images-library/index.json, formats/images.md), source, catégorie et lieux déduits du chemin
// des images (règles de la campagne, bibliotheque.json de son dossier, puis noms des lieux), PNJ rapprochés d'après le nom
// des fichiers, étiquettes du MJ (etat/images.json), fenêtre flottante d'une image et vignettes. Partagée par les widgets
// Images et Ici et par la fiche d'un PNJ. Une étiquette changée prévient les widgets abonnés à l'état « images » (s.abonner).

import { h, icone, bouton, flottant, normaliser, infobulle, afficherEnGrand, avecEcranJoueurs } from './ui.js';
import { chargerLieux, nomLieu } from './lieux.js';
import { contributions } from './modules.js';

// Catégories des images (formats/images.md) et leur icône ; les règles de la campagne (bibliotheque.json, `categories`)
// et les modules de campagne (emplacement imagesCategories, app/modules.js) peuvent en ajouter, lues au chargement.
export const CATEGORIES = {
  carte: 'Cartes', illustration: 'Illustrations', creature: 'Créatures et PNJ', tresor: 'Trésors',
  document: 'Documents', encart: 'Encarts',
};
const ICONES = { carte: 'carte', illustration: 'lu-image', creature: 'crocs', tresor: 'piece', document: 'lettre', encart: 'livre' };
export const iconeCategorie = k => ICONES[k] || 'lu-image';
const ajouterCategorie = (k, v) => {
  CATEGORIES[k] = typeof v === 'string' ? v : v?.nom || k;
  if (v?.icone) ICONES[k] = v.icone;
};
// Une image rangée dans un de ces dossiers est une carte, quelle que soit la campagne.
const DOSSIERS_CARTES = new Set(['cartes', 'carte', 'maps', 'map', 'plans', 'plan']);
// Mots trop courants pour rapprocher un fichier d'un PNJ ou d'un lieu.
const MOTS_VIDES = new Set(['dame', 'baron', 'baronne', 'pere', 'sire', 'sir', 'madame', 'les', 'le', 'la', 'et', 'de', 'des', 'du', 'van', 'der', 'von', 'ses', 'fils', 'cuistot', 'esprits', 'perdus']);
const MOTS_VIDES_LIEUX = new Set(['les', 'des', 'aux', 'the', 'and', 'une']);
const motsLieu = t => normaliser(t).split(/[^a-z0-9]+/).filter(m => m.length >= 3 && !MOTS_VIDES_LIEUX.has(m));

let promesse = null;

// null si la bibliothèque n'est pas (encore) indexée.
export function chargerBibliotheque(donnees, etat) {
  promesse ||= (async () => {
    const index = await fetch('images-library/index.json', { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
    if (!index?.images?.length) return null;
    // Règles de la campagne (facultatives) : ce que les fichiers ne disent pas (formats/images.md).
    const regles = await fetch('bibliotheque.json', { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null) || {};
    const lieux = await chargerLieux(donnees);
    const pnjListe = (await donnees('pnj')).donnees?.pnj || [];
    Object.entries(regles.categories || {}).forEach(([k, v]) => ajouterCategorie(k, v));
    contributions('imagesCategories').forEach(c => Object.entries(c).forEach(([k, v]) => ajouterCategorie(k, v)));
    const s = await etat('images', { schema: 1, etiquettes: {} });
    s.valeur.etiquettes ||= {};
    const parId = new Map(index.images.map(i => [i.id, i]));
    const etiquettes = i => s.valeur.etiquettes[i.id] || {};

    // Titre d'une image : celui d'un module de campagne (nom VF d'une carte du Tarokka), sinon celui de l'index.
    const titre = i => contributions('imageTitre', i)[0] || i.titre;

    // Source, catégorie et lieux déduits du chemin. Source : le dossier de premier niveau (un par source d'images : livre,
    // homebrew, dossier du MJ), sous son nom. Catégorie et lieu : la première règle de `chemins` dont le
    // texte est dans le chemin, sinon un dossier de cartes, sinon les lieux dont tous les mots du nom (ou de l'id) sont dans
    // le chemin, le dossier de la source mis à part (le plus précis l'emporte : « Port d'Aurval » plutôt que « Aurval »).
    const chemins = (regles.chemins || []).map(r => ({ ...r, contient: normaliser(r.contient) })).filter(r => r.contient);
    const regle = (rel, cle) => chemins.find(r => r[cle] && rel.includes(r.contient))?.[cle] || null;
    const motsLieux = [...lieux.values()].map(l => ({ id: l.id, noms: [l.nom, l.id].map(t => new Set(motsLieu(t))).filter(m => m.size) }));
    function lieuxDuChemin(segments) {
      const mots = new Set(segments.flatMap(motsLieu));
      let scores = motsLieux.map(l => ({ id: l.id, n: Math.max(0, ...l.noms.filter(m => [...m].every(x => mots.has(x))).map(m => m.size)) })).filter(x => x.n);
      // Un sous-lieu trouvé l'emporte sur son lieu (« Cité d'Aurval/Palais royal » : le palais).
      const parents = new Set(scores.map(x => lieux.get(x.id)?.parent).filter(Boolean));
      scores = scores.filter(x => !parents.has(x.id));
      const max = Math.max(0, ...scores.map(x => x.n));
      return scores.filter(x => x.n === max).map(x => x.id);
    }
    for (const i of index.images) {
      const brut = i.chemin.replace(/^images-library\//, '').split('/');
      const rel = normaliser(brut.join('/'));
      const segments = rel.replace(/\.\w+$/, '').split('/');
      const dossiers = segments.slice(0, -1);
      i.source = dossiers.length ? brut[0] : null;
      i.categorieAuto = regle(rel, 'categorie') || (dossiers.some(d => DOSSIERS_CARTES.has(d)) ? 'carte' : 'illustration');
      i.categorie = etiquettes(i).categorie || i.categorieAuto;
      const lieu = regle(rel, 'lieu');
      i.lieuxAuto = lieu ? [lieu] : lieuxDuChemin(segments.slice(dossiers.length ? 1 : 0));
    }

    // PNJ rapprochés d'après le nom du fichier : mots de l'id, du nom et des alias ; on garde le ou les PNJ
    // qui partagent le plus de mots avec le fichier (« isolde-vauclair » : Isolde de Vauclair, pas Bertrand de Vauclair).
    const motsPnj = pnjListe.map(p => {
      const mots = new Set([p.id, p.nom, ...(p.alias || [])].flatMap(t => normaliser(t).split(/[^a-z]+/)).filter(m => m.length >= 4 && !MOTS_VIDES.has(m)));
      return { id: p.id, mots };
    });
    const pnjAuto = new Map(index.images.map(i => {
      if (contributions('imageSansPnj', i).length) return [i.id, []];
      const mots = new Set(normaliser(i.chemin.split('/').pop().replace(/\.\w+$/, '')).split(/[^a-z]+/));
      const scores = motsPnj.map(p => ({ id: p.id, n: [...p.mots].filter(m => mots.has(m)).length })).filter(x => x.n);
      const max = Math.max(0, ...scores.map(x => x.n));
      return [i.id, scores.filter(x => x.n === max).map(x => x.id)];
    }));
    const nomPnj = id => pnjListe.find(p => p.id === id)?.nom || id;

    // Lieux et PNJ d'une image : les déduits, moins ceux que le MJ a retirés (`sans_lieux`, `sans_pnj`), plus ceux qu'il a ajoutés.
    const auto = { lieux: i => i.lieuxAuto, pnj: i => pnjAuto.get(i.id) };
    const deduits = (i, cle) => auto[cle](i).filter(id => !(etiquettes(i)[`sans_${cle}`] || []).includes(id));
    const lieuxDe = i => [...new Set([...deduits(i, 'lieux'), ...(etiquettes(i).lieux || [])])];
    const pnjDe = i => [...new Set([...deduits(i, 'pnj'), ...(etiquettes(i).pnj || [])])];

    function enregistrer(i) {
      const e = s.valeur.etiquettes[i.id];
      if (e) for (const k of Object.keys(e)) if (Array.isArray(e[k]) && !e[k].length) delete e[k];
      if (e && !Object.keys(e).length) delete s.valeur.etiquettes[i.id];
      s.enregistrer(0);
      ouvrir(i);
      s.signaler();
    }
    // Ajouter ou retirer un lieu ou un PNJ : un déduit retiré va dans `sans_…`, et y revient s'il est rajouté.
    function etiqueter(i, cle, id, ajouter) {
      const e = (s.valeur.etiquettes[i.id] ||= {});
      const ajoutes = new Set(e[cle] || []), retires = new Set(e[`sans_${cle}`] || []);
      const deduit = auto[cle](i).includes(id);
      if (ajouter) { if (deduit) retires.delete(id); else ajoutes.add(id); }
      else if (deduit) retires.add(id);
      else ajoutes.delete(id);
      e[cle] = [...ajoutes];
      e[`sans_${cle}`] = [...retires];
      enregistrer(i);
    }
    // Catégorie choisie par le MJ ; revenir à la déduite efface le choix.
    function classer(i, categorie) {
      const e = (s.valeur.etiquettes[i.id] ||= {});
      if (categorie === i.categorieAuto) delete e.categorie; else e.categorie = categorie;
      i.categorie = categorie;
      enregistrer(i);
    }

    // Fenêtre d'une image : l'image, l'autre version (MJ ou joueurs), sa catégorie, les lieux et PNJ étiquetés.
    function ouvrir(i) {
      const autre = i.paire ? parId.get(i.paire) : null;
      const puces = (ids, nom, cle) => ids.map(id => h('li', { class: 'cm-etiquette' },
        nom(id),
        auto[cle](i).includes(id) ? h('span', { class: 'cm-sourdine', title: 'Déduit du nom ou du dossier de l\'image' }, ' · auto') : null,
        bouton('', { icone: 'lu-x', titre: `Retirer ${nom(id)}`, classe: 'bn-btn--s bn-btn--fantome', onclick: () => etiqueter(i, cle, id, false) })));
      const selLieu = h('select', { class: 'bn-select', 'aria-label': 'Ajouter un lieu', onchange: e => e.target.value && etiqueter(i, 'lieux', e.target.value, true) },
        h('option', { value: '' }, '+ Lieu…'), [...lieux.values()].filter(l => (!l.parent || i.lieuxAuto.includes(l.id)) && !lieuxDe(i).includes(l.id)).sort((a, b) => a.nom.localeCompare(b.nom, 'fr')).map(l => h('option', { value: l.id }, l.nom)));
      const selPnj = h('select', { class: 'bn-select', 'aria-label': 'Ajouter un PNJ', onchange: e => e.target.value && etiqueter(i, 'pnj', e.target.value, true) },
        h('option', { value: '' }, '+ PNJ…'), [...pnjListe].filter(p => !pnjDe(i).includes(p.id)).sort((a, b) => a.nom.localeCompare(b.nom, 'fr')).map(p => h('option', { value: p.id }, p.nom)));
      const selCategorie = h('select', { class: 'bn-select', 'aria-label': 'Catégorie', onchange: e => classer(i, e.target.value) },
        Object.entries(CATEGORIES).map(([k, v]) => h('option', { value: k, selected: k === i.categorie }, k === i.categorieAuto ? `${v} (auto)` : v)));
      flottant('image', {
        surtitre: [i.source, CATEGORIES[i.categorie] || i.categorie, i.joueurs ? 'version joueurs' : null].filter(Boolean).join(' · '),
        titre: titre(i),
        largeur: 760,
        contenu: h('div', { class: 'cm-pile cm-visionneuse' },
          // Un clic : l'image en très grand, par-dessus tout, pour la montrer aux joueurs (demande du MJ, 2026-10-25).
          // L'icône de diffusion en haut à droite (plugin Écran des joueurs actif) l'envoie sur leur écran (demande du MJ, 2026-11-03).
          avecEcranJoueurs(infobulle(h('button', { type: 'button', class: 'cm-visionneuse__agrandir', 'aria-label': `Montrer « ${titre(i)} » en grand`, onclick: () => afficherEnGrand(encodeURI(i.chemin), { legende: titre(i) }) },
            h('img', { class: 'cm-visionneuse__image', src: encodeURI(i.chemin), alt: titre(i) })), 'Un clic : en grand.'), encodeURI((i.joueurs ? i : autre?.joueurs ? autre : i).chemin), titre(i)),
          h('div', { class: 'bn-groupe' },
            bouton('En grand', { classe: 'bn-btn--s', icone: 'lu-maximize-2', titre: 'Par-dessus tout, pour la montrer aux joueurs', onclick: () => afficherEnGrand(encodeURI(i.chemin), { legende: titre(i) }) }),
            h('a', { class: 'bn-btn bn-btn--s bn-btn--fantome', href: encodeURI(i.chemin), target: '_blank', rel: 'noopener' }, icone('lu-arrow-right'), h('span', {}, 'Onglet')),
            autre ? bouton(autre.joueurs ? 'Version joueurs' : 'Version MJ', { classe: 'bn-btn--s', icone: autre.joueurs ? 'lu-eye' : 'oeil', onclick: () => ouvrir(autre) }) : null,
            // Ce qu'un plugin ajoute (emplacement imageActions, app/modules.js) : l'écran des joueurs.
            ...contributions('imageActions', i, { lieux: lieuxDe(i), nomLieu: id => nomLieu(lieux, id), titre: titre(i) }).flat(),
            h('span', { class: 'ui-s cm-sourdine' }, [i.largeur && `${i.largeur} × ${i.hauteur}`, `${Math.round(i.octets / 1024).toLocaleString('fr-FR')} Ko`].filter(Boolean).join(' · '))),
          h('div', { class: 'cm-section' },
            h('p', { class: 'etiquette cm-section__titre' }, icone(iconeCategorie(i.categorie), 'bn-icone--s'), 'Catégorie'),
            selCategorie),
          h('div', { class: 'cm-section' },
            h('p', { class: 'etiquette cm-section__titre' }, icone('epingle', 'bn-icone--s'), 'Lieux'),
            h('ul', { class: 'cm-puces' }, puces(lieuxDe(i), id => nomLieu(lieux, id), 'lieux')),
            selLieu),
          h('div', { class: 'cm-section' },
            h('p', { class: 'etiquette cm-section__titre' }, icone('crocs', 'bn-icone--s'), 'PNJ'),
            h('ul', { class: 'cm-puces' }, puces(pnjDe(i), nomPnj, 'pnj')),
            selPnj),
          h('p', { class: 'ui-s cm-sourdine' }, i.dossier)),
      });
    }

    // Vignette : la miniature, sa catégorie en icône en bas à gauche, suivie d'une épingle si l'image a un lieu et de crocs
    // si elle a un PNJ (ce qui manque se voit d'un coup d'œil) ; le détail au survol.
    function vignette(i) {
      const ls = lieuxDe(i), ps = pnjDe(i);
      const detail = [CATEGORIES[i.categorie] || i.categorie,
        ls.length ? ls.map(id => nomLieu(lieux, id)).join(', ') : 'sans lieu',
        ps.length ? ps.map(nomPnj).join(', ') : null].filter(Boolean).join(' · ');
      return infobulle(h('button', { type: 'button', class: 'cm-vignette', onclick: () => ouvrir(i), 'aria-label': `${titre(i)} (${detail})` },
        h('span', { class: 'cm-vignette__image' },
          i.miniature ? h('img', { src: encodeURI(i.miniature), alt: '', loading: 'lazy' }) : icone('carte', 'bn-icone--l'),
          h('span', { class: 'cm-vignette__etiquettes' },
            icone(iconeCategorie(i.categorie), 'bn-icone--s'),
            ls.length ? icone('epingle', 'bn-icone--s cm-vignette__lieu') : null,
            ps.length ? icone('crocs', 'bn-icone--s cm-vignette__pnj') : null)),
        h('span', { class: 'cm-vignette__titre' }, titre(i)),
        i.paire && !i.joueurs ? h('span', { class: 'cm-vignette__marque', title: 'Existe en version joueurs' }, icone('lu-eye', 'bn-icone--s')) : null,
        i.joueurs ? h('span', { class: 'cm-vignette__marque', title: 'Version joueurs' }, 'J') : null), detail, { titre: titre(i) });
    }

    return { index, s, lieux, titre, lieuxDe, pnjDe, nomPnj, ouvrir, vignette, parId };
  })();
  return promesse;
}
