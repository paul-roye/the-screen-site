// Paquets de musique par défaut (modeles/musique/, construits par le script de paquets du mainteneur, mainteneur/construire-paquets.ps1
// depuis une musique déjà importée) : cochés à la création d'une campagne (accueil, « Nouvelle campagne »), ils donnent
// son musique/ de départ. Thèmes seulement (pas de lieux, PNJ ni factions : ceux d'une autre campagne).
// listerPaquets() -> [{ id, nom, description, playlists, pistes, genre? }] ; fusionnerPaquets(ids) -> { sources, pistes }
// (textes JSON) : musique/sources.json et musique/pistes.json de la campagne, comme si l'import les avait écrits depuis
// toutes ces playlists (une vidéo de deux paquets n'est gardée qu'une fois), ou null sans paquet.

const BASE = '/modeles/musique/';

export async function listerPaquets() {
  try {
    const r = await fetch(BASE + 'paquets.json', { cache: 'no-store' });
    return r.ok ? (await r.json()).paquets || [] : [];
  } catch { return []; }
}

const lireJson = async chemin => {
  const r = await fetch(BASE + chemin, { cache: 'no-store' });
  if (!r.ok) throw new Error(`Paquet de musique illisible : ${chemin}.`);
  return r.json();
};

// Les éléments de plusieurs listes, le premier de chaque `id` gardé.
const unir = listes => {
  const m = new Map();
  for (const l of listes) for (const x of l || []) if (!m.has(x.id)) m.set(x.id, structuredClone(x));
  return [...m.values()];
};
// Thèmes de séance (ouverture, fin) : ceux du premier paquet qui en a choisi un, sinon le premier tout court.
const themesDe = listes => {
  const ids = [...new Set(listes.flatMap(l => (l || []).map(t => t.id)))];
  return ids.map(id => structuredClone(listes.map(l => (l || []).find(t => t.id === id)).find(t => t?.video) || listes.map(l => (l || []).find(t => t.id === id)).find(Boolean)));
};

export async function fusionnerPaquets(ids) {
  if (!ids?.length) return null;
  const lus = await Promise.all(ids.map(async id => ({ s: await lireJson(`${id}/sources.json`), p: await lireJson(`${id}/pistes.json`) })));
  const regles = [], vues = new Set();
  for (const { s } of lus) for (const r of s.regles || []) {
    const cle = JSON.stringify([r.motif, r.etiquettes]);
    if (!vues.has(cle)) { vues.add(cle); regles.push(r); }
  }
  const sources = {
    schema: 1, jeu: 'musique-sources', titre: lus[0].s.titre, avertissement: lus[0].s.avertissement, paquets: ids,
    ...(lus.some(x => x.s.bruit?.length) ? { bruit: [...new Set(lus.flatMap(x => x.s.bruit || []))] } : {}),   // noms de l'aventure à ôter des titres
    playlists: unir(lus.map(x => x.s.playlists)),
    themes: themesDe(lus.map(x => x.s.themes)),
    etiquettes: unir(lus.map(x => x.s.etiquettes)),
    regles,
    pistes: Object.assign({}, ...lus.map(x => x.s.pistes || {})),
  };

  // Pistes : dans l'ordre des paquets ; une vidéo déjà vue reçoit la source de l'autre en `aussi`, et ses étiquettes.
  const parId = new Map();
  for (const { p } of lus) for (const x of p.pistes || []) {
    const deja = parId.get(x.id);
    if (!deja) { parId.set(x.id, structuredClone(x)); continue; }
    deja.aussi = [...new Set([...(deja.aussi || []), x.source, ...(x.aussi || [])])].filter(id => id !== deja.source);
    deja.etiquettes = [...new Set([...deja.etiquettes, ...x.etiquettes])];
    deja.note ||= x.note;
  }
  const pistes = [...parId.values()];
  const rang = new Map(sources.etiquettes.map((e, i) => [e.id, i]));
  for (const x of pistes) x.etiquettes.sort((a, b) => (rang.get(a) ?? 1e6) - (rang.get(b) ?? 1e6));
  const dans = id => pistes.filter(x => x.source === id || (x.aussi || []).includes(id)).length;
  const fichierPistes = {
    schema: 1, jeu: 'musique', titre: lus[0].p.titre, genere_le: lus.map(x => x.p.genere_le).sort().at(-1), avertissement: lus[0].p.avertissement, paquets: ids,
    sources: unir(lus.map(x => x.p.sources)).map(s => ({ ...s, pistes: dans(s.id) })),
    themes: themesDe(lus.map(x => x.p.themes)),
    etiquettes: unir(lus.map(x => x.p.etiquettes)).map(e => ({ ...e, pistes: pistes.filter(x => x.etiquettes.includes(e.id)).length })),
    pistes,
  };
  return { sources: JSON.stringify(sources, null, 2) + '\n', pistes: JSON.stringify(fichierPistes, null, 2) + '\n' };
}
