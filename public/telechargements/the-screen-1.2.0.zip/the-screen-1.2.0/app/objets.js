// Objets à trouver ou à recevoir : ceux de data/objets.json (formats/objets.md) et ceux que le MJ crée ici, rattachés à un
// lieu (et sous-lieu), un jalon, une étape ou une rencontre. Pour chacun : l'objet de D&D Beyond qui lui correspond
// (catalogue de l'extension, cherché d'après son nom anglais) ou un objet personnalisé (nom, description, commentaire,
// poids en livres), puis « Donner » à un héros ou au groupe : l'objet va dans l'inventaire D&D Beyond (extension, commande
// « objet ») et le don est noté. Un clic sur un objet ouvre sa fenêtre flottante (« objet:<id> »).
// Utilisé par le widget Objets, Ici (objets du lieu), le Déroulé (jalons, étapes) et la préparation des rencontres.
// État : etat/objets.json (formats/etat.md) : retouches des objets des données, objets créés, objet de D&D Beyond choisi, dons.
// Catalogue : tous les objets que le compte du MJ a débloqués (extension, commande « objets »), gardé un jour dans le
// navigateur, filtré par les livres choisis (app/livres-beyond.js) ; textes à la demande (« objets-fiches »).

import { h, icone, bouton, badge, alerte, section, blocOriginal, provenance, flottant, flottantOuvert, lienFlottant, bascule, identifiant, normaliser, heure, FINE } from './ui.js';
import { lisible, estFixe } from './des.js';
import { lancerVisible } from './lancers.js';
import { chargerLieux, nomComplet, sousLieux } from './lieux.js';
import { ordreDesScenarisees } from './scenarisees.js';
import { etatHorloge, horlogeEnService, maintenant, libelleMoment } from './horloge.js';
import { derouleSurLeTableau, voirJalon, voirEtape } from './trame.js';
import { lireBeyond, demanderExtension, ficheDe } from './beyond.js';
import { chargerLivres, livres, surChangementLivres } from './livres-beyond.js';
import { contributions } from './modules.js';

const DEFAUT = { schema: 1, objets: {} };
export const etatObjets = etat => etat('objets', DEFAUT);

// Genre d'un objet (formats/objets.md) : libellé et icône.
export const GENRES = {
  magique: ['Objet magique', 'amulette'],
  equipement: ['Équipement', 'epee'],
  tresor: ['Trésor', 'piece'],
  document: ['Document', 'lettre'],
  cle: ['Clé', 'cle'],
  autre: ['Objet', 'lu-box'],
};
const STATUTS = { 'a-donner': 'À donner', partiel: 'En partie donné', donne: 'Donné' };
const ATTENTE_RECHERCHE = 700;   // ms après la dernière touche
const PAR_PAGE = 12;

// ───── Catalogue de D&D Beyond (par l'extension) ─────

// « :2 » : catalogue complet et `groupe` des variantes (extension 1.8.1) ; un cache plus ancien est relu.
const CLE_CATALOGUE = 'cm:objets-beyond:2';
let promesseCatalogue = null;
surChangementLivres(() => { promesseCatalogue = null; });

let promesseConfig = null;
const configBeyond = () => {
  promesseConfig ||= demanderExtension({ type: 'config' });
  promesseConfig.catch(() => { promesseConfig = null; });
  return promesseConfig;
};

// Tous les objets du compte (résumés), marqués `partenaire` (source d'un éditeur partenaire) et `dansLivres` (à montrer
// d'après le réglage des livres). { liste, parCle, campagne }.
export function chargerCatalogue({ forcer = false } = {}) {
  if (promesseCatalogue && !forcer) return promesseCatalogue;
  promesseCatalogue = (async () => {
    const beyond = await lireBeyond();
    const campagne = beyond.campagne?.id || null;
    let liste = null;
    if (!forcer) {
      try {
        const c = JSON.parse(localStorage.getItem(CLE_CATALOGUE) || 'null');
        if (c && Date.now() - c.quand < 864e5 && c.campagne === campagne && Array.isArray(c.liste)) liste = c.liste;
      } catch { /* pas de cache */ }
    }
    if (!liste) {
      liste = await demanderExtension({ type: 'objets', campagne }, 180000);
      // Pas de cache pour le catalogue incomplet d'une extension 1.8.0 (sans `groupe`) : relu une fois l'extension rechargée.
      if (liste.length && 'groupe' in liste[0]) try { localStorage.setItem(CLE_CATALOGUE, JSON.stringify({ quand: Date.now(), campagne, liste })); } catch { /* cache impossible */ }
    }
    let cfg = null;
    try { cfg = await configBeyond(); } catch { /* sans dictionnaire : pas de contenu partenaire reconnu */ }
    const categorie = new Map((cfg?.sources || []).map(s => [s.id, s.categorie]));
    const partenaires = new Set((cfg?.categories || []).filter(c => c.partenaire).map(c => c.id));
    const sigles = new Map((cfg?.sources || []).map(s => [s.id, s.sigle]));
    const l = livres();
    for (const o of liste) {
      o.cle = `${o.id}:${o.type}`;
      o.nomCle = normaliser(o.nom);
      o.partenaire = o.sources.some(id => partenaires.has(categorie.get(id)));
      o.sigle = o.homebrew ? 'Homebrew' : o.sources.map(id => l.sigle.get(id) || sigles.get(id)).filter(Boolean).join(', ') || null;
    }
    return { liste, parCle: new Map(liste.map(o => [o.cle, o])), campagne };
  })();
  promesseCatalogue.catch(() => { promesseCatalogue = null; });
  return promesseCatalogue;
}

// Un objet du catalogue est-il dans les livres choisis ? (livres cochés, contenu partenaire, homebrews)
function dansLesLivres(o) {
  const l = livres();
  if (o.homebrew) return l.homebrew;
  return o.sources.some(id => l.ids.includes(id)) || (l.partenaires && o.partenaire);
}

const fichesBeyond = new Map();   // "id:type" -> fiche (résumé, description HTML…)
export async function fichesObjets(cles) {
  const manquantes = [...new Set(cles)].filter(c => c && !fichesBeyond.has(c));
  if (manquantes.length) {
    const { campagne } = await chargerCatalogue();
    for (let i = 0; i < manquantes.length; i += 50) {
      (await demanderExtension({ type: 'objets-fiches', campagne, cles: manquantes.slice(i, i + 50) }, 120000)).forEach((f, j) => fichesBeyond.set(manquantes[i + j], f));
    }
  }
  return cles.map(c => fichesBeyond.get(c) || null);
}

// Classement d'une recherche : nom exact, puis début du nom, puis début d'un mot ; les versions 2014 après les autres.
function chercher(catalogue, texte, { magiques = false } = {}) {
  const mots = normaliser(texte).split(/[\s,()]+/).filter(Boolean);
  if (!mots.length) return null;
  const q = mots.join(' ');
  return catalogue.liste
    .filter(o => dansLesLivres(o) && (!magiques || o.magique) && mots.every(w => o.nomCle.includes(w)))
    .map(o => ({ o, rang: o.nomCle === q ? 0 : o.nomCle.startsWith(q) ? 1 : o.nomCle.split(/[\s,'’()-]+/).some(w => w.startsWith(mots[0])) ? 2 : 3 }))
    .sort((a, b) => a.rang - b.rang || Number(a.o.legacy) - Number(b.o.legacy) || a.o.nom.localeCompare(b.o.nom, 'en'))
    .map(x => x.o);
}

// L'objet que désigne sans hésitation un nom anglais (demande du MJ, 2026-10-23) : le seul des livres choisis qui porte
// exactement ce nom, sinon les mêmes mots dans un autre ordre, sans quantité entre parenthèses (« Hand Crossbow » →
// « Crossbow, Hand », « Bolts (20) » → « Bolts ») ; la version 2024 passe avant celle de 2014, un livre avant un homebrew.
// null s'il y a doute. Essayé sur le catalogue du MJ : 94 des 102 objets des données qui ont un nom anglais.
const nomCompare = t => normaliser(t).split(/[\s,()]+/).filter(Boolean).join(' ');
const motsCompare = t => normaliser(t).replace(/\(\s*\d+\s*\)/g, ' ').split(/[\s,()]+/).filter(Boolean).sort().join(' ');
function choixEvident(catalogue, nomEn) {
  const garder = l => {
    if (l.length > 1 && l.some(o => !o.legacy)) l = l.filter(o => !o.legacy);
    if (l.length > 1 && l.some(o => !o.homebrew)) l = l.filter(o => !o.homebrew);
    return l;
  };
  for (const cle of [nomCompare, motsCompare]) {
    const q = cle(nomEn);
    if (!q) return null;
    const l = garder(catalogue.liste.filter(o => dansLesLivres(o) && cle(o.nom) === q));
    if (l.length) return l.length === 1 ? l[0] : null;
  }
  return null;
}

// Raretés du SRD en VF (formats/objets.md), au masculin.
const RARETES = { Common: 'courant', Uncommon: 'peu courant', Rare: 'rare', 'Very Rare': 'très rare', Legendary: 'légendaire', Artifact: 'artefact', Varies: 'variable', Unknown: 'inconnue' };
const rareteVf = r => RARETES[r] || r || null;
const livresLb = p => (p != null && p !== '' ? `${String(p).replace('.', ',')}${FINE}lb` : null);
// « Wondrous item · légendaire · harmonisation · DMG · 2014 » ; « générique » : objet que D&D Beyond n'ajoute pas tel quel.
const resumeBeyond = o => [o.genre, o.magique ? rareteVf(o.rarete) : null, o.harmonisation ? 'harmonisation' : null, livresLb(o.poids || null), o.sigle, o.legacy ? '2014' : null,
  o.ajoutable === false ? 'générique' : null].filter(Boolean).join(' · ');

// Un objet générique de D&D Beyond (« Silvered Weapon », « Armor, +1 », « Bag of Tricks ») ne s'ajoute pas à un inventaire
// (canBeAddedToInventory faux) : ses variantes, qui renvoient à lui par `groupe` (groupedId), si.
const variantesDe = (c, o) => c.liste.filter(v => v.groupe === o.id && !v.legacy);
// Arme ou munition de base nommée dans un texte français (les `effets` d'une arme argentée : « à partir d'une dague ») :
// le mot anglais qui la reconnaît parmi les variantes.
const ARMES_VF = [['épée courte', 'shortsword'], ['épée longue', 'longsword'], ['épée à deux mains', 'greatsword'], ['dague', 'dagger'], ['rapière', 'rapier'],
  ['cimeterre', 'scimitar'], ['hache d\'armes', 'battleaxe'], ['hachette', 'handaxe'], ['grande hache', 'greataxe'], ['masse d\'armes', 'mace'], ['marteau de guerre', 'warhammer'],
  ['lance d\'arçon', 'lance'], ['lance', 'spear'], ['arc court', 'shortbow'], ['arc long', 'longbow'], ['arbalète de poing', 'hand crossbow'], ['arbalète légère', 'light crossbow'],
  ['arbalète lourde', 'heavy crossbow'], ['carreau', 'bolt'], ['flèche', 'arrow'], ['javeline', 'javelin'], ['bâton', 'quarterstaff'], ['fléau', 'flail'], ['fouet', 'whip'], ['serpe', 'sickle']];
const armeDeBase = texte => { const t = normaliser(texte); return ARMES_VF.find(([vf]) => t.includes(normaliser(vf)))?.[1] || null; };

// Texte HTML de D&D Beyond en paragraphes de texte (jamais d'innerHTML) : un paragraphe par bloc, une ligne par rangée de table.
function texteBeyond(html) {
  const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
  const blocs = [];
  const visiter = el => {
    for (const n of el.children) {
      if (n.matches('table')) n.querySelectorAll('tr').forEach(tr => blocs.push([...tr.children].map(c => c.textContent.trim()).filter(Boolean).join(' · ')));
      else if (n.matches('ul, ol')) n.querySelectorAll(':scope > li').forEach(li => blocs.push('• ' + li.textContent.trim()));
      else if (n.matches('div, section') && n.children.length) visiter(n);
      else blocs.push(n.textContent.trim());
    }
  };
  visiter(doc.body);
  if (!blocs.length && doc.body.textContent.trim()) blocs.push(doc.body.textContent.trim());
  return blocs.filter(Boolean).map(t => h('p', { class: 'ui' }, t));
}

const vignette = (url, nom, ic = 'lu-box') => (url
  ? h('img', { class: 'cm-avatar', src: url, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer', title: nom || null })
  : h('span', { class: 'cm-avatar cm-avatar--vide' }, icone(ic, 'bn-icone--s')));

// ───── Outils (un seul jeu pour toute la page) ─────

let promesseOutils = null;
export function outilsObjets(ctx) {
  promesseOutils ||= creerOutils(ctx);
  return promesseOutils;
}

async function creerOutils({ donnees, etat, dialogue }) {
  const s = await etatObjets(etat);
  const v = () => s.valeur;
  v().objets ||= {};
  await chargerLivres(etat);
  const lire = async jeu => (await donnees(jeu)).donnees;
  const [d, lectR, deroule, pnjD, persosD, lieux, sH] = await Promise.all([
    lire('objets'), lire('rencontres-aleatoires'), lire('deroule-campagne'), lire('pnj'), lire('personnages'), chargerLieux(donnees), etatHorloge(etat)]);
  const donneesObjets = d?.objets || [];
  const parIdDonnees = new Map(donneesObjets.map(o => [o.id, o]));
  const scenarisees = new Map((lectR?.rencontres_scenarisees || []).map(r => [r.id, r]));
  const etapes = [...(deroule?.etapes || [])].sort((a, b) => a.ordre - b.ordre);
  const etapeParId = new Map(etapes.map(e => [e.id, e]));
  const jalonParId = new Map((deroule?.jalons || []).map(j => [j.id, j]));
  const pnjParId = new Map((pnjD?.pnj || []).map(p => [p.id, p]));
  const heros = (persosD?.personnages || []).filter(p => p.role === 'personnage');
  const persoParId = new Map((persosD?.personnages || []).map(p => [p.id, p]));
  const ordreScen = ordreDesScenarisees(deroule, lectR?.rencontres_scenarisees || []);
  const place = id => etapes.findIndex(e => e.id === id);

  const enregistrer = (source = null) => { s.enregistrer(0); s.signaler(source); };
  const quandMaintenant = () => ({ horloge: horlogeEnService() ? maintenant(sH.valeur) : null, quand: new Date().toISOString() });
  const libelleQuand = q => (q ? (q.horloge ? libelleMoment(q.horloge) : heure(q.quand)) : '');
  const nomPerso = id => (id === 'groupe' ? 'le groupe' : persoParId.get(id)?.nom_court || persoParId.get(id)?.nom || id);

  // Entrée d'état d'un objet (créée au besoin pour un objet des données).
  function entree(id, creer = false) {
    let e = v().objets[id];
    if (!e && creer && parIdDonnees.has(id)) e = v().objets[id] = { dons: [] };
    if (e) e.dons ||= [];
    return e || null;
  }

  // Vue d'un objet : ce qu'il faut pour l'afficher, qu'il vienne des données ou du MJ. null s'il n'existe pas.
  function vueDe(id) {
    const o = parIdDonnees.get(id) || null;
    const e = v().objets[id] || null;
    if (!o && !e) return null;
    const origine = o ? 'donnees' : e.cree ? 'cree' : 'orphelin';
    if (origine === 'orphelin' && !e.dons?.length) return null;   // retouches d'un objet disparu des données, sans don : rien à montrer
    const formule = e?.quantite != null ? String(e.quantite) : o?.quantite != null ? String(o.quantite) : '1';
    const fixe = estFixe(formule) || !lisible(formule);
    const quantite = fixe ? Math.max(1, parseInt(formule.match(/\d+/)?.[0] || '1', 10)) : null;   // null : à lancer
    const dons = e?.dons || [];
    // Un don « identification » (l'objet de D&D Beyond donné après l'objet personnalisé) ne compte pas une seconde fois.
    const donne = dons.filter(x => !x.identification).reduce((n, x) => n + (x.quantite || 1), 0);
    const reste = quantite == null ? null : Math.max(0, quantite - donne);
    const nom = o ? o.nom : e.nom?.trim() || (origine === 'orphelin' ? `${id} (absent des données)` : 'Objet sans nom');
    return {
      id, origine, o, e, nom,
      // Nom de l'objet personnalisé sur D&D Beyond : retouché par le MJ, sinon celui que voient les joueurs (`nom_joueurs`).
      nomBeyond: (o ? e?.nom?.trim() : null) || o?.nom_joueurs || nom,
      nom_en: e?.nom_en ?? o?.nom_en ?? '',
      description: e?.description ?? o?.description ?? '',
      commentaire: e?.commentaire ?? '',
      poids: e?.poids !== undefined ? e.poids : o?.poids ?? null,
      // Valeur marchande d'un exemplaire (po entières) : le coût de l'objet personnalisé sur D&D Beyond.
      cout: e?.cout !== undefined ? e.cout : o?.cout ?? null,
      coutEstime: e?.cout === undefined && !!o?.cout_estime,
      genre: e?.genre || o?.genre || 'autre',
      formule, quantite, dons, donne, reste,
      beyond: e?.beyond || null,
      // Objet personnalisé sur D&D Beyond : choisi par le MJ, ou d'office quand les données disent qu'il n'existe pas là-bas,
      // ou que les joueurs ne doivent pas encore savoir ce que c'est (`nom_joueurs`).
      personnalise: e?.personnalise ?? (o?.beyond === false || !!o?.nom_joueurs),
      // Nom de l'objet du catalogue dans l'inventaire D&D Beyond (renommé par l'extension) : celui du MJ (`nom_beyond` ;
      // vide : le nom anglais de D&D Beyond), sinon `nom_joueurs` tant qu'il n'est pas identifié, sinon le nom VF.
      nomCatalogue: e?.nom_beyond != null ? e.nom_beyond : o?.nom_joueurs && !dons.some(x => x.identification) ? o.nom_joueurs : nom,
      nomCatalogueRetouche: e?.nom_beyond != null,
      // Donné en objet personnalisé sous son nom pour les joueurs, pas encore remplacé par l'objet de D&D Beyond.
      aIdentifier: !!o?.nom_joueurs && o.beyond !== false && dons.some(x => x.beyond && !x.beyond.catalogue) && !dons.some(x => x.identification),
      statut: !donne ? 'a-donner' : reste === 0 ? 'donne' : 'partiel',
      rattachement: o ? { lieu: o.lieu, sous_lieu: o.sous_lieu, jalon: o.jalon, etape: o.etape, rencontre: o.rencontre, pnj: o.pnj, personnage: o.personnage }
        : e?.rattachement || {},
    };
  }
  const tousLesIds = () => [...parIdDonnees.keys(), ...Object.keys(v().objets).filter(id => !parIdDonnees.has(id))];

  // Où le trouver, en une ligne.
  function ouDe(vue) {
    const r = vue.rattachement;
    const morceaux = [];
    if (r.lieu) morceaux.push(nomComplet(lieux, r.lieu, r.sous_lieu));
    if (r.rencontre) morceaux.push(scenarisees.has(r.rencontre) ? `rencontre « ${scenarisees.get(r.rencontre).nom} »` : 'rencontre du MJ');
    if (r.jalon) morceaux.push(jalonParId.has(r.jalon) ? `jalon « ${jalonParId.get(r.jalon).nom} »` : `jalon ${r.jalon}`);
    if (r.etape) morceaux.push(etapeParId.has(r.etape) ? `étape ${etapeParId.get(r.etape).ordre} : ${etapeParId.get(r.etape).nom}` : `étape ${r.etape}`);
    if (r.pnj && !r.rencontre) morceaux.push(pnjParId.get(r.pnj)?.nom || r.pnj);
    return morceaux.join(' · ') || 'Rattaché à rien';
  }

  // Rang dans l'ordre de la campagne : jalon, rencontre (comme l'onglet Hors tables), étape, puis première étape du lieu.
  function rangDe(vue) {
    const r = vue.rattachement;
    if (r.jalon && jalonParId.has(r.jalon)) { const j = jalonParId.get(r.jalon); return place(j.etape) * 1000 + (j.rang || 0) + 0.25; }
    if (r.rencontre && ordreScen.get(r.rencontre)) return ordreScen.get(r.rencontre).rang + 0.5;
    if (r.etape && place(r.etape) >= 0) return place(r.etape) * 1000 + 998;
    const lieu = r.lieu || pnjParId.get(r.pnj)?.lieu;
    if (lieu) { const i = etapes.findIndex(e => (e.lieux || []).includes(lieu)); if (i >= 0) return i * 1000 + 999; }
    return Infinity;
  }
  const ranger = ids => ids.map((id, i) => ({ vue: vueDe(id), i })).filter(x => x.vue).sort((a, b) => rangDe(a.vue) - rangDe(b.vue) || a.i - b.i).map(x => x.vue);

  // ───── Listes ─────

  const tous = () => ranger(tousLesIds());
  // Au lieu général : ceux de ses sous-lieux compris ; dans un sous-lieu : les siens. Un objet sans lieu porté par un PNJ
  // de ce lieu y compte aussi.
  function duLieu(lieu, sous = null) {
    return ranger(tousLesIds().filter(id => {
      const r = vueDe(id)?.rattachement || {};
      const p = !r.lieu && r.pnj ? pnjParId.get(r.pnj) : null;
      const [l, sl] = r.lieu ? [r.lieu, r.sous_lieu] : p ? [p.lieu, p.sous_lieu] : [null, null];
      return l === lieu && (!sous || sl === sous);
    }));
  }
  const duJalon = j => ranger(tousLesIds().filter(id => vueDe(id)?.rattachement.jalon === j.id));
  const deLEtape = e => ranger(tousLesIds().filter(id => vueDe(id)?.rattachement.etape === e.id));
  const deLaRencontre = rid => ranger(tousLesIds().filter(id => vueDe(id)?.rattachement.rencontre === rid));

  // ───── Avant de terminer un jalon ou une étape (formats/objets.md, « Alerte de fin ») ─────

  // Objets pas encore entièrement donnés qui tiennent aux jalons et aux étapes qu'on termine. Un jalon : `jalon`, ou une
  // `rencontre` de ses `rencontres`. Une étape : les objets de ses jalons et ceux qui portent son `etape` ; `surPlace` :
  // ceux qui ne tiennent qu'à un lieu de l'étape (ni jalon, ni étape, ni rencontre). `donnes` : objets que l'appelant va donner
  // (bloc maj-etat de fin de session), comptés comme donnés. → { liste, surPlace }
  function enAttente({ jalons = [], etapes: ets = [], donnes = [] }) {
    const idsJalons = new Set([...jalons, ...ets.flatMap(eid => (deroule?.jalons || []).filter(j => j.etape === eid).map(j => j.id))]);
    const rencontres = new Set([...idsJalons].flatMap(id => jalonParId.get(id)?.rencontres || []));
    const idsEtapes = new Set(ets);
    const lieuxEtapes = new Set(ets.flatMap(eid => etapeParId.get(eid)?.lieux || []));
    const vues = tousLesIds().map(vueDe).filter(x => x && x.statut !== 'donne' && !donnes.includes(x.id));
    const liste = vues.filter(x => idsJalons.has(x.rattachement.jalon) || idsEtapes.has(x.rattachement.etape) || rencontres.has(x.rattachement.rencontre));
    const pris = new Set(liste.map(x => x.id));
    const surPlace = vues.filter(x => !pris.has(x.id) && !x.rattachement.jalon && !x.rattachement.etape && !x.rattachement.rencontre && lieuxEtapes.has(x.rattachement.lieu));
    const trier = l => l.map((vue, i) => ({ vue, i })).sort((a, b) => rangDe(a.vue) - rangDe(b.vue) || a.i - b.i).map(x => x.vue);
    return { liste: trier(liste), surPlace: trier(surPlace) };
  }

  // À appeler avant de terminer des jalons ou des étapes, d'où qu'on les termine (Déroulé, fin de session). Rien en attente :
  // vrai tout de suite. Sinon une fenêtre les liste (un clic ouvre l'objet, pour le donner ; la liste suit les dons) et
  // demande confirmation : vrai si le MJ termine quand même. quoi : { jalons: [id], etapes: [id], donnes?: [id] }.
  function avantDeTerminer(quoi) {
    const avant = enAttente(quoi);
    if (!avant.liste.length && !avant.surPlace.length) return Promise.resolve(true);
    const noms = [...(quoi.jalons || []).map(id => jalonParId.get(id)?.nom), ...(quoi.etapes || []).map(id => etapeParId.get(id)?.nom)].filter(Boolean);
    return new Promise(fin => {
      let ok = false;
      const zone = h('div', { class: 'cm-pile' });
      const majZone = () => {
        const { liste: l, surPlace } = enAttente(quoi);
        zone.replaceChildren(...[
          l.length ? h('p', { class: 'ui' }, `${l.length} objet${l.length > 1 ? 's' : ''} pas encore donné${l.length > 1 ? 's' : ''} : un clic ouvre l'objet, pour le donner.`)
            : h('p', { class: 'ui' }, icone('lu-check', 'bn-icone--s'), ' Tout ce qui tient au jalon ou à l\'étape est donné.'),
          l.length ? liste(l) : null,
          surPlace.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `Restés sur place (${surPlace.length})`),
            h('p', { class: 'ui-s cm-sourdine' }, 'Trouvés dans les lieux de l\'étape, sans jalon ni rencontre : à prendre avant de partir, ou à laisser.'), liste(surPlace)) : null,
        ].filter(Boolean));
      };
      majZone();
      const desabonner = s.abonner(majZone);
      let dlg;
      dlg = dialogue('Objets à donner', noms.length === 1 ? `Terminer « ${noms[0]} »` : 'Terminer', zone, h('div', { class: 'bn-groupe' },
        bouton('Terminer quand même', { classe: 'bn-btn--primaire', icone: 'lu-check', titre: 'Les objets restent « à donner »', onclick: () => { ok = true; dlg.close(); } }),
        bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
      dlg.addEventListener('close', () => { desabonner(); fin(ok); }, { once: true });
    });
  }

  // ───── Ligne ─────

  function badgeStatut(vue) {
    if (vue.dons.some(x => x.retrait)) return badge('Retrait demandé', 'cierge', 'lu-rotate-ccw');
    if (vue.statut === 'donne') {
      const qui = [...new Set(vue.dons.map(x => x.a))].map(nomPerso);
      return badge(qui.length > 1 ? 'Donné' : qui[0] === 'le groupe' ? 'Au groupe' : `À ${qui[0]}`, 'brume', 'lu-gift');
    }
    if (vue.statut === 'partiel') return badge(`${vue.donne}/${vue.quantite} donnés`, 'soleil', 'lu-gift');
    return null;
  }

  // Un objet dans une liste : un clic ouvre sa fenêtre. ou : la ligne dit où le trouver (widget Objets).
  function ligne(vue, { ou = false } = {}) {
    const [genre, ic] = GENRES[vue.genre] || GENRES.autre;
    const qte = vue.quantite == null ? vue.formule : vue.quantite > 1 ? `×${vue.quantite}` : null;
    const meta = [ou ? ouDe(vue) : null, vue.o?.obtention].filter(Boolean).join(' · ');
    const btn = h('button', { type: 'button', class: `bn-carte cm-objet cm-ouvre cm-objet--${vue.statut}`, title: `${genre} : ouvrir, donner`, onclick: () => ouvrir(vue.id) },
      h('span', { class: 'cm-objet__nom cm-ouvre__nom' }, icone(ic, 'bn-icone--s'), h('span', {}, vue.nom), qte ? h('span', { class: 'cm-objet__qte' }, qte) : null),
      h('span', { class: 'cm-objet__badges' }, badgeStatut(vue),
        vue.o?.maudit ? badge('Maudit', 'sang', 'crane') : null,
        vue.genre === 'magique' && vue.o?.rarete ? badge(vue.o.rarete, 'ultra') : null,
        vue.origine === 'cree' ? badge('MJ', 'sang', 'lu-pencil') : null),
      meta ? h('span', { class: 'cm-objet__meta' }, meta) : null);
    return lienFlottant(btn, 'objet:' + vue.id);
  }
  const liste = vues => h('div', { class: 'cm-objets-liste' }, vues.map(x => ligne(x)));

  // « + Objet » : en crée un, rattaché (lieu, jalon, étape, rencontre…), et ouvre sa fenêtre.
  function boutonNouveau(rattachement = {}, { libelle = 'Objet', classe = 'bn-btn--s bn-btn--fantome' } = {}) {
    return bouton(libelle, { icone: 'lu-plus', classe, titre: 'Créer un objet ici : de D&D Beyond ou personnalisé', onclick: () => nouveau(rattachement) });
  }
  function nouveau(rattachement = {}) {
    const id = 'mj-' + identifiant();
    v().objets[id] = { cree: true, nom: 'Nouvel objet', genre: 'autre', description: '', rattachement: Object.fromEntries(Object.entries(rattachement).filter(([, x]) => x)), dons: [], creee: new Date().toISOString() };
    enregistrer();
    ouvrir(id, { nommer: true });
    return id;
  }

  // ───── Fenêtre d'un objet ─────

  const recherches = new Map();   // id d'objet -> { texte, magiques, nombre, ouverte }
  const ouvertes = new Set();
  const etatRecherche = vue => {
    if (!recherches.has(vue.id)) recherches.set(vue.id, { texte: vue.nom_en || (vue.e?.cree && vue.nom === 'Nouvel objet' ? '' : vue.nom), magiques: false, nombre: PAR_PAGE });
    return recherches.get(vue.id);
  };

  function ouvrir(id, { nommer = false } = {}) {
    const vue = vueDe(id);
    if (!vue) return;
    ouvertes.add(id);
    flottant('objet:' + id, { surtitre: surtitreFenetre(vue), titre: vue.nom, largeur: 560, pictogramme: 'amulette', contenu: contenuFenetre(id) });
    if (nommer) setTimeout(() => { const c = flottantOuvert('objet:' + id)?.el.querySelector('.cm-objet-f__nom'); c?.focus(); c?.select(); }, 0);
  }
  const surtitreFenetre = vue => [(GENRES[vue.genre] || GENRES.autre)[0], vue.origine === 'cree' ? 'créé par le MJ' : null, vue.statut !== 'a-donner' ? STATUTS[vue.statut].toLowerCase() : null].filter(Boolean).join(' · ');

  // Redessine les fenêtres ouvertes, sauf celle où l'on tape (forcer : la redessiner quand même, le champ de recherche
  // reprenant la main).
  function rafraichirFenetres(forcer = null) {
    for (const id of [...ouvertes]) {
      const f = flottantOuvert('objet:' + id);
      const vue = vueDe(id);
      if (!f || !vue) { f?.fermer(); ouvertes.delete(id); continue; }
      const tape = f.el.contains(document.activeElement) && document.activeElement.matches('input, textarea, select');
      if (tape && id !== forcer) continue;
      const cherchait = tape && document.activeElement.classList.contains('cm-recherche__champ');
      f.maj(contenuFenetre(id), vue.nom, surtitreFenetre(vue));
      if (cherchait) setTimeout(() => f.el.querySelector('.cm-recherche__champ')?.focus(), 0);
    }
  }
  s.abonner(rafraichirFenetres);

  function contenuFenetre(id) {
    const vue = vueDe(id);
    const o = vue.o;
    return h('div', { class: 'cm-pile cm-objet-f' },
      h('p', { class: 'cm-prep__ou' }, icone('epingle', 'bn-icone--s'), ouDe(vue), ' ',
        vue.o?.rarete ? badge(vue.o.rarete, 'ultra') : null, o?.harmonisation ? badge('Harmonisation', null) : null, o?.maudit ? badge('Maudit', 'sang', 'crane') : null,
        valeurObjet(vue)),
      vue.origine === 'cree' ? champsCreation(vue) : null,
      o?.nom_joueurs ? h('p', { class: 'ui cm-objet-f__obtention', title: 'Le nom que voient les joueurs tant qu\'ils n\'ont pas identifié l\'objet' },
        icone('lu-eye', 'bn-icone--s'), h('span', {}, 'Pour les joueurs : ', h('b', {}, o.nom_joueurs))) : null,
      lignesRattachement(vue, o),
      o?.obtention ? h('p', { class: 'ui cm-objet-f__obtention' }, icone('lu-search', 'bn-icone--s'), h('span', {}, o.obtention)) : null,
      vue.description?.trim() && vue.origine !== 'cree' ? h('figure', { class: 'bn-alire' },
        h('figcaption', { class: 'bn-alire__label' }, icone('livre', 'bn-icone--s'), 'Pour les joueurs'), h('p', {}, vue.description)) : null,
      o?.effets || o?.note_mj ? h('div', { class: 'cm-pour-mj' },
        h('p', { class: 'etiquette cm-pour-mj__titre' }, icone('lu-eye-off', 'bn-icone--s'), 'Pour le MJ, ne pas lire'),
        o.effets ? h('p', { class: 'ui' }, h('b', {}, 'Effets : '), o.effets) : null,
        o.note_mj ? h('p', { class: 'ui' }, o.note_mj) : null) : null,
      liensObjet(vue),
      blocOriginal(o?.original),
      blocBeyond(vue),
      blocDon(vue),
      blocIdentification(vue),
      blocDons(vue),
      o ? provenance(o) : null,
      piedFenetre(vue));
  }

  // Valeur : le coût en po (« estimée » quand la source n'en donne pas), sinon la valeur telle que l'annonce le livre.
  function valeurObjet(vue) {
    if (vue.cout != null) {
      const b = badge(`${vue.cout}${FINE}po${vue.coutEstime ? ' · estimée' : ''}`, 'soleil', 'piece');
      b.title = [vue.coutEstime ? 'Valeur estimée : la source ne donne pas de prix' : 'Valeur marchande d\'un exemplaire', vue.o?.valeur ? `Le livre : ${vue.o.valeur}` : null].filter(Boolean).join('\n');
      return b;
    }
    return vue.o?.valeur ? badge(vue.o.valeur, 'soleil', 'piece') : null;
  }

  // Liens vers la rencontre, le jalon, l'étape, le PNJ.
  function liensObjet(vue) {
    const r = vue.rattachement;
    const liens = [];
    if (r.rencontre) liens.push(h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Ouvrir la rencontre',
      onclick: () => import('./rencontres-mj.js').then(m => m.outilsRencontresMj({ donnees, etat, dialogue })).then(R => R.ouvrir(r.rencontre)) }, scenarisees.has(r.rencontre) ? `Rencontre « ${scenarisees.get(r.rencontre).nom} »` : 'La rencontre'));
    if (r.jalon && jalonParId.has(r.jalon)) liens.push(derouleSurLeTableau()
      ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Voir dans le déroulé', onclick: () => voirJalon(r.jalon) }, `Jalon « ${jalonParId.get(r.jalon).nom} »`)
      : h('span', { class: 'ui-s' }, `Jalon « ${jalonParId.get(r.jalon).nom} »`));
    if (r.etape && etapeParId.has(r.etape) && derouleSurLeTableau()) liens.push(h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => voirEtape(r.etape) }, `Étape ${etapeParId.get(r.etape).ordre} : ${etapeParId.get(r.etape).nom}`));
    if (r.pnj && pnjParId.has(r.pnj)) liens.push(h('span', { class: 'ui-s' }, `Porté ou donné par ${pnjParId.get(r.pnj).nom}`));
    return liens.length ? h('p', { class: 'cm-tenanciers' }, liens) : null;
  }

  // Quête personnelle d'un héros (badge violet : un clic ouvre sa fiche dans Personnages), et ce qu'un module de campagne
  // y ajoute (la place du Tarokka : emplacement objetLigne, app/modules.js).
  function lignesRattachement(vue, o) {
    const r = vue.rattachement;
    const p = r.personnage ? persoParId.get(r.personnage) : null;
    const modules = contributions('objetLigne', r, o);   // o : l'objet de objets.json, s'il en vient
    if (!r.personnage && !modules.length) return null;
    return h('p', { class: 'cm-objet-f__quete' },
      r.personnage ? [h('span', { class: 'etiquette' }, 'Quête personnelle'), p
        ? h('button', { type: 'button', class: 'bn-badge bn-badge--ultra cm-badge-pj', title: `Sa fiche, dans le widget Personnages`, onclick: () => ouvrirPerso(p.id) }, icone('lu-user'), nomPerso(p.id))
        : badge(r.personnage, 'ultra', 'lu-user')] : null,
      modules);
  }
  function ouvrirPerso(id) {
    const ev = new CustomEvent('cm:voir-personnage', { detail: { id, ouvert: false } });
    document.dispatchEvent(ev);
    if (!ev.detail.ouvert) annonce('Widget Personnages absent', `Ajoutez le widget Personnages au tableau pour ouvrir la fiche de ${nomPerso(id)}.`, 'brume');
  }

  // Objet créé par le MJ : nom (en français), genre, rattachement.
  function champsCreation(vue) {
    const e = vue.e;
    return h('div', { class: 'cm-prep__edition' },
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Nom'),
        h('input', { class: 'bn-input cm-objet-f__nom', value: e.nom || '', 'aria-label': 'Nom de l\'objet',
          onchange: ev => { e.nom = ev.target.value.trim() || 'Objet sans nom'; if (!recherches.get(vue.id)?.touchee) recherches.delete(vue.id); ev.target.blur(); enregistrer(); } })),
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Genre'),
        selection(Object.entries(GENRES).map(([k, [lib]]) => [k, lib]), e.genre || 'autre', val => { e.genre = val; enregistrer(); }, 'Genre de l\'objet')),
      h('label', { class: 'bn-champ cm-prep__plein' }, h('span', { class: 'bn-champ__label' }, 'Rattaché à'), choixRattachement(e)));
  }

  function selection(options, valeur, surChoix, etiquette) {
    const sel = h('select', { class: 'bn-select', 'aria-label': etiquette, onchange: ev => { ev.target.blur(); surChoix(ev.target.value); } },
      options.map(([val, lib]) => h('option', { value: val }, lib)));
    sel.value = valeur;
    return sel;
  }

  // Un lieu ou un sous-lieu, un jalon, une étape, une rencontre prévue : une liste à groupes.
  function choixRattachement(e) {
    const r = e.rattachement || {};
    const valeur = r.rencontre ? 'rencontre:' + r.rencontre : r.jalon ? 'jalon:' + r.jalon : r.etape ? 'etape:' + r.etape : r.lieu ? `lieu:${r.lieu}${r.sous_lieu ? '/' + r.sous_lieu : ''}` : '';
    const lieuxPrincipaux = [...lieux.values()].filter(l => !l.parent).sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));
    const sel = h('select', { class: 'bn-select', 'aria-label': 'Rattachement de l\'objet',
      onchange: ev => {
        ev.target.blur();
        const val = ev.target.value, genre = val.split(':')[0], reste = val.slice(val.indexOf(':') + 1);
        e.rattachement = genre === 'jalon' ? { jalon: reste } : genre === 'etape' ? { etape: reste } : genre === 'rencontre' ? { rencontre: reste, lieu: scenarisees.get(reste)?.lieu, sous_lieu: scenarisees.get(reste)?.sous_lieu }
          : genre === 'lieu' ? { lieu: reste.split('/')[0], sous_lieu: reste.split('/')[1] || undefined } : {};
        e.rattachement = Object.fromEntries(Object.entries(e.rattachement).filter(([, x]) => x));
        enregistrer();
      } },
    h('option', { value: '' }, 'Rien'),
    r.rencontre && !scenarisees.has(r.rencontre) ? h('option', { value: 'rencontre:' + r.rencontre }, 'Sa rencontre (créée par le MJ)') : null,
    h('optgroup', { label: 'Lieux' }, lieuxPrincipaux.flatMap(l => [h('option', { value: 'lieu:' + l.id }, l.nom),
      ...sousLieux(lieux, l.id).map(sl => h('option', { value: `lieu:${l.id}/${sl.id}` }, `${l.nom} – ${sl.nom}`))])),
    h('optgroup', { label: 'Jalons' }, [...(deroule?.jalons || [])].sort((a, b) => place(a.etape) - place(b.etape) || a.rang - b.rang)
      .map(j => h('option', { value: 'jalon:' + j.id }, `${etapeParId.get(j.etape)?.ordre ?? '?'}.${j.rang} ${j.nom}`))),
    h('optgroup', { label: 'Étapes' }, etapes.map(x => h('option', { value: 'etape:' + x.id }, `${x.ordre}. ${x.nom}`))),
    h('optgroup', { label: 'Rencontres prévues' }, [...scenarisees.values()].sort((a, b) => (ordreScen.get(a.id)?.rang ?? Infinity) - (ordreScen.get(b.id)?.rang ?? Infinity))
      .map(x => h('option', { value: 'rencontre:' + x.id }, x.nom))));
    sel.value = valeur;
    return sel;
  }

  // ───── D&D Beyond : l'objet du catalogue, ou un objet personnalisé ─────

  function blocBeyond(vue) {
    const titre = vue.personnalise ? 'Sur D&D Beyond : objet personnalisé' : 'Sur D&D Beyond';
    return section(titre, 'lu-box',
      vue.personnalise ? champsPersonnalise(vue) : vue.beyond && !recherches.get(vue.id)?.ouverte ? objetChoisi(vue) : blocRecherche(vue));
  }

  // L'objet du catalogue choisi : vignette, nom, résumé ; sa fiche au clic. Un objet générique (« Silvered Weapon ») ne
  // s'ajoute pas : ses variantes sont proposées (blocVariantes).
  function objetChoisi(vue) {
    const b = vue.beyond;
    return [
      b.ajoutable === false ? blocVariantes(vue) : null,
      h('div', { class: 'cm-recherche__ligne cm-objet-f__choisi' },
        vignette(b.avatar, b.nom),
        h('button', { type: 'button', class: 'cm-recherche__nom', title: 'Voir sa fiche D&D Beyond', onclick: () => ouvrirFicheBeyond(b.cle, vue.id) },
          h('span', { class: 'cm-recherche__titre' }, b.nom), h('span', { class: 'ui-s cm-sourdine' }, resumeBeyond(b))),
        h('span', { class: 'bn-groupe' },
          bouton('', { icone: 'lu-pencil', titre: 'Choisir un autre objet de D&D Beyond', classe: 'bn-btn--s bn-btn--fantome', onclick: () => { etatRecherche(vue).ouverte = true; rafraichirFenetres(vue.id); } }),
          bouton('', { icone: 'lu-x', titre: 'Ne plus le relier à D&D Beyond', classe: 'bn-btn--s bn-btn--fantome', onclick: () => { entree(vue.id, true).beyond = null; enregistrer(); } }))),
      b.auto ? h('p', { class: 'ui-s cm-sourdine' }, `Choisi d'office d'après le nom anglais « ${vue.nom_en} ».`) : null,
      champNomCatalogue(vue),
      champCommentaire(vue),
      h('div', { class: 'bn-groupe' }, bouton('Objet personnalisé à la place', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil',
        titre: 'Le donner comme objet personnalisé (nom, description, poids) plutôt que l\'objet de D&D Beyond', onclick: () => { entree(vue.id, true).personnalise = true; enregistrer(); } })),
    ];
  }

  // Variantes d'un objet générique (lues dans le catalogue) : celle de l'arme de base que nomment les données (`effets` :
  // « à partir d'une dague ») d'abord, et mise en avant. ✓ en choisit une.
  function blocVariantes(vue) {
    const zone = h('div', { class: 'cm-recherche__resultats' }, h('p', { class: 'ui-s cm-sourdine' }, 'Lecture des variantes…'));
    chargerCatalogue().then(c => {
      const o = c.parCle.get(vue.beyond.cle);
      const vs = o ? variantesDe(c, o) : [];
      const base = armeDeBase([vue.o?.effets, vue.o?.description, vue.nom, vue.commentaire].filter(Boolean).join(' '));
      const conseil = base ? vs.find(x => normaliser(x.nom).split(/[\s,()]+/).join(' ').includes(base)) : null;
      const ranges = conseil ? [conseil, ...vs.filter(x => x !== conseil)] : vs;
      zone.replaceChildren(...(vs.length ? [h('ul', { class: 'cm-recherche__liste' }, ranges.map(x => h('li', { class: 'cm-recherche__ligne' + (x === conseil ? ' est-actif' : '') },
        vignette(x.avatar, x.nom),
        h('button', { type: 'button', class: 'cm-recherche__nom', title: 'Voir sa fiche', onclick: () => ouvrirFicheBeyond(x.cle, vue.id) },
          h('span', { class: 'cm-recherche__titre' }, x.nom), h('span', { class: 'ui-s cm-sourdine' }, x === conseil ? 'D\'après les données · ' + resumeBeyond(x) : resumeBeyond(x))),
        bouton('', { icone: 'lu-check', classe: 'bn-btn--s bn-btn--primaire', titre: `Choisir ${x.nom}`, onclick: () => choisirBeyond(vue.id, x) }))))]
        : [h('p', { class: 'ui-s' }, 'Aucune variante dans le catalogue : choisissez un autre objet, ou donnez-le en objet personnalisé.')]));
    }, err => zone.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Catalogue de D&D Beyond injoignable', err.message)));
    return alerte('cierge', 'lu-triangle-alert', 'Objet générique : D&D Beyond ne l\'ajoute pas tel quel',
      h('p', { class: 'ui-s' }, `Choisissez sa variante${vue.o?.effets ? ` (${vue.o.effets.trim().replace(/\.$/, '')})` : ''}.`), zone);
  }

  // Nom de l'objet du catalogue dans l'inventaire D&D Beyond : le nom de la campagne d'office (nomCatalogue), modifiable
  // (`nom_beyond`), « Rétablir » ; « Garder le nom anglais » (`nom_beyond` vide) n'envoie aucun renommage.
  function champNomCatalogue(vue) {
    const anglais = vue.nomCatalogue === '';
    const majNom = val => {
      const e = entree(vue.id, true);
      delete e.nom_beyond;
      if (val !== null && val !== vueDe(vue.id).nomCatalogue) e.nom_beyond = val;
      enregistrer();
    };
    return h('div', { class: 'cm-objet-f__nom-beyond' },
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Nom sur D&D Beyond'),
        h('input', { class: 'bn-input', value: anglais ? '' : vue.nomCatalogue, placeholder: anglais ? vue.beyond.nom : '', disabled: anglais, 'aria-label': 'Nom de l\'objet dans l\'inventaire D&D Beyond',
          title: 'D&D Beyond le renomme ainsi dans l\'inventaire (« Customize », « Name »)', onchange: ev => majNom(ev.target.value.trim() || null) })),
      h('span', { class: 'bn-groupe' },
        h('label', { class: 'cm-case', title: 'Ne pas le renommer : il garde son nom de D&D Beyond' },
          h('input', { type: 'checkbox', class: 'bn-case', checked: anglais, onchange: ev => { const e = entree(vue.id, true); if (ev.target.checked) e.nom_beyond = ''; else delete e.nom_beyond; enregistrer(); } }),
          h('span', {}, 'Garder le nom anglais')),
        vue.nomCatalogueRetouche && !anglais ? bouton('Rétablir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Le nom de la campagne',
          onclick: () => { delete entree(vue.id, true).nom_beyond; enregistrer(); } }) : null));
  }

  // Commentaire : la note de l'objet sur D&D Beyond (« Notes » de l'objet dans l'inventaire).
  function champCommentaire(vue) {
    return h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Commentaire (note de l\'objet sur D&D Beyond)'),
      h('textarea', { class: 'bn-textarea', rows: 2, placeholder: 'Trouvé dans la crypte du vieux moulin, offert par le bourgmestre…',
        onchange: ev => { const e = entree(vue.id, true); if (ev.target.value.trim()) e.commentaire = ev.target.value.trim(); else delete e.commentaire; enregistrer(); } }, vue.commentaire));
  }

  // Objet personnalisé : nom (d'office celui que voient les joueurs, `nom_joueurs`), description pour les joueurs, commentaire,
  // poids en livres entières (D&D Beyond refuse les décimales). Pour un objet des données, chaque champ part de leur valeur ;
  // « Rétablir » efface les retouches.
  function champsPersonnalise(vue) {
    const e = () => entree(vue.id, true);
    const retouche = vue.o && ['nom', 'description', 'poids', 'cout'].some(k => vue.e?.[k] !== undefined);
    const deDonnees = cle => (cle === 'nom' ? vue.o.nom_joueurs ?? vue.o.nom : vue.o[cle]);
    const majChamp = (cle, val) => {
      if (vue.o && (val === (deDonnees(cle) ?? null) || (val === '' && !deDonnees(cle)))) delete e()[cle];
      else e()[cle] = val;
      enregistrer();
    };
    // Un nombre entier positif ou nul (vide : rien).
    const champEntier = (cle, libelle, valeur, aide) => h('label', { class: 'bn-champ cm-objet-f__poids', title: aide },
      h('span', { class: 'bn-champ__label' }, libelle),
      h('input', { class: 'bn-input', type: 'number', min: '0', step: '1', value: valeur == null ? '' : String(Math.round(valeur)), placeholder: '—', 'aria-label': `${libelle} (entier)`,
        onchange: ev => { const n = ev.target.value === '' ? null : Math.max(0, Math.round(Number(ev.target.value))); majChamp(cle, Number.isFinite(n) ? n : null); } }));
    return [
      vue.origine !== 'cree' ? h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, vue.o?.nom_joueurs ? 'Nom sur D&D Beyond (celui que voient les joueurs)' : 'Nom sur D&D Beyond'),
        h('input', { class: 'bn-input', value: vue.nomBeyond, 'aria-label': 'Nom de l\'objet sur D&D Beyond', onchange: ev => majChamp('nom', ev.target.value.trim() || deDonnees('nom') || '') })) : null,
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Description (pour les joueurs)'),
        h('textarea', { class: 'bn-textarea', rows: 3, placeholder: 'Ce que les héros voient ou lisent.', onchange: ev => majChamp('description', ev.target.value.trim()) }, vue.description)),
      champCommentaire(vue),
      h('div', { class: 'cm-objet-f__ligne' },
        champEntier('poids', 'Poids (lb)', vue.poids, 'Poids d\'un exemplaire, en livres entières (D&D Beyond refuse les décimales)'),
        champEntier('cout', vue.coutEstime ? 'Valeur (po, estimée)' : 'Valeur (po)', vue.cout, 'Valeur marchande d\'un exemplaire, en po : le coût de l\'objet sur D&D Beyond'),
        h('span', { class: 'bn-groupe' },
          retouche ? bouton('Rétablir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Reprendre le nom, la description, le poids et la valeur des données',
            onclick: () => { const x = e(); delete x.nom; delete x.description; delete x.poids; delete x.cout; enregistrer(); } }) : null,
          bouton('Chercher sur D&D Beyond', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-search', titre: 'Le relier à un objet du catalogue de D&D Beyond',
            onclick: () => { const x = e(); x.personnalise = false; etatRecherche(vue).ouverte = true; enregistrer(); } }))),
    ];
  }

  // Recherche dans le catalogue : le nom anglais d'office, résultats une fraction de seconde après la dernière touche.
  // Quand le nom anglais tombe juste (choixEvident), l'objet est choisi d'office, sauf si le MJ a déjà retiré le lien
  // (`beyond: null`), demandé un autre objet (✎, « Chercher sur D&D Beyond ») ou tapé dans la recherche.
  function blocRecherche(vue) {
    const rech = etatRecherche(vue);
    const resultats = h('div', { class: 'cm-recherche__resultats', 'aria-live': 'polite' }, h('p', { class: 'ui-s cm-sourdine' }, 'Chargement du catalogue de D&D Beyond…'));
    let minuterie = null;
    const auto = c => (!rech.touchee && !rech.ouverte && vue.e?.beyond !== null && vue.nom_en ? choixEvident(c, vue.nom_en) : null);
    const majResultats = () => chargerCatalogue().then(c => {
      const o = auto(c);
      if (o) { choisirBeyond(vue.id, o, { auto: true }); rafraichirFenetres(vue.id); return; }
      resultats.replaceChildren(...vueResultats(vue, c, rech));
    },
      err => resultats.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Catalogue de D&D Beyond injoignable', err.message, ' ',
        bouton('Réessayer', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', onclick: () => { resultats.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Chargement…')); majResultats(); } }))));
    const champ = h('input', { class: 'bn-input cm-recherche__champ', type: 'search', value: rech.texte, placeholder: 'Nom anglais : potion of healing, rope, longsword…', 'aria-label': 'Chercher un objet de D&D Beyond',
      oninput: ev => { rech.texte = ev.target.value; rech.touchee = true; rech.nombre = PAR_PAGE; clearTimeout(minuterie); minuterie = setTimeout(majResultats, ATTENTE_RECHERCHE); } });
    const magiques = h('label', { class: 'cm-case', title: 'Seulement les objets magiques' },
      h('input', { type: 'checkbox', class: 'bn-case', checked: rech.magiques, onchange: ev => { rech.magiques = ev.target.checked; majResultats(); } }), h('span', {}, 'Magiques'));
    majResultats();
    return [
      vue.o?.beyond === false ? h('p', { class: 'ui-s cm-sourdine' }, 'Les données disent qu\'il n\'existe pas sur D&D Beyond : cherchez un équivalent, ou gardez l\'objet personnalisé.') : null,
      h('div', { class: 'cm-recherche__filtres cm-objet-f__filtres' }, champ, magiques),
      resultats,
      h('div', { class: 'bn-groupe' },
        vue.beyond ? bouton('Garder le choix', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', onclick: () => { rech.ouverte = false; rafraichirFenetres(vue.id); } }) : null,
        bouton('Objet personnalisé', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', titre: 'Lettre, clé, trésor unique… : nom, description et poids à votre guise',
          onclick: () => { entree(vue.id, true).personnalise = true; rech.ouverte = false; enregistrer(); } })),
    ];
  }

  function vueResultats(vue, c, rech) {
    const trouves = chercher(c, rech.texte, { magiques: rech.magiques });
    const nb = c.liste.filter(dansLesLivres).length;
    if (!trouves) return [h('p', { class: 'ui-s cm-sourdine' }, `${nb} objets dans vos livres (${livres().liste.map(x => x[1]).join(', ')}${livres().partenaires ? ', partenaires' : ''}${livres().homebrew ? ', homebrews' : ''}). Tapez un nom anglais.`)];
    if (!trouves.length) return [h('p', { class: 'ui-s cm-sourdine' }, 'Aucun objet ne correspond dans vos livres. Essayez un autre mot, ou gardez un objet personnalisé.')];
    const affiches = trouves.slice(0, rech.nombre);
    return [
      h('ul', { class: 'cm-recherche__liste' }, affiches.map(o => h('li', { class: 'cm-recherche__ligne' + (vue.beyond?.cle === o.cle ? ' est-actif' : '') },
        vignette(o.avatar, o.nom),
        h('button', { type: 'button', class: 'cm-recherche__nom', title: 'Voir sa fiche', onclick: () => ouvrirFicheBeyond(o.cle, vue.id) },
          h('span', { class: 'cm-recherche__titre' }, o.nom), h('span', { class: 'ui-s cm-sourdine' }, resumeBeyond(o))),
        bouton('', { icone: 'lu-check', classe: 'bn-btn--s bn-btn--primaire', titre: `Choisir ${o.nom} pour « ${vue.nom} »`, onclick: () => choisirBeyond(vue.id, o) })))),
      trouves.length > affiches.length ? h('div', { class: 'bn-groupe' }, bouton(`Afficher plus (${trouves.length - affiches.length} de plus)`, { classe: 'bn-btn--s bn-btn--fantome',
        onclick: () => { rech.nombre += PAR_PAGE; rafraichirFenetres(vue.id); } })) : null,
    ].filter(Boolean);
  }

  // Le choix garde de quoi afficher l'objet sans relire le catalogue. auto : choisi d'office d'après le nom anglais.
  function choisirBeyond(id, o, { auto = false } = {}) {
    const e = entree(id, true);
    e.beyond = { cle: o.cle, id: o.id, type: o.type, nom: o.nom, genre: o.genre, rarete: o.rarete, magique: o.magique, harmonisation: o.harmonisation,
      poids: o.poids, avatar: o.avatar, sigle: o.sigle, legacy: o.legacy, ...(o.ajoutable === false ? { ajoutable: false } : {}), ...(auto ? { auto: true } : {}) };
    e.personnalise = false;
    const r = recherches.get(id);
    if (r) r.ouverte = false;
    enregistrer();
  }

  // Fiche d'un objet de D&D Beyond (texte en paragraphes) ; pour : objet du gestionnaire auquel le choisir.
  async function ouvrirFicheBeyond(cle, pour = null) {
    try {
      const [f] = await fichesObjets([cle]);
      if (!f) return annonce('Objet introuvable', 'Il n\'est plus dans le catalogue de D&D Beyond.');
      const vue = pour ? vueDe(pour) : null;
      flottant('beyond-objet:' + cle, { surtitre: 'Objet · D&D Beyond', titre: f.nom, largeur: 520, contenu: [
        h('div', { class: 'cm-objet-b' },
          f.image ? h('img', { class: 'cm-objet-b__image', src: f.image, alt: '', referrerpolicy: 'no-referrer' }) : null,
          h('div', { class: 'cm-pile' },
            h('p', { class: 'ui' }, [f.typeLibelle || f.genre, f.magique ? rareteVf(f.rarete) : null].filter(Boolean).join(' · ')),
            f.harmonisation ? h('p', { class: 'ui-s' }, 'Harmonisation requise' + (f.harmonisationTexte ? ` ${f.harmonisationTexte}` : '')) : null,
            h('p', { class: 'ui-s cm-sourdine' }, [f.ca ? `CA ${f.ca}` : null, f.degats ? `${f.degats} ${f.degatsType || ''}`.trim() : null, f.proprietes?.length ? f.proprietes.join(', ') : null,
              livresLb(f.poids || null), f.cout ? `${f.cout} po` : null, f.sigle || fichesSigle(f), f.legacy ? '2014' : null].filter(Boolean).join(' · ')))),
        h('div', { class: 'cm-objet-b__texte' }, texteBeyond(f.description)),
        vue ? h('div', { class: 'bn-groupe' }, bouton(`Choisir pour « ${vue.nom} »`, { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check',
          onclick: () => chargerCatalogue().then(c => { const o = c.parCle.get(cle); if (o) choisirBeyond(pour, o); flottantOuvert('beyond-objet:' + cle)?.fermer(); }) })) : null,
      ].filter(Boolean) });
    } catch (err) { annonce('D&D Beyond injoignable', err.message); }
  }
  const fichesSigle = f => (f.homebrew ? 'Homebrew' : f.sources.map(id => livres().sigle.get(id)).filter(Boolean).join(', ') || null);

  // ───── Donner ─────

  const choixDon = new Map();   // id d'objet -> { a, quantite, beyond, ouvert }

  // À qui (un héros ou le groupe), combien, et s'il part sur D&D Beyond. Une quantité en dés (« 2d4 ») se lance d'abord.
  // Le nombre n'est pas borné par ce qui reste (demande du MJ, 2026-10-30) : en donner plus augmente le nombre d'exemplaires
  // de l'objet (`quantite` de etat/objets.json) ; un objet déjà donné en entier se donne encore (« Donner encore », replié).
  const MAX_DON = 99;
  function blocDon(vue) {
    const c = choixDon.get(vue.id) || { a: vue.o?.personnage && persoParId.has(vue.o.personnage) ? vue.o.personnage : 'groupe', quantite: null, beyond: true };
    choixDon.set(vue.id, c);
    const quantite = Math.min(MAX_DON, c.quantite ?? (vue.reste || 1));
    const options = [...heros.map(p => [p.id, p.nom_court || p.nom, 'lu-user']), ['groupe', 'Groupe', 'lu-users']];
    const etat = h('div', { 'aria-live': 'polite' });
    const generique = !vue.personnalise && vue.beyond?.ajoutable === false;
    const sansNom = vue.personnalise ? !vue.nomBeyond.trim() : !vue.beyond || generique;
    const btn = bouton(c.beyond ? 'Donner sur D&D Beyond' : 'Noter le don', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-gift', disabled: sansNom && c.beyond,
      titre: sansNom && c.beyond ? (generique ? 'Objet générique : choisissez d\'abord sa variante' : 'Choisissez d\'abord l\'objet de D&D Beyond, ou passez en objet personnalisé') : null,
      onclick: async () => {
        btn.disabled = true;
        etat.replaceChildren(...(c.beyond ? [h('p', { class: 'ui-s cm-sourdine' }, 'Ajout dans D&D Beyond…')] : []));
        try {
          const n = Math.min(MAX_DON, c.quantite ?? (vue.reste || 1));   // le nombre saisi au moment du clic
          const r = c.beyond ? await ajouterABeyond(vue, c.a, n) : null;
          const e = entree(vue.id, true);
          if (vue.quantite != null && n > vue.reste) e.quantite = String(vue.donne + n);   // plus que prévu : l'objet en a plus
          e.dons.push({ a: c.a, quantite: n, ...quandMaintenant(), ...(r ? { beyond: infosBeyond(r, !vue.personnalise) } : {}) });
          choixDon.delete(vue.id);
          enregistrer();
          if (r) signalerNom(vue, r);
        } catch (err) {
          etat.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Pas ajouté à D&D Beyond', err.message, ' ', 'Décochez « Sur D&D Beyond » pour noter le don quand même.'));
          btn.disabled = false;
        }
      } });
    const champQte = vue.quantite == null
      ? bouton(vue.formule, { classe: 'bn-btn--s', icone: 'd20', titre: `Lancer ${vue.formule} : combien en trouvent-ils ?`, onclick: ev => {
        const j = lancerVisible(vue.formule, { legende: `Combien : ${vue.nom}`, depuis: ev.currentTarget });
        if (j) { entree(vue.id, true).quantite = Math.max(1, j.total); enregistrer(); }
      } })
      : h('label', { class: 'cm-objet-f__qte' }, h('span', { class: 'ui-s cm-sourdine' }, 'Nombre'),
        h('input', { class: 'bn-input', type: 'number', min: '1', max: String(MAX_DON), value: String(quantite), 'aria-label': 'Nombre à donner',
          onchange: ev => { c.quantite = Math.min(MAX_DON, Math.max(1, parseInt(ev.target.value, 10) || 1)); ev.target.value = String(c.quantite); } }));
    const contenu = [
      bascule('À qui', options, c.a, val => { c.a = val; rafraichirFenetres(vue.id); }, { repliable: true }),
      h('div', { class: 'cm-objet-f__don' },
        champQte,
        h('label', { class: 'cm-case', title: 'Ajouter l\'objet à l\'inventaire D&D Beyond du héros, ou à celui du groupe (party). Par l\'extension Chrome.' },
          h('input', { type: 'checkbox', class: 'bn-case', checked: c.beyond, onchange: ev => { c.beyond = ev.target.checked; rafraichirFenetres(vue.id); } }), h('span', {}, 'Sur D&D Beyond')),
        vue.quantite == null ? null : btn),
      etat];
    if (vue.reste !== 0) return section(vue.donne ? `Donner le reste (${vue.reste ?? '?'})` : 'Donner', 'lu-gift', ...contenu);
    return h('details', { class: 'cm-repli', open: !!c.ouvert, ontoggle: ev => { c.ouvert = ev.currentTarget.open; } },
      h('summary', { class: 'etiquette' }, icone('lu-gift', 'bn-icone--s'), ' Donner encore'), ...contenu);
  }

  // Objet donné en objet personnalisé sous son nom pour les joueurs (`nom_joueurs`) : une fois identifié par les héros,
  // l'objet de D&D Beyond (choisi d'après `nom_en`) va aux mêmes mains ; l'objet personnalisé est à retirer de la fiche.
  function blocIdentification(vue) {
    if (!vue.aIdentifier) return null;
    const perso = vue.dons.filter(x => x.beyond && !x.beyond.catalogue);
    const pret = !vue.personnalise && vue.beyond && vue.beyond.ajoutable !== false;
    const etat = h('div', { 'aria-live': 'polite' });
    const btn = bouton(pret ? `Identifié : donner ${vue.beyond.nom}` : 'Identifié : choisir l\'objet de D&D Beyond', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-sparkles',
      titre: pret ? `L'objet de D&D Beyond, à ${[...new Set(perso.map(x => nomPerso(x.a)))].join(', ')}` : `Chercher « ${vue.nom_en} » dans le catalogue`,
      onclick: async () => {
        const e = entree(vue.id, true);
        if (!pret) { e.personnalise = false; etatRecherche(vue).ouverte = !vue.beyond; enregistrer(); return; }
        btn.disabled = true;
        etat.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Ajout dans D&D Beyond…'));
        try {
          for (const x of perso) {
            // Identifié : le nom de la campagne (jamais `nom_joueurs`), ou celui que le MJ a saisi.
            const r = await ajouterABeyond(vue, x.a, x.quantite || 1, { catalogue: true, nom: vue.e?.nom_beyond ?? vue.nom });
            e.dons.push({ a: x.a, quantite: x.quantite || 1, identification: true, ...quandMaintenant(), beyond: infosBeyond(r, true) });
            signalerNom(vue, r);
          }
          enregistrer();
          annonce('Objet identifié', `Retirez « ${vue.nomBeyond} » (objet personnalisé) de l'inventaire D&D Beyond ${perso.map(x => (x.a === 'groupe' ? 'du groupe' : `de ${nomPerso(x.a)}`)).join(', ')}.`, 'brume');
        } catch (err) {
          etat.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Pas ajouté à D&D Beyond', err.message));
          btn.disabled = false;
        }
      } });
    return section('Identifié par les héros ?', 'lu-sparkles',
      h('p', { class: 'ui-s cm-sourdine' }, `Donné en objet personnalisé, « ${vue.nomBeyond} ». Une fois identifié, l'objet de D&D Beyond va aux mêmes mains.`),
      h('div', { class: 'bn-groupe' }, btn), etat);
  }

  // Ce qu'un don garde de l'objet ajouté : son id dans l'inventaire et son entityTypeId (pour le renommer plus tard), le nom
  // donné à un objet du catalogue.
  const infosBeyond = (r, catalogue) => ({ objet: r.id, type: r.entityTypeId ?? null, catalogue, ...(catalogue && r.nomBeyond && r.nomEcrit === true ? { nom: r.nomBeyond } : {}) });
  // Objet du catalogue ajouté mais pas renommé (extension d'avant 1.9.0, ou refus de D&D Beyond) : à faire à la main.
  function signalerNom(vue, r) {
    if (r.nomBeyond && r.nomEcrit !== true) annonce('Objet donné, pas renommé', `Il garde son nom anglais sur D&D Beyond : renommez-le à la main sur la fiche (« Customize », « Name ») en « ${r.nomBeyond} »${r.nomEcrit === undefined ? ', ou rechargez l\'extension (version 1.9.0)' : ''}.`);
  }

  // Fiche D&D Beyond qui reçoit l'objet : celle du héros ; pour le groupe, celle d'un membre (l'objet va dans l'inventaire
  // du groupe de la campagne).
  async function cibleBeyond(a) {
    const beyond = await lireBeyond();
    if (a === 'groupe') {
      const membre = Object.keys(beyond.fiches || {})[0];
      if (membre && beyond.campagne?.id) return { personnage: membre, groupe: true, campagne: beyond.campagne.id };
    } else {
      const f = persoParId.has(a) ? ficheDe(persoParId.get(a), beyond) : null;
      if (f) return { personnage: f.id, groupe: false };
    }
    throw new Error(a === 'groupe' ? 'Campagne D&D Beyond pas encore relevée par l\'extension.' : `Fiche D&D Beyond de ${nomPerso(a)} introuvable dans les relevés de l'extension.`);
  }

  // catalogue : l'objet de D&D Beyond même si l'objet est donné en personnalisé (identification) ; nom : celui de l'objet du
  // catalogue dans l'inventaire (vide : son nom anglais). Rend la réponse de l'extension, plus nomBeyond (le nom demandé).
  async function ajouterABeyond(vue, a, quantite, { catalogue = !vue.personnalise, nom = vue.nomCatalogue } = {}) {
    const cible = await cibleBeyond(a);
    const commun = { type: 'objet', ...cible, quantite, note: vue.commentaire || '' };
    const entier = x => (x == null ? null : Math.max(0, Math.round(x)));
    try {
      const r = await demanderExtension(catalogue
        ? { ...commun, definition: { id: vue.beyond.id, type: vue.beyond.type }, nomBeyond: nom || '' }
        : { ...commun, nom: vue.nomBeyond, description: vue.description || '', poids: entier(vue.poids), cout: entier(vue.cout) });
      return { ...r, nomBeyond: catalogue ? nom || '' : '' };
    } catch (e) {   // extension d'avant 1.8.0 : elle ne connaît ni les objets du catalogue ni le poids
      throw /Demande inconnue|Objet sans nom/.test(e.message) ? new Error('L\'extension ne sait pas encore donner ces objets : rechargez-la dans chrome://extensions (version 1.9.0).') : e;
    }
  }

  // « Renommer sur D&D Beyond » : le nom actuel (nomCatalogue ; vide : le nom anglais revient) sur les exemplaires du catalogue
  // déjà donnés, d'après l'id gardé par chaque don.
  async function renommerDons(vue, bouton) {
    const dons = vue.dons.filter(x => x.beyond?.catalogue && x.beyond.objet);
    bouton.disabled = true;
    const echecs = [];
    for (const x of dons) {
      try {
        await demanderExtension({ type: 'renommer', ...(await cibleBeyond(x.a)), objet: x.beyond.objet, typeObjet: x.beyond.type || null, nom: vue.nomCatalogue });
        x.beyond.nom = vue.nomCatalogue;
      } catch (e) {
        echecs.push(`${nomPerso(x.a)} : ${/Demande inconnue/.test(e.message) ? 'rechargez l\'extension (version 1.9.0)' : e.message}`);
      }
    }
    enregistrer();
    if (echecs.length) annonce('Pas renommé sur D&D Beyond', echecs.join(' · '));
    else annonce('Renommé sur D&D Beyond', vue.nomCatalogue ? `« ${vue.nomCatalogue} »` : 'Il reprend son nom anglais.', 'brume');
  }

  // Dons déjà faits : à qui, combien, quand ; « Annuler » ne retire que la note (l'inventaire D&D Beyond reste à corriger).
  function blocDons(vue) {
    if (!vue.dons.length) return null;
    const duCatalogue = vue.dons.filter(x => x.beyond?.catalogue && x.beyond.objet);
    // Un nom à mettre à jour : un exemplaire du catalogue qui ne porte pas le nom actuel.
    const aRenommer = duCatalogue.some(x => (x.beyond.nom ?? '') !== vue.nomCatalogue);
    return section('Donné', 'lu-check', h('ul', { class: 'cm-objet-f__dons' }, vue.dons.map((x, i) => h('li', {},
      h('span', {}, h('b', {}, nomPerso(x.a).replace(/^le g/, 'Le g')), x.quantite > 1 ? ` ×${x.quantite}` : '', h('span', { class: 'ui-s cm-sourdine' }, ` · ${libelleQuand(x)}`),
        x.identification ? badge('Identifié', 'ultra', 'lu-sparkles') : null,
        x.beyond ? badge(x.beyond.catalogue ? 'D&D Beyond' : 'D&D Beyond, personnalisé', 'brume', 'lu-check') : h('span', { class: 'ui-s cm-sourdine' }, ' · noté seulement'),
        x.beyond?.catalogue && x.beyond.nom ? h('span', { class: 'ui-s cm-sourdine' }, ` · « ${x.beyond.nom} »`) : null,
        x.retrait ? alerteRetrait(vue, x, i) : null),
      x.retrait ? null : bouton('', { icone: 'lu-rotate-ccw', titre: x.beyond ? 'Annuler ce don : demander d\'abord aux joueurs de retirer l\'objet de leur inventaire D&D Beyond' : 'Annuler ce don',
        classe: 'bn-btn--s bn-btn--fantome', onclick: () => annulerDon(vue, x, i) })))),
    duCatalogue.length ? h('div', { class: 'bn-groupe' }, bouton('Renommer sur D&D Beyond', { classe: 'bn-btn--s' + (aRenommer ? '' : ' bn-btn--fantome'), icone: 'lu-pencil',
      titre: vue.nomCatalogue ? `Les exemplaires déjà donnés prennent le nom « ${vue.nomCatalogue} »` : 'Les exemplaires déjà donnés reprennent leur nom anglais',
      onclick: ev => renommerDons(vue, ev.currentTarget) })) : null);
  }

  // Annuler un don (décision du MJ, 2026-10-23) : rien n'est retiré d'office de D&D Beyond, les héros ont pu s'échanger
  // l'objet. Un don arrivé sur D&D Beyond passe d'abord « retrait demandé » (`retrait`) : le MJ demande aux joueurs de le
  // retirer de leur inventaire, attend leur réponse, puis confirme. Un don seulement noté s'annule tout de suite.
  function annulerDon(vue, x, i) {
    if (!x.beyond) {
      if (!confirm(`Annuler le don à ${nomPerso(x.a)} ?`)) return;
      vue.e.dons.splice(i, 1);
    } else x.retrait = quandMaintenant();
    enregistrer();
  }
  function alerteRetrait(vue, x, i) {
    const nom = x.beyond?.nom || (x.beyond?.catalogue ? vue.beyond?.nom : vue.nomBeyond) || vue.nom;
    const chez = x.a === 'groupe' ? 'l\'inventaire du groupe' : `l'inventaire de ${nomPerso(x.a)}`;
    return alerte('cierge', 'lu-triangle-alert', 'Annulation en attente des joueurs',
      `Demandez aux joueurs de retirer « ${nom} »${x.quantite > 1 ? ` (×${x.quantite})` : ''} de ${chez} sur D&D Beyond (ou du héros qui l'a maintenant). Une fois fait, confirmez.`, ' ',
      h('span', { class: 'bn-groupe' },
        bouton('C\'est fait : annuler le don', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check', onclick: () => { vue.e.dons.splice(i, 1); enregistrer(); } }),
        bouton('Garder le don', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { delete x.retrait; enregistrer(); } })));
  }

  function piedFenetre(vue) {
    if (vue.origine === 'donnees') return null;
    return h('div', { class: 'bn-groupe cm-prep__pied' }, bouton('Supprimer', { classe: 'bn-btn--s bn-btn--danger', icone: 'lu-trash-2', onclick: () => supprimer(vue.id) }));
  }
  function supprimer(id) {
    const vue = vueDe(id);
    if (!vue || !confirm(`Supprimer l'objet « ${vue.nom} » du gestionnaire ?${vue.dons.some(x => x.beyond) ? ' Ce qui a été donné sur D&D Beyond y reste.' : ''}`)) return;
    delete v().objets[id];
    flottantOuvert('objet:' + id)?.fermer();
    ouvertes.delete(id);
    enregistrer();
  }

  function annonce(titre, texte, couleur = 'cierge') {
    document.dispatchEvent(new CustomEvent('cm:annonce', { detail: { cle: 'objets-' + titre, titre, texte, icone: 'lu-triangle-alert', couleur } }));
  }

  return {
    s, v, d, vueDe, ouDe, tous, duLieu, duJalon, deLEtape, deLaRencontre,
    ligne, liste, boutonNouveau, nouveau, ouvrir, nomPerso, libelleQuand, enAttente, avantDeTerminer, donneesPresentes: !!d,
  };
}
