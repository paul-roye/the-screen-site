// Calcul des temps de voyage (règle du MJ, formats/temps-de-voyage.md), partagé par les widgets Trajets et Déroulé :
// temps = miles / vitesse, doublé en terrain difficile ; une journée = 8 heures de marche.
// Vitesse : miles par jour du rythme (regles[].miles_par_jour de temps-de-voyage.json), + monture, / 8 heures.

import { h, infobulle, FINE } from './ui.js';

export const KM_PAR_MILE = 1.609344;
export const HEURES_PAR_JOUR = 8;
const MILES_PAR_JOUR_NORMAL = 24;

export const nombre = (n, decimales = 1) => n.toLocaleString('fr-FR', { maximumFractionDigits: decimales });

export const enMiles = miles => `${nombre(miles)}${FINE}mile${miles > 1 ? 's' : ''}`;

// Miles convertis en km : au-delà de 5 km, arrondi au km (« ~26 km ») ; les miles font foi.
export function enKm(miles) {
  const km = miles * KM_PAR_MILE;
  return km > 5 ? `~${Math.round(km)}${FINE}km` : `${nombre(km)}${FINE}km`;
}

// Distance de voyage dans l'unité choisie, l'autre unité en infobulle ; note : décision du MJ sur cette distance.
export function distanceVoyage(miles, { unite = 'miles', note = null } = {}) {
  const [vue, autre] = unite === 'km' ? [enKm(miles), enMiles(miles)] : [enMiles(miles), enKm(miles)];
  return infobulle(h('span', { class: 'cm-distance' }, vue), note ? `${note} (${autre})` : autre, { titre: note ? 'Distance fixée par le MJ' : null });
}

export function enHeures(min) {
  const m = Math.round(min), hh = Math.floor(m / 60), mm = m % 60;
  return hh ? (mm ? `${hh} h ${String(mm).padStart(2, '0')}` : `${hh} h`) : `${mm} min`;
}

// 1 340 min -> « 2 j + 6 h 20 » (journées de 8 heures de marche)
export function enJours(min) {
  const jour = HEURES_PAR_JOUR * 60;
  const j = Math.floor(Math.round(min) / jour), reste = Math.round(min) - j * jour;
  if (!j) return enHeures(reste);
  return reste ? `${j} j + ${enHeures(reste)}` : `${j} j`;
}

// Rythmes de marche, pour bascule() de app/ui.js : valeur, libellé, icône (à pas de loup, en marche, en course).
export const RYTHMES = [['lent', 'Lent', 'lu-allure-lente'], ['normal', 'Normal', 'lu-allure-normale'], ['rapide', 'Rapide', 'lu-allure-rapide']];

// Règles de vitesse lues dans temps-de-voyage.json : { lent, normal, rapide } en miles par jour, bonus de monture.
export function vitessesDe(d) {
  const regle = id => d?.regles?.find(r => r.id === id);
  return {
    parJour: {
      lent: regle('rythme-lent')?.miles_par_jour,
      normal: regle('journee')?.miles_par_jour || MILES_PAR_JOUR_NORMAL,
      rapide: regle('rythme-rapide')?.miles_par_jour,
    },
    bonusMonture: regle('monture')?.miles_en_plus,
  };
}

// Miles par heure de marche au rythme choisi.
export function milesParHeure(vitesses, rythme = 'normal', monture = false) {
  return ((vitesses.parJour[rythme] || vitesses.parJour.normal) + (monture ? (vitesses.bonusMonture || 0) : 0)) / HEURES_PAR_JOUR;
}

// Minutes de marche pour un trajet { miles, terrain_difficile }.
export function minutesTrajet(t, mph) {
  return t.miles / mph * 60 * (t.terrain_difficile ? 2 : 1);
}

// Lieux traversés par une suite de trajets [{ de, vers }] (chacun se parcourt dans un sens ou dans l'autre),
// en partant de `de` et en arrivant à `vers` s'ils sont donnés : [lieu, lieu, …], ou null si les trajets ne se suivent pas.
export function enchainer(trajets, de, vers) {
  if (!trajets.length) return null;
  const departs = de ? [de] : [trajets[0].de, trajets[0].vers];
  for (const depart of departs) {
    const lieux = [depart];
    let ici = depart;
    for (const t of trajets) {
      if (t.de === ici) ici = t.vers; else if (t.vers === ici) ici = t.de; else { ici = null; break; }
      lieux.push(ici);
    }
    if (ici && (!vers || ici === vers)) return lieux;
  }
  return null;
}

// Itinéraire le plus court en temps de marche entre deux lieux du réseau des trajets (temps-de-voyage.json) :
// [de, …, vers], ou null s'ils ne sont pas reliés. Pour préparer un trajet dans le widget Trajets.
export function cheminLePlusCourt(trajets, de, vers, mph) {
  if (!de || !vers) return null;
  if (de === vers) return [de];
  const voisins = new Map();
  for (const t of trajets) {
    for (const [a, b] of [[t.de, t.vers], [t.vers, t.de]]) {
      if (!voisins.has(a)) voisins.set(a, []);
      voisins.get(a).push([b, minutesTrajet(t, mph)]);
    }
  }
  const dist = new Map([[de, 0]]), prec = new Map(), faits = new Set();
  for (;;) {
    let u = null;
    for (const [n, x] of dist) if (!faits.has(n) && (u === null || x < dist.get(u))) u = n;
    if (u === null) return null;
    if (u === vers) break;
    faits.add(u);
    for (const [w, c] of voisins.get(u) || []) {
      if (!dist.has(w) || dist.get(u) + c < dist.get(w)) { dist.set(w, dist.get(u) + c); prec.set(w, u); }
    }
  }
  const chemin = [vers];
  while (chemin[0] !== de) chemin.unshift(prec.get(chemin[0]));
  return chemin;
}

// Totaux d'une suite de trajets : { miles, minutes, difficile }.
export function totaux(trajets, mph) {
  return {
    miles: trajets.reduce((a, t) => a + t.miles, 0),
    minutes: trajets.reduce((a, t) => a + minutesTrajet(t, mph), 0),
    difficile: trajets.some(t => t.terrain_difficile),
  };
}
