// Lecture de wiki/wiki.json (formats/wiki.md), écrit par l'import du wiki et qui peut manquer. L'import est une source
// pour l'IA de la campagne (wiki-complet.md), pas pour le gestionnaire : il n'en lit que les portraits, en attendant que
// personnages.json ait les siens (`portrait`), et le contrôle des liens du bouton Données.

import { wikiActif } from './campagne.js';

let promesse = null;

// null si la campagne n'a pas de wiki (`wiki.url` du manifeste, facultatif) : rien n'est lu dans wiki/.
export function chargerWiki() {
  if (!wikiActif()) return Promise.resolve(null);
  promesse ||= fetch('wiki/wiki.json', { cache: 'no-store' })
    .then(r => (r.ok ? r.json() : null))
    .catch(() => null)
    .then(w => (w ? { ...w, parId: new Map((w.pages || []).map(p => [p.id, p])) } : null));
  return promesse;
}

// Chemin d'un portrait téléchargé par l'import (wiki/images/…), ou null.
export function portraitDe(wiki, idPage) {
  const f = wiki?.parId.get(idPage)?.portrait?.fichier;
  return f ? 'wiki/' + f : null;
}

// Portrait d'un personnage de personnages.json : son `portrait` (chemin depuis le dossier de la campagne, ou adresse),
// sinon celui que l'import du wiki a téléchargé, sinon `repli` (l'avatar de la fiche D&D Beyond), sinon null.
export function portraitDuPersonnage(p, wiki, repli = null) {
  return p?.portrait || portraitDe(wiki, p?.liens?.wiki?.id) || repli || null;
}
