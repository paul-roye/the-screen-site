// Menu rapide : une colonne d'icônes posée sur le bord gauche de la page, par-dessus le tableau, dans les deux modes.
// Replié, il ne dépasse que d'une languette (dans la marge de la page) ; au survol (ou au clavier) il se déploie en entier.
// Haut de la page, récapitulatif du groupe (Personnages), carte des trajets agrandie (Trajets), tirage des rencontres en
// fenêtre (Rencontres), tirage d'une babiole dans l'une des tables (app/babioles.js), dés en fenêtre (le widget Dés lui-même,
// qui partage etat/des.json avec celui du tableau). Les widgets répondent aux événements document `cm:voir-groupe`,
// `cm:voir-carte` et `cm:voir-tirage` (detail.ouvert passé à vrai) : montés, même réduits ou dans l'autre mode ; sinon une
// annonce dit lequel ajouter. La poignée du haut le glisse de haut en bas ; sa place est gardée dans le navigateur (propre
// au poste). Disposition du tableau verrouillée (`verrouiller()` de l'objet rendu) : poignée cachée, le menu reste où il est.

import { h, icone, bouton, boutonMenu, flottant, flottantOuvert } from './ui.js';
import { annoncer } from './horloge.js';
import { fichesBabioles } from './babioles.js';
import { chargerCarte } from './carte.js';
import des from './widgets/des.js';
import { LARGEURS, debogageActif, largeurSimulee, simulerLargeur, surDebogage } from './debogage.js';

const CLE_PLACE = 'cm:menu-rapide:haut';   // haut du menu, en fraction de la hauteur de la fenêtre
const MARGE = 8;

// Demande à un widget d'ouvrir quelque chose ; personne n'a répondu : il n'est pas monté.
function demander(evenement, widget) {
  const detail = { ouvert: false };
  document.dispatchEvent(new CustomEvent(evenement, { detail }));
  if (!detail.ouvert) annoncer({ cle: 'menu-rapide', titre: `Ajoutez le widget ${widget} au tableau`, icone: 'lu-info', couleur: 'brume',
    texte: `Ce raccourci passe par lui (dans l'un des deux modes, même réduit).` });
}

// Un menu ouvert à droite de son bouton, à sa hauteur (le menu rapide est collé au bord gauche).
function aDroite(btn, menu) {
  const r = btn.getBoundingClientRect(), m = menu.getBoundingClientRect();
  Object.assign(menu.style, { left: Math.round(r.right + 6) + 'px', top: Math.round(Math.min(r.top, innerHeight - m.height - MARGE)) + 'px' });
}

export function monterMenuRapide({ donnees, etat, dialogue }) {
  const raccourci = (ic, titre, onclick) => bouton('', { icone: ic, titre, classe: 'bn-btn--fantome cm-menu-rapide__btn', onclick });

  // Babioles : un choix par table de babioles.json, avec son nom (« Avancées », « Basiques », « Joueurs »).
  const btnBabiole = raccourci('cle', 'Tirer une babiole', () => {});
  const zoneBabiole = h('div', { class: 'cm-menu-rapide__sous' }, btnBabiole);
  fichesBabioles({ donnees, etat, dialogue }).then(fb => {
    if (!fb?.tables.length) { zoneBabiole.hidden = true; return; }   // pas de babioles dans cette campagne
    const [, menu] = boutonMenu(btnBabiole, fb.tables.map(t => [t.nom, `Tirer dans « ${t.nom} » (${t.de})`, () => {
      if (!fb.tirerDans(t.id)) annoncer({ cle: 'menu-rapide', titre: `Rien à tirer dans « ${t.nom} »`, icone: 'cle', couleur: 'cierge',
        texte: t.lignes.every(l => l.a_remplir) ? 'Ses lignes sont encore vides : à remplir dans data/babioles.json, à la main ou avec votre agent IA de campagne.' : 'Toutes ses babioles ont été données (option « Écarter » du widget Babioles).' });
    }]), 'Tirer une babiole');
    menu.addEventListener('toggle', e => { if (e.newState === 'open') aDroite(btnBabiole, menu); });
    zoneBabiole.append(menu);
  });

  // Dés : le widget Dés dans une fenêtre flottante (un second clic la ferme). Corps sans hauteur fixe : les cinq jets
  // précédents y tiennent.
  const btnDes = raccourci('d20', 'Lancer des dés', () => {
    const deja = flottantOuvert('menu-rapide:des');
    if (deja) { deja.fermer(); return; }
    const corps = h('div', { class: 'bn-widget__corps cm-des-flottant' });
    flottant('menu-rapide:des', { titre: 'Dés', contenu: corps, largeur: 380, compact: true, depuis: btnDes });
    des.monter({ corps, actions: h('div'), resume: h('div'), etat });
  });

  // Mode débogage (fenêtre Campagne, onglet « Ce poste ») : une largeur d'écran simulée (app/debogage.js), allumé en orange
  // tant qu'elle s'applique.
  const btnLargeur = raccourci('lu-monitor', 'Largeur d\'écran simulée (mode débogage)', () => {});
  const zoneLargeur = h('div', { class: 'cm-menu-rapide__sous' }, btnLargeur);
  const reelle = () => `Réelle (${innerWidth} px)`;
  const [, menuLargeur] = boutonMenu(btnLargeur, [
    [reelle(), 'La largeur de la fenêtre', () => simulerLargeur(null), () => !largeurSimulee()],
    ...LARGEURS.map(([l, lib]) => [`${l} px · ${lib}`, null, () => simulerLargeur(l), () => largeurSimulee() === l]),
  ], 'Largeur d\'écran simulée');
  menuLargeur.addEventListener('toggle', e => {
    if (e.newState !== 'open') return;
    menuLargeur.firstElementChild.textContent = reelle();
    aDroite(btnLargeur, menuLargeur);
  });
  zoneLargeur.append(menuLargeur);
  const majDebogage = () => {
    zoneLargeur.hidden = !debogageActif();
    btnLargeur.classList.toggle('est-actif', !!largeurSimulee());
  };
  surDebogage(majDebogage);
  majDebogage();

  // Carte et tirage : seulement si la campagne a une carte des trajets (carte.json) et des tables de rencontres.
  const btnCarte = raccourci('carte', 'Carte des trajets', () => demander('cm:voir-carte', 'Trajets'));
  const btnTirage = raccourci('loup', 'Tirage des rencontres', () => demander('cm:voir-tirage', 'Rencontres'));
  btnCarte.hidden = btnTirage.hidden = true;
  chargerCarte().then(c => { btnCarte.hidden = !c; });
  donnees('rencontres-aleatoires').then(l => { btnTirage.hidden = l.statut !== 'ok'; });

  const poignee = h('button', { type: 'button', class: 'cm-menu-rapide__poignee', title: 'Glisser pour monter ou descendre le menu (flèches au clavier)',
    'aria-label': 'Déplacer le menu rapide' }, icone('lu-grip-horizontal', 'bn-icone--s'));
  const el = h('nav', { class: 'cm-menu-rapide', 'aria-label': 'Menu rapide' },
    poignee,
    raccourci('lu-arrow-up', 'Haut de la page', () => window.scrollTo({ top: 0 })),
    raccourci('lu-users', 'Le groupe : vie, ressources, objets, argent', () => demander('cm:voir-groupe', 'Personnages')),
    btnCarte,
    btnTirage,
    zoneBabiole,
    btnDes,
    zoneLargeur);
  document.body.append(el);

  // ───── Place : glissée à la poignée, gardée en fraction de la hauteur, toujours dans l'écran ─────
  let fraction = 0.3;
  try { const f = parseFloat(localStorage.getItem(CLE_PLACE)); if (f >= 0 && f <= 1) fraction = f; } catch { /* pas de stockage */ }
  const borne = haut => Math.max(MARGE, Math.min(innerHeight - el.offsetHeight - MARGE, haut));
  const placer = haut => { el.style.top = borne(haut) + 'px'; };
  const garder = () => {
    fraction = (el.offsetTop - MARGE) / Math.max(1, innerHeight - el.offsetHeight - 2 * MARGE);
    try { localStorage.setItem(CLE_PLACE, String(Math.max(0, Math.min(1, fraction)))); } catch { /* le choix vaut pour la session */ }
  };
  const replacer = () => placer(MARGE + fraction * (innerHeight - el.offsetHeight - 2 * MARGE));
  replacer();
  addEventListener('resize', replacer);

  let depart = null;
  poignee.addEventListener('pointerdown', e => {
    if (poignee.disabled) return;
    depart = { y: e.clientY, haut: el.offsetTop };
    poignee.setPointerCapture(e.pointerId);
    el.classList.add('est-deplace');
  });
  poignee.addEventListener('pointermove', e => { if (depart) placer(depart.haut + e.clientY - depart.y); });
  const lacher = () => { if (!depart) return; depart = null; el.classList.remove('est-deplace'); garder(); };
  poignee.addEventListener('pointerup', lacher);
  poignee.addEventListener('pointercancel', lacher);
  poignee.addEventListener('keydown', e => {
    const pas = { ArrowUp: -24, ArrowDown: 24 }[e.key];
    if (!pas) return;
    e.preventDefault();
    placer(el.offsetTop + pas);
    garder();
  });
  return { el, verrouiller(v) { el.classList.toggle('est-fige', v); poignee.disabled = v; } };
}

