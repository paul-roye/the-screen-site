// Module de campagne Tarokka (Curse of Strahd) : la lecture de madame Éva et les tirages personnels (widget Tarokka,
// app/widgets/tarokka.js), et ce que le Tarokka place ailleurs : aux étapes du déroulé (etapes[].tarokka), sur la carte
// d'un lieu (Ici), aux objets (objets[].tarokka), dans la bibliothèque d'images (cartes du jeu) et à la fin de session.
// Chargé seulement si le manifeste de la campagne le demande (`modules`), voir app/modules.js.
// Données : data/tarokka.json (formats/tarokka.md). État : etat/tarokka.json (formats/etat.md).

import { h, icone, badge } from '../ui.js';
import { verifierEcarts } from '../donnees.js';
import widget from '../widgets/tarokka.js';

const ETAT_DEFAUT = { schema: 1, tirage: {}, suivi: {}, notes: {}, options: {} };
const PLACES_DEFAUT = ['tome', 'symbole', 'epee', 'allie', 'strahd'];

let tarokka = null;    // data/tarokka.json, s'il est lisible
let sTarokka = null;   // etat/tarokka.json

const places = () => tarokka?.places || [];
const placeDe = id => places().find(x => x.id === id);
const nomCarte = id => tarokka?.cartes?.find(c => c.id === id)?.nom || id;
const placesDe = t => t.places || (t.place ? [t.place] : []);

// Ce que le Tarokka place à une étape (étape.tarokka) : pour chaque place, la carte notée à la table, sinon la carte
// prévue (première signification), avec ce qu'elle révèle et la prophétie. Replié : c'est le secret des joueurs.
function blocTarokka(t) {
  const liste = placesDe(t);
  const contenu = liste.map(id => {
    const pl = placeDe(id);
    if (!pl) return h('p', { class: 'ui-s cm-sourdine' }, `Place « ${id} » absente de tarokka.json.`);
    const idCarte = sTarokka?.valeur.tirage?.[id] || pl.significations?.[0]?.carte;
    const carte = tarokka.cartes.find(c => c.id === idCarte);
    const sig = pl.significations?.find(x => x.carte === idCarte);
    return h('div', { class: 'cm-deroule-tarokka' },
      h('p', { class: 'etiquette cm-section__titre' }, icone('tarokka', 'bn-icone--s'), pl.nom, carte ? ` · ${carte.nom}` : ''),
      sig ? h('p', { class: 'ui-l' }, sig.titre) : h('p', { class: 'ui-s cm-sourdine' }, 'Pas de signification pour cette carte.'),
      sig?.a_lire ? h('figure', { class: 'bn-alire' },
        h('figcaption', { class: 'bn-alire__label' }, icone('livre', 'bn-icone--s'), 'À lire à voix haute'),
        String(sig.a_lire).split(/\n{2,}/).map(p => h('p', {}, p))) : null);
  });
  return h('details', { class: 'cm-repli cm-deroule-secret' },
    h('summary', { class: 'etiquette' }, icone('tarokka', 'bn-icone--s'), ` Tarokka : ${liste.map(id => placeDe(id)?.nom || id).join(', ')}`),
    h('div', { class: 'cm-pile' }, t.texte ? h('p', { class: 'ui' }, t.texte) : null, contenu));
}

// tarokka.json : cartes, places, significations, tirages personnels préparés.
function verifierTarokka(d, p) {
  const cartes = new Map((d.cartes || []).map(c => [c.id, c]));
  if (!cartes.size) p.push('« cartes » manquant ou vide.');
  for (const c of d.cartes || []) {
    if (!['commun', 'haut'].includes(c.paquet)) p.push(`Carte ${c.id} : paquet « ${c.paquet} » inconnu (commun ou haut).`);
    if (c.paquet === 'commun' && !['epees', 'etoiles', 'pieces', 'glyphes'].includes(c.suite)) p.push(`Carte ${c.id} : couleur « ${c.suite} » inconnue.`);
  }
  if (!Array.isArray(d.places) || !d.places.length) p.push('« places » manquant ou vide.');
  for (const pl of d.places || []) {
    verifierEcarts(pl.ecarts, `place ${pl.id}`, p);
    if (pl.resultat_fixe) {
      if (!pl.resultat_fixe.titre) p.push(`Place ${pl.id} : « resultat_fixe » sans « titre ».`);
      for (const id of pl.resultat_fixe.cartes_coherentes || []) {
        if (!cartes.has(id)) p.push(`Place ${pl.id} : la carte cohérente « ${id} » n'existe pas dans « cartes ».`);
      }
    }
    const vues = new Set();
    for (const s of pl.significations || []) {
      const c = cartes.get(s.carte);
      if (!c) p.push(`Place ${pl.id} : la carte « ${s.carte} » n'existe pas dans « cartes ».`);
      else if (pl.paquet && c.paquet !== pl.paquet) p.push(`Place ${pl.id} : la carte « ${s.carte} » n'est pas du paquet « ${pl.paquet} ».`);
      if (vues.has(s.carte)) p.push(`Place ${pl.id} : la carte « ${s.carte} » a deux significations.`);
      vues.add(s.carte);
      verifierEcarts(s.ecarts, `place ${pl.id}, carte ${s.carte}`, p);
    }
  }
  // Tirage préparé : une carte rangée dans un paquet ne sort qu'une fois (places qui ne listent qu'une partie de leur paquet,
  // cartes de secours comprises, puis lectures personnelles).
  const taillePaquet = pq => (d.cartes || []).filter(c => c.paquet === pq).length;
  const rangees = new Map();
  const ranger = (id, ou) => {
    if (rangees.has(id)) p.push(`La carte « ${id} » est prévue deux fois : ${rangees.get(id)} et ${ou}.`);
    else rangees.set(id, ou);
  };
  for (const pl of d.places || []) {
    if ((pl.significations || []).length < taillePaquet(pl.paquet)) for (const s of pl.significations) ranger(s.carte, `place ${pl.id}`);
  }
  const tp = d.tirages_personnels;
  if (tp) {
    const emplacements = new Set((tp.cartes || []).map(c => c.id));
    const paquetDe = new Map((tp.cartes || []).map(c => [c.id, c.paquet]));
    if (!emplacements.size) p.push('« tirages_personnels.cartes » manquant ou vide.');
    const vus = new Set();
    for (const perso of tp.personnages || []) {
      if (!perso.id || !perso.nom) p.push('Un personnage de « tirages_personnels » n\'a pas d\'« id » ou de « nom ».');
      if (vus.has(perso.id)) p.push(`Personnage « ${perso.id} » en double.`);
      vus.add(perso.id);
      for (const cle of Object.keys(perso.lectures || {})) {
        if (!emplacements.has(cle)) p.push(`Personnage ${perso.id} : lecture « ${cle} » inconnue (attendu : ${[...emplacements].join(', ')}).`);
      }
      for (const [cle, l] of Object.entries(perso.lectures || {})) {
        if (l.carte !== undefined) {
          const c = cartes.get(l.carte);
          if (!c) p.push(`Personnage ${perso.id}, ${cle} : la carte « ${l.carte} » n'existe pas dans « cartes ».`);
          else if (paquetDe.get(cle) && c.paquet !== paquetDe.get(cle)) p.push(`Personnage ${perso.id}, ${cle} : la carte « ${l.carte} » n'est pas du paquet « ${paquetDe.get(cle)} ».`);
          ranger(l.carte, `${perso.id}, ${cle}`);
        }
        verifierEcarts(l.ecarts, `personnage ${perso.id}, ${cle}`, p);
      }
      verifierEcarts(perso.ecarts, `personnage ${perso.id}`, p);
    }
    verifierEcarts(tp.ecarts, 'tirages_personnels', p);
  }
}

// Places du Tarokka citées par d'autres fichiers : celles de tarokka.json, sinon les cinq de la lecture.
async function placesConnues(autre) {
  const t = await autre('tarokka');
  return new Set(t?.places?.map(x => x.id) || PLACES_DEFAUT);
}

export default {
  id: 'tarokka',
  titre: 'Tarokka',
  widgets: [widget],
  formats: { tarokka: { schema: 1, verifier: verifierTarokka } },
  champs: {
    // Étapes du déroulé : etapes[].tarokka { place | places, texte }.
    'deroule-campagne': async (d, p, autre) => {
      const connues = await placesConnues(autre);
      for (const e of d.etapes || []) {
        if (!e.tarokka) continue;
        const liste = placesDe(e.tarokka);
        if (!liste.length) p.push(`Étape ${e.id} : « tarokka » sans « place » ni « places ».`);
        for (const pl of liste) if (!connues.has(pl)) p.push(`Étape ${e.id} : place du Tarokka « ${pl} » inconnue.`);
      }
    },
    // Objets : objets[].tarokka, la place du Tarokka où l'objet est révélé.
    objets: async (d, p, autre) => {
      const t = await autre('tarokka');
      if (!(d.objets || []).some(o => o.tarokka)) return;
      if (!t) { p.push('Avertissement : tarokka.json n\'est pas chargé, les places du Tarokka des objets ne sont pas vérifiées.'); return; }
      const ids = new Set((t.places || []).map(x => x.id));
      for (const o of d.objets || []) if (o.tarokka && !ids.has(o.tarokka)) p.push(`Objet ${o.id} : tarokka « ${o.tarokka} » absent de tarokka.json (places).`);
    },
  },

  async preparer({ donnees, etat }) {
    tarokka = (await donnees('tarokka')).donnees;
    sTarokka = tarokka ? await etat('tarokka', ETAT_DEFAUT) : null;
  },

  emplacements: {
    etapeRepere: e => (e.tarokka ? h('span', { title: 'Le Tarokka place quelque chose ici' }, icone('tarokka', 'bn-icone--s cm-actif')) : null),
    etapeBloc: e => (e.tarokka ? blocTarokka(e.tarokka) : null),
    lieuRepere: (lieu, etapes) => (etapes.some(e => e.tarokka && (e.lieux || []).includes(lieu))
      ? h('span', { class: 'bn-lieu__tarokka', title: 'Le Tarokka place quelque chose ici (onglet Trame)' }, icone('tarokka', 'bn-icone--s cm-actif')) : null),
    objetLigne: (r, o) => (o?.tarokka ? [h('span', { class: 'etiquette' }, 'Tarokka'), badge(placeDe(o.tarokka)?.nom || o.tarokka, 'ultra', 'tarokka')] : null),

    imagesCategories: { tarokka: { nom: 'Tarokka', icone: 'tarokka' } },
    // Nom VF des cartes du Tarokka (tarokka.json) ; une carte n'est jamais rapprochée d'un PNJ.
    imageTitre: i => (tarokka?.cartes || []).find(c => c.image && c.image === i.chemin)?.nom || null,
    imageSansPnj: i => i.categorie === 'tarokka',

    sessionEtats: ['tarokka'],
    sessionPrompt({ etats, ligne, date }) {
      if (!tarokka) return;
      const dT = etats.tarokka;
      ligne('### Tarokka');
      ligne(`- Tirage ${dT?.tirage_valide ? `validé par le MJ le ${date(dT.tirage_valide)}` : 'pas encore validé par le MJ'}.`);
      for (const pl of places()) {
        const notee = dT?.tirage?.[pl.id];
        const prevue = pl.significations?.[0]?.carte;
        const carte = notee ? `carte notée : ${nomCarte(notee)} (\`${notee}\`)` : prevue ? `pas de carte notée, la carte prévue s'applique : ${nomCarte(prevue)} (\`${prevue}\`)` : 'pas de carte notée';
        const suivi = pl.libelle_suivi ? ` ; ${pl.libelle_suivi.toLowerCase()} : ${dT?.suivi?.[pl.id] ? 'oui' : 'non'}` : '';
        const note = dT?.notes?.[pl.id]?.trim() ? ` ; note : ${dT.notes[pl.id].trim().replace(/\n+/g, ' ')}` : '';
        ligne(`- ${pl.nom} (\`${pl.id}\`) : ${carte}${suivi}${note}.`);
      }
      // Tirages personnels : la carte notée par le MJ, sinon la carte prévue de la lecture.
      const tp = tarokka.tirages_personnels;
      for (const perso of tp?.personnages || []) {
        const morceaux = (tp.cartes || []).map(e => {
          const notee = dT?.tirage_personnel?.[perso.id]?.[e.id], prevue = perso.lectures?.[e.id]?.carte;
          const quoi = notee ? `carte notée : ${nomCarte(notee)} (\`${notee}\`)` : prevue ? `carte prévue : ${nomCarte(prevue)} (\`${prevue}\`)` : 'pas de carte';
          const note = dT?.notes?.[`perso:${perso.id}:${e.id}`]?.trim();
          return `${e.nom.toLowerCase()}, ${quoi}${note ? ` (note : ${note.replace(/\n+/g, ' ')})` : ''}`;
        });
        if (morceaux.length) ligne(`- Tirage personnel de ${perso.nom} (\`${perso.id}\`) : ${morceaux.join(' ; ')}.`);
      }
      ligne('');
    },
    sessionExemple: () => (tarokka ? { tarokka: { tirage: { tome: 'id-de-carte' }, suivi: { tome: true }, notes: { tome: 'Texte ajouté à la suite.' } } } : null),
    sessionAide: () => (tarokka ? ['- `tarokka.tirage` : carte réellement tirée à une place (`null` pour effacer). `suivi` : objet trouvé, allié recruté.'] : null),
    sessionAppliquer({ m, etats, liste, ignores, oui, ajouterNote, session }) {
      const t = m.tarokka || {};
      if (!m.tarokka) return;
      if (!tarokka) { ignores.push('« tarokka » : tarokka.json n\'est pas lisible, le tirage n\'est pas changé.'); return; }
      const cartes = new Set((tarokka.cartes || []).map(c => c.id));
      for (const [pl, carte] of Object.entries(t.tirage || {})) {
        if (!placeDe(pl)) { ignores.push(`Tarokka : place « ${pl} » inconnue.`); continue; }
        if (carte !== null && !cartes.has(carte)) { ignores.push(`Tarokka : carte « ${carte} » inconnue.`); continue; }
        const avant = etats.tarokka?.tirage?.[pl] || null;
        if (avant !== carte) liste.push({ fichier: 'tarokka', quoi: `Tarokka, ${placeDe(pl).nom} : carte notée`, avant: avant ? nomCarte(avant) : 'aucune', apres: carte ? nomCarte(carte) : 'aucune',
          appliquer: E => { E.tarokka.tirage ||= {}; if (carte) E.tarokka.tirage[pl] = carte; else delete E.tarokka.tirage[pl]; E.tarokka.date_tirage = new Date().toISOString(); } });
      }
      for (const [pl, v] of Object.entries(t.suivi || {})) {
        if (!placeDe(pl)) { ignores.push(`Tarokka : place « ${pl} » inconnue.`); continue; }
        if (typeof v === 'boolean' && v !== !!etats.tarokka?.suivi?.[pl])
          liste.push({ fichier: 'tarokka', quoi: `Tarokka, ${placeDe(pl).nom} : ${(placeDe(pl).libelle_suivi || 'suivi').toLowerCase()}`, avant: oui(etats.tarokka?.suivi?.[pl]), apres: oui(v), appliquer: E => { E.tarokka.suivi ||= {}; E.tarokka.suivi[pl] = v; } });
      }
      for (const [pl, texte] of Object.entries(t.notes || {})) {
        if (!placeDe(pl)) { ignores.push(`Tarokka : place « ${pl} » inconnue.`); continue; }
        if (typeof texte === 'string' && texte.trim())
          liste.push({ fichier: 'tarokka', quoi: `Tarokka, ${placeDe(pl).nom} : note ajoutée`, avant: null, apres: texte.trim(), appliquer: E => { E.tarokka.notes ||= {}; E.tarokka.notes[pl] = ajouterNote(E.tarokka.notes[pl], texte, session); } });
      }
    },
  },
};
