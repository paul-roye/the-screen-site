// Règles des créatures compagnons de Flee, Mortals! (MCDM), résumées en français pour la table : rédaction propre (pas
// de texte du livre), d'après le chapitre « Companion Creatures » lu sur D&D Beyond le 2026-10-20 ; le livre fait foi.
// Module partagé, copie identique dans le gestionnaire (app/regles-compagnons.js) et dans l'extension du joueur
// (extensions/compagnon/js/regles-compagnons.js) : il n'importe que h() et icone() de ui.js, et n'emploie que des classes
// communes aux deux (cm-pile, cm-section, cm-section__titre, cm-liste, cm-sourdine, bn-lien). À modifier dans les deux.
// contenuReglesCompagnons({ mj }) : le contenu d'une fenêtre (flottant()) ; mj : ajoute la partie du MJ.

import { h, icone } from './ui.js';

export const LIEN_REGLES_COMPAGNONS = 'https://www.dndbeyond.com/sources/dnd/fm/introduction#CompanionCreatures';

// Typographie : espace insécable avant « : » et dans les guillemets, fine avant « ; », dans « DD 5 » et « 5 ft » (le
// texte ci-dessous s'écrit avec des espaces ordinaires).
const INSECABLE = String.fromCharCode(0xa0), FINE = String.fromCharCode(0x202f);
const fr = t => (typeof t !== 'string' ? t : t
  .replace(/ ([:»])/g, INSECABLE + '$1').replace(/« /g, '«' + INSECABLE).replace(/ ;/g, FINE + ';')
  .replace(/\b(DD|\d+) (\d|ft\b)/g, '$1' + FINE + '$2'));
const b = t => h('b', {}, fr(t));
const texte = p => (Array.isArray(p) ? p : [p]).map(fr);
const section = (ic, titre, points) => h('section', { class: 'cm-section' },
  h('p', { class: 'etiquette cm-section__titre' }, icone(ic, 'bn-icone--s'), titre),
  h('ul', { class: 'ui cm-liste' }, points.map(p => h('li', {}, texte(p)))));

export function contenuReglesCompagnons({ mj = false } = {}) {
  return h('div', { class: 'cm-pile' },
    h('p', { class: 'ui-s cm-sourdine' }, texte(['Résumé des règles des créatures compagnons de ', h('i', {}, 'Flee, Mortals!'), ' (MCDM). En cas de doute, le livre fait foi.'])),
    section('lu-users', 'Le compagnon et son soigneur', [
      ['Une créature sauvage qui part à l\'aventure avec les héros. Un personnage, son ', b('soigneur'), ', le commande, et son joueur le joue. Le MJ peut le reprendre s\'il est séparé de son soigneur ou maltraité.'],
      ['En combat, il agit ', b('pendant le tour de son soigneur'), '. Il se déplace, prend ses réactions et ses actions bonus de lui-même ; comme action, seulement ', b('Foncer, Se désengager ou Esquiver'), ', sauf si le soigneur dépense son ', b('action bonus'), ' pour lui en ordonner une autre (celles de son profil comprises). Il doit voir ou entendre son soigneur pour recevoir un ordre.'],
      'Il agit à sa guise si son soigneur est neutralisé, ou pendant un rampage. Soigneur neutralisé ou mort : le MJ décide qui le joue (d\'ordinaire, le même joueur).',
      'Soigneur charmé : ses ordres valent toujours, sauf celui d\'attaquer la créature qui l\'a charmé.',
      'Changer de soigneur : à la fin d\'un repos court ou long, vers un autre personnage volontaire (le MJ peut aussi le faire partir de lui-même). Un seul compagnon par groupe est conseillé.',
    ]),
    section('d20', 'Ses chiffres', [
      [b('Bonus de maîtrise'), ' : celui du soigneur. Dans son profil, « PB » vaut ce bonus, et « PBd6 » autant de d6 (PB +2 : 2d6). Ses PV dépendent aussi du niveau du soigneur.'],
      [b('Dés de vie'), ' : des d8, quelle que soit sa taille.'],
      [b('Langue'), ' : il comprend des ordres simples dans une langue choisie par le soigneur, mais ne parle, ne lit ni n\'écrit.'],
    ]),
    section('griffe', 'Férocité', [
      ['Au ', b('début de son tour'), ' (celui du soigneur), s\'il n\'est pas neutralisé : ', b('+1d4, et +1 par ennemi'), ' qu\'il voit ou entend ', b('à 5 ft ou moins'), '. Une nuée, ou des créatures sur un même profil, comptent pour un ; le MJ juge de ce qui est un vrai ennemi (une proie trop facile ne l\'excite pas). Pas de maximum.'],
      ['Elle se dépense en ', b('pouvoirs de férocité'), ' : les trois actions de son profil qui ont un coût (« 3rd Level: … (5 Ferocity) »). Le soigneur doit avoir le niveau du pouvoir, et le compagnon assez de férocité, dépensée avant d\'agir. Un pouvoir prend toujours son action (donc jamais en attaque d\'opportunité), et aucun ne sert pendant un rampage.'],
      [b('Fin du combat'), ' (quand on ne joue plus à l\'initiative) : s\'il n\'est pas mourant, il regagne autant de PV que sa férocité, qui retombe à 0.'],
    ]),
    section('crocs', 'Attaque de signature', [
      'Une attaque au corps à corps désignée dans son profil, d\'ordinaire sa meilleure. C\'est celle du rampage, et certains pouvoirs s\'en servent.',
    ]),
    section('lu-swords', 'Rampage', [
      ['Juste après le jet de férocité, ', b('à 10 ou plus'), ' (et s\'il n\'est pas neutralisé), il risque le rampage.'],
      ['Le soigneur peut le ', b('retenir'), ' : test de ', b('Sagesse (Dressage)'), ', sans action, ', b('DD 5 + férocité'), '. Il ne doit pas être neutralisé, et le compagnon doit le voir ou l\'entendre. Réussite : son tour se passe normalement ; échec, ou pas de test : rampage.'],
      ['En rampage, il ', b('fonce aussitôt'), ' (jusqu\'à sa vitesse) sur la créature la plus proche qu\'il perçoit et lui porte son ', b('attaque de signature'), ', avec ', b('la moitié de sa férocité'), ' en dégâts de plus si elle touche.'],
      'Un allié et un ennemi aussi proches l\'un que l\'autre : le joueur lance un dé ; impair, il s\'en prend à un allié, pair, à un ennemi (le joueur choisit lequel, son propre héros compris). Personne à portée : il Fonce vers le plus proche ; personne en vue : il part au hasard (le MJ choisit la direction), en évitant le danger.',
      [b('Fin'), ' : son action faite, ou son tour fini, la férocité retombe à 0 et le rampage cesse.'],
    ]),
    section('crane', 'À 0 PV', [
      ['Il est ', b('mourant'), ' et fait des jets de sauvegarde contre la mort, comme un personnage. Si le combat finit ainsi, sa férocité retombe à 0, sans lui rendre de PV.'],
    ]),
    mj ? section('lu-eye-off', 'Pour le MJ', [
      ['Équilibre : sans la classe ', h('i', {}, 'beastheart'), ', compter un compagnon comme un puissant objet magique de combat ; on peut monter la difficulté des rencontres d\'un cran, surtout quand les héros sont en moyenne au niveau 7 ou moins.'],
      'Ennemis pour la férocité : au jugement du MJ ; deux ou trois créatures faibles peuvent n\'en faire qu\'une.',
      'Monture : un compagnon assez grand se monte (selle exotique) ; rien ne change (même tour, l\'action bonus du soigneur pour ses autres actions). En rampage, son cavalier compte comme à 5 ft ; contre lui, il attaque avec désavantage. Barde, au choix du MJ : il la maîtrise, mais n\'ajoute plus le PB du soigneur à sa CA.',
      'Un PNJ avec un animal garde le profil ordinaire de la créature ; le profil de compagnon sert à celle qui rejoint les héros.',
    ]) : null,
    h('p', { class: 'ui' }, texte([h('a', { class: 'bn-lien', href: LIEN_REGLES_COMPAGNONS, target: '_blank', rel: 'noopener' },
      'Le chapitre complet sur D&D Beyond'), ' (', h('i', {}, 'Flee, Mortals!'), ', « Companion Creatures »).'])));
}
