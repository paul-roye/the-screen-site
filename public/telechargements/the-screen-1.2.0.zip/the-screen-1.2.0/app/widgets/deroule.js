// Widget Déroulé : la trame de la campagne (deroule-campagne.json, format 2). Frise par arc : les étapes, indicatives (l'ordre
// est conseillé, rien n'est imposé : on démarre n'importe quelle étape, plusieurs peuvent être en cours), et sous chacune
// ses jalons (moments précis : trajets, rencontres prévues, événements, amorces, haltes) et le rappel discret de ses pistes.
// « À garder en tête » (fenêtre ouverte par un bouton de l'en-tête) : les pistes (fils de fond à faire reparaître) en tableau :
// leur départ, leurs résurgences (les « manifestations » des données) à jouer dans les étapes en cours, leur fin. Étapes, jalons et pistes sont à
// venir, en cours (une piste : commencée) ou terminés (etat/deroule.json, suivi partagé : app/trame.js). Rien ne marque une
// étape terminée d'office, et rien ne déplace les héros : le widget demande s'ils se rendent au lieu de l'élément, avec
// l'option de partir en trajet (dialogue de départ, puis heure par heure dans l'Horloge).
// Le détail d'un jalon ou d'une piste s'ouvre dans une fenêtre flottante ; un autre widget peut l'ouvrir (cm:voir-jalon,
// cm:voir-piste, cm:voir-etape). L'en-tête rappelle l'étape de référence (même widget réduit ; un clic y ramène) et porte
// « À garder en tête » et « Étape suivante ».
// Quêtes personnelles : un jalon ou une piste avec `personnage` porte le nom du PJ (sa fiche dans le widget Personnages) ;
// frise et pistes se filtrent par PJ (bouton de l'en-tête, widget déplié).
// Données : data/deroule-campagne.json (formats/deroule-campagne.md), personnages (noms des PJ), lieux, pnj, rencontres
// scénarisées, temps de voyage, tarokka. État : etat/deroule.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, section, provenance, blocOriginal, flottant, flottantOuvert, sansRamener, lienFlottant, boutonMenu, bascule, infobulle, deNom } from '../ui.js';
import { chargerLieux, nomLieu, nomComplet, aLieu, versLieu, etatIci, arriverA } from '../lieux.js';
import { etatPnj, suiviDe, rangDe, etatEffectif, boutonVu, chargerFactions, ouvrirFichePnj } from '../fiche-pnj.js';
import { outilsRencontresMj } from '../rencontres-mj.js';
import { outilsObjets } from '../objets.js';
import { HEURES_PAR_JOUR, enKm, enMiles, enHeures, enJours, vitessesDe, milesParHeure, totaux, enchainer, cheminLePlusCourt } from '../voyage.js';
import { ICONES_JALON, ICONE_PISTE, LIBELLES_STATUT, etatDeroule, statutDe, commencer, terminer, rouvrir, oublier, valider, remarqueDe, noterRemarque, cleResurgence, resurgenceJouee, jouerResurgence, etapeDeResurgence, remarqueResurgence, saisirRemarqueResurgence, crayonResurgence, boutPiste as boutDePiste, BOUTS_PISTE, rangeurEtapes, elementPnj, elementRencontre, elementObjet } from '../trame.js';
import { vueArbre } from '../arbre.js';
import { outilsRestes } from '../restes.js';
import { contributions } from '../modules.js';
import { annoncer, etatHorloge, horlogeEnService, maintenant } from '../horloge.js';
import { etatRencontres, terrainDuLieu } from '../rencontres-moteur.js';
import { partirEnTrajet } from '../passage.js';
import { libelleSource, wikiActif } from '../campagne.js';

export default {
  type: 'deroule',
  requiert: 'deroule-campagne',
  titre: 'Déroulé',
  surtitre: 'La trame de la campagne',
  icone: 'sablier',
  description: 'Les arcs et leurs étapes (indicatives), du niveau 1 au niveau 12, avec leurs jalons (trajets, rencontres prévues, événements, amorces) et les pistes à garder en tête : ce qui est en cours, les niveaux gagnés, les lieux, et ce que le Tarokka y place.',
  taille: { w: 5, h: 16 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, actions, resume, deplier, donnees, etat, dialogue }) {
    const lecture = await donnees('deroule-campagne');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Déroulé indisponible', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const lieux = await chargerLieux(donnees);
    const voyage = (await donnees('temps-de-voyage')).donnees;
    const R = await outilsRencontresMj({ donnees, etat, dialogue });   // rencontres prévues et créées : app/rencontres-mj.js
    const O = await outilsObjets({ donnees, etat, dialogue });          // objets à trouver : app/objets.js
    // Ce qui reste quand on termine quelque chose : app/restes.js.
    const Restes = await outilsRestes({ donnees, etat, dialogue, R, O, liens: { jalon: j => ouvrirJalon(j), piste: p => ouvrirPiste(p) } });
    const donneesPnj = (await donnees('pnj')).donnees;
    const pnj = new Map((donneesPnj?.pnj || []).map(p => [p.id, p]));
    const factions = await chargerFactions(donnees);
    const sPnj = pnj.size ? await etatPnj(etat) : null;
    const persos = new Map(((await donnees('personnages')).donnees?.personnages || []).map(p => [p.id, p]));
    const s = await etatDeroule(etat, donnees);   // suivi complété, jalons devenus pistes migrés
    const v = () => s.valeur;
    const sTrajets = await etat('trajets', { schema: 1, itineraire: [], unite: 'miles', rythme: 'normal', monture: false });
    const sIci = await etatIci(etat, donnees);   // lieu des héros : « Les héros se rendent-ils à … ? »
    const sHorloge = await etatHorloge(etat);
    const etapes = [...d.etapes].sort((a, b) => a.ordre - b.ordre);
    const arcs = [...d.arcs].sort((a, b) => a.ordre - b.ordre);
    const etapeParId = new Map(etapes.map(e => [e.id, e]));
    const jalonParId = new Map((d.jalons || []).map(j => [j.id, j]));
    const pisteParId = new Map((d.pistes || []).map(p => [p.id, p]));
    // Jalons sous l'étape qui les ouvre, par rang ; pistes sous la leur, dans l'ordre du fichier.
    const jalonsDe = new Map(etapes.map(e => [e.id, (d.jalons || []).filter(j => j.etape === e.id).sort((a, b) => a.rang - b.rang)]));
    const pistesDe = new Map(etapes.map(e => [e.id, (d.pistes || []).filter(p => p.etape === e.id)]));
    const jalonsDansLOrdre = etapes.flatMap(e => jalonsDe.get(e.id));
    const pistesDansLOrdre = etapes.flatMap(e => pistesDe.get(e.id));
    const trajets = new Map((voyage?.trajets || []).map(t => [t.id, t]));
    const mph = milesParHeure(vitessesDe(voyage));   // rythme normal, à pied : la règle du MJ
    const ouverts = new Set();                       // étapes dépliées à la main
    let defiler = true;

    const statut = (genre, id) => statutDe(v(), genre, id);
    const libStatut = (genre, st) => LIBELLES_STATUT[genre][st];
    const niveaux = e => e.niveau_atteint ? `Niv. ${e.niveau_groupe} → ${e.niveau_atteint}` : `Niv. ${e.niveau_groupe}`;
    const libelleType = t => d.types_jalons?.[t] || t;

    // ───── Étapes en cours, étape de référence ─────
    const etapesEnCours = () => etapes.filter(e => statut('etape', e.id) === 'en-cours');
    const debutDe = e => v().suivi.etapes[e.id]?.debut || '';
    // Étape de l'en-tête : l'étape de référence (la dernière démarrée) si elle est en cours ; sinon la dernière démarrée de
    // celles qui le sont ; à défaut la référence, même terminée (« Étape suivante » repart d'elle).
    function focus() {
      const ref = etapeParId.get(v().etape) || null;
      if (ref && statut('etape', ref.id) === 'en-cours') return ref;
      return etapesEnCours().sort((a, b) => debutDe(b).localeCompare(debutDe(a)))[0] || ref;
    }
    // Étape suivante : la prochaine à venir dans l'ordre conseillé.
    const suivante = () => { const f = focus(); return etapes.find(e => (!f || e.ordre > f.ordre) && statut('etape', e.id) === 'a-venir') || null; };

    // ───── Quêtes personnelles : le PJ d'un jalon ou d'une piste, filtre ─────
    const nomPerso = id => persos.get(id)?.nom_court || persos.get(id)?.nom || id;
    const avecPerso = [...(d.jalons || []), ...(d.pistes || [])];
    // PJ qui ont des jalons ou des pistes, dans l'ordre de personnages.json (un id inconnu à la fin : le bouton Données le signale).
    const quetes = [...new Set([...persos.keys(), ...avecPerso.map(x => x.personnage)])].filter(id => id && avecPerso.some(x => x.personnage === id));
    let filtre = null;   // PJ dont seule la quête est affichée ; pas gardé : au rechargement, tout le déroulé
    const visible = x => !filtre || x.personnage === filtre;
    // Filtrée, la frise garde les étapes où se jouent les jalons et les pistes du PJ, et l'étape de référence pour se repérer.
    const etapeVisible = e => !filtre || e === focus() || jalonsDe.get(e.id).some(visible) || pistesDe.get(e.id).some(visible);

    // Fiche du PJ dans le widget Personnages (monté, même dans l'autre mode : la fiche est une fenêtre flottante).
    function ouvrirPerso(id) {
      const ev = new CustomEvent('cm:voir-personnage', { detail: { id, ouvert: false } });
      document.dispatchEvent(ev);
      if (!ev.detail.ouvert) annoncer({ cle: 'personnages-absent', titre: 'Widget Personnages absent', icone: 'lu-user', couleur: 'brume', texte: `Ajoutez le widget Personnages au tableau pour ouvrir la fiche ${deNom(nomPerso(id))}.` });
    }
    // Icône PJ et nom du personnage, en violet ; un clic ouvre sa fiche, sans ouvrir le jalon ou la piste.
    const lienPerso = id => persos.has(id)
      ? h('button', { type: 'button', class: 'bn-badge bn-badge--ultra cm-badge-pj', title: `Quête personnelle ${deNom(nomPerso(id))}\nCliquer : sa fiche`, onclick: ev => { ev.stopPropagation(); ouvrirPerso(id); } }, icone('lu-user'), nomPerso(id))
      : h('span', { class: 'bn-badge bn-badge--ultra cm-badge-pj', title: `« ${id} » absent de personnages.json` }, icone('lu-user'), id);
    const lignePerso = id => h('p', { class: 'cm-quete-pj' }, h('span', { class: 'etiquette' }, 'Quête personnelle'), lienPerso(id));

    function enregistrer() {
      s.enregistrer(0);
      s.signaler(rendre);
      rendre();
    }

    // ───── Les héros se rendent-ils à … ? Rien ne les déplace d'office ─────

    async function arriverAuLieu(id) {
      arriverA(sIci, lieux, id, horlogeEnService() ? maintenant(sHorloge.valeur) : null);
      const terrain = terrainDuLieu(lieux.get(lieux.get(id)?.parent || id)?.type);
      if (terrain) {
        const sR = await etatRencontres(etat);
        sR.valeur.contexte.terrain = terrain;
        sR.enregistrer(0);
        sR.signaler();
      }
    }

    // « Démarrer le trajet » : le dialogue de départ (rythme, cases de la procédure de rencontre ; partirEnTrajet() de app/passage.js), puis le
    // trajet heure par heure dans l'Horloge. Sans le widget Horloge, l'itinéraire va dans le widget Trajets, qui fait arriver
    // les héros.
    function demarrerTrajet(ids, btn) {
      if (horlogeEnService()) { partirEnTrajet({ dialogue, donnees, etat }, ids); return; }
      sTrajets.valeur.itineraire = [...ids];
      delete sTrajets.valeur.arrive;
      sTrajets.enregistrer(0);
      sTrajets.signaler();
      const noms = ids.map(id => nomLieu(lieux, id)).join(' → ');
      if (document.querySelector('.cm-tableau .bn-widget[data-type="trajets"]')) {
        document.dispatchEvent(new CustomEvent('cm:voir-trajets'));
        if (btn) { btn.querySelector('span').textContent = 'Chargé dans Trajets'; btn.disabled = true; }
      } else {
        annoncer({ cle: 'trajet-charge', titre: 'Trajet chargé', icone: 'lu-route', couleur: 'brume', texte: `${noms}. Ajoutez le widget Horloge au tableau pour le mener heure par heure, ou le widget Trajets pour faire arriver les héros.` });
      }
    }

    // Un lieu situé dans un autre, sans trajet propre, se rejoint depuis lui (formats/lieux.md).
    const reseau = new Set((voyage?.trajets || []).flatMap(t => [t.de, t.vers]));
    const lieuDeVoyage = id => (reseau.has(id) || !reseau.has(lieux.get(id)?.situe_dans) ? id : lieux.get(id).situe_dans);
    // Itinéraire vers un lieu depuis celui des héros : une route du jalon qui part d'où ils sont, sinon la plus courte.
    function itineraireVers(lieu, routes = []) {
      const depart = sIci.valeur.lieu ? lieuDeVoyage(sIci.valeur.lieu) : null;
      const route = routes.find(r => r.lieux && (!depart || r.lieux[0] === depart));
      if (route) return route.lieux;
      const chemin = depart ? cheminLePlusCourt(voyage?.trajets || [], depart, lieuDeVoyage(lieu), mph) : null;
      return chemin?.length > 1 ? chemin : null;
    }
    const dejaLa = (lieu, sousLieu) => sIci.valeur.lieu === lieu && (!sousLieu || sIci.valeur.sous_lieu === sousLieu);

    // « Les héros se rendent-ils à … ? » : pas maintenant (d'office), ils y arrivent (arrivée notée), ou préparer le trajet.
    // cibles : [{ lieu, sous_lieu?, routes? }]. Renvoie { el, appliquer } ; el est null quand il n'y a rien à demander
    // (pas de lieu, ou les héros y sont déjà).
    function questionLieu(cibles) {
      const utiles = cibles.filter(c => c.lieu && lieux.has(c.lieu) && !dejaLa(c.lieu, c.sous_lieu))
        .filter((c, i, t) => t.findIndex(x => x.lieu === c.lieu && x.sous_lieu === c.sous_lieu) === i);
      if (!utiles.length) return { el: null, appliquer: () => {} };
      let choix = 'rester';
      const groupe = 'cm-aller-' + Math.random().toString(36).slice(2, 8);
      const radio = (valeur, texte, detail, desactive = false) => h('label', { class: 'cm-case' + (desactive ? ' cm-sourdine' : '') },
        h('input', { type: 'radio', class: 'bn-case', name: groupe, value: valeur, checked: valeur === choix, disabled: desactive, onchange: () => { choix = valeur; } }),
        h('span', {}, texte, detail ? h('span', { class: 'ui-s cm-sourdine' }, ` · ${detail}`) : null));
      const ici = sIci.valeur.lieu;
      const itineraires = utiles.map(c => itineraireVers(c.lieu, c.routes));
      const el = h('div', { class: 'bn-aller' },
        h('p', { class: 'etiquette cm-section__titre' }, icone('epingle', 'bn-icone--s'), `Les héros se rendent-ils ${utiles.map(c => aLieu(nomComplet(lieux, c.lieu, c.sous_lieu))).join(' ou ')} ?`),
        radio('rester', 'Pas maintenant', ici ? `ils restent ${aLieu(nomComplet(lieux, ici, sIci.valeur.sous_lieu))}` : 'lieu des héros pas noté'),
        utiles.map((c, i) => {
          const it = itineraires[i];
          // Déjà dans ce lieu : ils passent seulement dans le sous-lieu (pas d'arrivée, pas de trajet).
          if (c.lieu === ici) return radio(`arriver:${i}`, `Ils vont ${aLieu(nomLieu(lieux, c.sous_lieu))}`, `même lieu, pas d'arrivée notée`);
          return [
            radio(`arriver:${i}`, `Ils arrivent ${aLieu(nomComplet(lieux, c.lieu, c.sous_lieu))}`, horlogeEnService() ? 'arrivée notée à l\'heure de l\'horloge' : 'arrivée notée'),
            radio(`trajet:${i}`, `Ils partent ${versLieu(nomLieu(lieux, c.lieu))}`, it ? `trajet ${it.map(id => nomLieu(lieux, id)).join(' → ')}` : ici ? `pas de route connue depuis ${nomLieu(lieux, ici)}` : 'lieu des héros pas noté', !it),
          ];
        }));
      function appliquer() {
        const [quoi, i] = choix.split(':');
        const c = utiles[Number(i)];
        if (quoi === 'arriver') arriverAuLieu(c.sous_lieu || c.lieu);
        if (quoi === 'trajet' && itineraires[i]) demarrerTrajet(itineraires[i]);
      }
      return { el, appliquer };
    }

    const caseACocher = (ensemble, id, coche, ...texte) => {
      if (coche) ensemble.add(id);
      return h('label', { class: 'cm-case' },
        h('input', { type: 'checkbox', class: 'bn-case', checked: coche, onchange: ev => { if (ev.target.checked) ensemble.add(id); else ensemble.delete(id); } }), h('span', {}, ...texte));
    };

    // Bouton « Commencer » d'une piste, dans une confirmation : immédiat (comme « Vu » d'un PNJ).
    const boutonCommencerPiste = p => {
      const b = bouton('Commencer', { classe: 'bn-btn--s', icone: 'lu-play', titre: `Commencer la piste « ${p.nom} »`, onclick: () => {
        commencer(v(), 'piste', p.id);
        s.enregistrer(0);
        s.signaler(rendre);
        rendre();
        b.replaceWith(badge('Commencée', 'soleil'));
      } });
      return b;
    };

    // ───── Démarrer une étape : confirmation ─────
    // L'étape quittée (celle de l'en-tête, si elle est en cours) : ses PNJ pas encore vus, et ce qui n'est pas terminé (elle,
    // les étapes sautées, leurs jalons), à cocher s'il a été fait : rien n'est terminé d'office. Pistes attendues de la nouvelle
    // étape pas encore commencées. Les héros se rendent-ils à son lieu ?

    const pnjDuLieu = ids => [...pnj.values()].filter(p => ids.includes(p.lieu));
    // Plusieurs étapes au même lieu (la maison, puis son sous-sol) : chacune ne garde que ce qui est de ses pièces
    // (rangeurEtapes de app/trame.js ; à défaut de pouvoir le dire, l'élément reste dans toutes).
    const rangeur = rangeurEtapes(d);
    const pnjDeLEtape = (e, ids = e.lieux || []) => pnjDuLieu(ids).filter(p => rangeur.estDe(elementPnj(p), e.id));
    const rencontreDeLEtape = (e, vue) => rangeur.estDe(elementRencontre(vue), e.id);
    const objetDeLEtape = (e, o) => rangeur.estDe(elementObjet(o, pnj), e.id);
    const ABSENTS = ['mort', 'disparu', 'absent'];

    function demarrer(e1) {
      if (!e1) return;
      const e0 = focus();
      const quitte = e0 && e0 !== e1 && statut('etape', e0.id) === 'en-cours' ? e0 : null;
      const attendues = (e1.pistes_attendues || []).filter(pa => pisteParId.has(pa.piste) && statut('piste', pa.piste) === 'a-venir');
      // Dans chaque lieu de l'étape, le sous-lieu de son premier jalon pas encore terminé (par rang) : là où l'étape commence.
      // Les héros déjà dans le lieu (au grenier, pour « la Funeste demeure : le sous-sol ») se voient proposer d'y descendre.
      const debutDans = lieu => {
        const js = jalonsDe.get(e1.id).filter(j => j.lieu === lieu);
        return (js.find(j => statut('jalon', j.id) !== 'termine') || js[0])?.sous_lieu || undefined;
      };
      const q = questionLieu((e1.lieux || []).filter(id => !lieux.get(id)?.parent).map(lieu => ({ lieu, sous_lieu: debutDans(lieu) })));
      const appliquer = () => { v().etape = e1.id; commencer(v(), 'etape', e1.id); defiler = true; };
      if (!quitte && !attendues.length && !q.el) { appliquer(); enregistrer(); return; }
      const coches = { etape: new Set(), jalon: new Set() };
      let alertePnj = null, alerteRestes = null;
      if (quitte) {
        // PNJ de l'étape quittée (ses lieux, ses jalons) que les joueurs n'ont pas vus ; présents seulement.
        const ids = new Set([...pnjDeLEtape(quitte).map(p => p.id), ...jalonsDe.get(quitte.id).flatMap(j => j.pnj || [])]);
        const nonVus = [...ids].map(id => pnj.get(id)).filter(p => p && sPnj && !suiviDe(sPnj, p.id).rencontre && !ABSENTS.includes(etatEffectif(p, suiviDe(sPnj, p.id))));
        const importants = nonVus.filter(p => rangDe(p, suiviDe(sPnj, p.id)) !== 'mineur');
        const mineurs = nonVus.filter(p => rangDe(p, suiviDe(sPnj, p.id)) === 'mineur');
        // Chaque PNJ avec son bouton « Vu » : on peut le cocher ici même.
        const listePnj = gens => {
          const ul = h('ul', { class: 'cm-confirmation__pnj' });
          const remplir = () => ul.replaceChildren(...gens.map(p => h('li', {},
            h('span', {}, p.nom, h('span', { class: 'ui-s cm-sourdine' }, p.role ? ` · ${p.role}` : '')),
            boutonVu(p, sPnj, () => { sPnj.signaler(); remplir(); }))));
          remplir();
          return ul;
        };
        if (nonVus.length) alertePnj = alerte('cierge', 'crocs', `PNJ de « ${quitte.nom} » pas encore vus (${nonVus.length})`, [
          importants.length ? listePnj(importants) : null,
          mineurs.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `${mineurs.length} mineur${mineurs.length > 1 ? 's' : ''}`), listePnj(mineurs)) : null,
        ].filter(Boolean));
        const sautees = e1.ordre > quitte.ordre ? etapes.filter(e => e.ordre > quitte.ordre && e.ordre < e1.ordre && statut('etape', e.id) !== 'termine') : [];
        const jalonsRestants = [quitte, ...sautees].flatMap(e => jalonsDe.get(e.id)).filter(j => statut('jalon', j.id) !== 'termine');
        alerteRestes = alerte('cierge', 'lu-triangle-alert', 'Pas encore terminé', h('div', { class: 'cm-pile cm-confirmation__restes' },
          caseACocher(coches.etape, quitte.id, false, `« ${quitte.nom} » est terminée`),
          sautees.map(e => caseACocher(coches.etape, e.id, false, `Étape ${e.ordre} : ${e.nom}`)),
          jalonsRestants.map(j => caseACocher(coches.jalon, j.id, false, icone(ICONES_JALON[j.type] || 'lu-info', 'bn-icone--s'), ` ${j.nom}`,
            statut('jalon', j.id) === 'en-cours' ? h('span', { class: 'cm-sourdine' }, ' (en cours)') : j.facultatif ? h('span', { class: 'cm-sourdine' }, ' (facultatif)') : '')),
          h('p', { class: 'ui-s cm-sourdine' }, `Cochez ce qui a été fait. Ce qui n'est pas coché reste tel quel${sautees.length ? ' ; une étape sautée reste à venir' : ''}, et « ${quitte.nom} » reste en cours si elle n'est pas cochée.`)));
      }
      const alerteAttendues = attendues.length ? alerte('cierge', ICONE_PISTE, `Pistes attendues pas encore commencées (${attendues.length})`,
        h('ul', { class: 'cm-confirmation__pnj' }, attendues.map(pa => {
          const p = pisteParId.get(pa.piste);
          return h('li', {}, h('span', {}, h('b', {}, p.nom), h('span', { class: 'ui-s cm-sourdine' }, ` · ${pa.texte}`)), boutonCommencerPiste(p));
        }))) : null;
      const contenu = h('div', { class: 'cm-pile' },
        h('p', { class: 'ui' }, 'Démarrer « ', h('b', {}, e1.nom), ' »', quitte ? [' (en cours : « ', h('b', {}, quitte.nom), ' »)'] : '', '.'),
        alerteAttendues, alertePnj, alerteRestes, q.el);
      const dlg = dialogue('Déroulé · démarrer une étape', `Étape ${e1.ordre} / ${etapes.length}`, contenu,
        h('div', { class: 'bn-groupe' },
          bouton('Démarrer l\'étape', { classe: 'bn-btn--primaire', icone: 'lu-play', onclick: async () => {
            if (!(await O.avantDeTerminer({ etapes: [...coches.etape], jalons: [...coches.jalon] }))) return;   // objets pas encore donnés
            coches.etape.forEach(id => terminer(v(), 'etape', id));
            coches.jalon.forEach(id => terminer(v(), 'jalon', id));
            appliquer();
            dlg.close();
            q.appliquer();
            enregistrer();
          } }),
          bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    }

    // Terminer une étape, un jalon ou une piste : d'abord ce qui reste à y faire (app/restes.js : jalons, trajets, rencontres,
    // pistes, PNJ, objets), que le MJ règle ou laisse ; « Annuler » ne termine rien. « Terminer, tout est bon » le valide.
    async function terminerEnVerifiant(genre, x, quoi) {
      const reponse = await Restes.demander(quoi, { genre, id: x.id, nom: x.nom });
      if (!reponse) return false;
      terminer(v(), genre, x.id);
      if (reponse === 'valide') valider(v(), genre, x.id);
      return true;
    }
    async function terminerEtape(e) {
      if (await terminerEnVerifiant('etape', e, { etape: e.id })) enregistrer();
    }
    async function terminerJalon(j) {
      if (!(await terminerEnVerifiant('jalon', j, { jalon: j.id }))) return;
      enregistrer();
      apresJalon(j, true);
    }
    async function terminerPiste(p) {
      if (await terminerEnVerifiant('piste', p, { piste: p.id })) enregistrer();
    }

    // Une étape qui n'est plus en cours redevient à venir ; si c'était la référence, la dernière démarrée de celles qui
    // restent en cours la remplace.
    function plusEnCours(e) {
      oublier(v(), 'etape', e.id);
      if (v().etape === e.id) v().etape = etapesEnCours().sort((a, b) => debutDe(b).localeCompare(debutDe(a)))[0]?.id || null;
      enregistrer();
    }

    // ───── Après un jalon commencé ou terminé ─────
    // Les héros vont-ils à son lieu ? Pistes à commencer (début : ce jalon) ou à terminer (fin : ce jalon), étapes dont tous
    // les jalons clés sont faits. Propositions cochées, appliquées par « Valider » ; le lieu reste « Pas maintenant » d'office.
    function apresJalon(j, fini) {
      const lieu = j.lieu || j.vers;
      const q = questionLieu(lieu ? [{ lieu, sous_lieu: j.lieu ? j.sous_lieu : undefined, routes: voyageDuJalon(j)?.routes || [] }] : []);
      const aCommencer = (d.pistes || []).filter(p => p.debut?.jalon === j.id && statut('piste', p.id) === 'a-venir');
      const aTerminer = fini ? (d.pistes || []).filter(p => p.fin?.jalon === j.id && statut('piste', p.id) !== 'termine') : [];
      const etapesFinies = fini ? etapes.filter(e => e.fin?.jalons_cles?.includes(j.id) && statut('etape', e.id) !== 'termine'
        && e.fin.jalons_cles.every(id => statut('jalon', id) === 'termine')) : [];
      if (!q.el && !aCommencer.length && !aTerminer.length && !etapesFinies.length) return;
      const coches = { commencer: new Set(), terminer: new Set(), etapes: new Set() };
      const contenu = h('div', { class: 'cm-pile' },
        aCommencer.length ? section('Pistes à commencer', ICONE_PISTE, aCommencer.map(p => caseACocher(coches.commencer, p.id, true, h('b', {}, p.nom), h('span', { class: 'ui-s cm-sourdine' }, ` · ${p.debut.texte}`)))) : null,
        aTerminer.length ? section('Pistes à terminer', ICONE_PISTE, aTerminer.map(p => caseACocher(coches.terminer, p.id, true, h('b', {}, p.nom), h('span', { class: 'ui-s cm-sourdine' }, ` · ${p.fin.texte}`)))) : null,
        etapesFinies.length ? section('Tous les jalons clés sont terminés', 'lu-flag', etapesFinies.map(e => caseACocher(coches.etapes, e.id, true, `Marquer « ${e.nom} » terminée`, h('span', { class: 'ui-s cm-sourdine' }, ` · ${e.fin.texte}`)))) : null,
        q.el);
      const dlg = dialogue(`Déroulé · jalon ${fini ? 'terminé' : 'en cours'}`, j.nom, contenu,
        h('div', { class: 'bn-groupe' },
          bouton('Valider', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: async () => {
            coches.commencer.forEach(id => commencer(v(), 'piste', id));
            coches.terminer.forEach(id => terminer(v(), 'piste', id));
            for (const id of coches.etapes) if (!(await terminerEnVerifiant('etape', etapeParId.get(id), { etape: id }))) return;
            dlg.close();
            q.appliquer();
            enregistrer();
          } }),
          bouton('Rien de plus', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    }

    // ───── Liens dans les fenêtres ─────

    const decision = x => x.decision_mj ? h('div', { class: 'cm-decision' }, badge('Décision du MJ', 'sang'), h('p', { class: 'ui' }, x.decision_mj.texte)) : null;
    // Où lire le détail : pages du PDF de la source de l'élément (un supplément), ou du livre.
    const pages = x => (x.pages_pdf || x.pages_livre ? h('p', { class: 'ui-s cm-sourdine' }, icone('livre', 'bn-icone--s'), ' Où lire : ',
      [x.pages_pdf ? `p. ${x.pages_pdf} du PDF${x.source ? ` (${libelleSource(x.source)})` : ''}` : null, x.pages_livre ? `p. ${x.pages_livre} du livre` : null].filter(Boolean).join(' · ')) : null);
    // Un lieu (et son sous-lieu) : la page du wiki des joueurs, s'il en a une.
    const lienLieu = (id, sousLieu) => {
      const url = wikiActif() ? lieux.get(id)?.wiki?.url : null;
      const nom = nomComplet(lieux, id, sousLieu);
      return url ? h('a', { class: 'bn-lien', href: url, target: '_blank', rel: 'noopener', title: 'Page du wiki des joueurs' }, nom) : h('span', {}, nom);
    };
    const statutCourt = (genre, id) => {
      const st = statut(genre, id);
      return st === 'a-venir' ? null : h('span', { class: 'cm-sourdine' }, ` (${libStatut(genre, st)})`);
    };
    const lienJalon = id => {
      const j = jalonParId.get(id);
      if (!j) return h('span', { class: 'cm-sourdine' }, id);
      return h('span', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirJalon(j) },
        icone(ICONES_JALON[j.type] || 'lu-info', 'bn-icone--s'), ` ${j.nom}`), statutCourt('jalon', id));
    };
    const lienPiste = p => h('span', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPiste(p) },
      icone(ICONE_PISTE, 'bn-icone--s'), ` ${p.nom}`), statutCourt('piste', p.id));
    const lienEtape = id => {
      const e = etapeParId.get(id);
      if (!e) return h('span', { class: 'cm-sourdine' }, id);
      return h('span', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Voir l\'étape dans la frise', onclick: () => voir(e.id, `.cm-etape[data-id="${CSS.escape(e.id)}"]`, !etapeVisible(e)) },
        `Étape ${e.ordre} : ${e.nom}`), statutCourt('etape', id));
    };
    // Un trajet de temps-de-voyage.json : « A → B », un clic ouvre son départ (rythme, puis heure par heure dans l'Horloge).
    const lienTrajet = id => {
      const t = trajets.get(id);
      if (!t) return h('span', { class: 'cm-sourdine' }, id);
      return h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Démarrer ce trajet : choisir le rythme et partir', onclick: () => demarrerTrajet([t.de, t.vers]) },
        icone('lu-route', 'bn-icone--s'), ` ${nomLieu(lieux, t.de)} → ${nomLieu(lieux, t.vers)}`);
    };
    const ouvrirPnj = p => ouvrirFichePnj(p, { lieux, s: sPnj, factions, typesRang: donneesPnj?.types_rang });
    const listePnj = ids => h('p', { class: 'cm-tenanciers' }, ids.map(id => pnj.has(id)
      ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPnj(pnj.get(id)) }, pnj.get(id).nom)
      : h('span', { class: 'ui-s cm-sourdine' }, id)));
    // Rencontres prévues (données) et créées par le MJ : une ligne chacune, un clic ouvre son menu (Ouvrir, Lancer…).
    const listeRencontres = vues => h('div', { class: 'cm-rmj-liste' }, vues.map(vue => R.ligne(vue, { voirDeroule: false, compacte: true })));
    const rencontresDeLaPiste = p => (p.rencontres || []).map(id => R.vueDe(id) || null).filter(Boolean);

    // ───── Remarques du MJ ─────
    // Sur une étape, un jalon ou une piste, avec ou sans rencontre : reprises par la fin de session.

    function modifierRemarque(genre, x) {
      let dlg;
      const champ = h('textarea', { class: 'bn-textarea', rows: 6, placeholder: 'Ce qui s\'est passé, ce qu\'il faudra en retenir…', 'aria-label': 'Remarque du MJ' }, remarqueDe(v(), genre, x.id)?.texte || '');
      dlg = dialogue('Remarque du MJ', x.nom, champ, h('div', { class: 'bn-groupe' },
        bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => {
          if (champ.value.trim() !== (remarqueDe(v(), genre, x.id)?.texte || '')) { noterRemarque(v(), genre, x.id, champ.value); enregistrer(); }
          dlg.close();
        } }),
        bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
      setTimeout(() => { champ.focus(); champ.setSelectionRange(champ.value.length, champ.value.length); }, 0);
    }
    const blocRemarque = (genre, x) => {
      const r = remarqueDe(v(), genre, x.id);
      return r ? section('Remarque du MJ', 'livre', h('p', { class: 'ui cm-rmj__remarque-texte' }, r.texte)) : null;
    };
    const boutonRemarque = (genre, x) => bouton(remarqueDe(v(), genre, x.id) ? 'Modifier la remarque' : 'Remarque', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', titre: 'Ce qui s\'est passé, ce qu\'il faudra en retenir : reprise par la fin de session', onclick: () => modifierRemarque(genre, x) });
    const marqueRemarque = (genre, x) => (remarqueDe(v(), genre, x.id) ? h('span', { class: 'bn-jalon__meta', title: 'Une remarque du MJ' }, ' · ', icone('livre', 'bn-icone--s')) : null);

    // ───── Étapes ─────

    function vueEtape(e) {
      const st = statut('etape', e.id);
      const estFocus = e === focus();
      const cles = e.fin?.jalons_cles || [];
      const clesFaits = cles.filter(id => statut('jalon', id) === 'termine').length;
      const finAtteinte = cles.length > 0 && clesFaits === cles.length && st !== 'termine';
      const attendues = st === 'termine' ? [] : (e.pistes_attendues || []).filter(pa => pisteParId.has(pa.piste) && statut('piste', pa.piste) === 'a-venir');
      // L'étape de l'en-tête garde son néon ; les autres étapes en cours sont encadrées sans néon.
      const det = h('details', { class: `cm-etape cm-etape--${st}${estFocus ? ' est-focus' : ''}`, open: st === 'en-cours' || ouverts.has(e.id), 'data-id': e.id },
        h('summary', {},
          h('span', { class: 'cm-etape__ordre', title: st === 'termine' ? 'Terminée' : null }, st === 'termine' ? icone('lu-check', 'bn-icone--s') : e.ordre),
          h('span', { class: 'cm-etape__nom' }, e.nom),
          h('span', { class: 'cm-etape__badges' },
            st === 'en-cours' ? badge('En cours', 'sang') : null,
            st === 'termine' ? badge('Terminée', 'brume', 'lu-check') : null,
            Restes.symbole({ etape: e.id }, { genre: 'etape', id: e.id, nom: e.nom }),
            finAtteinte ? h('span', { title: 'Tous les jalons clés sont terminés' }, badge('Fin atteinte', 'cierge', 'lu-flag')) : null,
            badge(niveaux(e), e.niveau_atteint ? 'ultra' : null),
            contributions('etapeRepere', e))),   // modules de campagne (le Tarokka) : app/modules.js
        h('div', { class: 'cm-pile' },
          e.lieux?.length ? h('p', { class: 'cm-lieu' }, icone('epingle', 'bn-icone--s'), e.lieux.map(id => {
            const nl = lieux.get(id)?.niveau_livre;
            return nomLieu(lieux, id) + (nl ? ` (livre : niv. ${nl.min === nl.max ? nl.min : `${nl.min}-${nl.max}`})` : '');
          }).join(' · ')) : null,
          h('p', { class: 'texte' }, e.description),
          e.fin?.texte ? h('p', { class: 'ui cm-etape__fin' }, icone('lu-flag', 'bn-icone--s'), h('span', {}, h('b', {}, 'Fin : '), e.fin.texte,
            cles.length ? [' · ', h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Voir ces jalons clés', onclick: () => ouvrirJalonsCles(e) }, `jalons clés terminés : ${clesFaits}/${cles.length}`)] : '')) : null,
          finAtteinte ? alerte('cierge', 'lu-flag', 'Tous les jalons clés sont terminés', h('span', {}, 'L\'étape est-elle finie ? '),
            bouton('Marquer terminée', { classe: 'bn-btn--s', icone: 'lu-check', onclick: () => terminerEtape(e) })) : null,
          attendues.length ? alerte('cierge', ICONE_PISTE, 'Pistes attendues pas encore commencées', h('ul', { class: 'cm-confirmation__pnj' }, attendues.map(pa => {
            const p = pisteParId.get(pa.piste);
            return h('li', {}, h('span', {}, lienPiste(p), h('span', { class: 'ui-s cm-sourdine' }, ` · ${pa.texte}`)),
              bouton('Commencer', { classe: 'bn-btn--s', icone: 'lu-play', onclick: () => { commencer(v(), 'piste', p.id); enregistrer(); } }));
          }))) : null,
          e.niveau_atteint ? h('p', { class: 'ui-s' }, icone('etoile', 'bn-icone--s'), ` Le groupe passe au niveau ${e.niveau_atteint}.`) : null,
          blocRemarque('etape', e),
          decision(e),
          blocOriginal(e.original),
          contributions('etapeBloc', e),
          R.deLEtape(e).length ? section('Rencontres', 'lu-swords', listeRencontres(R.deLEtape(e))) : null,
          O.deLEtape(e).length ? section('Objets', 'amulette', O.liste(O.deLEtape(e))) : null,
          h('div', { class: 'bn-groupe' },
            st === 'a-venir' ? bouton('Démarrer', { classe: 'bn-btn--s', icone: 'lu-play', titre: 'Ouvre ses jalons et ses pistes ; les héros ne bougent pas', onclick: () => demarrer(e) })
              : st === 'en-cours' ? bouton('Plus en cours', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'L\'étape redevient à venir', onclick: () => plusEnCours(e) }) : null,
            st === 'termine'
              ? bouton('Rouvrir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Ce n\'est pas terminé : l\'étape redevient en cours', onclick: () => { rouvrir(v(), 'etape', e.id); enregistrer(); } })
              : bouton('Marquer terminée', { classe: 'bn-btn--s', icone: 'lu-check', titre: 'L\'étape est faite (et compte comme commencée)', onclick: () => terminerEtape(e) }),
            R.boutonNouvelle({ etape: e.id }, { libelle: 'Rencontre' }),
            O.boutonNouveau({ etape: e.id }),
            boutonRemarque('etape', e),
            bouton('Arbre', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-network', titre: 'Ses jalons, rencontres, PNJ, objets et pistes, en branches', onclick: () => ouvrirArbre(e) }))));
      det.addEventListener('toggle', () => { if (det.open) ouverts.add(e.id); else ouverts.delete(e.id); });
      return det;
    }

    // Les jalons clés d'une étape (ceux qui disent qu'elle est finie), en fenêtre : un clic ouvre chacun.
    function ouvrirJalonsCles(e) {
      const cles = (e.fin?.jalons_cles || []).map(id => jalonParId.get(id)).filter(Boolean);
      flottant('jalons-cles:' + e.id, { surtitre: `Étape ${e.ordre} : ${e.nom}`, titre: 'Jalons clés', largeur: 500, pictogramme: 'lu-flag', contenu: h('div', { class: 'cm-pile' },
        e.fin?.texte ? h('p', { class: 'ui' }, icone('lu-flag', 'bn-icone--s'), ' ', h('b', {}, 'Fin : '), e.fin.texte) : null,
        h('div', { class: 'bn-jalons' }, cles.map(vueJalon))) });
    }

    // ───── Jalons ─────

    // Itinéraires d'un jalon : { libre } (les joueurs tracent leur route), ou { routes: [{ nom, de, lieux, miles, minutes,
    // difficile, inconnus }] } : un seul itinéraire (trajets), ou plusieurs au choix (variantes). Rythme normal, à pied.
    // lieux : les lieux traversés, ou null si les trajets ne se suivent pas (alors pas de totaux).
    function voyageDe(j) {
      if (j.itineraire_libre) return { libre: true, routes: [] };
      const brutes = j.variantes?.length ? j.variantes.map(r => ({ nom: r.nom, de: r.de || j.de, ids: r.trajets || [] }))
        : j.trajets?.length ? [{ de: j.de, ids: j.trajets }] : [];
      const routes = brutes.map(r => {
        const ts = r.ids.map(id => trajets.get(id)).filter(Boolean);
        const inconnus = r.ids.filter(id => !trajets.has(id));
        const chemin = inconnus.length ? null : enchainer(ts, r.de, j.vers);
        return { nom: r.nom, de: r.de, lieux: chemin, inconnus, ...totaux(ts, mph) };
      });
      return routes.length ? { routes } : null;
    }
    const voyageDuJalon = j => (j.type === 'trajet' || j.trajets?.length || j.variantes?.length || j.itineraire_libre ? voyageDe(j) : null);
    // Ligne du jalon : « 16 miles · 5 h 20 », « 2 itinéraires · 6 h 20 à 9 h 40 », « itinéraire libre ».
    function resumeVoyage(vy) {
      if (vy.libre) return 'itinéraire libre';
      const ok = vy.routes.filter(r => r.lieux);
      if (!ok.length) return '';
      if (vy.routes.length === 1) return `${enMiles(ok[0].miles)} · ${enHeures(ok[0].minutes)}`;
      const t = ok.map(r => r.minutes).sort((a, b) => a - b);
      return `${vy.routes.length} itinéraires · ${enHeures(t[0])}${t.length > 1 && t[t.length - 1] !== t[0] ? ` à ${enHeures(t[t.length - 1])}` : ''}`;
    }

    // Un itinéraire : un clic sur la route (ou sur « Démarrer le trajet ») ouvre son départ : rythme, cases de la procédure de rencontre, puis
    // heure par heure dans l'Horloge.
    function vueRoute(r) {
      const nomR = r.nom ? h('b', {}, `${r.nom} : `) : null;
      if (!r.lieux) return h('p', { class: 'ui-s cm-sourdine' }, nomR,
        r.inconnus.length ? `absent de temps-de-voyage.json : ${r.inconnus.join(', ')}.` : 'les trajets indiqués ne se suivent pas, pas de total.');
      const btn = bouton('Démarrer le trajet', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-route', titre: 'Choisir le rythme et partir : le trajet se mène heure par heure dans l\'Horloge', onclick: () => demarrerTrajet(r.lieux, btn) });
      return h('div', { class: 'cm-fiche-jalon__route' },
        h('p', { class: 'cm-lieu' }, icone('lu-route', 'bn-icone--s'),
          h('button', { type: 'button', class: 'bn-lien cm-lien-bouton cm-fiche-jalon__trajet', title: 'Démarrer ce trajet : choisir le rythme et partir', onclick: () => demarrerTrajet(r.lieux, btn) },
            nomR, r.lieux.map(id => nomLieu(lieux, id)).join(' → '))),
        h('p', { class: 'ui-s' }, h('b', {}, enMiles(r.miles)), ` (${enKm(r.miles)}) · ${enHeures(r.minutes)} de marche`,
          r.minutes > HEURES_PAR_JOUR * 60 ? ` · ${enJours(r.minutes)} en journées de 8 h` : '',
          r.difficile ? ' · terrain difficile sur une partie du trajet (temps doublé)' : ''),
        h('div', { class: 'bn-groupe' }, btn));
    }

    function vueVoyage(j, vy) {
      if (vy?.libre) {
        const buts = [j.vers, ...(j.lieux || [])].filter((x, i, t) => x && t.indexOf(x) === i);
        return h('p', { class: 'cm-lieu' }, icone('lu-route', 'bn-icone--s'), h('span', {}, h('b', {}, 'Itinéraire libre'),
          j.de ? ` depuis ${nomLieu(lieux, j.de)}` : '', buts.length ? ` vers ${buts.map(id => nomLieu(lieux, id)).join(', ')}` : '',
          ' : les joueurs choisissent leur route, à suivre dans le widget Trajets.'));
      }
      if (vy) return vy.routes.map(vueRoute);
      return j.type === 'trajet' && (j.de || j.vers) ? h('p', { class: 'cm-lieu' }, icone('lu-route', 'bn-icone--s'), [j.de, j.vers].filter(Boolean).map(id => nomLieu(lieux, id)).join(' → ')) : null;
    }

    // Destination d'une amorce (ou d'un jalon qui envoie ailleurs sans route) : démarrer le trajet depuis le lieu des héros.
    function vueVers(j) {
      const it = itineraireVers(j.vers);
      const btn = it ? bouton('Démarrer le trajet', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-route', titre: `Choisir le rythme et partir : ${it.map(id => nomLieu(lieux, id)).join(' → ')}`, onclick: () => demarrerTrajet(it, btn) }) : null;
      return h('div', { class: 'cm-contexte' }, h('p', { class: 'cm-lieu' }, icone('lu-arrow-right', 'bn-icone--s'), h('span', {}, 'Envoie vers ', lienLieu(j.vers))), btn);
    }

    // Statut d'affichage d'un jalon : en cours ou terminé (son suivi), sinon d'après son étape : en cours (« suivant » : à
    // faire maintenant), terminée (« passé »), ou à venir.
    function statutAffiche(j) {
      const st = statut('jalon', j.id);
      if (st !== 'a-venir') return st === 'termine' ? 'termine' : 'en-cours';
      const se = statut('etape', j.etape);
      return se === 'en-cours' ? 'suivant' : se === 'termine' ? 'passe' : 'a-venir';
    }

    // Pistes liées à un jalon : il les commence, les termine, ou elles s'y manifestent.
    const pistesDuJalon = j => (d.pistes || []).filter(p => p.debut?.jalon === j.id || p.fin?.jalon === j.id || (p.manifestations || []).some(m => m.jalon === j.id));

    function contenuJalon(j) {
      const vy = voyageDuJalon(j);
      const lies = pistesDuJalon(j).filter(visible);
      const role = p => [p.debut?.jalon === j.id ? 'la commence' : null, p.fin?.jalon === j.id ? 'la termine' : null,
        (p.manifestations || []).some(m => m.jalon === j.id) ? 's\'y manifeste' : null].filter(Boolean).join(', ');
      return h('div', { class: 'cm-pile cm-fiche-jalon' },
        j.personnage ? lignePerso(j.personnage) : null,
        blocRemarque('jalon', j),
        h('p', { class: 'texte' }, j.description),
        j.declencheur ? h('p', { class: 'ui cm-fiche-jalon__quand' }, icone('lu-clock', 'bn-icone--s'), h('span', {}, j.declencheur)) : null,
        j.lieu ? h('p', { class: 'cm-lieu' }, icone('epingle', 'bn-icone--s'), lienLieu(j.lieu, j.sous_lieu)) : null,
        j.vers && !vy && j.type !== 'trajet' ? vueVers(j) : null,
        vueVoyage(j, vy),
        R.duJalon(j).length ? section('Rencontres prévues', 'lu-swords', listeRencontres(R.duJalon(j))) : null,
        O.duJalon(j).length ? section('Objets', 'amulette', O.liste(O.duJalon(j))) : null,
        j.pnj?.length ? section('PNJ', 'lu-users', listePnj(j.pnj)) : null,
        j.lieux?.length ? section('Autres lieux', 'epingle', h('p', { class: 'cm-tenanciers' }, j.lieux.map(id => lienLieu(id)))) : null,
        lies.length ? section('Pistes', ICONE_PISTE, h('ul', { class: 'cm-liste ui cm-liens-pistes' }, lies.map(p => h('li', {}, lienPiste(p), h('span', { class: 'ui-s cm-sourdine' }, ` · ${role(p)}`))))) : null,
        decision(j),
        blocOriginal(j.original),
        pages(j));
    }

    // Une ligne par jalon ; un clic ouvre son détail dans une fenêtre flottante. La ligne n'est pas un bouton (le nom du PJ en
    // est un autre) : le nom porte le focus clavier. Le déclencheur, en petit, sous le nom.
    function vueJalon(j) {
      const st = statutAffiche(j);
      const vy = voyageDuJalon(j);
      return lienFlottant(h('div', { class: `bn-jalon bn-jalon--${st} cm-ouvre`, 'data-jalon': j.id, onclick: () => ouvrirJalon(j) },
        h('span', { class: 'bn-jalon__icone', title: libelleType(j.type) }, icone(ICONES_JALON[j.type] || 'lu-info', 'bn-icone--s')),
        h('span', { class: 'bn-jalon__nom cm-ouvre__nom' }, j.personnage ? lienPerso(j.personnage) : null, h('button', { type: 'button', class: 'bn-jalon__bouton' }, j.nom),
          vy && resumeVoyage(vy) ? h('span', { class: 'bn-jalon__meta' }, ` · ${resumeVoyage(vy)}`) : null,
          R.duJalon(j).length ? h('span', { class: 'bn-jalon__meta', title: 'Rencontres prévues' }, ' · ', icone('lu-swords', 'bn-icone--s'), ` ${R.duJalon(j).length}`) : null,
          O.duJalon(j).length ? h('span', { class: 'bn-jalon__meta', title: 'Objets à trouver' }, ' · ', icone('amulette', 'bn-icone--s'), ` ${O.duJalon(j).length}`) : null,
          marqueRemarque('jalon', j),
          j.declencheur ? h('span', { class: 'bn-jalon__declencheur' }, icone('lu-clock', 'bn-icone--s'), j.declencheur) : null),
        h('span', { class: 'cm-etape__badges' },
          st === 'en-cours' ? badge('En cours', 'soleil') : null,
          st === 'termine' ? badge('Terminé', 'brume', 'lu-check') : null,
          Restes.symbole({ jalon: j.id }, { genre: 'jalon', id: j.id, nom: j.nom }),
          j.facultatif && st !== 'termine' ? badge('Facultatif', null) : null)), 'jalon:' + j.id);
    }

    // Détail d'un jalon dans une fenêtre flottante ; redessiné quand son suivi change.
    // depuis : sa ligne, quand un autre widget l'ouvre (la fenêtre se place près d'elle, pas près du clic).
    function ouvrirJalon(j, depuis = null) {
      const st = statut('jalon', j.id);
      const etape = etapeParId.get(j.etape);
      flottant('jalon:' + j.id, {
        surtitre: [libelleType(j.type), st !== 'a-venir' ? libStatut('jalon', st) : null, j.facultatif ? 'facultatif' : null, etape ? `étape ${etape.ordre} : ${etape.nom}` : null].filter(Boolean).join(' · '),
        titre: j.nom,
        largeur: 520,
        pictogramme: ICONES_JALON[j.type] || 'lu-info',
        contenu: [contenuJalon(j), boutonsJalon(j)],
        depuis,
      });
    }

    // Un jalon se met en cours (plusieurs peuvent l'être) et se termine, sans changer l'étape ni déplacer les héros.
    function boutonsJalon(j) {
      const st = statut('jalon', j.id);
      return h('div', { class: 'bn-groupe cm-fiche-jalon__pied' },
        R.boutonNouvelle({ jalon: j.id }, { libelle: 'Rencontre' }),
        O.boutonNouveau({ jalon: j.id }),
        boutonRemarque('jalon', j),
        st === 'a-venir' ? bouton('Marquer en cours', { classe: 'bn-btn--s', icone: 'lu-play', onclick: () => { commencer(v(), 'jalon', j.id); enregistrer(); apresJalon(j, false); } })
          : st === 'en-cours' ? bouton('Plus en cours', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'Le jalon redevient à venir', onclick: () => { oublier(v(), 'jalon', j.id); enregistrer(); } }) : null,
        st === 'termine'
          ? bouton('Rouvrir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Ce n\'est pas terminé : le jalon redevient en cours', onclick: () => { rouvrir(v(), 'jalon', j.id); enregistrer(); } })
          : bouton('Marquer terminé', { classe: 'bn-btn--s', icone: 'lu-check', titre: 'Le jalon est fait (et compte comme commencé)', onclick: () => terminerJalon(j) }));
    }

    // ───── Pistes ─────

    // Ce que le widget propose pour une piste : la commencer (son jalon de début est commencé ou terminé), la terminer (son
    // jalon de fin est terminé).
    function propositionPiste(p) {
      const st = statut('piste', p.id);
      if (st === 'a-venir' && p.debut?.jalon && statut('jalon', p.debut.jalon) !== 'a-venir') return 'commencer';
      if (st === 'en-cours' && p.fin?.jalon && statut('jalon', p.fin.jalon) === 'termine') return 'terminer';
      return null;
    }

    // Le rappel discret d'une piste sous son étape ; un clic ouvre sa fenêtre.
    function lignePiste(p, rappel = false) {
      const st = statut('piste', p.id);
      const prop = propositionPiste(p);
      return lienFlottant(h('div', { class: `bn-jalon bn-jalon--piste bn-jalon--${st === 'a-venir' ? 'a-venir' : st}${rappel ? ' bn-jalon--rappel' : ''} cm-ouvre`,
        'data-piste': rappel ? null : p.id, onclick: () => ouvrirPiste(p) },
        h('span', { class: 'bn-jalon__icone', title: rappel ? 'Piste ouverte par cette étape' : 'Piste' }, icone(ICONE_PISTE, 'bn-icone--s')),
        h('span', { class: 'bn-jalon__nom cm-ouvre__nom' }, p.personnage ? lienPerso(p.personnage) : null, h('button', { type: 'button', class: 'bn-jalon__bouton' }, p.nom)),
        h('span', { class: 'cm-etape__badges' }, badgesPiste(p, prop, st, !rappel))), 'piste:' + p.id);
    }

    function badgesPiste(p, prop, st, avecFacultatif) {
      return [
        prop ? h('span', { title: prop === 'commencer' ? 'Son jalon de début est arrivé' : 'Son jalon de fin est terminé' }, badge(prop === 'commencer' ? 'À commencer ?' : 'À terminer ?', 'cierge')) : null,
        st === 'en-cours' ? badge('Commencée', 'soleil') : null,
        st === 'termine' ? badge('Terminée', 'brume', 'lu-check') : null,
        Restes.symbole({ piste: p.id }, { genre: 'piste', id: p.id, nom: p.nom }),
        p.facultatif && st !== 'termine' && avecFacultatif ? badge('Facultatif', null) : null,
      ].filter(Boolean);
    }

    // Une résurgence (une « manifestation » des données) : son texte, et son renvoi (étape, jalon, lieu ou trajet).
    // etape : le lien vers l'étape, en entier (d'office), ou court dans la vue normale du tableau.
    const renvoiManifestation = (m, etape = lienEtape) => (m.etape ? etape(m.etape) : m.jalon ? lienJalon(m.jalon) : m.lieu ? h('span', {}, icone('epingle', 'bn-icone--s'), ' ', lienLieu(m.lieu)) : m.trajet ? lienTrajet(m.trajet) : null);
    // Une résurgence jouée (demande du MJ, 2026-11-05) : cochée d'un clic, d'où qu'on la voie (fenêtre de la piste, « À garder
    // en tête », arbre d'une étape, ce qui reste). La jouer commence la piste si elle ne l'était pas.
    const jouee = (p, m) => resurgenceJouee(v(), p.id, m);
    function basculerResurgence(p, m) {
      const oui = !jouee(p, m);
      jouerResurgence(v(), p.id, m, oui);
      if (oui && statut('piste', p.id) === 'a-venir') commencer(v(), 'piste', p.id);
      enregistrer();
    }
    const caseResurgence = (p, m) => h('button', { type: 'button', class: 'cm-res-jouee', 'aria-pressed': String(jouee(p, m)),
      'aria-label': jouee(p, m) ? 'Jouée : un clic l\'annule' : 'Marquer cette résurgence jouée', title: jouee(p, m) ? 'Jouée : un clic l\'annule' : 'Marquer cette résurgence jouée',
      onclick: ev => { ev.stopPropagation(); basculerResurgence(p, m); } }, icone('lu-check'));
    // Sa remarque (jouée ou non : ce qui s'est passé, ou pourquoi on l'a sautée) : un crayon, et le texte dessous.
    const crayon = (p, m) => crayonResurgence(v(), p, m, () => saisirRemarqueResurgence(dialogue, v(), p, m, enregistrer));
    const texteRemarque = (p, m) => { const r = remarqueResurgence(v(), p.id, m); return r ? h('span', { class: 'cm-res-remarque' }, icone('livre', 'bn-icone--s'), ' ', r.texte) : null; };
    function vueManifestation(p, m) {
      const renvoi = renvoiManifestation(m);
      return h('li', { class: jouee(p, m) ? 'est-jouee' : '' }, caseResurgence(p, m),
        h('span', {}, m.texte, renvoi ? h('span', { class: 'cm-manifestation__renvoi' }, renvoi) : null, texteRemarque(p, m)), crayon(p, m));
    }

    function contenuPiste(p) {
      const prop = propositionPiste(p);
      // Le début et la fin : leur texte, leur jalon, et la remarque du MJ (un crayon, comme pour une résurgence).
      const bout = (quel, b) => h('p', { class: 'ui cm-piste__bout' }, h('b', {}, `${BOUTS_PISTE[quel]} : `), b?.texte || '—', b?.jalon ? h('span', { class: 'cm-manifestation__renvoi' }, lienJalon(b.jalon)) : null,
        ' ', crayon(p, boutDePiste(p, quel)), texteRemarque(p, boutDePiste(p, quel)));
      return h('div', { class: 'cm-pile cm-fiche-jalon' },
        p.personnage ? lignePerso(p.personnage) : null,
        blocRemarque('piste', p),
        prop === 'commencer' ? alerte('cierge', ICONE_PISTE, 'Son début est arrivé', `« ${jalonParId.get(p.debut.jalon)?.nom} » est ${libStatut('jalon', statut('jalon', p.debut.jalon))} : la commencer ?`) : null,
        prop === 'terminer' ? alerte('cierge', ICONE_PISTE, 'Sa fin est arrivée', `« ${jalonParId.get(p.fin.jalon)?.nom} » est terminé : la terminer ?`) : null,
        h('p', { class: 'texte' }, p.description),
        bout('debut', p.debut),
        bout('fin', p.fin),
        p.manifestations?.length ? section('Résurgences : où la faire reparaître', ICONE_PISTE, h('ul', { class: 'cm-liste ui cm-manifestations' }, p.manifestations.map(m => vueManifestation(p, m)))) : null,
        rencontresDeLaPiste(p).length ? section('Rencontres liées', 'lu-swords', listeRencontres(rencontresDeLaPiste(p))) : null,
        p.pnj?.length ? section('PNJ', 'lu-users', listePnj(p.pnj)) : null,
        p.lieux?.length ? section('Lieux', 'epingle', h('p', { class: 'cm-tenanciers' }, p.lieux.map(id => lienLieu(id)))) : null,
        decision(p),
        blocOriginal(p.original),
        pages(p));
    }

    function ouvrirPiste(p, depuis = null) {
      const st = statut('piste', p.id);
      const etape = etapeParId.get(p.etape);
      flottant('piste:' + p.id, {
        surtitre: ['Piste', st !== 'a-venir' ? libStatut('piste', st) : null, p.facultatif ? 'facultative' : null, etape ? `s'ouvre à l'étape ${etape.ordre} : ${etape.nom}` : null].filter(Boolean).join(' · '),
        titre: p.nom,
        largeur: 520,
        pictogramme: ICONE_PISTE,
        contenu: [contenuPiste(p), boutonsPiste(p)],
        depuis,
      });
    }

    function boutonsPiste(p) {
      const st = statut('piste', p.id);
      const agir = fn => () => { fn(v(), 'piste', p.id); enregistrer(); };
      return h('div', { class: 'bn-groupe cm-fiche-jalon__pied' },
        boutonRemarque('piste', p),
        st === 'a-venir' ? bouton('Commencer', { classe: 'bn-btn--s', icone: 'lu-play', onclick: agir(commencer) }) : null,
        st === 'en-cours' ? bouton('Terminer', { classe: 'bn-btn--s', icone: 'lu-check', titre: 'Elle ne sert plus', onclick: () => terminerPiste(p) }) : null,
        st === 'en-cours' ? bouton('Plus commencée', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'La piste redevient à venir', onclick: agir(oublier) }) : null,
        st === 'termine' ? bouton('Rouvrir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Elle sert encore : la piste redevient commencée', onclick: agir(rouvrir) }) : null);
    }

    // Sous chaque étape : ses jalons, puis le rappel de ses pistes.
    function vueSousEtape(e) {
      const js = jalonsDe.get(e.id).filter(visible);
      const ps = pistesDe.get(e.id).filter(visible);
      return js.length || ps.length ? h('div', { class: 'bn-jalons bn-jalons--frise' }, js.map(vueJalon), ps.map(p => lignePiste(p, true))) : null;
    }

    // Fenêtres ouvertes : redessinées quand le suivi change.
    function rafraichirFenetres() {
      sansRamener(() => {
        (d.jalons || []).filter(j => flottantOuvert('jalon:' + j.id)).forEach(j => ouvrirJalon(j));
        (d.pistes || []).filter(p => flottantOuvert('piste:' + p.id)).forEach(p => ouvrirPiste(p));
        etapes.filter(e => flottantOuvert('jalons-cles:' + e.id)).forEach(ouvrirJalonsCles);
        etapes.filter(e => flottantOuvert('arbre:' + e.id)).forEach(ouvrirArbre);
        if (flottantOuvert('deroule:pistes')) ouvrirPistesAGarder();
      });
    }

    // ───── « À garder en tête » : toutes les pistes en tableau, dans une fenêtre ouverte par un bouton de l'en-tête (même widget réduit) ─────
    // Pensé pour répondre vite à « que dois-je faire vivre maintenant ? » (demande du MJ, 2026-11-02) : les pistes rangées en
    // groupes, de la plus urgente à la moins : à jouer maintenant (une résurgence dans ce qui est en cours), à décider (la
    // commencer ou la terminer, d'un bouton), en veille (commencées, avec leur prochaine résurgence), à venir et terminées
    // repliées. Le groupe dit le statut : les tags ne disent plus que le joueur et ce qui sort de l'ordinaire. Les étapes en petits
    // carrés numérotés, comme dans la frise, leur nom en infobulle. Boutons des joueurs en haut ; « Étapes en cours » ne garde
    // que les deux premiers groupes. Colonnes triables, d'office les pistes des joueurs d'abord. Vue normale : sans les textes
    // de départ et de fin ; vue détaillée : tous les textes. Dans la frise, chaque étape garde le rappel discret de ses pistes.
    function pistesAGarder() {
      const liste = pistesDansLOrdre.filter(visible);
      const etapesActives = new Set(etapesEnCours().map(e => e.id));
      const commencees = liste.filter(p => statut('piste', p.id) === 'en-cours');
      return {
        liste,
        ailleurs: commencees.filter(p => !etapesActives.has(p.etape)),
        ici: commencees.filter(p => etapesActives.has(p.etape)),
        aCommencer: liste.filter(p => propositionPiste(p) === 'commencer'),
      };
    }
    // Résurgences à jouer maintenant : celles d'une étape en cours, d'un jalon en cours (ou à venir d'une étape en cours), du
    // lieu où sont les héros ou d'une route qui en part. Les autres (libres, à venir, passées) : repliées.
    function resurgences(p) {
      const actives = new Set(etapesEnCours().map(e => e.id));
      const ici = sIci.valeur.lieu;
      const aJouer = m => {
        if (m.etape) return actives.has(m.etape);
        if (m.jalon) {
          const st = statut('jalon', m.jalon);
          return st === 'en-cours' || (st === 'a-venir' && actives.has(jalonParId.get(m.jalon)?.etape));
        }
        if (m.lieu) return !!ici && (m.lieu === ici || m.lieu === sIci.valeur.sous_lieu);
        if (m.trajet) { const t = trajets.get(m.trajet); return !!ici && (t?.de === ici || t?.vers === ici); }
        return false;
      };
      // Une résurgence jouée n'est plus à jouer : elle passe avec les autres.
      const toutes = p.manifestations || [];
      const active = m => aJouer(m) && !jouee(p, m);
      return { actives: toutes.filter(active), autres: toutes.filter(m => !active(m)) };
    }
    const GROUPES_PISTES = [
      { id: 'jouer', titre: 'À jouer maintenant', icone: 'lu-play', ton: 'sang', aide: 'Commencées, avec une résurgence dans ce qui est en cours : étapes, jalons, lieu des héros' },
      { id: 'decider', titre: 'À décider', icone: 'lu-circle-help', ton: 'cierge', aide: 'À commencer (son jalon de début est arrivé, ou son étape est en cours) ou à terminer (son jalon de fin est terminé)' },
      { id: 'veille', titre: 'En veille', icone: 'lu-clock', aide: 'Commencées, rien à jouer ici et maintenant : leur prochaine résurgence' },
      { id: 'venir', titre: 'À venir', icone: 'sablier', aide: 'Pas encore commencées, rien ne les appelle' },
      { id: 'finies', titre: 'Terminées', icone: 'lu-check', aide: 'Elles ne servent plus' },
    ];
    function groupeDePiste(p) {
      const st = statut('piste', p.id);
      if (st === 'termine') return 'finies';
      if (propositionPiste(p)) return 'decider';
      if (st === 'a-venir') return statut('etape', p.etape) === 'en-cours' ? 'decider' : 'venir';
      return resurgences(p).actives.length ? 'jouer' : 'veille';
    }
    // La prochaine résurgence : celle de l'étape à venir la plus proche.
    function prochaineResurgence(p) {
      const etapeDe = m => m.etape || (m.jalon && statut('jalon', m.jalon) !== 'termine' ? jalonParId.get(m.jalon)?.etape : null);
      return resurgences(p).autres.map(m => ({ m, id: etapeDe(m) })).filter(x => x.id && statut('etape', x.id) === 'a-venir')
        .sort((a, b) => ordreEtape(a.id) - ordreEtape(b.id))[0] || null;
    }
    const filtrePistes = { enCours: false };
    const groupesPliesPistes = new Set(['venir', 'finies']);
    const triPistes = { cle: 'joueurs', inverse: false };
    const CLE_VUE_PISTES = 'cm:pistes:vue';
    let vuePistes = 'normale';
    try { if (localStorage.getItem(CLE_VUE_PISTES) === 'detaillee') vuePistes = 'detaillee'; } catch { /* pas de stockage : vue normale */ }
    const LARGEURS_PISTES = { normale: 1040, detaillee: 1240 };
    const ordreEtape = id => etapeParId.get(id)?.ordre ?? Infinity;
    const rangJoueur = p => (p.personnage ? quetes.indexOf(p.personnage) : Infinity);
    const TRIS_PISTES = {
      joueurs: (a, b) => rangJoueur(a) - rangJoueur(b) || ordreEtape(a.etape) - ordreEtape(b.etape),
      nom: (a, b) => a.nom.localeCompare(b.nom, 'fr'),
      depart: (a, b) => ordreEtape(a.etape) - ordreEtape(b.etape),
      resurgences: (a, b) => resurgences(b).actives.length - resurgences(a).actives.length || ordreEtape(a.etape) - ordreEtape(b.etape),
      fin: (a, b) => ordreEtape(jalonParId.get(a.fin?.jalon)?.etape) - ordreEtape(jalonParId.get(b.fin?.jalon)?.etape),
    };
    // Un clic trie par la colonne, un second inverse.
    function enteteTri(cle, libelle, ic, titre) {
      return h('button', { type: 'button', class: 'cm-tri cm-tri--entete', 'aria-pressed': String(triPistes.cle === cle), title: titre, onclick: () => {
        if (triPistes.cle === cle) triPistes.inverse = !triPistes.inverse;
        else { triPistes.cle = cle; triPistes.inverse = false; }
        sansRamener(ouvrirPistesAGarder);
      } }, h('span', {}, libelle), icone(ic, 'bn-icone--s'));
    }
    // Une étape en petit carré numéroté, comme dans la frise : en rouge en cours, en bleu terminée. Son nom en infobulle ; un
    // clic l'amène en vue dans la frise.
    const carreEtape = id => {
      const e = etapeParId.get(id);
      if (!e) return null;
      return infobulle(h('button', { type: 'button', class: `cm-carre cm-carre--${statut('etape', id)}`, 'aria-label': `Étape ${e.ordre} : ${e.nom}`,
        onclick: () => voir(e.id, `.cm-etape[data-id="${CSS.escape(e.id)}"]`, !etapeVisible(e)) }, e.ordre), e.nom, { titre: `Étape ${e.ordre} · ${LIBELLES_STATUT.etape[statut('etape', id)]}` });
    };
    // Une résurgence : le carré de son étape, son texte, son autre renvoi s'il en a un.
    const ligneResurgence = (p, m) => h('li', { class: 'cm-pistes__res' + (jouee(p, m) ? ' est-jouee' : '') }, caseResurgence(p, m), m.etape ? carreEtape(m.etape) : null,
      h('span', {}, m.texte, !m.etape && renvoiManifestation(m) ? h('span', { class: 'cm-manifestation__renvoi' }, renvoiManifestation(m)) : null, texteRemarque(p, m)), crayon(p, m));
    const listeResurgences = (p, ms) => h('ul', { class: 'cm-pistes__liste-res ui-s' }, ms.map(m => ligneResurgence(p, m)));
    // Un bout de la piste (départ, fin) : le carré d'une étape, le jalon s'il y en a un, le texte en vue détaillée.
    const boutPiste = (etape, b, detail, p = null, quel = null) => {
      const lien = b?.jalon ? lienJalon(b.jalon) : null;
      const texte = detail && b?.texte ? h('p', { class: 'ui-s cm-pistes__texte' }, b.texte) : null;
      const rq = detail && p ? texteRemarque(p, boutDePiste(p, quel)) : null;
      return [etape || lien ? h('div', { class: 'cm-pistes__bout ui-s' }, carreEtape(etape), lien) : null, texte, rq ? h('p', { class: 'ui-s' }, rq) : null];
    };
    // La case du milieu : ce qu'il y a à faire, selon le groupe de la piste.
    function casePiste(p, groupe, detail) {
      const { actives, autres } = resurgences(p);
      const libres = autres.filter(m => !m.etape && !m.jalon && !m.lieu && !m.trajet).length;
      const reste = detail && autres.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'ui-s cm-sourdine' }, `Les autres (${autres.length})`), listeResurgences(p, autres)) : null;
      if (groupe === 'jouer') return [listeResurgences(p, actives), reste];
      if (groupe === 'decider') {
        const prop = propositionPiste(p);
        return [
          h('div', { class: 'cm-pistes__decision' },
            prop === 'terminer'
              ? [h('span', { class: 'ui-s' }, 'Son jalon de fin est terminé.'), bouton('Terminer', { classe: 'bn-btn--s', icone: 'lu-check', onclick: () => terminerPiste(p) })]
              : [h('span', { class: 'ui-s' }, prop === 'commencer' ? 'Son jalon de début est arrivé.' : 'Son étape est en cours.'), bouton('Commencer', { classe: 'bn-btn--s', icone: 'lu-play', onclick: () => { commencer(v(), 'piste', p.id); enregistrer(); } })]),
          actives.length ? listeResurgences(p, actives) : null,
          reste,
        ];
      }
      if (groupe === 'veille') {
        const suite = prochaineResurgence(p);
        return [
          suite ? h('div', { class: 'cm-pistes__suite ui-s' }, h('span', { class: 'cm-sourdine' }, 'Prochaine :'), carreEtape(suite.id), detail ? h('span', {}, suite.m.texte) : null) : null,
          !detail && libres ? h('p', { class: 'ui-s cm-sourdine' }, `${libres} à tout moment`) : null,
          !suite && !libres && !detail ? h('p', { class: 'ui-s cm-sourdine' }, '—') : null,
          reste,
        ];
      }
      return detail ? reste : null;
    }
    function lignePisteTableau(p, groupe) {
      const st = statut('piste', p.id);
      const detail = vuePistes === 'detaillee';
      const etapeFin = jalonParId.get(p.fin?.jalon)?.etape;
      return lienFlottant(h('tr', { 'data-piste': p.id, class: st === 'termine' ? 'est-terminee' : null },
        h('td', {}, h('div', { class: 'cm-pistes__tags' }, p.personnage ? lienPerso(p.personnage) : null,
          p.facultatif && st !== 'termine' ? badge('Facultatif', null) : null,
          Restes.symbole({ piste: p.id }, { genre: 'piste', id: p.id, nom: p.nom }))),
        h('td', { class: 'cm-pistes__nom' }, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPiste(p) }, p.nom), marqueRemarque('piste', p)),
        h('td', {}, boutPiste(p.etape, p.debut, detail, p, 'debut')),
        h('td', {}, casePiste(p, groupe, detail)),
        h('td', {}, boutPiste(etapeFin, p.fin, detail, p, 'fin'))), 'piste:' + p.id);
    }
    function ouvrirPistesAGarder() {
      const liste = pistesDansLOrdre.filter(visible).sort(TRIS_PISTES[triPistes.cle]);
      if (triPistes.inverse) liste.reverse();
      const refiltrer = () => sansRamener(ouvrirPistesAGarder);
      const groupes = GROUPES_PISTES.filter(g => !filtrePistes.enCours || g.id === 'jouer' || g.id === 'decider')
        .map(g => ({ ...g, pistes: liste.filter(p => groupeDePiste(p) === g.id) })).filter(g => g.pistes.length);
      const f = flottant('deroule:pistes', {
        surtitre: ['Déroulé · pistes', filtre ? `quête ${deNom(nomPerso(filtre))}` : null].filter(Boolean).join(' · '),
        titre: 'À garder en tête',
        pictogramme: ICONE_PISTE,
        contenu: h('div', { class: 'cm-pile cm-pistes-ouvertes' },
          h('div', { class: 'cm-contexte cm-pistes__filtres' },
            quetes.length ? bascule('Joueur', [[null, 'Tous'], ...quetes.map(id => [id, nomPerso(id)])], filtre, id => filtrer(id)) : null,
            h('button', { type: 'button', class: 'bn-btn bn-btn--s', 'aria-pressed': String(filtrePistes.enCours), title: 'Seulement ce qui se joue maintenant : « À jouer maintenant » et « À décider »',
              onclick: () => { filtrePistes.enCours = !filtrePistes.enCours; refiltrer(); } }, icone('lu-locate-fixed'), h('span', {}, 'Étapes en cours')),
            h('span', { class: 'cm-pistes__vue' }, bascule('Vue', [['normale', 'Normale'], ['detaillee', 'Détaillée']], vuePistes, x => {
              vuePistes = x;
              try { localStorage.setItem(CLE_VUE_PISTES, x); } catch { /* le choix vaut pour la session */ }
              refiltrer();
            }))),
          groupes.length ? h('table', { class: `bn-table cm-pistes cm-pistes--${vuePistes}` },
            h('thead', {}, h('tr', {},
              h('th', {}, enteteTri('joueurs', 'Tags', 'lu-user', 'Trier : les pistes des joueurs d\'abord')),
              h('th', {}, enteteTri('nom', 'Piste', 'lu-arrow-down-a-z', 'Trier par nom')),
              h('th', {}, enteteTri('depart', 'Départ', 'lu-arrow-down-0-1', 'Trier par étape de départ')),
              h('th', {}, enteteTri('resurgences', 'Résurgences', 'lu-arrow-down-wide-narrow', 'Où la faire reparaître. Trier : celles qui en ont le plus à jouer d\'abord')),
              h('th', {}, enteteTri('fin', 'Fin', 'lu-arrow-down-0-1', 'Trier par étape de fin')))),
            groupes.map(g => {
              const plie = groupesPliesPistes.has(g.id);
              return h('tbody', {},
                h('tr', { class: `cm-pistes__groupe${g.ton ? ` cm-pistes__groupe--${g.ton}` : ''}` }, h('th', { colspan: 5, scope: 'rowgroup' },
                  h('button', { type: 'button', 'aria-expanded': String(!plie), title: g.aide, onclick: () => { if (plie) groupesPliesPistes.delete(g.id); else groupesPliesPistes.add(g.id); refiltrer(); } },
                    icone(plie ? 'lu-chevron-down' : 'lu-chevron-up', 'bn-icone--s'), icone(g.icone, 'bn-icone--s'), h('span', {}, g.titre), h('span', { class: 'cm-pistes__nombre' }, g.pistes.length)))),
                plie ? null : g.pistes.map(p => lignePisteTableau(p, g.id)));
            }))
            : h('p', { class: 'ui-s cm-sourdine' }, filtrePistes.enCours ? 'Rien à jouer ni à décider dans ce qui est en cours.' : 'Aucune piste.')),
      });
      f.el.style.width = `min(${LARGEURS_PISTES[vuePistes]}px, calc(100vw - 32px))`;
      return f;
    }

    // ───── Une étape en arbre ─────
    // Ses jalons, puis ce qu'ils portent ; ses pistes et leurs résurgences, avec les étapes où elles mènent. À l'essai (demande du
    // MJ, 2026-11-02). Un clic sur un nom ouvre l'élément ; le « − » replie sa branche.
    const choixArbre = new Map();   // étape → Map(nœud → replié)
    const tonDe = st => (st === 'termine' ? 'fait' : st === 'en-cours' ? 'en-cours' : null);
    const courtDe = (txt, n = 90) => (txt && txt.length > n ? txt.slice(0, n - 1).trim() + '…' : txt);
    const rubrique = (id, nom, ic, enfants, replie = false) => (enfants.length ? { id, nom, icone: ic, groupe: true, enfants, replie } : null);
    const noeudRencontre = (cle, vue) => ({ id: `${cle}/r:${vue.id}`, nom: vue.nom, icone: 'lu-swords', ton: vue.statut === 'terminee' ? 'fait' : vue.statut === 'en-cours' ? 'en-cours' : null, detail: vue.statut === 'terminee' ? 'jouée' : null, ouvrir: () => R.ouvrir(vue.id), compte: { cle: 'r:' + vue.id, fait: vue.statut === 'terminee' },
      enfants: [...O.deLaRencontre(vue.id).map(o => noeudObjet(`${cle}/r:${vue.id}`, o)), vue.e?.remarque ? { id: `${cle}/r:${vue.id}/rq`, nom: courtDe(vue.e.remarque), icone: 'livre' } : null] });
    const noeudObjet = (cle, o) => ({ id: `${cle}/o:${o.id}`, nom: o.nom, icone: 'amulette', ton: o.statut === 'donne' ? 'fait' : null, detail: o.statut === 'donne' ? 'donné' : null, ouvrir: () => O.ouvrir(o.id), compte: { cle: 'o:' + o.id, fait: o.statut === 'donne' } });
    const noeudPnj = (cle, id) => {
      const p = pnj.get(id);
      if (!p) return null;
      const vu = !!(sPnj && suiviDe(sPnj, id).rencontre);
      return { id: `${cle}/p:${id}`, nom: p.nom, icone: 'crocs', ton: vu ? 'fait' : null, detail: [vu ? 'rencontré' : null, courtDe(p.role, 40)].filter(Boolean).join(' · '), ouvrir: () => ouvrirPnj(p), compte: { cle: 'p:' + id, fait: vu } };
    };
    const noeudLieu = (cle, id, sous) => (lieux.has(id) ? { id: `${cle}/l:${id}`, nom: nomComplet(lieux, id, sous), icone: 'epingle' } : null);
    // L'état d'une résurgence vue depuis l'étape `ici` (retours du MJ, 2026-11-05) : 'jouee' (de cette étape, jouée : bleu),
    // 'a-jouer' (de cette étape, pas jouée : orange), 'retard' (d'une étape d'avant ou terminée, jamais jouée, sa piste
    // commencée : rouge), 'passee' (jouée ailleurs, ou sa piste est terminée : en sourdine), 'ailleurs' (à venir, ou libre).
    function etatResurgence(p, m, ici) {
      const idE = etapeDeResurgence(m, jalonParId);
      const faite = jouee(p, m);
      const stP = statut('piste', p.id);
      if (idE === ici.id) return faite ? 'jouee' : stP === 'termine' ? 'passee' : 'a-jouer';
      if (faite || stP === 'termine') return 'passee';
      if (idE && stP === 'en-cours' && (ordreEtape(idE) < ici.ordre || statut('etape', idE) === 'termine')) return 'retard';
      return 'ailleurs';
    }
    const TON_RESURGENCE = { jouee: 'fait', 'a-jouer': 'a-jouer', retard: 'alerte', passee: 'discret', ailleurs: 'discret' };
    // Une résurgence : son texte, où elle mène (une autre étape, un jalon) quand ce n'est pas ici, et sa case « jouée ».
    // Celles de cette étape comptent dans les carrés ; celles d'ailleurs, non.
    function noeudResurgence(cle, p, m, i, ici) {
      const e = etapeParId.get(etapeDeResurgence(m, jalonParId)) || null;
      const jalon = m.jalon ? jalonParId.get(m.jalon) : null;
      const et = etatResurgence(p, m, ici);
      const faite = jouee(p, m);
      const rq = remarqueResurgence(v(), p.id, m);
      const detail = [e && e.id !== ici.id ? `étape ${e.ordre}` : null, jalon?.nom, m.lieu ? nomLieu(lieux, m.lieu) : null,
        faite ? 'jouée' : et === 'retard' ? 'aurait dû être jouée' : et === 'a-jouer' ? 'à jouer ici' : null].filter(Boolean).join(' · ');
      return { id: `${cle}/m:${i}`, nom: courtDe(m.texte), icone: 'lu-arrow-right', detail, ton: TON_RESURGENCE[et],
        essentiel: et === 'a-jouer' || et === 'retard',
        compte: et === 'jouee' || et === 'a-jouer' ? { cle: `m:${p.id}:${cleResurgence(m)}`, fait: et === 'jouee' } : null,
        actions: [
          { icone: 'lu-pencil', actif: !!rq, titre: rq ? 'Modifier la remarque sur cette résurgence' : 'Ajouter une remarque sur cette résurgence', fn: () => saisirRemarqueResurgence(dialogue, v(), p, m, enregistrer) },
          { icone: 'lu-check', actif: faite, titre: faite ? 'Jouée : un clic l\'annule' : 'Marquer cette résurgence jouée', fn: () => basculerResurgence(p, m) },
        ],
        enfants: rq ? [{ id: `${cle}/m:${i}/rq`, nom: courtDe(rq.texte), icone: 'livre' }] : [],
        ouvrir: jalon ? () => ouvrirJalon(jalon) : e && e.id !== ici.id ? () => ouvrirArbre(e) : null };
    }
    // La remarque du MJ sur le début ou la fin d'une piste : un nœud « livre », seulement si elle existe.
    function noeudBout(cle, p, quel) {
      const rq = remarqueResurgence(v(), p.id, boutDePiste(p, quel));
      return rq ? { id: `${cle}/${quel}`, nom: `${BOUTS_PISTE[quel]} : ${courtDe(rq.texte, 80)}`, icone: 'livre', ton: 'discret', ouvrir: () => saisirRemarqueResurgence(dialogue, v(), p, boutDePiste(p, quel), enregistrer) } : null;
    }
    // Une piste, vue depuis l'étape : repliée, elle montre ses résurgences à jouer ici (et celles en retard) ; dépliée, toutes.
    // Son cadre : rouge s'il y a du retard, orange s'il reste à jouer ici, bleu si tout ce qui était ici est joué. sienne : la
    // piste s'ouvre ou est attendue dans cette étape, elle compte elle-même (commencée ou non).
    function noeudPiste(cle, p, ici, sienne = false) {
      const ms = p.manifestations || [];
      const ets = ms.map(m => etatResurgence(p, m, ici));
      const n = x => ets.filter(y => y === x).length;
      const st = statut('piste', p.id);
      const ton = n('retard') ? 'alerte' : n('a-jouer') ? 'a-jouer' : n('jouee') ? 'fait' : st === 'termine' ? 'fait' : null;
      const detail = [p.personnage ? nomPerso(p.personnage) : null, libStatut('piste', st),
        n('a-jouer') ? `${n('a-jouer')} à jouer ici` : null, n('retard') ? `${n('retard')} en retard` : null].filter(Boolean).join(' · ');
      return { id: `${cle}/pi:${p.id}`, nom: p.nom, icone: ICONE_PISTE, ton, detail, ouvrir: () => ouvrirPiste(p), replie: true,
        compte: sienne ? { cle: 'pi:' + p.id, fait: st !== 'a-venir' } : null,
        enfants: [
          noeudBout(`${cle}/pi:${p.id}`, p, 'debut'),
          ...ms.map((m, i) => noeudResurgence(`${cle}/pi:${p.id}`, p, m, i, ici)),
          noeudBout(`${cle}/pi:${p.id}`, p, 'fin'),
        ].filter(Boolean) };
    }
    function noeudJalon(j, e) {
      const cle = `j:${j.id}`;
      const vus = pistesDuJalon(j);
      const rq = remarqueDe(v(), 'jalon', j.id);
      return { id: cle, nom: j.nom, icone: ICONES_JALON[j.type] || 'lu-info', ton: tonDe(statut('jalon', j.id)), detail: [libelleType(j.type), j.facultatif ? 'facultatif' : null, statut('jalon', j.id) !== 'a-venir' ? libStatut('jalon', statut('jalon', j.id)) : null].filter(Boolean).join(' · '), ouvrir: () => ouvrirJalon(j), compte: { cle: 'j:' + j.id, fait: statut('jalon', j.id) === 'termine' },
        enfants: [
          rq ? { id: `${cle}/rq`, nom: courtDe(rq.texte), icone: 'livre' } : null,
          j.lieu ? noeudLieu(cle, j.lieu, j.sous_lieu) : null,
          ...R.duJalon(j).filter(Boolean).map(r => noeudRencontre(cle, r)),
          ...O.duJalon(j).map(o => noeudObjet(cle, o)),
          ...(j.pnj || []).map(id => noeudPnj(cle, id)),
          ...vus.map(p => noeudPiste(cle, p, e)),
        ].filter(Boolean) };
    }
    function racineArbre(e) {
      const c = `e:${e.id}`;
      const js = jalonsDe.get(e.id);
      const dansJalons = new Set(js.flatMap(j => R.duJalon(j).filter(Boolean).map(r => r.id)));
      const surPlace = (e.lieux || []).flatMap(l => R.duLieu(l)).filter((x, i, t) => x && !dansJalons.has(x.id) && t.findIndex(y => y?.id === x.id) === i && rencontreDeLEtape(e, x));
      const objetsIci = (e.lieux || []).flatMap(l => O.duLieu(l)).filter((x, i, t) => !x.rattachement.jalon && !x.rattachement.rencontre && t.findIndex(y => y.id === x.id) === i && objetDeLEtape(e, x));
      const ouverts = pistesDe.get(e.id);
      const attendues = (e.pistes_attendues || []).map(pa => pisteParId.get(pa.piste)).filter(p => p && !ouverts.includes(p));
      const reviennent = (d.pistes || []).filter(p => !ouverts.includes(p) && !attendues.includes(p) && (p.manifestations || []).some(m => etapeDeResurgence(m, jalonParId) === e.id));
      const rq = remarqueDe(v(), 'etape', e.id);
      const parLieu = (e.lieux || []).filter(l => lieux.has(l));
      return { id: c, nom: `Étape ${e.ordre} : ${e.nom}`, icone: 'sablier', ton: tonDe(statut('etape', e.id)), detail: libStatut('etape', statut('etape', e.id)),
        enfants: [
          rq ? { id: `${c}/rq`, nom: courtDe(rq.texte), icone: 'livre' } : null,
          rubrique(`${c}/jalons`, 'Jalons', 'lu-list', js.filter(visible).map(j => noeudJalon(j, e))),
          rubrique(`${c}/renc`, 'Rencontres de l\'étape', 'lu-swords', [...R.deLEtape(e), ...surPlace].map(r => noeudRencontre(c, r))),
          rubrique(`${c}/obj`, 'Objets sur place', 'amulette', [...O.deLEtape(e), ...objetsIci].filter((x, i, t) => t.findIndex(y => y.id === x.id) === i).map(o => noeudObjet(c, o)), true),
          rubrique(`${c}/lieux`, 'Lieux et leurs PNJ', 'epingle', parLieu.map(l => ({ ...noeudLieu(c, l), replie: true, enfants: pnjDeLEtape(e, [l]).map(p => noeudPnj(`${c}/l:${l}`, p.id)).filter(Boolean) }))),
          rubrique(`${c}/pistes`, 'Pistes qui s\'ouvrent ici', ICONE_PISTE, ouverts.map(p => noeudPiste(c, p, e, true))),
          rubrique(`${c}/att`, 'Pistes attendues', ICONE_PISTE, attendues.map(p => noeudPiste(c, p, e, true)), true),
          rubrique(`${c}/rev`, 'Pistes qui reparaissent ici', ICONE_PISTE, reviennent.map(p => noeudPiste(c, p, e))),
        ].filter(Boolean) };
    }
    function ouvrirArbre(e) {
      if (!choixArbre.has(e.id)) choixArbre.set(e.id, new Map());
      const choix = choixArbre.get(e.id);
      flottant('arbre:' + e.id, {
        surtitre: `Étape ${e.ordre} · en arbre`, titre: e.nom, plein: true, pictogramme: 'lu-network',
        contenu: h('div', { class: 'cm-pile' },
          h('div', { class: 'bn-groupe' },
            bouton('Tout déplier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-chevron-down', onclick: () => {
              const racine = racineArbre(e);
              const tous = n => { (n.enfants || []).filter(Boolean).forEach(x => { choix.set(x.id, false); tous(x); }); };
              tous(racine);
              sansRamener(() => ouvrirArbre(e));
            } }),
            bouton('Tout replier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-chevron-up', onclick: () => {
              const tous = n => { (n.enfants || []).filter(Boolean).forEach(x => { choix.set(x.id, true); tous(x); }); };
              tous(racineArbre(e));
              sansRamener(() => ouvrirArbre(e));
            } })),
          h('div', { class: 'cm-arbre-zone' }, vueArbre(racineArbre(e), choix, () => sansRamener(() => ouvrirArbre(e))))),
      });
    }
    const comptePistes = h('span', { class: 'cm-btn-pistes__nombre', 'aria-hidden': 'true' });
    const btnPistes = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone bn-btn--fantome cm-btn-pistes', onclick: () => ouvrirPistesAGarder() }, icone(ICONE_PISTE), comptePistes);
    function majBoutonPistes() {
      const { liste, ailleurs, ici, aCommencer } = pistesAGarder();
      const n = ailleurs.length + ici.length;
      btnPistes.hidden = !liste.length;
      comptePistes.textContent = n ? String(n) : '';
      btnPistes.classList.toggle('est-ailleurs', !!ailleurs.length);
      const titre = `À garder en tête : ${n ? `${n} piste${n > 1 ? 's' : ''} commencée${n > 1 ? 's' : ''}` : 'aucune piste commencée'}${ailleurs.length ? ` (dont ${ailleurs.length} hors des étapes en cours)` : ''}${aCommencer.length ? ` · ${aCommencer.length} à commencer ?` : ''}. Cliquer : toutes les pistes`;
      btnPistes.title = titre;
      btnPistes.setAttribute('aria-label', titre);
    }

    // ───── En-tête : l'étape de référence (même widget réduit) et le bouton « Étape suivante » ─────

    const btnSuivant = bouton('', { icone: 'lu-arrow-right', classe: 'bn-btn--s', onclick: () => demarrer(suivante()) });

    // Cibler l'étape en cours la plus haute de la frise (widget déplié) : l'amener en haut du widget. Le clic sur le résumé,
    // lui, ramène à l'étape de référence (la dernière démarrée).
    const rangFrise = new Map(arcs.flatMap(a => a.etapes || []).map((id, i) => [id, i]));
    const plusHaute = () => etapesEnCours().sort((a, b) => (rangFrise.get(a.id) ?? Infinity) - (rangFrise.get(b.id) ?? Infinity))[0] || null;
    const btnCible = bouton('', { icone: 'lu-locate-fixed', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', onclick: () => {
      const e = plusHaute();
      if (e) voir(null, `.cm-etape[data-id="${CSS.escape(e.id)}"]`, !etapeVisible(e));
    } });

    // Filtre par PJ (widget déplié seulement) : un seul PJ a une quête, le bouton bascule ; plusieurs, il ouvre un menu.
    // Icône seule, enfoncée quand la frise est filtrée : la place va au résumé de l'étape, et chaque élément affiché porte le nom du PJ.
    const btnFiltre = bouton('', { icone: 'lu-user', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie' });
    function majFiltre() {
      const nom = filtre ? nomPerso(filtre) : null;
      btnFiltre.setAttribute('aria-pressed', String(!!filtre));
      const titre = filtre ? `Filtré : quête personnelle ${deNom(nom)}. Cliquer : ${quetes.length > 1 ? 'changer' : 'tout le déroulé'}`
        : quetes.length > 1 ? 'Filtrer la frise et les pistes : la quête personnelle d\'un personnage' : `Seulement la quête personnelle ${deNom(nomPerso(quetes[0]))}`;
      btnFiltre.title = titre;
      btnFiltre.setAttribute('aria-label', titre);
    }
    function filtrer(id) {
      filtre = id;
      majFiltre();
      defiler = true;   // retour à l'étape de référence, gardée dans la frise filtrée
      rendre();
    }
    const menuFiltre = quetes.length > 1 ? boutonMenu(btnFiltre, [
      ['Tout le déroulé', 'Tous les jalons et toutes les pistes', () => filtrer(null), () => !filtre],
      ...quetes.map(id => [`Quête ${deNom(nomPerso(id))}`, `Seulement les jalons et les pistes de la quête personnelle ${deNom(nomPerso(id))}`, () => filtrer(id), () => filtre === id]),
    ], 'Filtrer le déroulé par personnage')[1] : null;
    if (quetes.length === 1) btnFiltre.addEventListener('click', () => filtrer(filtre ? null : quetes[0]));
    if (quetes.length) majFiltre();
    actions.append(...[btnCible, quetes.length ? btnFiltre : null, menuFiltre, btnPistes, btnSuivant].filter(Boolean));

    function majEntete() {
      majBoutonPistes();
      const haute = plusHaute();
      btnCible.hidden = !haute;
      btnCible.title = haute ? `Aller à l'étape en cours la plus haute : ${haute.nom}` : '';
      btnCible.setAttribute('aria-label', btnCible.title);
      const f = focus();
      const autres = etapesEnCours().filter(e => e !== f);
      const js = jalonsDansLOrdre.filter(j => statut('jalon', j.id) === 'en-cours');
      const ensuite = suivante();
      const titreSuite = !ensuite ? '' : f ? `Étape suivante : ${ensuite.nom}` : `Démarrer : ${ensuite.nom}`;
      btnSuivant.hidden = !ensuite;
      btnSuivant.title = titreSuite;
      btnSuivant.setAttribute('aria-label', titreSuite);
      if (!f) { resume.replaceChildren(h('span', { class: 'cm-sourdine' }, 'Aucune étape en cours')); return; }
      const arc = arcs.find(a => a.id === f.arc);
      const fini = statut('etape', f.id) === 'termine';
      const haut = `Étape ${f.ordre} / ${etapes.length}${arc ? ` · ${arc.nom}` : ''}`;
      const bas = (fini ? '✓ ' : '') + f.nom + (autres.length ? ` +${autres.length}` : '') + (js.length === 1 ? ` › ${js[0].nom}` : js.length ? ` › ${js.length} jalons en cours` : '');
      const commencees = pistesDansLOrdre.filter(p => statut('piste', p.id) === 'en-cours');
      resume.replaceChildren(h('button', {
        type: 'button', class: 'bn-widget__resume-bouton',
        title: [haut, f.nom + (fini ? ' (terminée)' : ''),
          autres.length ? `Aussi en cours : ${autres.map(e => e.nom).join(', ')}` : null,
          js.length ? `Jalons en cours : ${js.map(j => j.nom).join(', ')}` : null,
          commencees.length ? `Pistes commencées : ${commencees.length}` : null,
          `Niveau ${f.niveau_groupe}${f.niveau_atteint ? ` → ${f.niveau_atteint}` : ''}`, 'Cliquer : voir dans le déroulé'].filter(Boolean).join('\n'),
        onclick: voirEnCours,
      }, h('span', { class: 'surtitre' }, haut), h('span', {}, bas)));
    }

    // fenetres : redessiner aussi les fenêtres ouvertes (et les ramener devant).
    function rendre({ fenetres = true } = {}) {
      const haut = corps.scrollTop;
      majEntete();
      const premiere = focus() ? null : suivante();
      corps.replaceChildren(...[
        premiere ? h('div', { class: 'bn-carte cm-deroule-resume' },
          h('p', { class: 'ui cm-sourdine' }, 'Aucune étape en cours.'),
          h('div', { class: 'bn-groupe' }, bouton(`Démarrer « ${premiere.nom} »`, { classe: 'bn-btn--s', icone: 'lu-play', onclick: () => demarrer(premiere) }))) : null,
        arcs.map(a => {
          const visibles = (a.etapes || []).map(id => etapeParId.get(id)).filter(e => e && etapeVisible(e));
          if (filtre && !visibles.length) return null;
          return h('section', { class: 'cm-arc' },
            h('div', { class: 'cm-arc__tete' },
              h('span', { class: 'surtitre' }, `Arc ${a.ordre} · niveaux ${a.niveaux.min} à ${a.niveaux.max}`),
              h('h3', { class: 'titre-m' }, a.nom),
              a.resume ? h('p', { class: 'ui-s cm-sourdine' }, a.resume) : null),
            h('div', { class: 'cm-etapes' }, visibles.map(e => [vueEtape(e), vueSousEtape(e)]).flat().filter(Boolean)));
        }),
        h('details', { class: 'cm-repli' },
          h('summary', { class: 'etiquette' }, 'Progression et notes'),
          h('div', { class: 'cm-pile' },
            d.resume ? h('p', { class: 'ui' }, d.resume) : null,
            d.progression ? section('Progression', 'etoile', h('p', { class: 'ui' }, d.progression.texte, d.progression.niveau_max ? ` Niveau maximum : ${d.progression.niveau_max}.` : ''), blocOriginal(d.progression.original)) : null,
            d.niveaux_du_livre ? section('Niveaux du livre', 'livre', h('p', { class: 'ui-s' }, d.niveaux_du_livre.texte)) : null,
            d.notes?.length ? h('ul', { class: 'ui cm-liste' }, d.notes.map(n => h('li', {}, n))) : null,
            provenance(d))),
      ].flat().filter(Boolean));
      // Étape de référence changée : l'amener en haut du widget. Widget réduit ou dans l'autre mode : ce sera fait quand il
      // apparaîtra (voir plus bas).
      if (defiler && recentrer()) defiler = false;
      else corps.scrollTop = haut;
      if (fenetres) rafraichirFenetres();
    }
    // Amener un élément en haut du widget (l'élément précédent reste en vue), sans faire défiler la page.
    const amener = el => { corps.scrollTop = el.getBoundingClientRect().top - corps.getBoundingClientRect().top + corps.scrollTop - 48; };
    function recentrer() {
      const actif = corps.querySelector('.cm-etape.est-focus');   // l'étape de référence, ses jalons juste dessous
      if (!actif || !corps.clientHeight) return false;
      amener(actif);
      return true;
    }
    // Chaque fois que le widget apparaît (déplié, ou passé de l'autre mode au tableau) : retour à l'étape de référence.
    let apparu = false;
    new ResizeObserver(() => {
      const vu = corps.clientHeight > 0;
      if (vu && !apparu) { recentrer(); defiler = false; }
      apparu = vu;
    }).observe(corps);

    // Clic sur le résumé de l'en-tête : déplier au besoin, revenir à l'étape de référence.
    function voirEnCours() {
      deplier();
      apparu = corps.clientHeight > 0;
      recentrer();
    }

    // « Voir dans le déroulé » (widgets Rencontres, Ici, Personnages ; liens des fenêtres) : déplier le widget et l'étape,
    // amener l'élément en vue. Un filtre par PJ qui le cacherait est levé. Renvoie l'élément amené en vue.
    function voir(cle, selecteur, cache) {
      const widget = corps.closest('.bn-widget');
      if (filtre && cache) { filtre = null; majFiltre(); }
      deplier();
      apparu = corps.clientHeight > 0;   // déjà amené ici : l'apparition ne doit pas ramener à l'étape de référence
      if (cle) ouverts.add(cle);
      rendre();
      const el = corps.querySelector(selecteur);
      if (el) amener(el);
      widget?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      return el;
    }
    const ecouter = (nom, fn) => {
      const f = ev => { if (!corps.isConnected) { document.removeEventListener(nom, f); return; } fn(ev.detail || {}); };
      document.addEventListener(nom, f);
    };
    // Un jalon démarré ou terminé depuis la fin d'une rencontre : la même suite que ses boutons (pistes, étapes, lieu).
    ecouter('cm:apres-jalon', ({ id, fini }) => {
      const j = jalonParId.get(id);
      if (j) apresJalon(j, !!fini);
    });
    // Un jalon : sa ligne amenée en vue, sa fenêtre ouverte à côté.
    ecouter('cm:voir-jalon', ({ id }) => {
      const j = jalonParId.get(id);
      if (j) ouvrirJalon(j, voir(null, `[data-jalon="${CSS.escape(j.id)}"]`, !visible(j)));
    });
    // Une piste : la fenêtre « À garder en tête », son groupe déplié, puis sa fenêtre à côté de sa ligne. Un filtre par PJ qui
    // la cacherait est levé.
    ecouter('cm:voir-piste', ({ id }) => {
      const p = pisteParId.get(id);
      if (!p) return;
      if (filtre && !visible(p)) { filtre = null; majFiltre(); rendre(); }
      filtrePistes.enCours = false;
      groupesPliesPistes.delete(groupeDePiste(p));
      ouvrirPistesAGarder();
      ouvrirPiste(p, document.querySelector(`.cm-pistes-ouvertes [data-piste="${CSS.escape(p.id)}"]`));
    });
    ecouter('cm:voir-etape', ({ id }) => {
      const e = etapeParId.get(id);
      if (e) voir(e.id, `.cm-etape[data-id="${CSS.escape(e.id)}"]`, !etapeVisible(e));
    });

    rendre();
    s.abonner(() => { defiler = true; rendre(); });   // suivi changé ailleurs (Ici, fin de session, bouton Données)
    sIci.abonner(rafraichirFenetres);                   // le lieu des héros change ce que proposent les fenêtres
    // Rencontres créées, préparées ou terminées, objets créés ou donnés, PNJ rencontrés (lignes, comptes, symboles d'alerte).
    R.s.abonner(rendre);
    O.s.abonner(rendre);
    sPnj?.abonner(rendre);
    return {};
  },
};
