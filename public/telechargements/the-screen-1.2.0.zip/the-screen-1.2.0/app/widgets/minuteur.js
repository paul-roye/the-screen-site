// Widget Minuteur : limiter un moment (une décision, une pause, une épreuve). Compact : tient en 2 colonnes.
// Les boutons +1′ +5′ +10′ +30′ s'ajoutent à la durée en cours : à l'arrêt ils composent la durée, en marche
// ou en pause ils prolongent le temps restant. Remise à zéro : 0:00.
// L'heure de fin est gardée dans etat/minuteur.json : le minuteur continue si la page est rechargée.

import { h, icone, bouton } from '../ui.js';

const AJOUTS = [1, 5, 10, 30];   // minutes
const lisible = ms => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const hh = Math.floor(s / 3600), mm = Math.floor(s / 60) % 60, ss = s % 60;
  return hh ? `${hh}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}` : `${mm}:${String(ss).padStart(2, '0')}`;
};

export default {
  type: 'minuteur',
  titre: 'Minuteur',
  surtitre: 'Le temps presse',
  icone: 'sablier',
  description: 'Un compte à rebours compact pour limiter un moment : +1, +5, +10 ou +30 minutes s\'ajoutent à la durée en cours, pause, son à la fin.',
  taille: { w: 2, h: 3 },
  min: { w: 2, h: 3 },
  unique: true,
  compact: true,

  async monter({ corps, etat }) {
    const s = await etat('minuteur', { schema: 1, duree: 0, fin: null, reste: null, son: true });
    const v = () => s.valeur;
    let minuterie = null;
    let sonne = false;

    const affichage = h('span', { class: 'cm-minuteur__temps' });
    const barre = h('span', { class: 'cm-minuteur__plein' });
    const annonce = h('span', { class: 'cm-invisible', 'aria-live': 'polite' });
    const zoneLecture = h('span', { class: 'cm-minuteur__commandes' });
    const btnSon = bouton('', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { v().son = !v().son; s.enregistrer(); majSon(); } });

    // duree : durée totale du compte en cours (sert à la barre) ; fin : heure de fin s'il tourne ; reste : restant en pause.
    const restant = () => v().fin ? v().fin - Date.now() : (v().reste ?? v().duree);
    const enMarche = () => !!v().fin;
    const enPause = () => !enMarche() && v().reste != null && v().reste > 0;
    const fini = () => !enMarche() && v().reste === 0;

    function majSon() {
      btnSon.replaceChildren(icone(v().son ? 'lu-volume-2' : 'lu-volume-x'));
      btnSon.setAttribute('aria-label', v().son ? 'Son activé (couper)' : 'Son coupé (activer)');
      btnSon.title = btnSon.getAttribute('aria-label');
      btnSon.setAttribute('aria-pressed', String(v().son));
    }

    function bip() {
      if (!v().son) return;
      try {
        const ctx = new AudioContext();
        [0, 0.35, 0.7].forEach(t => {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.frequency.value = 660; o.connect(g); g.connect(ctx.destination);
          g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
          g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + t + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.3);
          o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.32);
        });
      } catch { /* pas de son possible : la couleur et le texte suffisent */ }
    }

    let dernier = '';
    function tic() {
      if (enMarche() && restant() <= 0) {
        v().fin = null; v().reste = 0; s.enregistrer(0);
        if (!sonne) { sonne = true; bip(); }
      }
      const r = fini() ? 0 : restant();
      affichage.textContent = lisible(r);
      barre.style.width = v().duree > 0 ? `${Math.max(0, Math.min(100, r / v().duree * 100))}%` : '0%';
      corps.classList.toggle('cm-minuteur--marche', enMarche());
      corps.classList.toggle('cm-minuteur--fini', fini());
      const texte = enMarche() ? 'En cours' : fini() ? 'Temps écoulé' : enPause() ? 'En pause' : r > 0 ? `Prêt, ${lisible(r)}` : 'Ajoutez une durée';
      if (annonce.textContent !== texte) annonce.textContent = texte;
      affichage.title = texte;
      const cle = `${enMarche()}|${enPause()}|${r > 0}`;
      if (cle !== dernier) {
        dernier = cle;
        zoneLecture.replaceChildren(
          enMarche()
            ? bouton('', { classe: 'bn-btn--s', icone: 'lu-pause', titre: 'Pause', onclick: pause })
            : bouton('', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-play', titre: enPause() ? 'Reprendre' : 'Démarrer', disabled: !(r > 0) || fini(), onclick: demarrer }),
          bouton('', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'Remettre à zéro', onclick: remettre }),
          btnSon);
      }
      if (!enMarche()) { clearInterval(minuterie); minuterie = null; }
    }

    function demarrer() {
      const r = restant();
      if (!(r > 0)) return;
      v().fin = Date.now() + r;
      v().reste = null;
      sonne = false;
      s.enregistrer(0);
      clearInterval(minuterie);
      minuterie = setInterval(tic, 250);
      tic();
    }
    function pause() { v().reste = restant(); v().fin = null; s.enregistrer(0); tic(); }
    function remettre() { v().duree = 0; v().fin = null; v().reste = null; sonne = false; s.enregistrer(0); tic(); }
    // Ajouter : prolonge le compte en cours, ou compose la durée à l'arrêt (repart de 0 après un temps écoulé).
    function ajouter(minutes) {
      const ms = minutes * 60000;
      if (enMarche()) { v().fin += ms; v().duree += ms; }
      else if (enPause()) { v().reste += ms; v().duree += ms; }
      else { v().duree = (fini() ? 0 : restant()) + ms; v().reste = null; sonne = false; }
      s.enregistrer(0);
      tic();
    }

    // Terminé pendant que la page était fermée : pas de sonnerie à la réouverture.
    if (enMarche() && restant() <= 0) sonne = true;
    corps.classList.add('cm-minuteur');
    corps.replaceChildren(
      h('div', { class: 'cm-minuteur__ligne' }, affichage, zoneLecture),
      h('span', { class: 'cm-minuteur__barre' }, barre),
      h('div', { class: 'cm-minuteur__presets' },
        AJOUTS.map(m => h('button', { type: 'button', class: 'cm-puce-bouton', title: `Ajouter ${m} minute${m > 1 ? 's' : ''}`, onclick: () => ajouter(m) }, `+${m}′`))),
      annonce);
    majSon();
    tic();
    if (enMarche()) minuterie = setInterval(tic, 250);
    return {};
  },
};
