// Widget Marchands : une ligne par marchand, par ville (d'office celle où sont les héros : « Zone »), recherche d'un article ;
// un clic ouvre la fiche du marchand dans une fenêtre flottante (articles triés par nom ou par prix, ajout au panier).
// Panier avec total en po / pa / pc. Un clic sur un tenancier ouvre sa fiche de PNJ (data/pnj.json).
// Données : data/marchands.json (formats/marchands.md). État : etat/marchands.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, onglets, section, provenance, blocOriginal, normaliser, identifiant, flottant, flottantOuvert, sansRamener, lienFlottant } from '../ui.js';
import { chargerLieux, nomLieu, etatIci } from '../lieux.js';
import { etatPnj, chargerFactions, ouvrirFichePnj } from '../fiche-pnj.js';
import { vocabulaire } from '../campagne.js';

const RENDU = ['po', 'pa', 'pc'];   // pièces utilisées pour rendre un total (pe et pp restent dans les conversions)

export default {
  type: 'marchands',
  requiert: 'marchands',
  titre: 'Marchands',
  icone: 'piece',
  description: 'Boutiques, tavernes et auberges par ville, prix triables, panier avec le total en po, pa et pc, et la fiche des tenanciers.',
  taille: { w: 5, h: 16 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, actions, donnees, etat }) {
    const lecture = await donnees('marchands');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Marchands indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const monnaies = d.monnaies;
    const lieux = await chargerLieux(donnees);
    const lecturePnj = await donnees('pnj');
    const pnj = new Map((lecturePnj.donnees?.pnj || []).map(p => [p.id, p]));
    const sPnj = await etatPnj(etat);
    const factions = await chargerFactions(donnees);
    const s = await etat('marchands', { schema: 1, ville: '', suivre_zone: true, tri: 'nom', panier: [] });
    const v = () => s.valeur;
    v().suivre_zone ??= true;
    const sIci = await etatIci(etat, donnees);
    let ongletActif = 'boutiques';
    let cherche = '';

    // 1234 pc -> « 12 po 3 pa 4 pc »
    function enPieces(pc) {
      let reste = Math.round(pc);
      const morceaux = [];
      for (const m of RENDU) {
        const val = monnaies[m];
        const n = Math.floor(reste / val);
        if (n) { morceaux.push(`${n.toLocaleString('fr-FR')} ${m}`); reste -= n * val; }
      }
      return morceaux.join(' ') || '0 pc';
    }

    const villes = [...new Set(d.marchands.map(m => m.lieu))];
    const nbPanier = () => v().panier.reduce((a, l) => a + l.qte, 0);
    // « Zone » : la ville où sont les héros (le lieu de Ici, ou celui qui le contient), si elle a des marchands.
    const villeIci = () => {
      const l = sIci.valeur.lieu;
      return villes.includes(l) ? l : villes.includes(lieux.get(l)?.situe_dans) ? lieux.get(l).situe_dans : null;
    };
    const villeAffichee = () => (v().suivre_zone && villeIci()) || v().ville;

    function ajouter(m, a) {
      const deja = v().panier.find(l => !l.libre && l.marchand === m.id && l.nom === a.nom);
      if (deja) deja.qte++;
      else v().panier.push({ id: identifiant(), marchand: m.id, nom: a.nom, prix_pc: a.prix_pc, qte: 1 });
      s.enregistrer(0);
      majOnglet();
    }

    function ficheTenancier(id) {
      const p = pnj.get(id);
      if (p) ouvrirFichePnj(p, { lieux, s: sPnj, factions, typesRang: lecturePnj.donnees?.types_rang });
    }

    // ───── Boutiques ─────

    const correspondArticle = (a, q) => normaliser(a.nom).includes(q) || normaliser(a.categorie).includes(q);

    // Tri des articles : un clic sur l'en-tête de colonne (flèche de tri), pour toutes les fiches ouvertes.
    function enteteTri(cle, libelle, ic) {
      return h('button', { type: 'button', class: 'cm-tri cm-tri--entete', 'aria-pressed': String(v().tri === cle), title: `Trier les articles par ${libelle.toLowerCase()}`,
        onclick: () => { v().tri = cle; s.enregistrer(); rafraichirFiches(); } }, h('span', {}, libelle), icone(ic, 'bn-icone--s'));
    }

    function tableArticles(m) {
      const articles = [...m.articles].sort(v().tri === 'prix'
        ? (a, b) => (a.prix_pc ?? Infinity) - (b.prix_pc ?? Infinity)
        : (a, b) => a.nom.localeCompare(b.nom, 'fr'));
      if (!articles.length) return null;
      const categories = [...new Set(articles.map(a => a.categorie || ''))];
      return h('div', { class: 'bn-table-wrap' }, h('table', { class: 'bn-table cm-articles' },
        h('thead', {}, h('tr', {}, h('th', {}, enteteTri('nom', 'Article', 'lu-arrow-down-a-z')), h('th', { class: 'num' }, enteteTri('prix', 'Prix', 'lu-arrow-down-0-1')),
          h('th', {}, h('span', { class: 'cm-invisible' }, 'Ajouter')))),
        categories.map(cat => h('tbody', {},
          cat && categories.length > 1 ? h('tr', { class: 'cm-categorie' }, h('th', { colspan: 3, scope: 'colgroup' }, cat)) : null,
          articles.filter(a => (a.categorie || '') === cat).map(a => h('tr', {},
            h('td', {}, h('span', { class: 'bn-table__nom' }, a.nom), a.note ? h('span', { class: 'bn-table__sous' }, a.note) : null),
            h('td', { class: 'num cm-prix' }, a.prix),
            h('td', { class: 'num' }, typeof a.prix_pc === 'number'
              ? bouton('', { icone: 'lu-plus', titre: `Ajouter au panier : ${a.nom}`, classe: 'bn-btn--s bn-btn--fantome', onclick: () => ajouter(m, a) })
              : null)))))));
    }

    // Fiche d'un marchand, dans une fenêtre flottante.
    function contenuMarchand(m) {
      return h('div', { class: 'cm-pile cm-fiche-marchand' },
        h('p', { class: 'texte' }, m.description),
        m.tenanciers?.length ? h('p', { class: 'cm-tenanciers' }, h('span', { class: 'etiquette' }, 'Tenu par'), m.tenanciers.map(id => pnj.has(id)
          ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ficheTenancier(id) }, pnj.get(id).nom)
          : h('span', { class: 'cm-sourdine' }, id))) : null,
        m.a_jouer ? h('p', { class: 'aparte' }, m.a_jouer) : null,
        m.regle_de_prix ? section('Prix', 'piece', h('p', { class: 'ui' }, m.regle_de_prix)) : null,
        m.marchandage ? section('Marchandage', 'lu-info', h('p', { class: 'ui' }, m.marchandage)) : null,
        m.services?.length ? section('Services', 'lu-list', m.services.map(x => h('p', { class: 'ui' }, x))) : null,
        tableArticles(m),
        blocOriginal(m.original),
        provenance(m));
    }
    const ouvrirMarchand = m => flottant('marchand:' + m.id, { surtitre: [m.type, nomLieu(lieux, m.lieu), m.zone].filter(Boolean).join(' · '), titre: m.nom, pictogramme: 'piece', contenu: contenuMarchand(m) });
    const rafraichirFiches = () => sansRamener(() => d.marchands.filter(m => flottantOuvert('marchand:' + m.id)).forEach(ouvrirMarchand));

    // Une ligne par marchand : nom, type, où ; avec une recherche, les articles trouvés chez lui.
    function ligneMarchand(m, q, toutes) {
      const trouves = q ? m.articles.filter(a => correspondArticle(a, q)) : [];
      return lienFlottant(h('button', { type: 'button', class: 'cm-marchand-ligne cm-ouvre', onclick: () => ouvrirMarchand(m) },
        h('span', { class: 'cm-marchand__nom cm-ouvre__nom' }, m.nom),
        h('span', { class: 'cm-marchand__meta' }, badge(m.type, 'cierge'), [toutes ? nomLieu(lieux, m.lieu) : null, m.zone, m.emplacement].filter(Boolean).join(' · ')),
        trouves.length ? h('span', { class: 'cm-marchand__trouves' }, icone('lu-search', 'bn-icone--s'),
          trouves.slice(0, 4).map(a => a.nom).join(', ') + (trouves.length > 4 ? ` (${trouves.length})` : '')) : null), 'marchand:' + m.id);
    }

    function vueBoutiques() {
      const q = normaliser(cherche);
      const ville = villeAffichee();
      const liste = d.marchands.filter(m => (!ville || m.lieu === ville)
        && (!q || normaliser(m.nom).includes(q) || normaliser(m.type).includes(q) || m.articles.some(a => correspondArticle(a, q))));
      const champ = h('input', {
        class: 'bn-input', type: 'search', value: cherche, placeholder: 'Un article, une boutique…', 'aria-label': 'Chercher un article ou une boutique',
        oninput: e => { cherche = e.target.value; const pos = e.target.selectionStart; rendre(); const n = corps.querySelector('.cm-marchands-recherche input'); n?.focus(); n?.setSelectionRange(pos, pos); },
      });
      // Choisir une ville à la main ne suit plus la zone.
      const selVille = h('select', { class: 'bn-select', 'aria-label': 'Ville', title: 'Ville', onchange: e => { v().ville = e.target.value; v().suivre_zone = false; s.enregistrer(); rendre(); } },
        h('option', { value: '' }, 'Toutes'), villes.map(id => h('option', { value: id }, nomLieu(lieux, id))));
      selVille.value = ville;
      const ici = villeIci();
      return h('div', { class: 'cm-pile cm-marchands' },
        h('div', { class: 'cm-marchands-filtres', hidden: !filtresVisibles },
          h('label', { class: 'cm-case', title: ici ? `Suivre la zone : les marchands du lieu où sont les héros (${nomLieu(lieux, ici)})` : 'Suivre la zone : les héros sont dans un lieu sans marchand (widget Ici)' },
            h('input', { type: 'checkbox', class: 'bn-case', checked: !!v().suivre_zone, onchange: e => { v().suivre_zone = e.target.checked; s.enregistrer(); rendre(); } }),
            icone('epingle', 'bn-icone--s'), h('span', {}, 'Zone')),
          h('span', { class: 'cm-filtre' }, icone('epingle', 'bn-icone--s'), selVille),
          h('div', { class: 'cm-recherche cm-marchands-recherche' }, icone('lu-search', 'bn-icone--s'), champ)),
        liste.length ? h('div', { class: 'cm-marchands-liste' }, liste.map(m => ligneMarchand(m, q, !ville))) : h('p', { class: 'ui cm-sourdine' }, 'Aucun marchand ne correspond.'),
        d.vins?.length ? section(vocabulaire('Vins {de_monde}') || 'Vins', 'coupe-vin', h('ul', { class: 'ui cm-liste' }, d.vins.map(x => h('li', {}, h('b', {}, x.nom), ` : ${x.qualite}`)))) : null,
        d.conseil ? h('p', { class: 'aparte cm-sourdine' }, d.conseil) : null);
    }

    // ───── Panier ─────

    function vuePanier() {
      const lignes = v().panier;
      const total = lignes.reduce((a, l) => a + l.prix_pc * l.qte, 0);
      const nomMarchand = id => d.marchands.find(m => m.id === id)?.nom || id;
      const qte = (l, delta) => { l.qte = Math.max(1, l.qte + delta); s.enregistrer(0); rendre(); };
      const libelle = h('input', { class: 'bn-input', placeholder: 'Ex. une épée longue chez l\'armurier', 'aria-label': 'Libellé de la ligne libre' });
      const montant = h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '0', step: 'any', 'aria-label': 'Montant' });
      const piece = h('select', { class: 'bn-select cm-select-court', 'aria-label': 'Pièce' }, Object.keys(monnaies).map(m => h('option', { value: m }, m)));
      piece.value = 'po';
      const erreur = h('p', { class: 'bn-champ__erreur', hidden: true });
      const ajouterLibre = e => {
        e.preventDefault();
        const n = Number(montant.value);
        if (!libelle.value.trim() || !(n >= 0) || montant.value === '') {
          erreur.replaceChildren(icone('crane', 'bn-icone--s'), 'Indiquez un libellé et un montant.');
          erreur.hidden = false;
          return;
        }
        v().panier.push({ id: identifiant(), libre: true, nom: libelle.value.trim(), prix_pc: Math.round(n * monnaies[piece.value]), qte: 1, prix: `${n.toLocaleString('fr-FR')} ${piece.value}` });
        s.enregistrer(0);
        rendre();
      };
      return h('div', { class: 'cm-pile' },
        lignes.length ? h('div', { class: 'bn-table-wrap' }, h('table', { class: 'bn-table cm-panier' },
          h('thead', {}, h('tr', {}, h('th', {}, 'Article'), h('th', { class: 'num' }, 'Qté'), h('th', { class: 'num' }, 'Total'), h('th', {}, h('span', { class: 'cm-invisible' }, 'Retirer')))),
          h('tbody', {}, lignes.map(l => h('tr', {},
            h('td', {}, h('span', { class: 'bn-table__nom' }, l.nom), h('span', { class: 'bn-table__sous' }, `${l.libre ? 'Ligne libre' : nomMarchand(l.marchand)} · ${l.prix || enPieces(l.prix_pc)} l'unité`)),
            h('td', { class: 'num' }, h('span', { class: 'cm-qte' },
              bouton('', { icone: 'lu-minus', titre: `Un de moins : ${l.nom}`, classe: 'bn-btn--s bn-btn--fantome', disabled: l.qte <= 1, onclick: () => qte(l, -1) }),
              h('span', { class: 'chiffre cm-qte__n' }, l.qte),
              bouton('', { icone: 'lu-plus', titre: `Un de plus : ${l.nom}`, classe: 'bn-btn--s bn-btn--fantome', onclick: () => qte(l, 1) }))),
            h('td', { class: 'num cm-prix' }, enPieces(l.prix_pc * l.qte)),
            h('td', { class: 'num' }, bouton('', { icone: 'lu-x', titre: `Retirer ${l.nom}`, classe: 'bn-btn--s bn-btn--fantome', onclick: () => { v().panier = v().panier.filter(x => x.id !== l.id); s.enregistrer(0); rendre(); } }))))))) : h('p', { class: 'ui cm-sourdine' }, 'Le panier est vide. Ajoutez des articles depuis les boutiques, ou une ligne libre ci-dessous.'),
        lignes.length ? h('div', { class: 'bn-carte cm-total' },
          h('span', { class: 'etiquette' }, 'Total'),
          h('span', { class: 'chiffre' }, enPieces(total)),
          h('span', { class: 'ui-s cm-sourdine' }, `soit ${total.toLocaleString('fr-FR')} pc`)) : null,
        h('form', { class: 'cm-ligne-libre', onsubmit: ajouterLibre },
          h('p', { class: 'etiquette cm-section__titre' }, icone('lu-plus', 'bn-icone--s'), 'Ligne libre'),
          h('div', { class: 'bn-ligne-champs' }, h('div', { class: 'bn-champ' }, libelle), h('div', { class: 'cm-montant' }, montant, piece)),
          erreur,
          h('div', { class: 'bn-groupe' },
            h('button', { type: 'submit', class: 'bn-btn bn-btn--s' }, icone('lu-plus'), h('span', {}, 'Ajouter')),
            lignes.length ? bouton('Vider le panier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-trash-2', onclick: () => { if (confirm('Vider le panier ?')) { v().panier = []; s.enregistrer(0); rendre(); } } }) : null)));
    }

    // Bouton de l'en-tête, comme PNJ : masque le choix de la ville et la recherche, en orange quand ils cachent une recherche.
    const CLE_FILTRES = 'cm:marchands:filtres';
    let filtresVisibles = true;
    try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* pas de stockage : visibles */ }
    const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      filtresVisibles = !filtresVisibles;
      try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* le choix vaut pour la session */ }
      rendre();
    } });
    function majBoutonFiltres() {
      btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
      btnFiltres.classList.toggle('est-filtre', !filtresVisibles && !!cherche);
      const titre = (filtresVisibles ? 'Masquer la recherche et le choix de la ville' : 'Afficher la recherche et le choix de la ville') + (!filtresVisibles && cherche ? ' (une recherche est active)' : '');
      btnFiltres.title = titre;
      btnFiltres.setAttribute('aria-label', titre);
    }
    actions.prepend(btnFiltres);

    let barre = null;
    function majOnglet() {
      const o = barre?.querySelectorAll('[role=tab]')[1];
      if (o) o.lastChild.textContent = nbPanier() ? `Panier (${nbPanier()})` : 'Panier';
    }

    function rendre() {
      const haut = corps.scrollTop;
      majBoutonFiltres();
      const o = onglets('Marchands', [
        { id: 'boutiques', libelle: 'Boutiques', icone: 'piece', rendu: vueBoutiques },
        { id: 'panier', libelle: nbPanier() ? `Panier (${nbPanier()})` : 'Panier', icone: 'lu-shopping-basket', rendu: vuePanier },
      ], ongletActif, id => { if (id !== ongletActif) { ongletActif = id; corps.scrollTop = 0; } });
      barre = o.barre;
      corps.replaceChildren(o.barre, o.zone);
      corps.scrollTop = haut;
    }
    rendre();
    sIci.abonner(() => { if (v().suivre_zone) rendre(); });   // les héros ont changé de lieu
    return {};
  },
};
