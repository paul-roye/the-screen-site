// Widget Horloge : le jour de campagne et sa date au calendrier de la campagne, l'heure de jeu, le moment (aube, jour, crépuscule, nuit), la météo
// du créneau en cours, la lune, les jours marqués, où sont les héros (à l'abri, sur la route, en pleine nature) et le dernier repos long.
// Le temps n'avance que quand le MJ le décide : boutons de durée, repos, attente de l'aube, « Démarrer le trajet » du widget Trajets.
// Réduit, l'en-tête rappelle le jour, l'heure, la météo, le moment, où sont les héros et l'activité en cours.
// Dès une heure dehors, le passage du temps propose les tests de rencontre heure par heure (app/passage.js).
// Rencontres suit sa table de jour ou de nuit tant que ce widget est sur le tableau.
// Calculs : app/horloge.js (calendrier et météo selon les réglages de la campagne : app/calendrier.js). Les textes du
// calendrier (sens d'un jour, divinités, coutumes, règle de la lune, présentation) viennent de son fichier : rien n'est
// montré qu'il ne donne pas (le Classique n'en a presque pas).
// Les mots du ciel (« Pluie faible ») sont ceux de la météo ; sans météo, le moment seul. Une campagne au ciel toujours voilé
// (`ciel_voile`) a son rappel : une icône, la règle du monde en infobulle, à dire à la table. État : etat/horloge.json, et le terrain
// dans etat/rencontres.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, bascule, infobulle, flottant, flottantOuvert, sansRamener, lienFlottant, section, FINE } from '../ui.js';
import {
  etatHorloge, reglagesDe, lecture, MOMENTS, libelleHeure, libelleMoment, libelleDuree, enMinutes, enHHMM, depuisHHMM,
  changer, avancer, jusqua, sansReposLong, noterReposLong, retirerDuJournal, retourDe, REPOS_COURT, REPOS_LONG, VEILLE_MAX,
  chargerCalendrier,
} from '../horloge.js';
import { libelleDate, libelleDateComplete, nomJourMarque, vueMeteo, iconeMeteo, libelleTemperature, meteoDeLaJournee, cielDuMonde, rangDate, dateDuJour } from '../calendrier.js';
import { chargerAgenda, alertesDe } from '../agenda.js';
import { reglage } from '../campagne.js';
import { etatRencontres, TERRAINS } from '../rencontres-moteur.js';
import { passerLeTemps, vueActivite, activiteCourante, preparerActivite, boutonRepos, boutonAvancer, alerteVeille, garderOuvert, LIBELLES_ACTIVITE, annulerAvecSuites } from '../passage.js';

const PAS = [[10, '+10 min'], [30, '+30 min'], [60, '+1 h'], [240, '+4 h']];

export default {
  type: 'horloge',
  titre: 'Horloge',
  icone: 'lune',
  description: 'Le jour de campagne, sa date au calendrier de la campagne et l\'heure de jeu : aube, jour, crépuscule ou nuit, météo, lune, jours marqués, dernier repos long. Dès une heure dehors, propose les tests de rencontre heure par heure, de jour ou de nuit ; alerte quand la nuit tombe et quand le temps change.',
  taille: { w: 4, h: 9 },
  min: { w: 3, h: 5 },
  unique: true,

  async monter({ corps, actions, resume, donnees, etat, dialogue }) {
    const s = await etatHorloge(etat);
    const sR = await etatRencontres(etat);
    const v = () => s.valeur;
    resume.dataset.quand = 'reduit';
    const contexte = { dialogue, donnees, etat };
    const intervalle = (await donnees('rencontres-aleatoires')).donnees?.procedure?.intervalle_minutes || 60;
    const { cal, meteo } = await chargerCalendrier(donnees);
    // Le nom du calendrier (« Calendrier Classique » : `titre` de calendrier.json), et dans une phrase (« du calendrier Classique »).
    const nomCalendrier = cal?.titre || 'Calendrier';
    const calendrierMin = nomCalendrier.charAt(0).toLowerCase() + nomCalendrier.slice(1);
    const agenda = cal ? await chargerAgenda(donnees, etat) : null;   // entrées datées : app/agenda.js
    const rencontresMj = await preparerActivite(contexte);

    // Rien dans l'en-tête : un clic sur l'heure règle l'horloge, « Annuler » est au bout des boutons de temps.
    const titreRegler = 'Régler le jour, l\'heure, le dernier repos long et le soleil';
    // « Annuler » propose aussi de défaire ce qui s'est passé pendant ce temps (tests, arrivées, rencontres lancées).
    const btnAnnuler = bouton('', { icone: 'lu-rotate-ccw', classe: 'bn-btn--s bn-btn--fantome cm-horloge__annuler', onclick: () => annulerAvecSuites(contexte) });

    // Une heure ou plus : dehors, le dialogue propose les tests de rencontre ; à l'abri, le temps passe directement.
    const passer = (duree, motif, repos = null) => passerLeTemps(contexte, { titre: motif, motif, duree, repos });

    const astreDe = moment => (moment === 'jour' ? 'soleil' : moment === 'nuit' ? 'lune' : 'cierge');

    // Un jour marqué se montre le jour même et dans les deux semaines qui précèdent ; tous sont dans la fenêtre du jour.
    const HORIZON_MARQUES = 14;
    const dansJours = n => `${n}${FINE}j`;

    // Le jour en une phrase : `resume` du calendrier, sinon la première phrase de `sens`.
    const resumeJour = j => j.resume || (j.sens || '').match(/^.*?[.!?](?=\s|$)/)?.[0] || j.sens || '';
    const cap = t => t.charAt(0).toUpperCase() + t.slice(1);
    const divinite = j => (j.divinite ? cap([j.divinite.nom, j.divinite.culte].filter(Boolean).join(' · ')) : null);
    // Un calendrier qui donne des divinités aux jours en dit aussi l'absence (Middenwoć) ; un autre n'en parle pas.
    const avecDivinites = !!cal?.semaine?.some(j => j.divinite);
    // « Mardi (mardi) » ne dit rien : l'équivalent ne s'affiche que s'il diffère du nom.
    const equivalent = j => (j.equivalent && j.equivalent.toLowerCase() !== j.nom.toLowerCase() ? j.equivalent : null);
    const ligneDivinite = j => (avecDivinites ? divinite(j) || 'Sans divinité' : null);

    // « JOUR 1 · Lundi 6 octobre · 1009 », sur une ligne : le jour de campagne, la date du calendrier, l'année (nom du
    // calendrier en infobulle). La date en dit une ligne au survol (`resume`, qui nomme déjà la divinité) ; un clic ouvre la
    // fenêtre du jour.
    function vueJour(l) {
      const d = l.date;
      const jour = h('span', { class: 'surtitre' }, `Jour ${v().jour}`);
      if (!d) return h('span', { class: 'bn-horloge__jour' }, jour);
      const j = d.semaine;
      const point = () => h('span', { class: 'surtitre', 'aria-hidden': 'true' }, '·');
      const date = h('button', { type: 'button', class: 'bn-horloge__date', onclick: () => ouvrirJour() }, libelleDate(d));
      // L'année (avec son point) à part : elle disparaît quand l'heure et la météo sont l'une au-dessus de l'autre.
      const bulle = j.resume || [resumeJour(j), ligneDivinite(j) ? `${ligneDivinite(j)}.` : ''].filter(Boolean).join(' ') || cap(libelleDateComplete(d));
      const titreJour = `${j.nom}${equivalent(j) ? ` (${equivalent(j)})` : ''}${j.signification ? ` : ${j.signification}` : ''}`;
      return h('span', { class: 'bn-horloge__jour' }, jour, point(),
        lienFlottant(infobulle(date, bulle, { titre: titreJour }), FENETRE_JOUR),
        h('span', { class: 'bn-horloge__an' }, point(), infobulle(h('span', { class: 'surtitre bn-horloge__annee' }, String(d.annee)), `Année ${d.annee} du ${calendrierMin}`, { titre: nomCalendrier })));
    }

    // Lever ou coucher du soleil en icône : « ⤓ dans 1 h », l'heure exacte au survol.
    function vueSoleil(l) {
      const { coucher, dans, a } = l.soleil;
      return infobulle(h('span', { class: 'bn-horloge__soleil' }, icone(coucher ? 'lu-sunset' : 'lu-sunrise'), `dans ${libelleDuree(dans)}`),
        `À ${libelleHeure(a)}, dans ${libelleDuree(dans)}.`, { titre: coucher ? 'Coucher du soleil' : 'Lever du soleil' });
    }

    // ───── Fenêtre du jour : l'essentiel d'abord, le détail du jour et le calendrier repliés ─────

    const FENETRE_JOUR = 'horloge-jour';
    function ouvrirJour() {
      const l = lecture(v());
      if (!l.date) return;
      flottant(FENETRE_JOUR, { surtitre: `Jour ${v().jour} · ${l.date.annee} du ${calendrierMin}`, titre: cap(libelleDate(l.date)), largeur: 460, contenu: vueFenetreJour(l) });
    }

    // « Pour le MJ, ne pas lire » : secrets du jour (`secret_mj`) et décision du MJ.
    function pourMJ(...textes) {
      const t = textes.filter(Boolean);
      if (!t.length) return null;
      return h('div', { class: 'cm-pour-mj' },
        h('p', { class: 'etiquette cm-pour-mj__titre' }, icone('lu-eye-off', 'bn-icone--s'), 'Pour le MJ, ne pas lire'),
        t.map(x => h('p', { class: 'ui-s' }, x)));
    }

    function vueFenetreJour(l) {
      const d = l.date, j = d.semaine;
      const aujourdhui = l.marques.filter(x => x.dans === 0);
      const lune = l.lune ? (l.lune.pleine ? 'pleine lune cette nuit' : `${l.lune.nom.toLowerCase()}, pleine le ${libelleDate(l.lune.prochaine)} (dans ${dansJours(l.lune.dans)})`) : '';
      return h('div', { class: 'cm-pile bn-jour' },
        // L'essentiel : ce que le jour représente, en peu de mots.
        h('div', { class: 'bn-jour__essentiel' },
          equivalent(j) || j.signification ? h('p', { class: 'ui-l' }, [equivalent(j) ? cap(equivalent(j)) : '', j.signification].filter(Boolean).join(' · ')) : null,
          ligneDivinite(j) ? h('p', { class: 'ui bn-jour__divinite' }, icone('cierge', 'bn-icone--s'), ligneDivinite(j)) : null,
          resumeJour(j) ? h('p', { class: 'texte' }, resumeJour(j)) : null,
          aujourdhui.map(x => h('p', { class: 'ui bn-jour__marque', 'data-type': x.jm.type }, icone('etoile', 'bn-icone--s'), h('span', {}, h('b', {}, nomJourMarque(x)), ` : ${x.jm.texte}`))),
          (agenda?.duRang(cal, d.rang) || []).map(e => h('p', { class: 'ui bn-jour__agenda' }, icone('lu-calendar-days', 'bn-icone--s'), h('span', {}, h('b', {}, e.nom), e.details ? ` : ${e.details}` : ''))),
          h('p', { class: 'ui-s cm-sourdine' }, [l.saison?.nom, lune].filter(Boolean).join(' · '))),
        vueMeteoJournee(),
        vueDetailJour(j),
        vueCalendrier(l));
    }

    // La météo de toute la journée (demande du MJ, 2026-10-22 : pour le compte rendu de séance), créneau par créneau, à copier.
    function vueMeteoJournee() {
      const m = meteo && meteoDeLaJournee(meteo, v().jour);
      if (!m) return null;
      const texte = `Jour ${v().jour}, météo de la journée : ${m.texte}.`;
      const statut = h('span', { class: 'ui-s cm-sourdine', 'aria-live': 'polite' });
      return section('La météo de la journée', 'brume',
        m.resume ? h('p', { class: 'ui' }, m.resume) : null,
        h('ul', { class: 'ui-s cm-liste' }, m.creneaux.map(c => h('li', {}, c))),
        h('div', { class: 'bn-groupe' }, bouton('Copier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-copy', titre: 'Copier la météo de la journée, pour le compte rendu',
          onclick: () => navigator.clipboard?.writeText(texte).then(() => { statut.textContent = 'Copiée.'; }, () => { statut.textContent = 'Copie impossible.'; }) }), statut));
    }

    function vueDetailJour(j) {
      if (!(j.sens || j.coutumes?.length || j.etymologie || j.secret_mj || j.decision_mj?.texte)) return null;
      return h('details', { class: 'cm-repli' },
        h('summary', { class: 'etiquette' }, `${j.nom} en détail`),
        h('div', { class: 'cm-pile' },
          j.sens ? h('p', { class: 'texte' }, j.sens) : null,
          section('Coutumes', 'lu-users', j.coutumes?.length ? h('ul', { class: 'ui-s cm-liste' }, j.coutumes.map(c => h('li', {}, c))) : null),
          j.etymologie ? h('p', { class: 'aparte cm-sourdine' }, j.etymologie) : null,
          pourMJ(j.secret_mj, j.decision_mj?.texte)));
    }

    // Le calendrier : le mois, la semaine (le jour en cours en rouge), la lune, les saisons, les jours marqués à venir.
    function vueCalendrier(l) {
      const d = l.date, m = d.mois, vraisMois = cal.mois.filter(x => !x.fete);
      const saisons = (cal.saisons || []).map(s => `${s.nom.toLowerCase()} le ${s.debut.jour} ${cal.mois.find(x => x.id === s.debut.mois)?.nom || s.debut.mois}`);
      return h('details', { class: 'cm-repli' },
        h('summary', { class: 'etiquette' }, `Le ${calendrierMin}`),
        h('div', { class: 'cm-pile' },
          cal.presentation ? h('p', { class: 'texte' }, cal.presentation) : null,
          // Un jour de fête hors des mois (Harptos) n'est pas un mois : il se dit à part, et ne compte pas dans le rang des mois.
          section(m.fete ? 'La fête' : 'Le mois', 'livre', h('p', { class: 'ui-s' }, m.fete ? `${m.nom}.${m.note ? ` ${m.note}` : ''}`
            : `${cap(m.nom)}, ${vraisMois.indexOf(m) + 1}e mois sur ${vraisMois.length}${m.equivalent && m.equivalent !== m.nom ? ` (${m.equivalent})` : ''}, ${m.jours} jours.${m.note ? ` ${m.note}` : ''}`)),
          section(`La ${cal.semaine_nom || 'semaine'}`, 'sablier',
            h('ol', { class: 'bn-jour__semaine' }, cal.semaine.map(x => h('li', { 'aria-current': x.id === d.semaine.id ? 'true' : null },
              h('b', {}, x.nom), h('span', {}, equivalent(x) || ''), h('span', {}, avecDivinites ? x.divinite?.nom || '—' : '')))),
            cal.semaine_note ? h('p', { class: 'ui-s cm-sourdine' }, cal.semaine_note) : null),
          section('La lune', 'lune', cal.lune?.regle ? h('p', { class: 'ui-s' }, cal.lune.regle) : null),
          section('Les saisons', 'soleil', saisons.length ? h('p', { class: 'ui-s' }, `${saisons.join(' ; ')}.`.replace(/^./, c => c.toUpperCase())) : null),
          section('Jours marqués', 'etoile', l.marques.length ? h('ul', { class: 'ui-s cm-liste' }, l.marques.map(x => h('li', {},
            h('b', {}, nomJourMarque(x)), ` : ${libelleDateComplete(x.date)}, ${x.dans ? `dans ${x.dans} jour${x.dans > 1 ? 's' : ''}` : 'aujourd\'hui'}.`))) : null),
          cal.annee?.note ? h('p', { class: 'ui-s cm-sourdine' }, cal.annee.note) : null,
          cal.credits?.texte ? h('p', { class: 'ui-s cm-sourdine' }, cal.credits.texte, cal.credits.url ? [' ', h('a', { class: 'bn-lien', href: cal.credits.url, target: '_blank', rel: 'noopener' }, 'Source')] : null) : null));
    }

    // ───── Agenda (demande du MJ, 2026-10-25) : le calendrier de l'année, et les entrées datées de chaque jour ─────
    // Bouton de l'en-tête. L'année en cours d'abord ; on va de l'année du départ à cinq ans au-delà de l'année en cours. Aujourd'hui
    // en rouge, les jours passés estompés, une étoile pour un jour marqué, un point orange pour une entrée d'agenda ; un clic sur
    // une date ouvre sa fenêtre : ses jours marqués, ses entrées (modifier, retirer) et « Ajouter ». Les entrées : app/agenda.js.

    const FENETRE_AGENDA = 'horloge-agenda', FENETRE_DATE = 'horloge-agenda-date';
    const ANNEES_EN_AVANT = 5;
    let anneeAgenda = null;   // l'année montrée
    let rangOuvert = null;    // la date dont la fenêtre est ouverte
    // Un rang du calendrier (rangDate) et sa date ; le jour 1 de la campagne est `debut_campagne`.
    const rangDepart = () => rangDate(cal, cal.debut_campagne) - cal.debut_campagne.jour_campagne;
    const dateDuRangCal = rang => dateDuJour(cal, rang - rangDepart());
    const suffixe = () => (cal.annee.suffixe ? ` ${cal.annee.suffixe}` : '');

    function ouvrirAgenda() {
      const l = lecture(v());
      if (!l.date || !agenda) return;
      anneeAgenda ??= l.date.annee;
      flottant(FENETRE_AGENDA, { surtitre: nomCalendrier, titre: `Agenda · ${anneeAgenda}${suffixe()}`, largeur: 880, contenu: vueAgenda(l) });
    }

    // Les jours marqués de l'année, par rang (comme joursMarques : `tous_les`).
    function marquesDeLAnnee(annee) {
      const m = new Map();
      for (const jm of cal.jours_marques || []) {
        if (jm.tous_les > 1 && annee % jm.tous_les) continue;
        const r = rangDate(cal, { annee, mois: jm.mois, jour: jm.jour });
        if (r !== null) m.set(r, [...(m.get(r) || []), jm]);
      }
      return m;
    }
    function entreesParRang() {
      const m = new Map();
      for (const e of agenda.entrees()) { const r = agenda.rangDe(cal, e); if (r !== null) m.set(r, [...(m.get(r) || []), e]); }
      return m;
    }

    function vueAgenda(l) {
      const an = anneeAgenda, auj = l.date.rang;
      const anMin = Math.min(dateDuJour(cal, 1).annee, l.date.annee), anMax = l.date.annee + ANNEES_EN_AVANT;
      const marques = marquesDeLAnnee(an), parRang = entreesParRang();
      const aller = a => { anneeAgenda = Math.max(anMin, Math.min(anMax, a)); ouvrirAgenda(); };
      const cellule = rang => {
        const d = dateDuRangCal(rang), es = parRang.get(rang) || [], ms = marques.get(rang) || [];
        const b = h('button', { type: 'button', class: ['cm-agenda__jour', rang === auj ? 'est-aujourdhui' : '', rang < auj ? 'est-passe' : '', es.length ? 'a-entree' : '',
          ms.length ? 'a-marque' : '', rang === rangOuvert ? 'est-ouvert' : ''].filter(Boolean).join(' '), onclick: () => ouvrirDate(rang) }, String(d.jour));
        const bulle = [...ms.map(x => `★ ${x.nom}`), ...es.map(e => e.nom)].join(' · ');
        return bulle ? infobulle(b, bulle, { titre: cap(libelleDateComplete(d)), ton: es.length ? 'cierge' : undefined }) : b;
      };
      // Un mois en grille de semaines (dizaines de Harptos comprises) ; un jour de fête hors des mois (Harptos) : sa seule case.
      const blocMois = m => {
        const r0 = rangDate(cal, { annee: an, mois: m.id, jour: 1 });
        if (m.fete) return h('section', { class: 'cm-agenda__mois cm-agenda__mois--fete' }, h('p', { class: 'etiquette' }, m.nom), cellule(r0));
        // Sans jour de semaine dans la date (les dizaines de Harptos recommencent chaque mois), le mois commence en première colonne.
        const decalage = cal.semaine_dans_la_date === false ? 0 : Math.max(0, cal.semaine.indexOf(dateDuRangCal(r0).semaine));
        return h('section', { class: 'cm-agenda__mois' }, h('p', { class: 'etiquette' }, m.nom),
          h('div', { class: 'cm-agenda__grille', style: `--colonnes: ${cal.semaine.length}` },
            cal.semaine.map(j => infobulle(h('span', { class: 'cm-agenda__entete' }, j.nom.slice(0, 2)), j.nom)),
            Array.from({ length: decalage }, () => h('span')),
            Array.from({ length: m.jours }, (_, i) => cellule(r0 + i))));
      };
      // Les prochaines entrées, d'aujourd'hui en avant.
      const prochaines = [...parRang.entries()].filter(([r]) => r >= auj).sort((a, b) => a[0] - b[0]).flatMap(([r, es]) => es.map(e => [r, e])).slice(0, 8);
      const retirees = agenda.retirees();
      return h('div', { class: 'cm-pile cm-agenda' },
        h('div', { class: 'cm-agenda__nav' },
          bouton('', { icone: 'lu-chevron-left', classe: 'bn-btn--s bn-btn--fantome', titre: 'Année précédente', disabled: an <= anMin, onclick: () => aller(an - 1) }),
          h('span', { class: 'titre-m' }, `${an}${suffixe()}`),
          bouton('', { icone: 'lu-chevron-right', classe: 'bn-btn--s bn-btn--fantome', titre: an >= anMax ? `Cinq ans au plus après l'année en cours` : 'Année suivante', disabled: an >= anMax, onclick: () => aller(an + 1) }),
          an !== l.date.annee ? bouton('Aujourd\'hui', { classe: 'bn-btn--s', onclick: () => aller(l.date.annee) }) : null,
          h('span', { class: 'ui-s cm-sourdine cm-agenda__legende' }, h('span', { class: 'cm-agenda__pastille est-aujourdhui' }), ' aujourd\'hui ',
            h('span', { class: 'cm-agenda__pastille a-entree' }), ' agenda ', h('span', { class: 'cm-agenda__pastille a-marque' }), ' jour marqué · un clic sur une date')),
        h('div', { class: 'cm-agenda__annee' }, cal.mois.map(blocMois)),
        prochaines.length ? section('Prochaines entrées', 'lu-calendar-days', h('ul', { class: 'cm-liste ui-s' }, prochaines.map(([r, e]) => h('li', {},
          h('button', { type: 'button', class: 'cm-lien-bouton cm-agenda__lien', onclick: () => { anneeAgenda = dateDuRangCal(r).annee; ouvrirAgenda(); ouvrirDate(r); } }, cap(libelleDateComplete(dateDuRangCal(r)))),
          r === auj ? ' (aujourd\'hui)' : ` (dans ${dansJours(r - auj)})`, ' : ', h('b', {}, e.nom))))) : null,
        retirees.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `Entrées du fichier retirées (${retirees.length})`),
          h('ul', { class: 'cm-liste ui-s' }, retirees.map(e => h('li', {}, h('b', {}, e.nom), ' ', bouton('Remettre', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => agenda.revenir(e.id) }))))) : null,
        agenda.fichierPresent ? null : h('p', { class: 'ui-s cm-sourdine' }, 'Pas de data/agenda.json : l\'agenda n\'a que ce que vous y écrivez ici. Votre agent IA de campagne peut l\'écrire (formats/agenda.md).'));
    }

    const rafraichirAgenda = () => { if (flottantOuvert(FENETRE_AGENDA)) sansRamener(ouvrirAgenda); };
    const rafraichirJour = () => { if (flottantOuvert(FENETRE_JOUR)) sansRamener(ouvrirJour); };
    // La fenêtre d'une date : ses jours marqués, ses entrées (modifier, retirer, revenir au texte du fichier), « Ajouter ».
    function ouvrirDate(rang) {
      rangOuvert = rang;
      const d = dateDuRangCal(rang);
      flottant(FENETRE_DATE, { surtitre: `Agenda · jour ${rang - rangDepart()} de campagne`, titre: cap(libelleDateComplete(d)), largeur: 440, contenu: vueDate(rang),
        surFermeture: () => { rangOuvert = null; rafraichirAgenda(); } });
      rafraichirAgenda();
    }
    let edition = null;   // { rang, id (null : nouvelle entrée) } : le formulaire ouvert dans la fenêtre d'une date
    function vueDate(rang) {
      const d = dateDuRangCal(rang);
      const ms = marquesDeLAnnee(d.annee).get(rang) || [];
      const es = agenda.duRang(cal, rang);
      const formulaire = id => {
        const e = id ? es.find(x => x.id === id) : null;
        const nom = h('input', { class: 'bn-input', value: e?.nom || '', placeholder: 'Festival du Soleil éclatant, délai, rendez-vous…', 'aria-label': 'Nom' });
        const details = h('textarea', { class: 'bn-textarea', rows: 3, placeholder: 'Ce qui se passe, ce qu\'il faut préparer…', 'aria-label': 'Détails' }, e?.details || '');
        // Alertes (demande du MJ, 2026-10-25) : « Le jour même » coché d'office, et autant de « N jours avant » qu'on veut.
        const al = alertesDe(e);
        const caseJour = h('input', { type: 'checkbox', class: 'bn-case', checked: al.jour_meme });
        const puces = h('span', { class: 'cm-agenda__puces' });
        const majPuces = () => puces.replaceChildren(...al.avant.map(n => h('span', { class: 'bn-badge cm-agenda__puce' }, `${n}${FINE}j avant`,
          h('button', { type: 'button', class: 'cm-agenda__retirer', 'aria-label': `Retirer l'alerte ${n} jours avant`, onclick: () => { al.avant = al.avant.filter(x => x !== n); majPuces(); } }, icone('lu-x', 'bn-icone--s')))));
        majPuces();
        const nombre = h('input', { class: 'bn-input cm-agenda__nombre', type: 'number', min: 1, max: 365, value: 7, 'aria-label': 'Nombre de jours avant',
          onkeydown: ev => { if (ev.key === 'Enter') { ev.preventDefault(); ajouterAvant(); } } });
        const ajouterAvant = () => { const n = Number(nombre.value); if (Number.isInteger(n) && n > 0 && !al.avant.includes(n)) { al.avant = [...al.avant, n].sort((a, b) => b - a); majPuces(); } };
        const valider = () => {
          if (!nom.value.trim()) { nom.focus(); return; }
          edition = null;   // avant d'écrire : l'écriture redessine la fenêtre (abonnement à l'agenda)
          agenda.ecrire(id, { date: { annee: d.annee, mois: d.mois.id, jour: d.jour }, nom: nom.value, details: details.value, alertes: { jour_meme: caseJour.checked, avant: al.avant } });
        };
        setTimeout(() => nom.focus(), 0);
        return h('form', { class: 'cm-pile cm-agenda__form', onsubmit: ev => { ev.preventDefault(); valider(); } },
          h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Nom'), nom),
          h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Détails'), details),
          h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Me prévenir'),
            h('div', { class: 'cm-agenda__alertes' },
              h('label', { class: 'cm-case' }, caseJour, 'Le jour même'),
              puces,
              h('span', { class: 'cm-agenda__ajout' }, nombre, bouton('jours avant', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-plus', titre: 'Ajouter une alerte ce nombre de jours avant', onclick: ajouterAvant })))),
          h('div', { class: 'bn-groupe' },
            bouton(id ? 'Enregistrer' : 'Ajouter', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check', onclick: valider }),
            bouton('Annuler', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { edition = null; ouvrirDate(rang); } })));
      };
      const enEdition = edition?.rang === rang ? edition : null;
      return h('div', { class: 'cm-pile' },
        ms.map(jm => h('p', { class: 'ui bn-jour__marque', 'data-type': jm.type }, icone('etoile', 'bn-icone--s'), h('span', {}, h('b', {}, jm.nom), jm.texte ? ` : ${jm.texte}` : ''))),
        es.length ? h('ul', { class: 'cm-agenda__entrees' }, es.map(e => h('li', { class: 'cm-agenda__entree' },
          enEdition?.id === e.id ? formulaire(e.id) : [
            h('p', { class: 'ui' }, h('b', {}, e.nom), e.origine === 'mj' ? badge('MJ', 'sang', 'lu-pencil') : e.retouchee ? badge('Retouchée', 'cierge', 'lu-pencil') : null, e.secret ? badge('Secret', 'ultra', 'lu-eye-off') : null),
            e.details ? h('p', { class: 'ui-s' }, e.details) : null,
            h('p', { class: 'ui-s cm-sourdine cm-agenda__rappel' }, icone('lu-bell', 'bn-icone--s'), texteAlertes(e)),
            h('div', { class: 'bn-groupe' },
              bouton('Modifier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', onclick: () => { edition = { rang, id: e.id }; ouvrirDate(rang); } }),
              e.retouchee ? bouton('Revenir au fichier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: () => agenda.revenir(e.id) }) : null,
              bouton('Retirer', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-trash-2', titre: e.origine === 'mj' ? 'La supprimer' : 'L\'écarter (le fichier ne change pas ; elle se remet depuis l\'agenda)',
                onclick: () => { if (confirm(`Retirer « ${e.nom} » de l'agenda ?`)) agenda.retirer(e.id); } }))]))) : null,
        !es.length && !ms.length && !enEdition ? h('p', { class: 'ui-s cm-sourdine' }, 'Rien ce jour-là.') : null,
        enEdition && !enEdition.id ? formulaire(null)
          : bouton('Ajouter une entrée', { classe: 'bn-btn--s', icone: 'lu-plus', onclick: () => { edition = { rang, id: null }; ouvrirDate(rang); } }));
    }
    // « Alerte le jour même, 7 j et 1 j avant », « Pas d'alerte ».
    function texteAlertes(e) {
      const a = alertesDe(e);
      const avant = a.avant.length ? `${a.avant.map(n => `${n}${FINE}j`).join(', ').replace(/, ([^,]*)$/, ' et $1')} avant` : '';
      if (!a.jour_meme && !avant) return 'Pas d\'alerte';
      return `Alerte ${[a.jour_meme ? 'le jour même' : '', avant].filter(Boolean).join(', ')}`;
    }

    // Les alertes : quand l'Horloge passe à un jour suivant (pas en annulant), les entrées dont c'est le jour ou dont une alerte
    // « N jours avant » tombe dans les jours passés, une fenêtre par passage (la plus proche de chaque entrée). Trente jours au
    // plus en arrière, si l'heure a été réglée loin en avant.
    let dernierJour = v().jour;
    function verifierAlertes() {
      const j = v().jour, avant = dernierJour;
      if (!agenda || j === avant) return;
      dernierJour = j;
      if (j < avant) return;
      const depuis = Math.max(avant, j - 30);
      const parEntree = new Map();
      for (const e of agenda.entrees()) {
        const r = agenda.rangDe(cal, e);
        if (r === null) continue;
        const jourE = r - rangDepart(), a = alertesDe(e);
        for (const n of [...(a.jour_meme ? [0] : []), ...a.avant]) {
          const jourAlerte = jourE - n;
          if (jourAlerte > depuis && jourAlerte <= j && !(parEntree.get(e.id)?.n <= n)) parEntree.set(e.id, { e, n, jourE });
        }
      }
      if (parEntree.size) montrerAlertes([...parEntree.values()].sort((a, b) => a.jourE - b.jourE), j);
    }
    function montrerAlertes(liste, j) {
      let dlg;
      const quand = x => { const dans = x.jourE - j; return dans > 0 ? `Dans ${dans}${FINE}jour${dans > 1 ? 's' : ''}` : dans === 0 ? 'Aujourd\'hui' : `Il y a ${-dans}${FINE}jour${dans < -1 ? 's' : ''}`; };
      dlg = dialogue('Agenda', liste.length > 1 ? `${liste.length} rappels de l'agenda` : 'Rappel de l\'agenda', h('ul', { class: 'cm-agenda__entrees' }, liste.map(x => {
        const r = x.jourE + rangDepart();
        return h('li', { class: 'cm-agenda__entree' },
          h('p', { class: 'ui' }, badge(quand(x), x.jourE === j ? 'sang' : 'cierge', 'lu-bell'), h('b', {}, x.e.nom), x.e.secret ? badge('Secret', 'ultra', 'lu-eye-off') : null),
          h('p', { class: 'ui-s cm-sourdine' }, cap(libelleDateComplete(dateDuRangCal(r))), ` · jour ${x.jourE} de campagne`),
          x.e.details ? h('p', { class: 'ui-s' }, x.e.details) : null,
          h('div', { class: 'bn-groupe' }, bouton('Voir dans l\'agenda', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-calendar-days',
            onclick: () => { dlg.close(); anneeAgenda = dateDuRangCal(r).annee; ouvrirAgenda(); ouvrirDate(r); } })));
      })), h('div', { class: 'bn-groupe' }, bouton('Compris', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => dlg.close() })));
    }

    // Une entrée ajoutée, modifiée ou retirée (ici, ou rechargée) : l'agenda, la date ouverte et la fenêtre du jour suivent.
    agenda?.s.abonner(() => {
      rafraichirAgenda();
      if (rangOuvert !== null && flottantOuvert(FENETRE_DATE)) flottantOuvert(FENETRE_DATE).maj(vueDate(rangOuvert));
      rafraichirJour();
    });
    if (agenda) actions.prepend(infobulle(bouton('', { icone: 'lu-calendar-days', classe: 'bn-btn--s bn-btn--fantome', onclick: () => ouvrirAgenda() }),
      'Le calendrier de l\'année, et l\'agenda : un clic sur une date pour y noter quelque chose.', { titre: 'Agenda' }));

    // Jour marqué du jour, ou à venir dans les deux semaines : « ★ Solstice d'hiver dans 3 j », le texte en infobulle.
    function vueJourMarque(l) {
      const x = l.marques.find(m => m.dans <= HORIZON_MARQUES);
      if (!x) return null;
      return infobulle(h('span', { class: 'bn-horloge__marque', 'data-type': x.jm.type, 'data-jour': x.dans ? null : 'oui' },
        icone('etoile', 'bn-icone--s'), h('span', { class: 'bn-horloge__marque-nom' }, nomJourMarque(x)),
        h('span', {}, x.dans ? ` dans ${dansJours(x.dans)}` : ' : aujourd\'hui')),
      x.jm.texte, { titre: `${nomJourMarque(x)} : ${libelleDateComplete(x.date)}`, ton: x.jm.type === 'special' ? 'sang' : 'cierge' });   // la couleur de l'étoile
    }

    // La ligne du ciel (demande du MJ, 2026-10-24 : « ciel gris, sans soleil » contredisait la pluie) : le temps du créneau
    // en cours (« Pluie faible »), sinon le moment (« Plein jour », « Nuit de pleine lune »). Ciel toujours voilé : une icône
    // le rappelle, avec la règle du monde (`regle_du_monde` de la météo) et ce que donne le ciel du moment dans ce monde.
    function vueCiel(l) {
      const c = l.meteo?.creneau;
      const texte = c ? c.texte : l.ambiance;
      const ligne = h('span', { class: 'titre-m bn-horloge__ambiance' },
        h('span', { class: 'bn-horloge__ambiance-texte' }, texte), reglage('ciel_voile', false) ? vueVoile(c) : null);
      return c ? infobulle(ligne, [l.meteo.jour.resume, `${l.meteo.nom} (${l.meteo.plage}) : ${c.texte}, ${libelleTemperature(c.min, c.max)}.`].filter(Boolean).join(' '), { titre: 'Le temps qu\'il fait' }) : ligne;
    }
    function vueVoile(c) {
      const monde = c && meteo ? cielDuMonde(meteo, c.ciel) : null;
      const regle = meteo?.regle_du_monde?.texte || 'Le soleil ne se montre jamais : un temps clair se décrit sous un ciel voilé.';
      return infobulle(h('span', { class: 'bn-horloge__voile', tabindex: '0' }, icone('brume', 'bn-icone--s')),
        [regle, monde ? `Ce ciel-ci : ${monde}` : ''].filter(Boolean).join(' '), { titre: 'Ciel toujours voilé : à dire à la table', ton: 'ultra' });
    }

    function vueHorloge() {
      const l = lecture(v());
      const astre = astreDe(l.moment);
      // La nuit de pleine lune sans météo, le titre le dit déjà ; le jour, c'est la lune de la nuit qui vient.
      // Court pour tenir sur la ligne (« ☾ dans 18 j », compté jusqu'à la prochaine pleine lune, que l'icône dit déjà,
      // demande du MJ du 2026-10-23) ; la phase en infobulle, la règle de la lune dans la fenêtre du jour.
      const phaseLune = !l.lune || (l.lune.pleine && l.moment === 'nuit' && !l.meteo) ? null
        : infobulle(h('span', { class: 'bn-horloge__lune' }, icone('lune', 'bn-icone--s'), l.lune.pleine ? 'cette nuit' : `dans ${dansJours(l.lune.dans)}`),
          l.lune.pleine ? 'Pleine lune cette nuit.'
            : `Pleine lune le ${libelleDate(l.lune.prochaine)}, dans ${l.lune.dans} jour${l.lune.dans > 1 ? 's' : ''}.`,
          { titre: l.lune.nom });
      // À gauche, les lignes du jour, serrées ; à droite, la météo et l'heure en grand, sur toute leur hauteur (côte à côte ou
      // l'une au-dessus de l'autre : ajusterBandeau).
      return h('div', { class: 'bn-horloge', 'data-moment': l.moment },
        icone(astre, 'bn-horloge__astre'),
        h('div', { class: 'bn-horloge__textes' },
          vueJour(l),
          vueCiel(l),
          h('span', { class: 'ui-s bn-horloge__detail' }, vueSoleil(l), phaseLune ? [' · ', phaseLune] : null),
          vueJourMarque(l)),
        h('div', { class: 'bn-horloge__droite' },
          l.meteo ? vueMeteo(meteo, l.meteo, { nuit: l.moment === 'nuit', texte: false, classe: 'bn-horloge__meteo' }) : null,
          h('button', { type: 'button', class: 'bn-horloge__heure', title: titreRegler, onclick: () => regler() }, libelleHeure(v().minute))),
        h('ol', { class: 'bn-horloge__phases' }, MOMENTS.map(([id, lib]) => h('li', { 'aria-current': id === l.moment ? 'true' : null }, lib))));
    }

    // Où sont les héros : le terrain du widget Rencontres (etat/rencontres.json), partagé.
    function vueTerrain() {
      return h('div', { class: 'cm-contexte cm-horloge__terrain' },
        h('span', { class: 'etiquette' }, 'Les héros sont'),
        bascule('Où sont les héros', TERRAINS, sR.valeur.contexte.terrain, t => {
          sR.valeur.contexte.terrain = t;
          sR.enregistrer(0);
          sR.signaler(rendre);
          rendre();
        }));
    }

    // Une ligne : « + » (une durée au choix), repos et attentes en libellés courts, « Annuler ».
    function vueCommandes() {
      const r = reglagesDe(v());
      return h('div', { class: 'cm-horloge__commandes', role: 'group', 'aria-label': 'Faire passer le temps' },
        boutonAvancer('Faire avancer le temps', PAS.map(([min, lib]) => [lib, `Avancer de ${libelleDuree(min)}`, () => (min >= 60 ? passer(min, lib) : avancer(s, min, lib))])),
        boutonRepos('sablier', 'court', `Repos court : ${libelleDuree(REPOS_COURT)}`, () => passer(REPOS_COURT, 'Repos court', 'court')),
        boutonRepos('lune', 'long', `Repos long : ${libelleDuree(REPOS_LONG)}, jusqu'à l'heure ronde suivante ; noté comme dernier repos long`, () => passer(REPOS_LONG, 'Repos long', 'long')),
        boutonRepos('soleil', 'aube', `Attendre l'aube : jusqu'au lever du soleil, à ${libelleHeure(r.lever)}`, () => passer(jusqua(v(), r.lever), 'Attendre l\'aube'), true),
        boutonRepos('cierge', 'soir', `Attendre le soir : jusqu'au coucher du soleil, à ${libelleHeure(r.coucher)}`, () => passer(jusqua(v(), r.coucher), 'Attendre le soir'), true),
        btnAnnuler);
    }

    // En-tête du widget réduit : l'icône du moment (dans sa couleur : soleil, cierge à l'aube et au crépuscule, lune), l'heure
    // en grand, la météo (icône du ciel et température, l'icône seule si la place manque), puis deux lignes l'une sur l'autre :
    // jour, moment et où sont les héros ; ce qui vient ou l'activité en cours. La date et le temps qu'il fait au survol.
    function majEntete() {
      const l = lecture(v());
      const terrain = TERRAINS.find(([id]) => id === sR.valeur.contexte.terrain)?.[1];
      const activite = activiteCourante(v());
      const veille = sansReposLong(v());
      const haut = [`Jour ${v().jour}`, MOMENTS.find(([id]) => id === l.moment)?.[1], terrain].filter(Boolean).join(' · ');
      const suite = activite ? `${activite.titre} (${libelleDuree(activite.fait || 0)} / ${libelleDuree(activite.total)})` : l.ensuite || '';
      const alerteRepos = veille !== null && veille > VEILLE_MAX ? 'plus de 24 h sans repos long : fatigue +1' : '';
      const c = l.meteo?.creneau;
      resume.title = [`${libelleHeure(v().minute)} · ${haut}`, l.date ? libelleDateComplete(l.date) : '',
        c ? `${l.meteo.nom} : ${c.texte}, ${libelleTemperature(c.min, c.max)}` : '', suite, alerteRepos].filter(Boolean).join('\n');
      resume.classList.add('cm-horloge__resume');
      resume.dataset.moment = l.moment;
      resume.replaceChildren(
        icone(astreDe(l.moment), 'cm-horloge__resume-astre'),
        h('span', { class: 'cm-horloge__resume-heure' }, libelleHeure(v().minute)),
        c ? h('span', { class: 'cm-horloge__resume-meteo' }, icone(iconeMeteo(c, l.moment === 'nuit')), h('span', {}, libelleTemperature(c.min, c.max))) : '',
        h('span', { class: 'surtitre' }, haut),
        h('span', { class: 'cm-horloge__resume-suite' }, suite, alerteRepos ? h('span', { class: 'cm-horloge__alerte' }, `${suite ? ' · ' : ''}${alerteRepos}`) : ''));
    }

    // Dernier repos long : au-delà de 24 h, alerte repliée « Fatigue +1 » (pendant une activité, c'est sa carte qui la montre).
    function vueRepos(enActivite) {
      const veille = sansReposLong(v());
      if (enActivite && veille !== null && veille > VEILLE_MAX) return null;
      if (veille === null) {
        return h('p', { class: 'ui-s cm-sourdine cm-horloge__dernier' }, 'Dernier repos long : pas encore noté. ',
          h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => noterReposLong(s) }, 'Il vient de se terminer'), ' · ',
          h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => regler() }, 'Indiquer quand'));
      }
      const texte = `Dernier repos long terminé ${libelleMoment(v().repos_long)}, il y a ${libelleDuree(Math.max(0, veille))}.`;
      return veille > VEILLE_MAX
        ? garderOuvert('veille', alerteVeille(v(), veille))
        : h('p', { class: 'ui-s cm-sourdine cm-horloge__dernier' }, icone('lune', 'bn-icone--s'), ' ', texte);
    }

    // Journal des avancées. La croix de la dernière ligne l'annule, comme « Annuler » (l'heure recule, les suites sont
    // proposées) ; celle d'une ligne plus ancienne la retire seulement, sans changer l'heure (retour du MJ, 2026-10-23 :
    // retirer les dernières lignes laissait l'horloge en avance).
    let journalOuvert = false;
    function vueJournal() {
      const tout = v().journal || [];
      if (!tout.length) return null;
      const lignes = tout.map((e, i) => ({ e, i })).reverse().slice(0, 30);
      const croix = i => (i === tout.length - 1
        ? bouton('', { icone: 'lu-rotate-ccw', titre: `Annuler cette avancée (revenir à ${libelleMoment(retourDe(v()))})`, classe: 'bn-btn--s bn-btn--fantome cm-horloge__retirer', onclick: () => annulerAvecSuites(contexte) })
        : bouton('', { icone: 'lu-x', titre: `Retirer cette ligne du journal (l'heure ne change pas)`, classe: 'bn-btn--s bn-btn--fantome cm-horloge__retirer', onclick: () => retirerDuJournal(s, i) }));
      const det = h('details', { class: 'cm-repli', open: journalOuvert, ontoggle: e => { journalOuvert = e.target.open; } },
        h('summary', { class: 'etiquette' }, `Journal (${tout.length})`),
        h('ol', { class: 'cm-horloge__journal' }, lignes.map(({ e, i }) => h('li', {},
          h('span', { class: 'cm-horloge__ecart' }, `${enMinutes(e.apres) >= enMinutes(e.avant) ? '+' : ''}${libelleDuree(enMinutes(e.apres) - enMinutes(e.avant))}`),
          h('span', {}, h('b', {}, e.motif), h('span', { class: 'cm-sourdine' }, ` · ${libelleMoment(e.avant)} → ${libelleMoment(e.apres)}`)),
          croix(i)))),
        h('p', { class: 'ui-s cm-sourdine' }, 'La dernière ligne s\'annule (l\'heure recule) ; une ligne plus ancienne se retire sans changer l\'heure. Pour rattraper un oubli, un clic sur l\'heure la règle.'));
      return det;
    }

    // Activité en cours (trajet, repos, attente) : menée dans une fenêtre flottante, pour ne pas faire défiler le widget.
    // Elle s'ouvre d'elle-même au début de chaque activité ; elle ne se ferme pas tant que l'activité dure, pour ne pas perdre
    // le fil (demande du MJ, 2026-11-01) : elle se réduit, et le résumé du widget ou sa barre la rouvrent.
    let activiteOuverte = null;   // id de la dernière activité ouverte d'office
    const FENETRE = 'horloge-activite';
    const PICTOS_ACTIVITE = { voyage: 'lu-route', repos: 'lune', attente: 'sablier' };
    function ouvrirActivite(a) {
      flottant(FENETRE, { surtitre: LIBELLES_ACTIVITE[a.type], titre: a.titre, largeur: 560, fermable: false, pictogramme: PICTOS_ACTIVITE[a.type],
        contenu: vueActivite(contexte, a, { sH: s, sR, intervalle, annuler: btnAnnuler, fenetre: true }) });
    }
    function suivreActivite(a) {
      if (!a) { flottantOuvert(FENETRE)?.fermer(); return; }
      if (a.id !== activiteOuverte) { activiteOuverte = a.id; flottantOuvert(FENETRE)?.fermer(); ouvrirActivite(a); }
      else if (flottantOuvert(FENETRE)) sansRamener(() => ouvrirActivite(a));
    }
    // La fenêtre d'un trajet suit ses rencontres prévues (lancée, terminée…).
    rencontresMj?.s.abonner(() => { const a = activiteCourante(v()); if (a && flottantOuvert(FENETRE)) sansRamener(() => ouvrirActivite(a)); });
    function vueActiviteResume(a) {
      return h('button', { type: 'button', class: 'bn-carte cm-activite cm-activite--resume', title: 'Ouvrir la fenêtre de l’activité', onclick: () => ouvrirActivite(a) },
        h('span', { class: 'surtitre' }, LIBELLES_ACTIVITE[a.type]),
        h('span', { class: 'cm-activite__titre' }, a.titre),
        h('span', { class: 'cm-activite__barre' }, h('span', { style: `width: ${Math.min(100, (a.fait / a.total) * 100)}%` })),
        h('span', { class: 'cm-activite__suite' }, `${libelleDuree(a.fait)} sur ${libelleDuree(a.total)}`, h('span', {}, icone('lu-maximize-2', 'bn-icone--s'), ' Ouvrir')));
    }

    function rendre() {
      const dernier = v().journal?.at(-1);
      btnAnnuler.disabled = !dernier;
      const titre = dernier ? `Annuler : ${dernier.motif} (revenir à ${libelleMoment(retourDe(v()))})` : 'Rien à annuler';
      btnAnnuler.title = titre;
      btnAnnuler.setAttribute('aria-label', titre);
      const activite = activiteCourante(v());
      majEntete();
      corps.replaceChildren(...[
        vueHorloge(),
        !v().maj && !(v().journal || []).length ? h('p', { class: 'ui-s cm-sourdine' }, 'Pas encore réglée : jour 1, 8 h. ',
          h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => regler() }, 'Régler l\'horloge')) : null,
        vueTerrain(),
        activite ? vueActiviteResume(activite) : vueCommandes(),
        vueRepos(!!activite),
        vueJournal(),
      ].filter(Boolean));
      ajusterBandeau();
      suivreActivite(activite);
      rafraichirJour();   // la fenêtre du jour suit l'horloge
    }

    // Haut de l'horloge : la météo à gauche de l'heure tant que possible (en grand, puis plus petites, la date sous « JOUR 1 »,
    // la météo sans son texte, le tout resserré), sinon l'heure au-dessus de la météo (charte, .bn-horloge--cote, --serre,
    // --sans-texte, --pile, --jour-empile, --etroit). On garde la première qui tient : rien ne déborde, la température
    // entière, quelques lettres du texte de la météo, la date entière (sauf la dernière, où elle se coupe en « … »). Mesuré
    // à chaque rendu et quand le widget change de taille, sans seuil fixe.
    const DISPOSITIONS = [['cote'], ['serre'], ['serre', 'jour-empile'], ['serre', 'sans-texte', 'jour-empile'],
      ['serre', 'sans-texte', 'jour-empile', 'etroit'], ['pile'], ['pile', 'jour-empile'], ['pile', 'jour-empile', 'etroit']]
      .map(l => l.map(d => `bn-horloge--${d}`));
    const CLASSES_DISPOSITION = [...new Set(DISPOSITIONS.flat())];
    // Les enfants de `el` restent dans son cadre. Calés à droite, ils débordent à gauche quand la place manque, ce que
    // scrollWidth ne voit pas.
    const dansSonCadre = el => {
      if (!el) return true;
      const cadre = el.getBoundingClientRect();
      return [...el.children].every(c => {
        const q = c.getBoundingClientRect();
        return !q.width || (q.left >= cadre.left - 1 && q.right <= cadre.right + 1);
      });
    };
    function tient(bloc) {
      const droite = bloc.querySelector('.bn-horloge__droite'), meteo = bloc.querySelector('.bn-horloge__meteo');
      const texte = meteo?.querySelector('.bn-meteo__texte'), date = bloc.querySelector('.bn-horloge__date');
      return bloc.scrollWidth <= bloc.clientWidth + 1
        && dansSonCadre(droite) && dansSonCadre(meteo)
        && (!texte || texte.clientWidth >= Math.min(texte.scrollWidth, 52))
        && (!date || date.scrollWidth <= date.clientWidth + 1);
    }
    function ajusterBandeau() {
      const bloc = corps.querySelector('.bn-horloge');
      if (!bloc) return;
      for (const d of DISPOSITIONS) {
        bloc.classList.remove(...CLASSES_DISPOSITION);
        bloc.classList.add(...d);
        if (tient(bloc)) break;
      }
    }
    new ResizeObserver(ajusterBandeau).observe(corps);

    // ───── Réglage : jour, heure, dernier repos long, soleil, lune ─────

    function regler() {
      const r = reglagesDe(v());
      const champ = (libelle, input, aide) => h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, libelle), input, aide ? h('span', { class: 'ui-s cm-sourdine' }, aide) : null);
      const nombre = (valeur, attrs = {}) => h('input', { class: 'bn-input bn-input--nombre', type: 'number', step: '1', value: valeur ?? '', ...attrs });
      const heure = valeur => h('input', { class: 'bn-input', type: 'time', step: '60', value: valeur === null || valeur === undefined ? '' : enHHMM(valeur) });
      // Sous le jour de campagne, sa date au calendrier, qui suit la saisie.
      const dateLue = h('span', {});
      const lireDate = () => {
        const n = Number(jour.value);
        const d = Number.isInteger(n) && n >= 1 ? lecture({ ...v(), jour: n }).date : null;
        dateLue.textContent = d ? libelleDateComplete(d) : 'Jour 1 : le début de la campagne.';
      };
      const jour = nombre(v().jour, { min: '1', oninput: () => lireDate() });
      lireDate();
      const hh = heure(v().minute);
      const reposJour = nombre(v().repos_long?.jour, { min: '1', placeholder: '—' });
      const reposHeure = heure(v().repos_long?.minute);
      const lever = heure(r.lever);
      const coucher = heure(r.coucher);
      const erreur = h('div');
      let dlg;
      const enregistrer = () => {
        const n = x => Number(x.value);
        const m = depuisHHMM(hh.value), ml = depuisHHMM(lever.value), mc = depuisHHMM(coucher.value), mr = depuisHHMM(reposHeure.value);
        const sansRepos = reposJour.value === '' && reposHeure.value === '';
        const pb = [
          !(Number.isInteger(n(jour)) && n(jour) >= 1) ? 'Le jour est un nombre entier, 1 ou plus.' : null,
          m === null ? 'Indiquez l\'heure.' : null,
          !sansRepos && (!(Number.isInteger(n(reposJour)) && n(reposJour) >= 1) || mr === null) ? 'Pour le dernier repos long, indiquez le jour et l\'heure où il s\'est terminé (ou laissez les deux vides).' : null,
          ml === null || mc === null || ml + 120 > mc ? 'Le soleil se lève au moins deux heures avant de se coucher.' : null,
        ].filter(Boolean);
        if (pb.length) { erreur.replaceChildren(alerte('sang', 'crane', 'À corriger', h('ul', { class: 'ui-s cm-liste' }, pb.map(x => h('li', {}, x))))); return; }
        v().reglages = { lever: ml, coucher: mc };
        v().repos_long = sansRepos ? null : { jour: n(reposJour), minute: mr };
        changer(s, { jour: n(jour), minute: m }, 'Réglage', { silencieux: true });
        s.signaler();
        s.sauverMaintenant().then(rendre);   // « Pas encore réglée » disparaît une fois l'horloge enregistrée
        dlg.close();
      };
      dlg = dialogue('Horloge', 'Régler l\'horloge', h('form', { class: 'cm-pile', onsubmit: e => { e.preventDefault(); enregistrer(); } },
        h('div', { class: 'bn-ligne-champs' }, champ('Jour de campagne', jour, dateLue), champ('Heure', hh)),
        h('div', { class: 'bn-ligne-champs' }, champ('Dernier repos long terminé : jour', reposJour), champ('à', reposHeure, 'Vide : pas encore noté.')),
        h('details', { class: 'cm-repli' },
          h('summary', { class: 'etiquette' }, 'Soleil'),
          h('div', { class: 'cm-pile' },
            h('div', { class: 'bn-ligne-champs' }, champ('Lever du soleil', lever), champ('Coucher du soleil', coucher)),
            h('p', { class: 'ui-s cm-sourdine' }, `L'aube et le crépuscule durent une heure de part et d'autre. Rencontres prend la table de nuit après le crépuscule et jusqu'à l'aube.${cal ? ` La date, l'année et la lune suivent le ${calendrierMin} (fenêtre Campagne, onglet « Campagne »).` : ''}`))),
        erreur,
        h('button', { type: 'submit', hidden: true })),
      h('div', { class: 'bn-groupe' },
        bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: enregistrer }),
        bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    }

    s.abonner(rendre);
    s.abonner(verifierAlertes);   // un nouveau jour : les rappels de l'agenda
    sR.abonner(rendre);   // terrain changé ailleurs (Rencontres, passage du temps)
    rendre();
    return {};
  },
};
