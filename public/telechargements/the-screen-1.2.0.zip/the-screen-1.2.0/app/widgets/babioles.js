// Widget Babioles : tirage de petits objets à faire trouver aux personnages, liste filtrable, suivi des babioles données.
// Une babiole tirée, choisie dans la liste ou dans les derniers tirages s'ouvre dans une fenêtre flottante (app/babioles.js,
// fiche partagée avec Rencontres). Données : data/babioles.json (formats/babioles.md). État : etat/babioles.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, normaliser, heure, flottantOuvert, lienFlottant } from '../ui.js';
import { fichesBabioles, plageBabiole as plage, vierge, intituleBabiole as intitule, tirerParmi, noterTirage } from '../babioles.js';

const ICONES_LIENS = { lieu: 'epingle', sous_lieu: 'porte', pnj: 'crocs', faction: 'bouclier', element_intrigue: 'glyphe', personnage: 'lu-users' };
const DISTRIBUTION =[['', 'Données ou non'], ['non', 'Pas encore données'], ['oui', 'Déjà données']];

export default {
  type: 'babioles',
  requiert: 'babioles',
  titre: 'Babioles',
  icone: 'cle',
  description: 'Petits objets étranges à faire trouver aux personnages : tirage dans les trois tables, liste filtrable par thème ou par lien, babioles déjà données écartées.',
  taille: { w: 5, h: 16 },
  min: { w: 3, h: 7 },
  unique: true,

  async monter({ corps, actions, donnees, etat, dialogue }) {
    const lecture = await donnees('babioles');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Babioles indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const fb = await fichesBabioles({ donnees, etat, dialogue });
    const { d, tables, parId, s, lieux, elements: elementsIntrigue, donnee, libelleDonnee, secrete, nomElement } = fb;
    if (!tables.length) {
      corps.append(alerte('sang', 'lu-database', 'Babioles indisponibles', 'babioles.json ne contient aucune table lisible.'));
      return {};
    }
    const v = () => s.valeur;
    const table = () => tables.find(t => t.id === v().table);

    // Ligne affichée : { id, jet (null si choisie dans la liste), cible (tirage parmi les lignes filtrées) }.
    // Au chargement : le dernier tirage de la table en cours.
    let affiche = null;
    const dernierTirage = () => {
      const e = [...v().historique].reverse().find(x => x.table === v().table && parId.has(x.ligne));
      return e ? { id: e.ligne, jet: e.jet, cible: false } : null;
    };
    affiche = dernierTirage();

    // ───── Filtres de la liste ─────

    const filtre = { texte: '', theme: '', type: '', element: '', distrib: '' };
    const filtresActifs = () => Object.values(filtre).some(Boolean);

    // Élément lié (« lieu:aurval ») : un lieu compte aussi ses sous-lieux, les lieux situés dedans et les éléments d'intrigue qui s'y trouvent.
    function touche(l, cle) {
      const i = cle.indexOf(':');
      const type = cle.slice(0, i), id = cle.slice(i + 1);
      return (l.lore_links || []).some(k => (k.type === type && k.id === id) || (type === 'lieu' && (
        (k.type === 'sous_lieu' && lieux.get(k.id)?.parent === id)
        || (k.type === 'lieu' && lieux.get(k.id)?.situe_dans === id)
        || (k.type === 'element_intrigue' && elementsIntrigue.get(k.id)?.lieu === id))));
    }

    function correspond(l) {
      if (filtre.theme && l.theme !== filtre.theme) return false;
      if (filtre.type && !(l.lore_links || []).some(k => k.type === filtre.type)) return false;
      if (filtre.element && !touche(l, filtre.element)) return false;
      if (filtre.distrib && !!donnee(l) !== (filtre.distrib === 'oui')) return false;
      if (filtre.texte) {
        const q = normaliser(filtre.texte);
        if (![l.nom, l.texte, l.note_mj].some(c => normaliser(c).includes(q))) return false;
      }
      return true;
    }

    const recherche = h('input', {
      class: 'bn-input', type: 'search', placeholder: 'Nom, texte, note du MJ…', 'aria-label': 'Chercher une babiole',
      oninput: e => { filtre.texte = e.target.value; rendreListe(); },
    });
    const selTheme = h('select', { class: 'bn-select', 'aria-label': 'Thème', onchange: e => { filtre.theme = e.target.value; rendreListe(); } });
    const selType = h('select', { class: 'bn-select', 'aria-label': 'Type de lien', onchange: e => { filtre.type = e.target.value; rendreListe(); } });
    const selElement = h('select', { class: 'bn-select', 'aria-label': 'Élément lié', onchange: e => { filtre.element = e.target.value; rendreListe(); } });
    const selDistrib = h('select', { class: 'bn-select', 'aria-label': 'Données ou non', onchange: e => { filtre.distrib = e.target.value; rendreListe(); } },
      DISTRIBUTION.map(([val, txt]) => h('option', { value: val }, txt)));


    // Options des filtres : ce que contient la table choisie. Les factions secrètes n'y figurent pas (le thème les couvre).
    function remplirFiltres() {
      const lignes = table().lignes.filter(l => !vierge(l));
      const themes = Object.keys(d.themes || {}).filter(th => lignes.some(l => l.theme === th));
      selTheme.replaceChildren(h('option', { value: '' }, 'Tous les thèmes'), ...themes.map(th => h('option', { value: th }, d.themes[th])));
      selTheme.hidden = !themes.length;
      const liens = lignes.flatMap(l => l.lore_links || []).filter(k => !secrete(k));
      const types = Object.keys(d.types_liens || {}).filter(t => liens.some(k => k.type === t));
      selType.replaceChildren(h('option', { value: '' }, 'Tous les liens'), ...types.map(t => h('option', { value: t }, d.types_liens[t])));
      selType.hidden = !types.length;
      // Les lieux comptent aussi ceux des sous-lieux et des éléments d'intrigue (« tout ce qui touche à ce lieu »).
      const elements = new Map(types.map(t => [t, new Set()]));
      for (const k of liens) {
        elements.get(k.type)?.add(k.id);
        const lieu = k.type === 'sous_lieu' ? lieux.get(k.id)?.parent : k.type === 'element_intrigue' ? elementsIntrigue.get(k.id)?.lieu : null;
        if (lieu) (elements.get('lieu') || elements.set('lieu', new Set()).get('lieu')).add(lieu);
      }
      selElement.replaceChildren(h('option', { value: '' }, 'Tous les éléments liés'),
        ...Object.keys(d.types_liens || {}).filter(t => elements.get(t)?.size).map(t => h('optgroup', { label: d.types_liens[t] },
          [...elements.get(t)].map(id => [id, nomElement(t, id)]).sort((a, b) => a[1].localeCompare(b[1], 'fr'))
            .map(([id, nom]) => h('option', { value: `${t}:${id}` }, nom)))));
      selElement.hidden = !types.length;
      for (const [cle, sel] of [['theme', selTheme], ['type', selType], ['element', selElement]]) {
        if (![...sel.options].some(o => o.value === filtre[cle])) filtre[cle] = '';
        sel.value = filtre[cle];
      }
    }

    // ───── Tirage ─────

    // Lignes tirables : jamais une ligne vierge ; sans les babioles données si l'option est cochée ; filtrées pour un tirage ciblé.
    const candidats = cible => table().lignes.filter(l => !vierge(l) && !(v().ecarter_distribuees && donnee(l)) && (!cible || correspond(l)));

    // Chances égales par résultat de dé couvert : une ligne 81-82 a deux chances sur cent.
    function tirer(cible, eviter = null) {
      let liste = candidats(cible);
      if (!liste.length) return;
      if (eviter && liste.length > 1) liste = liste.filter(l => l.id !== eviter);
      const { l, jet } = tirerParmi(liste);
      noterTirage(s, table().id, l, jet);
      s.enregistrer(0);
      affiche = { id: l.id, jet, cible };
      // Le tirage s'ouvre dans sa fenêtre ; « Relancer » remplace la babiole écartée par la nouvelle.
      if (eviter) flottantOuvert('babiole:' + eviter)?.fermer();
      rendre();
      ouvrirBabiole(l, { jet, cible, tirage: true });
    }

    // Babiole tirée, ou choisie dans la liste ou les derniers tirages : sa fiche dans une fenêtre flottante (une par babiole).
    // tirage : elle vient d'être tirée, « Relancer » en tire une autre (parmi les lignes filtrées si cible).
    const ouvrirBabiole = (l, { jet = null, cible = false, tirage = false } = {}) => fb.ouvrir(l, { jet, relancer: tirage ? {
      possible: () => candidats(cible).length > 0, faire: () => tirer(cible, l.id),
      titre: cible ? 'Relancer parmi les lignes filtrées' : 'Relancer dans la table',
    } : null });

    // ───── Vues ─────

    const zoneTete = h('div', { class: 'cm-pile' });
    const compteurListe = h('span', { class: 'ui-s cm-sourdine' });
    const btnCible = bouton('Tirer parmi ces lignes', { icone: 'd20', classe: 'bn-btn--s', onclick: () => tirer(true) });
    const liste = h('ol', { class: 'cm-babioles-liste' });
    const zoneHistorique = h('div', {});
    let historiqueOuvert = false;   // « Derniers tirages » reste déplié quand on y retire des tirages

    // Recherche et filtres : masquables par le bouton de l'en-tête (comme PNJ), choix gardé dans le navigateur. Masqués,
    // ils filtrent encore : le bouton le rappelle en orange.
    const filtres = h('div', { class: 'cm-pnj-filtres' },
      h('div', { class: 'cm-recherche' }, icone('lu-search', 'bn-icone--s'), recherche),
      h('div', { class: 'cm-pnj-selects' }, selTheme, selType, selElement, selDistrib),
      h('div', { class: 'cm-contexte' }, btnCible, compteurListe));
    const CLE_FILTRES = 'cm:babioles:filtres';
    let filtresVisibles = true;
    try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* pas de stockage : visibles */ }
    const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      filtresVisibles = !filtresVisibles;
      try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* le choix vaut pour la session */ }
      majFiltres();
    } });
    function majFiltres() {
      filtres.hidden = !filtresVisibles;
      const actifs = filtresActifs();
      btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
      btnFiltres.classList.toggle('est-filtre', !filtresVisibles && actifs);
      const titre = (filtresVisibles ? 'Masquer la recherche et les filtres' : 'Afficher la recherche et les filtres') + (!filtresVisibles && actifs ? ' (des filtres sont actifs)' : '');
      btnFiltres.title = titre;
      btnFiltres.setAttribute('aria-label', titre);
    }
    actions.prepend(btnFiltres);

    // Une ligne : la table, « Tirer », « Écarter » (les babioles déjà données) et ce qu'il reste à donner.
    function rendreTete() {
      const t = table();
      const tirables = t.lignes.filter(l => !vierge(l));
      const restantes = tirables.filter(l => !donnee(l));
      const possibles = candidats(false);
      const selTable = h('select', { class: 'bn-select', 'aria-label': 'Table', title: t.usage || 'Table', onchange: e => {
        v().table = e.target.value; s.enregistrer(); affiche = dernierTirage(); remplirFiltres(); rendre();
      } }, tables.map(x => h('option', { value: x.id }, `${x.nom} · ${x.de}`)));
      selTable.value = t.id;
      zoneTete.replaceChildren(...[
        h('div', { class: 'cm-babioles-tete' },
          selTable,
          bouton('Tirer', { icone: 'd20', classe: 'bn-btn--s bn-btn--primaire', titre: 'Tirer une babiole dans la table', disabled: !possibles.length, onclick: () => tirer(false) }),
          tirables.length ? [
            h('label', { class: 'cm-case', title: 'Écarter du tirage les babioles déjà données' },
              h('input', { type: 'checkbox', class: 'bn-case', checked: !!v().ecarter_distribuees, onchange: e => { v().ecarter_distribuees = e.target.checked; s.enregistrer(0); rendre(); } }),
              'Écarter'),
            h('span', { class: 'cm-babioles-tete__reste', title: `${restantes.length} babiole${restantes.length > 1 ? 's' : ''} sur ${tirables.length} pas encore donnée${restantes.length > 1 ? 's' : ''}` },
              icone('lu-gift', 'bn-icone--s'), `${restantes.length}/${tirables.length}`)] : null),
        !tirables.length ? alerte('cierge', 'lu-triangle-alert', 'Table vide', `Les ${t.lignes.length} lignes de « ${t.nom} » sont vides (« a_remplir » dans data/babioles.json). Remplissez-les à la main ou avec votre agent IA de campagne si vous en avez un.`) : null,
        tirables.length && !possibles.length ? alerte('cierge', 'lu-gift', 'Tout est distribué', 'Toutes les babioles de cette table ont été données. Décochez « Écarter les babioles déjà distribuées » pour tirer quand même.') : null,
      ].filter(Boolean));
    }


    // Étiquettes des liens d'une ligne de la liste (sans les factions secrètes) ; celle de l'élément filtré ressort.
    function etiquettesLiens(l) {
      const liens = (l.lore_links || []).filter(k => !secrete(k));
      if (!liens.length) return null;
      return h('span', { class: 'cm-babiole-ligne__liens' }, liens.map(k => h('span', {
        class: 'cm-etiquette-lien' + (filtre.element === `${k.type}:${k.id}` ? ' est-filtre' : ''),
        title: `${d.types_liens?.[k.type] || k.type} : ${nomElement(k.type, k.id)}${k.note ? `\n${k.note}` : ''}`,
      }, icone(ICONES_LIENS[k.type] || 'epingle', 'bn-icone--s'), nomElement(k.type, k.id))));
    }

    function rendreListe() {
      const t = table();
      const actifs = filtresActifs();
      // Avec un filtre, les emplacements vierges disparaissent : ils n'ont ni texte ni lien.
      const lignes = t.lignes.filter(l => !actifs || (!vierge(l) && correspond(l)));
      const ciblables = actifs ? candidats(true).length : 0;
      compteurListe.textContent = `${lignes.length} ligne${lignes.length > 1 ? 's' : ''}`;
      btnCible.disabled = !ciblables;
      majFiltres();
      btnCible.querySelector('span').textContent = actifs ? `Tirer parmi ces lignes (${ciblables})` : 'Tirer parmi ces lignes';
      btnCible.title = !actifs ? 'Choisissez d\'abord un filtre' : v().ecarter_distribuees ? 'Parmi les lignes filtrées pas encore données' : 'Parmi les lignes filtrées';
      liste.replaceChildren(...(lignes.length ? lignes.map(l => {
        const dist = donnee(l);
        return h('li', {}, lienFlottant(h('button', {
          type: 'button',
          class: 'cm-babiole-ligne cm-ouvre' + (vierge(l) ? ' est-vierge' : '') + (dist ? ' est-donnee' : '') + (affiche?.id === l.id ? ' est-choisie' : ''),
          'aria-current': affiche?.id === l.id ? 'true' : null,
          title: [l.theme ? d.themes?.[l.theme] : null, dist ? libelleDonnee(dist) : null].filter(Boolean).join(' · ') || null,
          onclick: () => ouvrirBabiole(l),
        },
          h('span', { class: 'cm-babiole-ligne__jet' }, plage(l)),
          h('span', { class: 'cm-babiole-ligne__corps' },
            h('span', { class: 'cm-babiole-ligne__nom cm-ouvre__nom' }, vierge(l) ? 'À remplir (data/babioles.json)' : intitule(l)),
            etiquettesLiens(l)),
          dist ? badge('Donnée', 'brume', 'lu-gift') : null), 'babiole:' + l.id));
      }) : [h('li', {}, h('p', { class: 'ui-s cm-sourdine' }, 'Aucune babiole ne correspond.'))]));
    }

    function rendreHistorique() {
      const derniers = [...v().historique].reverse().filter(e => parId.has(e.ligne)).slice(0, 10);
      zoneHistorique.replaceChildren(derniers.length ? h('details', { class: 'cm-repli', open: historiqueOuvert, ontoggle: e => { historiqueOuvert = e.target.open; } },
        h('summary', { class: 'etiquette' }, `Derniers tirages (${v().historique.length})`),
        h('ol', { class: 'cm-babioles-liste' }, derniers.map(e => {
          const { l, t } = parId.get(e.ligne);
          // La croix retire le tirage de l'historique, rien d'autre (une babiole donnée le reste).
          return h('li', { class: 'cm-babiole-tirage' }, lienFlottant(h('button', { type: 'button', class: 'cm-babiole-ligne cm-ouvre', title: t.nom, onclick: () => ouvrirBabiole(l, { jet: e.jet }) },
            h('span', { class: 'cm-babiole-ligne__jet' }, String(e.jet)),
            h('span', { class: 'cm-babiole-ligne__nom cm-ouvre__nom' }, intitule(l)),
            h('span', { class: 'ui-s cm-sourdine' }, heure(e.quand))), 'babiole:' + l.id),
            bouton('', { icone: 'lu-x', titre: 'Retirer ce tirage de l\'historique', classe: 'bn-btn--s bn-btn--fantome', onclick: () => {
              v().historique = v().historique.filter(x => x.id !== e.id);
              s.enregistrer(0);
              rendre();
            } }));
        }))) : '');
    }

    // Babioles notées comme données mais absentes de babioles.json (id renommé ?) : gardées et signalées.
    function orphelines() {
      const ids = Object.keys(v().distribuees).filter(id => !parId.has(id));
      return ids.length ? alerte('cierge', 'lu-triangle-alert', `${ids.length} babiole${ids.length > 1 ? 's' : ''} donnée${ids.length > 1 ? 's' : ''} absente${ids.length > 1 ? 's' : ''} de babioles.json`,
        h('ul', { class: 'ui-s cm-liste' }, ids.map(id => h('li', {}, `« ${id} » : ${libelleDonnee(v().distribuees[id])}${v().distribuees[id].note ? ` (${v().distribuees[id].note})` : ''}`))),
        h('p', { class: 'ui-s' }, `${ids.length > 1 ? 'Gardées telles quelles' : 'Gardée telle quelle'} dans etat/babioles.json. Un id a peut-être été renommé dans data/babioles.json.`)) : null;
    }

    function rendre() {
      const haut = corps.scrollTop;
      rendreTete();
      rendreListe();
      rendreHistorique();
      corps.replaceChildren(...[
        orphelines(),
        zoneTete,
        h('section', { class: 'cm-pile cm-babioles-parcourir', 'aria-label': 'Parcourir la table' }, filtres, liste),
        zoneHistorique,
      ].filter(Boolean));
      corps.scrollTop = haut;
      fb.rafraichir();   // fenêtres ouvertes : « Relancer » suit les filtres et « Écarter »
    }

    remplirFiltres();
    rendre();
    s.abonner(rendre);
    return {};
  },
};
