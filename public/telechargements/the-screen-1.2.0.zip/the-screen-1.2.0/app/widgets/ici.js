// Widget Ici : tout ce qui touche le lieu où sont les héros, réuni d'après l'id du lieu, sans donnée propre. Sous la carte
// du lieu, des onglets : PNJ (d'office ; factions, qui ouvre la porte), Rencontres prévues sur place, Objets à trouver
// (marchands), Trame (étapes, jalons, rappels des pistes commencées, Tarokka), Lieu (notes du MJ, trajets au départ, images,
// historique des déplacements). On peut consulter un autre lieu sans y
// emmener les héros. Au lieu général : ses sous-lieux (et les lieux situés dedans) pour y descendre, et tout ce qui s'y
// rattache, sous-lieux compris ; dans un sous-lieu, la vue se réduit à lui (PNJ, rencontres, jalons, marchands), et l'on
// remonte au lieu en un clic.
// Données : lieux, pnj, marchands, occupants-maisons, rencontres-aleatoires, deroule-campagne, tarokka, factions, temps-de-voyage
// (formats/). État : etat/ici.json (formats/etat.md) : lieu et sous-lieu actuels, arrivées, trajets faits, notes ; « Arriver »
// du widget Trajets l'écrit aussi. Suivi du déroulé : etat/deroule.json (app/trame.js).

import { h, icone, bouton, badge, alerte, section, blocOriginal, heure, flottant, lienFlottant, onglets } from '../ui.js';
import { chargerLieux, nomLieu, nomComplet, sousLieux, etatIci, arriverA, nettoyerHistorique, corrigerLieu } from '../lieux.js';
import { etatPnj, chargerFactions, suiviDe, rangDe, RANGS, lignePnj, majLignePnj, badgeFaction, ouvrirFaction, ouvrirFichePnj } from '../fiche-pnj.js';
import { outilsRencontresMj } from '../rencontres-mj.js';
import { outilsObjets } from '../objets.js';
import { ICONES_JALON, ICONE_PISTE, derouleSurLeTableau, voirJalon, voirPiste, voirEtape, etatDeroule, statutDe } from '../trame.js';
import { contributions } from '../modules.js';
import { vitessesDe, milesParHeure, minutesTrajet, enHeures, distanceVoyage } from '../voyage.js';
import { etatHorloge, horlogeEnService, maintenant, libelleMoment, libelleDuree } from '../horloge.js';
import { chargerBibliotheque } from '../bibliotheque.js';
import { tirerOccupants, vueOccupants } from './maisons.js';
import { etatRencontres, terrainDuLieu } from '../rencontres-moteur.js';
import { wikiActif } from '../campagne.js';

export default {
  type: 'ici',
  requiert: 'lieux',
  titre: 'Ici',
  icone: 'epingle',
  description: 'Le lieu où sont les héros, et tout ce qui s\'y rattache, en onglets : PNJ et factions, rencontres prévues, objets à trouver et marchands, étapes et Tarokka, puis vos notes, les trajets au départ et les images. On peut consulter un autre lieu sans les y emmener.',
  taille: { w: 5, h: 16 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, actions, donnees, etat, dialogue }) {
    const lieux = await chargerLieux(donnees);
    const principaux = [...lieux.values()].filter(l => !l.parent).sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));
    if (!principaux.length) {
      corps.append(alerte('cierge', 'lu-database', 'Lieux indisponibles', 'data/lieux.json est absent ou vide : écrivez-le, à la main ou avec votre agent IA de campagne (format : formats/lieux.md).'));
      return {};
    }
    const lire = async jeu => (await donnees(jeu)).donnees;
    const [refLieux, pnjD, marchandsD, maisonsD, rencontresD, deroule, voyage] = await Promise.all(
      ['lieux', 'pnj', 'marchands', 'occupants-maisons', 'rencontres-aleatoires', 'deroule-campagne', 'temps-de-voyage'].map(lire));
    const brut = new Map((refLieux?.lieux || []).map(l => [l.id, l]));
    const pnj = pnjD?.pnj || [];
    const pnjParId = new Map(pnj.map(p => [p.id, p]));
    const typesRang = pnjD?.types_rang || {};
    const factions = await chargerFactions(donnees);
    const sPnj = await etatPnj(etat);
    const sIci = await etatIci(etat, donnees);
    const sDeroule = deroule ? await etatDeroule(etat, donnees) : null;
    const sHorloge = await etatHorloge(etat);
    const biblio = await chargerBibliotheque(donnees, etat);
    const etapes = [...(deroule?.etapes || [])].sort((a, b) => a.ordre - b.ordre);
    const R = await outilsRencontresMj({ donnees, etat, dialogue });   // rencontres prévues et créées : app/rencontres-mj.js
    const O = await outilsObjets({ donnees, etat, dialogue });          // objets à trouver : app/objets.js
    const mph = milesParHeure(vitessesDe(voyage));   // rythme normal, à pied : la règle du MJ
    const v = () => sIci.valeur;

    // Sous-lieu des héros, s'il est bien un sous-lieu de leur lieu (un sous-lieu retiré des données est ignoré).
    const sousValide = (lieu, sl) => (sl && lieux.get(sl)?.parent === lieu ? sl : null);
    const sousHeros = () => sousValide(v().lieu, v().sous_lieu);
    let vue = lieux.has(v().lieu) ? v().lieu : principaux[0].id;   // lieu affiché
    let sousVue = vue === v().lieu ? sousHeros() : null;          // sous-lieu affiché : la vue se réduit à lui
    let lieuSuivi = v().lieu, sousSuivi = sousHeros();            // où étaient les héros au dernier rendu
    let historiqueOuvert = false;   // historique des déplacements (onglet Lieu), replié d'office
    const jetsMaisons = {};
    let retrait = null;   // dernière ligne retirée de l'historique, pour « Annuler »

    const sousCourant = () => sousVue;
    const dansVue = id => id === vue || lieux.get(id)?.parent === vue;

    function voir(id, sl = null) {
      vue = id;
      sousVue = sl;
      rendre();
      corps.scrollTop = 0;
    }

    // Descendre dans un sous-lieu, ou remonter au lieu (id null) : on consulte, les héros ne bougent pas.
    function choisirSous(id) {
      sousVue = id || null;
      rendre();
      corps.scrollTop = 0;
    }

    // Les héros arrivent : lieu actuel (et sous-lieu affiché), visite datée ; et où ils sont pour les rencontres (à l'abri
    // en ville…, voir terrainDuLieu). Dans un sous-lieu du lieu où ils sont déjà, aucune arrivée n'est notée.
    async function arriver() {
      const lieu = vue;
      arriverA(sIci, lieux, sousVue || lieu, horlogeEnService() ? maintenant(sHorloge.valeur) : null);
      const terrain = terrainDuLieu(lieux.get(lieu)?.type);
      if (terrain) {
        const sR = await etatRencontres(etat);
        sR.valeur.contexte.terrain = terrain;
        sR.enregistrer(0);
        sR.signaler();
      }
    }

    const lienLieu = id => h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Voir ce lieu', onclick: () => voir(id) }, nomLieu(lieux, id));

    // ───── En-tête : le lieu, où sont les héros, leurs venues ─────

    function vueChoix() {
      const selLieu = h('select', { class: 'bn-select', 'aria-label': 'Voir un lieu', onchange: e => voir(e.target.value) },
        principaux.map(l => h('option', { value: l.id }, (l.situe_dans ? `${l.nom} (${nomLieu(lieux, l.situe_dans)})` : l.nom) + (l.id === v().lieu ? ' · les héros sont ici' : ''))));
      selLieu.value = vue;
      return h('div', { class: 'cm-pnj-selects' }, selLieu);
    }

    // Le choix du lieu se masque par le bouton de l'en-tête, comme la recherche du widget PNJ (widget déplié ; choix propre
    // au poste, gardé dans le navigateur). Masqué pendant qu'on regarde un autre lieu que celui des héros : bouton orange.
    const CLE_CHOIX = 'cm:ici:choix';
    let choixVisible = true;
    try { choixVisible = localStorage.getItem(CLE_CHOIX) !== 'masque'; } catch { /* pas de stockage : visible */ }
    const btnChoix = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      choixVisible = !choixVisible;
      try { localStorage.setItem(CLE_CHOIX, choixVisible ? 'visible' : 'masque'); } catch { /* le choix vaut pour la session */ }
      rendre();
    } });
    function majBoutonChoix() {
      const ailleurs = vue !== v().lieu;
      btnChoix.setAttribute('aria-pressed', String(choixVisible));
      btnChoix.classList.toggle('est-filtre', !choixVisible && ailleurs);
      const titre = (choixVisible ? 'Masquer le choix du lieu' : 'Afficher le choix du lieu') + (!choixVisible && ailleurs ? ' (un autre lieu que celui des héros est affiché)' : '');
      btnChoix.title = titre;
      btnChoix.setAttribute('aria-label', titre);
    }
    actions.prepend(btnChoix);

    // ici : les héros y sont. Sans arrivée notée (lieu corrigé à la main, ou repris du groupe de personnages.json), rien à dire.
    function libelleVenues(vs, ici) {
      if (!vs.length) return ici ? '' : 'Jamais venus';
      const jours = [...new Set(vs.filter(x => x.jour).map(x => x.jour))];
      if (!jours.length) return vs.length > 1 ? `Déjà venus (${vs.length} fois)` : 'Déjà venus';
      return `Venus : ${jours.map(j => `jour ${j}`).join(', ')}${vs.some(x => !x.jour) ? ', et avant' : ''}`;
    }

    // Les héros quittent leur sous-lieu, sans quitter le lieu (aucune arrivée notée).
    function sortirDuSousLieu() {
      v().sous_lieu = null;
      sIci.enregistrer(0);
      sIci.signaler();
    }

    function vueTete() {
      const l = lieux.get(vue);
      const sl = sousVue ? lieux.get(sousVue) : null;
      const b = brut.get(vue) || {};
      const herosIci = vue === v().lieu;
      const herosSous = herosIci ? sousHeros() : null;
      const ici = herosIci && (!sl || herosSous === sousVue);
      const nl = l.niveau_livre;
      const meta = [l.typeLibelle, l.zone ? `zone ${l.zone}` : null, l.chapitre_livre ? `chap. ${l.chapitre_livre}` : null,
        nl ? `niv. ${nl.min === nl.max ? nl.min : `${nl.min} à ${nl.max}`}` : null].filter(Boolean).join(' · ');
      const sls = sousLieux(lieux, vue);
      const contenus = principaux.filter(x => x.situe_dans === vue);
      // Sous-lieux, et lieux situés dedans : un clic pour y descendre. Celui où sont les héros porte l'épingle.
      const descendre = (x, dedans) => h('button', {
        type: 'button', class: 'bn-badge bn-lieu__sous-lieu' + (x.id === herosSous ? ' est-ici' : ''),
        title: dedans ? `${x.nom} : un lieu à part, situé dans ${l.nom}` : `${x.nom}${x.zone ? ` (zone ${x.zone})` : ''}${x.id === herosSous ? ' : les héros y sont' : ''}`,
        onclick: () => (dedans ? voir(x.id) : choisirSous(x.id)),
      }, x.id === herosSous ? icone('epingle') : dedans ? icone('chateau') : null, x.nom);
      const repere = ici ? badge('Les héros sont ici', 'brume', 'epingle') : null;
      repere?.classList.add('bn-lieu__ici');
      const carte = h('div', { class: 'bn-carte bn-lieu' + (ici ? ' est-ici' : '') },
        meta || repere ? h('div', { class: 'bn-lieu__haut' }, meta ? h('span', { class: 'surtitre' }, meta) : null, repere) : null,
        sl ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton bn-lieu__remonter', title: `Remonter à tout ${l.nom}, sous-lieux compris`, onclick: () => choisirSous(null) },
          icone('lu-corner-left-up', 'bn-icone--s'), l.nom) : null,
        h('h3', { class: 'titre-m' }, sl ? sl.nom : l.nom,
          sl?.zone ? h('span', { class: 'cm-zone' }, sl.zone) : null,
          !sl ? contributions('lieuRepere', vue, etapes) : null),   // modules de campagne (le Tarokka) : app/modules.js
        l.situe_dans && !sl ? h('p', { class: 'ui-s' }, 'Dans : ', lienLieu(l.situe_dans)) : null,
        !sl && (sls.length || contenus.length) ? h('div', { class: 'bn-lieu__sous' }, sls.map(x => descendre(x, false)), contenus.map(x => descendre(x, true))) : null,
        h('div', { class: 'cm-contexte bn-lieu__bas' },
          ici ? null
            : bouton('Les héros arrivent ici', { classe: 'bn-btn--s bn-btn--primaire', icone: 'epingle', titre: herosIci ? `Ils passent dans ${sl.nom} (pas d'arrivée notée : ils sont déjà à ${l.nom})` : horlogeEnService() ? 'Noter leur arrivée, à l\'heure de l\'horloge' : 'Noter leur arrivée', onclick: arriver }),
          !sl && herosSous ? h('span', { class: 'ui-s bn-lieu__dans' }, 'dans ', h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => choisirSous(herosSous) }, nomLieu(lieux, herosSous)),
            bouton('', { icone: 'lu-x', classe: 'bn-btn--s bn-btn--fantome', titre: `Ils quittent ${nomLieu(lieux, herosSous)} (et restent à ${l.nom})`, onclick: sortirDuSousLieu })) : null,
          !ici && v().lieu ? bouton('Où ils sont', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: `Revenir à ${nomComplet(lieux, v().lieu, sousHeros())}`, onclick: () => voir(v().lieu, sousHeros()) }) : null,
          (venues => (sl || !venues ? null : h('span', { class: 'ui-s cm-sourdine' }, venues)))(libelleVenues((v().visites || []).filter(x => x.lieu === vue), herosIci)),
          !sl && wikiActif() && l.wiki?.url ? h('a', { class: 'bn-lien ui-s', href: l.wiki.url, target: '_blank', rel: 'noopener' }, 'Page du wiki') : null),
        sl ? null : b.decision_mj ? h('div', { class: 'cm-decision' }, badge('Décision du MJ', 'sang'), h('p', { class: 'ui' }, b.decision_mj.texte)) : null,
        sl ? null : blocOriginal(b.original));
      placeRepere.disconnect();
      if (repere) {
        placeRepere.observe(carte);
        document.fonts?.ready.then(() => carte.isConnected && placerRepere(carte));   // les polices changent la largeur des textes
      }
      return carte;
    }

    // « Les héros sont ici » : en haut à droite de la carte du lieu, sur la ligne de sa description tant qu'elle y tient
    // sur une ligne ; sinon en bas à droite (.est-repere-bas). Mesuré à chaque redimensionnement.
    const placeRepere = new ResizeObserver(entrees => entrees.forEach(e => placerRepere(e.target)));
    function placerRepere(carte) {
      const repere = carte.querySelector('.bn-lieu__ici');
      const haut = carte.querySelector('.bn-lieu__haut'), bas = carte.querySelector('.bn-lieu__bas');
      if (!repere || !haut || !bas) return;
      carte.classList.remove('est-repere-bas');
      haut.append(repere);
      const meta = haut.querySelector('.surtitre');
      if (meta && meta.scrollWidth > meta.clientWidth + 1) {
        carte.classList.add('est-repere-bas');
        bas.append(repere);
      }
    }

    // ───── Contenus des onglets : chacun { n (nombre d'éléments, 0 : rien à montrer), contenu() } ─────

    // PNJ : rangés ici (dans le sous-lieu choisi), du plus important au plus discret ; les mineurs repliés ; puis ceux qu'on y croise aussi.
    // Un clic sur un PNJ ouvre sa fiche dans une fenêtre flottante.
    const optionsLigne = () => ({ lieux, s: sPnj, surChange: changementPnj, factions, typesRang });
    function blocPnj() {
      const sous = sousCourant();
      const rang = p => RANGS.indexOf(rangDe(p, suiviDe(sPnj, p.id)));
      const ranger = liste => liste.map((p, i) => ({ p, i })).sort((a, b) => rang(a.p) - rang(b.p) || a.i - b.i).map(x => x.p);
      const gens = ranger(pnj.filter(p => p.lieu === vue && (!sous || p.sous_lieu === sous)));
      const aussi = ranger(pnj.filter(p => p.lieu !== vue && (p.aussi || []).some(a => (sous ? a === sous : dansVue(a)))));
      const ligne = (p, opts = {}) => lignePnj(p, { ...optionsLigne(), complement: !sous && p.sous_lieu && p.sous_lieu !== vue ? nomLieu(lieux, p.sous_lieu) : '', ...opts });
      const importants = gens.filter(p => rangDe(p, suiviDe(sPnj, p.id)) !== 'mineur');
      const mineurs = gens.filter(p => rangDe(p, suiviDe(sPnj, p.id)) === 'mineur');
      return { n: gens.length + aussi.length, contenu: () => [
        importants.length ? h('div', { class: 'cm-pnj-groupe' }, importants.map(p => ligne(p))) : null,
        mineurs.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `${mineurs.length} mineur${mineurs.length > 1 ? 's' : ''}`),
          h('div', { class: 'cm-pnj-groupe' }, mineurs.map(p => ligne(p)))) : null,
        aussi.length ? h('div', { class: 'cm-pnj-groupe' }, h('p', { class: 'etiquette cm-section__titre' }, icone('lu-arrow-right', 'bn-icone--s'), 'Aussi croisés ici'),
          aussi.map(p => ligne(p, { aussi: true, complement: '' }))) : null,
      ].filter(Boolean) };
    }

    // Un suivi de PNJ a changé (ici ou ailleurs) : badges et boutons des lignes, sans les refermer.
    function majLignes() {
      for (const el of corps.querySelectorAll('.cm-pnj')) {
        const p = pnjParId.get(el.dataset.id);
        if (p) majLignePnj(el, p, optionsLigne());
      }
    }
    function changementPnj() { sPnj.signaler(majLignes); majLignes(); }
    const ouvrirPnj = p => ouvrirFichePnj(p, { lieux, s: sPnj, factions, typesRang });

    // Marchands : une ligne chacun ; un clic ouvre sa fiche dans une fenêtre flottante.
    function blocMarchands() {
      const sous = sousCourant();
      const ms = (marchandsD?.marchands || []).filter(m => m.lieu === vue && (!sous || m.id === sous));
      const ouvrir = m => flottant('marchand:' + m.id, { surtitre: [m.type, nomLieu(lieux, m.lieu)].filter(Boolean).join(' · '), titre: m.nom, contenu: ficheMarchand(m) });
      return { n: ms.length, contenu: () => [h('div', { class: 'cm-marchands-liste' }, ms.map(m => lienFlottant(h('button', { type: 'button', class: 'cm-marchand-ligne cm-ouvre', onclick: () => ouvrir(m) },
        h('span', { class: 'cm-marchand__nom cm-ouvre__nom' }, m.nom),
        h('span', { class: 'cm-marchand__meta' }, badge(m.type, 'cierge'), [m.zone, m.emplacement].filter(Boolean).join(' · '))), 'marchand:' + m.id)))] };
    }
    function ficheMarchand(m) {
      return h('div', { class: 'cm-pile cm-fiche-marchand' },
        m.description ? h('p', { class: 'texte' }, m.description) : null,
        m.tenanciers?.length ? h('p', { class: 'cm-tenanciers' }, h('span', { class: 'etiquette' }, 'Tenu par'), m.tenanciers.map(id => pnjParId.has(id)
          ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPnj(pnjParId.get(id)) }, pnjParId.get(id).nom)
          : h('span', { class: 'cm-sourdine' }, id))) : null,
        m.a_jouer ? h('p', { class: 'aparte' }, m.a_jouer) : null,
        m.regle_de_prix ? section('Prix', 'piece', h('p', { class: 'ui' }, m.regle_de_prix)) : null,
        m.services?.length ? section('Services', 'lu-list', m.services.map(x => h('p', { class: 'ui' }, x))) : null,
        m.articles?.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `${m.articles.length} article${m.articles.length > 1 ? 's' : ''}`),
          h('div', { class: 'bn-table-wrap' }, h('table', { class: 'bn-table cm-articles' },
            h('tbody', {}, m.articles.map(a => h('tr', {},
              h('td', {}, h('span', { class: 'bn-table__nom' }, a.nom), a.note ? h('span', { class: 'bn-table__sous' }, a.note) : null),
              h('td', { class: 'num cm-prix' }, a.prix))))))) : null);
    }

    function blocMaisons() {
      const tables = (maisonsD?.tables || []).filter(t => t.lieu?.id === vue);
      return { n: tables.length, contenu: () => tables.map(t => h('div', { class: 'cm-pile' },
        h('div', { class: 'cm-contexte' },
          tables.length > 1 ? h('span', { class: 'etiquette' }, t.lieu.nom) : null,
          bouton(`Lancer le ${t.de.replace(/^1/, '')}`, { icone: 'd20', classe: 'bn-btn--s', onclick: () => { jetsMaisons[t.id] = tirerOccupants(t); rendre(); } })),
        jetsMaisons[t.id] ? vueOccupants(t, jetsMaisons[t.id], rendre, { R }) : h('p', { class: 'ui-s cm-sourdine' }, t.usage || 'Quand les héros frappent à une porte.'))) };
    }

    // Rencontres sur place (prévues : lieu, sans de ni vers ; et celles que le MJ y a rattachées), dans l'ordre de la
    // campagne : au lieu général avec celles de tous ses sous-lieux, dans un sous-lieu celles de ce sous-lieu. Celles d'un
    // trajet restent sur son jalon (Déroulé). Un clic ouvre le menu d'une rencontre ; « + Rencontre » en crée une ici.
    function blocRencontres() {
      const sous = sousCourant();
      const liste = R.duLieu(vue, sous);
      return { n: liste.length, contenu: () => [
        liste.length ? h('div', { class: 'cm-rmj-liste' }, liste.map(x => R.ligne(x, { compacte: !!sous }))) : h('p', { class: 'ui-s cm-sourdine' }, 'Aucune rencontre prévue ici.'),
        h('div', { class: 'bn-groupe' }, R.boutonNouvelle({ lieu: vue, sous_lieu: sous || null }, { libelle: 'Rencontre ici' })),
      ] };
    }

    // Objets à trouver ici (au lieu général, ceux de ses sous-lieux et de ses PNJ compris), le compte de ceux qui restent à
    // donner ; « + Objet ici » en crée un.
    function blocObjets() {
      const sous = sousCourant();
      const liste = O.duLieu(vue, sous);
      const reste = liste.filter(x => x.statut !== 'donne').length;
      return { n: liste.length, compte: liste.length ? (reste === liste.length ? reste : `${reste}/${liste.length}`) : null, contenu: () => [
        liste.length ? O.liste(liste) : h('p', { class: 'ui-s cm-sourdine' }, 'Aucun objet à trouver ici.'),
        h('div', { class: 'bn-groupe' }, O.boutonNouveau({ lieu: vue, sous_lieu: sous || null }, { libelle: 'Objet ici' })),
      ] };
    }

    // Étapes qui se jouent ici (et ce qu'un module de campagne y ajoute : le Tarokka), jalons qui se jouent ici (lieu ; dans un sous-lieu, ceux de ce
    // sous-lieu), et ce que les pistes commencées font reparaître ici (leurs manifestations à ce lieu).
    function blocTrame() {
      const sous = sousCourant();
      const sv = sDeroule?.valeur || {};
      const rangEtape = id => etapes.findIndex(e => e.id === id);
      const ici = etapes.filter(e => (e.lieux || []).includes(vue));
      const jalons = (deroule?.jalons || []).filter(j => j.lieu === vue && (!sous || j.sous_lieu === sous))
        .sort((a, b) => rangEtape(a.etape) - rangEtape(b.etape) || a.rang - b.rang);
      const rappels = (deroule?.pistes || []).filter(p => statutDe(sv, 'piste', p.id) === 'en-cours')
        .flatMap(p => (p.manifestations || []).filter(m => m.lieu === vue).map(m => ({ p, m })));
      const avecDeroule = derouleSurLeTableau();
      const btnVoir = (fn, nom) => bouton('', { icone: 'sablier', classe: 'bn-btn--s bn-btn--fantome', titre: avecDeroule ? `Voir « ${nom} » dans le déroulé` : 'Ajoutez le widget Déroulé au tableau', disabled: !avecDeroule, onclick: fn });
      // Statuts du Déroulé : étape en cours ou terminée ; jalon en cours ou terminé.
      const statutEtape = e => ({ 'en-cours': badge('En cours', 'sang'), termine: badge('Terminée', 'brume', 'lu-check') })[statutDe(sv, 'etape', e.id)] || null;
      const statutJalon = j => ({ 'en-cours': badge('En cours', 'soleil'), termine: badge('Terminé', 'brume', 'lu-check') })[statutDe(sv, 'jalon', j.id)] || null;
      return { n: ici.length + jalons.length + rappels.length, contenu: () => [
        ici.map(e => h('div', { class: 'cm-ici__trame' },
          h('div', { class: 'cm-ici__trame-ligne' },
            h('span', { class: 'cm-etape__ordre' }, e.ordre),
            h('span', { class: 'cm-ici__trame-nom' }, e.nom, h('span', { class: 'cm-sourdine' }, ` · niv. ${e.niveau_groupe}${e.niveau_atteint ? ` → ${e.niveau_atteint}` : ''}`)),
            statutEtape(e),
            btnVoir(() => voirEtape(e.id), e.nom)),
          contributions('etapeBloc', e))),
        jalons.length ? h('div', { class: 'cm-pile cm-ici__jalons' }, jalons.map(j => h('div', { class: 'cm-ici__trame-ligne' },
          h('span', { class: 'bn-jalon__icone', title: deroule.types_jalons?.[j.type] || j.type }, icone(ICONES_JALON[j.type] || 'lu-info', 'bn-icone--s')),
          h('span', { class: 'cm-ici__trame-nom' }, j.nom,
            h('span', { class: 'cm-sourdine' }, [!sous && j.sous_lieu ? ` · ${nomLieu(lieux, j.sous_lieu)}` : '', j.facultatif ? ' · facultatif' : ''].join('')),
            j.declencheur ? h('span', { class: 'bn-jalon__declencheur' }, icone('lu-clock', 'bn-icone--s'), j.declencheur) : null),
          statutJalon(j),
          btnVoir(() => voirJalon(j.id), j.nom)))) : null,
        rappels.length ? h('div', { class: 'cm-pile cm-ici__jalons' }, rappels.map(({ p, m }) => h('div', { class: 'cm-ici__trame-ligne cm-ici__rappel' },
          h('span', { class: 'bn-jalon__icone', title: 'Piste commencée : à faire reparaître ici' }, icone(ICONE_PISTE, 'bn-icone--s')),
          h('span', { class: 'cm-ici__trame-nom' }, p.nom, h('span', { class: 'bn-jalon__declencheur' }, m.texte)),
          btnVoir(() => voirPiste(p.id), p.nom)))) : null,
      ].flat().filter(Boolean) };
    }

    // Factions du lieu : un clic sur une pastille ouvre la fiche de la faction et ses membres.
    function blocFactions() {
      const fs = (factions?.liste || []).filter(f => !f.secret && (f.lieux || []).includes(vue));
      const ouvrir = f => ouvrirFaction(f, { pnj, s: sPnj, lieux, factions, typesRang });
      return { n: fs.length, contenu: () => [h('div', { class: 'cm-puces-liens', title: 'Un clic ouvre la fiche de la faction et ses membres' }, fs.map(f => badgeFaction(f, { surClic: ouvrir })))] };
    }

    // Trajets directs au départ d'ici (ou du lieu qui le contient), temps de marche au rythme normal.
    function blocTrajets() {
      const depuis = lieux.get(vue)?.situe_dans && !(voyage?.trajets || []).some(t => t.de === vue || t.vers === vue) ? lieux.get(vue).situe_dans : vue;
      const ts = (voyage?.trajets || []).filter(t => t.de === depuis || t.vers === depuis)
        .map(t => ({ t, vers: t.de === depuis ? t.vers : t.de })).sort((a, b) => a.t.miles - b.t.miles);
      return { n: ts.length, contenu: () => [
        depuis !== vue ? h('p', { class: 'ui-s cm-sourdine' }, `Depuis ${nomLieu(lieux, depuis)}.`) : null,
        h('ul', { class: 'cm-ici__trajets', title: 'À pied, au rythme normal. Le widget Trajets compose l\'itinéraire et fait arriver les héros.' }, ts.map(({ t, vers }) => h('li', {},
          lienLieu(vers),
          h('span', { class: 'cm-ici__trajet-chiffres' }, distanceVoyage(t.miles, { note: t.decision_mj?.texte }), ` · ${enHeures(minutesTrajet(t, mph))}`),
          t.terrain_difficile ? badge('Difficile ×2', 'cierge') : null))),
      ].filter(Boolean) };
    }

    function blocImages() {
      const images = biblio ? biblio.index.images.filter(i => !i.joueurs && biblio.lieuxDe(i).includes(vue)) : [];
      return { n: images.length, contenu: () => [h('div', { class: 'cm-vignettes' }, images.map(biblio.vignette))] };
    }

    // Historique des déplacements (tous lieux) : une seule liste, arrivées notées et trajets faits mêlés dans l'ordre où ils
    // se sont passés (le plus récent en haut ; un trajet juste avant la première arrivée qu'il a notée). On y corrige le lieu
    // actuel sans noter d'arrivée, et chaque ligne se retire d'un clic (l'heure ne change pas) ; « Annuler » la remet.
    function blocHistorique() {
      const vs = v().visites || [];
      const ts = v().trajets || [];
      return { n: vs.length + ts.length, contenu: () => {
        const quandVisite = x => (x.jour ? libelleMoment(x) : x.quand ? `noté le ${heure(x.quand)}` : 'avant le suivi');
        const selLieu = h('select', { class: 'bn-select', 'aria-label': 'Lieu actuel', onchange: e => corrigerLieu(sIci, e.target.value) },
          h('option', { value: '' }, '— Inconnu —'), principaux.map(l => h('option', { value: l.id }, l.nom)));
        selLieu.value = v().lieu || '';
        const elements = vs.map((x, i) => ({ visite: x, i }));
        for (const t of ts) {
          const k = elements.findIndex(e => e.visite?.trajet === t.id);
          const apres = elements.findIndex(e => e.visite?.quand && t.quand && e.visite.quand > t.quand);
          const pos = k >= 0 ? k : apres >= 0 ? apres : elements.length;
          elements.splice(pos, 0, { trajet: t });
        }
        // Retirer : un instantané permet d'annuler (lieu actuel compris : retirer la dernière arrivée peut le changer).
        const retirer = (titre, texte, quoi) => bouton('', { icone: 'lu-x', titre, classe: 'bn-btn--s bn-btn--fantome cm-horloge__retirer', onclick: () => {
          retrait = { texte, avant: structuredClone({ visites: v().visites, trajets: v().trajets || [], lieu: v().lieu, sous_lieu: v().sous_lieu }) };
          nettoyerHistorique(sIci, quoi);
        } });
        const annuler = () => {
          Object.assign(v(), retrait.avant);
          retrait = null;
          sIci.enregistrer(0);
          sIci.signaler();
        };
        const ligne = e => {
          if (e.visite) {
            const x = e.visite;
            return h('li', { class: 'cm-historique__ligne' },
              icone('epingle', 'bn-icone--s'),
              h('span', {}, h('b', {}, nomLieu(lieux, x.lieu)), h('span', { class: 'cm-sourdine' }, ` · ${quandVisite(x)}`)),
              retirer(`Retirer cette arrivée à ${nomLieu(lieux, x.lieu)}`, `arrivée à ${nomLieu(lieux, x.lieu)}`, { visites: [e.i] }));
          }
          const t = e.trajet;
          const noms = t.itineraire.map(id => nomLieu(lieux, id)).join(' → ');
          return h('li', { class: 'cm-historique__ligne' },
            icone('lu-route', 'bn-icone--s'),
            h('span', {}, h('b', {}, noms),
              h('span', { class: 'cm-sourdine' }, ` · ${[t.debut && t.fin ? `${libelleMoment(t.debut)} → ${libelleMoment(t.fin)}` : null,
                t.marche ? `${libelleDuree(t.marche)} de marche` : null, t.fini ? null : 'arrêté en route'].filter(Boolean).join(' · ')}`)),
            retirer('Retirer ce trajet (ses arrivées restent, chacune sur sa ligne ; la marche depuis le dernier repos long ne le compte plus)', `trajet ${noms}`, { trajets: [t.id], avecArrivees: false }));
        };
        return [
          h('div', { class: 'cm-contexte' }, h('span', { class: 'etiquette' }, 'Lieu actuel'), selLieu),
          retrait ? h('p', { class: 'ui-s cm-contexte' }, h('span', { class: 'cm-sourdine' }, `Retiré : ${retrait.texte}.`),
            bouton('Annuler', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: annuler })) : null,
          elements.length ? h('ol', { class: 'cm-historique' }, [...elements].reverse().map(ligne))
            : h('p', { class: 'ui-s cm-sourdine' }, 'Aucune arrivée notée.'),
          h('p', { class: 'ui-s cm-sourdine' }, 'Corriger le lieu actuel ne note pas d\'arrivée. Retirer une ligne ne change pas l\'heure ; si la dernière arrivée part, le lieu actuel redevient celui de l\'arrivée d\'avant (sauf s\'il a été corrigé depuis).'),
        ].filter(Boolean);
      } };
    }

    function notesDuLieu() {
      const lieu = vue;
      return h('textarea', {
        class: 'bn-textarea cm-notes', rows: 3, 'aria-label': `Notes sur ${nomLieu(lieux, lieu)}`, placeholder: 'Ce qui s\'est passé ici, ce qui a changé, ce qu\'il reste à y faire…',
        oninput: e => { if (e.target.value.trim()) v().notes[lieu] = e.target.value; else delete v().notes[lieu]; sIci.enregistrer(800); },
      }, v().notes?.[lieu] || '');
    }

    // ───── Onglets ─────
    // PNJ (d'office), Rencontres, Objets, Trame, Lieu. Dans chacun, le contenu principal n'a pas d'intitulé (l'onglet le dit),
    // le reste en sections. Un onglet sans rien à montrer n'apparaît pas (Rencontres et Objets restent : on y crée).
    // L'onglet choisi est gardé (etat/ici.json, « onglet »).
    const pile = (...x) => h('div', { class: 'cm-pile cm-ici__onglet' }, x.flat().filter(Boolean));
    function listeOnglets() {
      const p = blocPnj(), f = blocFactions(), m = blocMaisons();
      const r = blocRencontres(), o = blocObjets(), mar = blocMarchands();
      const t = blocTrame(), tr = blocTrajets(), img = blocImages(), hist = blocHistorique();
      return [
        p.n || f.n || m.n ? { id: 'pnj', libelle: 'PNJ', icone: 'crocs', compte: p.n || null, rendu: () => pile(
          p.n ? p.contenu() : null,
          f.n ? section('Factions', 'lu-users', f.contenu()) : null,
          m.n ? section('Qui ouvre la porte ?', 'porte', m.contenu()) : null) } : null,
        { id: 'rencontres', libelle: 'Rencontres', court: 'Renc.', icone: 'lu-swords', compte: r.n || null, rendu: () => pile(r.contenu()) },
        { id: 'objets', libelle: 'Objets', icone: 'amulette', compte: o.compte, rendu: () => pile(
          o.contenu(),
          mar.n ? section('Marchands', 'piece', mar.contenu()) : null) },
        t.n ? { id: 'trame', libelle: 'Trame', icone: 'sablier', compte: t.n, rendu: () => pile(t.contenu()) } : null,
        { id: 'lieu', libelle: 'Lieu', icone: 'lu-map', rendu: () => pile(
          section('Notes du MJ', 'livre', notesDuLieu()),
          tr.n ? section('Partir d\'ici', 'lu-route', tr.contenu()) : null,
          img.n ? section('Images', 'carte', img.contenu()) : null,
          (det => (det.addEventListener('toggle', () => { historiqueOuvert = det.open; }), det))(h('details', { class: 'cm-repli', open: historiqueOuvert },
            h('summary', { class: 'etiquette' }, icone('lu-footprints', 'bn-icone--s'), `Historique des déplacements${hist.n ? ` (${hist.n})` : ''}`),
            h('div', { class: 'cm-pile' }, hist.contenu())))) },
      ].filter(Boolean);
    }

    // Seul un clic change l'onglet gardé : un lieu sans l'onglet gardé (pas de PNJ, pas de trame) s'ouvre sur le premier,
    // sans l'oublier pour les lieux suivants.
    function vueOnglets() {
      let construction = true;
      const o = onglets('Ici', listeOnglets(), v().onglet || 'pnj', id => {
        if (construction || id === (v().onglet || 'pnj')) return;
        v().onglet = id;
        delete v().ouverts;   // ancien champ (blocs repliables d'avant les onglets)
        sIci.enregistrer();
        corps.scrollTop = 0;
      });
      construction = false;
      return [o.barre, o.zone];
    }

    function rendre() {
      const haut = corps.scrollTop;
      // Les héros ont bougé (Trajets, Déroulé, bloc maj-etat, ce widget) : si l'on regardait leur lieu, on les suit, jusque
      // dans leur sous-lieu.
      if (v().lieu !== lieuSuivi || sousHeros() !== sousSuivi) {
        if (vue === lieuSuivi && lieux.has(v().lieu)) { vue = v().lieu; sousVue = sousHeros(); }
        lieuSuivi = v().lieu;
        sousSuivi = sousHeros();
      }
      if (!lieux.has(vue)) vue = principaux[0].id;
      if (sousVue && lieux.get(sousVue)?.parent !== vue) sousVue = null;
      majBoutonChoix();
      corps.replaceChildren(...[
        choixVisible ? vueChoix() : null,
        vueTete(),
        ...vueOnglets(),
      ].filter(Boolean));
      corps.scrollTop = haut;
    }

    sIci.abonner(rendre);
    R.s.abonner(rendre);   // rencontres créées, préparées ou terminées ailleurs
    O.s.abonner(rendre);   // objets créés ou donnés ailleurs
    sPnj.abonner(majLignes);
    sDeroule?.abonner(rendre);
    biblio?.s.abonner(rendre);
    rendre();
    return {};
  },
};
