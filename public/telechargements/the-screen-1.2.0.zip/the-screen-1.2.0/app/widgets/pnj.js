// Widget PNJ : répertoire par lieu et sous-lieu, recherche par nom et alias, filtres (lieu, état, rang, faction, savoirs, vus),
// tri par rang, fiche (fenêtre flottante) et suivi de campagne. Les factions secrètes sont masquées tant que le
// MJ ne demande pas à les voir. « Suivre la zone » (coché d'office) : la liste s'ouvre sur le lieu où sont les héros (Ici,
// sinon l'étape du Déroulé), encadré. L'en-tête compte les PNJ déjà rencontrés, en tout et dans ce lieu.
// Données : data/pnj.json (formats/pnj.md), data/factions.json (formats/factions.md). État : etat/pnj.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, normaliser } from '../ui.js';
import { chargerLieux, nomLieu, etatIci } from '../lieux.js';
import { etatPnj, suiviDe, rangDe, etatEffectif, ETATS_EN_JEU, RANGS, chargerFactions, badgeFaction, lignePnj, majLignePnj, intriguesConnues } from '../fiche-pnj.js';

// Filtre « Vus » à trois états, un clic passe au suivant : tous, seulement les déjà rencontrés, seulement les autres.
const VUS = {
  '': { suivant: 'vus', mot: 'Vus', titre: 'Vus ou non : tous les PNJ. Cliquer : seulement ceux déjà rencontrés' },
  vus: { suivant: 'non-vus', mot: 'Vus', titre: 'Seulement les PNJ déjà rencontrés. Cliquer : seulement ceux pas encore rencontrés' },
  'non-vus': { suivant: '', mot: 'Non vus', titre: 'Seulement les PNJ pas encore rencontrés. Cliquer : tous' },
};

export default {
  type: 'pnj',
  requiert: 'pnj',
  titre: 'PNJ',
  surtitre: 'Qui est qui',
  icone: 'crocs',
  description: 'Les PNJ par lieu et sous-lieu : recherche par nom ou alias, rang (VIP, majeur, mineur), factions, ceux qui en savent long, déjà rencontrés, fiche complète et notes de campagne.',
  taille: { w: 5, h: 16 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, actions, resume, donnees, etat }) {
    const lecture = await donnees('pnj');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'PNJ indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const lieux = await chargerLieux(donnees);
    const factions = await chargerFactions(donnees);
    const s = await etatPnj(etat);
    const sIci = await etatIci(etat, donnees);
    const sDeroule = await etat('deroule', { schema: 1, etape: null });
    const etapes = (await donnees('deroule-campagne')).donnees?.etapes || [];
    const typesRang = d.types_rang || {};
    const filtre = { texte: '', lieu: '', etat: '', rang: '', faction: '', savoirs: false, vus: '', secrets: false, triRang: false, suivre: true };
    // Zone en cours : le lieu où sont les héros (Ici), sinon le premier lieu de l'étape en cours du Déroulé qui a des PNJ.
    const lieuxPnj = new Set(d.lieux.map(l => l.id));
    function zone() {
      if (lieuxPnj.has(sIci.valeur.lieu)) return sIci.valeur.lieu;
      return (etapes.find(e => e.id === sDeroule.valeur.etape)?.lieux || []).find(id => lieuxPnj.has(id)) || null;
    }
    // Sous-lieu -> lieu, pour savoir où compter un « aussi ».
    const parentDe = new Map(d.lieux.flatMap(l => (l.sous_lieux || []).map(sl => [sl.id, l.id])));
    const dansLieu = (id, lieu) => id === lieu || parentDe.get(id) === lieu;
    const avecRang = d.pnj.some(p => p.rang);
    // PNJ qui en savent long sur une intrigue secrète (`savoirs`) : le filtre en porte le nom s'il n'y
    // en a qu'une.
    const intriguesSues = [...new Set(d.pnj.flatMap(p => Object.keys(p.savoirs || {})))];
    const uneIntrigue = intriguesSues.length === 1 ? intriguesConnues().find(x => x.id === intriguesSues[0]) : null;

    const recherche = h('input', {
      class: 'bn-input', type: 'search', placeholder: 'Nom, alias, rôle…', 'aria-label': 'Chercher un PNJ',
      oninput: e => { filtre.texte = e.target.value; rendreListe(); },
    });
    // Filtres sur une ligne : une icône dit ce que filtre chaque liste, « Tous » quand rien n'est choisi.
    const selLieu = h('select', { class: 'bn-select', 'aria-label': 'Lieu', title: 'Lieu', onchange: e => { filtre.lieu = e.target.value; rendreListe(); allerALaZone(); } },
      h('option', { value: '' }, 'Tous'), d.lieux.map(l => h('option', { value: l.id }, nomLieu(lieux, l.id) || l.nom)));
    const PLURIELS = { vivant: 'Vivants', mort: 'Morts', 'mort-vivant': 'Morts-vivants', disparu: 'Disparus', absent: 'Absents' };
    const selEtat = h('select', { class: 'bn-select', 'aria-label': 'État', title: 'État', onchange: e => { filtre.etat = e.target.value; rendreListe(); } },
      h('option', { value: '' }, 'Tous'), ETATS_EN_JEU.filter(([v]) => v).map(([v]) => h('option', { value: v }, PLURIELS[v])));
    const selRang = h('select', { class: 'bn-select', 'aria-label': 'Rang', title: 'Rang', onchange: e => { filtre.rang = e.target.value; rendreListe(); } },
      h('option', { value: '' }, 'Tous'), h('option', { value: 'vip' }, 'VIP'), h('option', { value: 'importants' }, 'VIP et majeurs'),
      h('option', { value: 'majeur' }, 'Majeurs'), h('option', { value: 'mineur' }, 'Mineurs'));
    const filtreIcone = (ic, select) => h('span', { class: 'cm-filtre' }, icone(ic, 'bn-icone--s'), select);
    // Factions groupées par type ; les secrètes n'apparaissent qu'avec « Afficher les secrets ».
    const selFaction = h('select', { class: 'bn-select', 'aria-label': 'Faction', title: 'Faction', onchange: e => { filtre.faction = e.target.value; rendreListe(); } });
    function remplirFactions() {
      if (!factions) return;
      const types = Object.keys(factions.types);
      selFaction.replaceChildren(h('option', { value: '' }, 'Toutes'), ...
        types.map(t => {
          const fs = factions.liste.filter(f => f.type === t && (filtre.secrets || !f.secret));
          return fs.length ? h('optgroup', { label: factions.types[t] }, fs.map(f => h('option', { value: f.id }, f.nom + (f.secret ? ' (secret)' : '')))) : null;
        }).filter(Boolean));
      if (filtre.faction && ![...selFaction.options].some(o => o.value === filtre.faction)) filtre.faction = '';
      selFaction.value = filtre.faction;
    }
    remplirFactions();
    // Cases à cocher sur une ligne : icône et mot court, le détail au survol (le mot s'efface dans un widget étroit, CSS).
    const caseFiltre = (cle, ic, mot, titre, apres) => h('label', { class: 'cm-case', title: titre },
      h('input', { type: 'checkbox', class: 'bn-case', checked: filtre[cle], onchange: e => { filtre[cle] = e.target.checked; apres?.(); rendreListe(); } }),
      ic ? icone(ic, 'bn-icone--s') : null, h('span', { class: 'cm-pnj-cases__mot' }, mot));
    // « Vus » : case à trois états (coche : déjà rencontrés ; croix : pas encore).
    const btnVus = h('button', { type: 'button', class: 'cm-case cm-case--triple', onclick: () => { filtre.vus = VUS[filtre.vus].suivant; majVus(); rendreListe(); } });
    function majVus() {
      const e = VUS[filtre.vus];
      btnVus.dataset.etat = filtre.vus || 'tous';
      btnVus.title = e.titre;
      btnVus.setAttribute('aria-label', e.titre);
      btnVus.replaceChildren(h('span', { class: 'cm-case__boite' }, filtre.vus === 'vus' ? icone('lu-check') : filtre.vus === 'non-vus' ? icone('lu-x') : null),
        icone(filtre.vus === 'non-vus' ? 'lu-eye-off' : 'oeil', 'bn-icone--s'), h('span', { class: 'cm-pnj-cases__mot' }, e.mot));
    }
    majVus();
    // Tri par rang : à droite de la ligne des cases, une flèche de tri.
    const btnTri = h('button', { type: 'button', class: 'cm-tri', 'aria-pressed': 'false',
      title: 'Trier par rang : VIP, puis majeurs, puis mineurs (sinon : l\'ordre du lieu)',
      onclick: () => { filtre.triRang = !filtre.triRang; btnTri.setAttribute('aria-pressed', String(filtre.triRang)); rendreListe(); } },
    icone('lu-arrow-down-wide-narrow', 'bn-icone--s'), h('span', { class: 'cm-pnj-cases__mot' }, 'Rang'));

    // En-tête : les PNJ déjà rencontrés, en tout et là où sont les héros (la zone suivie).
    function majCompteur(n) {
      const vu = p => !!suiviDe(s, p.id).rencontre;
      const z = zone();
      const ici = z ? d.pnj.filter(p => dansLieu(p.lieu, z) || dansLieu(p.sous_lieu, z)) : [];
      resume.title = `${d.pnj.filter(vu).length} PNJ déjà rencontrés sur ${d.pnj.length}`
        + (z ? `\n${ici.filter(vu).length} sur ${ici.length} à ${nomLieu(lieux, z)}, où sont les héros` : '')
        + `\n${n} PNJ affiché${n > 1 ? 's' : ''} avec les filtres`;
      resume.replaceChildren(...[
        h('span', { class: 'surtitre' }, `${d.pnj.filter(vu).length} PNJ connus sur ${d.pnj.length}`),
        z ? h('span', { class: 'cm-pnj-compte' }, icone('epingle', 'bn-icone--s'), `${ici.filter(vu).length} sur ${ici.length} ici`) : null,
      ].filter(Boolean));
    }
    const liste = h('div', { class: 'cm-pile' });

    // Clic sur une faction (fiche ou ligne) : filtrer la liste sur elle.
    function surFaction(f) {
      filtre.faction = f.id;
      selFaction.value = f.id;
      rendreListe();
      majFiltres();   // filtres masqués : le bouton de l'en-tête passe en orange
      corps.scrollTop = 0;
    }

    function correspond(p) {
      const suivi = suiviDe(s, p.id);
      const rang = rangDe(p, suivi);
      if (filtre.rang === 'importants' ? rang === 'mineur' : filtre.rang && rang !== filtre.rang) return false;
      if (filtre.faction && !(p.factions || []).includes(filtre.faction)) return false;
      if (filtre.savoirs && !Object.keys(p.savoirs || {}).length) return false;
      if (filtre.vus && !!suivi.rencontre !== (filtre.vus === 'vus')) return false;
      if (filtre.etat && etatEffectif(p, suivi) !== filtre.etat) return false;
      if (filtre.texte) {
        const q = normaliser(filtre.texte);
        const champs = [p.nom, ...(p.alias || []), p.role, p.profil, suivi.note];
        if (!champs.some(c => normaliser(c).includes(q))) return false;
      }
      return true;
    }

    const optionsLigne = () => ({ lieux, s, surChange: changement, factions, secrets: filtre.secrets, surFaction, typesRang });
    const ligne = (p, aussi) => lignePnj(p, { ...optionsLigne(), aussi });

    // Une modification du suivi : mettre à jour les badges des lignes (et de la fiche ouverte) et le compte de l'en-tête.
    function changement() {
      s.signaler(rendreListe);
      // Un filtre dépend du suivi : la liste elle-même change (les fiches ouvertes restent ouvertes).
      if (filtre.rang || filtre.vus || filtre.etat || filtre.triRang) return rendreListe();
      for (const el of liste.querySelectorAll('.cm-pnj')) {
        const p = d.pnj.find(x => x.id === el.dataset.id);
        if (p) majLignePnj(el, p, optionsLigne());
      }
      majCompteur(liste.querySelectorAll('.cm-pnj').length);
    }

    // Ordre d'un lieu : celui de lieux[].pnj ; « Trier par rang » : VIP, majeurs, mineurs, sans changer l'ordre à rang égal.
    function ranger(gens, l) {
      const ordre = new Map((l.pnj || []).map((id, i) => [id, i]));
      const rangDeP = p => RANGS.indexOf(rangDe(p, suiviDe(s, p.id)));
      return [...gens].sort((a, b) => (filtre.triRang ? rangDeP(a) - rangDeP(b) : 0) || (ordre.get(a.id) ?? 1e9) - (ordre.get(b.id) ?? 1e9));
    }

    function rendreListe() {
      const blocs = [];
      let n = 0;
      for (const l of d.lieux) {
        if (filtre.lieu && filtre.lieu !== l.id) continue;
        const ici = ranger(d.pnj.filter(p => p.lieu === l.id && correspond(p)), l);
        const aussi = filtre.lieu ? ranger(d.pnj.filter(p => p.lieu !== l.id && (p.aussi || []).some(a => dansLieu(a, l.id)) && correspond(p)), l) : [];
        if (!ici.length && !aussi.length) continue;
        n += ici.length + aussi.length;
        const sousLieux = (l.sous_lieux || []).length > 1 ? l.sous_lieux : [{ id: null }];
        const estIci = l.id === zone();
        blocs.push(h('section', { class: 'cm-pnj-lieu' + (estIci ? ' est-ici' : ''), 'data-lieu': l.id },
          h('h3', { class: 'titre-m' }, nomLieu(lieux, l.id) || l.nom, l.zone ? h('span', { class: 'cm-zone' }, l.zone) : null,
            estIci ? badge(lieuxPnj.has(sIci.valeur.lieu) ? 'Les héros sont ici' : 'Étape en cours', 'sang', 'epingle') : null),
          sousLieux.map(sl => {
            const gens = sl.id ? ici.filter(p => p.sous_lieu === sl.id) : ici;
            if (!gens.length) return null;
            return h('div', { class: 'cm-pnj-groupe' },
              sl.id ? h('p', { class: 'etiquette cm-section__titre' }, icone('epingle', 'bn-icone--s'), sl.nom, sl.zone ? ` · ${sl.zone}` : '') : null,
              gens.map(p => ligne(p)));
          }),
          // PNJ rangés ailleurs dans le fichier mais dont le sous-lieu n'est pas listé ici.
          sousLieux[0].id ? (() => {
            const orphelins = ici.filter(p => !l.sous_lieux.some(sl => sl.id === p.sous_lieu));
            return orphelins.length ? h('div', { class: 'cm-pnj-groupe' }, h('p', { class: 'etiquette' }, 'Ailleurs'), orphelins.map(p => ligne(p))) : null;
          })() : null,
          aussi.length ? h('div', { class: 'cm-pnj-groupe' }, h('p', { class: 'etiquette cm-section__titre' }, icone('lu-arrow-right', 'bn-icone--s'), 'Aussi croisés ici'), aussi.map(p => ligne(p, true))) : null));
      }
      majCompteur(n);
      const f = filtre.faction && factions?.parId.get(filtre.faction);
      liste.replaceChildren(...[
        f ? h('div', { class: 'bn-carte cm-faction-choisie' },
          h('div', { class: 'bn-groupe' }, badgeFaction(f), h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome', onclick: () => { filtre.faction = ''; selFaction.value = ''; rendreListe(); majFiltres(); } }, icone('lu-x'), h('span', {}, 'Toutes les factions'))),
          h('p', { class: 'ui-s' }, f.description)) : null,
        ...(blocs.length ? blocs : [h('p', { class: 'ui cm-sourdine' }, 'Aucun PNJ ne correspond.')]),
      ].filter(Boolean));
    }

    // « Suivre la zone » : la liste s'ouvre sur le lieu où sont les héros, et y revient quand ils en changent
    // ou quand le widget réapparaît (déplié, changement de mode).
    function allerALaZone() {
      if (!filtre.suivre || !corps.clientHeight) return;
      const el = liste.querySelector('.cm-pnj-lieu.est-ici');
      const collee = corps.querySelector('.cm-pnj-filtres:not([hidden])');   // recherche et filtres collés en haut
      if (el) corps.scrollTop += el.getBoundingClientRect().top - corps.getBoundingClientRect().top - (collee?.offsetHeight || 0) - 8;
    }
    let visible = false;
    new ResizeObserver(() => {
      const v = corps.clientHeight > 0;
      if (v && !visible) allerALaZone();
      visible = v;
    }).observe(corps);
    let zoneAvant = zone();
    const surZone = () => { rendreListe(); if (zone() !== zoneAvant) { zoneAvant = zone(); allerALaZone(); } };
    sIci.abonner(surZone);
    sDeroule.abonner(surZone);

    s.abonner(rendreListe);
    // Recherche et filtres : collés en haut quand la liste défile ; le bouton de l'en-tête les masque (choix gardé sur ce poste).
    // Masqués, ils filtrent encore : le bouton le rappelle en orange.
    const filtres = h('div', { class: 'cm-pnj-filtres' },
      h('div', { class: 'cm-recherche' }, icone('lu-search', 'bn-icone--s'), recherche),
      h('div', { class: 'cm-pnj-selects' }, filtreIcone('epingle', selLieu), filtreIcone('crane', selEtat),
        avecRang ? filtreIcone('etoile', selRang) : null, factions ? filtreIcone('bouclier', selFaction) : null),
      h('div', { class: 'cm-pnj-cases' },
        caseFiltre('suivre', 'epingle', 'Zone', 'Suivre la zone : amener la liste sur le lieu où sont les héros (widget Ici), et l\'encadrer', allerALaZone),
        intriguesSues.length ? caseFiltre('savoirs', uneIntrigue?.icone || 'glyphe', uneIntrigue?.court || uneIntrigue?.nom || 'Savoirs',
          `Seulement ceux qui peuvent renseigner : ${uneIntrigue?.nom || 'les secrets de la campagne'}`) : null,
        btnVus,
        factions?.liste.some(x => x.secret) ? caseFiltre('secrets', 'lu-eye-off', 'Secrets', 'Afficher les factions secrètes : jamais côté joueurs', remplirFactions) : null,
        avecRang ? btnTri : null));
    const CLE_FILTRES = 'cm:pnj:filtres';
    let filtresVisibles = true;
    try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* pas de stockage : visibles */ }
    const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      filtresVisibles = !filtresVisibles;
      try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* le choix vaut pour la session */ }
      majFiltres();
    } });
    function majFiltres() {
      filtres.hidden = !filtresVisibles;
      const actifs = filtre.texte || filtre.lieu || filtre.etat || filtre.rang || filtre.faction || filtre.savoirs || filtre.vus;
      btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
      btnFiltres.classList.toggle('est-filtre', !filtresVisibles && !!actifs);
      const titre = (filtresVisibles ? 'Masquer la recherche et les filtres' : 'Afficher la recherche et les filtres') + (!filtresVisibles && actifs ? ' (des filtres sont actifs)' : '');
      btnFiltres.title = titre;
      btnFiltres.setAttribute('aria-label', titre);
    }
    actions.prepend(btnFiltres);
    majFiltres();
    corps.replaceChildren(
      filtres,
      liste,
      // Ce que l'agent IA de campagne a déjà couvert : une note sur l'export, repliée en bas.
      d.couverture ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'Chapitres couverts par le fichier'), h('p', { class: 'ui-s cm-sourdine' }, d.couverture)) : '');   // replaceChildren écrirait « null »
    rendreListe();
    allerALaZone();
    return {};
  },
};
