// Widget Qui sait quoi : pour chaque intrigue secrète de la campagne (où sont trois reliques, qui sert le traître…), la grille
// groupes × sujets (explication au clic) ; et le savoir commun, par thème, croyances fausses en évidence.
// Depuis un groupe : ses factions (data/factions.json) et leurs membres qui en savent quelque chose (`savoirs` de data/pnj.json).
// Données : data/connaissances.json, format 2 (formats/connaissances.md). Rien n'est enregistré (sauf le suivi des PNJ,
// depuis leur fiche).

import { h, icone, bouton, badge, alerte, onglets, section, provenance, blocOriginal, infobulle, flottant } from '../ui.js';
import { chargerLieux } from '../lieux.js';
import { etatPnj, suiviDe, rangDe, RANGS, repereRang, chargerFactions, badgeFaction, dialoguePnj } from '../fiche-pnj.js';
import { libelleSource } from '../campagne.js';

const VALEURS = {
  oui: { libelle: 'Oui', couleur: 'brume' },
  partiel: { libelle: 'En partie', couleur: 'cierge' },
  non: { libelle: 'Non', couleur: null },
};

export default {
  type: 'connaissances',
  requiert: 'connaissances',
  titre: 'Qui sait quoi',   // pas de surtitre : « Ce que le monde sait » répétait le titre (retiré à la demande du MJ, 2026-10-25)
  icone: 'oeil',
  description: 'Qui sait quoi sur les secrets de la campagne, et ce que tout le monde croit savoir, croyances fausses en évidence.',
  taille: { w: 6, h: 15 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, donnees, etat, dialogue }) {
    const lecture = await donnees('connaissances');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Connaissances indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const intrigues = d.intrigues || [];
    const sc = d.savoir_commun;
    const factions = await chargerFactions(donnees);
    const donneesPnj = (await donnees('pnj')).donnees;
    const pnj = donneesPnj?.pnj || [];
    const sPnj = await etatPnj(etat);
    const lieux = await chargerLieux(donnees);
    let ongletActif = intrigues[0] ? 'intrigue:' + intrigues[0].id : 'savoir';
    // Case choisie de chaque grille, dont le détail est ouvert : { <id d'intrigue>: { groupe, sujet } }.
    const choix = Object.fromEntries(intrigues.map(f => [f.id, { groupe: null, sujet: null }]));
    let theme = '';
    let seulementFausses = false;

    // ───── Intrigues ─────

    // Factions du groupe, et leurs membres qui en savent quelque chose : à qui les PJ peuvent demander.
    function vueInformateurs(f, g) {
      if (!g.factions?.length || !factions) return null;
      const fs = g.factions.map(id => factions.parId.get(id)).filter(x => x && !x.secret);
      const membres = pnj.filter(p => p.savoirs?.[f.id] && (p.factions || []).some(id => g.factions.includes(id)))
        .sort((a, b) => RANGS.indexOf(rangDe(a, suiviDe(sPnj, a.id))) - RANGS.indexOf(rangDe(b, suiviDe(sPnj, b.id))));
      return h('div', { class: 'cm-pile cm-informateurs' },
        fs.length ? h('div', { class: 'bn-groupe cm-badges' }, h('span', { class: 'ui-s' }, h('b', {}, 'Factions : ')), fs.map(x => badgeFaction(x))) : null,
        section('À qui demander', f.icone || 'glyphe', membres.length
          ? membres.map(p => h('details', { class: 'cm-informateur' },
            h('summary', {}, repereRang(rangDe(p, suiviDe(sPnj, p.id))), h('b', {}, p.nom), h('span', { class: 'ui-s cm-sourdine' }, ` · ${p.role}`)),
            h('p', { class: 'ui' }, p.savoirs[f.id]),
            h('div', { class: 'bn-groupe' }, bouton('Fiche du PNJ', { classe: 'bn-btn--s bn-btn--fantome', icone: 'crocs', onclick: () => dialoguePnj(dialogue, p, { lieux, s: sPnj, factions, typesRang: donneesPnj?.types_rang }) }))))
          : h('p', { class: 'ui-s cm-sourdine' }, 'Aucun membre de ces factions n\'en sait quelque chose.')));
    }

    // Le détail d'un groupe (ou d'une case : un sujet) : dans une fenêtre flottante, qui porte le nom du groupe.
    function vueDetail(f) {
      const c = choix[f.id];
      const g = f.groupes.find(x => x.id === c.groupe);
      if (!g) return null;
      const sujet = f.sujets.find(x => x.id === c.sujet);
      return h('div', { class: 'cm-pile cm-savoir-detail' },
        sujet ? h('p', { class: 'ui' }, badge(VALEURS[g.sait[sujet.id]]?.libelle || g.sait[sujet.id], VALEURS[g.sait[sujet.id]]?.couleur), ' ', h('b', {}, sujet.nom)) : null,
        g.exemples?.length ? h('p', { class: 'ui-s cm-sourdine' }, 'Par exemple : ' + g.exemples.join(', ')) : null,
        sujet?.description ? h('p', { class: 'ui-s' }, sujet.description) : null,
        h('p', { class: 'texte' }, g.explication),
        sujet ? null : vueInformateurs(f, g),
        // Quand le MJ a tranché une contradiction de la source : ce qu'elle disait (`valeur_source`).
        Object.entries(g.ajustements || {}).filter(([id]) => !sujet || id === sujet.id).map(([id, a]) => h('div', { class: 'cm-decision' },
          badge('Tranché par le MJ', 'sang'),
          h('p', { class: 'ui' }, h('b', {}, `${f.sujets.find(x => x.id === id)?.nom || id} : `), a.decision),
          a.valeur_source ? h('p', { class: 'ui-s cm-sourdine' }, `${a.source_initiale ? libelleSource(a.source_initiale) : 'La source'} disait : ${VALEURS[a.valeur_source]?.libelle.toLowerCase() || a.valeur_source}.`) : null)),
        provenance(g));
    }

    // Grille compacte (refonte demandée par le MJ, 2026-10-25 : illisible même en 1600 px). En tête de colonne, le nom court du
    // sujet (`court`), ou, widget étroit (requête de conteneur, CSS), son icône (`icone` : une icône de la charte, ou `lu-…`) ;
    // à défaut d'icône, son initiale ; le nom complet en infobulle. Les groupes par leur nom court. Une case : une pastille dont
    // la forme dit la réponse (pleine : oui, à moitié : en partie, petit rond creux : non), lisible sans les couleurs. Le
    // détail s'ouvre dans une fenêtre flottante.
    const iconeConnue = nom => !!nom && !!document.getElementById(nom.startsWith('lu-') ? nom : 'bn-' + nom);
    // Le libellé court d'une réponse ; aleurs des données (« Le sait. ») en dit le sens, au survol de la légende.
    const libelleValeur = val => VALEURS[val]?.libelle || val;
    // Sans icône : les initiales des deux premiers mots qui comptent (« Emplacement des sanctuaires » : ES), pour que deux
    // sujets qui commencent pareil se distinguent.
    const VIDES = new Set(['de', 'des', 'du', 'la', 'le', 'les', 'l', 'd', 'et', 'avec', 'a', 'au', 'aux', 'en']);
    const initiales = texte => (texte.split(/[\s'’-]+/).filter(m => m && !VIDES.has(m.toLowerCase())).slice(0, 2).map(m => m.charAt(0)).join('') || texte.charAt(0)).toUpperCase();
    function teteSujet(s) {
      const court = s.court || s.nom;
      return infobulle(h('span', { class: 'cm-savoir__sujet' },
        h('span', { class: 'cm-savoir__sujet-texte' }, court),
        h('span', { class: 'cm-savoir__sujet-icone', 'aria-hidden': 'true' },
          iconeConnue(s.icone) ? icone(s.icone) : h('span', { class: 'cm-savoir__initiale' }, initiales(court)))),
      s.description || s.nom, { titre: s.nom });
    }
    function ouvrirDetail(f) {
      const c = choix[f.id];
      const g = f.groupes.find(x => x.id === c.groupe);
      if (!g) return;
      const sujet = f.sujets.find(x => x.id === c.sujet);
      flottant('savoir:' + f.id, { surtitre: [f.nom, sujet?.nom].filter(Boolean).join(' · '), titre: g.nom, largeur: 520, contenu: vueDetail(f),
        surFermeture: () => { choix[f.id] = { groupe: null, sujet: null }; rendre(); } });
    }

    function vueIntrigue(f) {
      const c = choix[f.id];
      const choisir = (groupe, sujet) => { choix[f.id] = { groupe, sujet }; rendre(); ouvrirDetail(f); };
      const grille = h('table', { class: 'cm-savoir' },
        h('thead', {}, h('tr', {}, h('th', { scope: 'col', class: 'cm-savoir__tete-groupe' }, 'Groupe'), f.sujets.map(s => h('th', { scope: 'col' }, teteSujet(s))))),
        h('tbody', {}, f.groupes.map(g => h('tr', { class: c.groupe === g.id ? 'est-choisi' : null },
          h('th', { scope: 'row' },
            infobulle(h('button', { type: 'button', class: 'cm-savoir__groupe', 'aria-pressed': String(c.groupe === g.id && !c.sujet), onclick: () => choisir(g.id, null) },
              g.court || g.nom), [g.nom, g.exemples?.length ? `Par exemple : ${g.exemples.join(', ')}.` : ''].filter(Boolean).join(' · '))),
          f.sujets.map(s => {
            const val = g.sait[s.id];
            const ajuste = !!g.ajustements?.[s.id];
            return h('td', {}, h('button', {
              type: 'button', class: `cm-savoir__case cm-savoir__case--${val}`, 'aria-pressed': String(c.groupe === g.id && c.sujet === s.id),
              'aria-label': `${g.nom}, ${s.nom} : ${libelleValeur(val)}${ajuste ? ' (tranché par le MJ)' : ''}`,
              onclick: () => choisir(g.id, s.id),
            }, h('span', { class: 'cm-savoir__pastille' }), ajuste ? h('span', { class: 'cm-savoir__mj' }, 'MJ') : null));
          })))));
      const pastille = val => h('span', { class: `cm-savoir__case--${val} cm-savoir__legende-pastille` }, h('span', { class: 'cm-savoir__pastille' }));
      const apropos = [
        f.resume ? h('p', { class: 'ui-s' }, f.resume) : null,
        f.chaine_d_informateurs ? section('Chaîne d\'informateurs', 'lu-arrow-right',
          f.chaine_d_informateurs.texte ? h('p', { class: 'ui-s cm-sourdine' }, f.chaine_d_informateurs.texte) : null,
          h('ol', { class: 'ui cm-liste' }, f.chaine_d_informateurs.etapes.map(e => h('li', {}, e)))) : null,
        f.regle ? alerte('cierge', 'lu-info', 'Règle', f.regle) : null,
        provenance(f)].filter(Boolean);
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'cm-savoir-zone' }, grille),
        h('p', { class: 'ui-s cm-sourdine cm-savoir__legende' },
          ['oui', 'partiel', 'non'].map(val => {
            const x = h('span', {}, pastille(val), ` ${libelleValeur(val).toLowerCase()}`);
            return f.valeurs?.[val] ? infobulle(x, f.valeurs[val]) : x;
          }),
          f.groupes.some(g => Object.keys(g.ajustements || {}).length) ? h('span', {}, h('span', { class: 'cm-savoir__mj cm-savoir__mj--legende' }, 'MJ'), ' tranché par le MJ') : null,
          h('span', {}, 'Un clic : le détail.')),
        apropos.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'À propos de cette grille'), h('div', { class: 'cm-pile' }, apropos)) : null);
    }

    // ───── Savoir commun ─────

    // Liste compacte (refonte du 2026-10-25 : illisible, une grande carte par phrase et une barre de thèmes qui débordait).
    // Le thème dans une liste, « Fausses » qui bascule ; les phrases groupées par thème, une ligne chacune (sa source au
    // survol) ; une croyance fausse marquée d'un crâne rouge, la vérité pour le MJ dessous ; la version d'origine repliée.
    function vueSavoir() {
      const elements = sc.elements.filter(e => (!theme || e.theme === theme) && (!seulementFausses || e.croyance_fausse));
      const nbFausses = sc.elements.filter(e => e.croyance_fausse && (!theme || e.theme === theme)).length;
      const choixTheme = h('select', { class: 'bn-select', 'aria-label': 'Thème', onchange: e => { theme = e.target.value; rendre(); } },
        h('option', { value: '' }, `Tous les thèmes (${sc.elements.length})`),
        sc.themes.map(t => h('option', { value: t.id }, `${t.nom} (${sc.elements.filter(e => e.theme === t.id).length})`)));
      choixTheme.value = theme;
      const fausses = infobulle(bouton(`Fausses (${nbFausses})`, { icone: 'crane', classe: 'bn-btn--s' + (seulementFausses ? '' : ' bn-btn--fantome'),
        onclick: () => { seulementFausses = !seulementFausses; rendre(); } }), 'Seulement ce que les gens croient à tort.', { ton: 'sang' });
      fausses.setAttribute('aria-pressed', String(seulementFausses));
      const ligne = e => h('li', { class: 'cm-croyance' + (e.croyance_fausse ? ' cm-croyance--fausse' : '') },
        e.croyance_fausse ? infobulle(icone('crane', 'bn-icone--s cm-croyance__marque'), 'Croyance fausse : les gens le croient à tort.', { ton: 'sang' }) : h('span', { class: 'cm-croyance__puce', 'aria-hidden': 'true' }),
        h('div', { class: 'cm-croyance__corps' },
          (x => (e.source ? infobulle(x, [e.source, e.pages_livre ? `p. ${e.pages_livre}` : null].filter(Boolean).join(', ')) : x))(h('p', { class: 'ui' }, e.texte)),
          e.note ? h('p', { class: 'ui-s cm-croyance__note' }, h('b', {}, 'En vérité : '), e.note) : null,
          blocOriginal(e.original)));
      const groupes = sc.themes.map(t => [t, elements.filter(e => e.theme === t.id)]).filter(([, l]) => l.length);
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'cm-savoir-filtres' }, choixTheme, fausses),
        elements.length ? groupes.map(([t, l]) => h('section', { class: 'cm-savoir-theme' },
          theme ? null : h('p', { class: 'etiquette cm-section__titre' }, t.nom, h('span', { class: 'cm-sourdine' }, ` · ${l.length}`)),
          h('ul', { class: 'cm-savoir-liste' }, l.map(ligne)))) : h('p', { class: 'ui cm-sourdine' }, 'Rien dans ce thème.'),
        sc.resume || sc.source ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'À propos du savoir commun'),
          h('div', { class: 'cm-pile' }, sc.resume ? h('p', { class: 'ui-s' }, sc.resume) : null, provenance(sc))) : null);
    }

    function rendre() {
      const haut = corps.scrollTop;
      const liste = [
        ...intrigues.map(f => ({ id: 'intrigue:' + f.id, libelle: f.nom, icone: f.icone || 'glyphe', rendu: () => vueIntrigue(f) })),
        sc ? { id: 'savoir', libelle: 'Savoir commun', icone: 'livre', rendu: vueSavoir } : null,
      ].filter(Boolean);
      const o = onglets('Qui sait quoi', liste, ongletActif, id => { if (id !== ongletActif) { ongletActif = id; corps.scrollTop = 0; } });
      corps.replaceChildren(o.barre, o.zone);
      corps.scrollTop = haut;
    }
    rendre();
    return {};
  },
};
