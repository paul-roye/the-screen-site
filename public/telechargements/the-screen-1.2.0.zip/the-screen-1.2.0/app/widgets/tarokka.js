// Widget Tarokka : la lecture de madame Éva et les tirages personnels.
// Tirage : les cinq cartes seules, face cachée tant que le tirage n'est pas validé ; un clic sur une carte cachée la retourne,
// un clic sur une carte retournée ouvre son détail dans une fenêtre flottante (prophétie à lire, pour le MJ, case « Trouvé »,
// notes). L'icône « Cacher » les recache ; tirage validé, elles restent face visible.
// Joueurs : un bouton par personnage ; à droite, le tourment et la voie expliqués, ou les deux cartes du personnage choisi.
// Édition : les cartes réellement posées (tirage principal et tirages personnels), puis la validation du tirage.
// Déroulement : calculé d'après le tirage (cartes prévues ou notées) : ordre des paquets, schéma de la croix, étapes.
// En-tête : la table de madame Éva (plein écran : la croix, les joueurs, la légende) ; widget réduit, les cinq cartes en
// miniature, face cachée jusqu'à la validation, auréolées d'or une fois l'objet trouvé ou l'allié recruté.
// Tirage truqué (place.resultat_fixe, anciennes données) : le résultat est lu quelle que soit la carte piochée.
// Données : data/tarokka.json (formats/tarokka.md). État : etat/tarokka.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, onglets, blocEcarts, flottant, flottantOuvert, lienFlottant, deNom } from '../ui.js';
import { chargerWiki, portraitDuPersonnage } from '../wiki.js';

const COULEURS = {
  epees: { nom: 'Épées', icone: 'epee' },
  etoiles: { nom: 'Étoiles', icone: 'etoile' },
  pieces: { nom: 'Pièces', icone: 'piece' },
  glyphes: { nom: 'Glyphes', icone: 'glyphe' },
  haut: { nom: 'Haut jeu', icone: 'tarokka' },
};
// Emblème d'une carte face visible quand aucune carte n'a été saisie (résultat fixé seul).
const EMBLEMES = { tome: 'livre', symbole: 'corbeau', epee: 'soleil', allie: 'coeur', strahd: 'chateau', tourment: 'crane', voie: 'epingle' };
// Emblème des cartes du haut jeu sans `icone` dans les données (une icône des données, si elle existe dans la charte, prime).
const ICONES_HAUT = {
  artefact: 'amulette', 'homme-brise': 'coeur-brise', 'sombre-seigneur': 'couronne', donjon: 'cachot', fantome: 'fantome',
  bourreau: 'hache', cavalier: 'fer-cheval', innocente: 'cierge', marionnette: 'marionnette', tentatrice: 'coupe-vin',
  bete: 'loup', brumes: 'brume', corbeau: 'corbeau', voyant: 'oeil',
};
// La croix du livre, par ordre de pose : colonne, rangée, et où la poser.
const CROIX = { 1: [1, 2, 'à gauche'], 2: [2, 1, 'en haut'], 3: [3, 2, 'à droite'], 4: [2, 3, 'en bas'], 5: [2, 2, 'au centre'] };
const ROMAINS = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX'];
const rang = c => c.rang === 'maitre' ? 'Maître' : (ROMAINS[c.rang] || '');
const couleurDe = c => c.paquet === 'haut' ? 'haut' : c.suite;
const liste = v => (Array.isArray(v) ? v : v ? [v] : []);
const sansAccent = t => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const parOrdre = (a, b) => (a.ordre ?? 0) - (b.ordre ?? 0);
const TITRE_TABLE = 'La table de madame Éva';

export default {
  type: 'tarokka',
  requiert: 'tarokka',
  // Module de campagne Tarokka (app/modules/tarokka.js) : seulement pour Curse of Strahd.
  titre: 'Tarokka',
  icone: 'tarokka',
  description: 'Curse of Strahd seulement : la lecture de madame Éva et les tirages personnels, cachés jusqu\'à la validation. Un clic retourne une carte, un autre ouvre ce qu\'elle révèle.',
  taille: { w: 7, h: 15 },
  min: { w: 4, h: 4 },
  unique: true,

  async monter({ corps, actions, resume, deplier, donnees, etat, campagne }) {
    const lecture = await donnees('tarokka');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database',
        lecture.statut === 'absent' ? 'Données du Tarokka absentes' : 'Données du Tarokka illisibles',
        lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const cartes = new Map(d.cartes.map(c => [c.id, c]));
    const places = [...d.places].sort(parOrdre);
    const tp = d.tirages_personnels;
    const emplacements = [...(tp?.cartes || [])].sort(parOrdre);   // tourment, voie
    const persos = tp?.personnages || [];
    // Portraits et prénoms : personnages.json et le wiki, s'ils sont là (sinon l'initiale et le nom des lectures).
    const [lPersos, wiki] = await Promise.all([donnees('personnages').catch(() => null), chargerWiki()]);
    const fichePerso = id => (lPersos?.statut === 'ok' ? lPersos.donnees.personnages?.find(x => x.id === id) : null);
    const court = perso => fichePerso(perso.id)?.nom_court || perso.nom.split(' ')[0];

    // Tirage préparé : une place qui n'a de significations que pour une partie de son paquet liste ses cartes prévues.
    // La première est posée d'office ; les suivantes sont des cartes de secours. Une carte notée dans etat/ prime.
    const taillePaquet = pq => d.cartes.filter(c => c.paquet === pq).length;
    const prevues = p => (p.significations || []).length < taillePaquet(p.paquet)
      ? p.significations.map(x => x.carte).filter(id => cartes.has(id)) : [];
    const s = await etat('tarokka', { schema: 1, tirage: {}, suivi: {}, notes: {}, options: {}, tirage_personnel: {} });
    s.valeur.options ||= {};
    s.valeur.tirage_personnel ||= {};
    const cartePlace = p => cartes.get(s.valeur.tirage[p.id] || prevues(p)[0]);
    const cartePerso = (perso, e) => cartes.get(s.valeur.tirage_personnel[perso.id]?.[e.id] || perso.lectures?.[e.id]?.carte);
    const nomCouleur = id => d.couleurs?.find(c => c.id === id)?.nom || COULEURS[id]?.nom || id;
    const deCouleur = id => { const n = nomCouleur(id); return /^[aeiouyéèêh]/i.test(n) ? `d'${n}` : `de ${n}`; };   // « d'Épées », « de Pièces »
    const libelleCarte = c => `${c.nom}${rang(c) ? ` (${rang(c)} ${deCouleur(c.suite)})` : ''}`;
    const reveles = new Set();   // jamais enregistré : tout est caché à l'ouverture
    resume.dataset.quand = 'reduit';   // les miniatures, seulement widget réduit
    let ongletActif = 'tirage';
    let joueurActif = null;      // onglet Joueurs : personnage dont les cartes sont montrées
    let forcer = false;          // tirage validé : modification forcée, le temps d'une saisie
    const valide = () => !!s.valeur.tirage_valide;
    const dateFr = iso => new Date(iso).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
    const emblemeDe = carte => {
      const c = couleurDe(carte);
      if (c !== 'haut') return COULEURS[c].icone;
      const existe = n => n && window.BN?.icones?.includes(n);
      return existe(carte.icone) ? carte.icone : existe(ICONES_HAUT[carte.id]) ? ICONES_HAUT[carte.id] : COULEURS.haut.icone;
    };

    // ───── Emplacements : une place du tirage, ou une carte d'un tirage personnel (clé « perso:<id>:<emplacement> ») ─────

    const clePerso = (perso, e) => `perso:${perso.id}:${e.id}`;
    const clesPerso = perso => emplacements.map(e => clePerso(perso, e));
    const toutesCles = () => [...places.map(p => p.id), ...persos.flatMap(clesPerso)];
    function emplacement(cle) {
      if (cle.startsWith('perso:')) {
        const [, pid, eid] = cle.split(':');
        const perso = persos.find(x => x.id === pid), e = emplacements.find(x => x.id === eid);
        if (!perso || !e) return null;
        const l = perso.lectures?.[e.id];
        const carte = cartePerso(perso, e);
        const prevue = !l?.carte || carte?.id === l.carte;   // la carte posée est celle de la lecture préparée
        return {
          cle, perso, e, lecture: l, carte, resultat: !carte && l ? l : null, actif: !!(l || carte), embleme: e.id,
          nom: `${e.nom} ${deNom(court(perso))}`, etiquette: e.nom, role: e.role,
          titre: l && prevue ? l.titre : carte ? 'Carte non prévue' : 'Pas de lecture', lieu: prevue ? l?.lieu : null,
        };
      }
      const place = places.find(p => p.id === cle);
      if (!place) return null;
      const carte = cartePlace(place);
      const fixe = place.resultat_fixe;
      const sig = carte && place.significations?.find(x => x.carte === carte.id);
      return {
        cle, place, carte, sig, resultat: !carte && fixe ? fixe : null, actif: !!(carte || fixe), embleme: place.id,
        nom: place.nom, etiquette: place.nom, role: place.role, numero: place.ordre,
        titre: fixe?.titre || sig?.titre || (carte ? 'Carte non prévue' : 'Aucune carte notée'), lieu: fixe?.lieu || sig?.lieu,
      };
    }
    const estFace = cle => valide() || reveles.has(cle);
    const trouve = p => !!(p.libelle_suivi && s.valeur.suivi[p.id]);

    // ───── Cartes ─────

    // Face d'une carte (bouton, ou simple bloc dans une fenêtre) : la carte posée, sinon le résultat fixé (« Fixé »).
    function face(em, { tag = 'button', anime = false, attrs = {} } = {}) {
      const c = em.carte;
      return h(tag, {
        type: tag === 'button' ? 'button' : null, 'data-suite': c ? couleurDe(c) : 'haut',
        class: 'bn-tarokka' + (c ? '' : ' cm-tarokka--fixe') + (anime ? ' cm-retourne' : '') + (em.place && trouve(em.place) ? ' est-trouve' : ''), ...attrs,
      },
        h('span', { class: 'bn-tarokka__cadre' }),
        h('span', { class: 'bn-tarokka__rang', 'aria-hidden': c && !rang(c) ? 'true' : null }, c ? (rang(c) || ' ') : 'Fixé'),
        icone(c ? emblemeDe(c) : (EMBLEMES[em.embleme] || 'tarokka'), 'bn-tarokka__embleme'),
        h('h4', { class: 'bn-tarokka__nom' }, c ? c.nom : em.resultat.titre),
        h('p', { class: 'bn-tarokka__suite' }, c ? nomCouleur(couleurDe(c)) : em.etiquette));
    }

    function dos(nom, actif, onclick) {
      return h('button', {
        type: 'button', class: 'bn-tarokka bn-tarokka--dos' + (actif ? '' : ' cm-tarokka--vide'),
        'aria-label': actif ? `Retourner la carte : ${nom}` : `${nom} : rien à révéler`, disabled: !actif, onclick,
      }, icone('chauve-souris', 'bn-tarokka__embleme'));
    }

    // Une carte de la lecture : cachée, un clic la retourne ; retournée, un clic ouvre son détail.
    function carteVue(cle, anime) {
      const em = emplacement(cle);
      if (!em) return null;
      if (!em.actif || !estFace(cle)) return dos(em.nom, em.actif, () => retourner(cle));
      return lienFlottant(face(em, { anime: anime === cle, attrs: { 'aria-label': `${em.nom} : ${em.titre}. Voir le détail`, onclick: () => ouvrirDetail(cle) } }), `tarokka:${cle}`);
    }

    function retourner(cle) {
      reveles.add(cle);
      rendre(cle);
    }

    // Recacher des cartes : leurs fenêtres de détail se ferment aussi.
    function cacher(cles) {
      for (const cle of cles) { reveles.delete(cle); flottantOuvert(`tarokka:${cle}`)?.fermer(); }
      rendre();
    }
    function boutonCacher(cles) {
      const montrees = cles.filter(c => reveles.has(c));
      if (valide() || !montrees.length) return null;
      return bouton('', { icone: 'lu-eye-off', titre: 'Cacher les cartes', classe: 'bn-btn--s bn-btn--fantome cm-tk-cacher', onclick: () => cacher(montrees) });
    }

    // ───── En-tête : la table, et les cinq cartes en miniature (widget réduit) ─────

    function miniCarte(p) {
      const em = emplacement(p.id);
      const montre = valide() && em.actif;
      const quoi = montre ? ` : ${em.carte ? em.carte.nom : em.resultat.titre}` : !em.actif ? ' : pas de carte' : '';
      const libelle = `${p.nom}${quoi}${trouve(p) ? ` · ${p.libelle_suivi}` : ''}`;
      return h('button', {
        type: 'button', class: `bn-tarokka bn-tarokka--mini${montre ? '' : ' bn-tarokka--dos'}${em.actif ? '' : ' cm-tarokka--vide'}${trouve(p) ? ' est-trouve' : ''}`,
        'data-suite': montre ? (em.carte ? couleurDe(em.carte) : 'haut') : null, title: `${libelle}\nCliquer : voir la carte`, 'aria-label': libelle,
        onclick: () => montrer(p),
      }, icone(!montre ? 'chauve-souris' : em.carte ? emblemeDe(em.carte) : (EMBLEMES[p.id] || 'tarokka'), 'bn-tarokka__embleme'));
    }
    function majEntete() {
      resume.replaceChildren(h('div', { class: 'cm-tarokka-mini', role: 'group', 'aria-label': valide() ? 'Tirage de madame Éva (validé)' : 'Tirage de madame Éva (pas encore validé)' }, places.map(miniCarte)));
    }

    // Clic sur une miniature : déplier, onglet Tirage, retourner la carte et ouvrir son détail.
    function montrer(p) {
      deplier();
      ongletActif = 'tirage';
      const em = emplacement(p.id);
      if (!em.actif) { rendre(); return; }
      reveles.add(p.id);
      rendre(p.id);
      ouvrirDetail(p.id);
    }

    actions.append(bouton('', { icone: 'croix-tarokka', titre: TITRE_TABLE + ' : la lecture en grand, à la bonne place', classe: 'bn-btn--s bn-btn--fantome', onclick: () => ouvrirTable() }));

    // ───── Détail d'une carte (fenêtre flottante) ─────

    function lieuZone(o) {
      if (!o?.lieu && !o?.zone) return null;
      return h('p', { class: 'cm-lieu' }, icone('epingle', 'bn-icone--s'), [o.lieu, o.zone && 'zone ' + o.zone].filter(Boolean).join(', '));
    }

    // « texte » d'une signification : pour le MJ seul (où, comment, à quelle condition), jamais lu aux joueurs.
    function pourMJ(texte) {
      if (!texte) return null;
      return h('div', { class: 'cm-pour-mj' },
        h('p', { class: 'etiquette cm-pour-mj__titre' }, icone('lu-eye-off', 'bn-icone--s'), 'Pour le MJ, ne pas lire'),
        h('p', { class: 'texte' }, texte));
    }

    function aLire(texte) {
      if (!texte) return null;
      return h('figure', { class: 'bn-alire' },
        h('figcaption', { class: 'bn-alire__label' }, icone('livre', 'bn-icone--s'), 'À lire à voix haute'),
        String(texte).split(/\n{2,}/).map(p => h('p', {}, p)));
    }

    function idee(texte) {
      if (!texte) return null;
      return h('div', { class: 'cm-idee' },
        h('p', { class: 'etiquette cm-section__titre' }, icone('tarokka', 'bn-icone--s'), 'Idée de la prophétie'),
        h('p', { class: 'lecture' }, texte));
    }

    function section(titre, ic, ...contenu) {
      const c = contenu.flat().filter(Boolean);
      if (!c.length) return null;
      return h('div', { class: 'cm-section' }, h('p', { class: 'etiquette cm-section__titre' }, ic ? icone(ic, 'bn-icone--s') : null, titre), ...c);
    }

    function repli(titre, ...contenu) {
      const c = contenu.flat().filter(Boolean);
      if (!c.length) return null;
      return h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, titre), h('div', { class: 'cm-pile' }, ...c));
    }

    function notes(cle) {
      return h('label', { class: 'bn-champ' },
        h('span', { class: 'bn-champ__label' }, 'Notes de séance'),
        h('textarea', {
          class: 'bn-textarea cm-notes', rows: 2, placeholder: 'Ce que les joueurs en ont compris, où ils en sont…',
          oninput: e => { s.valeur.notes[cle] = e.target.value; s.enregistrer(800); },
        }, s.valeur.notes[cle] || ''));
    }

    // Options A / B d'une carte (allié) : le MJ choisit, le choix est gardé.
    function blocOptions(cleChoix, options) {
      if (!options?.length) return null;
      const choisie = s.valeur.options[cleChoix];
      return h('div', { class: 'cm-options' }, options.map(o => h('div', { class: 'bn-carte cm-option-carte' + (choisie === o.id ? ' est-choisie' : '') },
        h('div', { class: 'cm-fiche__tete' },
          h('span', { class: 'cm-choix__nom' }, `${o.id} · ${o.titre}`),
          bouton(choisie === o.id ? 'Retenue' : 'Retenir', {
            classe: 'bn-btn--s', 'aria-pressed': String(choisie === o.id),
            onclick: () => { s.valeur.options[cleChoix] = choisie === o.id ? undefined : o.id; s.enregistrer(0); rendre(); },
          })),
        lieuZone(o),
        o.texte ? h('p', { class: 'ui' }, o.texte) : null)));
    }

    function blocSignification(place, sig) {
      return [
        lieuZone(sig),
        aLire(sig.a_lire),
        idee(sig.idee_prophetie),
        pourMJ(sig.texte),
        blocOptions(`${place.id}:${sig.carte}`, sig.options),
        sig.renvois?.length ? h('p', { class: 'ui-s cm-sourdine' }, 'Voir : ' + sig.renvois.join(' · ')) : null,
        blocEcarts(sig.ecarts, campagne.libelle),
      ];
    }

    function idees(place, fixe) {
      const lf = place.lectures_focos;
      if (!lf) return null;
      const retenu = n => fixe && sansAccent(fixe.titre + ' ' + (fixe.lieu || '')).includes(sansAccent(n));
      const ligne = x => h('li', { class: retenu(x.nom) ? 'est-retenu' : null }, h('b', {}, x.nom), ' : ', x.idee, retenu(x.nom) ? [' ', badge('Retenu', 'brume', 'lu-check')] : null);
      return repli('Idées de Fleshing Out pour la prophétie',
        lf.usage ? h('p', { class: 'ui-s cm-sourdine' }, lf.usage) : null,
        lf.pnj?.length ? section('PNJ', null, h('ul', { class: 'ui cm-liste cm-idees' }, lf.pnj.map(ligne))) : null,
        lf.lieux?.length ? section('Lieux', null, h('ul', { class: 'ui cm-liste cm-idees' }, lf.lieux.map(ligne))) : null);
    }

    // Carte sans signification : voulu quand le tirage est préparé (seules les cartes prévues en ont une).
    function nonPrevue(place, carte) {
      if (!carte) return alerte('', 'lu-info', 'Aucune carte notée', 'Notez la carte posée à cette place dans l\'onglet Édition.');
      const pv = (place.significations || []).map(x => cartes.get(x.carte)?.nom || x.carte);
      return alerte('', 'lu-info', 'Carte non prévue',
        pv.length
          ? `Aucune prophétie pour « ${carte.nom} » à cette place. ${pv.length > 1 ? 'Cartes prévues' : 'Carte prévue'} : ${pv.join(', ')}.`
          : `Aucune prophétie n'est prévue pour « ${place.nom} ».`);
    }

    // Carte prévue ou carte de secours : bascule en un clic, gardée dans etat/ (pas une fois le tirage validé).
    function choixPrevue(place, carte) {
      const pv = prevues(place);
      if (pv.length < 2 || valide()) return null;
      return h('div', { class: 'cm-contexte' },
        h('span', { class: 'etiquette' }, 'Carte posée'),
        h('div', { class: 'bn-bascule', role: 'group', 'aria-label': `Carte posée : ${place.nom}` }, pv.map((id, i) => h('button', {
          type: 'button', class: 'bn-btn bn-btn--s', 'aria-pressed': String(carte?.id === id),
          onclick: () => { if (i === 0) delete s.valeur.tirage[place.id]; else s.valeur.tirage[place.id] = id; s.enregistrer(0); rendre(); },
        }, h('span', {}, cartes.get(id).nom + (i ? ' (secours)' : ''))))));
    }

    function textePlace(em) {
      const { place, carte, sig } = em;
      const fixe = place.resultat_fixe;
      const coincide = carte && fixe?.cartes_coherentes?.includes(carte.id);
      return [
        place.libelle_suivi ? h('label', { class: 'cm-case' },
          h('input', {
            type: 'checkbox', class: 'bn-case', checked: !!s.valeur.suivi[place.id],
            onchange: e => { s.valeur.suivi[place.id] = e.target.checked; s.enregistrer(); rendre(); },
          }), place.libelle_suivi) : null,
        choixPrevue(place, carte),
        fixe ? [
          h('div', { class: 'bn-groupe' },
            badge('Résultat fixé', 'sang', 'tarokka'),
            carte ? (coincide ? badge('La carte coïncide', 'brume', 'lu-check') : badge('Lire le résultat fixé', 'cierge')) : null),
          lieuZone(fixe),
          pourMJ(fixe.texte),
          idee(fixe.idee_prophetie),
          section('Conséquences', 'carte', fixe.consequences ? h('p', { class: 'ui' }, fixe.consequences) : null),
        ] : sig ? blocSignification(place, sig) : nonPrevue(place, carte),
        section('Règles', 'lu-info', liste(place.regles).map(r => h('p', { class: 'ui' }, r))),
        idees(place, fixe),
        fixe && sig ? repli(`Selon le livre, pour ${carte.nom}`, h('p', { class: 'cm-choix__nom' }, sig.titre), blocSignification(place, sig)) : null,
        fixe?.cartes_coherentes?.length ? repli('Cartes qui coïncident',
          h('p', { class: 'ui' }, fixe.cartes_coherentes.map(id => {
            const c = cartes.get(id);
            return c ? `${libelleCarte(c)}${c.carte_a_jouer ? ' · ' + c.carte_a_jouer : ''}` : id;
          }).join(' ; '))) : null,
        place.ecarts?.length ? repli(`Écarts de la place (${place.ecarts.length})`, blocEcarts(place.ecarts, campagne.libelle)) : null,
        notes(place.id),
      ];
    }

    function blocLecture(l) {
      return [lieuZone(l), aLire(l.a_lire), idee(l.idee_prophetie), pourMJ(l.texte), blocEcarts(l.ecarts, campagne.libelle)];
    }

    function textePerso(em) {
      const { perso, e, lecture: l, carte } = em;
      const prevue = l?.carte && cartes.get(l.carte);
      const autre = carte && prevue && carte.id !== prevue.id;
      return [
        perso.quete ? h('p', { class: 'ui-s cm-sourdine' }, perso.quete) : null,
        !l ? alerte('', 'lu-info', 'Pas de lecture', `Aucune lecture préparée pour ${em.nom}.`)
          : autre ? [
            alerte('', 'lu-info', 'Carte non prévue', `La lecture préparée va avec « ${prevue.nom} ».`),
            repli(`Lecture préparée, pour ${prevue.nom}`, h('p', { class: 'cm-choix__nom' }, l.titre), blocLecture(l)),
          ] : blocLecture(l),
        e.role ? h('p', { class: 'ui-s cm-sourdine' }, `${e.nom} : ${e.role}.`) : null,
        perso.ecarts?.length ? repli(`Écarts (${perso.ecarts.length})`, blocEcarts(perso.ecarts, campagne.libelle)) : null,
        notes(em.cle),
      ];
    }

    function detail(cle) {
      const em = emplacement(cle);
      if (!em) return null;
      const carteVisible = em.actif ? face(em, { tag: 'div' }) : null;
      return {
        surtitre: [em.nom, em.carte && libelleCarte(em.carte)].filter(Boolean).join(' · '),
        titre: em.titre,
        contenu: h('div', { class: 'cm-tk-detail', 'data-suite': em.carte ? couleurDe(em.carte) : 'haut' },
          carteVisible ? h('div', { class: 'cm-tk-detail__carte' }, carteVisible,
            em.carte?.carte_a_jouer ? h('p', { class: 'ui-s cm-sourdine' }, em.carte.carte_a_jouer) : null) : null,
          h('div', { class: 'cm-tk-detail__texte' }, em.place ? textePlace(em) : textePerso(em))),
      };
    }

    function ouvrirDetail(cle) {
      const c = detail(cle);
      if (c) flottant(`tarokka:${cle}`, { ...c, largeur: 780 });
    }
    function majDetails() {
      for (const cle of toutesCles()) {
        const f = flottantOuvert(`tarokka:${cle}`);
        if (!f) continue;
        if (!f.el.contains(document.activeElement) || document.activeElement.tagName !== 'TEXTAREA') { const c = detail(cle); f.maj(c.contenu, c.titre, c.surtitre); }
      }
    }

    // ───── La croix du tirage, partagée par l'onglet Déroulement et la table ─────

    // rendu(p) : l'élément posé à la place p. Moins ou plus de cinq places : en ligne, dans l'ordre.
    function croix(rendu, classe = '') {
      const enCroix = places.length === 5 && places.every(p => CROIX[p.ordre]);
      return h('div', { class: `cm-tk-croix ${enCroix ? '' : 'cm-tk-croix--ligne'} ${classe}`.trim() }, places.map((p, i) => {
        const [col, rangee] = enCroix ? CROIX[p.ordre] : [i + 1, 1];
        const el = rendu(p);
        el.style.gridColumn = String(col);
        el.style.gridRow = String(rangee);
        return el;
      }));
    }
    const ouPoser = p => places.length === 5 ? CROIX[p.ordre]?.[2] : null;

    // ───── Onglet Tirage : les cartes seules ─────

    function vueTirage(anime) {
      const actives = places.filter(p => emplacement(p.id).actif);
      if (!actives.length) {
        return h('div', { class: 'cm-vide' },
          h('div', { class: 'bn-tirage' }, places.map(p => h('div', { class: 'bn-tirage__place' }, h('span', { class: 'surtitre' }, p.nom), dos(p.nom, false)))),
          h('p', { class: 'ui cm-sourdine' }, 'Aucun tirage enregistré. Après la lecture de madame Éva, notez les cartes sorties.'),
          bouton('Noter les cartes', { icone: 'lu-pencil', classe: 'bn-btn--primaire', onclick: () => { ongletActif = 'cartes'; rendre(); } }));
      }
      return h('div', { class: 'cm-tarokka' },
        h('div', { class: 'bn-tirage', role: 'group', 'aria-label': 'Tirage de madame Éva' },
          places.map(p => h('div', { class: 'bn-tirage__place' }, h('span', { class: 'surtitre' }, p.nom), carteVue(p.id, anime)))),
        boutonCacher(places.map(p => p.id)));
    }

    // ───── Onglet Joueurs ─────

    function portrait(perso) {
      const src = portraitDuPersonnage(fichePerso(perso.id), wiki);
      const initiale = court(perso).charAt(0).toUpperCase();
      return h('span', { class: 'cm-portrait cm-tk-portrait' },
        src ? h('img', { src, alt: '', loading: 'lazy', onerror: e => e.target.replaceWith(document.createTextNode(initiale)) }) : initiale);
    }

    function vueJoueurs(anime) {
      if (!tp) return h('p', { class: 'ui cm-sourdine' }, 'Pas de tirage personnel dans data/tarokka.json.');
      if (!persos.length) {
        return alerte('cierge', 'sablier', 'Lectures personnelles en attente',
          'Les personnages et leurs deux lectures ne sont pas encore dans data/tarokka.json (format : formats/tarokka.md, « tirages_personnels »).');
      }
      const choisi = persos.find(x => x.id === joueurActif);
      return h('div', { class: 'cm-tk-joueurs' },
        h('div', { class: 'cm-tk-joueurs__menu', role: 'group', 'aria-label': 'Tirages personnels' }, persos.map(x => h('button', {
          type: 'button', class: 'cm-tk-joueur', 'aria-pressed': String(x.id === joueurActif),
          title: x.id === joueurActif ? 'Revenir au tourment et à la voie' : `Les cartes ${deNom(court(x))}`,
          onclick: () => { joueurActif = joueurActif === x.id ? null : x.id; rendre(); },
        }, portrait(x), h('span', { class: 'cm-tk-joueur__nom' }, court(x))))),
        h('div', { class: 'cm-tk-joueurs__vue' }, choisi ? vueJoueur(choisi, anime) : vueEmplacements()));
    }

    // Par défaut : ce que disent le tourment et la voie.
    function vueEmplacements() {
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'cm-tk-emplacements' }, emplacements.map(e => h('div', { class: 'cm-tk-emplacement', 'data-suite': e.paquet === 'haut' ? 'haut' : 'commun' },
          icone(EMBLEMES[e.id] || 'tarokka', 'cm-tk-emplacement__icone'),
          h('div', {},
            h('p', { class: 'cm-tk-emplacement__nom' }, e.nom, h('span', { class: 'ui-s cm-sourdine' }, e.paquet === 'haut' ? 'haut jeu' : 'jeu commun')),
            h('p', { class: 'ui' }, e.role))))),
        tp.resume ? h('p', { class: 'ui cm-sourdine' }, tp.resume) : null,
        repli('Conseils', tp.conseils?.length ? h('ul', { class: 'ui cm-liste' }, tp.conseils.map(c => h('li', {}, c))) : null),
        tp.ecarts?.length ? repli(`Écarts (${tp.ecarts.length})`, blocEcarts(tp.ecarts, campagne.libelle)) : null);
    }

    // Les deux cartes seules (le nom est sur le bouton enfoncé ; la quête et les écarts, dans la fenêtre d'une carte),
    // à la hauteur du widget : tout se voit sans défiler (ajusterDuo).
    function vueJoueur(perso, anime) {
      return h('div', { class: 'cm-tk-joueur-vue' },
        h('div', { class: 'bn-tirage cm-tk-duo' }, emplacements.map(e =>
          h('div', { class: 'bn-tirage__place' }, h('span', { class: 'surtitre' }, e.nom), carteVue(clePerso(perso, e), anime)))),
        boutonCacher(clesPerso(perso)));
    }

    // Largeur des cartes d'un joueur : ce que laisse la hauteur du widget sous leurs libellés (cartes en 5 / 8), 150 px au plus.
    function ajusterDuo() {
      const duo = corps.querySelector('.cm-tk-joueurs__vue .cm-tk-duo');
      if (!duo) return;
      const place = duo.querySelector('.bn-tirage__place');
      const libelle = place.firstElementChild.offsetHeight + parseFloat(getComputedStyle(place).rowGap || 0);
      const bas = corps.getBoundingClientRect().bottom - parseFloat(getComputedStyle(corps).paddingBottom || 0);
      const haut = duo.getBoundingClientRect().top + corps.scrollTop;
      const largeur = Math.max(56, Math.min(150, Math.floor((bas - haut - libelle - 4) / 1.6)));
      duo.style.setProperty('--_l', largeur + 'px');
    }
    new ResizeObserver(() => { if (corps.isConnected) ajusterDuo(); }).observe(corps);

    // ───── Onglet Déroulement : calculé d'après le tirage ─────

    // Ordre des paquets, du dessus : le tirage principal, puis les tirages personnels (un personnage après l'autre).
    function paquets() {
      const pile = { commun: [], haut: [] };
      for (const p of places) { const c = cartePlace(p); if (c) pile[c.paquet]?.push({ carte: c, cle: p.id, pour: `${p.ordre}. ${p.nom}` }); }
      for (const perso of persos) for (const e of emplacements) {
        const c = cartePerso(perso, e);
        if (c) pile[c.paquet]?.push({ carte: c, cle: clePerso(perso, e), pour: `${e.nom.toLowerCase()} ${deNom(court(perso))}` });
      }
      const posees = new Set([...pile.commun, ...pile.haut].map(x => x.carte.id));
      const aPart = places.flatMap(p => prevues(p).filter(id => !posees.has(id))
        .map(id => ({ carte: cartes.get(id), cle: p.id, pour: `secours pour ${p.nom}` })));
      return { ...pile, aPart };
    }

    function puce(x) {
      if (!x?.carte) return h('span', { class: 'cm-sourdine' }, 'aucune carte');
      return h('button', {
        type: 'button', class: 'cm-tk-puce', 'data-suite': couleurDe(x.carte), onclick: () => ouvrirDetail(x.cle),
        title: [libelleCarte(x.carte), x.carte.carte_a_jouer].filter(Boolean).join(' · ') + '\nVoir le détail',
      }, icone(emblemeDe(x.carte), 'bn-icone--s'), h('span', {}, x.carte.nom));
    }

    function vueDeroulement() {
      const dr = d.deroulement || {};
      const pq = paquets();
      const pile = (titre, l) => l.length ? h('div', { class: 'cm-tk-pile' },
        h('p', { class: 'etiquette' }, titre),
        h('ol', { class: 'cm-tk-pile__liste' }, l.map(x => h('li', {}, puce(x), h('span', { class: 'ui-s cm-sourdine' }, x.pour))))) : null;
      const posees = pqt => places.filter(p => cartePlace(p)?.paquet === pqt || (!cartePlace(p) && p.paquet === pqt));
      const pose = pqt => posees(pqt).map(p => `${p.ordre}${ouPoser(p) ? ' ' + ouPoser(p) : ''}`).join(', ');
      const schema = croix(p => {
        const em = emplacement(p.id);
        return h('div', { class: 'cm-tk-place' },
          h('span', { class: 'cm-tk-place__nom' }, h('b', {}, p.ordre), ' ', p.nom),
          em.actif ? face(em, { attrs: { 'aria-label': `${p.nom} : ${em.titre}. Voir le détail`, onclick: () => ouvrirDetail(p.id) } }) : dos(p.nom, false));
      }, 'cm-tk-croix--petite');
      const etapes = [
        h('li', {}, `Séparer les deux paquets : le haut jeu (${taillePaquet('haut')} cartes) et le jeu commun (${taillePaquet('commun')}).`),
        posees('commun').length ? h('li', {}, `Jeu commun : poser face cachée les ${posees('commun').length} premières cartes : ${pose('commun')}.`) : null,
        posees('haut').length ? h('li', {}, `Haut jeu : poser face cachée les ${posees('haut').length} premières cartes : ${pose('haut')}.`) : null,
        places.map(p => {
          const em = emplacement(p.id);
          return h('li', {}, `Retourner la carte ${p.ordre}${ouPoser(p) ? ` (${ouPoser(p)})` : ''}, ${p.nom} : `, puce({ carte: em.carte, cle: p.id }),
            em.actif ? h('span', { class: 'cm-tk-etape__resultat' }, ` → ${em.titre}`) : null, '. Lire la prophétie.');
        }),
      ];
      return h('div', { class: 'cm-pile cm-tk-deroulement' },
        dr.resume ? h('p', { class: 'texte' }, dr.resume) : null,
        section('Avant la séance : ranger les paquets', 'tarokka',
          h('div', { class: 'cm-tk-piles' }, pile('Jeu commun, du dessus', pq.commun), pile('Haut jeu, du dessus', pq.haut)),
          pq.aPart.length ? h('p', { class: 'ui cm-tk-apart' }, 'À part : ', pq.aPart.map((x, i) => [i ? ', ' : '', puce(x), ` (${x.pour})`])) : null,
          d.couleurs?.some(c => c.carte_a_jouer) ? h('p', { class: 'ui-s cm-sourdine' },
            'Avec un jeu de cartes classique : ' + d.couleurs.map(c => `${c.nom} = ${c.carte_a_jouer}`).join(', ') + '.') : null),
        section('La lecture', 'chauve-souris',
          h('div', { class: 'cm-tk-lecture' }, schema, h('ol', { class: 'ui cm-liste cm-tk-etapes' }, etapes))),
        persos.length ? section('Les tirages personnels', 'lu-users',
          tp.resume ? h('p', { class: 'ui-s cm-sourdine' }, tp.resume) : null,
          h('ol', { class: 'ui cm-liste cm-tk-etapes' }, persos.map(perso => h('li', {}, h('b', {}, court(perso)), ' pioche ',
            emplacements.map((e, i) => [i ? ', puis ' : '', puce({ carte: cartePerso(perso, e), cle: clePerso(perso, e) }), ` (${e.nom.toLowerCase()})`]), '.'))),
          repli('Conseils', tp.conseils?.length ? h('ul', { class: 'ui cm-liste' }, tp.conseils.map(c => h('li', {}, c))) : null)) : null,
        section('Après la lecture', 'lu-check',
          !valide() ? h('p', { class: 'ui' }, 'Valider le tirage dans l\'onglet Édition : les cartes se montrent alors face visible.') : h('p', { class: 'ui cm-sourdine' }, `Tirage validé le ${dateFr(s.valeur.tirage_valide)}.`),
          dr.ecarts?.length ? repli(`Décisions et écarts (${dr.ecarts.length})`, blocEcarts(dr.ecarts, campagne.libelle)) : null),
        dr.etapes?.length ? repli('Selon le livre', h('ol', { class: 'ui cm-liste' }, dr.etapes.map(e => h('li', {}, e)))) : null,
        h('p', { class: 'ui-s cm-sourdine' }, `${dr.source || ''}${dr.pages_livre ? ', p. ' + dr.pages_livre : ''}`));
    }

    // ───── Onglet Édition : cartes réellement posées, validation du tirage ─────

    function vueCartes() {
      return valide() && !forcer ? vueValide() : vueSaisie();
    }

    // Tirage validé : les cartes posées, en lecture seule ; « Forcer la modification » rouvre la saisie.
    function vueValide() {
      return h('div', { class: 'cm-pile' },
        alerte('brume', 'lu-lock', 'Tirage validé', `Le ${dateFr(s.valeur.tirage_valide)}. Les cartes posées ne se changent plus.`),
        h('ul', { class: 'ui cm-liste' }, places.map(p => {
          const carte = cartePlace(p);
          return h('li', {}, h('b', {}, p.nom), ' : ', carte ? libelleCarte(carte) : p.resultat_fixe ? `résultat fixé (${p.resultat_fixe.titre})` : 'aucune carte');
        })),
        persos.length ? h('ul', { class: 'ui cm-liste' }, persos.map(perso => h('li', {}, h('b', {}, court(perso)), ' : ',
          emplacements.map(e => { const c = cartePerso(perso, e); return `${e.nom.toLowerCase()}, ${c ? libelleCarte(c) : 'aucune carte'}`; }).join(' ; ')))) : null,
        h('div', { class: 'bn-groupe' },
          bouton('Forcer la modification', { icone: 'lu-lock-open', classe: 'bn-btn--s bn-btn--fantome', titre: 'Pour corriger une erreur de saisie', onclick: () => { forcer = true; rendre(); } })));
    }

    // Liste des cartes d'un paquet, par couleur ; marque(c) : « · prévue », « · secours »…
    function choixCarte(id, paquet, vide, valeur, marque, surChoix) {
      const groupes = {};
      for (const c of d.cartes.filter(c => !paquet || c.paquet === paquet)) (groupes[couleurDe(c)] ||= []).push(c);
      const select = h('select', { class: 'bn-select', id, onchange: e => surChoix(e.target.value) },
        h('option', { value: '' }, vide),
        Object.entries(groupes).map(([coul, l]) => h('optgroup', { label: nomCouleur(coul) },
          l.map(c => h('option', { value: c.id }, (rang(c) ? `${c.nom} (${rang(c)})` : c.nom) + marque(c))))));
      select.value = valeur || '';
      return select;
    }

    function vueSaisie() {
      const choix = {};            // place → carte
      const choixPerso = {};       // personnage → emplacement → carte
      const erreur = h('p', { class: 'bn-champ__erreur', hidden: true });
      const efface = () => { erreur.hidden = true; };
      const champs = places.map(p => {
        const coherentes = new Set(p.resultat_fixe?.cartes_coherentes || []);
        const pv = prevues(p);
        const marque = c => coherentes.has(c.id) ? ' · coïncide' : pv[0] === c.id ? ' · prévue' : pv.includes(c.id) ? ' · secours' : '';
        choix[p.id] = s.valeur.tirage[p.id] || '';
        return h('div', { class: 'bn-champ' },
          h('label', { class: 'bn-champ__label', for: `tk-${p.id}` }, p.nom),
          choixCarte(`tk-${p.id}`, p.paquet, pv.length ? `— Carte prévue : ${cartes.get(pv[0]).nom} —` : p.resultat_fixe ? '— Non notée —' : '— Pas encore tirée —',
            choix[p.id], marque, v => { choix[p.id] = v; efface(); }),
          h('span', { class: 'bn-champ__aide' }, p.resultat_fixe ? 'Résultat fixé : la carte ne change pas la lecture.' : pv.length ? 'À changer seulement si une autre carte a été posée.' : (p.role || '')));
      });
      const champsPerso = persos.map(perso => {
        choixPerso[perso.id] = { ...(s.valeur.tirage_personnel[perso.id] || {}) };
        return h('div', { class: 'cm-tk-saisie-perso' },
          h('p', { class: 'etiquette' }, court(perso)),
          h('div', { class: 'cm-saisie__champs' }, emplacements.map(e => {
            const prevue = perso.lectures?.[e.id]?.carte;
            const id = `tk-${perso.id}-${e.id}`;
            return h('div', { class: 'bn-champ' },
              h('label', { class: 'bn-champ__label', for: id }, e.nom),
              choixCarte(id, e.paquet, prevue && cartes.has(prevue) ? `— Carte prévue : ${cartes.get(prevue).nom} —` : '— Pas encore tirée —',
                choixPerso[perso.id][e.id], c => prevue === c.id ? ' · prévue' : '', v => { if (v) choixPerso[perso.id][e.id] = v; else delete choixPerso[perso.id][e.id]; efface(); }));
          })));
      });
      // valider : true (valider le tirage), false (retirer la validation), undefined (ne rien changer).
      const enregistrer = valider => {
        // Cartes réellement posées, cartes prévues comprises : un paquet n'a qu'un exemplaire de chaque carte.
        const prises = [
          ...places.map(p => choix[p.id] || prevues(p)[0]),
          ...persos.flatMap(perso => emplacements.map(e => choixPerso[perso.id][e.id] || perso.lectures?.[e.id]?.carte)),
        ].filter(Boolean);
        const doublon = prises.find((id, i) => prises.indexOf(id) !== i);
        if (doublon) {
          erreur.replaceChildren(icone('crane', 'bn-icone--s'), `« ${cartes.get(doublon)?.nom || doublon} » est posée deux fois. Un paquet n'a qu'un exemplaire de chaque carte.`);
          erreur.hidden = false;
          return;
        }
        if (valider && !confirm('Valider le tirage ? Les cartes posées ne pourront plus être changées, sauf en forçant la modification.')) return;
        const avant = JSON.stringify([s.valeur.tirage, s.valeur.tirage_personnel]);
        s.valeur.tirage = Object.fromEntries(Object.entries(choix).filter(([, v]) => v));
        s.valeur.tirage_personnel = Object.fromEntries(Object.entries(choixPerso).filter(([, v]) => Object.keys(v).length));
        if (JSON.stringify([s.valeur.tirage, s.valeur.tirage_personnel]) !== avant) s.valeur.date_tirage = new Date().toISOString();
        if (valider) s.valeur.tirage_valide = new Date().toISOString();
        if (valider === false) delete s.valeur.tirage_valide;
        s.enregistrer(0);
        forcer = false;
        reveles.clear();
        rendre();
        if (valider === undefined && !valide()) corps.querySelector('.cm-saisie__ok')?.removeAttribute('hidden');
      };
      const truque = places.some(p => p.resultat_fixe);
      const prepare = places.some(p => prevues(p).length);
      const enForce = valide();
      const aide = prepare
        ? 'Les cartes prévues sont posées d\'office. Ne changez une place que si une autre carte a été posée à la table.'
        : truque
        ? 'Les résultats sont fixés d\'avance : noter les cartes piochées est facultatif. Les cartes marquées « coïncide » disent la même chose que le résultat fixé.'
        : 'Choisissez la carte sortie pour chaque place.';
      return h('form', { class: 'cm-saisie', onsubmit: e => { e.preventDefault(); enregistrer(enForce ? undefined : true); } },
        enForce
          ? alerte('cierge', 'lu-lock-open', 'Modification forcée', `Tirage validé le ${dateFr(s.valeur.tirage_valide)}. Ne changez une carte que pour corriger une erreur de saisie.`)
          : alerte('', 'lu-info', 'Cartes piochées', `${aide} Une fois le tirage validé, les cartes ne se changent plus.`),
        h('div', { class: 'cm-saisie__champs' }, champs),
        champsPerso.length ? h('div', { class: 'cm-pile' }, h('p', { class: 'etiquette cm-section__titre' }, icone('lu-users', 'bn-icone--s'), 'Tirages personnels'), champsPerso) : null,
        erreur,
        h('div', { class: 'bn-groupe' },
          enForce ? [
            h('button', { type: 'submit', class: 'bn-btn bn-btn--primaire' }, icone('lu-check'), h('span', {}, 'Enregistrer la correction')),
            bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => { forcer = false; rendre(); } }),
            bouton('Retirer la validation', { icone: 'lu-lock-open', classe: 'bn-btn--fantome', onclick: () => enregistrer(false) }),
          ] : [
            h('button', { type: 'submit', class: 'bn-btn bn-btn--primaire' }, icone('lu-lock'), h('span', {}, 'Valider le tirage')),
            bouton('Enregistrer sans valider', { icone: 'lu-check', classe: 'bn-btn--fantome', onclick: () => enregistrer() }),
            h('span', { class: 'ui-s cm-sourdine cm-saisie__ok', hidden: true }, 'Enregistré.'),
          ]));
    }

    // ───── La table de madame Éva : plein écran, la croix à gauche, les joueurs à droite, la légende au bout ─────

    // La légende garde la dernière carte survolée : on lit sans tenir la souris.
    let decrite = null;
    function contenuTable(anime) {
      const legende = h('div', { class: 'cm-tk-legende', 'aria-live': 'polite' });
      const parDefaut = () => legende.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, valide()
        ? 'Survolez une carte : sa place et ce qu\'elle révèle. Un clic ouvre le détail.'
        : 'Survolez une carte : sa place. Un clic la retourne, un autre ouvre son détail.'));
      const decrire = cle => {
        decrite = cle;
        const em = emplacement(cle);
        const vue = em.actif && estFace(cle);
        // Prophétie à lire, seulement si la carte posée est celle de la lecture préparée.
        const texte = !vue ? null : em.place ? (em.sig?.a_lire || em.place.resultat_fixe?.idee_prophetie) : em.titre !== 'Carte non prévue' ? em.lecture?.a_lire : null;
        legende.replaceChildren(...[   // replaceChildren écrirait « null »
          h('p', { class: 'cm-tk-legende__place' }, em.numero ? h('span', { class: 'cm-tk-num' }, em.numero) : null, h('b', {}, em.nom)),
          em.role ? h('p', { class: 'ui-s cm-sourdine' }, em.role) : null,
          vue ? h('p', { class: 'cm-tk-legende__resultat', 'data-suite': em.carte ? couleurDe(em.carte) : 'haut' },
            em.carte ? h('span', { class: 'cm-tk-legende__carte' }, em.carte.nom) : null, em.carte ? ' → ' : null, em.titre,
            em.lieu ? h('span', { class: 'cm-tk-legende__lieu' }, em.lieu) : null)
            : h('p', { class: 'ui-s cm-sourdine' }, em.actif ? 'Face cachée : un clic la retourne.' : 'Pas de carte à cette place.'),
          texte ? h('div', { class: 'cm-tk-legende__lire' }, String(texte).split(/\n{2,}/).map(p => h('p', {}, p))) : null,
        ].filter(Boolean));
      };
      const surCarte = (el, cle) => { el.addEventListener('pointerenter', () => decrire(cle)); el.addEventListener('focusin', () => decrire(cle)); return el; };
      const place = (cle, etiquette) => surCarte(h('div', { class: 'cm-tk-place' }, h('span', { class: 'cm-tk-place__nom' }, etiquette), carteVue(cle, anime)), cle);
      // Les joueurs : une ligne par héros (portrait et prénom, puis le tourment et la voie), les emplacements en tête de colonne.
      const joueurs = persos.length ? h('div', { class: 'cm-tk-tjoueurs', style: `--_n: ${emplacements.length}` },
        h('span'), emplacements.map(e => h('span', { class: 'cm-tk-tjoueurs__tete' }, e.nom)),
        persos.map(perso => [
          h('div', { class: 'cm-tk-tjoueurs__nom' }, portrait(perso), h('span', {}, court(perso))),
          emplacements.map(e => surCarte(h('div', { class: 'cm-tk-tjoueurs__carte' }, carteVue(clePerso(perso, e), anime)), clePerso(perso, e))),
        ])) : null;
      const cles = toutesCles();
      if (cles.includes(decrite)) decrire(decrite); else parDefaut();
      return {
        surtitre: valide() ? `Tirage validé le ${dateFr(s.valeur.tirage_valide)}` : 'Face cachée tant que le tirage n\'est pas validé',
        contenu: h('div', { class: 'cm-tk-tablee' },
          h('div', { class: 'cm-tk-table' },
            croix(p => place(p.id, [h('b', {}, p.ordre), ' ', p.nom])),
            joueurs,
            boutonCacher(cles)),
          legende),
      };
    }
    function ouvrirTable() {
      const c = contenuTable();
      flottant('tarokka:table', { titre: TITRE_TABLE, surtitre: c.surtitre, contenu: c.contenu, plein: true });
    }
    function majTable(anime) {
      const f = flottantOuvert('tarokka:table');
      if (f) { const c = contenuTable(anime); f.maj(c.contenu, TITRE_TABLE, c.surtitre); }
    }

    // ───── Rendu ─────

    function rendre(anime) {
      majEntete();
      const haut = corps.scrollTop;
      const o = onglets('Tarokka', [
        { id: 'tirage', libelle: 'Tirage', icone: 'tarokka', rendu: () => vueTirage(anime) },
        { id: 'personnels', libelle: 'Joueurs', icone: 'lu-users', rendu: () => vueJoueurs(anime) },
        { id: 'cartes', libelle: 'Édition', court: 'Édit', icone: valide() ? 'lu-lock' : 'lu-pencil', rendu: vueCartes },
        { id: 'deroulement', libelle: 'Déroulement', icone: 'livre', rendu: vueDeroulement },
      ], ongletActif, id => { if (id !== ongletActif) { ongletActif = id; forcer = false; corps.scrollTop = 0; requestAnimationFrame(ajusterDuo); } });
      corps.replaceChildren(o.barre, o.zone);
      corps.scrollTop = haut;
      ajusterDuo();
      majTable(anime);
      majDetails();
    }
    rendre();
    return {};
  },
};
