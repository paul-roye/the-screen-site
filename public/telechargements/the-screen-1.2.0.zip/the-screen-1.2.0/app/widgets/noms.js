// Widget Noms : prénom + nom de famille accordé au genre, tirés des noms de la campagne.
// Données : data/noms.json (formats/noms.md). État : etat/noms.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, bascule, heure, identifiant } from '../ui.js';
import { auHasard } from '../des.js';

const HISTORIQUE_MAX = 200;
const GENRES = { m: 'Masculin', f: 'Féminin' };

export default {
  type: 'noms',
  requiert: 'noms',
  titre: 'Noms',
  icone: 'lettre',
  description: 'Prénom et nom de famille accordé au genre, en un clic. Historique des noms tirés, noms retenus avec une note.',
  taille: { w: 4, h: 11 },
  min: { w: 3, h: 6 },
  unique: true,

  async monter({ corps, donnees, etat }) {
    const lecture = await donnees('noms');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Noms indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const s = await etat('noms', { schema: 1, genre: 'hasard', historique: [] });
    const v = () => s.valeur;
    let seulementRetenus = false;

    const nomComplet = e => `${e.prenom} ${e.famille}`;
    const retenus = () => new Set(v().historique.filter(e => e.retenu).map(nomComplet));
    const courant = () => v().historique[v().historique.length - 1];

    // Tire sans redonner un nom retenu ni le même prénom que juste avant.
    function prenom(genre, eviter) {
      const liste = d.prenoms[genre === 'm' ? 'masculins' : 'feminins'];
      const possibles = liste.filter(x => x !== eviter);
      return auHasard(possibles.length ? possibles : liste);
    }
    function famille(genre, eviter) {
      const formes = d.familles.map(f => genre === 'm' ? f.masculin : f.feminin);
      const possibles = formes.filter(x => x !== eviter);
      return auHasard(possibles.length ? possibles : formes);
    }
    function composer(genre, garderPrenom, garderFamille) {
      const deja = retenus();
      for (let i = 0; i < 30; i++) {
        const e = { prenom: garderPrenom || prenom(genre, courant()?.prenom), famille: garderFamille || famille(genre, courant()?.famille) };
        if (!deja.has(nomComplet(e))) return e;
      }
      return { prenom: garderPrenom || prenom(genre), famille: garderFamille || famille(genre) };
    }

    function tirer() {
      const genre = v().genre === 'hasard' ? auHasard(['m', 'f']) : v().genre;
      v().historique.push({ id: identifiant(), quand: new Date().toISOString(), genre, ...composer(genre), retenu: false, note: '' });
      if (v().historique.length > HISTORIQUE_MAX) {
        const trop = v().historique.length - HISTORIQUE_MAX;
        const iRetire = v().historique.findIndex(e => !e.retenu);
        if (trop > 0 && iRetire >= 0) v().historique.splice(iRetire, 1);
      }
      s.enregistrer(0);
      rendre();
    }

    // Relancer une partie : remplace le dernier tirage tant qu'il n'est pas retenu, sinon en crée un nouveau.
    function relancer(partie) {
      const c = courant();
      if (!c) return tirer();
      const e = composer(c.genre, partie === 'famille' ? c.prenom : null, partie === 'prenom' ? c.famille : null);
      if (c.retenu) v().historique.push({ id: identifiant(), quand: new Date().toISOString(), genre: c.genre, ...e, retenu: false, note: '' });
      else Object.assign(c, e, { quand: new Date().toISOString() });
      s.enregistrer(0);
      rendre();
    }

    function basculerRetenu(e) {
      e.retenu = !e.retenu;
      s.enregistrer(0);
      rendre();
    }

    function copier(texte, btn) {
      navigator.clipboard?.writeText(texte).then(() => {
        btn.replaceChildren(icone('lu-check'));
        setTimeout(() => btn.replaceChildren(icone('lu-copy')), 1200);
      }).catch(() => {});
    }

    function vueResultat() {
      const c = courant();
      if (!c) return h('div', { class: 'bn-carte cm-nom cm-nom--vide' }, h('p', { class: 'ui cm-sourdine' }, 'Choisissez un genre, puis tirez un nom.'));
      const btnCopier = bouton('', { icone: 'lu-copy', titre: 'Copier le nom', classe: 'bn-btn--s bn-btn--fantome', onclick: e => copier(nomComplet(c), e.currentTarget) });
      return h('div', { class: 'bn-carte cm-nom', 'aria-live': 'polite' },
        h('div', { class: 'cm-fiche__tete' },
          h('span', { class: 'surtitre' }, GENRES[c.genre]),
          h('div', { class: 'bn-groupe' }, c.retenu ? badge('Retenu', 'brume', 'epingle') : null, btnCopier)),
        h('p', { class: 'cm-nom__texte' }, nomComplet(c)),
        h('div', { class: 'bn-groupe' },
          bouton('Autre prénom', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', onclick: () => relancer('prenom') }),
          bouton('Autre nom', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', onclick: () => relancer('famille') }),
          bouton(c.retenu ? 'Oublier' : 'Retenir', { classe: 'bn-btn--s', icone: 'epingle', 'aria-pressed': String(!!c.retenu), onclick: () => basculerRetenu(c) })),
        c.retenu ? h('label', { class: 'bn-champ' },
          h('span', { class: 'bn-champ__label' }, 'Pour qui ?'),
          h('input', { class: 'bn-input', value: c.note || '', placeholder: 'L\'aubergiste du gué, un chasseur…', oninput: e => { c.note = e.target.value; s.enregistrer(800); } })) : null);
    }

    function vueHistorique() {
      const liste = [...v().historique].reverse().filter(e => !seulementRetenus || e.retenu);
      const nbRetenus = v().historique.filter(e => e.retenu).length;
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'cm-fiche__tete' },
          h('p', { class: 'etiquette cm-section__titre' }, icone('livre', 'bn-icone--s'), `Historique (${v().historique.length})`),
          h('label', { class: 'cm-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: seulementRetenus, onchange: e => { seulementRetenus = e.target.checked; rendre(); } }), `Retenus seulement (${nbRetenus})`)),
        liste.length ? h('ol', { class: 'cm-journal' }, liste.map(e => h('li', { class: 'cm-nom-ligne' },
          h('span', { class: 'cm-nom-ligne__nom' }, nomComplet(e)),
          e.note ? h('span', { class: 'ui-s cm-sourdine cm-nom-ligne__note' }, e.note) : null,
          h('span', { class: 'ui-s cm-sourdine' }, heure(e.quand)),
          bouton('', { icone: 'epingle', titre: e.retenu ? `Oublier ${nomComplet(e)}` : `Retenir ${nomComplet(e)}`, classe: 'bn-btn--s bn-btn--fantome' + (e.retenu ? ' cm-actif' : ''), 'aria-pressed': String(!!e.retenu), onclick: () => basculerRetenu(e) }),
          bouton('', { icone: 'lu-x', titre: `Effacer ${nomComplet(e)}`, classe: 'bn-btn--s bn-btn--fantome', onclick: () => { v().historique = v().historique.filter(x => x.id !== e.id); s.enregistrer(0); rendre(); } }))))
          : h('p', { class: 'ui-s cm-sourdine' }, seulementRetenus ? 'Aucun nom retenu.' : 'Aucun nom tiré pour l\'instant.'),
        v().historique.some(e => !e.retenu) ? h('div', { class: 'bn-groupe' }, bouton('Effacer les non retenus', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-trash-2', onclick: () => {
          if (!confirm('Effacer de l\'historique tous les noms non retenus ?')) return;
          v().historique = v().historique.filter(e => e.retenu); s.enregistrer(0); rendre();
        } })) : null);
    }

    function rendre() {
      corps.replaceChildren(
        h('div', { class: 'cm-contexte' },
          bascule('Genre', [['m', 'Masculin'], ['f', 'Féminin'], ['hasard', 'Au hasard']], v().genre, g => { v().genre = g; s.enregistrer(); rendre(); }),
          bouton('Tirer un nom', { icone: 'd20', classe: 'bn-btn--primaire', onclick: tirer })),
        vueResultat(),
        vueHistorique(),
        (d.usage || d.notes?.length) ? h('details', { class: 'cm-repli' },
          h('summary', { class: 'etiquette' }, 'Usage et conventions'),
          h('div', { class: 'cm-pile' },
            d.usage ? h('p', { class: 'ui' }, d.usage) : null,
            (d.notes || []).map(n => h('p', { class: 'ui' }, n.texte, ' ', badge(n.source, n.source === 'MJ' ? 'sang' : 'ultra'))))) : null);
    }
    rendre();
    return {};
  },
};
