// Widget Rencontres aléatoires : test toutes les heures (procedure.intervalle_minutes), tirage jour / nuit
// (1d20+1d12, sous-tables : app/rencontres-moteur.js), fiche de la rencontre. Un test sans rencontre tient sur une ligne
// dans le widget ; une rencontre (et toute ligne du journal) s'ouvre dans une fenêtre flottante, et la babiole qu'elle fait
// trouver dans la sienne (app/babioles.js). Avec l'horloge, un rappel quand le créneau en cours a du brouillard, de la forte
// neige ou du verglas. Une rencontre de créatures tirée se lance dans le widget Combat ; l'onglet Hors tables liste les
// rencontres prévues et celles créées par le MJ (app/rencontres-mj.js). Données : data/rencontres-aleatoires.json
// (formats/rencontres-aleatoires.md). État : etat/rencontres.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, onglets, blocEcarts, heure, identifiant, flottant, flottantOuvert, lienFlottant, infobulle, ouvrirMenu } from '../ui.js';
import { lancer, estFixe } from '../des.js';
import { etatHorloge, horlogeEnService, tableRencontres, maintenant, libelleMoment, lecture as lectureHorloge, MOMENTS_LIBELLES, chargerCalendrier } from '../horloge.js';
import { rappelMeteo } from '../calendrier.js';
import { etatRencontres, moteurRencontres, chargerExternes, jetsDe, nomExterne, plageLigne, TERRAINS, modificateursDe, defaireRencontre } from '../rencontres-moteur.js';
import { fichesBabioles } from '../babioles.js';
import { outilsRencontresMj, noteCreature } from '../rencontres-mj.js';
import { reglage } from '../campagne.js';
import { derouleSurLeTableau, voirPiste } from '../trame.js';

const TYPES = {
  creatures: { libelle: 'Créatures', couleur: 'sang', icone: 'crocs' },
  trouvaille: { libelle: 'Trouvaille', couleur: 'cierge', icone: 'oeil' },
  piege: { libelle: 'Piège', couleur: 'cierge', icone: 'lu-triangle-alert' },
};

// Contexte du tirage : les libellés dès qu'ils tiennent (demande du MJ, 2026-10-23), deux lignes au plus. Paliers essayés
// dans l'ordre : [ligne de la fenêtre de 12 h, jour et nuit en icônes, terrain en icônes] ; tout en toutes lettres d'abord,
// puis la fenêtre en seconde ligne, puis jour et nuit en icônes, puis le terrain aussi (la fenêtre revient en première
// ligne). Rien ne tient : la seconde ligne passe à la ligne. Mesuré à chaque changement de largeur. Rend el.
const PALIERS = [[1, false, false], [2, false, false], [2, true, false], [1, true, true], [2, true, true]];
function adapterContexte(el, ligne1, ligne2, plafond) {
  const tient = l => l.scrollWidth <= l.clientWidth;
  const essayer = () => {
    if (!el.isConnected || !el.clientWidth) return;
    el.classList.remove('est-serre');
    for (const [ligne, moment, terrain] of PALIERS) {
      (ligne === 1 ? ligne1 : ligne2).append(plafond);
      el.classList.toggle('cm-icones-moment', moment);
      el.classList.toggle('cm-icones-terrain', terrain);
      if (tient(ligne1) && tient(ligne2)) return;
    }
    el.classList.add('est-serre');
  };
  new ResizeObserver(essayer).observe(el);
  document.fonts?.ready.then(() => requestAnimationFrame(essayer));   // les libellés changent de largeur avec la police
  return el;
}

export default {
  type: 'rencontres',
  requiert: 'rencontres-aleatoires',
  titre: 'Rencontres',
  icone: 'loup',
  description: 'Test de rencontre à chaque heure de voyage, tirage sur les tables de jour et de nuit, fiche prête à jouer, journal et suivis.',
  taille: { w: 5, h: 19 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, donnees, etat, campagne, dialogue }) {
    const lecture = await donnees('rencontres-aleatoires');
    if (lecture.statut !== 'ok') {
      corps.append(alerte('sang', 'lu-database', 'Données des rencontres illisibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const s = await etatRencontres(etat);
    const moteur = moteurRencontres(d, s, await chargerExternes(d, donnees, etat));
    const { proc, fiches, tables, tableDe, quantite } = moteur;
    // Fiches des babioles tirées par une rencontre (tirage_externe), partagées avec le widget Babioles.
    const fb = moteur.externes.babioles ? await fichesBabioles({ donnees, etat, dialogue }) : null;
    // 60 -> « 1 h », 30 -> « 30 min », 90 -> « 1 h 30 »
    const intervalle = (m => m % 60 ? (m > 60 ? `${Math.floor(m / 60)} h ${m % 60}` : `${m} min`) : `${m / 60} h`)(proc.intervalle_minutes);
    // Rencontres prévues et créées (onglet Hors tables), rencontres lancées depuis un tirage : app/rencontres-mj.js.
    const R = await outilsRencontresMj({ donnees, etat, dialogue });
    const sousOuvertes = new Set();   // lignes de l'onglet Tables dont la sous-table est dépliée (lignesDe)
    const v = () => s.valeur;
    const lib = campagne.libelle;
    const sHorloge = await etatHorloge(etat);
    const { meteo } = await chargerCalendrier(donnees);   // rappel du brouillard, de la forte neige ou du verglas
    // Événements de campagne (data/evenements.json, formats/evenements.md ; demande du MJ, 2026-10-25) : un bouton après
    // « Rencontre », si la campagne les active (fenêtre Campagne) et que le fichier existe ; sinon rien.
    const evenements = reglage('evenements', false) ? await donnees('evenements').then(x => (x.statut === 'ok' ? x.donnees.evenements || [] : [])) : [];
    const evenementDe = e => evenements.find(x => x.id === e.evenement?.id) || null;
    let ongletActif = 'tirage';
    let affichee = null;   // entrée du journal à montrer dans l'onglet Tirage (cm:voir-rencontre), sinon la dernière

    // Tant que le widget Horloge est sur le tableau, la table de jour ou de nuit suit l'heure de jeu (nuit : après le crépuscule,
    // avant l'aube). Le MJ peut la forcer après confirmation (choisirMoment) : elle ne bouge plus jusqu'au prochain changement.
    let momentHorloge = null;
    function suivreHorloge() {
      if (!horlogeEnService()) { momentHorloge = null; return false; }
      const m = tableRencontres(sHorloge.valeur);
      if (m === momentHorloge) return false;
      momentHorloge = m;
      if (v().contexte.moment === m) return false;
      v().contexte.moment = m;
      s.enregistrer();
      return true;
    }
    suivreHorloge();
    let momentTables = v().contexte.moment;

    // Jour ou nuit choisi à la main : contre l'horloge, le MJ confirme d'abord (il fait jour ou nuit à l'heure de jeu).
    function choisirMoment(val, appliquer) {
      if (val === v().contexte.moment) return;
      const selonHorloge = horlogeEnService() ? tableRencontres(sHorloge.valeur) : null;
      if (!selonHorloge || selonHorloge === val) { appliquer(); return; }
      const l = lectureHorloge(sHorloge.valeur);
      const moment = MOMENTS_LIBELLES[l.moment];
      let dlg;
      dlg = dialogue('Rencontres', val === 'nuit' ? 'Tirer sur la table de nuit ?' : 'Tirer sur la table de jour ?',
        alerte('cierge', 'lu-triangle-alert', `L'horloge dit : ${moment}, ${libelleMoment(sHorloge.valeur)}`,
          `Selon l'horloge, les rencontres se tirent sur la table de ${selonHorloge}. Forcer la table de ${val} ? Elle restera choisie jusqu'au prochain passage du jour à la nuit (ou l'inverse).`),
        h('div', { class: 'bn-groupe' },
          bouton(`Forcer la table de ${val}`, { classe: 'bn-btn--primaire', icone: val === 'nuit' ? 'lune' : 'soleil', onclick: () => { dlg.close(); appliquer(); } }),
          bouton(`Garder la table de ${selonHorloge}`, { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    }

    // ───── Tirage (app/rencontres-moteur.js) ─────
    // L'heure de jeu, quand l'horloge sert : notée sur l'entrée, et le plafond de 12 h se compte en temps de jeu.
    const horlogeActuelle = () => (horlogeEnService() ? maintenant(sHorloge.valeur) : null);
    // Une rencontre qui a lieu s'ouvre dans sa fenêtre ; une rencontre qui fait trouver une babiole n'ouvre que la fenêtre
    // de la babiole, pour la donner (sa ligne du journal ouvre la fiche de la rencontre). Un test raté reste sur la ligne
    // du widget.
    // Un tirage pas noté (dé d'une ligne, « Rencontre » : décision du MJ, 2026-10-25) reste dans la page : sa fenêtre et la ligne
    // de résultat le montrent ; il n'entre au journal que lancé ou noté (moteur.accepter).
    const propositions = new Map();   // id -> entrée hors du journal
    const trouver = id => v().journal.find(x => x.id === id) || propositions.get(id) || null;
    const apres = e => {
      if (!e?.id) return;
      if (!v().journal.includes(e)) { propositions.set(e.id, e); affichee = e.id; rendre(); }
      if (moteur.sortie(e) && (e.proposee || !ouvrirBabioleDe(e))) ouvrirRencontre(e);
    };
    const tester = () => { affichee = null; apres(moteur.tester(v().contexte, horlogeActuelle())); };
    const tirerDirect = () => { affichee = null; apres(moteur.tirerDirect(v().contexte, horlogeActuelle())); };
    // « Tirer cette ligne » (onglet Tables) : la table principale donne le moment ; une sous-table, celui de l'onglet.
    const momentDe = t => t.id === proc.tirage.tables.nuit ? 'nuit' : t.id === proc.tirage.tables.jour ? 'jour' : momentTables;
    const tirerLigne = (t, l) => { affichee = null; apres(moteur.tirerLigneChoisie({ ...v().contexte, moment: momentDe(t) }, t.id, l.jet, horlogeActuelle())); };
    // La babiole tirée par une rencontre (tirage_externe dans babioles.json) : sa fiche, comme dans le widget Babioles.
    const babioleDe = e => (e.tirage_externe?.jeu === 'babioles' && fb?.parId.get(e.tirage_externe.id)?.l) || null;
    // Ouvre sa fenêtre (note proposée pour « Donner » : où elle a été trouvée) ; renvoie faux s'il n'y en a pas.
    const ouvrirBabioleDe = e => {
      const l = babioleDe(e);
      if (l) fb.ouvrir(l, { jet: e.tirage_externe.jet, noteDon: `Trouvée lors d'une rencontre aléatoire${e.horloge ? ` (${libelleMoment(e.horloge)})` : ''}.` });
      return !!l;
    };

    // Fenêtre d'une ligne du journal : sa fiche. Redessinée quand le widget l'est (quantité relancée, suivi noté…), sauf
    // pendant qu'on y tape une note ; fermée si la ligne est effacée.
    const titreRencontre = e => (e.type === 'espions' ? 'Espions' : e.type === 'evenement' ? e.evenement?.nom || 'Événement' : e.test && !e.test.reussi ? 'Rien ne se passe'
      : e.aucune ? 'Pas de rencontre' : fiches.get(e.rencontre)?.nom || e.rencontre);
    const ouvertes = new Set();   // id des lignes dont la fenêtre a été ouverte
    const surtitreRencontre = e => [e.moment === 'nuit' ? 'Nuit' : 'Jour', e.horloge ? libelleMoment(e.horloge) : heure(e.quand)].join(' · ');
    function ouvrirRencontre(e) {
      ouvertes.add(e.id);
      flottant('rencontre:' + e.id, { surtitre: surtitreRencontre(e), titre: titreRencontre(e), largeur: 520, contenu: ficheRencontre(e, { fenetre: true }) });
    }
    // Redessinées sur place, sans passer devant les autres fenêtres (celle de la rencontre lancée, par exemple).
    function rafraichirRencontres() {
      for (const id of [...ouvertes]) {
        const f = flottantOuvert('rencontre:' + id);
        const e = trouver(id);
        if (!f || !e) { f?.fermer(); ouvertes.delete(id); continue; }
        if (!(f.el.contains(document.activeElement) && document.activeElement.tagName === 'TEXTAREA')) f.maj(ficheRencontre(e, { fenetre: true }), titreRencontre(e), surtitreRencontre(e));
      }
    }

    // ───── Rendu d'une rencontre ─────

    // Table d'un jet : « Jour » ou « Nuit » pour une table principale, sinon le nom de la sous-table (« Squelettes »).
    const nomTable = (id, e) => id === proc.tirage.tables.jour ? 'Jour' : id === proc.tirage.tables.nuit ? 'Nuit'
      : tables.get(id)?.nom || id || (e?.moment === 'nuit' ? 'Nuit' : 'Jour');
    const nomTableExterne = x => (moteur.externes[x.jeu]?.donnees?.tables || []).find(t => t.id === x.table)?.nom || x.table;

    // Un jet de la chaîne : « Jour 1d20+1d12 : 15 + 8 = 23 », « Squelettes 1d10 : 4 retiré, relancé : 6 »,
    // « Jour : ligne 13-15 choisie » (« Tirer cette ligne »).
    function texteJet(t, e) {
      const nom = nomTable(t.table, e);
      if (t.force) {
        const tb = tables.get(t.table), l = tb && moteur.ligneDe(tb, t.total);
        return `${nom} : ligne ${l ? plageLigne(l) : t.total} choisie`;
      }
      const relances = (t.relances || []).map(r => `${r.total} retiré`).join(', ');
      const valeur = t.total == null ? 'tout est retiré' : `${t.detail || t.total}${String(t.detail).includes('+') ? ' = ' + t.total : ''}`;
      return `${nom} ${t.formule} : ${relances ? `${relances}, relancé : ` : ''}${valeur}`;
    }

    // Le test, puis les jets enchaînés : « Test 1d20 : 19 ≥ 18 (route) · Jour 1d20+1d12 : 23 → Squelettes 1d10 : 6 ».
    function texteJets(e) {
      const morceaux = [];
      if (e.test) morceaux.push(`Test ${proc.test.de} : ${e.test.jet} ${e.test.reussi ? '≥' : '<'} ${e.test.seuil} (${e.terrain === 'route' ? 'route' : 'nature'})`);
      const chaine = jetsDe(e).map(t => texteJet(t, e));
      const x = e.tirage_externe;
      if (x?.jet != null) chaine.push(`${nomTableExterne(x)} ${x.formule} : ${x.jet}`);
      if (chaine.length) morceaux.push(chaine.join(' → '));
      return morceaux.join(' · ');
    }
    const ligneJets = e => h('p', { class: 'des cm-jets' }, icone('d20', 'bn-icone--s'), texteJets(e));

    // Ce qu'on fait d'une rencontre sortie au tirage (décision du MJ, 2026-10-25). Proposée : « Lancer » ouvre sa préparation
    // (monstres reliés à leur nombre tiré, difficulté), d'où « Lancer le combat » la note au journal et la charge dans Combat ;
    // sans créatures (trouvaille, piège, babiole), « Noter » ; celle d'un test, « Écarter » (le test reste noté). Notée
    // (avant le 2026-10-25, ou lancée) : sa rencontre, gardée dans etat/rencontres-mj.json.
    function boutonsCombat(e, f) {
      if (e.sans_effet || e.ecartee) return null;
      const creatures = f.type === 'creatures' && e.quantites?.length;
      if (e.proposee) {
        const accepter = horloge => moteur.accepter(e, horloge ?? horlogeActuelle());
        return h('div', { class: 'cm-pile' },
          h('p', { class: 'ui-s cm-sourdine' }, creatures ? 'Pas encore notée : elle compte (journal, plafond) quand le combat est lancé.' : 'Pas encore notée : elle compte (journal, plafond) quand vous la notez.'),
          h('div', { class: 'bn-groupe cm-fiche__combat' },
            creatures ? bouton('Lancer', { classe: 'bn-btn--s bn-btn--primaire', icone: 'epee', titre: 'Sa préparation : monstres, nombres, difficulté ; puis « Lancer le combat »',
              onclick: () => R.depuisTirage(e, { jets: texteJets(e), accepter }) })
              : bouton('Noter', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check', titre: 'Elle a lieu : notée au journal, comptée dans le plafond',
                onclick: () => { accepter(); propositions.delete(e.id); rendre(); ouvrirBabioleDe(e); } }),
            e.test ? bouton('Écarter', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'Elle n\'a pas lieu : le test reste noté, la rencontre ne compte pas',
              onclick: () => { moteur.ecarter(e); flottantOuvert('rencontre:' + e.id)?.fermer(); } }) : null));
      }
      if (!creatures) return null;
      const deja = R.duTirage(e.id);
      const vue = deja && R.vueDe(deja.id);
      return h('div', { class: 'bn-groupe cm-fiche__combat' },
        vue ? bouton('Ouvrir la rencontre', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-swords', titre: 'Sa préparation : monstres, nombres, noms', onclick: () => R.ouvrir(vue.id) })
          : bouton('Lancer', { classe: 'bn-btn--s bn-btn--primaire', icone: 'epee', titre: 'Sa préparation : monstres, nombres, difficulté ; puis « Lancer le combat »',
            onclick: () => R.depuisTirage(e, { jets: texteJets(e) }) }),
        vue && vue.statut !== 'a-jouer' ? badge(vue.statut === 'terminee' ? 'Terminée' : 'En cours', vue.statut === 'terminee' ? 'brume' : 'soleil', vue.statut === 'terminee' ? 'lu-check' : null) : null);
    }

    // L'objet tiré dans un autre fichier (une babiole) : son nom, qui ouvre sa fiche, le texte pour les joueurs, la note
    // du MJ repliée.
    function blocExterne(e) {
      const x = e.tirage_externe;
      if (!x) return null;
      if (x.absent || x.aucune) return alerte('cierge', 'lu-triangle-alert', 'Objet non tiré',
        x.absent ? `Table « ${x.table} » introuvable dans ${x.jeu}.json.` : `Plus rien à tirer dans « ${nomTableExterne(x)} » : tout est déjà donné ? Choisissez l'objet dans le widget Babioles.`);
      const l = babioleDe(e);
      return h('div', { class: 'bn-carte cm-objet-tire' },
        h('p', { class: 'etiquette cm-section__titre' }, icone(l ? 'lu-gift' : 'd20', 'bn-icone--s'), `${nomTableExterne(x)} · ${x.jet}`),
        l ? lienFlottant(h('button', { type: 'button', class: 'cm-lien-bouton cm-objet-tire__nom', title: 'Ouvrir la fiche de la babiole', onclick: () => ouvrirBabioleDe(e) }, nomExterne(x)), 'babiole:' + x.id)
          : h('p', { class: 'cm-objet-tire__nom' }, nomExterne(x)),
        x.nom?.trim() && x.texte?.trim() ? h('p', { class: 'texte' }, x.texte) : null,
        x.note_mj?.trim() ? h('details', { class: 'cm-babiole__mj' },
          h('summary', {}, badge('MJ', 'sang', 'lu-eye-off'), h('span', { class: 'ui-s' }, 'Secret : à ne pas montrer aux joueurs')),
          h('p', { class: 'texte' }, x.note_mj)) : null,
        l && fb.donnee(l) ? h('p', { class: 'ui-s cm-sourdine' }, fb.libelleDonnee(fb.donnee(l)) + '.') : null);
    }

    function listeCreatures(e) {
      if (!e.quantites?.length) return null;
      return h('ul', { class: 'cm-creatures' }, e.quantites.map((q, i) => h('li', {},
        h('span', { class: 'cm-creatures__nombre' }, q.total ?? q.formule),
        h('span', { class: 'cm-creatures__nom' }, q.nom),
        estFixe(q.formule) ? null : h('span', { class: 'des cm-sourdine' }, q.formule + (q.detail && q.detail.includes('+') ? ' · ' + q.detail : '')),
        estFixe(q.formule) || q.total === null ? null : bouton('', {
          icone: 'lu-refresh-cw', titre: `Relancer ${q.formule}`, classe: 'bn-btn--s bn-btn--fantome',
          onclick: () => { e.quantites[i] = quantite({ nom: q.nom, nom_en: q.nom_en, note_mj: q.note_mj, quantite: q.formule }); s.enregistrer(0); rendre(); },
        }),
        noteCreature(R.noteMj(q)))));   // note du MJ sur le profil D&D Beyond (note_mj des données, retrouvée par le nom)
    }

    function section(titre, ic, ...contenu) {
      const c = contenu.flat().filter(Boolean);
      if (!c.length) return null;
      return h('div', { class: 'cm-section' }, h('p', { class: 'etiquette cm-section__titre' }, ic ? icone(ic, 'bn-icone--s') : null, titre), ...c);
    }

    // fenetre : dans sa fenêtre flottante, dont le titre porte déjà le nom de la rencontre.
    function ficheRencontre(e, { fenetre = false } = {}) {
      // Ligne de l'ancien bouton Espions (retiré le 2026-10-24) : gardée dans le journal.
      if (e.type === 'espions') return h('p', { class: 'ui cm-sourdine' }, 'Des espions observent les héros (ligne notée par l\'ancien bouton Espions).');
      if (e.type === 'evenement') {
        const ev = evenementDe(e);
        return h('div', { class: 'cm-pile' }, h('p', { class: 'ui-s cm-sourdine' }, 'Événement de campagne ajouté comme rencontre : il compte dans le plafond.'),
          ev ? vueEvenement(ev) : h('p', { class: 'ui cm-sourdine' }, 'Cet événement n\'est plus dans data/evenements.json.'));
      }
      if (e.test && !e.test.reussi) {
        return h('div', { class: 'cm-rien' }, ligneJets(e), h('p', { class: 'titre-m cm-sourdine' }, 'Rien ne se passe'));
      }
      if (e.aucune) {
        const dernier = jetsDe(e).at(-1);
        return h('div', { class: 'cm-rien' }, ligneJets(e), h('p', { class: 'titre-m cm-sourdine' }, 'Pas de rencontre'),
          h('p', { class: 'ui-s cm-sourdine' }, !dernier || dernier.total == null ? 'Toutes les lignes tirées sont retirées des tables.'
            : dernier.force ? 'Tout ce que donne cette ligne est retiré des tables.' : `Aucune ligne de la table pour ${dernier.total}.`));
      }
      const f = fiches.get(e.rencontre);
      if (!f) return alerte('sang', 'lu-database', 'Rencontre inconnue', `« ${e.rencontre} » n'est plus dans data/rencontres-aleatoires.json.`);
      const t = TYPES[f.type] || TYPES.creatures;
      const suiviOuvert = v().suivis.some(x => x.rencontre === f.id && !x.resolu);
      return h('article', { class: 'cm-fiche' },
        ligneJets(e),
        h('div', { class: 'cm-fiche__tete' },
          fenetre ? h('span') : h('h3', { class: 'titre-m' }, f.nom),
          h('div', { class: 'bn-groupe cm-badges' },
            badge(t.libelle, t.couleur, t.icone),
            badge(e.moment === 'nuit' ? 'Nuit' : 'Jour', e.moment === 'nuit' ? 'ultra' : 'soleil', e.moment === 'nuit' ? 'lune' : 'soleil'),
            e.numero > 1 ? badge(`${e.numero}e rencontre`, 'ultra') : null,
            f.unique ? badge('Unique', null) : null)),
        // Unique sortie : le MJ dit s'il la cache des tables (marquée rencontrée) ou la garde ; la question reste jusque-là.
        f.unique && moteur.aLieu(e) && !moteur.rencontree(f.id) && !e.unique_gardee
          ? alerte('cierge', 'lu-eye-off', 'Rencontre unique : la cacher des tables ?',
            'Cachée, elle ne sort plus et reste grisée dans l\'onglet Tables, d\'où vous pouvez la faire revenir.', ' ',
            h('span', { class: 'bn-groupe cm-question-unique' },
              bouton('Cacher · rencontrée', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-eye-off', onclick: () => marquer(f.id, true) }),
              bouton('La garder', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { e.unique_gardee = true; s.enregistrer(0); rendre(); } })))
          : null,
        e.sans_effet ? alerte('brume', 'lu-info', 'Pas de rencontre : le groupe est à l\'arrêt',
          'Cette rencontre n\'a lieu qu\'en voyage. Elle ne compte pas dans le plafond.') : null,
        // Un modificateur coché au tirage (un guide…) qui neutralise cette rencontre.
        ...(proc.modificateurs || []).filter(m => (f.neutralise_par || []).includes(m.id) && modificateursDe(e).includes(m.id))
          .map(m => alerte('brume', 'lu-check', 'Pas de menace', m.regle)),
        listeCreatures(e),
        boutonsCombat(e, f),
        blocExterne(e),
        h('p', { class: 'texte' }, f.comment_jouer),
        e.variante ? h('p', { class: 'cm-variante' }, badge('Suggestion', 'ultra'), ' ', e.variante,
          f.variantes.length > 1 ? h('span', { class: 'cm-sourdine' }, ` (ou : ${f.variantes.filter(x => x !== e.variante).join(' ; ')})`) : null) : null,
        e.sous_table ? h('div', { class: 'bn-carte cm-sous-table' },
          h('p', { class: 'des' }, icone('d20', 'bn-icone--s'), ` ${e.sous_table.formule} : ${e.sous_table.total}`),
          h('p', { class: 'texte' }, e.sous_table.resultat || 'Aucune ligne pour ce jet.'),
          h('details', {}, h('summary', { class: 'etiquette' }, 'Toute la table'),
            h('ul', { class: 'ui-s' }, fiches.get(e.rencontre).sous_table.lignes.map(l => h('li', {}, h('b', {}, l.jet), ' ', l.resultat))))) : null,
        section('Tests', 'oeil', f.tests.map(x => h('p', { class: 'ui' }, x))),
        section('Profil', 'epee', f.profil ? h('p', { class: 'ui' }, f.profil) : null),
        section('Évitable', 'brume', f.evitable ? h('p', { class: 'ui' }, f.evitable) : null),
        section('Effets', 'lu-info', (f.effets || []).map(x => h('p', { class: 'ui' }, x))),
        section('Renfort possible', 'crane', (f.creatures_secondaires || []).map(c => {
          const j = estFixe(c.quantite) ? null : lancer(c.quantite);
          return h('p', { class: 'ui' }, h('b', {}, c.declencheur), ` ${c.quantite} ${c.nom}`,
            j ? h('span', { class: 'des cm-sourdine' }, ` (jet indicatif : ${j.total})`) : null, noteCreature(R.noteMj(c)));
        })),
        f.suivi ? alerte('', 'corbeau', 'Suivi', f.suivi, ' ',
          suiviOuvert ? badge('Noté', 'brume', 'lu-check') : bouton('Noter le suivi', {
            classe: 'bn-btn--s', icone: 'lu-plus',
            onclick: () => { v().suivis.push({ id: identifiant(), rencontre: f.id, texte: f.suivi, depuis: new Date().toISOString(), resolu: false }); s.enregistrer(0); rendre(); },
          })) : null,
        f.unique && moteur.rencontree(f.id) ? alerte('cierge', 'lu-info', 'Rencontrée : elle ne sort plus',
          'Décochez « Rencontrée » pour la remettre dans les tables.', ' ', caseRencontree(f.id))
          : f.unique && !moteur.cachee(f.id) && (e.unique_gardee || e.sans_effet) ? alerte('cierge', 'lu-info', 'Rencontre unique',
            'Cochez « Rencontrée » une fois jouée : elle ne sortira plus.', ' ', caseRencontree(f.id))
          : f.retirer_si || moteur.cachee(f.id) ? alerte('cierge', 'lu-info', moteur.cachee(f.id) ? 'Cachée des tables' : 'Retrait', f.retirer_si || 'Elle ne sort plus au tirage.', ' ',
            moteur.cachee(f.id)
              ? bouton('Remettre dans les tables', { classe: 'bn-btn--s', icone: 'lu-eye', onclick: () => cacher(f.id, false) })
              : bouton('Cacher des tables', { classe: 'bn-btn--s', icone: 'lu-eye-off', onclick: () => cacher(f.id, true) })) : null,
        section('Renvois', 'epingle', f.renvois.length ? h('p', { class: 'ui-s' }, f.renvois.join(' · ')) : null),
        blocEcarts(f.ecarts, lib),
        h('p', { class: 'ui-s cm-sourdine' }, `${f.source}${f.pages_livre ? ', p. ' + f.pages_livre : ''}`),
        h('label', { class: 'bn-champ' },
          h('span', { class: 'bn-champ__label' }, 'Notes'),
          h('textarea', { class: 'bn-textarea cm-notes', rows: 2, placeholder: 'Ce qui s\'est passé…', oninput: ev => { e.note = ev.target.value; s.enregistrer(800); } }, e.note || '')));
    }

    // Cachée des tables (n'importe quelle rencontre : grisée, le dé est relancé s'il tombe dessus) ou remise.
    const cacher = (id, oui) => { moteur.cacher(id, oui); s.enregistrer(0); s.signaler(rendre); rendre(); };
    // Unique marquée rencontrée (et cachée), ou remise dans les tables.
    const marquer = (id, oui) => { moteur.marquerRencontree(id, oui); s.enregistrer(0); s.signaler(rendre); rendre(); };

    // Rencontre unique : la case « Rencontrée » la cache des tables ou l'y remet. Le MJ la coche quand sa fiche le lui
    // demande après un tirage, ou lui-même si elle a été jouée hors tirage.
    function caseRencontree(id) {
      return h('label', { class: 'cm-case cm-rencontree', title: 'Rencontre unique : cochée, elle ne sort plus au tirage (le dé est relancé). Décochez pour la remettre dans les tables.' },
        h('input', { type: 'checkbox', class: 'bn-case', checked: moteur.rencontree(id), onchange: ev => marquer(id, ev.target.checked) }), 'Rencontrée');
    }

    // ───── Onglets ─────

    // Jour et nuit enfoncés prennent leur couleur : jour lumineux (soleil), nuit violette (CSS, .cm-moment-*). Le libellé en
    // infobulle aussi : dans un widget étroit, les boutons du tirage n'ont plus que leur icône (CSS).
    function bascule(libelles, valeur, surChoix, classe = '') {
      return h('div', { class: ('bn-bascule ' + classe).trim(), role: 'group' }, libelles.map(([val, texte, ic]) => infobulle(h('button', {
        type: 'button', class: 'bn-btn bn-btn--s cm-moment-' + val, 'data-valeur': val, 'aria-pressed': String(valeur === val), 'aria-label': texte, onclick: () => surChoix(val),
      }, ic ? icone(ic) : null, h('span', {}, texte)), texte)));
    }

    // Case d'un modificateur de la procédure (un guide…) : contexte.modificateurs.<id>.
    function caseModificateur(m) {
      const el = h('label', { class: 'cm-case' }, h('input', {
        type: 'checkbox', class: 'bn-case', checked: !!v().contexte.modificateurs?.[m.id],
        onchange: e => { v().contexte.modificateurs = { ...(v().contexte.modificateurs || {}), [m.id]: e.target.checked }; s.enregistrer(); rendre(); },
      }), m.court || m.nom);
      return infobulle(el, `${m.condition ? `${m.condition} ` : ''}${m.regle}`, { titre: m.nom });
    }

    function caseCtx(cle, texte, aide) {
      const el = h('label', { class: 'cm-case' }, h('input', {
        type: 'checkbox', class: 'bn-case', checked: !!v().contexte[cle],
        onchange: e => { v().contexte[cle] = e.target.checked; s.enregistrer(); rendre(); },
      }), texte);
      return aide ? infobulle(el, aide.texte, { titre: aide.titre }) : el;
    }

    function vueTirage() {
      const c = v().contexte;
      const changer = (cle, val) => { c[cle] = val; s.enregistrer(); s.signaler(rendre); rendre(); };
      const plafond = proc.plafond.rencontres;
      const hj = horlogeActuelle();
      const nb = moteur.rencontresDansFenetre(hj);
      const atteint = moteur.plafondAtteint(hj);
      const abri = c.terrain === 'abri';
      const derniere = (affichee && trouver(affichee)) || v().journal[v().journal.length - 1];
      const suivis = v().suivis.filter(x => !x.resolu);
      const debutFenetre = hj ? `sur les ${proc.plafond.fenetre_heures} dernières heures de jeu` : `depuis ${heure(v().fenetre.debut)}`;
      const comptePlafond = `${nb} rencontre${nb > 1 ? 's' : ''} sur ${plafond} ${debutFenetre}`;
      // Le contexte en deux lignes au plus (retours du MJ sur petit écran, 2026-10-23) : jour ou nuit, terrain et plafond ;
      // puis les cases, l'heure de jeu et le rappel météo. Les libellés dès qu'ils tiennent (adapterContexte).
      // Plafond de rencontres : « 12 h » et sa jauge, le compte et la règle en infobulle.
      const elPlafond = infobulle(h('span', { class: 'cm-plafond' },
        h('span', { class: 'etiquette' }, `${proc.plafond.fenetre_heures} h`),
        h('span', { class: 'cm-jauge', role: 'img', 'aria-label': comptePlafond },
          Array.from({ length: plafond }, (_, i) => h('span', { class: 'cm-jauge__pas' + (i < nb ? ' est-plein' : '') }))),
        hj ? null : bouton('', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: `Nouvelle fenêtre : ${proc.plafond.fenetre_heures} heures se sont écoulées`,
          onclick: () => { v().fenetre = { debut: new Date().toISOString(), rencontres: 0 }; s.enregistrer(0); rendre(); } })),
      `${comptePlafond}. ${proc.plafond.regle}`, { titre: `Fenêtre de ${proc.plafond.fenetre_heures} h`, ton: atteint ? 'cierge' : undefined });
      const enMarche = [...fiches.values()].filter(f => f.en_voyage_seulement).map(f => f.nom);
      const ligne1 = h('div', { class: 'cm-contexte cm-tirage-contexte__ligne' },
        bascule([['jour', 'Jour', 'soleil'], ['nuit', 'Nuit', 'lune']], c.moment, val => choisirMoment(val, () => changer('moment', val)), 'cm-bascule-moment'),
        bascule(TERRAINS, c.terrain, val => changer('terrain', val), 'cm-bascule-terrain'),
        elPlafond);
      const ligne2 = h('div', { class: 'cm-contexte cm-tirage-contexte__ligne' },
        (proc.modificateurs || []).map(caseModificateur),
        caseCtx('a_l_arret', 'À l\'arrêt', { titre: 'À l\'arrêt', texte: `Le groupe ne voyage pas (camp, attente). Certaines rencontres n'arrivent qu'en marche : à l'arrêt, elles sont sans effet et ne comptent pas dans le plafond${enMarche.length ? ` (${enMarche.join(', ')})` : ''}. Le temps qui passe dans l'Horloge en tient compte de lui-même : un repos à l'arrêt, un trajet en marche.` }),
        horlogeEnService() ? h('span', { class: 'ui-s cm-sourdine', title: 'Jour ou nuit suit l\'horloge : table de nuit après le crépuscule et avant l\'aube' },
          icone('sablier', 'bn-icone--s'), ` ${libelleMoment(sHorloge.valeur)}`) : null,
        // Brouillard (visibilité), forte neige ou verglas (terrain difficile, au choix du MJ) : un rappel, rien d'automatique.
        horlogeEnService() && meteo ? (l => rappelMeteo(meteo, l.meteo, { nuit: l.moment === 'nuit' }))(lectureHorloge(sHorloge.valeur)) : null);
      return h('div', { class: 'cm-pile' },
        adapterContexte(h('div', { class: 'cm-tirage-contexte' }, ligne1, ligne2), ligne1, ligne2, elPlafond),
        suivis.map(x => alerte('', 'corbeau', `Suivi · ${fiches.get(x.rencontre)?.nom || x.rencontre}`, x.texte, ' ',
          bouton('Résolu', { classe: 'bn-btn--s', icone: 'lu-check', onclick: () => { x.resolu = true; s.enregistrer(0); rendre(); } }))),
        atteint ? alerte('cierge', 'sablier', 'Plafond atteint', proc.plafond.regle) : null,
        // Tester, tirer une rencontre : sur une ligne (resserrés dans un widget étroit, CSS) ; l'aide est au survol.
        h('div', { class: 'cm-tirage-actions' },
          bouton(`Tester · ${intervalle}`, { icone: 'd20', classe: 'bn-btn--primaire', disabled: atteint || abri, onclick: tester,
            titre: abri ? 'À l\'abri (en ville, à l\'intérieur) : pas de test quand le temps passe' : `${proc.test.de} : rencontre sur ${proc.test.seuil[c.terrain]} ou plus. ${proc.test.regle}` }),
          bouton('Rencontre', { icone: 'loup', onclick: tirerDirect, titre: 'Tirer une rencontre sans test, directement sur la table' }),
          boutonEvenements()),
        // La règle des modificateurs cochés qui changent le tirage dans ce terrain (un guide en pleine nature).
        (proc.modificateurs || []).filter(m => c.modificateurs?.[m.id] && m.tirage && (!m.terrains || m.terrains.includes(c.terrain)))
          .map(m => h('p', { class: 'ui-s cm-sourdine' }, m.regle)),
        // Le dernier résultat sur une ligne, toujours de la même hauteur (pas de défilement) ; un clic ouvre sa fiche.
        h('div', { 'aria-live': 'polite' }, derniere ? ligneResultat(derniere) : h('p', { class: 'cm-resultat-ligne cm-sourdine' }, 'Aucun test pour l\'instant.')));
    }

    // ───── Événements de campagne ─────
    // Un bouton : celui de l'événement s'il n'y en a qu'un, sinon « Événements » et un menu. Sa fenêtre dit l'événement, ce que
    // le MJ doit faire, puis « Ajouter comme rencontre » (il compte dans le plafond) ou « Passer ».
    function boutonEvenements() {
      if (!evenements.length) return null;
      if (evenements.length === 1) {
        const ev = evenements[0];
        return bouton(ev.court || ev.nom, { icone: ev.icone || 'lu-sparkles', onclick: () => ouvrirEvenement(ev), titre: ev.resume || ev.nom });
      }
      return bouton('Événements', { icone: 'lu-sparkles', titre: 'Les événements de la campagne',
        onclick: ev => ouvrirMenu(ev.currentTarget, evenements.map(x => [x.nom, x.resume || '', () => ouvrirEvenement(x)]), 'Événements de la campagne') });
    }
    function vueEvenement(ev) {
      const piste = ev.piste && derouleSurLeTableau() ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => voirPiste(ev.piste) }, 'Voir la piste dans le Déroulé') : null;
      return h('div', { class: 'cm-pile' },
        ev.resume ? h('p', { class: 'ui-l' }, ev.resume) : null,
        ev.texte ? h('p', { class: 'texte' }, ev.texte) : null,
        (ev.sections || []).map(x => section(x.titre, x.icone || null,
          x.texte ? h('p', { class: 'ui' }, x.texte) : null,
          x.points?.length ? h('ul', { class: 'cm-liste ui' }, x.points.map(p => h('li', {}, p))) : null)),
        ev.mj ? h('div', { class: 'cm-pour-mj' }, h('p', { class: 'etiquette cm-pour-mj__titre' }, icone('lu-eye-off', 'bn-icone--s'), 'Pour le MJ'), h('p', { class: 'ui-s' }, ev.mj)) : null,
        piste);
    }
    function ouvrirEvenement(ev) {
      const hj = horlogeActuelle();
      const atteint = moteur.plafondAtteint(hj);
      let dlg;
      dlg = dialogue('Événement de campagne', ev.nom, h('div', { class: 'cm-pile' }, vueEvenement(ev),
        atteint ? alerte('cierge', 'sablier', 'Plafond atteint', `${proc.plafond.regle} L'ajouter comme rencontre le dépasse.`) : null),
      h('div', { class: 'bn-groupe' },
        bouton('Ajouter comme rencontre', { classe: 'bn-btn--primaire', icone: 'lu-plus', titre: 'Noter l\'événement dans le journal : il compte dans le plafond de rencontres',
          onclick: () => { dlg.close(); affichee = null; moteur.ajouterEvenement(ev, v().contexte, hj); } }),
        bouton('Passer', { classe: 'bn-btn--fantome', titre: 'Ne rien noter', onclick: () => dlg.close() })));
    }

    function ligneResultat(e) {
      const aLieu = moteur.sortie(e);
      const quoi = e.test && !e.test.reussi ? `${moteur.resume(e)} : rien ne se passe` : moteur.resume(e);
      return lienFlottant(h('button', { type: 'button', class: 'cm-resultat-ligne cm-ouvre' + (aLieu ? ' est-rencontre' : ''), title: `Ouvrir la fiche : ${quoi}`, onclick: () => ouvrirRencontre(e) },
        icone(e.type === 'espions' ? 'oeil' : e.type === 'evenement' ? evenementDe(e)?.icone || 'lu-sparkles' : aLieu ? 'loup' : 'd20', 'bn-icone--s'),
        h('span', { class: 'cm-resultat-ligne__quand' }, e.horloge ? libelleMoment(e.horloge) : heure(e.quand)),
        h('span', { class: 'cm-resultat-ligne__quoi cm-ouvre__nom' }, quoi)), 'rencontre:' + e.id);
    }

    // Une option d'une ligne : la rencontre (barrée si elle est retirée ; case « Rencontrée » pour une unique, tirage de
    // plus dans un autre fichier), ou le renvoi à une sous-table, qui se déplie sous la ligne.
    function celluleOption(o, l, cle) {
      const plusieurs = l.options.length > 1 ? h('span', { class: 'cm-sourdine' }, ' (au choix)') : null;
      if (o.table) {
        const st = tables.get(o.table);
        const ouverte = sousOuvertes.has(cle);
        return h('div', { class: 'cm-option' + (moteur.disponible(o) ? '' : ' est-retiree') },
          h('button', { type: 'button', class: 'cm-renvoi', 'aria-expanded': String(ouverte), title: ouverte ? 'Replier la sous-table' : 'Déplier la sous-table',
            onclick: () => { if (ouverte) sousOuvertes.delete(cle); else sousOuvertes.add(cle); rendre(); } },
            icone(ouverte ? 'lu-chevron-down' : 'lu-chevron-right', 'bn-icone--s'),
            h('span', { class: 'bn-table__nom' }, `→ ${st?.nom || o.table}`, h('span', { class: 'des cm-sourdine' }, ` (${st?.de || '?'})`), plusieurs)));
      }
      const f = fiches.get(o.rencontre);
      const externe = o.tirage_externe ? `+ ${(moteur.externes[o.tirage_externe.jeu]?.donnees?.tables || []).find(t => t.id === o.tirage_externe.table)?.nom || o.tirage_externe.table}` : null;
      return h('div', { class: 'cm-option' + (moteur.retiree(o.rencontre) ? ' est-retiree' : '') },
        h('span', { class: 'bn-table__nom' }, f?.nom || o.rencontre, plusieurs),
        h('span', { class: 'bn-table__sous' },
          o.creatures.length ? o.creatures.flatMap((c, i) => [i ? ', ' : '', `${c.quantite} `, lienCreature(c)]) : TYPES[f?.type]?.libelle || '',
          externe ? ` ${externe}` : '',
          f?.unique ? caseRencontree(f.id) : null));
    }
    // Une créature d'une ligne (demande du MJ, 2026-10-23) : un clic la relie d'avance à son monstre de D&D Beyond
    // (ouvrirLiaison de app/rencontres-mj.js) ; pas encore reliée : soulignée en orange.
    function lienCreature(c) {
      const k = R.correspondance(c.nom);
      return h('button', { type: 'button', class: 'cm-lien-bouton cm-creature-table' + (k ? ' est-reliee' : ''),
        title: k ? `Reliée à ${k.nom} (D&D Beyond) : un clic pour changer` : 'Pas encore reliée à un monstre de D&D Beyond : un clic pour le choisir',
        onclick: () => R.ouvrirLiaison(c) }, c.nom);
    }

    // Lignes d'une table (plage « 13-15 ») ; une ligne qui renvoie à une sous-table la montre dépliée sous elle (son usage,
    // ses lignes). cle : chemin de la ligne, pour garder ce qui est déplié (une même sous-table sert à plusieurs lignes).
    function lignesDe(t, chemin) {
      return t.lignes.flatMap(l => {
        const cle = `${chemin}/${t.id}:${l.jet}`;
        const tr = h('tr', {},
          h('td', { class: 'num' }, plageLigne(l)),
          h('td', {}, l.options.map(o => celluleOption(o, l, cle))),
          h('td', { class: 'num cm-table__actions' }, h('div', { class: 'cm-table__boutons' },
            bouton('', { icone: 'd20', classe: 'bn-btn--s bn-btn--fantome', disabled: !moteur.ligneDisponible(l),
              titre: moteur.ligneDisponible(l) ? `Tirer cette ligne (${plageLigne(l)})${l.options.some(o => o.table) ? ', puis la sous-table' : ''}` : 'Tout ce que donne cette ligne est retiré des tables',
              onclick: () => tirerLigne(t, l) }),
            // Cacher ou remettre chaque rencontre de la ligne (une unique rencontrée : sa case « Rencontrée »).
            l.options.filter(o => o.rencontre && !moteur.rencontree(o.rencontre)).map(o => bouton('', {
              icone: moteur.cachee(o.rencontre) ? 'lu-eye' : 'lu-eye-off',
              titre: (moteur.cachee(o.rencontre) ? 'Remettre dans les tables : ' : 'Cacher des tables : ') + (fiches.get(o.rencontre)?.nom || o.rencontre),
              classe: 'bn-btn--s bn-btn--fantome', onclick: () => cacher(o.rencontre, !moteur.cachee(o.rencontre)),
            })))));
        if (!sousOuvertes.has(cle)) return [tr];
        return [tr, ...l.options.filter(o => tables.has(o.table)).map(o => {
          const st = tables.get(o.table);
          return h('tr', { class: 'cm-sous-ligne' }, h('td', { colspan: 3 }, h('div', { class: 'cm-sous-table-bloc' },
            st.usage ? h('p', { class: 'ui-s cm-sourdine' }, st.usage) : null,
            h('table', { class: 'bn-table cm-table cm-table--sous' }, h('tbody', {}, lignesDe(st, cle))),
            blocEcarts(st.ecarts, lib))));
        })];
      });
    }

    function vueTables() {
      const table = tableDe(momentTables);
      const uniques = v().rencontrees;
      const autres = v().retirees.filter(id => !moteur.rencontree(id));
      const retirees = [...uniques, ...autres];
      const noms = ids => ids.map(id => fiches.get(id)?.nom || id).join(', ');
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'cm-contexte' },
          bascule([['jour', 'Jour', 'soleil'], ['nuit', 'Nuit', 'lune']], momentTables, val => { momentTables = val; rendre(); }),
          h('span', { class: 'des cm-sourdine' }, table.de)),
        h('div', { class: 'bn-table-wrap' }, h('table', { class: 'bn-table cm-table' },
          h('thead', {}, h('tr', {}, h('th', { class: 'num' }, 'Jet'), h('th', {}, 'Rencontre'), h('th', {}, h('span', { class: 'cm-invisible' }, 'Actions')))),
          h('tbody', {}, lignesDe(table, momentTables)))),
        retirees.length ? h('p', { class: 'ui-s cm-sourdine' }, [uniques.length ? `Rencontrées : ${noms(uniques)}.` : '', autres.length ? `Cachées : ${noms(autres)}.` : '',
          'Le dé est relancé s\'il tombe dessus.'].filter(Boolean).join(' ')) : null,
        blocEcarts(table.ecarts, lib),
        h('details', { class: 'cm-regles' },
          h('summary', { class: 'etiquette' }, 'Règles du tirage'),
          h('ul', { class: 'ui cm-liste' },
            h('li', {}, proc.quand),
            h('li', {}, `${proc.test.regle} Route : ${proc.test.seuil.route}, nature : ${proc.test.seuil.nature}.`),
            h('li', {}, proc.plafond.regle),
            h('li', {}, `Tirage : ${proc.tirage.de}, table de jour ou de nuit. ${proc.tirage.alternative}`),
            (proc.modificateurs || []).map(m => h('li', {}, `${m.condition ? `${m.condition} ` : ''}${m.regle}`))),
          h('p', { class: 'etiquette' }, 'Carrefours'),
          h('ul', { class: 'ui cm-liste' }, proc.carrefours.map(c => h('li', {}, h('b', {}, `${c.nom} (${c.zone})`), ' : ', c.regle))),
          blocEcarts(proc.ecarts, lib)),
        (d.points_en_attente || []).map(p => alerte('cierge', 'lu-triangle-alert', `En attente · ${p.sujet}`, p.impact)));
    }

    // Rencontres prévues (données) et créées par le MJ, dans l'ordre de la campagne : premier jalon du déroulé qui les cite
    // (ou auquel elles sont rattachées), sinon leur étape, sinon (sur place) la première étape qui se joue à leur lieu ; les
    // autres à la fin. Un clic sur une rencontre ouvre son menu (Ouvrir, Lancer, Marquer terminée…).
    function vueHorsTables() {
      const liste = R.prevues();
      const faites = liste.filter(x => x.statut === 'terminee').length;
      return h('div', { class: 'cm-pile cm-hors-tables' },
        h('div', { class: 'cm-contexte' }, R.boutonNouvelle({}, { classe: 'bn-btn--s' }),
          h('span', { class: 'ui-s cm-sourdine' }, `${liste.length} rencontres${faites ? ` · ${faites} terminée${faites > 1 ? 's' : ''}` : ''}`)),
        h('div', { class: 'cm-rmj-liste' }, liste.map(vue => R.ligne(vue))),
        d.trouvailles_sans_danger ? h('div', { class: 'bn-carte' },
          h('p', { class: 'etiquette' }, icone('glyphe', 'bn-icone--s'), ' ', d.trouvailles_sans_danger.titre || 'Trouvailles sans danger'),
          h('p', { class: 'ui' }, d.trouvailles_sans_danger.usage),
          h('ul', { class: 'texte cm-liste' }, d.trouvailles_sans_danger.exemples.map(x => h('li', {}, x)))) : null);
    }

    // Efface tout ce que le widget a noté : utile après des essais. data/ n'est jamais touché.
    const remiseAZero = bouton('Tout remettre à zéro', { classe: 'bn-btn--s bn-btn--danger', icone: 'lu-rotate-ccw', onclick: () => {
      if (!confirm('Tout remettre à zéro ? Journal, compteurs, suivis, fenêtre de 12 h, rencontres cachées et rencontrées sont effacés. Les tables d\'origine reviennent en entier.')) return;
      Object.assign(v(), { journal: [], retirees: [], rencontrees: [], compteurs: {}, suivis: [], fenetre: { debut: new Date().toISOString(), rencontres: 0 } });
      s.enregistrer(0);
      rendre();
    } });

    function vueJournal() {
      const j = [...v().journal].reverse();
      if (!j.length) return h('div', { class: 'cm-pile' }, h('p', { class: 'ui cm-sourdine' }, 'Aucun test pour l\'instant.'), h('div', { class: 'bn-groupe' }, remiseAZero));
      const resume = moteur.resume;
      return h('div', { class: 'cm-pile' },
        // Une ligne par entrée ; un clic ouvre sa fiche dans une fenêtre flottante.
        h('ol', { class: 'cm-journal' }, j.map(e => h('li', {},
          lienFlottant(h('div', { class: 'cm-journal__ligne cm-ouvre', onclick: () => ouvrirRencontre(e) },
            icone(e.moment === 'nuit' ? 'lune' : 'soleil', 'bn-icone--s'),
            h('span', { class: 'ui-s cm-sourdine cm-journal__quand', title: e.horloge ? `Noté le ${heure(e.quand)}` : null }, e.horloge ? libelleMoment(e.horloge) : heure(e.quand)),
            h('button', { type: 'button', class: 'cm-journal__quoi cm-ouvre__nom' + (e.test && !e.test.reussi ? ' cm-sourdine' : ''), title: 'Ouvrir la fiche' }, resume(e)),
            e.note ? icone('livre', 'bn-icone--s') : null,
            // Effacer une ligne rend son numéro et sa place dans le plafond ; la rencontre lancée depuis elle est supprimée aussi.
            bouton('', { icone: 'lu-x', titre: 'Effacer cette ligne', classe: 'bn-btn--s bn-btn--fantome cm-journal__effacer', onclick: ev => {
              ev.stopPropagation();
              const lancee = R.duTirage(e.id);
              if (lancee && !confirm(`Effacer cette ligne ? La rencontre lancée depuis ce tirage, « ${lancee.nom} », est supprimée aussi.`)) return;
              if (lancee) R.oublierTirage(e.id);
              defaireRencontre(s, e.id, { garderLigne: true });
              v().journal = v().journal.filter(x => x.id !== e.id); s.enregistrer(0); s.signaler(rendre); rendre();
            } })), 'rencontre:' + e.id)))),
        h('div', { class: 'bn-groupe' },
          bouton('Vider le journal', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-trash-2', onclick: () => {
            if (confirm('Vider tout le journal des rencontres ? Les compteurs, suivis et retraits sont conservés.')) { v().journal = []; s.enregistrer(0); rendre(); }
          } }),
          remiseAZero));
    }

    function rendre() {
      const haut = corps.scrollTop;
      const o = onglets('Rencontres', [
        { id: 'tirage', libelle: 'Tirage', icone: 'd20', rendu: vueTirage },
        { id: 'tables', libelle: 'Tables', icone: 'lu-list', rendu: vueTables },
        { id: 'hors', libelle: 'Hors tables', icone: 'lu-map', rendu: vueHorsTables },
        { id: 'journal', libelle: 'Journal', icone: 'livre', rendu: vueJournal },
      ], ongletActif, id => {
        if (id !== ongletActif) { ongletActif = id; corps.scrollTop = 0; }
      });
      corps.replaceChildren(o.barre, o.zone);
      corps.scrollTop = haut;
      rafraichirRencontres();
      // Fenêtre du tirage (menu rapide) : redessinée sans passer devant les fenêtres ouvertes depuis.
      flottantOuvert('rencontres:tirage')?.maj(vueTirage());
    }

    // « Rencontres » du menu rapide (app/menu-rapide.js) : l'onglet Tirage dans une fenêtre flottante, même widget réduit
    // ou dans l'autre mode.
    function voirTirage(ev) {
      if (!corps.isConnected) { document.removeEventListener('cm:voir-tirage', voirTirage); return; }
      flottant('rencontres:tirage', { surtitre: 'Rencontres', titre: 'Tirage', largeur: 560, contenu: vueTirage() });
      if (ev.detail) ev.detail.ouvert = true;
    }
    document.addEventListener('cm:voir-tirage', voirTirage);
    rendre();
    s.abonner(rendre);   // tests faits ailleurs (passage du temps : horloge, repos, trajets) et terrain changé par l'horloge
    R.s.abonner(rendre);   // rencontres préparées, lancées ou terminées ailleurs (Combat, Déroulé, Ici)
    sHorloge.abonner(() => { if (suivreHorloge()) momentTables = v().contexte.moment; rendre(); });

    // « Voir » une rencontre sortie pendant que le temps passait (app/passage.js) : sa fiche dans une fenêtre flottante, et
    // la ligne de résultat du widget sur cette entrée (même s'il est réduit ou dans l'autre mode).
    function voirRencontre(ev) {
      if (!corps.isConnected) { document.removeEventListener('cm:voir-rencontre', voirRencontre); return; }
      const e = trouver(ev.detail?.id);
      if (!e) return;
      affichee = e.id;
      rendre();
      if (e.proposee || !ouvrirBabioleDe(e)) ouvrirRencontre(e);
    }
    document.addEventListener('cm:voir-rencontre', voirRencontre);
    return {};
  },
};
