// Widget Maisons : qui ouvre la porte d'une maison quelconque, par lieu (jet du d20, quantités lancées).
// Données : data/occupants-maisons.json (formats/occupants-maisons.md). Les jets ne sont pas enregistrés ; une ligne qui a des
// créatures peut lancer une rencontre (préparation, puis Combat : app/rencontres-mj.js, origine « maison »).

import { h, icone, bouton, alerte, bascule, provenance, blocOriginal } from '../ui.js';
import { lancer, estFixe, ligneDeTable } from '../des.js';
import { outilsRencontresMj } from '../rencontres-mj.js';

// Jet sur une table d'occupants, quantités lancées. Partagé avec le widget Ici.
export function tirerOccupants(t) {
  const j = lancer(t.de);
  const ligne = ligneDeTable(t.lignes, j.total);
  return { jet: j.total, ligne, quantites: (ligne?.creatures || []).map(quantite) };
}

function quantite(c) {
  if (estFixe(c.quantite)) return { nom: c.nom, formule: c.quantite, total: Number(c.quantite) };
  const j = lancer(c.quantite);
  return { nom: c.nom, formule: c.quantite, total: j ? Math.max(0, j.total) : null };
}

// Résultat d'un jet (r : tirerOccupants) ; surChange() après la relance d'une quantité. R : les outils des rencontres du MJ
// (outilsRencontresMj) : « Lancer » sur une ligne qui a des créatures (demande du MJ, 2026-10-25 : il juge si ça tourne au combat).
export function vueOccupants(t, r, surChange, { R = null } = {}) {
  const lancable = R && r.quantites.some(q => q.total !== 0);
  return h('div', { class: 'cm-fiche', 'aria-live': 'polite' },
    h('p', { class: 'des cm-jets' }, icone('d20', 'bn-icone--s'), `${t.de} : ${r.jet}${r.ligne ? ` (${r.ligne.jet})` : ''}`),
    h('h3', { class: 'titre-m' }, r.ligne?.resultat || 'Aucune ligne pour ce jet'),
    r.quantites.length ? h('ul', { class: 'cm-creatures' }, r.quantites.map((q, i) => h('li', {},
      h('span', { class: 'cm-creatures__nombre' }, q.total ?? q.formule),
      h('span', { class: 'cm-creatures__nom' }, q.nom),
      estFixe(q.formule) ? null : h('span', { class: 'des cm-sourdine' }, q.formule),
      estFixe(q.formule) || q.total === null ? null : bouton('', {
        icone: 'lu-refresh-cw', titre: `Relancer ${q.formule}`, classe: 'bn-btn--s bn-btn--fantome',
        onclick: () => { r.quantites[i] = quantite({ nom: q.nom, quantite: q.formule }); surChange(); },
      })))) : null,
    lancable ? h('div', { class: 'bn-groupe cm-fiche__combat' }, bouton('Lancer', { classe: 'bn-btn--s', icone: 'epee',
      titre: 'Si ça tourne à la rencontre : sa préparation (monstres, nombres, difficulté), puis « Lancer le combat ». Ni journal ni plafond des rencontres aléatoires.',
      onclick: () => R.depuisMaison(t, r) })) : null,
    r.ligne?.detail ? h('p', { class: 'texte' }, r.ligne.detail) : null);
}

export default {
  type: 'maisons',
  requiert: 'occupants-maisons',
  titre: 'Maisons',
  icone: 'porte',
  description: 'Les occupants d\'une maison quelconque d\'un village ou d\'une ville, au d20, avec les quantités déjà lancées.',
  taille: { w: 4, h: 10 },
  min: { w: 3, h: 6 },
  unique: true,

  async monter({ corps, donnees, etat, dialogue }) {
    const lecture = await donnees('occupants-maisons');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Tables des maisons indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const tables = lecture.donnees.tables;
    const R = await outilsRencontresMj({ donnees, etat, dialogue });
    corps.classList.add('cm-maisons');   // marges resserrées, sans filet (CSS)
    let choix = tables[0].id;
    const resultats = {};   // id de table -> dernier jet

    function jeter(t) {
      resultats[t.id] = tirerOccupants(t);
      rendre();
    }

    function vueResultat(t) {
      const r = resultats[t.id];
      if (!r) return h('p', { class: 'ui cm-sourdine' }, t.usage || 'Lancez le dé quand les PJ frappent à une porte.');
      return vueOccupants(t, r, rendre, { R });
    }

    function rendre() {
      const t = tables.find(x => x.id === choix);
      corps.replaceChildren(
        h('div', { class: 'cm-contexte' },
          tables.length > 1 ? bascule('Lieu', tables.map(x => [x.id, x.lieu.nom]), choix, id => { choix = id; rendre(); }) : h('span', { class: 'etiquette' }, t.lieu.nom),
          bouton(`Lancer le ${t.de.replace(/^1/, '')}`, { icone: 'd20', classe: 'bn-btn--primaire', onclick: () => jeter(t) })),
        t.ambiance ? h('p', { class: 'aparte cm-sourdine' }, t.ambiance) : '',   // replaceChildren écrirait « null »
        vueResultat(t),
        h('details', { class: 'cm-repli' },
          h('summary', { class: 'etiquette' }, 'Toute la table'),
          h('div', { class: 'cm-pile' },
            t.usage && resultats[t.id] ? h('p', { class: 'ui-s cm-sourdine' }, t.usage) : null,
            h('div', { class: 'bn-table-wrap' }, h('table', { class: 'bn-table' },
              h('thead', {}, h('tr', {}, h('th', { class: 'num' }, 'Jet'), h('th', {}, 'Résultat'))),
              h('tbody', {}, t.lignes.map(l => h('tr', { 'aria-selected': resultats[t.id]?.ligne === l ? 'true' : null },
                h('td', { class: 'num' }, l.jet),
                h('td', {}, h('span', { class: 'bn-table__nom' }, l.resultat), l.detail ? h('span', { class: 'bn-table__sous' }, l.detail) : null)))))),
            blocOriginal(t.original),
            provenance(t))));
    }
    rendre();
    return {};
  },
};
