// Widget Trajets : itinéraire construit tronçon par tronçon, distances en miles ou en km, temps de marche, jours,
// selon le rythme et la monture, tests de rencontre à prévoir, aide pour marcher plus de 8 heures.
// Calcul (règle du MJ, app/voyage.js) : temps = miles / vitesse, doublé en terrain difficile ; jours = temps / 8 heures.
// Avec l'horloge, un rappel quand le créneau en cours a du brouillard, de la forte neige ou du verglas (data/meteo.json).
// Données : data/temps-de-voyage.json (formats/temps-de-voyage.md). État : etat/trajets.json (formats/etat.md).

import { h, icone, bouton, badge, alerte, bascule, section, provenance, blocOriginal, flottant, flottantOuvert, sansRamener, identifiant } from '../ui.js';
import { chargerLieux, nomLieu, etatIci, arriverA, noterTrajet } from '../lieux.js';
import { chargerCarte, traceEntre } from '../carte.js';
import { HEURES_PAR_JOUR, RYTHMES, nombre, enKm, enMiles, distanceVoyage, enHeures, enJours, vitessesDe, milesParHeure, minutesTrajet } from '../voyage.js';
import { etatHorloge, horlogeEnService, enMinutes, depuisMinutes, dureeVoyage, libelleDuree, libelleMoment, lecture as lectureHorloge, chargerCalendrier } from '../horloge.js';
import { rappelMeteo } from '../calendrier.js';
import { etatRencontres, terrainDuLieu } from '../rencontres-moteur.js';
import { partirEnTrajet } from '../passage.js';

const SVG = 'http://www.w3.org/2000/svg';
function svg(tag, attrs = {}, ...enfants) {
  const el = document.createElementNS(SVG, tag);
  for (const [k, val] of Object.entries(attrs)) if (val !== null && val !== undefined) el.setAttribute(k, val);
  el.append(...enfants.flat().filter(Boolean));
  return el;
}

const AIDE_8_HEURES = ['marche-forcee', 'sans-repos-long'];

export default {
  type: 'trajets',
  requiert: 'temps-de-voyage',
  titre: 'Trajets',
  icone: 'carte',
  description: 'Un itinéraire tronçon par tronçon : miles ou km, temps de marche (doublé en terrain difficile), jours de 8 heures, rythme et monture, tests de rencontre à prévoir.',
  taille: { w: 5, h: 13 },
  min: { w: 4, h: 7 },
  unique: true,

  async monter({ corps, deplier, donnees, etat, dialogue }) {
    const lecture = await donnees('temps-de-voyage');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Temps de voyage indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    const intervalle = (await donnees('rencontres-aleatoires')).donnees?.procedure?.intervalle_minutes || 30;
    // Lieux reliés : ceux des trajets ; nom et zone dans lieux.json (temps-de-voyage.lieux, s'il existe encore, sert à défaut).
    const annuaire = await chargerLieux(donnees);
    const locaux = new Map((d.lieux || []).map(l => typeof l === 'string' ? [l, { id: l }] : [l.id, l]));
    const ids = [...new Set(d.trajets.flatMap(t => [t.de, t.vers]))];
    const lieux = new Map(ids.map(id => [id, { id, nom: annuaire.get(id)?.nom || locaux.get(id)?.nom || id, zone: annuaire.get(id)?.zone ?? locaux.get(id)?.zone }]));
    const nom = id => lieux.get(id)?.nom || nomLieu(annuaire, id);
    const regle = id => d.regles.find(r => r.id === id);
    const vitesses = vitessesDe(d);
    const bonusMonture = vitesses.bonusMonture;
    const s = await etat('trajets', { schema: 1, itineraire: [], unite: 'miles', rythme: 'normal', monture: false });
    const v = () => s.valeur;
    const sIci = await etatIci(etat, donnees);
    const sHorloge = await etatHorloge(etat);
    const { meteo } = await chargerCalendrier(donnees);

    const voisins = id => d.trajets.filter(t => t.de === id || t.vers === id).map(t => ({ trajet: t, vers: t.de === id ? t.vers : t.de }));
    const troncon = (a, b) => d.trajets.find(t => (t.de === a && t.vers === b) || (t.de === b && t.vers === a));
    const distance = miles => v().unite === 'km' ? enKm(miles) : enMiles(miles);
    const distanceEl = (miles, note) => distanceVoyage(miles, { unite: v().unite, note });
    // Miles par heure de marche, au rythme choisi (monture comprise).
    const vitesse = () => milesParHeure(vitesses, v().rythme, v().monture);
    const minutes = t => minutesTrajet(t, vitesse());

    function changer(cle, val) { v()[cle] = val; s.enregistrer(); rendre(); }

    // ───── Carte : réseau des trajets, itinéraire en surbrillance, lieux cliquables ─────
    // Celle de la campagne (carte.json, app/carte.js) ; sans elle, le widget se passe de carte.
    const CARTE = await chargerCarte();
    const ratio = CARTE ? CARTE.hauteur / CARTE.largeur * 100 : 100;
    const pos = id => { const p = CARTE?.points?.[id]; return p ? [p[0], p[1] * ratio / 100] : null; };

    // ───── Tracé libre : des segments posés sur la carte, mesurés à l'échelle des trajets ─────
    // Repère du calque (largeur 100). Échelle : médiane, sur les trajets dessinés, de leurs miles rapportés à la longueur
    // de leur tracé sur la carte. Le tracé n'est pas enregistré ; il vaut pour la carte du widget et celle de la fenêtre.
    // Un point posé d'un Ctrl+clic ferme un segment en terrain difficile (temps doublé) : [x, y, true].
    let libre = null;   // { actif, points: [[x, y, difficile?]…] }
    const vuesLibre = new Set();   // ce qui se redessine quand le tracé change (cartes, résumé)
    const majLibre = () => vuesLibre.forEach(fn => fn());
    const longueur = pts => pts.slice(1).reduce((a, p, i) => a + Math.hypot(p[0] - pts[i][0], p[1] - pts[i][1]), 0);
    let echelleCalculee;
    function echelle() {
      if (echelleCalculee !== undefined) return echelleCalculee;
      const r = d.trajets.map(t => {
        const a = pos(t.de), b = pos(t.vers);
        if (!a || !b) return null;
        const l = longueur([a, ...traceEntre(CARTE, t.de, t.vers).map(([x, y]) => [x, y * ratio / 100]), b]);
        return l > 0 ? t.miles / l : null;
      }).filter(Boolean).sort((x, y) => x - y);
      return (echelleCalculee = r.length ? r[Math.floor(r.length / 2)] : null);
    }
    function basculerLibre() {
      libre = libre?.actif ? { ...libre, actif: false } : { actif: true, points: [] };
      rendre();
    }
    // Segments du tracé, en miles : [{ miles, difficile }].
    const segmentsLibres = e => (libre?.points || []).slice(1).map((p, i) => ({ miles: Math.hypot(p[0] - libre.points[i][0], p[1] - libre.points[i][1]) * e, difficile: !!p[2] }));

    // Les routes se voient sur la carte : seul l'itinéraire est tracé. Un lieu marqué (départ, lieu suivant) s'ajoute d'un clic ;
    // un clic sur le dernier lieu atteint retire ce tronçon. Au survol : une infobulle (nom, distance, temps de marche).
    // Outils en haut à droite : tracé libre ; dans le widget, agrandir et masquer la carte.
    function vueCarte(grande) {
      const it = v().itineraire;
      const dernier = it[it.length - 1];
      const suivants = new Set(dernier ? voisins(dernier).map(o => o.vers) : []);
      // Le trajet suit la route dessinée sur la carte (traceEntre), sinon une ligne droite.
      const segment = (a, b, classe) => {
        const pa = pos(a), pb = pos(b);
        if (!pa || !pb) return null;
        const milieu = traceEntre(CARTE, a, b).map(([x, y]) => [x, y * ratio / 100]);
        return svg('polyline', { points: [pa, ...milieu, pb].map(p => p.join(',')).join(' '), class: classe });
      };
      const trace = it.slice(1).map((id, i) => segment(it[i], id, 'cm-carte__trace'));
      const bulle = h('div', { class: 'bn-bulle cm-carte__bulle', role: 'tooltip', hidden: true });
      const montrer = (id, p, titre, detail, action) => {
        bulle.replaceChildren(...[h('b', {}, titre), detail ? h('span', {}, detail) : null].filter(Boolean));   // un null s'écrirait « null »
        // La couleur du lieu (demande du MJ, 2026-10-23 : l'infobulle s'accorde avec l'élément) : orange sur l'itinéraire et au
        // dernier lieu atteint, jaune route sinon ; le tracé libre (sans lieu) reste bleu.
        bulle.className = 'bn-bulle cm-carte__bulle' + (lieux.has(id) ? (id === dernier || it.includes(id) ? ' bn-bulle--cierge' : ' bn-bulle--soleil') : '');
        // Près d'un bord, l'infobulle se décale pour rester sur la carte (sous le point près du bord haut).
        const tx = p[0] < 15 ? '-12%' : p[0] > 85 ? '-88%' : '-50%';
        const ty = p[1] / ratio < 0.18 ? '12px' : 'calc(-100% - 12px)';
        Object.assign(bulle.style, { left: `${p[0]}%`, top: `${p[1] / ratio * 100}%`, transform: `translate(${tx}, ${ty})` });
        bulle.hidden = false;
      };
      // Tracé libre : un clic pose un point (sur un lieu, le point se place sur le lieu), Ctrl+clic en terrain difficile ;
      // un trait suit le pointeur ; un clic droit retire le dernier point (sans point, il termine), comme sur l'itinéraire.
      const poser = (p, difficile) => { libre.points.push(difficile ? [p[0], p[1], true] : [p[0], p[1]]); majLibre(); };
      const points = [...lieux.keys()].map(id => {
        const p = pos(id);
        if (!p) return null;
        const etat = id === dernier ? 'actuel' : it.includes(id) ? 'passe' : suivants.has(id) ? 'suivant' : (!dernier ? 'depart' : 'autre');
        const retirer = etat === 'actuel';
        const cliquable = etat === 'suivant' || etat === 'depart' || retirer;
        const t = suivants.has(id) ? troncon(dernier, id) : null;
        const detail = t ? `${distance(t.miles)} · ${enHeures(minutes(t))}${t.terrain_difficile ? ' · terrain difficile' : ''}`
          : retirer ? (it.length > 1 ? 'Clic ou clic droit : retirer ce tronçon' : 'Clic ou clic droit : retirer le départ')
            : etat === 'depart' ? 'Cliquer : partir d\'ici' : '';
        const aria = retirer ? `${nom(id)} : retirer ce lieu de l'itinéraire` : cliquable ? (dernier ? `Aller vers ${nom(id)} · ${detail}` : `Partir de ${nom(id)}`) : nom(id);
        const g = svg('g', { class: `cm-carte__point cm-carte__point--${etat}`, transform: `translate(${p[0]} ${p[1]})`, role: cliquable ? 'button' : null, tabindex: cliquable ? '0' : null, 'aria-label': aria },
          svg('circle', { r: grande ? 1.25 : 1.5 }));
        const agir = () => (retirer ? retirerDernier() : ajouter(id));
        g.addEventListener('click', e => {
          if (libre?.actif) { e.stopPropagation(); poser(p, e.ctrlKey || e.metaKey); return; }
          if (cliquable) agir();
        });
        if (cliquable) g.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); agir(); } });
        const survol = () => (libre?.actif ? montrer(id, p, nom(id), 'Cliquer : point du tracé libre', false) : montrer(id, p, nom(id), detail, cliquable));
        g.addEventListener('pointerenter', survol);
        g.addEventListener('focus', survol);
        g.addEventListener('pointerleave', () => { bulle.hidden = true; });
        g.addEventListener('blur', () => { bulle.hidden = true; });
        return g;
      });
      const gLibre = svg('g', { class: 'cm-carte__libre' });
      const elastique = svg('line', { class: 'cm-carte__elastique', visibility: 'hidden' });
      const calque = svg('svg', { viewBox: `0 0 100 ${ratio}`, class: 'cm-carte__calque', 'aria-label': 'Carte des trajets' }, trace, gLibre, elastique, points);
      // Pendant le tracé : le mode d'emploi en infobulle, en haut à gauche de la carte.
      const aide = h('div', { class: 'bn-bulle cm-carte__aide', role: 'note' },
        h('b', {}, 'Tracé libre'), h('span', {}, 'Clic : poser un point · Ctrl + clic : en terrain difficile · Clic droit : retirer le dernier point'));
      const carte = h('div', { class: 'cm-carte' + (grande ? ' cm-carte--grande' : '') },
        h('img', { src: encodeURI(CARTE.image), alt: 'Carte des trajets', loading: 'lazy', draggable: 'false' }),
        calque, bulle, aide,
        h('div', { class: 'cm-carte__outils' },
          outil('lu-ruler', libre?.actif ? 'Terminer le tracé libre' : 'Tracé libre : poser des segments sur la carte pour mesurer une distance et un temps de marche', basculerLibre, !!libre?.actif),
          grande ? null : outil('lu-maximize-2', 'Agrandir la carte', ouvrirCarte),
          grande ? null : outil('lu-eye-off', 'Masquer la carte', () => changer('carte', false))));
      const repere = e => { const r = calque.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * 100, (e.clientY - r.top) / r.height * ratio]; };
      calque.addEventListener('click', e => { if (libre?.actif) poser(repere(e), e.ctrlKey || e.metaKey); });
      // Clic droit : retirer le dernier segment (point du tracé libre, ou tronçon de l'itinéraire).
      calque.addEventListener('contextmenu', e => {
        if (libre?.actif) {
          e.preventDefault();
          if (libre.points.length) { libre.points.pop(); majLibre(); } else { libre.actif = false; rendre(); }
        } else if (v().itineraire.length) { e.preventDefault(); bulle.hidden = true; retirerDernier(); }
      });
      calque.addEventListener('pointermove', e => {
        const dernierPoint = libre?.actif && libre.points.at(-1);
        if (!dernierPoint) { elastique.setAttribute('visibility', 'hidden'); return; }
        const [x, y] = repere(e);
        [['x1', dernierPoint[0]], ['y1', dernierPoint[1]], ['x2', x], ['y2', y]].forEach(([k, val]) => elastique.setAttribute(k, val));
        elastique.setAttribute('visibility', 'visible');
      });
      calque.addEventListener('pointerleave', () => elastique.setAttribute('visibility', 'hidden'));
      // Segments et points à taille fixe à l'écran, quelle que soit la taille de la carte (traits : non-scaling-stroke).
      const dessiner = () => {
        const pts = libre?.points || [];
        carte.classList.toggle('est-trace', !!libre?.actif);
        // Le trait qui suit le pointeur part du dernier point (un clic droit vient peut-être d'en retirer un).
        if (!libre?.actif || !pts.length) elastique.setAttribute('visibility', 'hidden');
        else { elastique.setAttribute('x1', pts.at(-1)[0]); elastique.setAttribute('y1', pts.at(-1)[1]); }
        const unite = (calque.getBoundingClientRect().width || (grande ? 1150 : 430)) / 100;   // pixels par unité du calque
        gLibre.replaceChildren(
          ...pts.slice(1).map((p, i) => svg('line', { x1: pts[i][0], y1: pts[i][1], x2: p[0], y2: p[1], class: 'cm-carte__libre-trait' + (p[2] ? ' est-difficile' : '') })),
          ...pts.map(p => svg('circle', { cx: p[0], cy: p[1], r: 3 / unite, class: 'cm-carte__libre-point' })));
      };
      const fn = () => { if (!carte.isConnected) { vuesLibre.delete(fn); return; } dessiner(); };
      vuesLibre.add(fn);
      dessiner();
      requestAnimationFrame(fn);   // une fois la carte à l'écran, à sa vraie taille
      return carte;
    }
    // Bouton d'outil posé sur la carte : icône seule, en transparence.
    function outil(ic, titre, onclick, actif) {
      return h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone bn-btn--fantome cm-carte__outil', title: titre, 'aria-label': titre,
        'aria-pressed': actif === undefined ? null : String(actif), onclick }, icone(ic));
    }
    // Résumé du tracé libre : distance (l'autre unité au survol) et temps de marche au rythme choisi.
    function vueLibre() {
      const zone = h('div', { class: 'cm-libre' });
      const remplir = () => {
        zone.hidden = !libre;
        if (!libre) { zone.replaceChildren(); return; }
        const pts = libre.points;
        const e = echelle();
        const segs = e ? segmentsLibres(e) : [];
        const miles = segs.length ? segs.reduce((a, x) => a + x.miles, 0) : null;
        const milesDifficiles = segs.filter(x => x.difficile).reduce((a, x) => a + x.miles, 0);
        const min = segs.reduce((a, x) => a + x.miles / vitesse() * 60 * (x.difficile ? 2 : 1), 0);
        zone.replaceChildren(...[
          h('p', { class: 'cm-libre__chiffres' }, icone('lu-ruler', 'bn-icone--s'),
            miles != null ? [distanceEl(miles), ` · ${enHeures(min)} de marche`,
              min > HEURES_PAR_JOUR * 60 ? h('span', { class: 'cm-sourdine' }, ` (${enJours(min)} en journées de 8 h)`) : null,
              milesDifficiles ? h('span', { class: 'cm-libre__difficile' }, ' · dont ', distanceEl(milesDifficiles), ' en terrain difficile') : null]
              : h('span', { class: 'ui-s cm-sourdine' }, libre.actif ? 'Tracé libre : posez au moins deux points.' : 'Tracé libre')),
          !e ? h('p', { class: 'ui-s cm-sourdine' }, 'Échelle inconnue : aucun trajet tracé sur la carte.') : null,
          h('div', { class: 'bn-groupe' },
            pts.length ? bouton('Retirer le dernier point', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: () => { libre.points.pop(); majLibre(); } }) : null,
            libre.actif ? bouton('Terminer', { classe: 'bn-btn--s', icone: 'lu-check', onclick: () => { libre.actif = false; rendre(); } }) : null,
            bouton('Effacer', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', onclick: () => { libre = null; rendre(); } })),
        ].filter(Boolean));
      };
      const fn = () => { if (!zone.isConnected) { vuesLibre.delete(fn); return; } remplir(); };
      vuesLibre.add(fn);
      remplir();
      return zone;
    }
    function majCarteFlottante() {
      if (flottantOuvert('carte-trajets')) sansRamener(ouvrirCarte);
    }
    // Carte agrandie : fenêtre compacte, aussi large que l'écran le permet tout en tenant en hauteur (tête, carte et résumé
    // du tracé libre), sans défilement.
    function ouvrirCarte() {
      if (!CARTE) return;
      const hauteurCarte = innerHeight - 170;   // marges de la fenêtre (8 px en haut et en bas), tête, résumé du tracé
      const largeur = Math.max(480, Math.min(innerWidth - 32, Math.round(hauteurCarte * CARTE.largeur / CARTE.hauteur) + 20));
      flottant('carte-trajets', { titre: 'Carte des trajets', largeur, compact: true, pictogramme: 'carte', contenu: [vueCarte(true), vueLibre()] });
    }
    function ajouter(id) { v().itineraire.push(id); delete v().arrive; s.enregistrer(0); rendre(); majCarteFlottante(); }
    function retirerDernier() { v().itineraire.pop(); delete v().arrive; s.enregistrer(0); rendre(); majCarteFlottante(); }

    // « Démarrer le trajet » : le dialogue de départ (rythme, cases de la procédure de rencontre ; partirEnTrajet() de app/passage.js, partagé avec
    // le Déroulé), puis un trajet en cours, mené heure par heure dans l'Horloge : un test de rencontre par heure dehors, de jour
    // ou de nuit ; chaque lieu traversé est noté (widget Ici) à son heure d'arrivée ; pauses, combats et campement entre deux
    // heures. Fin : événement cm:trajet-fini.
    const demarrer = () => partirEnTrajet({ dialogue, donnees, etat }, [...v().itineraire]);

    // Sans le widget Horloge : les héros arrivent, sans suivre l'heure (lieux traversés notés, terrain d'arrivée).
    async function arriverSansHeure(ts) {
      const it = v().itineraire;
      const id = identifiant();
      ts.forEach((t, i) => arriverA(sIci, annuaire, it[i + 1], null, id));
      noterTrajet(sIci, { id, itineraire: [...it], atteints: it.length - 1, marche: ts.reduce((a, t) => a + minutes(t), 0), fini: true });
      const terrain = terrainDuLieu(annuaire.get(it.at(-1))?.type);
      if (terrain) {
        const sR = await etatRencontres(etat);
        sR.valeur.contexte.terrain = terrain;
        sR.enregistrer(0);
        sR.signaler();
      }
      v().arrive = { quand: new Date().toISOString() };
      s.enregistrer(0);
      rendre();
    }

    // Plus de 8 h de marche : repère à droite du bouton de départ, les règles (marche forcée) d'un clic.
    const plusDe8h = total => (total > HEURES_PAR_JOUR * 60
      ? h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome cm-plus-8h', title: 'Plus de 8 h de marche : marche forcée ou campement. Cliquer : les règles', onclick: aide },
        icone('lu-footprints'), h('span', {}, '> 8 h'))
      : null);

    function vueDepart(ts, total) {
      const fin = v().itineraire.at(-1);
      if (v().arrive) {
        return h('div', { class: 'cm-contexte' },
          h('p', { class: 'cm-lieu' }, icone('lu-check', 'bn-icone--s'), `Arrivés à ${nom(fin)}${v().arrive.jour ? ` · ${libelleMoment(v().arrive)}` : ''}`),
          bouton(`Repartir de ${nom(fin)}`, { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-route', onclick: () => { v().itineraire = [fin]; delete v().arrive; s.enregistrer(0); rendre(); majCarteFlottante(); } }));
      }
      const enCours = (sHorloge.valeur.activites || []).find(a => a.type === 'voyage');
      if (enCours) {
        return h('p', { class: 'cm-lieu' }, icone('lu-footprints', 'bn-icone--s'),
          `${enCours.titre} : ${libelleDuree(enCours.fait)} de marche sur ${libelleDuree(enCours.total)}. Il se mène heure par heure dans l'Horloge.`);
      }
      if (!horlogeEnService()) {
        return h('div', { class: 'cm-contexte' },
          bouton('Arriver', { icone: 'epingle', classe: 'bn-btn--s', titre: 'Noter les lieux traversés, sans suivre l\'heure', onclick: () => arriverSansHeure(ts) }),
          plusDe8h(total),
          h('span', { class: 'ui-s cm-sourdine' }, 'Ajoutez le widget Horloge pour suivre le trajet heure par heure, avec les tests de rencontre.'));
      }
      const ecoule = dureeVoyage(total);
      return h('div', { class: 'cm-contexte' },
        bouton('Démarrer le trajet', { icone: 'lu-route', classe: 'bn-btn--s bn-btn--primaire', titre: 'Un trajet en cours dans l\'Horloge : heure par heure, avec les tests de rencontre', onclick: demarrer }),
        plusDe8h(total),
        h('span', { class: 'ui-s cm-sourdine' }, `Sans halte : arrivée ${libelleMoment(depuisMinutes(enMinutes(sHorloge.valeur) + ecoule))} (+${libelleDuree(ecoule)}).`));
    }

    // Trajet mené jusqu'au bout dans l'Horloge : c'est celui-ci s'il suit le même itinéraire.
    function trajetFini(ev) {
      if (!corps.isConnected) { document.removeEventListener('cm:trajet-fini', trajetFini); return; }
      if (JSON.stringify(ev.detail?.itineraire) !== JSON.stringify(v().itineraire)) return;
      v().arrive = { quand: new Date().toISOString(), ...ev.detail.quand };
      s.enregistrer(0);
      rendre();
    }
    document.addEventListener('cm:trajet-fini', trajetFini);
    // « Carte » du menu rapide (app/menu-rapide.js) : la carte agrandie.
    function voirCarte(ev) {
      if (!corps.isConnected) { document.removeEventListener('cm:voir-carte', voirCarte); return; }
      if (!CARTE) return;   // pas de carte : le menu rapide l'annonce
      ouvrirCarte();
      if (ev.detail) ev.detail.ouvert = true;
    }
    document.addEventListener('cm:voir-carte', voirCarte);

    function aide() {
      const regles = AIDE_8_HEURES.map(regle).filter(Boolean);
      dialogue('Règles de voyage', 'Marcher plus de 8 heures', h('div', { class: 'cm-pile' },
        regles.length ? regles.map(r => h('p', { class: 'texte' }, r.detail || r.texte))
          : h('p', { class: 'ui cm-sourdine' }, 'Le fichier temps-de-voyage.json ne contient pas ces règles.')));
    }

    function vueTroncons() {
      const it = v().itineraire;
      const lignes = [];
      for (let i = 1; i < it.length; i++) {
        const t = troncon(it[i - 1], it[i]);
        if (!t) { lignes.push(h('li', {}, alerte('cierge', 'lu-triangle-alert', 'Tronçon inconnu', `Plus de trajet direct entre ${nom(it[i - 1])} et ${nom(it[i])}.`))); continue; }
        lignes.push(h('li', { class: 'cm-troncon' },
          h('div', { class: 'cm-troncon__lieux' }, h('span', {}, nom(it[i - 1])), icone('lu-arrow-right', 'bn-icone--s'), h('b', {}, nom(it[i]))),
          h('div', { class: 'cm-troncon__chiffres' },
            distanceEl(t.miles, t.decision_mj?.texte), h('span', {}, enHeures(minutes(t))),
            t.terrain_difficile ? badge('Terrain difficile ×2', 'cierge') : null)));
      }
      return h('ol', { class: 'cm-troncons' }, lignes);
    }

    function vueTotaux() {
      const it = v().itineraire;
      const ts = it.slice(1).map((id, i) => troncon(it[i], id)).filter(Boolean);
      if (!ts.length) return null;
      const miles = ts.reduce((a, t) => a + t.miles, 0);
      const total = ts.reduce((a, t) => a + minutes(t), 0);
      const mpj = vitesse() * HEURES_PAR_JOUR;
      return h('div', { class: 'bn-carte cm-totaux' },
        h('div', { class: 'cm-totaux__grille' },
          h('div', {}, h('span', { class: 'etiquette' }, 'Distance'), h('span', { class: 'chiffre' }, distanceEl(miles))),
          h('div', {}, h('span', { class: 'etiquette' }, 'Marche'), h('span', { class: 'chiffre' }, enHeures(total))),
          h('div', {}, h('span', { class: 'etiquette' }, 'Jours de 8 h'), h('span', { class: 'chiffre' }, enJours(total)))),
        h('p', { class: 'ui-s cm-sourdine' }, `${enMiles(mpj)} par jour (${nombre(vitesse(), 2)} par heure)${ts.some(t => t.terrain_difficile) ? ', temps doublé en terrain difficile' : ''}.`),
        h('p', { class: 'ui-s' }, icone('d20', 'bn-icone--s'), ` ≈ ${Math.ceil(total / intervalle)} tests de rencontre (un toutes les ${enHeures(intervalle)} de voyage).`),
        ts.length === it.length - 1 ? vueDepart(ts, total) : null);
    }

    function vueSuite() {
      const it = v().itineraire;
      const dernier = it[it.length - 1];
      const relies = [...lieux.values()].filter(l => voisins(l.id).length);
      if (!dernier) {
        const sel = h('select', { class: 'bn-select', id: 'tr-depart', onchange: e => e.target.value && ajouter(e.target.value) },
          h('option', { value: '' }, '— Choisir le départ —'),
          relies.sort((a, b) => a.nom.localeCompare(b.nom, 'fr')).map(l => h('option', { value: l.id }, `${l.nom}${l.zone ? ` (${l.zone})` : ''}`)));
        return h('div', { class: 'bn-champ' }, h('label', { class: 'bn-champ__label', for: 'tr-depart' }, 'Départ'), sel);
      }
      const options = voisins(dernier).sort((a, b) => a.trajet.miles - b.trajet.miles);
      const sel = h('select', { class: 'bn-select', id: 'tr-suite', onchange: e => e.target.value && ajouter(e.target.value) },
        h('option', { value: '' }, `— Depuis ${nom(dernier)}, aller vers… —`),
        options.map(o => h('option', { value: o.vers }, `${nom(o.vers)} · ${distance(o.trajet.miles)} · ${enHeures(minutes(o.trajet))}${o.trajet.terrain_difficile ? ' · difficile' : ''}`)));
      return h('div', { class: 'cm-pile' },
        h('div', { class: 'bn-champ' }, h('label', { class: 'bn-champ__label', for: 'tr-suite' }, 'Tronçon suivant'), sel),
        h('div', { class: 'bn-groupe' },
          bouton('Retirer le dernier', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: retirerDernier }),
          bouton('Nouvel itinéraire', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', onclick: nouvelItineraire })));
    }

    function nouvelItineraire() {
      v().itineraire = [];
      delete v().arrive;
      s.enregistrer(0);
      rendre();
      majCarteFlottante();
    }

    // « Retirer le dernier » et « Nouvel itinéraire » répétés en icônes au bout de la ligne des options, s'il y a un itinéraire
    // et s'ils tiennent sur la ligne (demande du MJ, 2026-11-01) : mesuré, ils s'effacent plutôt que de passer à la ligne.
    let iconesItineraire = null;
    function ajusterIcones() {
      if (!iconesItineraire?.isConnected) return;
      iconesItineraire.hidden = false;
      const premier = iconesItineraire.parentElement.firstElementChild;
      iconesItineraire.hidden = iconesItineraire.offsetTop > premier.offsetTop + premier.offsetHeight / 2;
    }
    new ResizeObserver(ajusterIcones).observe(corps);

    function rendre() {
      iconesItineraire = v().itineraire.length ? h('div', { class: 'bn-groupe cm-trajets__icones' },
        bouton('', { titre: 'Retirer le dernier', classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: retirerDernier }),
        bouton('', { titre: 'Nouvel itinéraire', classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', onclick: nouvelItineraire })) : null;
      corps.replaceChildren(...[
        h('div', { class: 'cm-contexte cm-trajets__reglages' },
          bascule('Unité', [['miles', 'Miles'], ['km', 'km']], v().unite, u => { changer('unite', u); majCarteFlottante(); }),
          bascule('Rythme', RYTHMES, v().rythme, r => changer('rythme', r), { repliable: true }),
          bonusMonture ? h('label', { class: 'cm-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: v().monture, onchange: e => changer('monture', e.target.checked) }), 'Monture') : null,
          // Brouillard (visibilité), forte neige ou verglas (terrain difficile, au choix du MJ) : un rappel, rien d'automatique.
          horlogeEnService() && meteo ? (l => rappelMeteo(meteo, l.meteo, { nuit: l.moment === 'nuit' }))(lectureHorloge(sHorloge.valeur)) : null,
          iconesItineraire),
        // La carte, sans titre ni légende, ses outils en haut à droite ; « Masquer » la replie (choix gardé dans etat/trajets.json).
        !CARTE ? null
          : v().carte !== false
          ? h('div', { class: 'cm-carte-bloc' }, vueCarte(false), vueLibre())
          : h('div', { class: 'bn-groupe' },
            bouton('Afficher la carte', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-eye', onclick: () => changer('carte', true) }),
            bouton('Agrandir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-maximize-2', onclick: ouvrirCarte })),
        // Le résumé (et le départ) d'abord, puis le détail des tronçons.
        vueTotaux(),
        vueTroncons(),
        vueSuite(),
        h('details', { class: 'cm-repli' },
          h('summary', { class: 'etiquette' }, 'Règles de voyage'),
          h('div', { class: 'cm-pile' },
            d.calcul ? section('Calcul', 'sablier', h('p', { class: 'ui' }, d.calcul.texte), blocOriginal(d.calcul.original)) : null,
            h('ul', { class: 'ui cm-liste' }, d.regles.map(r => h('li', {}, r.texte))),
            d.echelle ? section('Échelle', 'carte', h('p', { class: 'ui-s' }, d.echelle.texte), blocOriginal(d.echelle.original)) : null,
            d.conseil ? h('p', { class: 'aparte cm-sourdine' }, d.conseil) : null,
            provenance(d))),
      ].filter(Boolean));
      ajusterIcones();
      majCarteFlottante();
    }
    rendre();
    sHorloge.abonner(rendre);   // l'heure d'arrivée annoncée suit l'horloge
    s.abonner(rendre);          // itinéraire chargé depuis le Déroulé
    // « Charger dans Trajets » (Déroulé) : déplier le widget et l'amener en vue.
    function voirTrajets() {
      if (!corps.isConnected) { document.removeEventListener('cm:voir-trajets', voirTrajets); return; }
      if (!corps.closest('.cm-tableau')) return;   // dans l'autre mode
      deplier();
      corps.scrollTop = 0;
      corps.closest('.bn-widget')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
    document.addEventListener('cm:voir-trajets', voirTrajets);
    return {};
  },
};
