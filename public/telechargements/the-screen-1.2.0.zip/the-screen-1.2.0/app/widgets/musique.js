// Widget Musique : la musique d'ambiance des playlists YouTube, le son seul. Base : musique/pistes.json, écrite par
// « outils/Importer la musique.cmd » depuis musique/sources.json (formats/musique.md). Lancer, arrêter ; en boucle d'office
// (etat/musique.json, avec les favoris) ; volume propre au poste (gardé dans le navigateur).
// En-tête, même réduit : Lancer / Arrêter, mini-boutons des thèmes (la campagne, la fin, chaque héros de personnages.json ;
// jamais en boucle) et volume.
// Trouver une piste : recherche (nom, titre YouTube, étiquettes, playlist), boutons icônes Thème (par groupe), Lieu (avec
// « Ici », le lieu où sont les héros ; les sous-lieux d'un lieu choisi), PNJ / Faction et Auteur / Playlist (deux vues du
// même menu), clic sur une étiquette d'une ligne, favoris ; un bouton de l'en-tête masque la recherche et les filtres. Le crayon d'une ligne retouche ses étiquettes (corrections de
// etat/musique.json, appliquées par-dessus l'import).
// Le lecteur YouTube est caché hors du widget (voir lecteur()) : la musique continue quand le widget est réduit ou passe
// dans l'autre mode, et s'arrête quand il quitte le tableau.

import { h, icone, bouton, infobulle, alerte, normaliser, deNom, FINE } from '../ui.js';
import { chargerLieux, etatIci, nomLieu } from '../lieux.js';

// Catégories d'étiquettes, dans l'ordre d'une ligne : couleur du badge.
const COULEURS = { lieu: 'brume', pnj: 'ultra', faction: 'cierge', theme: '' };
const ORDRE = Object.keys(COULEURS);
const categorie = id => id.slice(0, id.indexOf(':'));
// Auteur (la chaîne YouTube) d'une playlist ; « nom » le portait avant que les playlists aient chacune un nom.
const auteurDe = src => src?.auteur || src?.nom || '';
const nomSource = src => (src?.auteur ? `${src.auteur} · ${src.nom}` : src?.nom || '');
const CLE_VOLUME = 'cm:musique:volume';
// Pistes à ne jamais jouer : cachées de la liste et des nombres des menus, sauf quand on filtre sur cette étiquette.
// Ajoutée à la base si sources.json ne la déclare pas (autre campagne).
const CACHEE = 'theme:cachee';

// « 52 min », « 1 h 05 », « 2 h 30 » : au-delà d'une heure, à 5 minutes près.
function duree(s) {
  if (!s) return '';
  if (s < 3600) return `${Math.max(1, Math.round(s / 60))}${FINE}min`;
  const m = Math.round(s / 300) * 5;
  return `${Math.floor(m / 60)}${FINE}h` + (m % 60 ? ` ${String(m % 60).padStart(2, '0')}` : '');
}

// ───── Lecteur YouTube ─────
// Un seul pour la page, posé dans <body> : une iframe déplacée dans la page se recharge, et un widget change de place à
// chaque changement de mode. YouTube n'a pas de lecture du son seul : le lecteur fait 200 × 200 px (le minimum demandé par
// YouTube), hors de l'écran, et YouTube choisit la plus petite qualité vidéo pour un si petit lecteur.
let pretApi = null;
let pretLecteur = null;
let joueur = null;
const ecoute = { etat: null, erreur: null };   // le widget monté (unique)

function chargerApi() {
  pretApi ||= new Promise((ok, ko) => {
    if (window.YT?.Player) { ok(window.YT); return; }
    const avant = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => { avant?.(); ok(window.YT); };
    document.head.append(h('script', { src: 'https://www.youtube.com/iframe_api', onerror: () => {
      pretApi = null;
      ko(new Error('YouTube est injoignable : vérifiez la connexion à Internet.'));
    } }));
  });
  return pretApi;
}

function lecteur() {
  pretLecteur ||= chargerApi().then(YT => new Promise(ok => {
    const place = h('div');
    document.body.append(h('div', { class: 'cm-musique-lecteur', 'aria-hidden': 'true' }, place));
    const p = new YT.Player(place, {
      width: 200, height: 200,
      playerVars: { controls: 0, disablekb: 1, fs: 0, iv_load_policy: 3, rel: 0, playsinline: 1, origin: location.origin },
      events: {
        onReady: () => { joueur = p; p.getIframe().tabIndex = -1; ok(p); },
        onStateChange: e => ecoute.etat?.(e.data),
        onError: e => ecoute.erreur?.(e.data),
      },
    });
  })).catch(e => { pretLecteur = null; throw e; });
  return pretLecteur;
}

export default {
  type: 'musique',
  titre: 'Musique',
  surtitre: 'Ambiance',
  icone: 'lu-music',
  description: 'La musique d\'ambiance des playlists YouTube, le son seul, en boucle : par thème (combat, horreur, taverne, village…), lieu, PNJ, faction, auteur ou playlist, pour le lieu où sont les héros, ou parmi vos favoris. Thèmes de la campagne et des héros d\'un clic.',
  taille: { w: 4, h: 10 },
  min: { w: 3, h: 4 },
  unique: true,

  async monter({ corps, actions, resume, donnees, etat }) {
    let base;
    try {
      const r = await fetch('musique/pistes.json', { cache: 'no-store' });
      if (!r.ok) throw new Error(String(r.status));
      base = await r.json();
    } catch {
      corps.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Pas encore de musique',
        'Lancez « outils/Importer la musique.cmd », puis rechargez la page.'));
      return {};
    }
    const s = await etat('musique', { schema: 1, boucle: true, piste: null, favoris: [] });
    const v = () => s.valeur;
    if (!Array.isArray(v().favoris)) v().favoris = [];
    if (!v().corrections || typeof v().corrections !== 'object') v().corrections = {};
    const lieux = await chargerLieux(donnees);
    const sIci = await etatIci(etat, donnees);
    const personnages = (await donnees('personnages')).donnees?.personnages || [];

    if (!base.etiquettes.some(e => e.id === CACHEE)) base.etiquettes.push({ id: CACHEE, nom: 'Cachée', groupe: 'Liste' });
    const noms = new Map(base.etiquettes.map(e => [e.id, e.nom]));
    const rangEtiquette = new Map(base.etiquettes.map((e, i) => [e.id, i]));
    const sources = new Map(base.sources.map(x => [x.id, x]));
    // Étiquettes d'une piste : celles de l'import (importees), retouchées à la main dans le widget (corrections de
    // etat/musique.json : { ajouter, retirer } par id YouTube ; une étiquette inconnue de pistes.json est ignorée).
    function appliquer(p) {
      const c = v().corrections[p.id];
      const set = new Set(p.importees);
      for (const e of c?.retirer || []) set.delete(e);
      for (const e of c?.ajouter || []) if (noms.has(e)) set.add(e);
      p.etiquettes = [...set].sort((a, b) => (rangEtiquette.get(a) ?? 1e6) - (rangEtiquette.get(b) ?? 1e6));
      p.cherche = normaliser([p.nom, p.titre, p.note, ...p.listes.map(l => nomSource(sources.get(l))), ...p.etiquettes.map(e => noms.get(e))].join(' '));
      return p;
    }
    // listes : toutes les playlists de la piste (la première, puis « aussi »).
    const pistes = base.pistes.map((p, rang) => appliquer({ ...p, rang, listes: [p.source, ...(p.aussi || [])], importees: p.etiquettes }));
    const parId = new Map(pistes.map(p => [p.id, p]));
    // Thèmes : ceux de la campagne (début et fin de séance), puis un par héros (sans les compagnons), même sans vidéo encore.
    const themesBase = new Map((base.themes || []).map(t => [t.id, t]));
    const themes = [
      ...(base.themes || []).filter(t => !t.id.startsWith('pj:')),
      ...personnages.filter(p => p.role === 'personnage').map(p => {
        const n = p.nom_court || p.nom;
        return { ...themesBase.get('pj:' + p.id), id: 'pj:' + p.id, nom: `Thème ${deNom(n)}`, initiale: n[0].toUpperCase(), pj: true };
      }),
    ];
    // La piste choisie : de la liste, ou un thème (sans source, jamais en boucle).
    const courante = () => {
      const p = parId.get(v().piste);
      if (p) return p;
      const t = v().piste && themes.find(x => x.video === v().piste);
      return t ? { id: t.video, nom: t.nom, titre: t.titre, duree: t.duree, theme: t } : null;
    };
    const enBoucle = () => !!v().boucle && !courante()?.theme;
    const estFavori = id => v().favoris.includes(id);

    // Lecture : arret, chargement ou lecture. refusees : les vidéos que YouTube a refusé de lire (cette session).
    let lecture = 'arret';
    let message = null;
    const refusees = new Map();
    let volume = 50, volumeAvant = 50;
    try {
      const x = localStorage.getItem(CLE_VOLUME);
      if (x !== null && Number(x) >= 0 && Number(x) <= 100) volume = Number(x);
    } catch { /* pas de stockage : volume par défaut */ }
    if (volume) volumeAvant = volume;

    async function lancer(id) {
      v().piste = id;
      s.enregistrer();
      message = null;
      lecture = 'chargement';
      majLecture();
      try {
        const p = await lecteur();
        if (lecture === 'arret') return;   // arrêté pendant le chargement de YouTube
        p.setVolume(volume);
        p.loadVideoById(id);
      } catch (e) {
        lecture = 'arret';
        message = { texte: e.message };
        majLecture();
      }
    }
    function arreter() {
      lecture = 'arret';
      joueur?.stopVideo();
      majLecture();
    }
    function surEtat(e) {
      if (e === 0) {   // fin de la vidéo
        if (enBoucle() && lecture !== 'arret') { joueur.seekTo(0, true); joueur.playVideo(); } else { lecture = 'arret'; majLecture(); }
      } else if (e === 1) {
        if (lecture === 'arret') { joueur.stopVideo(); return; }   // arrêtée entre-temps
        if (lecture !== 'lecture') { lecture = 'lecture'; majLecture(); }
      } else if (e === 3 && lecture === 'lecture') {
        lecture = 'chargement'; majLecture();
      } else if (e === 2 && lecture !== 'arret') {
        // Pause venue d'ailleurs. Celle qui suit de près un changement de fenêtre ou d'onglet (la page passe en arrière-plan
        // ou en revient), ou qui arrive page cachée, est reprise d'office, trois fois par minute au plus ; une pause qui
        // repart seule ne compte pas ; les autres (touches multimédia, commandes de Chrome) arrêtent la lecture.
        const surChangement = document.hidden || performance.now() - changementDePage < 3000;
        clearTimeout(attentePause);
        attentePause = setTimeout(() => {
          if (lecture === 'arret' || joueur.getPlayerState() !== 2) return;   // arrêtée ici entre-temps, ou repartie seule
          const maintenant = performance.now();
          reprises = reprises.filter(t => maintenant - t < 60000);
          if (surChangement && reprises.length < 3) {
            reprises.push(maintenant);
            console.info('Musique : YouTube a mis la lecture en pause au changement de fenêtre ; reprise.');
            joueur.playVideo();
          } else { lecture = 'arret'; majLecture(); }
        }, 800);
      }
    }
    // Changement de fenêtre ou d'onglet : la page passe en arrière-plan, perd le focus, ou les retrouve.
    let changementDePage = -Infinity, attentePause = null, reprises = [];
    const noterChangement = () => { changementDePage = performance.now(); };
    const evenementsPage = [[document, 'visibilitychange'], [window, 'blur'], [window, 'focus']];
    evenementsPage.forEach(([cible, ev]) => cible.addEventListener(ev, noterChangement));
    function surErreur(code) {
      const texte = code === 101 || code === 150 ? 'Cette vidéo ne se lit que sur YouTube.'
        : code === 100 ? 'Vidéo introuvable : retirée ou devenue privée.'
        : `YouTube refuse la lecture (erreur ${code}).`;
      refusees.set(v().piste, texte);
      lecture = 'arret';
      message = { texte, id: v().piste };
      majLecture();
    }
    ecoute.etat = surEtat;
    ecoute.erreur = surErreur;
    // Widget retiré du tableau (dans aucun des deux modes) : la musique s'arrête.
    const garde = setInterval(() => {
      if (corps.isConnected) return;
      clearInterval(garde);
      evenementsPage.forEach(([cible, ev]) => cible.removeEventListener(ev, noterChangement));
      clearTimeout(attentePause);
      if (ecoute.etat !== surEtat) return;
      ecoute.etat = ecoute.erreur = null;
      joueur?.stopVideo();
    }, 2000);

    // ───── En-tête, même réduit : Lancer / Arrêter, les mini-boutons des thèmes, le volume ─────
    const basculerLecture = () => {
      if (lecture !== 'arret') arreter();
      else if (courante()) lancer(courante().id);
    };
    const btnLecture = bouton('', { classe: 'bn-btn--s cm-musique__mini cm-musique__lecture', onclick: basculerLecture });
    const nomLecteur = h('span', { class: 'cm-musique__nom' });
    const sousLecteur = h('span', { class: 'cm-musique__sous' });
    const btnBoucle = bouton('', { icone: 'lu-repeat', classe: 'bn-btn--s', onclick: () => {
      if (courante()?.theme) return;
      v().boucle = !v().boucle; s.enregistrer(); majLecture();
    } });
    // Mini-boutons des thèmes : icône de la campagne, ou icône de personnage et initiale du héros. Un clic lance le thème
    // (ou l'arrête s'il joue) ; un héros sans thème encore est grisé.
    const boutonsThemes = themes.map(t => {
      const titre = t.video ? `${t.nom} : ${t.titre || t.video}` : `${t.nom} : pas encore choisi (musique/sources.json, puis « Importer la musique »)`;
      return h('button', {
        type: 'button', class: 'bn-btn bn-btn--s cm-musique__mini' + (t.pj ? ' cm-musique__mini--pj' : ''),
        'data-video': t.video || '', 'aria-disabled': t.video ? null : 'true', title: titre, 'aria-label': titre,
        onclick: () => {
          if (!t.video) return;
          if (v().piste === t.video && lecture !== 'arret') arreter(); else lancer(t.video);
        },
      }, t.pj ? [icone('lu-user'), h('span', {}, t.initiale)] : icone(t.icone || 'lu-music'));
    });
    const premierPj = boutonsThemes.findIndex((_, i) => themes[i].pj);
    const zoneThemes = h('span', { class: 'cm-musique__themes', role: 'group', 'aria-label': 'Thèmes de la campagne et des héros' },
      premierPj > 0 ? [boutonsThemes.slice(0, premierPj), h('span', { class: 'cm-musique__sep', 'aria-hidden': 'true' }), boutonsThemes.slice(premierPj)] : boutonsThemes);

    // Volume : l'icône coupe ou remet le son, le curseur à côté règle. En-tête trop étroit : le curseur passe dans une
    // petite fenêtre que l'icône ouvre (avec « Couper le son »).
    const curseurs = [0, 1].map(() => h('input', { type: 'range', class: 'cm-musique__volume', min: '0', max: '100', step: '1', 'aria-label': 'Volume',
      oninput: e => regler(Number(e.target.value)) }));
    const valeurVolume = h('span', { class: 'cm-musique__valeur' });
    const btnMuet = bouton('', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => couper() });
    const popVolume = h('div', { class: 'bn-menu cm-musique__pop-volume', popover: 'auto', role: 'dialog', 'aria-label': 'Volume' }, btnMuet, curseurs[1], valeurVolume);
    const btnSon = bouton('', { classe: 'bn-btn--fantome cm-musique__mini cm-musique__son', onclick: () => {
      if (widget()?.classList.contains('est-volume-replie')) popVolume.togglePopover(); else couper();
    } });
    popVolume.addEventListener('toggle', e => {
      if (e.newState !== 'open') return;
      const r = btnSon.getBoundingClientRect(), m = popVolume.getBoundingClientRect();
      Object.assign(popVolume.style, { left: Math.round(Math.min(r.left, innerWidth - m.width - 8)) + 'px', top: Math.round(r.bottom + 4) + 'px' });
      curseurs[1].focus();
    });
    const couper = () => { if (volume) { volumeAvant = volume; regler(0); } else regler(volumeAvant || 50); };
    function regler(x) {
      volume = x;
      if (x) volumeAvant = x;
      joueur?.setVolume(x);
      try { localStorage.setItem(CLE_VOLUME, String(x)); } catch { /* le réglage vaut pour la session */ }
      majSon();
    }
    function majSon() {
      for (const c of curseurs) { c.value = String(volume); c.title = `Volume : ${volume} %`; }
      valeurVolume.textContent = `${volume}${FINE}%`;
      btnSon.replaceChildren(icone(volume ? 'lu-volume-2' : 'lu-volume-x'));
      const replie = widget()?.classList.contains('est-volume-replie');
      const t = replie ? `Volume : ${volume} % (régler)` : volume ? 'Couper le son' : 'Remettre le son';
      btnSon.title = t;
      btnSon.setAttribute('aria-label', t);
      btnMuet.replaceChildren(icone(volume ? 'lu-volume-x' : 'lu-volume-2'));
      btnMuet.title = volume ? 'Couper le son' : 'Remettre le son';
      btnMuet.setAttribute('aria-label', btnMuet.title);
    }

    // L'en-tête sur une ligne, même étroit : il se resserre d'un cran tant qu'il déborde (le titre ne garde que son icône,
    // puis le curseur du volume passe dans sa fenêtre, puis les héros ne gardent que leur initiale, puis les écarts de
    // l'en-tête se resserrent). Mesuré, sans seuil fixe.
    const widget = () => resume.closest('.bn-widget');
    const NIVEAUX = ['est-titre-icone', 'est-volume-replie', 'est-heros-initiale', 'est-entete-serre'];
    resume.classList.add('cm-musique__resume');
    resume.append(btnLecture, zoneThemes, h('span', { class: 'cm-musique__volume-zone' }, btnSon, curseurs[0]), popVolume);
    function ajusterEntete() {
      const w = widget();
      if (!w || !resume.clientWidth) return;
      w.classList.remove(...NIVEAUX);
      for (const n of NIVEAUX) {
        if (resume.scrollWidth <= resume.clientWidth + 1) break;
        w.classList.add(n);
      }
      majSon();
    }
    const observateur = new ResizeObserver(() => {
      if (!resume.isConnected) return;
      requestAnimationFrame(ajusterEntete);
    });
    observateur.observe(resume);

    function majLecture() {
      const p = courante();
      const joue = lecture !== 'arret';
      btnLecture.replaceChildren(icone(joue ? 'lu-square-plein' : 'lu-play'));
      btnLecture.classList.toggle('bn-btn--primaire', !joue && !!p);
      btnLecture.classList.toggle('est-joue', joue);
      btnLecture.disabled = !p;
      btnLecture.title = joue ? `Arrêter « ${p?.nom} »` : p ? `Lancer « ${p.nom} »` : 'Choisissez une piste dans la liste';
      btnLecture.setAttribute('aria-label', btnLecture.title);
      nomLecteur.textContent = p ? p.nom : 'Aucune piste choisie';
      nomLecteur.classList.toggle('cm-sourdine', !p);
      nomLecteur.title = p?.nom || '';
      if (message && (!message.id || message.id === p?.id)) {
        sousLecteur.className = 'cm-musique__sous est-erreur';
        sousLecteur.replaceChildren(message.texte, message.id ? [' ', h('a', { class: 'bn-lien', href: `https://www.youtube.com/watch?v=${message.id}`, target: '_blank', rel: 'noopener' }, 'Ouvrir sur YouTube')] : '');
      } else {
        sousLecteur.className = 'cm-musique__sous';
        sousLecteur.textContent = !p ? 'Un clic sur une piste la lance.'
          : [lecture === 'chargement' ? 'Chargement…' : lecture === 'lecture' ? 'En cours' : 'À l\'arrêt', duree(p.duree), p.theme ? p.titre : nomSource(sources.get(p.source))].filter(Boolean).join(' · ');
      }
      // Un thème ne boucle jamais : le bouton le dit, sans changer le réglage des autres pistes.
      btnBoucle.setAttribute('aria-pressed', String(enBoucle()));
      btnBoucle.setAttribute('aria-disabled', String(!!p?.theme));
      btnBoucle.title = p?.theme ? 'Les thèmes de la campagne et des héros ne bouclent pas'
        : v().boucle ? 'En boucle : la piste reprend au début (cliquer pour l\'arrêter à la fin)' : 'Lire une fois (cliquer pour lire en boucle)';
      btnBoucle.setAttribute('aria-label', btnBoucle.title);
      for (const b of boutonsThemes) b.classList.toggle('est-joue', !!b.dataset.video && b.dataset.video === p?.id && joue);
      for (const el of liste.querySelectorAll('.cm-morceau')) {
        el.classList.toggle('est-courante', el.dataset.id === p?.id);
        el.classList.toggle('est-jouee', el.dataset.id === p?.id && joue);
        el.classList.toggle('est-refusee', refusees.has(el.dataset.id));
      }
    }

    // ───── Filtres ─────
    // etiquettes : thèmes, lieux, PNJ et factions choisis (une piste doit les porter tous) ; source : un auteur ou une
    // playlist ({ type: 'auteur' | 'playlist', id }), un seul à la fois.
    const filtre = { texte: '', etiquettes: new Set(), ici: false, favoris: false, source: null };
    // Où sont les héros (widget Ici) : le sous-lieu, puis le lieu ; une piste d'un sous-lieu compte pour son lieu.
    const ici = () => [sIci.valeur.sous_lieu, sIci.valeur.lieu].filter(Boolean);
    const lieuDe = e => e.slice(5);
    const parentDe = e => (e.startsWith('lieu:') ? lieux.get(lieuDe(e))?.parent : null);
    const dansIci = p => p.etiquettes.some(e => e.startsWith('lieu:') && (ici().includes(lieuDe(e)) || ici().includes(parentDe(e))));
    const dansSource = (p, src) => !src || (src.type === 'playlist' ? p.listes.includes(src.id) : p.listes.some(l => auteurDe(sources.get(l)) === src.id));
    // sauf : une étiquette, ou toute une catégorie (« lieu »), à ignorer pour compter ce qu'une puce donnerait dans un
    // menu ; ici : forcer le filtre « Ici » ; source : compter avec une autre source (menu Auteur / Playlist).
    function correspond(p, { sauf = null, ici: avecIci = filtre.ici, source = filtre.source } = {}) {
      const mots = normaliser(filtre.texte).split(/\s+/).filter(Boolean);
      return mots.every(m => p.cherche.includes(m))
        && [...filtre.etiquettes].every(e => e === sauf || categorie(e) === sauf || p.etiquettes.includes(e))
        && (!p.etiquettes.includes(CACHEE) || filtre.etiquettes.has(CACHEE) || sauf === CACHEE)
        && (!avecIci || dansIci(p))
        && dansSource(p, source)
        && (!filtre.favoris || estFavori(p.id));
    }
    function filtrees() {
      const l = pistes.filter(p => correspond(p));
      const sous = sIci.valeur.sous_lieu;   // « Ici » dans un sous-lieu : ses pistes d'abord
      if (filtre.ici && sous) l.sort((a, b) => b.etiquettes.includes('lieu:' + sous) - a.etiquettes.includes('lieu:' + sous) || a.rang - b.rang);
      return l;
    }
    // Thèmes cumulables (Combat et Boss) ; un seul lieu, PNJ ou faction à la fois : en choisir un autre remplace le premier.
    const UNIQUES = ['lieu', 'pnj', 'faction'];
    function basculerEtiquette(e, rendu = true) {
      if (filtre.etiquettes.has(e)) filtre.etiquettes.delete(e);
      else {
        if (UNIQUES.includes(categorie(e))) for (const x of filtre.etiquettes) if (categorie(x) === categorie(e)) filtre.etiquettes.delete(x);
        filtre.etiquettes.add(e);
      }
      if (rendu) rendre();
    }

    const recherche = h('input', { class: 'bn-input', type: 'search', placeholder: `Chercher parmi ${pistes.length} pistes`, 'aria-label': 'Chercher une piste',
      oninput: e => { filtre.texte = e.target.value; rendre(); } });
    const btnFavoris = bouton('', { icone: 'lu-star', classe: 'bn-btn--s', onclick: () => { filtre.favoris = !filtre.favoris; rendre(); } });
    const actifs = h('div', { class: 'cm-musique__actifs' });
    const nombre = n => h('span', { class: 'cm-musique__nombre' }, String(n));

    // Menu de filtre : un bouton icône qui ouvre une palette de puces, chacune avec le nombre de pistes qu'elle donnerait
    // avec les autres filtres (celles qui n'en donnent aucune sont cachées). Il reste ouvert : plusieurs choix d'affilée, une
    // puce choisie se retire d'un nouveau clic. Deux vues au plus (PNJ / Factions, Auteur / Playlist) : les onglets du menu
    // passent de l'une à l'autre, comme un nouveau clic sur le bouton quand le menu est ouvert.
    // vues : [{ libelle, icone, titre, actif(), groupes() → [[titre de groupe ou null, puces]] }].
    function menuFiltre(etiquette, vues) {
      let vue = 0;
      const btn = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--icone', 'aria-haspopup': 'dialog' });
      const pop = h('div', { class: 'bn-menu cm-musique__palette', popover: 'auto', role: 'dialog', 'aria-label': etiquette });
      btn.popoverTargetElement = pop;
      const changer = i => { vue = i; remplir(); majBouton(); };
      btn.addEventListener('click', e => {
        if (vues.length > 1 && pop.matches(':popover-open')) { e.preventDefault(); changer((vue + 1) % vues.length); }
      });
      pop.addEventListener('beforetoggle', e => { if (e.newState === 'open') remplir(); });
      pop.addEventListener('toggle', e => {
        btn.setAttribute('aria-expanded', String(e.newState === 'open'));
        if (e.newState !== 'open') return;
        // Sous le bouton, gardé dans l'écran (au-dessus s'il manque de place dessous).
        const r = btn.getBoundingClientRect(), m = pop.getBoundingClientRect();
        const haut = r.bottom + 4 + m.height > innerHeight - 8 ? Math.max(8, r.top - m.height - 4) : r.bottom + 4;
        Object.assign(pop.style, { left: Math.round(Math.max(8, Math.min(r.right - m.width, innerWidth - m.width - 8))) + 'px', top: Math.round(haut) + 'px' });
      });
      function remplir() {
        const x = vues[vue];
        pop.replaceChildren(...[
          vues.length > 1 ? h('div', { class: 'cm-musique__vues', role: 'tablist' }, vues.map((y, i) => h('button', {
            type: 'button', role: 'tab', class: 'cm-musique__vue', 'aria-selected': String(i === vue), onclick: () => changer(i),
          }, icone(y.icone, 'bn-icone--s'), y.libelle, y.actif() ? h('span', { class: 'cm-musique__point', 'aria-label': '(filtre actif)' }) : ''))) : null,
          ...x.groupes().filter(([, puces]) => puces.length).map(([titre, puces]) => h('div', { class: 'cm-musique__groupe' },
            titre ? h('div', { class: 'cm-musique__groupe-titre' }, titre) : null, h('div', { class: 'cm-musique__puces' }, puces))),
        ].filter(Boolean));
        if (!pop.querySelector('.cm-musique__puces')) pop.append(h('p', { class: 'ui cm-sourdine cm-musique__vide' }, 'Rien avec les autres filtres.'));
      }
      function majBouton() {
        const x = vues[vue];
        btn.replaceChildren(icone(x.icone));
        btn.setAttribute('aria-pressed', String(vues.some(y => y.actif())));
        const autre = vues.length > 1 ? ` ; menu ouvert, un autre clic passe ${x.vers}` : '';
        btn.title = x.titre + autre;
        btn.setAttribute('aria-label', btn.title);
      }
      majBouton();
      return { btn, pop, maj: () => { majBouton(); if (pop.matches(':popover-open')) remplir(); } };
    }

    // Une puce de menu : le nom, le nombre de pistes ; enfoncée quand le filtre est actif. couleur : celle des badges.
    const puce = ({ nom, n, actif, couleur = '', ic, titre, action }) => h('button', {
      type: 'button', class: 'cm-musique__choix' + (couleur ? ' cm-musique__choix--' + couleur : ''), 'aria-pressed': String(actif),
      title: titre || (actif ? 'Retirer ce filtre' : null), onclick: () => { action(); rendre(); },
    }, ic ? icone(ic, 'bn-icone--s') : null, h('span', { class: 'cm-musique__choix-nom' }, nom), nombre(n));
    // Les étiquettes d'une catégorie (dans l'ordre de sources.json) qui donnent au moins une piste, ou déjà choisies.
    const choixDe = (cat, garder = () => true) => base.etiquettes.filter(e => categorie(e.id) === cat && garder(e))
      .map(e => ({ ...e, n: pistes.filter(p => p.etiquettes.includes(e.id) && correspond(p, { sauf: UNIQUES.includes(cat) ? cat : e.id })).length }))
      .filter(e => e.n || filtre.etiquettes.has(e.id));
    const puceEtiquette = e => puce({ nom: e.nom, n: e.n, actif: filtre.etiquettes.has(e.id), couleur: COULEURS[categorie(e.id)], action: () => basculerEtiquette(e.id, false) });
    const choisie = cat => [...filtre.etiquettes].some(e => categorie(e) === cat);

    // Thèmes, par groupe (Action, Ambiance, Lieux…).
    const menuTheme = menuFiltre('Thèmes', [{
      libelle: 'Thème', icone: 'lu-tag', titre: 'Filtrer par thème : combat, horreur, taverne, village…', actif: () => choisie('theme'),
      groupes: () => {
        const groupes = new Map();
        for (const e of choixDe('theme')) {
          const g = e.groupe || 'Autres';
          if (!groupes.has(g)) groupes.set(g, []);
          groupes.get(g).push(puceEtiquette(e));
        }
        return [...groupes];
      },
    }]);
    // Lieux : « Ici » (le lieu où sont les héros, widget Ici), les lieux sans leurs sous-lieux, puis les sous-lieux de
    // chaque lieu choisi (ou d'un lieu dont un sous-lieu est choisi).
    const sousLieuConnu = e => { const pa = parentDe(e.id); return pa && noms.has('lieu:' + pa); };
    const menuLieu = menuFiltre('Lieux', [{
      libelle: 'Lieu', icone: 'epingle', actif: () => choisie('lieu') || (filtre.ici && !!(sIci.valeur.sous_lieu || sIci.valeur.lieu)),
      get titre() { const l = sIci.valeur.sous_lieu || sIci.valeur.lieu; return 'Filtrer par lieu' + (l ? ` ; « Ici » : ${nomLieu(lieux, l)}` : ''); },
      groupes: () => {
        const lieu = sIci.valeur.sous_lieu || sIci.valeur.lieu;
        const tete = lieu ? [puce({
          nom: `Ici · ${nomLieu(lieux, lieu)}`, ic: 'epingle', couleur: 'brume', actif: filtre.ici,
          n: pistes.filter(p => correspond(p, { ici: true })).length,
          titre: filtre.ici ? 'Retirer ce filtre' : 'Les pistes du lieu où sont les héros (widget Ici), même quand ils en changent',
          action: () => { filtre.ici = !filtre.ici; },
        })] : [];
        const ouverts = new Set([...filtre.etiquettes].filter(e => e.startsWith('lieu:')).map(e => (sousLieuConnu({ id: e }) ? 'lieu:' + parentDe(e) : e)));
        const sous = [...ouverts].map(l => [`Dans ${noms.get(l)}`, choixDe('lieu', e => parentDe(e.id) === lieuDe(l)).map(puceEtiquette)]);
        return [[null, [...tete, ...choixDe('lieu', e => !sousLieuConnu(e)).map(puceEtiquette)]], ...sous];
      },
    }]);
    // PNJ ou factions : deux vues du même menu.
    const menuPnj = menuFiltre('PNJ et factions', [
      { libelle: 'PNJ', vers: 'aux factions', icone: 'lu-user', titre: 'Filtrer par PNJ', actif: () => choisie('pnj'), groupes: () => [[null, choixDe('pnj').map(puceEtiquette)]] },
      { libelle: 'Factions', vers: 'aux PNJ', icone: 'lu-flag', titre: 'Filtrer par faction', actif: () => choisie('faction'), groupes: () => [[null, choixDe('faction').map(puceEtiquette)]] },
    ]);
    // Auteur (la chaîne) ou playlist : une seule source à la fois ; les playlists rangées par auteur.
    const auteurs = [...new Set(base.sources.map(auteurDe))];
    const puceSource = (type, id, nom) => {
      const src = { type, id };
      const actif = filtre.source?.type === type && filtre.source.id === id;
      return puce({ nom, actif, n: pistes.filter(p => correspond(p, { source: src })).length, action: () => { filtre.source = actif ? null : src; } });
    };
    const menuSource = menuFiltre('Auteurs et playlists', [
      { libelle: 'Auteurs', vers: 'aux playlists', icone: 'lu-music', titre: 'Filtrer par auteur', actif: () => filtre.source?.type === 'auteur',
        groupes: () => [[null, auteurs.map(a => puceSource('auteur', a, a))]] },
      { libelle: 'Playlists', vers: 'aux auteurs', icone: 'lu-list-music', titre: 'Filtrer par playlist', actif: () => filtre.source?.type === 'playlist',
        groupes: () => auteurs.map(a => [a, base.sources.filter(x => auteurDe(x) === a).map(x => puceSource('playlist', x.id, x.auteur ? x.nom : x.titre || x.nom))]) },
    ]);
    const menus = [menuTheme, menuLieu, menuPnj, menuSource];

    let majZoneFiltres = () => {};   // le bouton d'en-tête qui masque les filtres (plus bas)
    function rendreFiltres() {
      for (const m of menus) m.maj();
      majZoneFiltres();
      const lieu = sIci.valeur.sous_lieu || sIci.valeur.lieu;
      const nFav = v().favoris.filter(id => parId.has(id)).length;
      btnFavoris.setAttribute('aria-pressed', String(filtre.favoris));
      btnFavoris.title = filtre.favoris ? 'Montrer toutes les pistes' : nFav ? `Seulement les favoris (${nFav})` : 'Seulement les favoris (aucun encore : l\'étoile au bout d\'une ligne en ajoute un)';
      btnFavoris.setAttribute('aria-label', btnFavoris.title);

      // Filtres actifs : chacun se retire d'un clic.
      const retrait = (couleur, contenu, retirer) => h('button', { type: 'button', class: `bn-badge cm-musique__etiquette ${couleur ? 'bn-badge--' + couleur : ''}`, title: 'Retirer ce filtre', onclick: retirer }, contenu, icone('lu-x'));
      const n = filtrees().length;
      const src = filtre.source && (filtre.source.type === 'auteur' ? filtre.source.id : nomSource(sources.get(filtre.source.id)));
      actifs.hidden = !(filtre.ici || filtre.favoris || filtre.source || filtre.etiquettes.size || filtre.texte.trim());
      actifs.replaceChildren(...[
        filtre.favoris ? retrait('cierge', [icone('lu-star-plein'), 'Favoris'], () => { filtre.favoris = false; rendre(); }) : null,
        filtre.ici && lieu ? retrait('brume', [icone('epingle'), 'Ici'], () => { filtre.ici = false; rendre(); }) : null,
        ...[...filtre.etiquettes].sort((a, b) => ORDRE.indexOf(categorie(a)) - ORDRE.indexOf(categorie(b)))
          .map(e => retrait(COULEURS[categorie(e)], noms.get(e) || e, () => basculerEtiquette(e))),
        src ? retrait('', [icone(filtre.source.type === 'auteur' ? 'lu-music' : 'lu-list-music'), src], () => { filtre.source = null; rendre(); }) : null,
        h('span', { class: 'cm-musique__compte' }, `${n} sur ${pistes.length}`),
        bouton('', { icone: 'lu-x', classe: 'bn-btn--s bn-btn--fantome', titre: 'Effacer la recherche et les filtres', onclick: () => {
          filtre.texte = ''; recherche.value = ''; filtre.etiquettes.clear(); filtre.ici = false; filtre.favoris = false; filtre.source = null; rendre();
        } }),
      ].filter(Boolean));
    }

    // Favoris : gardés dans etat/musique.json (la campagne, pas le poste).
    function basculerFavori(id) {
      v().favoris = estFavori(id) ? v().favoris.filter(x => x !== id) : [...v().favoris, id];
      s.enregistrer();
      if (filtre.favoris) { rendre(); return; }
      rendreFiltres();
      const b = liste.querySelector(`.cm-morceau[data-id="${CSS.escape(id)}"] .cm-morceau__favori`);
      if (b) b.replaceWith(boutonFavori(id));
    }
    function boutonFavori(id) {
      const fav = estFavori(id);
      return h('button', {
        type: 'button', class: 'cm-morceau__favori' + (fav ? ' est-favori' : ''), 'aria-pressed': String(fav),
        title: fav ? 'Retirer des favoris' : 'Ajouter aux favoris', 'aria-label': fav ? 'Retirer des favoris' : 'Ajouter aux favoris',
        onclick: () => basculerFavori(id),
      }, icone(fav ? 'lu-star-plein' : 'lu-star', 'bn-icone--s'));
    }

    // ───── Liste ─────
    const liste = h('div', { class: 'cm-musique__liste', role: 'list' });
    // Étiquettes d'une ligne, dans cet ordre : le lieu (son sous-lieu à sa place), les PNJ, les factions, puis les thèmes.
    // Une faction cède la place à un PNJ (qui la porte) ou au lieu du même nom (l'abbaye). La recherche et les menus les
    // trouvent toutes.
    function etiquettesDe(p) {
      const sousLieux = new Set(p.etiquettes.map(parentDe).filter(Boolean));
      const nomsLieux = new Set(p.etiquettes.filter(e => e.startsWith('lieu:')).map(e => noms.get(e)));
      const aPnj = p.etiquettes.some(e => e.startsWith('pnj:'));
      return p.etiquettes
        .filter(e => !(e.startsWith('lieu:') && sousLieux.has(lieuDe(e))) && !(e.startsWith('faction:') && (aPnj || nomsLieux.has(noms.get(e)))))
        .sort((a, b) => ORDRE.indexOf(categorie(a)) - ORDRE.indexOf(categorie(b)));
    }
    function ligne(p) {
      const src = sources.get(p.source);
      const nom = h('button', { type: 'button', class: 'cm-morceau__nom' }, p.nom);
      const aussi = (p.aussi || []).map(l => sources.get(l)?.nom).filter(Boolean);
      infobulle(nom, [p.titre, p.note, aussi.length ? `Aussi dans : ${aussi.join(', ')}` : ''].filter(Boolean).join(' · '),
        { titre: nomSource(src) + (src?.qualite === 'moindre' ? ' (qualité moindre)' : '') });
      return h('div', { class: 'cm-morceau' + (estFavori(p.id) ? ' est-favori' : '') + (p.etiquettes.includes(CACHEE) ? ' est-cachee' : ''), role: 'listitem', 'data-id': p.id, onclick: e => {
        if (e.target.closest('.cm-musique__etiquette, .cm-morceau__favori, .cm-morceau__retouche')) return;
        if (p.id === v().piste && lecture !== 'arret') arreter(); else lancer(p.id);
      } },
        h('span', { class: 'cm-morceau__icone' }, icone('lu-volume-2', 'bn-icone--s cm-morceau__joue'), icone('lu-triangle-alert', 'bn-icone--s cm-morceau__refus')),
        nom,
        h('span', { class: 'cm-morceau__duree' }, duree(p.duree)),
        h('span', { class: 'cm-morceau__etiquettes' }, etiquettesDe(p).map(e => h('button', {
          type: 'button', class: `bn-badge cm-musique__etiquette ${COULEURS[categorie(e)] ? 'bn-badge--' + COULEURS[categorie(e)] : ''}`,
          'aria-pressed': String(filtre.etiquettes.has(e)), title: filtre.etiquettes.has(e) ? 'Retirer ce filtre' : 'Ne garder que les pistes « ' + noms.get(e) + ' »',
          onclick: () => basculerEtiquette(e),
        }, noms.get(e) || e))),
        h('span', { class: 'cm-morceau__source' + (src?.qualite === 'moindre' ? ' est-moindre' : ''), title: src?.qualite === 'moindre' ? 'Qualité moindre' : null }, auteurDe(src).split(' ')[0]),
        boutonFavori(p.id),
        h('button', {
          type: 'button', class: 'cm-morceau__retouche' + (v().corrections[p.id] ? ' est-retouchee' : ''),
          title: v().corrections[p.id] ? 'Étiquettes retouchées à la main : les modifier' : 'Modifier les étiquettes',
          'aria-label': 'Modifier les étiquettes', onclick: e => ouvrirRetouche(p, e.currentTarget),
        }, icone('lu-pencil', 'bn-icone--s')));
    }

    // ───── Retouche des étiquettes d'une piste ─────
    // Le crayon d'une ligne ouvre la palette de la piste : toutes les étiquettes de pistes.json par catégorie (thèmes par
    // groupe), celles de la piste enfoncées, un point sur celles qui diffèrent de l'import ; un clic ajoute ou retire.
    // Gardé dans corrections de etat/musique.json (seulement l'écart à l'import), appliqué par-dessus chaque import.
    // « Rétablir » rend à la piste les étiquettes de l'import.
    const popRetouche = h('div', { class: 'bn-menu cm-musique__palette', popover: 'auto', role: 'dialog', 'aria-label': 'Étiquettes de la piste' });
    let enRetouche = null;
    function ouvrirRetouche(p, ancre) {
      enRetouche = p;
      remplirRetouche();
      popRetouche.showPopover();
      const r = ancre.getBoundingClientRect(), m = popRetouche.getBoundingClientRect();
      const haut = r.bottom + 4 + m.height > innerHeight - 8 ? Math.max(8, r.top - m.height - 4) : r.bottom + 4;
      Object.assign(popRetouche.style, { left: Math.round(Math.max(8, Math.min(r.right - m.width, innerWidth - m.width - 8))) + 'px', top: Math.round(haut) + 'px' });
    }
    function retoucher(p, e) {
      const set = new Set(p.etiquettes);
      if (set.has(e)) set.delete(e); else set.add(e);
      const importees = new Set(p.importees);
      const c = { ajouter: [...set].filter(x => !importees.has(x)), retirer: p.importees.filter(x => !set.has(x)) };
      if (c.ajouter.length || c.retirer.length) v().corrections[p.id] = c; else delete v().corrections[p.id];
      majRetouche(p);
    }
    function majRetouche(p) {
      s.enregistrer();
      appliquer(p);
      remplirRetouche();
      rendreFiltres();
      // La ligne seule est refaite (même si elle ne correspond plus aux filtres : elle part au prochain rendu).
      const el = liste.querySelector(`.cm-morceau[data-id="${CSS.escape(p.id)}"]`);
      if (el) { el.replaceWith(ligne(p)); majLecture(); }
    }
    function remplirRetouche() {
      const p = enRetouche;
      if (!p) return;
      const importees = new Set(p.importees);
      const choix = e => {
        const a = p.etiquettes.includes(e.id);
        const change = a !== importees.has(e.id);
        return h('button', {
          type: 'button', class: 'cm-musique__choix' + (COULEURS[categorie(e.id)] ? ' cm-musique__choix--' + COULEURS[categorie(e.id)] : '') + (change ? ' est-retouchee' : ''),
          'aria-pressed': String(a), title: change ? (a ? 'Ajoutée à la main' : 'Retirée à la main') + ' ; un clic pour rétablir' : a ? 'Retirer' : 'Ajouter',
          onclick: () => retoucher(p, e.id),
        }, h('span', { class: 'cm-musique__choix-nom' }, e.nom));
      };
      const groupes = new Map();
      for (const e of base.etiquettes) {
        if (e.id === CACHEE) continue;   // le bouton Cacher de l'en-tête
        const cat = categorie(e.id);
        // Clé propre à la catégorie : le groupe de thèmes « Lieux » (Ville, Château…) n'est pas celui des lieux nommés.
        const g = cat === 'theme' ? 'theme:' + (e.groupe || 'Thèmes') : cat;
        if (!groupes.has(g)) groupes.set(g, []);
        groupes.get(g).push(choix(e));
      }
      const titreGroupe = g => (g.startsWith('theme:') ? g.slice(6) : { lieu: 'Lieux de la campagne', pnj: 'PNJ', faction: 'Factions' }[g]);
      popRetouche.replaceChildren(
        h('div', { class: 'cm-musique__retouche-tete' },
          h('span', { class: 'cm-musique__retouche-nom' }, p.nom),
          // Cacher : l'étiquette « Cachée », la piste quitte la liste au prochain rendu (filtre Thème › Cachée pour la revoir).
          p.etiquettes.includes(CACHEE)
            ? bouton('Montrer', { icone: 'lu-eye', classe: 'bn-btn--s bn-btn--fantome', titre: 'Remettre la piste dans la liste', onclick: () => retoucher(p, CACHEE) })
            : bouton('Cacher', { icone: 'lu-eye-off', classe: 'bn-btn--s bn-btn--fantome', titre: 'Ne plus montrer cette piste dans la liste (Thème › Cachée pour la revoir)', onclick: () => retoucher(p, CACHEE) }),
          v().corrections[p.id] ? bouton('Rétablir', { icone: 'lu-rotate-ccw', classe: 'bn-btn--s bn-btn--fantome', titre: 'Rendre à la piste les étiquettes de l\'import',
            onclick: () => { delete v().corrections[p.id]; majRetouche(p); } }) : ''),
        ...[...groupes].map(([g, puces]) => h('div', { class: 'cm-musique__groupe' },
          h('div', { class: 'cm-musique__groupe-titre' }, titreGroupe(g)), h('div', { class: 'cm-musique__puces' }, puces))));
    }
    popRetouche.addEventListener('toggle', e => { if (e.newState !== 'open') enRetouche = null; });
    function rendreListe() {
      const l = filtrees();
      const seul = !filtre.etiquettes.size && !filtre.texte.trim();
      liste.replaceChildren(...(l.length ? l.map(ligne)
        : [h('p', { class: 'ui cm-sourdine cm-musique__vide' },
          filtre.favoris && !v().favoris.length ? 'Pas encore de favori : l\'étoile au bout d\'une ligne en ajoute un.'
          : filtre.ici && seul && !filtre.favoris ? `Aucune piste pour ${nomLieu(lieux, sIci.valeur.sous_lieu || sIci.valeur.lieu)}.`
          : 'Aucune piste ne correspond.')]));
      majLecture();
    }
    function rendre() { rendreFiltres(); rendreListe(); }
    sIci.abonner(() => rendre());

    corps.classList.add('cm-musique');
    // Les menus hors de la zone des filtres : la retouche (crayon d'une ligne) s'ouvre aussi quand elle est masquée.
    const zoneFiltres = h('div', { class: 'cm-musique__filtres' },
      h('div', { class: 'cm-musique__ligne' }, h('div', { class: 'cm-recherche' }, icone('lu-search', 'bn-icone--s'), recherche),
        h('div', { class: 'cm-musique__boutons' }, menus.map(m => m.btn), btnFavoris)),
      actifs);
    corps.replaceChildren(
      h('div', { class: 'cm-musique__lecteur' },
        h('span', { class: 'cm-musique__titres' }, nomLecteur, sousLecteur),
        btnBoucle),
      zoneFiltres,
      liste,
      h('div', { class: 'cm-musique__menus' }, menus.map(m => m.pop), popRetouche));

    // Bouton de l'en-tête (widget déplié) : masque la recherche et les filtres, orange quand ils cachent un filtre actif.
    // Choix propre au poste, gardé dans le navigateur.
    const CLE_FILTRES = 'cm:musique:filtres';
    let filtresVisibles = true;
    try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* pas de stockage : visibles */ }
    const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      filtresVisibles = !filtresVisibles;
      try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* le choix vaut pour la session */ }
      majZoneFiltres();
      requestAnimationFrame(ajusterEntete);
    } });
    majZoneFiltres = () => {
      const filtresActifs = !!(filtre.texte.trim() || filtre.etiquettes.size || filtre.ici || filtre.favoris || filtre.source);
      zoneFiltres.hidden = !filtresVisibles;
      corps.classList.toggle('est-sans-filtres', !filtresVisibles);
      btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
      btnFiltres.classList.toggle('est-filtre', !filtresVisibles && filtresActifs);
      const titre = (filtresVisibles ? 'Masquer la recherche et les filtres' : 'Afficher la recherche et les filtres') + (!filtresVisibles && filtresActifs ? ' (des filtres sont actifs)' : '');
      btnFiltres.title = titre;
      btnFiltres.setAttribute('aria-label', titre);
    };
    actions.prepend(btnFiltres);
    majZoneFiltres();
    majSon();
    rendre();
    requestAnimationFrame(ajusterEntete);
    // Ouvert sur la piste choisie.
    requestAnimationFrame(() => {
      const el = liste.querySelector('.est-courante');
      if (el) liste.scrollTop = el.offsetTop - 8;
    });
    return {};
  },
};
