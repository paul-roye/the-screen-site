// Widget Faune : les animaux de la campagne par milieu, et une bête tirée au hasard.
// Données : data/faune.json (formats/faune.md). Rien n'est enregistré.

import { h, icone, bouton, alerte, bascule, section, provenance } from '../ui.js';
import { auHasard } from '../des.js';

const CATEGORIES = [
  ['predateurs', 'Prédateur', 'Prédateurs', 'griffe'],
  ['gibier', 'Gibier', 'Gibier', 'loup'],
  ['oiseaux', 'Oiseau', 'Oiseaux', 'corbeau'],
  ['autres', 'Autre', 'Autres', 'chauve-souris'],
];

export default {
  type: 'faune',
  requiert: 'faune',
  titre: 'Faune',
  icone: 'corbeau',
  description: 'Les animaux des bois, des marais et des montagnes, et un prédateur, un gibier ou un oiseau tiré au hasard.',
  taille: { w: 4, h: 9 },
  min: { w: 3, h: 5 },
  unique: true,

  async monter({ corps, donnees }) {
    const lecture = await donnees('faune');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Faune indisponible', lecture.problemes.join(' ')));
      return {};
    }
    const d = lecture.donnees;
    let milieu = d.milieux[0].id;
    let tirage = null;   // { categorie, animal, milieu }

    function tirer(cat) {
      const m = d.milieux.find(x => x.id === milieu);
      if (!m[cat]?.length) return;
      tirage = { categorie: cat, animal: auHasard(m[cat]), milieu };
      rendre();
    }

    function rendre() {
      const m = d.milieux.find(x => x.id === milieu);
      const libelle = id => CATEGORIES.find(c => c[0] === id);
      const actuel = tirage?.milieu === milieu ? tirage : null;
      const dom = d.animaux_domestiques;
      corps.replaceChildren(...[
        d.milieux.length > 1 ? bascule('Milieu', d.milieux.map(x => [x.id, x.nom]), milieu, id => { milieu = id; rendre(); }) : null,
        h('div', { class: 'bn-groupe' }, CATEGORIES.filter(([id]) => m[id]?.length).map(([id, un, , ic]) =>
          bouton(un, { icone: ic, classe: 'bn-btn--s' + (actuel?.categorie === id ? ' bn-btn--primaire' : ''), onclick: () => tirer(id), titre: `Tirer un ${un.toLowerCase()} au hasard (${m.nom})` }))),
        h('div', { class: 'bn-carte cm-nom', 'aria-live': 'polite' }, actuel
          ? [h('span', { class: 'surtitre' }, `${libelle(actuel.categorie)[1]} · ${m.nom}`), h('p', { class: 'cm-tirage-gros' }, actuel.animal.charAt(0).toUpperCase() + actuel.animal.slice(1))]
          : h('p', { class: 'ui cm-sourdine' }, 'Choisissez un milieu, puis tirez une bête.')),
        CATEGORIES.map(([id, , plusieurs, ic]) => m[id]?.length
          ? section(plusieurs, ic, h('ul', { class: 'cm-puces' }, m[id].map(a => h('li', { class: actuel?.animal === a && actuel.categorie === id ? 'cm-puce--choisie' : null }, a))))
          : null),
        (dom || d.poissons?.length) ? h('details', { class: 'cm-repli' },
          h('summary', { class: 'etiquette' }, 'Au village et dans l\'eau'),
          h('div', { class: 'cm-pile' },
            dom?.elevage?.length ? section('Élevage', null, h('ul', { class: 'cm-puces' }, dom.elevage.map(a => h('li', {}, a)))) : null,
            dom?.compagnie_et_travail?.length ? section('Compagnie et travail', null, h('ul', { class: 'cm-puces' }, dom.compagnie_et_travail.map(a => h('li', {}, a)))) : null,
            d.poissons?.length ? section('Poissons', null, h('ul', { class: 'cm-puces' }, d.poissons.map(a => h('li', {}, a)))) : null)) : null,
        d.notes?.length ? h('ul', { class: 'aparte cm-liste cm-sourdine' }, d.notes.map(n => h('li', {}, n))) : null,
        provenance(d),
      ].flat().filter(Boolean));
    }
    rendre();
    return {};
  },
};
