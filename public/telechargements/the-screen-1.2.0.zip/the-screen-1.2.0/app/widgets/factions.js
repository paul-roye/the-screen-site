// Widget Factions : les factions de la campagne par type, sur deux colonnes ou plus si la place le permet ; un clic ouvre la
// fiche de la faction (description, lieux, membres triés par rang) dans une fenêtre flottante.
// Les factions secrètes sont masquées tant que le MJ ne demande pas à les voir.
// Chaque membre a son bouton « Vu » (déjà rencontré, etat/pnj.json, partagé avec PNJ et Ici).
// Données : data/factions.json (formats/factions.md), data/pnj.json (champ factions).

import { h, icone, alerte, lienFlottant } from '../ui.js';
import { chargerLieux } from '../lieux.js';
import { etatPnj, chargerFactions, badgeFaction, membresFaction, ouvrirFaction } from '../fiche-pnj.js';

export default {
  type: 'factions',
  requiert: 'factions',
  titre: 'Factions',
  icone: 'bouclier',
  description: 'Les factions, peuples et assemblées de la campagne : ce qu\'elles veulent, où elles sont, et leurs membres du plus important au plus discret.',
  taille: { w: 4, h: 14 },
  min: { w: 3, h: 6 },
  unique: true,

  async monter({ corps, donnees, etat }) {
    const lecture = await donnees('factions');
    if (lecture.statut !== 'ok') {
      corps.append(alerte(lecture.statut === 'absent' ? 'cierge' : 'sang', 'lu-database', 'Factions indisponibles', lecture.problemes.join(' ')));
      return {};
    }
    const factions = await chargerFactions(donnees);
    const lieux = await chargerLieux(donnees);
    const donneesPnj = (await donnees('pnj')).donnees;
    const pnj = donneesPnj?.pnj || [];
    const sPnj = await etatPnj(etat);
    let secrets = false;

    // Une ligne par faction : son badge et le nombre de PNJ ; un clic ouvre sa fiche.
    function ligneFaction(f) {
      return lienFlottant(h('button', { type: 'button', class: 'cm-faction-ligne cm-ouvre', title: 'Ouvrir la fiche de la faction',
        onclick: () => ouvrirFaction(f, { pnj, s: sPnj, lieux, factions, typesRang: donneesPnj?.types_rang }) },
      badgeFaction(f), h('span', { class: 'ui-s cm-sourdine' }, `${membresFaction(f, pnj, sPnj).length} PNJ`)), 'faction:' + f.id);
    }

    function rendre() {
      const haut = corps.scrollTop;
      const nbSecretes = factions.liste.filter(f => f.secret).length;
      corps.replaceChildren(...[
        nbSecretes ? h('label', { class: 'cm-case', title: 'Jamais côté joueurs' },
          h('input', { type: 'checkbox', class: 'bn-case', checked: secrets, onchange: e => { secrets = e.target.checked; rendre(); } }),
          icone('lu-eye-off', 'bn-icone--s'), ` Afficher les factions secrètes (${nbSecretes})`) : null,
        h('div', { class: 'cm-factions' }, Object.entries(factions.types).map(([type, libelle]) => {
          const fs = factions.liste.filter(f => f.type === type && (secrets || !f.secret));
          return fs.length ? h('section', { class: 'cm-factions__type' }, h('p', { class: 'etiquette' }, libelle), h('div', { class: 'cm-factions__liste' }, fs.map(ligneFaction))) : null;
        })),
      ].flat().filter(Boolean));
      corps.scrollTop = haut;
    }
    rendre();
    sPnj.abonner(rendre);
    return {};
  },
};
