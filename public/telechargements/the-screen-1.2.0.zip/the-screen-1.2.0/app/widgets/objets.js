// Widget Objets : tous les objets de la campagne (data/objets.json, formats/objets.md) et ceux que le MJ a créés, dans l'ordre
// de la campagne ; recherche (nom français ou anglais), filtres (état, genre, lieu), « + Objet ». Un clic ouvre la fenêtre
// d'un objet : l'objet de D&D Beyond ou personnalisé, « Donner » à un héros ou au groupe (app/objets.js).
// Dans l'en-tête, même réduit : combien d'objets restent à donner là où sont les héros.
// État : etat/objets.json (formats/etat.md), partagé avec Ici, le Déroulé et les rencontres.

import { h, icone, bouton, alerte, normaliser, infobulle } from '../ui.js';
import { outilsObjets, GENRES } from '../objets.js';
import { chargerLieux, etatIci, nomLieu } from '../lieux.js';

const ETATS = [['', 'Tous'], ['a-donner', 'À donner'], ['donne', 'Donnés']];

export default {
  type: 'objets',
  titre: 'Objets',
  icone: 'amulette',
  description: 'Les objets à trouver dans la campagne (magiques, équipement, trésors, documents) : l\'objet de D&D Beyond qui leur correspond ou un objet personnalisé, et « Donner » à un héros ou au groupe, jusque dans l\'inventaire D&D Beyond.',
  taille: { w: 4, h: 14 },
  min: { w: 3, h: 6 },
  unique: true,

  async monter({ corps, actions, resume, donnees, etat, dialogue }) {
    const O = await outilsObjets({ donnees, etat, dialogue });
    const lieux = await chargerLieux(donnees);
    const sIci = await etatIci(etat, donnees);
    const filtre = { texte: '', etat: '', genre: '', lieu: '', ici: false };
    const liste = h('div', { class: 'cm-objets-liste' });
    const compteur = h('span', { class: 'ui-s cm-sourdine' });

    const recherche = h('input', { class: 'bn-input', type: 'search', placeholder: 'Nom français ou anglais', 'aria-label': 'Chercher un objet',
      oninput: e => { filtre.texte = e.target.value; rendreListe(); } });
    const selects = {};
    const choix = (cle, options, etiquette, ic) => h('span', { class: 'cm-filtre', title: etiquette }, icone(ic, 'bn-icone--s'),
      selects[cle] = h('select', { class: 'bn-select', 'aria-label': etiquette, onchange: e => { filtre[cle] = e.target.value; rendreListe(); majFiltres(); } },
        options.map(([val, lib]) => h('option', { value: val }, lib))));
    // « Ici » (demande du MJ, 2026-10-25) : les objets du lieu où sont les héros, sous-lieux compris ; il remplace le choix du lieu.
    const btnIci = infobulle(bouton('', { icone: 'epingle', classe: 'bn-btn--s bn-btn--fantome cm-filtre-bouton', onclick: () => { filtre.ici = !filtre.ici; rendreListe(); majFiltres(); } }),
      'Seulement les objets du lieu où sont les héros (sous-lieux compris).', { titre: 'Ici' });
    btnIci.setAttribute('aria-label', 'Ici');
    const lieuxPrincipaux = [...lieux.values()].filter(l => !l.parent).sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));
    const filtres = h('div', { class: 'cm-pnj-filtres' },
      h('div', { class: 'cm-filtres-ligne' }, h('div', { class: 'cm-recherche' }, icone('lu-search', 'bn-icone--s'), recherche), btnIci),
      h('div', { class: 'cm-pnj-selects' },
        choix('etat', ETATS, 'État', 'lu-gift'),
        choix('genre', [['', 'Tous les genres'], ...Object.entries(GENRES).map(([k, [lib]]) => [k, lib])], 'Genre', 'lu-box'),
        choix('lieu', [['', 'Tous les lieux'], ...lieuxPrincipaux.map(l => [l.id, l.nom])], 'Lieu', 'epingle')));

    // Recherche et filtres masquables (comme PNJ) ; masqués, ils filtrent encore : le bouton le rappelle en orange.
    const CLE_FILTRES = 'cm:objets:filtres';
    let filtresVisibles = true;
    try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* pas de stockage : visibles */ }
    const filtresActifs = () => !!(filtre.texte.trim() || filtre.etat || filtre.genre || filtre.lieu || filtre.ici);
    const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      filtresVisibles = !filtresVisibles;
      try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* le choix vaut pour la session */ }
      majFiltres();
    } });
    function majFiltres() {
      filtres.hidden = !filtresVisibles;
      btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
      btnFiltres.classList.toggle('est-filtre', !filtresVisibles && filtresActifs());
      const titre = (filtresVisibles ? 'Masquer la recherche et les filtres' : 'Afficher la recherche et les filtres') + (!filtresVisibles && filtresActifs() ? ' (des filtres sont actifs)' : '');
      btnFiltres.title = titre;
      btnFiltres.setAttribute('aria-label', titre);
      btnIci.setAttribute('aria-pressed', String(filtre.ici));
      selects.lieu.disabled = filtre.ici;
    }
    actions.prepend(btnFiltres);

    const garde = vue => {
      const mots = normaliser(filtre.texte).split(/\s+/).filter(Boolean);
      const texte = normaliser(`${vue.nom} ${vue.nom_en} ${vue.o?.nom_joueurs || ''} ${vue.beyond?.nom || ''}`);
      if (!mots.every(m => texte.includes(m))) return false;
      if (filtre.etat === 'a-donner' && vue.statut === 'donne') return false;
      if (filtre.etat === 'donne' && vue.statut === 'a-donner') return false;
      if (filtre.genre && vue.genre !== filtre.genre) return false;
      const lieu = filtre.ici ? sIci.valeur.lieu : filtre.lieu;
      if (filtre.ici && !lieu) return false;
      if (lieu && O.duLieu(lieu).every(x => x.id !== vue.id)) return false;
      return true;
    };

    function rendreListe() {
      const toutes = O.tous();
      const vues = toutes.filter(garde);
      liste.replaceChildren(...(vues.length ? vues.map(vue => O.ligne(vue, { ou: true }))
        : [h('p', { class: 'ui-s cm-sourdine' }, toutes.length ? 'Aucun objet ne correspond.' : 'Pas encore d\'objet.')]));
      compteur.textContent = vues.length === toutes.length ? `${toutes.length} objet${toutes.length > 1 ? 's' : ''}` : `${vues.length} sur ${toutes.length}`;
    }

    // En-tête : objets à donner là où sont les héros (lieu général, sous-lieux compris).
    function majResume() {
      const lieu = sIci.valeur.lieu;
      const n = lieu ? O.duLieu(lieu).filter(x => x.statut !== 'donne').length : 0;
      resume.replaceChildren(...(n ? [h('span', { class: 'cm-objets-resume', title: `${n} objet${n > 1 ? 's' : ''} à donner à ${nomLieu(lieux, lieu)}` }, icone('amulette', 'bn-icone--s'), `${n} ici`)] : []));
    }

    function rendre() {
      const haut = corps.scrollTop;
      rendreListe();
      majResume();
      corps.replaceChildren(...[
        O.donneesPresentes ? null : alerte('cierge', 'lu-database', 'Objets de la campagne pas encore exportés',
          'data/objets.json manque : écrivez-le, à la main ou avec votre agent IA de campagne (format : formats/objets.md). Les objets créés ici restent utilisables.'),
        filtres,
        liste,
        h('div', { class: 'cm-contexte' }, O.boutonNouveau({}, { libelle: 'Objet', classe: 'bn-btn--s' }), compteur),
      ].filter(Boolean));
      corps.scrollTop = haut;
    }

    majFiltres();
    rendre();
    O.s.abonner(rendre);
    sIci.abonner(() => { majResume(); if (filtre.ici) rendreListe(); });
    return {};
  },
};
