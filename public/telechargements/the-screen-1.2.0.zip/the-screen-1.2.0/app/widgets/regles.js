// Widget Règles : questions de règles de D&D 2024 (SRD 5.2.1, VF et VO), posées à l'agent du service de règles
// (regles/serveur.py, http://localhost:8736 par défaut : port réglé par « regles.port » de poste.json).
// L'agent cherche dans les PDF des règles indexés et répond en citant ses pages ; « Recherche seule » interroge
// l'index sans modèle (instantané, et marche sans Ollama ni clé). Une citation ouvre le PDF à sa page ; une source
// ouvre sa section entière en fenêtre flottante.
// État : etat/regles.json (formats/etat.md) : conversation en cours et derniers échanges.

import { h, icone, bouton, alerte, flottant, lienFlottant, identifiant } from '../ui.js';

const ECHANGES_MAX = 40;
const SIGLES = { fr: 'DRS', en: 'SRD' };

async function adresseService() {
  try {
    const poste = await fetch('poste.json', { cache: 'no-store' }).then(r => r.ok ? r.json() : {});
    return `http://localhost:${poste?.regles?.port || 8736}`;
  } catch { return 'http://localhost:8736'; }
}

// Flux SSE d'une réponse POST : rend { evenement, donnees } au fil de l'eau.
async function* lireFlux(reponse) {
  const lecteur = reponse.body.pipeThrough(new TextDecoderStream()).getReader();
  let tampon = '';
  for (;;) {
    const { value, done } = await lecteur.read();
    if (done) return;
    tampon += value.replace(/\r\n/g, '\n');
    let fin;
    while ((fin = tampon.indexOf('\n\n')) >= 0) {
      const bloc = tampon.slice(0, fin);
      tampon = tampon.slice(fin + 2);
      const evenement = /^event: (.*)$/m.exec(bloc)?.[1];
      const donnees = /^data: (.*)$/m.exec(bloc)?.[1];
      if (evenement && donnees) yield { evenement, donnees: JSON.parse(donnees) };
    }
  }
}

export default {
  type: 'regles',
  titre: 'Règles',
  icone: 'livre',
  description: 'Questions de règles de D&D 2024 : un agent cherche dans le SRD 5.2.1 (VF et VO) et répond en citant ses pages. Service local : regles/.',
  taille: { w: 4, h: 12 },
  min: { w: 3, h: 3 },   // assez pour l'en-tête et la saisie (le journal défile)
  unique: true,

  async monter({ corps, actions, etat }) {
    const s = await etat('regles', { schema: 1, conversation: identifiant(), recherche_seule: false, echanges: [] });
    const v = () => s.valeur;
    const service = await adresseService();
    let infos = null;           // réponse de /etat, null : service injoignable
    let enCours = null;         // { echange, abandon }

    const pdf = (langue, page) => `sources/${infos?.livres?.[langue] || ''}#page=${page}`;
    const ouvrirPdf = (langue, page) => { if (infos?.livres?.[langue]) window.open(pdf(langue, page), '_blank', 'noopener'); };

    // ── En-tête : recherche seule (bascule), nouvelle conversation ──
    const btnRecherche = bouton('', { icone: 'lu-search', titre: 'Recherche seule : les passages, sans modèle (instantané)', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie cm-regles__recherche', onclick: () => { v().recherche_seule = !v().recherche_seule; s.enregistrer(0); majEntete(); } });
    const btnNouvelle = bouton('', { icone: 'lu-rotate-ccw', titre: 'Nouvelle conversation (l’agent oublie les questions précédentes)', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', onclick: nouvelleConversation });
    actions.prepend(btnRecherche, btnNouvelle);
    function majEntete() {
      btnRecherche.setAttribute('aria-pressed', String(v().recherche_seule));
      btnRecherche.title = v().recherche_seule ? 'Recherche seule activée : les passages, sans réponse du modèle. Cliquer pour retrouver les réponses' : 'Recherche seule : les passages, sans modèle (instantané)';
      champ.placeholder = v().recherche_seule ? 'Mots de la règle (recherche seule)…' : 'Question de règles…';
      rendreStatut();
    }

    // ── Saisie ──
    const champ = h('textarea', { class: 'bn-input cm-regles__champ', rows: 1, 'aria-label': 'Question de règles' });
    const btnEnvoyer = bouton('', { icone: 'lu-arrow-right', titre: 'Envoyer (Entrée ; Maj + Entrée : à la ligne)', classe: 'bn-btn--s', onclick: envoyer });
    const btnArreter = bouton('', { icone: 'lu-square-plein', titre: 'Arrêter la réponse', classe: 'bn-btn--s', hidden: true, onclick: () => enCours?.abandon.abort() });
    champ.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); envoyer(); } });
    champ.addEventListener('input', ajusterChamp);
    function ajusterChamp() { champ.style.height = 'auto'; champ.style.height = Math.min(champ.scrollHeight + 2, 120) + 'px'; }

    const statut = h('div', { class: 'cm-regles__statut' });
    const journal = h('div', { class: 'cm-regles__journal', 'aria-live': 'polite' });
    corps.classList.add('cm-regles');
    corps.replaceChildren(statut, journal, h('div', { class: 'cm-regles__saisie' }, champ, btnEnvoyer, btnArreter));

    // ── Service ──
    async function verifier() {
      try {
        infos = await fetch(service + '/etat', { cache: 'no-store' }).then(r => r.json());
      } catch { infos = null; }
      rendreStatut();
    }
    function rendreStatut() {
      if (!infos) {
        statut.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Service de règles arrêté',
          'Lancé avec le gestionnaire une fois installé (« outils/Installer l’assistant de règles.cmd »), ou à la main : « uv run serveur.py » dans regles/.',
          bouton('Réessayer', { icone: 'lu-refresh-cw', classe: 'bn-btn--s', onclick: verifier })));
        return;
      }
      if (!infos.modele_pret && !v().recherche_seule) {
        statut.replaceChildren(alerte('cierge', 'lu-brain', 'Modèle indisponible', `${infos.raison} En attendant : recherche seule.`,
          bouton('Réessayer', { icone: 'lu-refresh-cw', classe: 'bn-btn--s', onclick: verifier })));
        return;
      }
      statut.replaceChildren();
    }

    // ── Échanges ──
    function nouvelleConversation() {
      if (enCours) enCours.abandon.abort();
      fetch(service + '/oublier', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversation: v().conversation }) }).catch(() => {});
      v().conversation = identifiant();
      v().echanges = [];
      s.enregistrer(0);
      rendre();
      champ.focus();
    }

    async function envoyer() {
      const question = champ.value.trim();
      if (!question || enCours) return;
      // Le service relance son Ollama s'il s'est arrêté : revérifier plutôt que rester en recherche seule.
      if (infos && !infos.modele_pret && !v().recherche_seule) await verifier();
      if (enCours) return;
      champ.value = '';
      ajusterChamp();
      const seule = v().recherche_seule || (infos && !infos.modele_pret);
      const echange = { id: identifiant(), quand: new Date().toISOString(), question, mode: seule ? 'recherche' : 'agent', reponse: '', recherches: [], sources: [], duree: null, erreur: null };
      v().echanges.push(echange);
      v().echanges.splice(0, Math.max(0, v().echanges.length - ECHANGES_MAX));
      enCours = { echange, abandon: new AbortController() };
      basculerEnvoi();
      rendre();
      const debut = performance.now();
      try {
        if (seule) {
          const r = await fetch(`${service}/recherche?n=6&q=${encodeURIComponent(question)}`, { signal: enCours.abandon.signal });
          if (!r.ok) throw new Error((await r.json()).erreur || r.statusText);
          echange.sources = await r.json();
        } else {
          const r = await fetch(service + '/question', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: enCours.abandon.signal,
            body: JSON.stringify({ question, conversation: v().conversation }),
          });
          if (!r.ok) throw new Error((await r.json()).erreur || r.statusText);
          for await (const { evenement, donnees } of lireFlux(r)) {
            if (evenement === 'texte') echange.reponse += donnees.t;
            else if (evenement === 'outil' && donnees.nom === 'chercher_regles') echange.recherches.push(donnees.entree.requete);
            else if (evenement === 'sources') echange.sources = donnees;
            else if (evenement === 'erreur') echange.erreur = donnees.message;
            majEchange(echange);
          }
        }
      } catch (e) {
        if (e.name === 'AbortError') echange.erreur = 'Réponse arrêtée.';
        else { echange.erreur = infos ? e.message : 'Service de règles injoignable.'; verifier(); }
      }
      echange.duree = Math.round((performance.now() - debut) / 100) / 10;
      enCours = null;
      basculerEnvoi();
      s.enregistrer(0);
      majEchange(echange);
    }
    function basculerEnvoi() { btnEnvoyer.hidden = !!enCours; btnArreter.hidden = !enCours; }

    // Réponse en Markdown léger : paragraphes, listes « - » ou « 1. », **gras**, citations cliquables.
    function enLigne(texte) {
      const morceaux = [];
      let dernier = 0;
      for (const m of texte.matchAll(/\*\*(.+?)\*\*|\[(DRS|SRD)[^\]]*?\]/g)) {
        morceaux.push(texte.slice(dernier, m.index));
        if (m[1]) morceaux.push(h('b', {}, m[1]));
        else {
          const page = /(\d+)/.exec(m[0])?.[1];
          const langue = m[2] === 'DRS' ? 'fr' : 'en';
          morceaux.push(page && infos?.livres?.[langue]
            ? h('a', { class: 'cm-regles__citation', href: pdf(langue, page), target: '_blank', rel: 'noopener', title: `Ouvrir le ${m[2]} à la page ${page}` }, m[0].slice(1, -1))
            : h('span', { class: 'cm-regles__citation' }, m[0].slice(1, -1)));
        }
        dernier = m.index + m[0].length;
      }
      morceaux.push(texte.slice(dernier));
      return morceaux;
    }
    function markdown(texte) {
      const blocs = [];
      let liste = null;
      for (const ligne of texte.split('\n')) {
        // Citation seule sur sa ligne (le petit modèle en ajoute en fin de réponse) : retirée si le texte la donne déjà.
        if (/^\s*(\[(DRS|SRD)[^\]]*\][\s.]*)+$/.test(ligne) && ligne.match(/\[[^\]]+\]/g).every(c => texte.replace(ligne, '').includes(c))) continue;
        const puce = /^\s*(?:[-*•]|\d+[.)])\s+(.*)$/.exec(ligne);
        if (puce) {
          if (!liste) blocs.push(liste = h(/^\s*\d/.test(ligne) ? 'ol' : 'ul', {}));
          liste.append(h('li', {}, enLigne(puce[1])));
        } else if (ligne.trim()) {
          liste = null;
          const titre = /^#+\s+(.*)$/.exec(ligne);
          blocs.push(h('p', titre ? { class: 'cm-regles__intertitre' } : {}, enLigne(titre ? titre[1] : ligne)));
        } else liste = null;
      }
      return blocs;
    }

    function ouvrirSource(src) {
      const cle = `regle:${src.section}`;
      const sigle = SIGLES[src.langue];
      const contenu = h('div', { class: 'cm-regles__section' }, h('p', { class: 'cm-sourdine' }, 'Chargement…'));
      flottant(cle, { surtitre: `${sigle} p. ${src.page}`, titre: src.chemin[src.chemin.length - 1] || sigle, contenu, largeur: 560 });
      fetch(`${service}/section/${encodeURIComponent(src.section)}`).then(r => r.json()).then(sec => {
        if (sec.erreur) { contenu.replaceChildren(h('p', {}, sec.erreur)); return; }
        contenu.replaceChildren(
          h('p', { class: 'cm-regles__chemin cm-sourdine' }, sec.chemin.slice(0, -1).join(' › ')),
          ...sec.texte.split('\n').map(l => h('p', {}, l)),
          infos?.livres?.[src.langue] ? h('p', {}, bouton(`Ouvrir le PDF page ${sec.page}`, { icone: 'lu-external-link', classe: 'bn-btn--s', onclick: () => ouvrirPdf(src.langue, sec.page) })) : null);
      }).catch(() => contenu.replaceChildren(h('p', {}, 'Service de règles injoignable.')));
    }

    // Sous la réponse, les passages comme en recherche seule (avec un extrait), sans doublon (une section lue en entier
    // après avoir été trouvée) : ceux que la réponse cite d'abord, les autres ensuite, repliés au-delà de SOURCES_VUES.
    const SOURCES_VUES = 6;
    function vueSources(e) {
      const vues = new Set();
      let sources = e.sources.filter(x => !vues.has(x.section) && vues.add(x.section));
      if (!sources.length) return null;
      const citees = new Set([...e.reponse.matchAll(/\[(DRS|SRD)\D*(\d+)/g)].map(m => `${m[1] === 'DRS' ? 'fr' : 'en'}:${m[2]}`));
      const citee = src => citees.has(`${src.langue}:${src.page}`);
      sources = [...sources.filter(citee), ...sources.filter(x => !citee(x))];
      const ligne = src => lienFlottant(h('button', { type: 'button', class: 'cm-regles__source', onclick: () => ouvrirSource(src) },
        h('span', { class: 'cm-regles__page' }, `${SIGLES[src.langue]} p. ${src.page}`),
        h('span', { class: 'cm-regles__nom' }, src.chemin[src.chemin.length - 1] || ''),
        h('span', { class: 'cm-regles__extrait' }, src.extrait + '…')), `regle:${src.section}`);
      const reste = sources.slice(SOURCES_VUES);
      return h('div', { class: 'cm-regles__sources cm-regles__sources--liste' }, sources.slice(0, SOURCES_VUES).map(ligne),
        reste.length ? h('details', { class: 'cm-regles__repli' }, h('summary', { class: 'cm-sourdine' }, `${reste.length} autre${reste.length > 1 ? 's' : ''} passage${reste.length > 1 ? 's' : ''}`),
          h('div', { class: 'cm-regles__sources cm-regles__sources--liste' }, reste.map(ligne))) : null);
    }

    function vueEchange(e) {
      const actif = enCours?.echange === e;
      const etapes = actif && !e.reponse
        ? h('p', { class: 'cm-regles__etape cm-sourdine' }, icone('lu-search', 'bn-icone--s'),
            e.mode === 'recherche' ? 'Recherche…' : e.recherches.length ? `Cherche « ${e.recherches[e.recherches.length - 1]} »…` : 'Réfléchit…')
        : null;
      const pied = !actif && (e.duree !== null || e.recherches.length)
        ? h('p', { class: 'cm-regles__pied cm-sourdine' }, [
            e.recherches.length ? `Cherché : ${e.recherches.map(r => `« ${r} »`).join(', ')}` : null,
            e.duree !== null ? `${String(e.duree).replace('.', ',')} s` : null].filter(Boolean).join(' · '))
        : null;
      return h('article', { class: 'cm-regles__echange' + (actif ? ' est-actif' : ''), 'data-id': e.id },
        h('p', { class: 'cm-regles__question' }, e.question),
        e.reponse ? h('div', { class: 'cm-regles__reponse' }, markdown(e.reponse)) : null,
        etapes,
        e.erreur ? h('p', { class: 'cm-regles__erreur' }, icone('lu-triangle-alert', 'bn-icone--s'), e.erreur) : null,
        vueSources(e),
        pied);
    }
    function majEchange(e) {
      const ancien = journal.querySelector(`[data-id="${e.id}"]`);
      const neuf = vueEchange(e);
      const enBas = corps.scrollHeight - corps.scrollTop - corps.clientHeight < 40;
      if (ancien) ancien.replaceWith(neuf); else journal.append(neuf);
      if (enBas) corps.scrollTop = corps.scrollHeight;
    }
    function rendre() {
      journal.replaceChildren(...(v().echanges.length
        ? v().echanges.map(vueEchange)
        : [h('p', { class: 'cm-regles__vide cm-sourdine' }, 'Règles de D&D 2024 (SRD 5.2.1). Réponses citées, une citation ouvre le PDF à sa page.')]));
      corps.scrollTop = corps.scrollHeight;
    }

    majEntete();
    rendre();
    await verifier();
    return {};
  },
};
