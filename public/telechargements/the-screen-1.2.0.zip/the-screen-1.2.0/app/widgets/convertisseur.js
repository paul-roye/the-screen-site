// Widget Convertisseur : pieds ↔ mètres (et cases de 5 pieds), dans les deux sens. Compact : tient en 2 colonnes.
// Deux règles : celle de la VF (5 pieds = 1,5 m, soit 0,3 m par pied) ou la valeur exacte (0,3048 m).

import { h, icone, FINE } from '../ui.js';

const REGLES = { jeu: 0.3, exacte: 0.3048 };
const COURANTES = [5, 10, 15, 20, 30, 60, 90, 120, 300];
const nombre = (n, d = 2) => n.toLocaleString('fr-FR', { maximumFractionDigits: d });
const lire = t => Number(String(t).replace(/\s/g, '').replace(',', '.'));

export default {
  type: 'convertisseur',
  titre: 'Pieds ↔ m',
  surtitre: 'Convertir',
  icone: 'epingle',
  description: 'Pieds ↔ mètres et cases de 5 pieds, en compact : règle de la VF (1,5 m pour 5 pieds) ou valeur exacte.',
  taille: { w: 2, h: 4 },
  min: { w: 2, h: 3 },
  unique: true,
  compact: true,

  async monter({ corps, etat }) {
    const s = await etat('convertisseur', { schema: 1, regle: 'jeu', pieds: 30 });
    const v = () => s.valeur;
    const facteur = () => REGLES[v().regle];

    const champPieds = h('input', { class: 'bn-input cm-conv__champ', inputmode: 'decimal', size: 1, 'aria-label': 'Pieds' });
    const champMetres = h('input', { class: 'bn-input cm-conv__champ', inputmode: 'decimal', size: 1, 'aria-label': 'Mètres' });
    const cases = h('span', { class: 'ui-s cm-sourdine' });
    const btnRegle = h('button', { type: 'button', class: 'cm-puce-bouton', onclick: () => { v().regle = v().regle === 'jeu' ? 'exacte' : 'jeu'; s.enregistrer(); afficher(); } });
    const liste = h('ul', { class: 'cm-conv__liste' });

    function afficher(source) {
      const p = v().pieds;
      const ok = Number.isFinite(p);
      if (source !== 'pieds') champPieds.value = ok ? nombre(p) : '';
      if (source !== 'metres') champMetres.value = ok ? nombre(p * facteur()) : '';
      cases.textContent = ok ? `${nombre(p / 5, 1)} case${p / 5 > 1 ? 's' : ''}` : '';
      btnRegle.textContent = v().regle === 'jeu' ? 'VF 1,5 m' : 'Exacte';
      btnRegle.title = v().regle === 'jeu' ? 'Règle de la VF : 1,5 m pour 5 pieds (cliquer pour la valeur exacte, 0,3048 m)' : 'Valeur exacte : 0,3048 m par pied (cliquer pour la règle de la VF)';
      liste.replaceChildren(...COURANTES.map(n => h('li', {},
        h('button', { type: 'button', class: 'cm-conv__courante' + (n === p ? ' est-choisie' : ''), onclick: () => { v().pieds = n; s.enregistrer(); afficher(); } },
          `${n}${FINE}ft`, h('span', { class: 'cm-sourdine' }, ` ${nombre(n * facteur(), 1)}${FINE}m`)))));
    }
    champPieds.addEventListener('input', () => { v().pieds = champPieds.value.trim() === '' ? NaN : lire(champPieds.value); s.enregistrer(500); afficher('pieds'); });
    champMetres.addEventListener('input', () => { v().pieds = champMetres.value.trim() === '' ? NaN : lire(champMetres.value) / facteur(); s.enregistrer(500); afficher('metres'); });

    corps.replaceChildren(
      h('div', { class: 'cm-conv' },
        h('label', { class: 'cm-conv__unite' }, champPieds, h('span', {}, 'ft')),
        icone('lu-arrow-left-right', 'bn-icone--s cm-sourdine'),
        h('label', { class: 'cm-conv__unite' }, champMetres, h('span', {}, 'm'))),
      h('div', { class: 'cm-conv__pied' }, cases, btnRegle),
      h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'Courantes'), liste));
    afficher();
    return {};
  },
};
