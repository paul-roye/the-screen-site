// Widget Dés : choisir des dés (d4 à d100) et un modificateur, puis lancer. Les dés roulent en 3D sur la page
// (app/des-3d.js) ; le total s'affiche au-dessus d'eux, puis dans le widget. Avantage / désavantage pour les d20.
// Clic sur un dé : un de plus ; clic droit ou « − » : un de moins. Sélection, réglages et derniers jets : etat/des.json.

import { h, icone, bouton, badge, infobulle } from '../ui.js';
import { aleatoire } from '../des.js';
import { lancerEn3d, critiqueDe } from '../des-3d.js';
import { emettre } from '../evenements.js';

const ORDRE = [4, 6, 8, 10, 12, 20, 100];          // sélecteurs
const FORMULE = [100, 20, 12, 10, 8, 6, 4];        // ordre dans la formule
const AVANTAGE = { normal: 'Normal', avantage: 'Avantage', desavantage: 'Désavantage' };
const AVANTAGE_COURT = { normal: 'Normal', avantage: 'Av.', desavantage: 'Désav.' };   // widget étroit
const MOINS = '−';
const HISTORIQUE = 30;

// Silhouettes des dés (grille 24, même trait que les icônes) ; le d20 vient de la charte.
const FORMES = {
  4: '<path d="M12 3l9.5 16.5h-19z"/><path d="M12 3v16.5"/>',
  6: '<path d="M12 2.5l8.5 4.9v9.2L12 21.5l-8.5-4.9V7.4z"/><path d="M3.5 7.4 12 12.3l8.5-4.9M12 12.3v9.2"/>',
  8: '<path d="M12 2.5 20.5 12 12 21.5 3.5 12z"/><path d="M12 2.5 15 14.5 3.5 12M15 14.5 20.5 12M15 14.5 12 21.5"/>',
  10: '<path d="M12 2.5 21 10.5 12 21.5 3 10.5z"/><path d="M12 2.5 8 13l4 2 4-2zM3 10.5 8 13M21 10.5 16 13M12 15v6.5"/>',
  12: '<path d="M12 2.5l9 6.5-3.4 10.5H6.4L3 9z"/><path d="M12 6.5l4.3 3.1-1.6 5H9.3l-1.6-5z"/><path d="M12 2.5v4M21 9l-4.7.6M17.6 19.5l-2.9-4.9M6.4 19.5l2.9-4.9M3 9l4.7.6"/>',
  100: '<path d="M7 4l5 4.5L7 20 2 8.5z"/><path d="M17 4l5 4.5L17 20l-5-11.5z"/>',
};
function forme(faces) {
  if (faces === 20) return icone('d20', 'cm-de__forme');
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('class', 'bn-icone cm-de__forme');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  for (const [a, val] of Object.entries({ fill: 'none', stroke: 'currentColor', 'stroke-width': '1.5', 'stroke-linejoin': 'round', 'stroke-linecap': 'round' })) svg.setAttribute(a, val);
  svg.innerHTML = FORMES[faces];   // tracés constants ci-dessus
  return svg;
}

const heure = iso => new Date(iso).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
const signe = n => (n < 0 ? `${MOINS}${-n}` : `+${n}`);

export function formule(choix, mod = 0, avantage = 'normal') {
  const termes = FORMULE.filter(f => choix[f] > 0).map(f => `${choix[f]}d${f}` + (f === 20 && avantage !== 'normal' ? (avantage === 'avantage' ? ' (av.)' : ' (désav.)') : ''));
  if (!termes.length) return '';
  return termes.join(' + ') + (mod ? ` ${mod < 0 ? MOINS : '+'} ${Math.abs(mod)}` : '');
}

// Les dés d'un jet : { faces, valeur, garde } ; avec l'avantage, chaque d20 est lancé deux fois (l'autre n'est pas gardé).
function jeter(choix, mod, avantage) {
  const des = [];
  for (const f of FORMULE) for (let k = 0; k < (choix[f] || 0); k++) {
    if (f === 20 && avantage !== 'normal') {
      const a = aleatoire(20), b = aleatoire(20);
      const premier = avantage === 'avantage' ? a >= b : a <= b;
      des.push({ faces: 20, valeur: a, garde: premier }, { faces: 20, valeur: b, garde: !premier });
    } else des.push({ faces: f, valeur: aleatoire(f), garde: true });
  }
  return { des, total: des.reduce((s, d) => s + (d.garde ? d.valeur : 0), 0) + mod };
}

// Un d100 roule en deux d10 : les dizaines (00 à 90) et les unités (0 à 9) ; 00 et 0 font 100.
function pourLa3d(des) {
  return des.flatMap(d => {
    if (d.faces !== 100) return [{ faces: d.faces, valeur: d.valeur, terne: !d.garde }];
    const r = d.valeur % 100;
    return [
      { faces: 10, valeur: Math.floor(r / 10) || 10, libelle: v => String((v % 10) * 10).padStart(2, '0') },
      { faces: 10, valeur: r % 10 || 10 },
    ];
  });
}

export default {
  type: 'des',
  titre: 'Dés',
  icone: 'd20',
  description: 'Choisir des dés (d4 à d100), un modificateur, l\'avantage, puis les lancer : ils roulent en 3D sur la page.',
  taille: { w: 3, h: 9 },
  min: { w: 2, h: 4 },   // 4 rangées : les dés et le dernier résultat (1600 px), sans les jets précédents
  unique: true,

  async monter({ corps, actions, resume, etat }) {
    const s = await etat('des', { schema: 1, choix: {}, mod: 0, avantage: 'normal', anime: true, son: true, historique: [] });
    const v = () => s.valeur;
    let enCours = false;
    // Plusieurs exemplaires peuvent être montés (le widget du tableau, la fenêtre du menu rapide) : chaque changement est
    // enregistré puis signalé aux autres, qui se redessinent (ecoute, plus bas).
    const garder = () => { s.enregistrer(); s.signaler(ecoute); };

    const zoneChoix = h('div', { class: 'cm-des__choix' });
    const zoneMod = h('div', { class: 'cm-des__mod' });
    const btnAvantage = h('button', { type: 'button', class: 'cm-puce-bouton cm-des__avantage', onclick: () => {
      const cles = Object.keys(AVANTAGE);
      v().avantage = cles[(cles.indexOf(v().avantage) + 1) % cles.length];
      garder();
      maj();
    } });
    const btnVider = bouton('', { icone: 'lu-rotate-ccw', titre: 'Retirer tous les dés et le modificateur', classe: 'bn-btn--s bn-btn--fantome cm-des__vider', onclick: () => {
      v().choix = {}; v().mod = 0; v().avantage = 'normal'; garder(); maj();
    } });
    const btnLancer = bouton('Lancer', { icone: 'd20', classe: 'bn-btn--s bn-btn--primaire cm-des__lancer', 'aria-label': 'Lancer', onclick: () => lancer(v().choix, v().mod, v().avantage, btnLancer) });
    const zoneResultat = h('div', { class: 'cm-des__resultat', 'aria-live': 'polite' });
    const zoneHistorique = h('ol', { class: 'cm-des__historique' });

    const btn3d = bouton('', { icone: 'lu-box', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', onclick: () => { v().anime = !v().anime; garder(); majReglages(); } });
    const btnSon = bouton('', { classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', onclick: () => { v().son = !v().son; garder(); majReglages(); } });
    actions.append(btn3d, btnSon);
    function majReglages() {
      const lib3d = v().anime ? 'Dés en 3D sur la page (désactiver)' : 'Résultat seul, sans les dés en 3D (activer la 3D)';
      btn3d.setAttribute('aria-pressed', String(v().anime));
      btn3d.setAttribute('aria-label', lib3d);
      btn3d.title = lib3d;
      btnSon.replaceChildren(icone(v().son ? 'lu-volume-2' : 'lu-volume-x'));
      btnSon.setAttribute('aria-pressed', String(v().son));
      btnSon.setAttribute('aria-label', v().son ? 'Son des dés activé (couper)' : 'Son des dés coupé (activer)');
      btnSon.title = btnSon.getAttribute('aria-label');
    }

    function changer(faces, ecart) {
      const n = Math.max(0, Math.min(20, (v().choix[faces] || 0) + ecart));
      if (n) v().choix[faces] = n; else delete v().choix[faces];
      garder();
      maj();
    }
    function changerMod(ecart) { v().mod = Math.max(-30, Math.min(30, v().mod + ecart)); garder(); maj(); }

    function maj() {
      const c = v().choix;
      zoneChoix.replaceChildren(...ORDRE.map(f => {
        const n = c[f] || 0;
        // Le nombre choisi s'écrit dans le libellé (« 2d20 ») ; la bande du bas retire un dé (place gardée à 0 : rien ne bouge).
        const ajout = infobulle(h('button', {
          type: 'button', class: 'cm-de__ajouter', 'aria-label': `Ajouter un d${f}` + (n ? ` (${n} choisi${n > 1 ? 's' : ''})` : ''),
          onclick: () => changer(f, 1),
          oncontextmenu: e => { e.preventDefault(); changer(f, -1); },
        }, forme(f), h('span', { class: 'cm-de__nom' }, n ? `${n}d${f}` : `d${f}`)),
        'Clic : un de plus · clic droit : un de moins', { titre: `d${f}` });
        return h('div', { class: 'cm-de' + (n ? ' est-choisi' : '') }, ajout,
          h('button', { type: 'button', class: 'cm-de__retirer', 'aria-label': `Retirer un d${f}`, title: `Retirer un d${f}`, disabled: !n, onclick: () => changer(f, -1) }, icone('lu-minus')));
      }));
      zoneMod.replaceChildren(
        h('button', { type: 'button', class: 'cm-puce-bouton', 'aria-label': 'Modificateur moins 1', onclick: () => changerMod(-1) }, icone('lu-minus')),
        h('button', { type: 'button', class: 'cm-puce-bouton cm-des__valeur-mod' + (v().mod ? ' est-actif' : ''), title: 'Modificateur (clic : remettre à 0)', onclick: () => changerMod(-v().mod) }, signe(v().mod)),
        h('button', { type: 'button', class: 'cm-puce-bouton', 'aria-label': 'Modificateur plus 1', onclick: () => changerMod(1) }, icone('lu-plus')));
      const avecD20 = (c[20] || 0) > 0;
      const av = AVANTAGE[v().avantage] ? v().avantage : 'normal';
      // Les trois libellés l'un sur l'autre, seul le choisi visible : le bouton garde la largeur du plus long (rien ne bouge).
      btnAvantage.replaceChildren(...Object.keys(AVANTAGE).map(k => h('span', { class: 'cm-des__av' + (k === av ? ' est-choisi' : '') },
        h('span', { class: 'cm-des__long' }, AVANTAGE[k]), h('span', { class: 'cm-des__court', 'aria-hidden': 'true' }, AVANTAGE_COURT[k]))));
      btnAvantage.disabled = !avecD20;
      btnAvantage.classList.toggle('est-actif', avecD20 && v().avantage !== 'normal');
      btnAvantage.title = avecD20 ? 'Avantage ou désavantage sur les d20 (clic : changer)' : 'Ajoutez un d20 pour l\'avantage';
      const f = formule(c, v().mod, v().avantage);
      btnLancer.disabled = !f;
      btnLancer.title = f ? `Lancer ${f}` : 'Choisissez au moins un dé';
      btnVider.disabled = !f && !v().mod;
      majReglages();
    }

    function puces(jet) {
      return jet.des.map(d => h('span', { class: 'cm-des__puce' + (d.garde ? '' : ' est-ecarte') + (d.faces === 20 && d.garde && (d.valeur === 20 || d.valeur === 1) ? (d.valeur === 20 ? ' est-max' : ' est-min') : '') },
        h('small', {}, `d${d.faces}`), String(d.valeur)));
    }
    // Un seul d20 gardé : 20 ou 1 naturel.
    function naturel(jet) {
      const d20 = jet.des.filter(d => d.faces === 20 && d.garde);
      if (d20.length !== 1) return '';
      if (d20[0].valeur === 20) return badge('20 naturel', 'brume', 'lu-sparkles');
      if (d20[0].valeur === 1) return badge('1 naturel', 'sang', 'lu-triangle-alert');
      return '';
    }

    function afficher() {
      const hist = v().historique;
      const dernier = hist[hist.length - 1];
      if (!dernier) {
        zoneResultat.replaceChildren(h('p', { class: 'ui-s cm-sourdine cm-des__vide' }, 'Choisissez des dés, puis lancez.'));
        resume.replaceChildren();
      } else if (enCours) {
        zoneResultat.replaceChildren(h('div', { class: 'cm-des__ligne' },
          h('div', { class: 'cm-des__quoi' }, h('span', { class: 'des cm-sourdine' }, dernier.formule)),
          h('span', { class: 'cm-des__total cm-des__total--attente' }, '…')));
      } else {
        // Le motif au-dessus de la formule, les dés lancés à leur droite, le total au bout (deux lignes au plus, 2026-10-20).
        zoneResultat.replaceChildren(h('div', { class: 'cm-des__ligne' },
          h('div', { class: 'cm-des__quoi' },
            dernier.motif ? h('div', { class: 'ui-s cm-des__motif', title: dernier.motif }, dernier.motif) : null,
            h('div', { class: 'cm-des__formule' }, h('span', { class: 'des cm-sourdine' }, dernier.formule), naturel(dernier))),
          h('div', { class: 'cm-des__puces' }, puces(dernier), dernier.mod ? h('span', { class: 'cm-des__mod-jet' }, signe(dernier.mod)) : ''),
          h('span', { class: 'cm-des__total' }, String(dernier.total))));
        resume.replaceChildren(h('b', {}, String(dernier.total)), h('span', { class: 'des cm-sourdine' }, dernier.formule));
      }
      // Jets précédents : un clic relance la même chose. Ceux faits ailleurs (initiative, fiches de monstres : motif) se
      // lisent seulement, leur motif au survol.
      const avant = hist.slice(0, -1).slice(-5).reverse();
      zoneHistorique.hidden = !avant.length;
      zoneHistorique.replaceChildren(...avant.map(j => h('li', {}, j.choix
        ? h('button', { type: 'button', class: 'cm-des__ancien', title: `Relancer ${j.formule}`, onclick: e => lancer(j.choix, j.mod, j.avantage, e.currentTarget) },
          h('span', { class: 'cm-sourdine' }, heure(j.quand)),
          h('span', { class: 'des' }, j.formule),
          h('b', {}, String(j.total)))
        : h('span', { class: 'cm-des__ancien est-ailleurs', title: j.motif || null },
          h('span', { class: 'cm-sourdine cm-des__motif' }, j.motif || heure(j.quand)),
          h('span', { class: 'des' }, j.formule),
          h('b', {}, String(j.total))))));
      ajusterHistorique();
    }

    // Les jets précédents qui tiennent dans la hauteur du widget, sans défilement (aucun dans un widget de 4 rangées).
    function ajusterHistorique() {
      if (!corps.clientHeight) return;   // widget réduit ou dans la réserve : à son retour, l'observateur le refait
      const l = [...zoneHistorique.children];
      l.forEach(li => { li.hidden = false; });
      zoneHistorique.hidden = !l.length;
      for (let i = l.length - 1; i >= 0 && corps.scrollHeight > corps.clientHeight; i--) l[i].hidden = true;
      if (l.length && l.every(li => li.hidden)) zoneHistorique.hidden = true;
    }

    async function lancer(choix, mod, avantage, depuis) {
      const f = formule(choix, mod, avantage);
      if (!f) return;
      const jet = jeter(choix, mod, avantage);
      v().historique.push({ quand: new Date().toISOString(), choix: { ...choix }, mod, avantage, formule: f, total: jet.total, des: jet.des });
      v().historique = v().historique.slice(-HISTORIQUE);   // en mémoire seulement (EN_MEMOIRE de app/etat.js) : rien à écrire
      emettre('des:resultat', { legende: 'Dés', couleur: 'sang', jets: [{ libelle: f, formule: f, total: jet.total, critique: critiqueDe(jet.des) }] });
      const anime = v().anime && !matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (anime) {
        enCours = true;
        afficher();
        const l = lancerEn3d(pourLa3d(jet.des), { depuis: depuis?.getBoundingClientRect(), son: v().son, total: jet.total, formule: f, critique: critiqueDe(jet.des) });
        const moi = l;
        dernierLancer = moi;
        await l.fin;
        if (dernierLancer !== moi) return;   // relancé entre-temps
        enCours = false;
      }
      afficher();
      s.signaler(ecoute);   // les autres exemplaires montrent le résultat une fois les dés posés
    }
    let dernierLancer = null;

    corps.classList.add('cm-des');
    resume.classList.add('cm-des__resume');
    resume.dataset.quand = 'reduit';   // déplié, le résultat est dans le widget
    const zoneReglages = h('div', { class: 'cm-des__reglages' }, zoneMod, btnAvantage);
    const jeu = h('div', { class: 'cm-des__jeu' }, zoneChoix, zoneReglages, h('div', { class: 'cm-des__boutons' }, btnLancer, btnVider));
    corps.replaceChildren(jeu, zoneResultat, zoneHistorique);

    // Sur une ligne : les dés, le modificateur et l'avantage l'un sur l'autre, puis Lancer (demande du MJ, 2026-10-20).
    // Faute de place (mesurée, sans seuil fixe) : Lancer sans son texte, puis le modificateur et l'avantage sous les dés,
    // Lancer toujours à leur droite ; si les sept dés n'y tiennent plus de front (widget de 3 colonnes), Lancer aussi
    // sous les dés, au bout de la ligne. L'avantage s'abrège en dernier.
    const DISPOSITIONS = [[], ['sans-texte'], ['sans-texte', 'dessous'], ['sans-texte', 'dessous', 'court'], ['sans-texte', 'tout-dessous'], ['sans-texte', 'tout-dessous', 'court']];
    const LARGEUR_DES = 7 * 30 + 6 * 3;   // les sept dés de front (.cm-des__choix : 30 px au moins, 3 px d'écart)
    function disposer() {
      if (!jeu.offsetWidth) return;   // widget réduit ou dans la réserve : à son retour, l'observateur le redispose
      for (const classes of DISPOSITIONS) {
        for (const c of ['sans-texte', 'court', 'dessous', 'tout-dessous']) jeu.classList.toggle(c, classes.includes(c));
        const tient = classes.includes('tout-dessous')
          ? Math.abs(btnLancer.getBoundingClientRect().top - zoneMod.getBoundingClientRect().top) < 10   // une seule ligne sous les dés
          : zoneChoix.getBoundingClientRect().width >= LARGEUR_DES - 0.5 && zoneReglages.scrollWidth <= zoneReglages.clientWidth + 1;
        if (tient) return;
      }
    }
    // La largeur décide de la disposition ; la hauteur (fixée par la grille), des jets précédents qui tiennent.
    let largeur = -1, hauteur = -1;
    new ResizeObserver(([e]) => {
      const l = Math.round(e.contentRect.width), ht = Math.round(e.contentRect.height);
      if (l === largeur && ht === hauteur) return;
      if (l !== largeur) disposer();
      largeur = l; hauteur = ht;
      ajusterHistorique();
    }).observe(corps);
    document.fonts?.ready.then(() => { disposer(); ajusterHistorique(); });
    maj();
    afficher();
    // Lancers faits ailleurs (app/lancers.js) ou dans un autre exemplaire : dans le résultat, l'historique et la sélection.
    // Un exemplaire retiré de la page (fenêtre fermée) ne s'écoute plus.
    function ecoute() {
      if (!corps.isConnected) { finEcoute(); return; }
      maj();
      if (!enCours) afficher();
    }
    const finEcoute = s.abonner(ecoute);
    return {};
  },
};
