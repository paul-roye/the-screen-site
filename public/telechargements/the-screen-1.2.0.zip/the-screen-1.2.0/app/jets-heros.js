// Jets des héros (demande du MJ, 2026-10-23) : compétences, tests de caractéristique, sauvegardes et initiative, d'après
// le relevé D&D Beyond (etat/beyond.json, extension 1.13.0 pour les compétences). Widget Personnages : le dé de l'en-tête
// lance pour tout le groupe (« jets secrets » : le résultat n'est vu que du MJ), classé du plus grand au plus petit ; le dé
// d'une fiche lance pour ce héros ; l'onglet Compétences de la fiche lance d'un clic sur une ligne.
// Les jets roulent comme ceux du gestionnaire (montrerJets de app/lancers.js) et vont dans l'historique du widget Dés.

import { h, icone, flottant, flottantOuvert } from './ui.js';
import { COMPETENCES } from '../extensions/mj/resumer.js';
import { jeterD20, formuleD20, montrerJets } from './lancers.js';
import { annoncer } from './horloge.js';

const signe = n => (n >= 0 ? '+' : '−') + Math.abs(n);
const CARACS = [['for', 'Force', 'For'], ['dex', 'Dextérité', 'Dex'], ['con', 'Constitution', 'Con'], ['int', 'Intelligence', 'Int'], ['sag', 'Sagesse', 'Sag'], ['cha', 'Charisme', 'Cha']];
const COURT = Object.fromEntries(CARACS.map(([c, , court]) => [c, court]));
const PAR_NOM = [...COMPETENCES].sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));

// Les jets proposés : { id, libelle, groupe }. id : « comp:<clé> », « test:<carac> », « js:<carac> », « init ».
export const JETS = [
  ...PAR_NOM.map(c => ({ id: 'comp:' + c.cle, libelle: c.nom, court: COURT[c.carac], groupe: 'comp' })),
  ...CARACS.map(([c, nom]) => ({ id: 'test:' + c, libelle: nom, groupe: 'test' })),
  ...CARACS.map(([c, nom]) => ({ id: 'js:' + c, libelle: nom, groupe: 'js' })),
  { id: 'init', libelle: 'Initiative', groupe: 'init' },
];
const parId = new Map(JETS.map(j => [j.id, j]));
export const nomJet = id => {
  const j = parId.get(id);
  return !j ? id : j.groupe === 'test' ? `Test de ${j.libelle}` : j.groupe === 'js' ? `Sauvegarde de ${j.libelle}` : j.libelle;
};

// Bonus d'un jet pour une fiche de héros (creature : une créature des « extras », un familier). null : pas de jet possible
// (une créature n'a ni sauvegardes relevées ni initiative à elle : un compagnon agit au tour de son maître).
// → { bonus, avantage, desavantage, approche } ; approche : compétences pas encore relevées (extension d'avant 1.13.0),
// le modificateur de caractéristique à la place.
export function bonusJet(f, id, { creature = false } = {}) {
  if (!f) return null;
  const [genre, cle] = id.split(':');
  const carac = c => f.caracteristiques?.[c];
  if (genre === 'comp') {
    const def = COMPETENCES.find(c => c.cle === cle);
    const x = f.competences?.[cle];
    if (x) return { bonus: x.bonus, avantage: !!x.avantage, desavantage: !!x.desavantage };
    const m = carac(def?.carac);
    return m ? { bonus: m.test ?? m.mod, approche: true } : null;
  }
  if (genre === 'test') {
    const m = carac(cle);
    return m ? { bonus: m.test ?? m.mod, avantage: !!m.avantage_test, desavantage: !!m.desavantage_test } : null;
  }
  if (creature) return null;
  if (genre === 'js') return carac(cle) ? { bonus: carac(cle).sauvegarde } : null;
  if (genre === 'init') return f.initiative != null ? { bonus: f.initiative } : null;
  return null;
}

const avantageDe = b => (b.avantage && !b.desavantage ? 'avantage' : b.desavantage && !b.avantage ? 'desavantage' : null);
// Avantage ou désavantage voulu par le MJ pour ce jet (la bascule de la fenêtre), ajouté à ceux de la fiche.
const combiner = (b, force) => ({ ...b, avantage: b.avantage || force === 'avantage', desavantage: b.desavantage || force === 'desavantage' });

// Lancer un jet pour des participants [{ nom, fiche, creature? }] ; plusieurs : une ligne chacun, du plus grand total au
// plus petit (jets de groupe). force : 'avantage' ou 'desavantage' pour tous.
export function lancerJet(participants, id, { force = null, depuis = null, groupe = false } = {}) {
  const jets = participants.map(p => {
    const b = bonusJet(p.fiche, id, { creature: p.creature });
    if (!b) return null;
    const jet = jeterD20(formuleD20(b.bonus), avantageDe(combiner(b, force)));
    return jet && { libelle: p.nom, jet, bonus: b.bonus, approche: b.approche };
  }).filter(Boolean).sort((a, b) => b.jet.total - a.jet.total || b.bonus - a.bonus);
  if (!jets.length) return null;
  if (jets.some(j => j.approche)) {
    annoncer({ cle: 'competences-absentes', titre: 'Compétences pas encore relevées', icone: 'd20', couleur: 'cierge',
      texte: 'Le relevé D&D Beyond ne donne pas encore les compétences : rechargez l\'extension (1.13.0) dans chrome://extensions. En attendant, le modificateur de caractéristique.' });
  }
  const legende = groupe ? `Jet de groupe : ${nomJet(id)}` : `${participants[0].nom} : ${nomJet(id)}`;
  montrerJets(jets, { legende, depuis });
  return jets;
}

// Fenêtre de choix du jet (dé de l'en-tête de Personnages, dé d'une fiche) : compétences, tests, sauvegardes, initiative.
// Le choix lance aussitôt et ferme la fenêtre ; l'avantage ou le désavantage pour tous se règle d'un bouton qui cycle.
// participants() : relus au moment du jet (le relevé change toutes les 30 s).
export function ouvrirChoixJet({ cle, titre, surtitre, participants, depuis = null, groupe = false }) {
  let force = null;
  const FORCES = [[null, 'Normal'], ['avantage', 'Avantage'], ['desavantage', 'Désavantage']];
  const btnForce = h('button', { type: 'button', class: 'bn-btn bn-btn--s cm-choix-jet__force', title: 'Avantage ou désavantage pour tous, en plus de ceux des fiches (un clic pour changer)',
    onclick: () => { force = FORCES[(FORCES.findIndex(([v]) => v === force) + 1) % FORCES.length][0]; majForce(); } });
  const majForce = () => {
    btnForce.replaceChildren(icone('d20'), h('span', {}, FORCES.find(([v]) => v === force)[1]));
    btnForce.setAttribute('aria-pressed', String(!!force));
    btnForce.dataset.force = force || '';
  };
  majForce();
  const lancer = (id, ev) => {
    lancerJet(participants(), id, { force, depuis: ev.currentTarget.getBoundingClientRect(), groupe });   // la position : la fenêtre se ferme
    flottantOuvert(cle)?.fermer();
  };
  const grille = (g, etiquette) => h('div', { class: 'cm-pile cm-choix-jet__bloc' },
    h('span', { class: 'etiquette' }, etiquette),
    h('div', { class: 'cm-choix-jet__grille' }, JETS.filter(j => j.groupe === g).map(j => h('button', { type: 'button', class: 'bn-btn bn-btn--s cm-choix-jet__choix', onclick: ev => lancer(j.id, ev) },
      h('span', {}, j.libelle), j.court ? h('span', { class: 'cm-sourdine' }, j.court) : null))));
  flottant(cle, { surtitre, titre, largeur: 460, depuis, contenu: h('div', { class: 'cm-pile cm-choix-jet' },
    h('div', { class: 'bn-groupe' }, btnForce),
    grille('comp', 'Compétences'),
    grille('test', 'Tests de caractéristique'),
    grille('js', 'Jets de sauvegarde'),
    grille('init', 'Initiative')) });
}

// Onglet Compétences d'une fiche : les dix-huit compétences par ordre alphabétique, bonus et maîtrise ; un clic lance.
// nom : prénom du héros (légende du jet). Sans compétences relevées : un mot pour recharger l'extension.
export function blocCompetences(f, nom) {
  if (!f?.competences) {
    return h('p', { class: 'ui-s cm-sourdine' }, 'Les compétences viennent du relevé D&D Beyond : rechargez l\'extension (1.13.0) dans chrome://extensions.');
  }
  const MAITRISES = { expertise: ['Expertise', 'cm-competence--expertise'], maitrise: ['Maîtrise', 'cm-competence--maitrise'], demi: ['Demi-maîtrise', 'cm-competence--demi'] };
  return h('ul', { class: 'cm-competences' }, PAR_NOM.map(c => {
    const x = f.competences[c.cle];
    if (!x) return null;
    const [mot, classe] = MAITRISES[x.maitrise] || [null, ''];
    const adv = x.avantage && !x.desavantage ? 'av.' : x.desavantage && !x.avantage ? 'désav.' : null;
    return h('li', {}, h('button', { type: 'button', class: `cm-competence ${classe}`.trim(),
      title: [`Lancer ${c.nom} pour ${nom}`, mot, adv ? (adv === 'av.' ? 'avec avantage' : 'avec désavantage') : null].filter(Boolean).join(' · '),
      onclick: ev => lancerJet([{ nom, fiche: f }], 'comp:' + c.cle, { depuis: ev.currentTarget.getBoundingClientRect() }) },
      h('span', { class: 'cm-competence__maitrise', 'aria-hidden': 'true' }),
      h('span', { class: 'cm-competence__nom' }, c.nom, h('span', { class: 'cm-sourdine' }, ' ' + COURT[c.carac])),
      adv ? h('span', { class: 'cm-competence__adv', 'data-adv': adv === 'av.' ? 'avantage' : 'desavantage' }, adv) : null,
      h('span', { class: 'cm-competence__bonus' }, signe(x.bonus))));
  }));
}
