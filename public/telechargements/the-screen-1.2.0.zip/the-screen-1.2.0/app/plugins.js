// Plugins : des connexions facultatives du gestionnaire à un appareil ou à un service (The Table : le ruban LED autour de
// la table de jeu), activées campagne par campagne dans la fenêtre Campagne, onglet « Plugins » (`plugins` de
// etat/campagne.json, formats/etat.md). Un plugin écoute les événements du gestionnaire (app/evenements.js) et agit dehors ;
// il peut aussi apporter des widgets (proposés dans « Ajouter un outil » quand il est actif) et des contributions aux
// emplacements des widgets hôtes (contributions() de app/modules.js : `combatEntete`…), comme un module de campagne.
// Il ne lit ni n'écrit data/ ; ses réglages vont dans etat/campagne.json. Contrat et catalogue des événements :
// formats/plugins.md. Un module de campagne (app/modules.js) est une mécanique de jeu choisie à la création de la campagne ;
// un plugin est une connexion, qu'on active ou coupe quand on veut.
//
// Un plugin (app/plugins/<id>.js) exporte :
//   { id, titre, icone, description,
//     defauts: { … },                       ses réglages par défaut (`actif` compris : faux)
//     widgets: [...],                        ses widgets, chacun avec `plugin: '<id>'` (grisés dans « Ajouter un outil » quand il est inactif)
//     emplacements: { <nom>: fonction },     ce qu'il ajoute aux widgets hôtes (EMPLACEMENTS de app/modules.js)
//     demarrer(ctx), arreter(),              ctx : { etat, donnees, dialogue, reglages: { lire, ecrire, surChangement }, ecouter }
//     reglages(ctx) }                        ses réglages dans l'onglet Plugins (un élément), sous l'interrupteur ; même ctx, inactif compris

import { h, icone, alerte, heure } from './ui.js';
import { etat } from './etat.js';
import { ecouter, journalEvenements, surJournal } from './evenements.js';
import theTable from './plugins/the-table.js';
import ecranJoueurs from './plugins/ecran-joueurs.js';

export const PLUGINS = [theTable, ecranJoueurs];
export const pluginDe = id => PLUGINS.find(p => p.id === id) || null;

const actifs = new Map();   // id -> { def, desabonner: [fonctions], surReglages: Set }
const surChangementFns = new Set();
let sCampagne = null;
let contexte = null;

// Au démarrage de la page (app/main.js), avant les widgets : les plugins actifs de la campagne démarrent.
export async function chargerPlugins(ctx) {
  contexte = ctx;
  sCampagne = await etat('campagne', { schema: 1 });
  for (const p of PLUGINS) if (reglagesDe(p.id).actif) await demarrerPlugin(p.id);
}

// Les réglages d'un plugin : ses défauts, puis ce qu'en garde etat/campagne.json.
export const reglagesDe = id => ({ ...(pluginDe(id)?.defauts || {}), ...(sCampagne?.valeur.plugins?.[id] || {}) });
export function ecrireReglages(id, patch) {
  const v = sCampagne.valeur;
  v.plugins = { ...(v.plugins || {}), [id]: { ...(v.plugins?.[id] || {}), ...patch } };
  sCampagne.enregistrer(0);
  actifs.get(id)?.surReglages.forEach(fn => { try { fn(reglagesDe(id)); } catch (e) { console.error(e); } });
}

export const pluginActif = id => actifs.has(id);
export const pluginsActifs = () => [...actifs.values()].map(a => a.def);
// Prévenu quand un plugin démarre ou s'arrête (le widget d'un plugin, la fenêtre Outil).
export function surChangementPlugins(fn) { surChangementFns.add(fn); return () => surChangementFns.delete(fn); }
const prevenir = () => surChangementFns.forEach(fn => { try { fn(); } catch (e) { console.error(e); } });

export async function activerPlugin(id, oui) {
  ecrireReglages(id, { actif: !!oui });
  if (oui) await demarrerPlugin(id);
  else arreterPlugin(id);
}

function contexteDe(id, a) {
  return {
    ...contexte,
    reglages: {
      lire: () => reglagesDe(id),
      ecrire: patch => ecrireReglages(id, patch),
      surChangement: fn => { a?.surReglages.add(fn); },
    },
    // Un écouteur posé par le plugin est retiré quand il s'arrête.
    ecouter: (nom, fn) => { const off = ecouter(nom, fn); a?.desabonner.push(off); return off; },
  };
}

async function demarrerPlugin(id) {
  const def = pluginDe(id);
  if (!def || actifs.has(id)) return;
  const a = { def, desabonner: [], surReglages: new Set() };
  actifs.set(id, a);
  try { await def.demarrer?.(contexteDe(id, a)); }
  catch (e) {
    console.error(`Plugin « ${def.titre} » : démarrage en erreur`, e);
    document.dispatchEvent(new CustomEvent('cm:annonce', { detail: { cle: 'plugin-' + id, titre: `Plugin ${def.titre} : démarrage en erreur`, icone: 'lu-triangle-alert', couleur: 'sang', texte: String(e?.message || e) } }));
  }
  prevenir();
}

function arreterPlugin(id) {
  const a = actifs.get(id);
  if (!a) return;
  a.desabonner.forEach(off => off());
  try { a.def.arreter?.(); } catch (e) { console.error(e); }
  actifs.delete(id);
  prevenir();
}

// ───── Onglet « Plugins » de la fenêtre Campagne ─────
// Une carte par plugin : l'interrupteur, sa description, ses réglages ; en bas, les derniers événements du gestionnaire
// (de quoi voir ce qu'un plugin reçoit).
export function contenuPlugins() {
  const cartes = PLUGINS.map(def => {
    const zoneReglages = h('div', { class: 'cm-plugin__reglages' });
    const interrupteur = h('input', { type: 'checkbox', class: 'bn-case', checked: pluginActif(def.id), onchange: async e => {
      e.target.disabled = true;
      try { await activerPlugin(def.id, e.target.checked); }
      finally { e.target.disabled = false; e.target.checked = pluginActif(def.id); }
    } });
    try { zoneReglages.replaceChildren(def.reglages?.(contexteDe(def.id, actifs.get(def.id) || null)) || ''); }
    catch (e) { zoneReglages.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Réglages illisibles', String(e?.message || e))); }
    return h('div', { class: 'cm-reglage cm-plugin' },
      h('div', { class: 'cm-plugin__tete' },
        icone(def.icone || 'lu-plug', 'bn-icone--l'),
        h('span', { class: 'cm-plugin__nom' }, def.titre),
        h('label', { class: 'cm-case' }, interrupteur, h('span', {}, 'Activer'))),
      h('p', { class: 'ui-s cm-sourdine' }, def.description),
      zoneReglages);
  });
  // Les derniers événements, repliés : le nom, l'heure, le détail en une ligne.
  const liste = h('ul', { class: 'cm-plugin__journal' });
  const ligne = e => h('li', {}, h('span', { class: 'cm-sourdine' }, heure(e.quand)), ' ', h('b', {}, e.nom), ' ',
    h('span', { class: 'cm-sourdine' }, JSON.stringify(e.detail).slice(0, 160)));
  const remplir = () => liste.replaceChildren(...journalEvenements().slice().reverse().map(ligne));
  remplir();
  const off = surJournal(() => { if (liste.isConnected) remplir(); else off(); });
  return h('div', { class: 'cm-pile' },
    h('p', { class: 'ui-s cm-sourdine' }, 'Un plugin relie le gestionnaire à un appareil ou à un service, pour cette campagne. Il reçoit ce qui se passe à la table (combat, heure, lieux, dés) et agit dehors ; coupé, il ne fait plus rien.'),
    cartes,
    h('details', { class: 'cm-plugin__evenements' },
      h('summary', { class: 'ui-s' }, 'Derniers événements du gestionnaire (ce que les plugins reçoivent)'),
      liste));
}
