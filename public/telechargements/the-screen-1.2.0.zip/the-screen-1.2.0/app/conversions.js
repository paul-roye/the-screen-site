// Conversion au chargement (app/donnees.js) : un fichier de data/ encore à un ancien format est converti en mémoire vers le
// format que lit l'outil, puis vérifié et lu comme les autres. Le fichier n'est jamais touché (data/ vient de l'agent IA de
// campagne ou du MJ) ; le bouton Données le signale (« converti du format N »). L'agent réexporte au nouveau format quand il
// en a l'occasion ; une conversion disparaît quand plus aucun fichier à l'ancien format n'est en service.
// CONVERSIONS[jeu][n] : d (format n) -> d (format n + 1).
//
// Version 1.0.0 : chaque format repart de son numéro du moment, sans conversion. Un format qui change ensuite ajoute ici
// sa fonction, par exemple : pnj: { 2: d => ({ ...d, schema: 3, … }) }.

const CONVERSIONS = {};

// Convertit d jusqu'au format `schema`, s'il le faut et si c'est possible : { donnees, depuis } (depuis : le format d'origine,
// null si rien n'a changé).
export function convertir(jeu, d, schema) {
  const etapes = CONVERSIONS[jeu] || {};
  const depuis = d?.schema;
  let x = d;
  while (x && typeof x.schema === 'number' && x.schema < schema && etapes[x.schema]) x = etapes[x.schema](x);
  return { donnees: x, depuis: x !== d ? depuis : null };
}
