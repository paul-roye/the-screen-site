// Babioles (data/babioles.json) : état (etat/babioles.json), tirage et fiche d'une babiole en fenêtre flottante
// (« babiole:<id> »). Partagé par le widget Babioles et par Rencontres (une babiole tirée par une rencontre :
// tirage_externe, app/rencontres-moteur.js). L'écran peut être vu des joueurs : la note du MJ, les secrets des éléments
// d'intrigue et les factions secrètes restent repliés. Formats : formats/babioles.md, formats/etat.md.

import { h, icone, bouton, badge, alerte, bascule, section, provenance, blocOriginal, identifiant, flottant, flottantOuvert, sansRamener } from './ui.js';
import { auHasard } from './des.js';
import { chargerLieux, nomLieu } from './lieux.js';
import { etatPnj, chargerFactions, ouvrirFichePnj, ouvrirFaction as ficheDeFaction } from './fiche-pnj.js';
import { lireBeyond, demanderExtension, ficheDe } from './beyond.js';
import { wikiActif } from './campagne.js';

const HISTORIQUE_MAX = 100;

export const tablesBabioles = d => (d?.tables || []).filter(t => t.id && Array.isArray(t.lignes));
export const finBabiole = l => l.jet_max ?? l.jet;
export const plageBabiole = l => finBabiole(l) !== l.jet ? `${l.jet}-${finBabiole(l)}` : String(l.jet);
export const vierge = l => !!l.a_remplir;
export const intituleBabiole = l => l.nom?.trim() || (l.texte?.trim().length > 90 ? l.texte.trim().slice(0, 88) + '…' : l.texte?.trim()) || l.id;

// Date d'une distribution : ISO complète (widget) ou AAAA-MM-JJ (date de séance, bloc maj-etat).
export function jourBabiole(quand) {
  if (!quand) return '?';
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(quand) ? `${quand}T12:00` : quand);
  return isNaN(d) ? quand : d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
}

export async function etatBabioles(etat, d) {
  const tables = tablesBabioles(d);
  const s = await etat('babioles', { schema: 1, table: tables[0]?.id ?? null, ecarter_distribuees: true, distribuees: {}, historique: [] });
  s.valeur.distribuees ||= {};
  s.valeur.historique ||= [];
  if (tables.length && !tables.some(t => t.id === s.valeur.table)) s.valeur.table = tables[0].id;
  return s;
}

// Lignes tirables d'une table : jamais une ligne vierge ; sans les babioles données si l'option « Écarter » est cochée.
export const tirables = (t, s) => t.lignes.filter(l => !vierge(l) && !(s.valeur.ecarter_distribuees && s.valeur.distribuees[l.id]));

// Chances égales par résultat de dé couvert : une ligne 81-82 a deux chances sur cent. Renvoie { l, jet } ou null.
export function tirerParmi(lignes) {
  if (!lignes.length) return null;
  const jet = auHasard(lignes.flatMap(l => Array.from({ length: finBabiole(l) - l.jet + 1 }, (_, i) => l.jet + i)));
  return { l: lignes.find(x => jet >= x.jet && jet <= finBabiole(x)), jet };
}

// Un tirage noté dans l'historique (« Derniers tirages » du widget Babioles).
export function noterTirage(s, table, l, jet) {
  const hist = s.valeur.historique;
  hist.push({ id: identifiant(), quand: new Date().toISOString(), table, ligne: l.id, jet });
  if (hist.length > HISTORIQUE_MAX) hist.splice(0, hist.length - HISTORIQUE_MAX);
}

// Fiches des babioles : chargées une fois (données, lieux, PNJ, factions, personnages), partagées par les widgets.
// contexte : { donnees, etat, dialogue } (dialogue pour « Donner »). Renvoie null si babioles.json ne se lit pas.
let chargement = null;
// La babiole d'un objet d'un inventaire D&D Beyond (objets_perso d'une fiche, objets du groupe : etat/beyond.json) : par sa
// note (« identifiant : <id> », mise par « Donner »), sinon par son nom (l'intitulé de la babiole, sans tenir compte de la
// casse, des accents ni des espaces). fb : ce que rend fichesBabioles() ; rend { l, t } ou null.
const cleNom = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const parNom = new WeakMap();
export function babioleDeLObjet(fb, { nom, note }) {
  if (!fb) return null;
  const id = /identifiant\s*:\s*([\w-]+)/i.exec(note || '')?.[1];
  if (id && fb.parId.has(id)) return fb.parId.get(id);
  if (!parNom.has(fb)) parNom.set(fb, new Map(fb.tables.flatMap(t => t.lignes.filter(l => !vierge(l)).map(l => [cleNom(intituleBabiole(l)), { l, t }]))));
  return parNom.get(fb).get(cleNom(nom)) || null;
}

export function fichesBabioles(contexte) {
  chargement ||= charger(contexte);
  return chargement;
}

async function charger({ donnees, etat, dialogue }) {
  const lecture = await donnees('babioles');
  if (lecture.statut !== 'ok') return null;
  const d = lecture.donnees;
  const tables = tablesBabioles(d);
  const lieux = await chargerLieux(donnees);
  const lieuxD = (await donnees('lieux')).donnees;
  const factions = await chargerFactions(donnees);
  const donneesPnj = (await donnees('pnj')).donnees;
  const pnjParId = new Map((donneesPnj?.pnj || []).map(p => [p.id, p]));
  const persos = (await donnees('personnages')).donnees?.personnages || [];
  const persoParId = new Map(persos.map(p => [p.id, p]));
  const elements = new Map((d.elements_intrigue || []).map(f => [f.id, f]));   // éléments d'intrigue (les reliques d'une intrigue secrète)
  const sPnj = await etatPnj(etat);
  const s = await etatBabioles(etat, d);
  const v = () => s.valeur;
  const parId = new Map(tables.flatMap(t => t.lignes.map(l => [l.id, { l, t }])));
  const donnee = l => v().distribuees[l.id];
  const aQui = a => a === 'groupe' ? 'au groupe' : a ? `à ${persoParId.get(a)?.nom || a}` : '';
  const libelleDonnee = dist => ['Donnée', aQui(dist.a), 'le', jourBabiole(dist.quand)].filter(Boolean).join(' ') + (dist.beyond ? ', ajoutée sur D&D Beyond' : '');
  const secrete = k => k.type === 'faction' && factions?.parId.get(k.id)?.secret;

  function nomElement(type, id) {
    if (type === 'lieu' || type === 'sous_lieu') return nomLieu(lieux, id);
    if (type === 'pnj') return pnjParId.get(id)?.nom || id;
    if (type === 'faction') return factions?.parId.get(id)?.nom || id;
    if (type === 'element_intrigue') return elements.get(id)?.nom || id;
    if (type === 'personnage') return persoParId.get(id)?.nom || id;
    return id;
  }

  // ───── Fiches ouvertes depuis les liens ─────

  const ouvrirPnj = p => ouvrirFichePnj(p, { lieux, s: sPnj, factions, typesRang: donneesPnj?.types_rang });
  const ouvrirFaction = f => ficheDeFaction(f, { pnj: donneesPnj?.pnj || [], s: sPnj, lieux, factions, typesRang: donneesPnj?.types_rang });

  // Lieu ou sous-lieu de lieux.json : type, zone, lieu qui le contient, décision du MJ, PNJ qu'on y croise, page du wiki.
  function ouvrirLieu(id) {
    const e = lieux.get(id);
    const brut = (lieuxD?.lieux || []).find(x => x.id === id);
    const parent = lieux.get(e?.parent || e?.situe_dans);
    const gens = (donneesPnj?.pnj || []).filter(p => e?.parent ? p.sous_lieu === id : p.lieu === id || p.sous_lieu === id);
    const wiki = !wikiActif() ? null : e?.wiki?.url || (e?.parent ? parent?.wiki?.url : null);
    flottant('lieu:' + id, { surtitre: parent ? nomLieu(lieux, parent.id) : 'Lieu', titre: e?.nom || id, contenu: h('div', { class: 'cm-pile cm-fiche-lieu' },
      h('p', { class: 'cm-lieu' }, icone('epingle', 'bn-icone--s'),
        [e?.typeLibelle || (e?.parent ? 'Sous-lieu' : null), e?.zone ? `zone ${e.zone}` : null, parent ? `dans ${parent.nom}` : null].filter(Boolean).join(' · ') || id),
      e ? null : h('p', { class: 'ui-s cm-sourdine' }, `« ${id} » absent de lieux.json.`),
      brut?.chapitre_livre ? h('p', { class: 'ui-s cm-sourdine' }, `Livre : chapitre ${brut.chapitre_livre}`) : null,
      brut?.decision_mj ? h('div', { class: 'cm-decision' }, badge('Décision du MJ', 'sang'), h('p', { class: 'ui' }, brut.decision_mj.texte)) : null,
      blocOriginal(brut?.original),
      gens.length ? section(`PNJ (${gens.length})`, 'lu-users', h('p', { class: 'cm-tenanciers' }, gens.map(p =>
        h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPnj(p) }, p.nom)))) : null,
      wiki ? h('p', { class: 'ui-s' }, h('a', { class: 'bn-lien', href: wiki, target: '_blank', rel: 'noopener' }, 'Page du wiki des joueurs')) : null) });
  }

  // Puce d'un lien (types_liens + nom de l'élément, note en infobulle) ; un clic ouvre la fiche quand il y en a une.
  function puce(k) {
    let nom = nomElement(k.type, k.id), ouvrir = null;
    if (k.type === 'lieu' || k.type === 'sous_lieu') ouvrir = () => ouvrirLieu(k.id);
    else if (k.type === 'pnj' && pnjParId.has(k.id)) ouvrir = () => ouvrirPnj(pnjParId.get(k.id));
    else if (k.type === 'faction' && factions?.parId.has(k.id)) ouvrir = () => ouvrirFaction(factions.parId.get(k.id));
    else if (k.type === 'element_intrigue' && elements.has(k.id)) {
      const f = elements.get(k.id);
      nom = `${f.nom} · ${nomLieu(lieux, f.sous_lieu || f.lieu)}`;
      ouvrir = () => ouvrirLieu(f.sous_lieu || f.lieu);
    }
    const contenu = [h('span', { class: 'cm-puce-lien__type' }, d.types_liens?.[k.type] || k.type), h('span', {}, nom)];
    return ouvrir
      ? h('button', { type: 'button', class: 'cm-puce-lien', title: k.note || `Ouvrir la fiche : ${nom}`, onclick: ouvrir }, contenu)
      : h('span', { class: 'cm-puce-lien', title: k.note || null }, contenu);
  }

  // Ce que seul le MJ voit, replié : note, secret et PNJ des éléments d'intrigue liés (la Dame et son identité, pour un
  // élément d'intrigue), factions secrètes.
  function blocMj(l) {
    const liens = l.lore_links || [];
    const fs = liens.filter(k => k.type === 'element_intrigue' && elements.has(k.id)).map(k => elements.get(k.id));
    const secretes = liens.filter(secrete);
    if (!l.note_mj?.trim() && !fs.length && !secretes.length) return null;
    return h('details', { class: 'cm-babiole__mj' },
      h('summary', {}, badge('MJ', 'sang', 'lu-eye-off'), h('span', { class: 'ui-s' }, 'Secret : à ne pas montrer aux joueurs')),
      l.note_mj?.trim() ? h('p', { class: 'texte' }, l.note_mj) : null,
      fs.length ? h('ul', { class: 'ui-s cm-liste' }, fs.map(f => {
        const p = f.pnj ? pnjParId.get(f.pnj) : null;
        return h('li', {}, h('b', {}, `${f.nom} : `), f.detail_mj || '', f.detail_mj && f.pnj ? ', aujourd\'hui ' : !f.detail_mj && f.pnj ? 'PNJ : ' : '',
          p ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPnj(p) }, p.nom) : f.pnj || '', '.');
      })) : null,
      secretes.length ? h('div', { class: 'cm-puces-liens' }, secretes.map(puce)) : null);
  }

  function copier(l, btn) {
    const texte = [l.nom?.trim(), l.texte?.trim()].filter(Boolean).join('\n\n');
    navigator.clipboard?.writeText(texte).then(() => {
      btn.replaceChildren(icone('lu-check'));
      setTimeout(() => btn.replaceChildren(icone('lu-copy')), 1200);
    }).catch(() => {});
  }

  // Fiche D&D Beyond qui reçoit l'objet : celle du personnage ; pour le groupe, celle d'un membre (l'objet va dans
  // l'inventaire du groupe de la campagne). null si elle n'est pas relevée (etat/beyond.json).
  function cibleBeyond(beyond, a) {
    if (a === 'groupe') {
      const membre = Object.keys(beyond.fiches || {})[0];
      return membre && beyond.campagne?.id ? { personnage: membre, groupe: true, campagne: beyond.campagne.id } : null;
    }
    const p = persoParId.get(a);
    const f = p ? ficheDe(p, beyond) : null;
    return f ? { personnage: f.id, groupe: false } : null;
  }

  // L'objet personnalisé créé dans D&D Beyond (extensions/mj/fond.js, commande « objet ») : le nom, le texte pour les joueurs
  // (jamais la note du MJ), et en note l'identifiant de la babiole dans data/babioles.json.
  async function ajouterABeyond(l, a) {
    const beyond = await lireBeyond();
    const cible = cibleBeyond(beyond, a);
    if (!cible) throw new Error(a === 'groupe' ? 'Campagne D&D Beyond pas encore relevée par l\'extension.' : `Fiche D&D Beyond de ${aQui(a).replace(/^à /, '')} introuvable dans les relevés de l'extension.`);
    try {
      return await demanderExtension({ type: 'objet', ...cible, nom: intituleBabiole(l), description: l.texte?.trim() || '',
        note: l.id ? `Note MJ : identifiant : ${l.id}` : '' });
    } catch (e) {   // extension d'avant 1.3.0 : elle ne connaît pas « objet »
      throw /Demande inconnue/.test(e.message) ? new Error('L\'extension ne sait pas encore ajouter d\'objet : rechargez-la dans chrome://extensions (version 1.3.0).') : e;
    }
  }

  // « Donner » : à un personnage, au groupe ou sans préciser, avec une note facultative ; à un personnage ou au groupe,
  // l'objet peut aussi être ajouté à son inventaire D&D Beyond (une seule fois : noté dans `beyond`).
  function donner(l, noteDon = '') {
    const avant = donnee(l);
    let choix = avant ? avant.a : l.personnage || 'groupe';
    const options = [...persos.filter(p => p.role === 'personnage').map(p => [p.id, p.nom]), ['groupe', 'Le groupe'], ['', 'Non précisé']];
    const caseBeyond = h('input', { type: 'checkbox', class: 'bn-case', checked: !avant?.beyond });
    const ligneBeyond = h('label', { class: 'cm-case', title: 'Objet personnalisé dans l\'inventaire du personnage, ou dans celui du groupe (party) : son nom, son texte, et en note son identifiant. Par l\'extension Chrome.' },
      caseBeyond, h('span'));
    const zoneChoix = h('div', { class: 'cm-babiole-qui' });
    const majChoix = () => {
      zoneChoix.replaceChildren(bascule('À qui', options, choix, val => { choix = val; majChoix(); }));
      ligneBeyond.hidden = !choix || !!avant?.beyond;
      ligneBeyond.lastChild.textContent = choix === 'groupe' ? 'Ajouter à l\'inventaire du groupe sur D&D Beyond' : 'Ajouter à son inventaire D&D Beyond';
    };
    majChoix();
    const note = h('textarea', { class: 'bn-textarea', rows: 2, 'aria-label': 'Note', placeholder: 'Où, comment : dans la poche d\'un cadavre, offerte par la vieille diseuse…' }, avant ? avant.note || '' : noteDon);
    const etatBeyond = h('div', { 'aria-live': 'polite' });
    let dlg;
    const btnAnnuler = bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() });
    const btnDonner = bouton(avant ? 'Enregistrer' : 'Donner', { classe: 'bn-btn--primaire', icone: 'lu-gift', onclick: async () => {
      const dist = { ...avant, quand: avant?.quand || new Date().toISOString(), a: choix, note: note.value.trim() };
      v().distribuees[l.id] = dist;
      s.enregistrer(0);
      s.signaler();
      if (!choix || ligneBeyond.hidden || !caseBeyond.checked) { dlg.close(); return; }
      // Le don est noté ; reste D&D Beyond. Un échec laisse la fenêtre ouverte, avec l'erreur.
      btnDonner.disabled = true;
      etatBeyond.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Ajout dans D&D Beyond…'));
      try {
        const r = await ajouterABeyond(l, choix);
        dist.beyond = { quand: new Date().toISOString(), a: choix, objet: r.id };
        s.enregistrer(0);
        s.signaler();
        dlg.close();
      } catch (e) {
        etatBeyond.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Donnée, mais pas ajoutée à D&D Beyond', e.message));
        btnDonner.disabled = false;
        btnDonner.lastChild.textContent = 'Réessayer D&D Beyond';
        btnAnnuler.lastChild.textContent = 'Fermer';
      }
    } });
    dlg = dialogue('Babioles', `Donner : ${intituleBabiole(l)}`, h('div', { class: 'cm-pile' },
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'À qui ?'), zoneChoix),
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Note (facultative)'), note),
      ligneBeyond, etatBeyond), [btnAnnuler, btnDonner]);
  }

  function reprendre(l) {
    if (!confirm(`Reprendre « ${intituleBabiole(l)} » ? Elle redevient tirable, et sa note de distribution est effacée.`)) return;
    delete v().distribuees[l.id];
    s.enregistrer(0);
    s.signaler();
  }

  // Fiche d'une babiole, dans sa fenêtre flottante (le nom, la table et le jet sont dans le titre de la fenêtre).
  // relancer : { faire, possible, titre } quand elle vient d'être tirée (« Relancer » en tire une autre).
  function carteBabiole(l, { relancer = null, noteDon = '' } = {}) {
    const dist = donnee(l);
    const publics = (l.lore_links || []).filter(k => !secrete(k));
    const perso = l.personnage ? persoParId.get(l.personnage)?.nom || l.personnage : null;
    const btnCopier = bouton('', { icone: 'lu-copy', titre: 'Copier le nom et le texte (sans la note du MJ)', classe: 'bn-btn--s bn-btn--fantome', onclick: e => copier(l, e.currentTarget) });
    return h('div', { class: 'cm-pile cm-babiole' },
      h('div', { class: 'cm-fiche__tete' },
        h('span'),
        h('div', { class: 'bn-groupe' }, l.theme ? badge(d.themes?.[l.theme] || l.theme, null) : null, btnCopier)),
      dist ? alerte('brume', 'lu-gift', libelleDonnee(dist), dist.note || '') : null,
      vierge(l) ? alerte('cierge', 'lu-pencil', 'Emplacement à remplir', 'Cette ligne est vierge : à remplir dans data/babioles.json, à la main ou avec votre agent IA de campagne si vous en avez un.') : null,
      l.texte?.trim() ? h('figure', { class: 'bn-alire' },
        h('figcaption', { class: 'bn-alire__label' }, icone('livre', 'bn-icone--s'), 'Pour les joueurs'),
        h('p', {}, l.texte)) : null,
      perso || l.lien_personnage?.trim() ? h('div', { class: 'cm-section' },
        h('p', { class: 'etiquette cm-section__titre' }, icone('lu-users', 'bn-icone--s'), perso ? `Personnage : ${perso}` : 'Personnage'),
        l.lien_personnage?.trim() ? h('p', { class: 'ui' }, l.lien_personnage) : null) : null,
      publics.length ? h('div', { class: 'cm-puces-liens' }, publics.map(puce)) : null,
      blocMj(l),
      vierge(l) ? null : h('div', { class: 'bn-groupe' },
        dist
          ? [bouton('Modifier', { classe: 'bn-btn--s', icone: 'lu-pencil', onclick: () => donner(l) }),
            bouton('Reprendre', { classe: 'bn-btn--s', icone: 'lu-rotate-ccw', titre: 'Annuler la distribution', onclick: () => reprendre(l) })]
          : bouton('Donner', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-gift', onclick: () => donner(l, noteDon) }),
        relancer ? bouton('Relancer', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', disabled: !relancer.possible(), titre: relancer.titre, onclick: relancer.faire }) : null),
      provenance(l));
  }

  // Une fenêtre par babiole ; o : { jet, relancer, noteDon (note proposée pour « Donner ») }. Après un don, une reprise : les fenêtres ouvertes suivent.
  const fenetres = new Map();   // id de babiole ouverte -> o
  function ouvrir(l, o = {}) {
    const { t } = parId.get(l.id);
    fenetres.set(l.id, o);
    flottant('babiole:' + l.id, {
      surtitre: `${t.nom} · ${o.jet != null ? `jet ${o.jet} sur ${t.de}` : `${t.de} : ${plageBabiole(l)}`}`,
      // Le nom, sinon (babioles du livre) le début de son texte ; le jet reste dans le surtitre.
      titre: intituleBabiole(l),
      contenu: carteBabiole(l, o),
    });
  }
  function rafraichir() {
    for (const [id, o] of fenetres) {
      if (flottantOuvert('babiole:' + id) && parId.has(id)) sansRamener(() => ouvrir(parId.get(id).l, o));
      else fenetres.delete(id);
    }
  }
  s.abonner(rafraichir);

  // Tirage dans une table, sans filtre (menu rapide) : comme « Tirer » du widget Babioles, noté dans l'historique, ouvert
  // dans sa fenêtre avec « Relancer ». eviter : la babiole qu'on relance. Renvoie la ligne tirée, ou null s'il n'y a rien à tirer.
  function tirerDans(tableId, eviter = null) {
    const t = tables.find(x => x.id === tableId);
    let liste = t ? tirables(t, s) : [];
    if (eviter && liste.length > 1) liste = liste.filter(l => l.id !== eviter);
    const r = tirerParmi(liste);
    if (!r) return null;
    noterTirage(s, t.id, r.l, r.jet);
    s.enregistrer(0);
    if (eviter) flottantOuvert('babiole:' + eviter)?.fermer();
    ouvrir(r.l, { jet: r.jet, relancer: { possible: () => tirables(t, s).length > 0, titre: 'Relancer dans la table', faire: () => tirerDans(tableId, r.l.id) } });
    s.signaler();   // le widget Babioles redessine ses derniers tirages
    return r.l;
  }

  return { d, tables, parId, s, lieux, factions, elements, pnjParId, persos, persoParId, donnee, libelleDonnee, secrete, nomElement, ouvrir, rafraichir, tirerDans };
}
