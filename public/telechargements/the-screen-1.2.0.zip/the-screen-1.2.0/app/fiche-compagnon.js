// Fiche d'un compagnon (un familier, un compagnon animal…) en bloc de stats, comme la fenêtre de l'extension du joueur
// (extensions/compagnon/fenetre.js, demande du MJ, 2026-10-24) : le profil de la créature relevé par l'extension du MJ
// (`profil` des créatures de etat/beyond.json, depuis 1.14.0), sa CA et ses PV personnalisés, le bonus de maîtrise de son
// soigneur pour un compagnon de Flee, Mortals! (« plus PB »), « PB » encadré dans les textes, et les pouvoirs de férocité
// marqués de leur coût. Côté MJ, rien ne se dépense : la férocité est tenue par le joueur, dans son extension.

import { h, icone, infobulle } from './ui.js';
import { blocStats, signe } from './monstres.js';

const DESCRIPTIONS = ['specialTraitsDescription', 'actionsDescription', 'bonusActionsDescription', 'reactionsDescription'];
const POUVOIR = /^\s*(\d+)\s*(?:st|nd|rd|th)\s+level\s*:\s*(.+?)\s*\(\s*(\d+)\s+ferocity\s*\)/i;
const SIGNATURE = /^\s*signature attack\b/i;
// « DC 10 plus PB » : le DD compte le bonus de maîtrise du soigneur (le bloc de stats ne lit que le nombre).
const ddAvecPb = (texte, pb) => texte && texte.replace(/\bDC\s*(\d+)\s+plus\s+(?:your\s+)?(?:PB|Proficiency Bonus)\b/gi, (_, n) => `DC ${Number(n) + pb}`);

// Un compagnon de Flee, Mortals! : des pouvoirs de férocité, une attaque de signature.
export function estCompagnonFlee(profil) {
  const texte = DESCRIPTIONS.map(k => profil?.[k] || '').join(' ');
  return /\bferocity\b/i.test(texte) || /signature attack/i.test(texte);
}

// cr : la créature du relevé (avec `profil`) ; niveau et pb : ceux de son soigneur ; cfg : dictionnaire de D&D Beyond
// (configBeyond de app/rencontres-mj.js), ou null (libellés de type et de taille absents). null sans profil relevé.
export function blocCompagnon(cr, { cfg = null, niveau = 1, pb = 2 } = {}) {
  const def = cr?.profil;
  if (!def) return null;
  const flee = estCompagnonFlee(def);
  const descriptions = Object.fromEntries(DESCRIPTIONS.map(k => [k, ddAvecPb(def[k], pb)]));
  const fiche = blocStats({ ...def, ...descriptions, name: cr.nom, armorClass: cr.ca ?? def.armorClass, averageHitPoints: cr.pv?.max ?? def.averageHitPoints },
    cfg, { pb: flee ? pb : null });
  if (flee) marquerPouvoirs(fiche, cr, niveau);
  // Pas de puissance (FP, PX) pour un compagnon : son seul PB, celui du soigneur pour un compagnon de Flee, Mortals!, sinon
  // celui de son FP.
  const pbAffiche = flee ? pb : (cfg?.puissances || []).find(x => x.id === def.challengeRatingId)?.maitrise ?? pb;
  const lignes = fiche.querySelector(':scope > dl.bn-stat__lignes');
  const puissance = [...(lignes?.querySelectorAll('dt') || [])].find(dt => dt.textContent === 'Puissance')?.parentElement;
  const lignePb = h('div', {}, h('dt', {}, 'PB'), h('dd', {}, `${signe(pbAffiche)} (bonus de maîtrise${flee ? ' de son soigneur' : ''})`));
  if (puissance) puissance.replaceWith(lignePb); else lignes?.append(lignePb);
  encadrerPb(fiche, pbAffiche);
  return fiche;
}

// Chaque pouvoir de férocité : au début de sa ligne, une griffe et son coût ; grisé s'il demande un niveau que le soigneur
// n'a pas, le coût en orange s'il dépasse la férocité notée. L'attaque de signature est marquée.
function marquerPouvoirs(fiche, cr, niveau) {
  const nomDe = p => p.querySelector('strong, b')?.textContent || '';
  for (const p of fiche.querySelectorAll('p.bn-stat__trait')) {
    if (SIGNATURE.test(nomDe(p))) { p.classList.add('cm-pouvoir--signature'); continue; }
    const m = POUVOIR.exec(nomDe(p));
    if (!m) continue;
    const niv = Number(m[1]), nom = m[2].trim(), cout = Number(m[3]);
    const inaccessible = niveau < niv, court = cr.ferocite != null && cr.ferocite < cout;
    p.classList.add('cm-pouvoir');
    p.classList.toggle('est-inaccessible', inaccessible);
    p.prepend(infobulle(h('span', { class: 'bn-badge cm-pouvoir__cout' + (court ? ' est-court' : ''), tabindex: '0' }, icone('griffe', 'bn-icone--s'), String(cout)),
      inaccessible ? `Niveau ${niv} requis : son soigneur est niveau ${niveau}.`
        : `${cout} férocité${cr.ferocite != null ? ` (il en a ${cr.ferocite})` : ''}. Le joueur la dépense dans son extension.`, { titre: `${nom} : ${cout} férocité` }), ' ');
  }
}

// Dans le texte des capacités et actions : « PB » devient un petit encadré violet (au survol, sa valeur : « PB : +2 ») ;
// « 2 × PB » ou « PB × 2 » aussi. Les dés de dégâts (« 1d6+PB ») restent des boutons de jet.
const MOTIF_PB = /(\d+)\s*[×x]\s*PB\b|\bPB\s*[×x]\s*(\d+)\b|\bPB\b/g;
function encadrerPb(fiche, pb) {
  if (!Number.isInteger(pb)) return;
  const boite = (texte, bulle) => infobulle(h('span', { class: 'bn-badge bn-badge--ultra cm-pb', tabindex: '0' }, texte), bulle, { titre: 'Bonus de maîtrise' });
  for (const p of fiche.querySelectorAll('p.bn-stat__trait')) {
    const marcheur = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
    const noeuds = [];
    for (let n = marcheur.nextNode(); n; n = marcheur.nextNode()) {
      if (/\bPB\b/.test(n.data) && !n.parentElement.closest('button, .bn-dd, .cm-pouvoir__cout')) noeuds.push(n);
    }
    for (const n of noeuds) {
      const morceaux = [];
      let fin = 0;
      for (const m of n.data.matchAll(MOTIF_PB)) {
        const k = Number(m[1] || m[2]) || 1;
        morceaux.push(n.data.slice(fin, m.index), k > 1 ? boite(`PB × ${k}`, `PB × ${k} : ${signe(k * pb)}`) : boite('PB', `PB : ${signe(pb)}`));
        fin = m.index + m[0].length;
      }
      morceaux.push(n.data.slice(fin));
      n.replaceWith(...morceaux.filter(x => x !== ''));   // replaceWith() écrirait les chaînes vides : filtrées
    }
  }
}
