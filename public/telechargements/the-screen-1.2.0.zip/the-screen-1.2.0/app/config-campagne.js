// Réglages d'une campagne (son manifeste, formats/campagne.md) : le formulaire de la fenêtre Campagne (onglet « Campagne »,
// campagne ouverte) et celui de l'accueil (« Nouvelle campagne »). formulaireCampagne(m, { creation, chartes, icones,
// modules }) -> { element, lire() } : lire() rend le manifeste complet, ou lève une erreur lisible (champ manquant).
// À la création seulement : l'identifiant (le dossier), le genre de campagne (Classique ou Curse of Strahd, qui pré-règle le
// ciel, la charte, le vocabulaire, les sources, les livres de D&D Beyond et les modules) et les modules. Le reste se change
// ensuite, campagne lancée. Un module réservé à un genre (le Tarokka, à Curse of Strahd) porte un avertissement.

import { h, bascule, alerte, bouton } from './ui.js';
import { CALENDRIERS, MODELES_CALENDRIERS, MOIS_DU_CALENDRIER_CLASSIQUE, reglagesTemps } from './calendrier.js';

// [id de source de D&D Beyond, sigle, titre] : les livres de départ selon le genre (app/livres-beyond.js, LIVRES_BASE).
const LIVRES_BASE = [[147, 'MM', 'Monster Manual (2024)'], [146, 'DMG', 'Dungeon Master’s Guide (2024)'], [145, 'PHB', 'Player’s Handbook (2024)'], [148, 'BR', 'D&D Beyond Basic Rules (2024)']];
export const GENRES = {
  classique: {
    libelle: 'Classique', aide: 'Une campagne maison ou un autre module : ciel ordinaire, livres de règles 2024, rien de pré-rempli.',
    charte: 'medieval-glorieux', ciel_voile: false, livres: LIVRES_BASE, modules: [], musique: ['fantasy'], calendrier: 'classique', meteo: 'carcassonne-2009-2010', evenements: false, vocabulaire: {}, sources: {},
  },
  'curse-of-strahd': {
    libelle: 'Curse of Strahd', aide: 'La Malédiction de Strahd : ciel toujours voilé, charte Barovie Néon, vocabulaire de la Barovie, module Tarokka, livres Curse of Strahd et Ravenloft: The Horrors Within. L\'auteur de cet outil vous recommande aussi le supplément Fleshing Out Curse of Strahd (DMs Guild) : votre agent IA de campagne peut en tirer les données, avec ses écarts.',
    charte: 'barovie-neon', ciel_voile: true, livres: [...LIVRES_BASE, [6, 'CoS', 'Curse of Strahd'], [232, 'RtHW', 'Ravenloft: The Horrors Within']], modules: ['tarokka'],
    musique: ['fantasy', 'curse-of-strahd'], calendrier: 'barovien', meteo: 'tallinn-2009-2010', evenements: true,
    vocabulaire: { monde: 'la Barovie', de_monde: 'de Barovie', dans_le_monde: 'en Barovie', habitant: 'Barovien', habitants: 'Baroviens' },
    sources: { 'CoS-VF': { court: 'Livre', nom: 'La Malédiction de Strahd (VF)' } },
  },
};
const MOTS = [
  ['monde', 'Le monde', 'le royaume d\'Aurval'], ['de_monde', '« de… »', 'd\'Aurval'], ['dans_le_monde', '« en… »', 'en Aurval'],
  ['habitant', 'Un habitant', 'Aurvalien'], ['habitants', 'Les habitants', 'Aurvaliens'],
];

// « Les Bannières d'Aurval » -> « les-bannieres-d-aurval » (identifiant de dossier).
export const versIdentifiant = t => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
  .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64);

// `meteos` : les météos fournies (modeles/meteos/index.json) ; `importes` : { calendrier, meteo }, vrai quand la campagne a
// un calendrier ou une météo importés dans data/ (proposés alors comme « importé »).
export function formulaireCampagne(m = {}, { creation = false, chartes = [], icones = [], modules = [], musiques = [], meteos = [], importes = {} } = {}) {
  const champ = (libelle, input, aide) => h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, libelle), input,
    aide ? h('span', { class: 'ui-s cm-sourdine' }, aide) : null);
  const texte = (valeur, attrs = {}) => h('input', { class: 'bn-input', type: 'text', value: valeur ?? '', ...attrs });
  const choix = (valeur, options) => h('select', { class: 'bn-select' }, options.map(([v, t]) => h('option', { value: v, selected: v === valeur }, t)));
  const caseACocher = (coche, libelle, aide) => {
    const input = h('input', { type: 'checkbox', class: 'bn-case', checked: !!coche });
    return { input, el: h('label', { class: 'cm-case' }, input, h('span', {}, h('b', {}, libelle), aide ? [h('br'), h('span', { class: 'ui-s cm-sourdine' }, aide)] : null)) };
  };
  const section = (titre, ...contenu) => h('fieldset', { class: 'cm-config__section' }, h('legend', { class: 'etiquette' }, titre), ...contenu);

  // Identité
  const titre = texte(m.titre, { required: true, placeholder: 'Les Bannières d\'Aurval' });
  const sousTitre = texte(m.sous_titre, { placeholder: 'Une ligne sous le titre, dans l\'accueil' });
  const ident = texte(m.id, { pattern: '[a-z0-9][a-z0-9-]*', placeholder: 'les-bannieres-d-aurval' });
  let identTouche = !!m.id;
  if (creation) {
    titre.addEventListener('input', () => { if (!identTouche) ident.value = versIdentifiant(titre.value); });
    ident.addEventListener('input', () => { identTouche = true; });
  }
  const icone = choix(m.icone || 'd20', (icones.length ? icones : [m.icone || 'd20']).map(n => [n, n]));

  // Genre (création) : pré-règle la charte, le ciel, le vocabulaire et les modules (voir GENRES).
  let genre = GENRES[m.genre] ? m.genre : 'classique';
  const zoneGenre = h('div');
  const charte = choix(m.charte || (creation ? GENRES[genre].charte : 'barovie-neon'), chartes.map(c => [c.id, c.nom]));
  const ciel = caseACocher(m.reglages?.ciel_voile ?? (creation ? GENRES[genre].ciel_voile : false), 'Ciel toujours voilé', 'Jamais de soleil (un monde sous des brumes éternelles) : l\'Horloge ne dessine pas de soleil et rappelle d\'une icône qu\'il faut décrire le temps sous ce voile.');

  // Le temps de l'Horloge (formats/campagne.md) : le calendrier et la météo, fournis par le gestionnaire (modeles/), ou
  // importés dans data/ (proposés seulement s'ils existent), ou aucun. Un calendrier fourni a sa date de départ, avec le
  // départ qu'il conseille ; tous ont 365 jours.
  const temps = reglagesTemps(creation ? { calendrier: { type: 'modele', modele: GENRES[genre].calendrier }, meteo: { type: 'modele', modele: GENRES[genre].meteo } } : m);
  const valeurCal = temps.calendrier.type === 'modele' ? temps.calendrier.modele : temps.calendrier.type;
  const calendrier = choix(valeurCal, [...CALENDRIERS.map(c => [c.id, c.nom]),
    ...(importes.calendrier || valeurCal === 'importe' ? [['importe', 'Calendrier importé (data/calendrier.json)']] : []), ['aucun', 'Aucun : jour 1, jour 2…']]);
  const debut = temps.calendrier.debut || {};
  const anDebut = h('input', { class: 'bn-input bn-input--nombre cm-date-depart__an', type: 'number', step: '1', 'aria-label': 'Année', value: Number.isInteger(debut.annee) ? debut.annee : '' });
  const moisDebut = h('select', { class: 'bn-select cm-date-depart__mois', 'aria-label': 'Mois ou jour de fête' });
  const jourDebut = h('input', { class: 'bn-input bn-input--nombre cm-date-depart__jour', type: 'number', min: '1', step: '1', 'aria-label': 'Jour', value: debut.jour || '' });
  // Un jour de fête hors des mois (Harptos : Hiver fatal, Herbeverte…) n'a qu'un jour : pas de jour à choisir.
  const feteChoisie = () => !!calCharge?.mois?.find(x => x.id === moisDebut.value)?.fete;
  const majJour = () => { const f = feteChoisie(); jourDebut.hidden = f; if (f) jourDebut.value = 1; };
  moisDebut.addEventListener('change', majJour);
  const conseilDebut = h('span', { class: 'ui-s cm-sourdine' });
  const descCal = h('span', { class: 'ui-s cm-sourdine' });
  // Le jour 1, serré sur une ligne, dans l'ordre d'une date : « 27 octobre 1009 » (demande du MJ, 2026-10-25).
  const zoneDebut = h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Le jour 1 de la campagne'),
    h('div', { class: 'cm-date-depart' }, jourDebut, moisDebut, anDebut), conseilDebut);
  // Les mois du calendrier choisi (le fichier fourni, lu une fois), pour la date de départ ; son départ conseillé.
  const lus = new Map();
  let calCharge = null;
  const lireCalendrier = id => {
    if (id === 'classique') return Promise.resolve({ mois: MOIS_DU_CALENDRIER_CLASSIQUE, debut_conseille: { annee: 1, mois: 'janvier', jour: 1 } });
    if (!lus.has(id)) lus.set(id, fetch(`${MODELES_CALENDRIERS}${encodeURIComponent(id)}.json`).then(r => (r.ok ? r.json() : null)).catch(() => null));
    return lus.get(id);
  };
  let dateTouchee = !!debut.mois;
  [anDebut, moisDebut, jourDebut].forEach(x => x.addEventListener('input', () => { dateTouchee = true; }));
  const majCalendrier = async () => {
    const id = calendrier.value;
    descCal.textContent = CALENDRIERS.find(c => c.id === id)?.description || (id === 'importe' ? 'Celui de data/calendrier.json, écrit à la main ou avec votre agent IA de campagne, sa date de départ comprise.' : 'Le jour de campagne seul.');
    zoneDebut.hidden = !CALENDRIERS.some(c => c.id === id);
    if (zoneDebut.hidden) { calCharge = null; return; }
    const cal = await lireCalendrier(id);
    if (calendrier.value !== id) return;
    calCharge = cal;
    const garde = moisDebut.value;
    moisDebut.replaceChildren(...(cal?.mois || []).map(x => h('option', { value: x.id }, x.fete ? `${x.nom} (jour de fête)` : x.nom)));
    const conseil = cal?.debut_conseille;
    if (!dateTouchee && conseil) { anDebut.value = conseil.annee; moisDebut.value = conseil.mois; jourDebut.value = conseil.jour; }
    else moisDebut.value = (cal?.mois || []).some(x => x.id === (debut.mois || garde)) ? debut.mois || garde : cal?.mois?.[0]?.id;
    conseilDebut.textContent = conseil?.texte || '';
    majJour();
  };
  const typeMeteo = temps.meteo.type === 'modele' ? `modele:${temps.meteo.modele}` : temps.meteo.type;
  const meteo = choix(typeMeteo, [...meteos.map(x => [`modele:${x.id}`, `${x.nom}${x.climat ? ` (${x.climat})` : ''}`]),
    ...(typeMeteo.startsWith('modele:') && !meteos.some(x => `modele:${x.id}` === typeMeteo) ? [[typeMeteo, typeMeteo.slice(7)]] : []),
    ...(importes.meteo || typeMeteo === 'importe' ? [['importe', 'Météo importée (data/meteo.json)']] : []), ['aucune', 'Aucune']]);
  const descMeteo = h('span', { class: 'ui-s cm-sourdine' });
  const debutReel = texte(temps.meteo.debut_reel, { placeholder: '10-01', pattern: '\\d{2}-\\d{2}' });
  const zoneReel = champ('Météo du jour 1 : la date réelle (MM-JJ)', debutReel, 'Sans calendrier, la météo part de ce jour de la première année du relevé (son premier jour par défaut), puis suit jour après jour.');
  const majTemps = () => {
    descMeteo.textContent = meteos.find(x => `modele:${x.id}` === meteo.value)?.description || (meteo.value === 'importe' ? 'Celle de data/meteo.json : écrite par « outils/Importer la météo.cmd », à la main ou avec votre agent IA de campagne.' : '');
    zoneReel.hidden = !(calendrier.value === 'aucun' && meteo.value !== 'aucune');
    majCalendrier();
  };
  calendrier.addEventListener('change', () => { dateTouchee = false; majTemps(); });
  meteo.addEventListener('change', majTemps);
  majTemps();
  const theme = choix(m.theme || 'nuit', [['nuit', 'Nuit'], ['parchemin', 'Parchemin']]);

  // Monde : le vocabulaire des textes (« Bêtes d'Aurval »).
  const mots = Object.fromEntries(MOTS.map(([cle, , exemple]) => [cle, texte(m.vocabulaire?.[cle], { placeholder: exemple })]));

  // Modules (création) : les mécaniques propres à une campagne. Un module réservé à un genre (le Tarokka, à Curse of Strahd)
  // le dit dans sa case, et une alerte paraît s'il est coché pour un autre genre.
  const casesModules = modules.map(x => ({ id: x.id, module: x, ...caseACocher((m.modules || []).includes(x.id), x.titre, x.description) }));
  const alertesModules = h('div', { class: 'cm-pile' });
  const majAlertesModules = () => alertesModules.replaceChildren(...casesModules
    .filter(c => c.input.checked && c.module.genre && c.module.genre !== genre)
    .map(c => alerte('cierge', 'lu-triangle-alert', `${c.module.titre} : réservé à Curse of Strahd`, c.module.avertissement)));
  casesModules.forEach(c => c.input.addEventListener('change', majAlertesModules));

  // Musique (création) : les paquets de musique par défaut (app/musique-paquets.js) copiés dans musique/ de la campagne.
  const casesMusique = musiques.map(x => ({ id: x.id, ...caseACocher(false, x.nom,
    `${x.description} ${x.playlists} playlists, ${x.pistes} pistes.`) }));

  const appliquerGenre = g => {
    const avant = GENRES[genre];
    genre = g;
    const G = GENRES[g];
    charte.value = G.charte;
    ciel.input.checked = G.ciel_voile;
    // Le vocabulaire du genre remplace celui du genre précédent, pas celui que le MJ a tapé.
    for (const [cle] of MOTS) if (!mots[cle].value.trim() || mots[cle].value === avant.vocabulaire[cle]) mots[cle].value = G.vocabulaire[cle] || '';
    casesModules.forEach(c => { c.input.checked = G.modules.includes(c.id); });
    casesMusique.forEach(c => { c.input.checked = G.musique.includes(c.id); });
    calendrier.value = G.calendrier;
    evenementsCase.input.checked = !!G.evenements;
    if (meteos.some(x => x.id === G.meteo)) meteo.value = `modele:${G.meteo}`;
    dateTouchee = false;
    majTemps();
    majAlertesModules();
    majGenre();
  };
  const majGenre = () => zoneGenre.replaceChildren(
    bascule('Genre de campagne', Object.entries(GENRES).map(([id, g]) => [id, g.libelle]), genre, appliquerGenre),
    h('p', { class: 'ui-s cm-sourdine' }, GENRES[genre].aide));
  majGenre();

  // Rencontres aléatoires (demande du MJ, 2026-10-25) : le plafond, dit comme une phrase (« Pas plus de 2 rencontres toutes
  // les 12 heures de jeu » : vide, celui de la table de la campagne), et les événements de campagne du widget Rencontres.
  const plafond = m.reglages?.plafond_rencontres || {};
  const nombre = (valeur, attrs) => h('input', { class: 'bn-input bn-input--nombre cm-phrase__nombre', type: 'number', min: '1', step: '1', value: valeur ?? '', ...attrs });
  const nbRencontres = nombre(plafond.rencontres, { placeholder: '2', 'aria-label': 'Nombre de rencontres' });
  const heuresFenetre = nombre(plafond.heures, { placeholder: '12', 'aria-label': 'Heures de jeu' });
  const evenementsCase = caseACocher(m.reglages?.evenements ?? (creation ? GENRES[genre].evenements : false), 'Événements de campagne',
    'Un bouton de plus dans le widget Rencontres, après « Rencontre » : un événement propre à la campagne (des espions qui suivent les héros…), ce qu\'il raconte, ce que le MJ doit faire, puis l\'ajouter comme rencontre (il compte alors dans le plafond) ou passer. Ses textes viennent de data/evenements.json, à écrire à la main ou avec votre agent IA de campagne : sans lui, rien ne s\'affiche.');
  if (creation && !m.genre) appliquerGenre(genre);   // après toutes les cases que le genre pré-règle

  // Liens : D&D Beyond, wiki vvd.world (facultatif).
  const beyond = texte(m.beyond?.url, { type: 'url', placeholder: 'https://www.dndbeyond.com/campaigns/1234567' });
  const wiki = caseACocher(!!m.wiki?.url, 'Wiki de campagne (vvd.world)', 'Le gestionnaire sait importer un wiki publié sur vvd.world pour nourrir votre agent IA de campagne, si vous en avez un : après chaque import, donnez-lui wiki/wiki-complet.md (et wiki/changements.md). C\'est surtout utile quand les joueurs écrivent eux-mêmes : un journal de bord où ils racontent leur aventure, des pages où ils décrivent leurs personnages. L\'agent peut reprendre ces descriptions pour nourrir le récit, se souvenir de ce que les joueurs ont retenu et imaginer des quêtes annexes à partir de leurs histoires. Le gestionnaire, lui, n\'en prend que les liens vers les pages et, à défaut d\'autres, les portraits des héros.');
  const wikiUrl = texte(m.wiki?.url, { type: 'url', placeholder: 'https://….vvd.world/u/…', disabled: !m.wiki?.url });
  const wikiHeros = texte(m.wiki?.categorie_heros, { placeholder: 'Héros', disabled: !m.wiki?.url });
  // Les deux champs côte à côte, alignés par le haut, l'aide en dessous, puis l'import du wiki ; le tout grisé (libellés
  // compris) et sans effet tant que la case est décochée (demande du MJ, 2026-10-25).
  const champsWiki = h('div', { class: 'cm-pile cm-champs-lies' },
    h('div', { class: 'bn-ligne-champs cm-ligne-haut' }, champ('Adresse du wiki', wikiUrl), champ('Catégorie des héros', wikiHeros)),
    h('span', { class: 'ui-s cm-sourdine' }, 'Catégorie des héros, facultative : la catégorie du wiki où sont les fiches des héros ; l\'import marque ces pages comme personnages joueurs et télécharge leurs portraits.'),
    !creation && m.wiki?.url ? blocImportWiki() : null);
  const majWiki = () => {
    wikiUrl.disabled = wikiHeros.disabled = !wiki.input.checked;
    champsWiki.classList.toggle('est-desactive', !wiki.input.checked);
    champsWiki.inert = !wiki.input.checked;   // le bouton « Importer le wiki » ne répond plus
  };
  wiki.input.addEventListener('change', () => { majWiki(); if (wiki.input.checked) wikiUrl.focus(); });
  majWiki();

  const element = h('div', { class: 'cm-pile cm-config' },
    section('Campagne',
      champ('Titre', titre),
      champ('Sous-titre', sousTitre),
      creation ? champ('Identifiant', ident, 'Le nom du dossier (campagnes/<identifiant>/) et de l\'adresse : minuscules, chiffres et tirets. Ne change plus ensuite.')
        : h('p', { class: 'ui-s cm-sourdine' }, `Dossier : campagnes/${m.id}/ · adresse : /${m.id}/`),
      creation ? zoneGenre : m.genre ? h('p', { class: 'ui-s cm-sourdine' }, `Genre : ${GENRES[m.genre]?.libelle || m.genre}`) : null),
    section('Apparence',
      h('div', { class: 'bn-ligne-champs' }, champ('Charte', charte), champ('Thème de départ', theme), champ('Icône', icone)),
      ciel.el),
    section('Le monde', h('p', { class: 'ui-s cm-sourdine' }, 'Les mots de l\'interface : « Bêtes d\'Aurval », « Acheter en Aurval », « Nommer un Aurvalien ». Un surtitre sans son mot n\'est pas affiché.'),
      h('div', { class: 'bn-ligne-champs' }, MOTS.map(([cle, libelle]) => champ(libelle, mots[cle])))),
    section('Le temps',
      h('p', { class: 'ui-s cm-sourdine' }, 'Le calendrier et la météo de l\'Horloge. Changer de calendrier en cours de campagne change les dates, pas les jours de campagne.'),
      h('div', { class: 'bn-ligne-champs cm-ligne-haut' }, champ('Calendrier', calendrier, descCal), champ('Météo', meteo, descMeteo)),
      zoneDebut, zoneReel,
      // Demande du MJ (2026-10-24) : une note sur les météos proposées, puis un mode d'emploi détaillé pour importer les siens.
      h('p', { class: 'ui-s' }, h('b', {}, 'Note : '), 'les météos proposées sont de vraies météos, relevées heure par heure pendant deux années complètes, 2009 puis 2010 (Open-Meteo), et résumées en quatre moments par jour (nuit, matin, après-midi, soir). La première année de la campagne prend la météo de 2009, jour pour jour : le 1er jour de l\'année de la campagne a le temps du 1er janvier 2009, le 100e celui du 10 avril 2009. La deuxième année prend 2010, la troisième revient à 2009, et ainsi de suite. Tous les calendriers ont 365 jours pour que cela tombe juste. Carcassonne donne un climat chaud et tempéré, Tallinn un climat froid et tempéré, avec de vrais hivers.'),
      h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'Comment importer votre propre calendrier ou votre propre météo'),
        h('div', { class: 'cm-pile ui-s' },
          h('p', {}, h('b', {}, 'Votre propre météo. '), 'Vous pouvez prendre le temps réel de n\'importe quelle ville, sur n\'importe quelles années depuis 1940 :'),
          h('ol', { class: 'cm-liste' },
            h('li', {}, 'Ouvrez une invite de commandes dans le dossier du gestionnaire, puis lancez « outils/Importer la météo.cmd » avec la ville, la première des deux années, le pays (son code à deux lettres, utile quand plusieurs villes portent ce nom) et l\'identifiant de la campagne : ',
              h('code', {}, `"outils\\Importer la météo.cmd" -Ville Edimbourg -Pays GB -Annee 2015 -Campagne ${m.id || '<identifiant>'}`), '.'),
            h('li', {}, 'Le script lit deux années, du 1er janvier au 31 décembre de l\'année suivante, sur Open-Meteo (gratuit, sans compte), les résume comme les météos proposées et les écrit dans data/meteo.json de la campagne. Il n\'écrase pas une météo déjà importée, sauf si vous ajoutez -Remplacer.'),
            h('li', {}, 'Rechargez cette page, choisissez « Météo importée » ci-dessus, puis enregistrez.')),
          h('p', {}, 'Une météo inventée (un monde sans saisons, un hiver éternel) peut aussi s\'écrire à la main ou avec votre agent IA de campagne, au format décrit dans formats/meteo.md.'),
          h('p', {}, h('b', {}, 'Votre propre calendrier. '), 'Pour un monde qui a le sien, écrivez data/calendrier.json, à la main ou avec votre agent IA de campagne, au format de formats/calendrier.md : exactement 365 jours ; ses mois, avec pour chacun le mois réel auquel il correspond (pour la météo) ; sa semaine ; sa lune ; ses saisons ; ses fêtes. Mettez-y aussi tous les textes que l\'Horloge doit montrer (la présentation du calendrier, le sens et la divinité de chaque jour, les coutumes, la règle de la lune, le texte des fêtes) : l\'Horloge n\'invente rien à leur place. Rechargez la page, choisissez « Calendrier importé », enregistrez, puis vérifiez le fichier avec le bouton Données de l\'en-tête.'),
          h('p', {}, h('b', {}, 'Vos fêtes et anniversaires. '), 'Sans changer de calendrier, l\'anniversaire d\'un PNJ, une fête de village ou la date d\'un événement de votre histoire vont dans data/jours-marques.json (formats/jours-marques.md), à écrire à la main ou avec votre agent IA de campagne : ils s\'ajoutent au calendrier choisi et l\'Horloge les annonce quand ils approchent.')))),
    section('Rencontres',
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Plafond de rencontres'),
        h('div', { class: 'cm-phrase' }, h('span', {}, 'Pas plus de'), nbRencontres, h('span', {}, 'rencontres toutes les'), heuresFenetre, h('span', {}, 'heures de jeu.')),
        h('span', { class: 'ui-s cm-sourdine' }, 'Le nombre atteint, le widget Rencontres ne fait plus de test tant que la plus ancienne rencontre n\'est pas sortie de cette période. Laissés vides : la règle de la table de rencontres de la campagne (data/rencontres-aleatoires.json).')),
      evenementsCase.el),
    section('Liens',
      champ('Campagne D&D Beyond', beyond, 'L\'adresse de la campagne sur D&D Beyond (fiches des héros).'),
      wiki.el, champsWiki),
    creation && casesModules.length ? section('Modules', h('p', { class: 'ui-s cm-sourdine' }, 'Des mécaniques propres à une campagne, avec leur outil et leurs données. Choisis à la création.'),
      casesModules.map(c => c.el), alertesModules) : null,
    creation && casesMusique.length ? section('Musique', h('p', { class: 'ui-s cm-sourdine' }, 'Les playlists de départ du widget Musique, étiquetées par thème (combat, taverne, horreur…). Sans lieux ni PNJ : ceux de la campagne se posent ensuite, au crayon d\'une piste ou dans musique/sources.json.'),
      casesMusique.map(c => c.el)) : null,
    !creation && m.modules?.length ? h('div', { class: 'cm-pile' }, h('p', { class: 'ui-s cm-sourdine' }, `Modules : ${m.modules.join(', ')} (choisis à la création).`), alertesModules) : null);
  majAlertesModules();

  function lire() {
    const t = titre.value.trim();
    if (!t) throw new Error('Le titre est obligatoire.');
    const id = creation ? ident.value.trim() : m.id;
    if (creation && !/^[a-z0-9][a-z0-9-]{0,63}$/.test(id)) throw new Error('Identifiant : minuscules, chiffres et tirets (« ma-campagne »).');
    const url = beyond.value.trim();
    if (url && !/dndbeyond\.com\/campaigns\/\d+/.test(url)) throw new Error('Campagne D&D Beyond : une adresse en https://www.dndbeyond.com/campaigns/1234567.');
    if (wiki.input.checked && !/^https?:\/\//.test(wikiUrl.value.trim())) throw new Error('Wiki : l\'adresse du wiki publié (https://…).');
    const vocabulaire = Object.fromEntries(MOTS.map(([cle]) => [cle, mots[cle].value.trim()]).filter(([, v]) => v));
    const r = { ...m, schema: 1, id, titre: t, sous_titre: sousTitre.value.trim(), icone: icone.value, charte: charte.value, theme: theme.value };
    if (!r.sous_titre) delete r.sous_titre;
    r.vocabulaire = vocabulaire;
    r.reglages = { ...(m.reglages || {}), ciel_voile: ciel.input.checked, evenements: evenementsCase.input.checked };
    const nbR = nbRencontres.value.trim(), nbH = heuresFenetre.value.trim();
    if (nbR || nbH) {
      if (!(Number.isInteger(+nbR) && +nbR >= 1 && Number.isInteger(+nbH) && +nbH >= 1)) throw new Error('Plafond de rencontres : deux nombres entiers, 1 ou plus (« Pas plus de 2 rencontres toutes les 12 heures »), ou les deux vides.');
      r.reglages.plafond_rencontres = { rencontres: +nbR, heures: +nbH };
    } else delete r.reglages.plafond_rencontres;
    const tc = calendrier.value;
    if (CALENDRIERS.some(c => c.id === tc)) {
      const mois = calCharge?.mois?.find(x => x.id === moisDebut.value);
      if (!mois) throw new Error('Calendrier : ses mois ne sont pas encore chargés, réessayez.');
      const an = Number(anDebut.value), j = Number(jourDebut.value);
      if (anDebut.value === '' || !Number.isInteger(an)) throw new Error('Calendrier : l\'année du jour 1 est un nombre entier.');
      if (!(Number.isInteger(j) && j >= 1 && j <= mois.jours)) throw new Error(`Calendrier : le ${jourDebut.value} ${mois.nom} n'existe pas (${mois.jours} jour${mois.jours > 1 ? 's' : ''}).`);
      r.calendrier = { type: 'modele', modele: tc, debut: { annee: an, mois: mois.id, jour: j } };
    } else r.calendrier = { type: tc };
    const tm = meteo.value;
    r.meteo = tm.startsWith('modele:') ? { type: 'modele', modele: tm.slice(7) } : { type: tm };
    const dr = debutReel.value.trim();
    if (tc === 'aucun' && tm !== 'aucune' && dr) {
      if (!/^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(dr)) throw new Error('Météo : la date réelle du jour 1 s\'écrit MM-JJ (« 10-01 » pour le 1er octobre).');
      r.meteo.debut_reel = dr;
    }
    if (url) r.beyond = { url, id: Number(url.match(/campaigns\/(\d+)/)[1]) }; else delete r.beyond;
    if (wiki.input.checked) {
      r.wiki = { ...(m.wiki || {}), url: wikiUrl.value.trim(), categorie_heros: wikiHeros.value.trim() };
      if (!r.wiki.categorie_heros) delete r.wiki.categorie_heros;
    } else delete r.wiki;
    delete r.projet_claude;   // ancien réglage d'avant la version 1.0.0, retiré du manifeste à l'enregistrement
    if (creation) {
      r.genre = genre;
      r.modules = casesModules.filter(c => c.input.checked).map(c => c.id);
      r.livres_beyond = GENRES[genre].livres.map(([lid, sigle, titreLivre]) => ({ id: lid, sigle, titre: titreLivre }));
      r.sources = { ...GENRES[genre].sources, MJ: { court: 'MJ', nom: 'Décisions du MJ', mj: true } };
    }
    return r;
  }
  // Les paquets de musique cochés (création).
  const musique = () => casesMusique.filter(c => c.input.checked).map(c => c.id);
  return { element, lire, musique };
}

// Import du wiki depuis la fenêtre Campagne : le serveur lance scripts/import-wiki/importer-wiki.ps1 en arrière-plan
// (<campagne>/import-wiki.json : GET son état, POST le lance) ; la date du dernier import, et ce qu'il affiche pendant qu'il
// tourne. Il lit l'adresse enregistrée : une adresse changée s'enregistre d'abord.
function blocImportWiki() {
  const etat = h('span', { class: 'ui-s cm-sourdine' }, '…');
  const journal = h('pre', { class: 'cm-journal-import ui-s' });
  const repli = h('details', { class: 'cm-repli', hidden: true }, h('summary', { class: 'etiquette' }, 'Journal de l\'import'), journal);
  const btn = bouton('Importer le wiki', { classe: 'bn-btn--s', icone: 'lu-download', onclick: () => lancer() });
  const el = h('div', { class: 'cm-pile' }, h('div', { class: 'bn-groupe' }, btn, etat), repli);
  const date = d => new Date(d).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
  let attente = 0, avant = null;   // après un lancement : quelques relectures de grâce, le temps que l'import démarre
  async function lire() {
    const r = await fetch('import-wiki.json', { cache: 'no-store' }).then(x => (x.ok ? x.json() : null)).catch(() => null);
    if (!r) { etat.textContent = 'État de l\'import inconnu (serveur ancien ?).'; return; }
    const fini = attente && r.importe_le && r.importe_le !== avant;
    const enCours = r.en_cours || (attente > 0 && !fini);
    if (attente > 0) attente--;
    if (fini) attente = 0;
    btn.disabled = enCours;
    const derniere = (r.journal || []).at(-1)?.trim();
    etat.textContent = enCours ? `Import en cours${derniere ? ` : ${derniere}` : '…'}` : r.importe_le ? `Dernier import : ${date(r.importe_le)}` : 'Jamais importé.';
    journal.textContent = (r.journal || []).join('\n');
    repli.hidden = !r.journal?.length;
    if (enCours && el.isConnected) setTimeout(lire, 2000);
  }
  async function lancer() {
    btn.disabled = true;
    const avantLancement = await fetch('import-wiki.json', { cache: 'no-store' }).then(x => x.json()).catch(() => ({}));
    avant = avantLancement.importe_le || null;
    const r = await fetch('import-wiki.json', { method: 'POST' }).catch(() => null);
    if (!r?.ok) { etat.textContent = r ? await r.text() : 'Le serveur ne répond pas.'; btn.disabled = false; return; }
    attente = 5;
    etat.textContent = 'Import lancé…';
    setTimeout(lire, 1500);
  }
  setTimeout(lire, 0);
  return el;
}
