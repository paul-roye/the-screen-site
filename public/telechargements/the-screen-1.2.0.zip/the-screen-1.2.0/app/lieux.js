// Annuaire des lieux : data/lieux.json (formats/lieux.md) est le référentiel commun.
// Les autres fichiers ne servent qu'en complément, pour un id que lieux.json ne connaîtrait pas.
// Chaque entrée : { id, nom, zone, type, typeLibelle, situe_dans, wiki, parent (pour un sous-lieu) }.

import { emettre } from './evenements.js';

const COMPLEMENTS = ['deroule-campagne', 'temps-de-voyage', 'pnj', 'occupants-maisons'];
let promesse = null;

export function chargerLieux(donnees) {
  promesse ||= (async () => {
    const lieux = new Map();
    const noter = (o, extra = {}) => {
      if (o?.id && o.nom && !lieux.has(o.id)) lieux.set(o.id, { id: o.id, nom: o.nom, zone: o.zone, ...extra });
    };
    const ref = (await donnees('lieux')).donnees;
    for (const l of ref?.lieux || []) {
      noter(l, { type: l.type, typeLibelle: ref.types?.[l.type], situe_dans: l.situe_dans, chapitre_livre: l.chapitre_livre, niveau_livre: l.niveau_livre, wiki: l.wiki });
      (l.sous_lieux || []).forEach(s => noter(s, { parent: l.id }));
    }
    for (const jeu of COMPLEMENTS) {
      const d = (await donnees(jeu)).donnees;
      if (!d) continue;
      (d.lieux || []).forEach(x => { noter(x); (x.sous_lieux || []).forEach(s => noter(s, { parent: x.id })); });
      (d.tables || []).forEach(t => noter(t.lieu));
    }
    return lieux;
  })();
  return promesse;
}

export function nomLieu(lieux, id) {
  return lieux.get(id)?.nom || id;
}

// « au Pressoir du gué », « à la Tour grise », « à Aurval » : l'article du nom contracté avec « à ».
export function aLieu(nom) {
  return String(nom).replace(/^(Le |Les |La |L['’]|)/, m => ({ 'Le ': 'au ', 'Les ': 'aux ', 'La ': 'à la ', '': 'à ' })[m] ?? `à l${m.slice(1)}`);
}
// « vers le Pressoir du gué » : l'article du nom en minuscule.
export const versLieu = nom => 'vers ' + String(nom).replace(/^(Le|Les|La|L)(?=[ '’])/, m => m.toLowerCase());

// « Aurval – Auberge du Cerf blanc » : un lieu et l'un de ses sous-lieux (formats/lieux.md) ; le lieu seul sans sous-lieu.
export function nomComplet(lieux, lieu, sousLieu) {
  return sousLieu && sousLieu !== lieu ? `${nomLieu(lieux, lieu)} – ${nomLieu(lieux, sousLieu)}` : nomLieu(lieux, lieu);
}

// Sous-lieux d'un lieu, dans l'ordre de lieux.json (puis des fichiers complémentaires).
export function sousLieux(lieux, id) {
  return [...lieux.values()].filter(l => l.parent === id);
}

// Où sont les héros (etat/ici.json, formats/etat.md) : widget Ici, « Arriver » du widget Trajets, bloc maj-etat.
// À la première ouverture, le lieu actuel et les lieux visités viennent du `groupe` de personnages.json ;
// ensuite le gestionnaire fait foi.
const ICI_DEFAUT = { schema: 1, lieu: null, sous_lieu: null, visites: null, notes: {}, onglet: 'pnj' };
let promesseIci = null;
export const iciEnService = () => !!document.querySelector('.bn-widget[data-type="ici"]');

export function etatIci(etat, donnees) {
  promesseIci ||= (async () => {
    const s = await etat('ici', ICI_DEFAUT);
    const v = s.valeur;
    v.notes ||= {};
    if (!Array.isArray(v.visites)) {
      const g = (await donnees('personnages')).donnees?.groupe;
      v.lieu ||= g?.lieu_actuel || null;
      v.visites = (g?.lieux_visites || []).map(lieu => ({ lieu }));   // enregistré au premier changement
    }
    return s;
  })();
  return promesseIci;
}

// Les héros arrivent à `lieu` : lieu actuel, et une visite notée (quand : { jour, minute } de l'horloge, s'il y en a une ;
// trajet : id du trajet pendant lequel ils y arrivent). Un sous-lieu passe par son lieu. Rien n'est noté s'ils y sont déjà.
export function arriverA(s, lieux, id, quand = null, trajet = null) {
  const v = s.valeur;
  const parent = lieux.get(id)?.parent;
  const lieu = parent || id;
  const sousLieu = parent ? id : null;
  if (v.lieu === lieu && (!sousLieu || v.sous_lieu === sousLieu)) return false;
  if (v.lieu !== lieu) v.visites.push({ lieu, quand: new Date().toISOString(), ...(quand ? { jour: quand.jour, minute: quand.minute } : {}), ...(trajet ? { trajet } : {}) });
  v.lieu = lieu;
  v.sous_lieu = sousLieu;
  s.enregistrer(0);
  s.signaler();
  emettre('lieu:arrivee', { lieu, sous_lieu: sousLieu, nom: lieux.get(id)?.nom || id, type: lieux.get(lieu)?.type || null, quand: quand ? { jour: quand.jour, minute: quand.minute } : null, trajet });
  return true;
}

// Trajet fait (mené dans l'Horloge jusqu'au bout ou arrêté, ou « Arriver » sans horloge), gardé pour l'historique (widget Ici).
// t : { id, itineraire, atteints, debut, fin ({ jour, minute } ou absents), marche (minutes), fini }.
export function noterTrajet(s, t) {
  s.valeur.trajets = [...(s.valeur.trajets || []).filter(x => x.id !== t.id), { ...t, quand: new Date().toISOString() }];
  s.enregistrer(0);
  s.signaler();
}

// Retirer de l'historique des arrivées (index de visites[]) et des trajets (id) : notés par erreur, ou pendant un essai.
// avecArrivees : un trajet retiré emporte les arrivées notées pendant lui.
// Si la dernière arrivée part, le lieu actuel redevient celui de la dernière qui reste ; sauf s'il a été corrigé depuis
// (il n'était plus celui de l'arrivée retirée) : il ne bouge pas.
export function nettoyerHistorique(s, { visites = [], trajets = [], avecArrivees = true }) {
  const v = s.valeur;
  const derniere = v.visites.at(-1);
  v.visites = v.visites.filter((x, i) => !visites.includes(i) && !(avecArrivees && trajets.includes(x.trajet)));
  v.trajets = (v.trajets || []).filter(t => !trajets.includes(t.id));
  if (derniere && v.visites.at(-1) !== derniere && v.lieu === derniere.lieu) { v.lieu = v.visites.at(-1)?.lieu || null; v.sous_lieu = null; }
  s.enregistrer(0);
  s.signaler();
}

// Corriger le lieu actuel sans noter d'arrivée.
export function corrigerLieu(s, lieu) {
  s.valeur.lieu = lieu || null;
  s.valeur.sous_lieu = null;
  s.enregistrer(0);
  s.signaler();
}
