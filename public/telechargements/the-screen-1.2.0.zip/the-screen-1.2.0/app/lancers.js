// Lancers de dés faits hors du widget Dés : initiative (Combat), nombre de monstres d'une rencontre (app/rencontres-mj.js),
// jets des fiches de monstres (attaques, dégâts, sauvegardes : app/monstres.js). Ils roulent en 3D (lancerEn3d de
// app/des-3d.js), selon les réglages 3D et son du widget Dés, et vont dans son historique (en mémoire, le temps de la page, avec leur motif).

import { etat } from './etat.js';
import { lancer } from './des.js';
import { lancerEn3d, FACES_3D, critiqueDe } from './des-3d.js';
import { emettre } from './evenements.js';

const DEFAUT = { schema: 1, choix: {}, mod: 0, avantage: 'normal', anime: true, son: true, historique: [] };   // comme le widget Dés
const HISTORIQUE = 30;

// « 1d8 + 1 », « 1d6 − 2 » (textes de D&D Beyond) -> « 1d8+1 », « 1d6-2 ».
export const formuleDe = t => String(t).replace(/[−–]/g, '-').replace(/\s+/g, '');
// Un d20 et son bonus : « 1d20+3 », « 1d20-1 », « 1d20 ».
export const formuleD20 = bonus => (bonus ? `1d20${bonus > 0 ? '+' : '-'}${Math.abs(bonus)}` : '1d20');

// Montrer des jets déjà faits (lancer() de app/des.js) : [{ libelle, jet, formule?, detail?, type? }] (type : de dégâts,
// sous le total). Un seul : son total en grand ;
// plusieurs : une ligne par jet (libellé, total, détail), ou en grand côte à côte avec colonnes (une attaque : le jet et
// ses dégâts). legende : au-dessus (« Morsure : jet d'attaque »). detail : remplace « formule : détail des dés ».
// couleur : jeton de la charte du résultat (sang ; ultra pour un monstre). depuis : élément d'où partent les dés.
export async function montrerJets(entrees, { legende = '', couleur = 'sang', depuis = null, colonnes = false } = {}) {
  const l = entrees.filter(e => e.jet);
  if (!l.length) return null;
  const s = await etat('des', DEFAUT);
  const v = s.valeur;
  v.historique ||= [];
  const quand = new Date().toISOString();
  for (const e of l) {
    const motif = [legende, l.length > 1 ? e.libelle : null].filter(Boolean).join(' · ') || e.libelle || '';
    v.historique.push({ quand, motif: [motif, e.type].filter(Boolean).join(' ') || null,   // « Bite : dégâts perforants »
      formule: e.formule || e.jet.formule, total: e.jet.total, des: (e.jet.faces || []).map(d => ({ ...d, garde: d.garde !== false })), mod: 0 });
  }
  v.historique = v.historique.slice(-HISTORIQUE);   // en mémoire seulement (EN_MEMOIRE de app/etat.js) : rien à écrire
  s.signaler();
  // Pour les plugins (app/evenements.js) : chaque jet avec son critique (20 ou 1 naturel sur un seul d20 gardé).
  emettre('des:resultat', { legende, couleur, jets: l.map(e => ({ libelle: e.libelle || '', formule: e.formule || e.jet.formule, total: e.jet.total, critique: critiqueDe(e.jet.faces) })) });
  if (v.anime === false || matchMedia('(prefers-reduced-motion: reduce)').matches) return null;
  const des = l.flatMap(e => (e.jet.faces || []).filter(d => FACES_3D.includes(d.faces)).map(d => (d.garde === false ? { ...d, terne: true } : d)));   // l'écarté : terne
  const un = l.length === 1 ? l[0] : null;
  const enColonnes = !un && colonnes;
  const ecrit = e => e.detail || `${e.formule || e.jet.formule} : ${e.jet.detail}`;
  return lancerEn3d(des, {
    depuis: depuis?.getBoundingClientRect ? depuis.getBoundingClientRect() : depuis, son: v.son !== false, couleur,
    legende: un ? legende || un.libelle : legende,
    total: un?.jet.total, type: un?.type, formule: un ? ecrit(un) : null, critique: un || enColonnes ? critiqueDe(l[0].jet.faces) : null,
    colonnes: enColonnes ? l.map(e => ({ libelle: e.libelle, total: e.jet.total, type: e.type, detail: ecrit(e) })) : null,
    lignes: un || enColonnes ? null : l.map(e => ({ libelle: e.libelle, total: e.jet.total, detail: ecrit(e), critique: critiqueDe(e.jet.faces) })),
  });
}

// Un jet d'un d20 (« 1d20+5 ») avec avantage (le meilleur de deux d20) ou désavantage (le moins bon) : les deux d20 sont
// dans faces, l'écarté avec garde: false (terne en 3D, barré dans l'historique du widget Dés ; le critique se juge sur le
// gardé). avantage : 'avantage', 'desavantage', ou rien (un seul jet).
export const AVANTAGES = { avantage: { libelle: 'avantage', court: 'av.' }, desavantage: { libelle: 'désavantage', court: 'désav.' } };
export function jeterD20(formule, avantage = null) {
  const f = formuleDe(formule);
  if (!AVANTAGES[avantage]) return lancer(f);
  const a = lancer(f), b = lancer(f);
  if (!a || !b) return null;
  const d20 = j => j.faces.find(d => d.faces === 20)?.valeur ?? 0;
  const garde = (avantage === 'avantage' ? d20(a) >= d20(b) : d20(a) <= d20(b)) ? a : b, autre = garde === a ? b : a;
  return { ...garde, formule: `${f} (${AVANTAGES[avantage].court})`,
    faces: [...garde.faces, ...autre.faces.filter(d => d.faces === 20).map(d => ({ ...d, garde: false }))],
    detail: `${garde.detail} (${AVANTAGES[avantage].libelle} : ${d20(autre)} écarté)` };
}

// Lancer une formule et la montrer ; renvoie le jet (null si la formule n'est pas lisible). options.avantage : un d20 avec
// avantage ou désavantage (jeterD20).
export function lancerVisible(formule, options = {}) {
  const f = formuleDe(formule);
  const jet = options.avantage ? jeterD20(f, options.avantage) : lancer(f);
  if (jet) montrerJets([{ libelle: options.libelle || '', jet, formule: jet.formule || f, type: options.type }], options);
  return jet;
}
