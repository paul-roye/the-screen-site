// La page joueurs (joueurs.html, servie sous l'adresse de la campagne) : l'écran des joueurs, en plein écran sur un autre
// écran (la TV à plat sous les figurines), piloté par le plugin « Écran des joueurs » de la page du MJ
// (app/plugins/ecran-joueurs.js) par un canal du navigateur (BroadcastChannel, même origine). Elle n'écrit jamais rien :
// elle reçoit la scène entière à chaque changement (message `etat`), les pings, et dit sa taille (`ecran`) pour que la
// projection du MJ ait les bonnes proportions. Le rendu est celui de app/projection.js, le même que dans le widget du MJ.
// Un clic n'importe où met la page en plein écran (quand la fenêtre n'a pas pu s'ouvrir directement en plein écran) ;
// un verrou de veille empêche l'écran de s'éteindre pendant la partie.

import { chargerCampagne, appliquerCharte } from './campagne.js';
import { monterProjection } from './projection.js';
import { rendreTableau } from './tableau-joueurs.js';
import { chargerIconesEtats } from './etats.js';

const m = await chargerCampagne();
await appliquerCharte(m);
document.title = `${m.titre} · écran des joueurs`;
chargerIconesEtats();

const racine = document.getElementById('app');
const proj = monterProjection(racine, { mode: 'joueurs' });
proj.maj({ affichage: 'tableau', titre: m.titre, sous_titre: 'En attente du gestionnaire…' });

const canal = new BroadcastChannel('the-screen:joueurs:' + (m.id || 'defaut'));
canal.onmessage = e => {
  const d = e.data || {};
  if (d.type === 'etat' && d.scene) { d.scene.rendreTableau = rendreTableau; proj.maj(d.scene); }
  else if (d.type === 'ping') proj.ping(d.x, d.y);
  else if (d.type === 'qui') direEcran();   // la page du MJ (re)démarre : elle veut la taille de la fenêtre
  else if (d.type === 'fermer') window.close();
};

// En plein écran ? Par l'API, par F11 ou par l'ouverture directe en plein écran (la fenêtre couvre l'écran).
const pleinEcran = () => !!document.fullscreenElement || matchMedia('(display-mode: fullscreen)').matches || (outerWidth >= screen.availWidth && outerHeight >= screen.availHeight);
function direEcran() {
  const plein = pleinEcran();
  document.body.classList.toggle('est-plein-ecran', plein);
  canal.postMessage({ type: 'ecran', largeur: innerWidth, hauteur: innerHeight, plein_ecran: plein });
}
addEventListener('resize', direEcran);
document.addEventListener('fullscreenchange', direEcran);
addEventListener('pagehide', () => canal.postMessage({ type: 'aurevoir' }));
canal.postMessage({ type: 'bonjour' });
direEcran();
setTimeout(direEcran, 1500);   // la fenêtre a pu changer de taille après son ouverture

// Un clic (ou Entrée) : plein écran. Échap le quitte : le navigateur le fait lui-même.
const demanderPleinEcran = () => { if (!pleinEcran()) document.documentElement.requestFullscreen?.().catch(() => {}); };
document.addEventListener('click', demanderPleinEcran);
document.addEventListener('keydown', e => { if (e.key === 'Enter') demanderPleinEcran(); });

// Verrou de veille : l'écran reste allumé tant que la page est visible ; redemandé quand elle revient.
let verrou = null;
async function garderAllume() {
  try { verrou = await navigator.wakeLock?.request('screen'); } catch { /* refusé : la TV suivra ses propres réglages */ }
}
garderAllume();
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') garderAllume(); });
