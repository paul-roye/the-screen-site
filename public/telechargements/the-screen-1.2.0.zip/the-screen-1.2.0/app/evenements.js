// Événements du gestionnaire : ce qui se passe à la table, émis par les widgets et les modules partagés (un combat qui
// avance, des PV qui changent, une arrivée, l'heure qui tourne, un jet de dés), écouté par les plugins (app/plugins.js :
// une connexion à un appareil ou à un service, The Table) et par qui veut. Un événement est une information, jamais une
// commande : l'émetteur ne sait pas qui écoute, et un écouteur qui plante n'arrête rien (erreur dans la console).
// Les événements `document` (cm:annonce, cm:voir-…, cm:mode) restent des commandes entre widgets : pas ici.
// Catalogue (nom, détail) : formats/plugins.md, à tenir à jour avec EVENEMENTS ci-dessous.

export const EVENEMENTS = {
  'combat:etat': 'L\'état du combat mené dans le widget Combat, à chaque changement (combat: null quand il n\'y en a plus).',
  'combat:pv': 'Dégâts, soins ou PV temporaires appliqués à un combattant dans le widget Combat.',
  'rencontre:demarree': 'Une rencontre est notée en cours (bouton Démarrer).',
  'rencontre:terminee': 'Une rencontre est marquée terminée, avec son état de fin s\'il y a eu combat.',
  'rencontre:annulee': 'Une rencontre lancée est annulée : elle n\'a pas eu lieu.',
  'lieu:arrivee': 'Les héros arrivent dans un lieu ou un sous-lieu.',
  'horloge:changement': 'L\'heure de jeu change (passage du temps, réglage, repos, annulation).',
  'des:resultat': 'Un lancer de dés fait dans le gestionnaire, avec ses résultats.',
  'mode:change': 'Le tableau change de mode (exploration, ville, voyage, rencontre).',
};

const JOURNAL_MAX = 50;
const ecouteurs = new Map();   // nom (ou '*') -> Set de fonctions
const journal = [];            // les derniers événements, pour l'onglet Plugins (fenêtre Campagne)
const surJournalFns = new Set();

// Émettre un événement : chaque écouteur de ce nom, puis ceux de '*', reçoit (detail, nom).
export function emettre(nom, detail = {}) {
  if (!EVENEMENTS[nom]) console.warn(`Événement inconnu : « ${nom} » (à décrire dans EVENEMENTS de app/evenements.js et formats/plugins.md)`);
  const e = { quand: new Date().toISOString(), nom, detail };
  journal.push(e);
  if (journal.length > JOURNAL_MAX) journal.shift();
  for (const fn of surJournalFns) { try { fn(e); } catch (err) { console.error(err); } }
  for (const fn of [...(ecouteurs.get(nom) || []), ...(ecouteurs.get('*') || [])]) {
    try { fn(detail, nom); } catch (err) { console.error(`Écouteur de « ${nom} » en erreur`, err); }
  }
}

// Écouter un événement (ou tous : '*'). Renvoie la fonction qui désabonne.
export function ecouter(nom, fn) {
  if (!ecouteurs.has(nom)) ecouteurs.set(nom, new Set());
  ecouteurs.get(nom).add(fn);
  return () => ecouteurs.get(nom)?.delete(fn);
}

export const journalEvenements = () => [...journal];
export function surJournal(fn) { surJournalFns.add(fn); return () => surJournalFns.delete(fn); }
