// Projection d'une scène pour l'écran des joueurs (plugin app/plugins/ecran-joueurs.js, étude
// mainteneur/etudes/ecran-joueurs.md) : le même rendu dans le widget du MJ (sa projection, avec le cadre des joueurs) et
// dans la page joueurs (joueurs.html, en plein écran sur la TV). Ce que le MJ voit dans son cadre est ce que la TV montre.
//
// Une scène : { affichage ('tableau' | 'carte' | 'image' | 'mire'), ecran { largeur_pouces (la dalle), rapport (largeur /
// hauteur de la fenêtre joueurs) }, carte (ci-dessous), image { chemin, legende }, tableau (app/tableau-joueurs.js), titre }.
// carte : { chemin (l'image à montrer : version joueurs côté joueurs), largeur, hauteur (px de l'image), echelle { px_case,
// origine_x, origine_y } ou null, zoom ('pouce' : 1 pouce par case ; 'ecran' : la carte entière ; un nombre k : k fois la base),
// rotation (0, 90, 180, 270), cadrage { x, y } (le centre du cadre, en px de la carte), brouillard { base ('cache' | 'revele'),
// formes[], adouci (le bord flouté du brouillard, px de carte, 0 : net) }, grille (vrai : la grille dessinée). Formes du
// brouillard, en px de la carte : { op ('revele' | 'cache'), type ('rect' { x, y, w, h } | 'cercle' { cx, cy, r } |
// 'trait' { points[], largeur } | 'polygone' { points[] }) }.
//
// Pile de couches dans un conteneur, toutes en coordonnées de la carte, une seule transformation CSS (translate, rotate,
// scale) : l'image, le brouillard (un canvas de 2 048 px au plus, étiré), un SVG (grille, cadre, ping). Mode joueurs : le
// conteneur est la fenêtre, le cadre est la fenêtre. Mode MJ : la carte entière tient dans le conteneur, le cadre des joueurs
// est dessiné dessus et le brouillard est translucide.

import { h } from './ui.js';

const SVG = 'http://www.w3.org/2000/svg';
const MASQUE_MAX = 2048;          // largeur du canvas du brouillard (px) : un dixième de case sur les cartes du livre
const RAPPORT_DEFAUT = 16 / 9;    // la fenêtre joueurs tant qu'elle n'a rien dit
export const ROTATIONS = [0, 90, 180, 270];

function svg(tag, attrs = {}, ...enfants) {
  const el = document.createElementNS(SVG, tag);
  for (const [k, v] of Object.entries(attrs)) if (v !== null && v !== undefined) el.setAttribute(k, v);
  el.append(...enfants.flat().filter(Boolean));
  return el;
}

// Dimensions de la carte une fois tournée (largeur, hauteur à l'écran, pour une échelle de 1).
const tournee = (c, rot) => (rot % 180 ? { w: c.hauteur, h: c.largeur } : { w: c.largeur, h: c.hauteur });

// L'échelle de base des joueurs (px CSS de leur fenêtre par px de carte) : 1 pouce par case quand la carte est calibrée et
// la dalle mesurée, sinon la carte entière dans la fenêtre. largeurFenetre, hauteurFenetre : la fenêtre joueurs en px CSS.
export function echelleJoueurs(scene, largeurFenetre, hauteurFenetre) {
  const c = scene.carte;
  if (!c) return 1;
  const t = tournee(c, c.rotation || 0);
  const entiere = Math.min(largeurFenetre / t.w, hauteurFenetre / t.h);
  const pouce = c.echelle?.px_case > 0 && scene.ecran?.largeur_pouces > 0 ? (largeurFenetre / scene.ecran.largeur_pouces) / c.echelle.px_case : null;
  const base = c.zoom === 'ecran' || !pouce ? entiere : pouce;
  return typeof c.zoom === 'number' && c.zoom > 0 ? base * c.zoom : base;
}

// Le cadre des joueurs en px de carte (sa largeur et sa hauteur avant rotation), d'après la dalle : indépendant des px CSS de
// la fenêtre joueurs (le rapport suffit).
export function cadreJoueurs(scene) {
  const rapport = scene.ecran?.rapport > 0 ? scene.ecran.rapport : RAPPORT_DEFAUT;
  const L = 1000, H = L / rapport;   // une fenêtre fictive : seules les proportions comptent
  const s = echelleJoueurs(scene, L, H);
  return { w: L / s, h: H / s };
}

// Le cadrage par défaut d'une carte : son centre.
export const centreDe = c => ({ x: c.largeur / 2, y: c.hauteur / 2 });

// Dessine le brouillard sur son canvas : noir là où c'est caché (opaque côté joueurs, translucide côté MJ par CSS).
// Les formes sont peintes nettes, dans l'ordre, sur un masque tampon (recacher défait exactement révéler ; deux cases côte
// à côte font une zone sans couture), puis le masque entier est flouté d'un coup sur `b.adouci` px de carte (retour du MJ,
// 2026-11-03 : un bord adouci par forme, composé coup par coup, laissait un halo quand on recachait une zone révélée).
// Un trait : des empreintes (carré ou rond, `forme`) le long du chemin ; sans `forme` (anciennes formes), un trait rond continu.
let tampon = null;
function peindreBrouillard(canvas, c, enCours = null) {
  const b0 = c.brouillard || { base: 'revele', formes: [] };
  const b = enCours ? { ...b0, formes: [...(b0.formes || []), enCours] } : b0;
  const k = canvas.width / c.largeur;
  const flou = b.adouci > 0 ? b.adouci * k / 2 : 0;   // écart-type du flou (px du canvas) : la transition s'étale sur ± adouci
  const marge = Math.ceil(flou * 3);                     // le masque déborde du canvas, pour que le flou ne pâlisse pas ses bords
  tampon ||= document.createElement('canvas');
  tampon.width = canvas.width + 2 * marge; tampon.height = canvas.height + 2 * marge;
  const ctx = tampon.getContext('2d');
  ctx.setTransform(k, 0, 0, k, marge, marge);
  ctx.fillStyle = '#000';
  ctx.strokeStyle = '#000';
  if (b.base !== 'revele') ctx.fillRect(-marge / k, -marge / k, tampon.width / k, tampon.height / k);
  // Un rectangle est calé sur les pixels du canvas (bords arrondis chacun de son côté) : deux cases côte à côte partagent
  // leur bord sans le liseré d'anticrénelage qu'y laisseraient des bords fractionnaires.
  const rectangle = (x, y, w, hh) => {
    const X = v => Math.round(v * k) + marge, Y = v => Math.round(v * k) + marge;
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillRect(X(x), Y(y), X(x + w) - X(x), Y(y + hh) - Y(y));
    ctx.restore();
  };
  const empreinte = (x, y, f) => {
    const s = f.largeur || 1;
    if (f.forme === 'rond') { ctx.beginPath(); ctx.arc(x, y, s / 2, 0, Math.PI * 2); ctx.fill(); }
    else rectangle(x - s / 2, y - s / 2, s, s);
  };
  for (const f of b.formes || []) {
    ctx.globalCompositeOperation = f.op === 'revele' ? 'destination-out' : 'source-over';
    if (f.type === 'rect') rectangle(f.x, f.y, f.w, f.h);
    else if (f.type === 'cercle') { ctx.beginPath(); ctx.arc(f.cx, f.cy, f.r, 0, Math.PI * 2); ctx.fill(); }
    else if (f.type === 'polygone' && f.points?.length >= 3) { ctx.beginPath(); f.points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.closePath(); ctx.fill(); }
    else if (f.type === 'trait' && f.points?.length && f.forme) {
      // Des empreintes tous les quarts de largeur le long du chemin (les points aimantés aux cases en donnent une par case).
      const pas = Math.max(1, (f.largeur || 1) / 4);
      let [px, py] = f.points[0];
      empreinte(px, py, f);
      for (const [x, y] of f.points.slice(1)) {
        const d = Math.hypot(x - px, y - py);
        if (f.aimante) { empreinte(x, y, f); [px, py] = [x, y]; continue; }
        for (let t = pas; t < d; t += pas) empreinte(px + (x - px) * t / d, py + (y - py) * t / d, f);
        empreinte(x, y, f);
        [px, py] = [x, y];
      }
    } else if (f.type === 'trait' && f.points?.length) {
      ctx.globalAlpha = 1;
      ctx.lineWidth = f.largeur || 1; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath();
      f.points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
      if (f.points.length === 1) ctx.lineTo(f.points[0][0] + 0.01, f.points[0][1]);
      ctx.stroke();
    }
  }
  ctx.globalCompositeOperation = 'source-over';
  const cx = canvas.getContext('2d');
  cx.setTransform(1, 0, 0, 1, 0, 0);
  cx.clearRect(0, 0, canvas.width, canvas.height);
  cx.filter = flou > 0 ? `blur(${flou}px)` : 'none';
  cx.drawImage(tampon, -marge, -marge);
  cx.filter = 'none';
}

// ───── Annotations : terrains, jetons, mesures (demande du MJ, 2026-11-03), montrées des deux côtés ─────
// Catalogues partagés avec le widget : [clé, libellé, icône Lucide, rôle de couleur de la charte]. Dans la scène :
// carte.terrains [{ type, forme }] (forme comme celles du brouillard), carte.jetons [{ type, variante?, x, y }],
// carte.mesures [{ type, x1, y1, x2, y2 }].
export const TERRAINS = [
  ['difficile', 'Terrain difficile', 'mountain', 'soleil'],
  ['feu', 'Zone enflammée', 'flame', 'cierge'],
  ['glace', 'Zone glacée', 'snowflake', 'brume'],
  ['vegetation', 'Végétation, ronces', 'shrub', 'mousse'],
  ['arcane', 'Zone arcanique', 'sparkles', 'ultra'],
  ['ombre', 'Zone d\'ombre', 'moon', 'cendre'],
];
export const JETONS = [
  ['porte', 'Porte dissimulée', 'door-closed', 'cierge'],
  ['piege', 'Piège', 'triangle-alert', 'sang'],
  ['coffre', 'Coffre, trésor', 'gem', 'soleil'],
  ['repere', 'Point d\'intérêt', 'map-pin', 'cierge'],
  ['corps', 'Corps', 'bone', 'os'],
  ['lumiere', 'Lumière', 'lamp', 'soleil'],
  ['passage', 'Passage, escalier', 'layers', 'brume'],
];
export const PIEGES = [['pics', 'Pics', 'chevrons-up'], ['fosse', 'Fosse', 'circle-dashed'], ['feu', 'Feu', 'flame'], ['fleches', 'Flèches', 'crosshair'], ['gaz', 'Gaz', 'wind'], ['lame', 'Lame', 'sword'], ['poison', 'Poison', 'skull']];
// Les zones d'effet des règles 2024 : cône, cube, cylindre, émanation, ligne, sphère (plus la distance simple).
export const ZONES = [['cone', 'Cône', 'cone'], ['cube', 'Cube', 'box'], ['cylindre', 'Cylindre', 'cylinder'], ['emanation', 'Émanation', 'circle-dot'], ['ligne', 'Ligne', 'move-horizontal'], ['sphere', 'Sphère', 'circle']];
export const PX_CASE_DEFAUT = 60;   // une case sur une carte non calibrée (pinceau, jetons, mesures)
const nombreFr = v => v.toFixed(1).replace('.', ',').replace(/,0$/, '');

// La géométrie d'une mesure (px de carte) : { forme ({ type: 'segment', a, b } | { type: 'polygone', points [{x, y}] } |
// { type: 'cercle', c, r }), libelle, ancre (du libellé) }. Règles 2024 : le cône est aussi large que long à son extrémité,
// le cube part d'un coin (côté : le plus grand des deux écarts), le cylindre et la sphère ont leur rayon, l'émanation
// s'étend du bord de l'espace de la créature (une case) dans toutes les directions, la ligne fait 5 ft de large.
// 1 case = 5 ft = 1,5 m.
export function geometrieMesure(m, pxCase) {
  const a = { x: m.x1, y: m.y1 }, b = { x: m.x2, y: m.y2 };
  const dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy), cases = L / pxCase;
  const pieds = c => `${Math.round(c * 5)} ft`;
  const u = L ? { x: dx / L, y: dy / L } : { x: 1, y: 0 }, n = { x: -u.y, y: u.x };
  const centre = pts => ({ x: pts.reduce((s, p) => s + p.x, 0) / pts.length, y: pts.reduce((s, p) => s + p.y, 0) / pts.length });
  const poly = (points, libelle) => ({ forme: { type: 'polygone', points }, libelle, ancre: centre(points) });
  switch (m.type) {
    case 'cone': return poly([a, { x: b.x + n.x * L / 2, y: b.y + n.y * L / 2 }, { x: b.x - n.x * L / 2, y: b.y - n.y * L / 2 }], `Cône ${pieds(cases)}`);
    case 'cube': { const s = Math.max(Math.abs(dx), Math.abs(dy)), sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1; return poly([a, { x: a.x + sx * s, y: a.y }, { x: a.x + sx * s, y: a.y + sy * s }, { x: a.x, y: a.y + sy * s }], `Cube ${pieds(s / pxCase)}`); }
    case 'emanation': { const d = L + pxCase / 2; return poly([{ x: a.x - d, y: a.y - d }, { x: a.x + d, y: a.y - d }, { x: a.x + d, y: a.y + d }, { x: a.x - d, y: a.y + d }], `Émanation ${pieds(cases)}`); }
    case 'ligne': { const w = pxCase / 2; return poly([{ x: a.x + n.x * w, y: a.y + n.y * w }, { x: b.x + n.x * w, y: b.y + n.y * w }, { x: b.x - n.x * w, y: b.y - n.y * w }, { x: a.x - n.x * w, y: a.y - n.y * w }], `Ligne ${pieds(cases)}`); }
    case 'cylindre': return { forme: { type: 'cercle', c: a, r: L }, libelle: `Cylindre, rayon ${pieds(cases)}`, ancre: a };
    case 'sphere': return { forme: { type: 'cercle', c: a, r: L }, libelle: `Sphère, rayon ${pieds(cases)}`, ancre: a };
    default: return { forme: { type: 'segment', a, b }, libelle: `${pieds(cases)} · ${nombreFr(cases * 1.5)} m · ${nombreFr(cases)} case${cases >= 1.95 ? 's' : ''}`, ancre: { x: (a.x + b.x) / 2 - n.x * pxCase * 0.3, y: (a.y + b.y) / 2 - n.y * pxCase * 0.3 } };
  }
}

const dansPolygone = (pts, p) => {
  let dedans = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const a = pts[i], b = pts[j];
    if ((a.y > p.y) !== (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) dedans = !dedans;
  }
  return dedans;
};
const distanceSegment = (p, a, b) => {
  const dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy;
  const t = l2 ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2)) : 0;
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
};
// Le point p (px de carte) est-il sur la mesure (à moins d'un tiers de case d'une distance) ?
export function mesureContient(m, p, pxCase) {
  const f = geometrieMesure(m, pxCase).forme;
  if (f.type === 'segment') return distanceSegment(p, f.a, f.b) <= pxCase / 3;
  if (f.type === 'cercle') return Math.hypot(p.x - f.c.x, p.y - f.c.y) <= f.r;
  return dansPolygone(f.points, p);
}
// Le point p est-il dans une forme (rect, cercle, polygone, ou trait : à moins d'une demi-largeur du chemin) ?
export function formeContient(f, p) {
  if (f.type === 'rect') return p.x >= f.x && p.x <= f.x + f.w && p.y >= f.y && p.y <= f.y + f.h;
  if (f.type === 'cercle') return Math.hypot(p.x - f.cx, p.y - f.cy) <= f.r;
  const pts = (f.points || []).map(([x, y]) => ({ x, y }));
  if (f.type === 'polygone') return pts.length >= 3 && dansPolygone(pts, p);
  const r = (f.largeur || 1) / 2;
  if (pts.length === 1) return Math.hypot(p.x - pts[0].x, p.y - pts[0].y) <= r;
  for (let i = 1; i < pts.length; i++) if (distanceSegment(p, pts[i - 1], pts[i]) <= r) return true;
  return false;
}
// Le centre d'une forme (pour son pictogramme) : le centre du rectangle, la moyenne des sommets, le milieu du trait.
export function centreForme(f) {
  if (f.type === 'rect') return { x: f.x + f.w / 2, y: f.y + f.h / 2 };
  if (f.type === 'cercle') return { x: f.cx, y: f.cy };
  const pts = f.points || [];
  if (f.type === 'trait') { const [x, y] = pts[Math.floor((pts.length - 1) / 2)] || [0, 0]; return { x, y }; }
  return { x: pts.reduce((s, q) => s + q[0], 0) / (pts.length || 1), y: pts.reduce((s, q) => s + q[1], 0) / (pts.length || 1) };
}
// L'élément SVG d'une forme (rect, cercle, polygone, trait), avec les attributs donnés.
export function elementForme(f, attrs = {}) {
  if (f.type === 'rect') return svg('rect', { x: f.x, y: f.y, width: f.w, height: f.h, ...attrs });
  if (f.type === 'cercle') return svg('circle', { cx: f.cx, cy: f.cy, r: f.r, ...attrs });
  let pts = f.points || [];
  if (f.type === 'polygone') return svg('polygon', { points: pts.map(q => q.join(',')).join(' '), ...attrs });
  if (pts.length === 1) pts = [pts[0], [pts[0][0] + 0.01, pts[0][1]]];
  return svg('polyline', { points: pts.map(q => q.join(',')).join(' '), fill: 'none', 'stroke-width': f.largeur || 1, 'stroke-linecap': f.forme === 'rond' ? 'round' : 'square', 'stroke-linejoin': f.forme === 'rond' ? 'round' : 'miter', ...attrs });
}
// L'élément SVG d'une mesure, avec son libellé (taille des textes en fraction de case).
export function elementMesure(m, pxCase) {
  const g = geometrieMesure(m, pxCase), f = g.forme;
  const el = f.type === 'segment' ? svg('line', { x1: f.a.x, y1: f.a.y, x2: f.b.x, y2: f.b.y })
    : f.type === 'cercle' ? svg('circle', { cx: f.c.x, cy: f.c.y, r: f.r })
    : svg('polygon', { points: f.points.map(p => `${p.x},${p.y}`).join(' ') });
  return svg('g', { class: `cm-proj__mesure cm-proj__mesure--${m.type === 'distance' ? 'distance' : 'zone'}` }, el,
    f.type === 'segment' ? [f.a, f.b].map(p => svg('circle', { cx: p.x, cy: p.y, r: pxCase / 10, class: 'cm-proj__mesure-bout' })) : null,
    svg('text', { x: g.ancre.x, y: g.ancre.y, class: 'cm-proj__mesure-texte', 'font-size': pxCase * 0.32, 'stroke-width': pxCase / 24 }, g.libelle));
}

// Monte la projection dans `conteneur` (vidé). mode : 'joueurs' ou 'mj'. Renvoie { maj(scene), ping(x, y), versCarte(ev),
// echelle(), surfaces: { calque } (le SVG en coordonnées de carte, pour les tracés en cours du MJ), cadre() }.
export function monterProjection(conteneur, { mode = 'joueurs' } = {}) {
  const mj = mode === 'mj';
  conteneur.classList.add('cm-proj', mj ? 'cm-proj--mj' : 'cm-proj--joueurs');
  const img = h('img', { class: 'cm-proj__carte', alt: '', draggable: false });
  const suffixe = Math.random().toString(36).slice(2, 7);   // les id des motifs SVG : deux projections dans la même page
  const masque = h('canvas', { class: 'cm-proj__brouillard' });
  const grille = svg('svg', { class: 'cm-proj__grille' });
  const calque = svg('svg', { class: 'cm-proj__calque' });   // cadre des joueurs, ping, tracés en cours
  const scene = h('div', { class: 'cm-proj__scene' }, img, masque, grille, calque);
  const hors = h('div', { class: 'cm-proj__hors' });         // tableau des joueurs, image, mire, titre : hors de la carte
  const fondImg = h('img', { class: 'cm-proj__fond-image', alt: '', draggable: false });
  const fond = h('div', { class: 'cm-proj__fond', hidden: true }, fondImg);   // le fond du tableau des joueurs, tourné de son côté
  conteneur.replaceChildren(scene, fond, hors);
  let courante = null, s = 1, matrice = new DOMMatrix(), cheminCharge = null;
  // La vue du MJ (mode mj) : la carte entière d'office, zoomée à la molette et défilée au bouton droit ou du milieu (retour du MJ,
  // 2026-11-03 : pour voir la zone projetée et placer les points du calibrage avec précision). k : fois l'échelle « carte
  // entière » ; centre : le point de carte au centre du conteneur (null : le centre de la carte). Remise à zéro quand la carte change.
  let vueK = 1, vueCentre = null, carteVue = null;
  // vueAuto : la vue n'a pas été touchée (molette, défilement, glisser) : elle montre tout, et suit le cadre des joueurs.
  let vueAuto = true;

  // La vue qui montre tout (mode MJ) : la carte entière et, s'il en déborde, le cadre des joueurs entier (retour du MJ,
  // 2026-11-03 : une carte plus petite que l'écran, ou cadrée hors de la carte, se place dans l'écran). Dans les axes de
  // l'écran (la carte tournée) : { k (fois l'échelle « carte entière », 1 au plus), centre (px de carte) }.
  function vueEntiere(c) {
    const { w, h: hh } = taille();
    const rot = c.rotation || 0, t = tournee(c, rot), cc = centreDe(c);
    const R = new DOMMatrix().rotate(rot);
    const kd = cadreJoueurs(courante), o = c.cadrage || cc;
    const q = R.transformPoint(new DOMPoint(o.x - cc.x, o.y - cc.y));
    const minx = Math.min(-t.w / 2, q.x - kd.w / 2), maxx = Math.max(t.w / 2, q.x + kd.w / 2);
    const miny = Math.min(-t.h / 2, q.y - kd.h / 2), maxy = Math.max(t.h / 2, q.y + kd.h / 2);
    const k = Math.min(w / (maxx - minx), hh / (maxy - miny)) / Math.min(w / t.w, hh / t.h);
    const m = R.inverse().transformPoint(new DOMPoint((minx + maxx) / 2, (miny + maxy) / 2));
    return { k: Math.min(1, k), centre: { x: cc.x + m.x, y: cc.y + m.y } };
  }
  // La vue telle qu'elle est, figée avant de la toucher (sinon elle suivrait le cadre pendant un glisser).
  function figerVue(c) {
    if (!vueAuto) return;
    const v = vueEntiere(c);
    vueK = v.k; vueCentre = v.k < 1 ? v.centre : null; vueAuto = false;
  }

  const taille = () => ({ w: conteneur.clientWidth || 1, h: conteneur.clientHeight || 1 });

  // La transformation de la scène : le cadrage (joueurs) ou le centre de la vue (MJ) au centre du conteneur.
  function placer() {
    const c = courante?.carte;
    if (!c) return;
    const { w, h: hh } = taille();
    const rot = c.rotation || 0;
    let centre;
    if (mj) {
      const t = tournee(c, rot);
      if (vueAuto) { const v = vueEntiere(c); vueK = v.k; vueCentre = v.k < 1 ? v.centre : null; }
      s = Math.min(w / t.w, hh / t.h) * vueK;
      centre = vueCentre || centreDe(c);
    } else {
      s = echelleJoueurs(courante, w, hh);
      centre = c.cadrage || centreDe(c);
    }
    matrice = new DOMMatrix().translate(w / 2, hh / 2).rotate(rot).scale(s).translate(-centre.x, -centre.y);
    scene.style.transform = matrice.toString();
    scene.style.setProperty('--_s', String(s));
    peindreCalque();
  }

  // Grille : un motif au pas de l'échelle, depuis l'origine calibrée ; trait d'un pixel d'écran.
  function peindreGrille(c) {
    grille.replaceChildren();
    if (!c.grille || !(c.echelle?.px_case > 0)) return;
    const p = c.echelle.px_case, ox = ((c.echelle.origine_x || 0) % p + p) % p, oy = ((c.echelle.origine_y || 0) % p + p) % p;
    const motif = svg('pattern', { id: `cm-proj-motif-${suffixe}`, patternUnits: 'userSpaceOnUse', width: p, height: p, x: ox, y: oy },
      svg('path', { d: `M ${p} 0 L 0 0 0 ${p}`, fill: 'none', stroke: 'currentColor', 'vector-effect': 'non-scaling-stroke' }));
    grille.append(svg('defs', {}, motif), svg('rect', { width: c.largeur, height: c.hauteur, fill: `url(#cm-proj-motif-${suffixe})` }));
  }

  // Les annotations (terrains hachurés avec leur pictogramme, mesures avec leur libellé, jetons), en coordonnées de carte,
  // des deux côtés ; redessinées à chaque scène. Une case non calibrée vaut PX_CASE_DEFAUT.
  const annot = svg('g', { class: 'cm-proj__annot' });
  calque.append(annot);
  function peindreAnnotations(c) {
    annot.replaceChildren();
    const q = c.echelle?.px_case > 0 ? c.echelle.px_case : PX_CASE_DEFAUT;
    const pas = q / 5;
    annot.append(svg('defs', {}, TERRAINS.map(([cle, , , ton]) => svg('pattern', { id: `cm-proj-hach-${cle}-${suffixe}`, patternUnits: 'userSpaceOnUse', width: pas, height: pas, style: `color: var(--${ton})` },
      svg('rect', { width: pas, height: pas, fill: 'currentColor', opacity: '0.16' }),
      svg('path', { d: `M 0 ${pas} L ${pas} 0 M ${-pas / 2} ${pas / 2} L ${pas / 2} ${-pas / 2} M ${pas / 2} ${pas * 1.5} L ${pas * 1.5} ${pas / 2}`, stroke: 'currentColor', 'stroke-width': q / 40, opacity: '0.7' })))));
    const picto = (x, y, icone, ton, r, classe) => svg('g', { class: classe, transform: `translate(${x} ${y})`, style: `color: var(--${ton})` },
      svg('circle', { r, class: 'cm-proj__picto-fond' }),
      svg('use', { href: `#lu-${icone}`, x: -r * 0.62, y: -r * 0.62, width: r * 1.24, height: r * 1.24 }));
    for (const t of c.terrains || []) {
      if (!t.forme) continue;
      const def = TERRAINS.find(d => d[0] === t.type) || TERRAINS[0];
      const motif = `url(#cm-proj-hach-${def[0]}-${suffixe})`;
      const el = elementForme(t.forme, t.forme.type === 'trait' ? { stroke: motif } : { fill: motif, stroke: 'currentColor', 'stroke-width': 1.5, 'vector-effect': 'non-scaling-stroke' });
      const ce = centreForme(t.forme);
      annot.append(svg('g', { class: 'cm-proj__terrain', style: `color: var(--${def[3]})` }, el, picto(ce.x, ce.y, def[2], def[3], q * 0.3, 'cm-proj__picto')));
    }
    for (const m of c.mesures || []) annot.append(elementMesure(m, q));
    for (const j of c.jetons || []) {
      const def = JETONS.find(d => d[0] === j.type) || JETONS[0];
      const icone = j.type === 'piege' ? (PIEGES.find(v => v[0] === j.variante)?.[2] || def[2]) : def[2];
      annot.append(picto(j.x, j.y, icone, def[3], q * 0.42, 'cm-proj__jeton'));
    }
  }
  // La mesure en cours (le MJ la glisse) : dessinée sans être gardée ; apercuMesure(null) l'efface.
  let mesureApercu = null;
  function apercuMesure(m) {
    mesureApercu?.remove(); mesureApercu = null;
    const c = courante?.carte;
    if (!m || !c) return;
    mesureApercu = elementMesure(m, c.echelle?.px_case > 0 ? c.echelle.px_case : PX_CASE_DEFAUT);
    calque.append(mesureApercu);
  }

  // Le cadre des joueurs (MJ seulement), dessiné en coordonnées de carte, tourné à l'inverse de la carte pour rester
  // droit à l'écran ; le dehors en sourdine.
  function peindreCalque() {
    const c = courante?.carte;
    const ancien = calque.querySelector('.cm-proj__cadre-groupe');
    ancien?.remove();
    if (!c || !mj) return;
    const k = cadreJoueurs(courante);
    const o = c.cadrage || centreDe(c);
    const rot = c.rotation || 0;
    const chemin = `M ${o.x - k.w / 2} ${o.y - k.h / 2} h ${k.w} v ${k.h} h ${-k.w} Z`;
    const grand = 1e6;
    annot.after(svg('g', { class: 'cm-proj__cadre-groupe', transform: `rotate(${-rot} ${o.x} ${o.y})` },
      svg('path', { class: 'cm-proj__dehors', d: `M ${-grand} ${-grand} h ${2 * grand} v ${2 * grand} h ${-2 * grand} Z ${chemin}`, 'fill-rule': 'evenodd' }),
      svg('path', { class: 'cm-proj__cadre', d: chemin, 'vector-effect': 'non-scaling-stroke' })));
  }

  // La mire de calibrage : un carré de 1 pouce, 10 cm, la grille des cases ; en px CSS de la fenêtre joueurs (mode joueurs),
  // ou à l'échelle dans le cadre (MJ : le même dessin, réduit).
  function mire(sc) {
    const { w, h: hh } = taille();
    const pouces = sc.ecran?.largeur_pouces > 0 ? sc.ecran.largeur_pouces : null;
    if (!pouces) return h('div', { class: 'cm-proj__mire' }, h('p', { class: 'cm-proj__mire-texte' }, 'Réglez d\'abord la largeur de l\'écran (fenêtre Campagne, onglet « Ce poste »).'));
    const casePx = w / pouces;
    const cm = casePx / 2.54;
    const n = Math.floor(pouces), m = Math.floor(hh / casePx);
    const el = h('div', { class: 'cm-proj__mire', style: { backgroundSize: `${casePx}px ${casePx}px` } },
      h('div', { class: 'cm-proj__mire-carre', style: { width: `${casePx}px`, height: `${casePx}px` } }, h('span', {}, '1 pouce')),
      h('div', { class: 'cm-proj__mire-regle', style: { width: `${10 * cm}px` } }, h('span', {}, '10 cm')),
      h('p', { class: 'cm-proj__mire-texte' }, `${pouces} pouces de large : ${n} × ${m} cases de 1 pouce · ${w} × ${hh} px`),
      h('p', { class: 'cm-proj__mire-texte cm-proj__mire-texte--s' }, 'Posez une règle sur l\'écran. Si la grille ne va pas jusqu\'aux bords, la TV coupe l\'image (surbalayage : « Scan uniquement » dans ses réglages).'));
    return el;
  }

  function maj(sc) {
    courante = sc;
    const c = sc?.carte;
    conteneur.dataset.affichage = sc?.affichage || 'tableau';
    scene.hidden = !(sc?.affichage === 'carte' && c);
    hors.hidden = !scene.hidden;
    if (scene.hidden) {
      // Une image : seule, sans sa légende (demande du MJ, 2026-11-03 : pas de nom sous l'image ; la légende sert au MJ).
      // Sans référent : une image distante (illustration d'un monstre sur D&D Beyond) se charge aussi.
      if (sc?.affichage === 'image' && sc.image?.chemin) hors.replaceChildren(h('img', { class: 'cm-proj__image', src: sc.image.chemin, alt: sc.image.legende || '', referrerpolicy: 'no-referrer' }));
      else if (sc?.affichage === 'mire') hors.replaceChildren(mire(sc));
      else if (sc?.tableau && sc.rendreTableau) hors.replaceChildren(sc.rendreTableau(sc.tableau, { mj }));
      else hors.replaceChildren(h('div', { class: 'cm-proj__veille' }, h('p', { class: 'cm-proj__titre' }, sc?.titre || ''), sc?.sous_titre ? h('p', { class: 'cm-proj__sous-titre' }, sc.sous_titre) : ''));
      // Rotations : l'image montrée et le tableau des joueurs ont la leur, le fond du tableau la sienne (indépendante).
      const tourner = (el, deg) => { el.style.transform = deg ? `rotate(${deg}deg)` : ''; el.classList.toggle('est-tournee', !!(deg % 180)); };
      const rot = sc?.affichage === 'image' ? (sc.image?.rotation ?? sc.rotation) : sc?.affichage === 'tableau' ? (sc.tableau?.rotation ?? sc.rotation) : sc?.rotation;
      tourner(hors, rot || 0);
      const f = sc?.affichage === 'tableau' && sc.tableau?.fond ? sc.tableau : null;
      fond.hidden = !f;
      if (f) { if (fondImg.getAttribute('src') !== f.fond) fondImg.src = f.fond; tourner(fond, f.fond_rotation || 0); }
      return;
    }
    fond.hidden = true;
    if (c.chemin !== cheminCharge) { img.src = c.chemin; cheminCharge = c.chemin; }
    if (c.id !== carteVue) { carteVue = c.id; vueK = 1; vueCentre = null; vueAuto = true; }
    scene.style.width = c.largeur + 'px';
    scene.style.height = c.hauteur + 'px';
    for (const el of [masque, grille, calque]) { el.style.width = c.largeur + 'px'; el.style.height = c.hauteur + 'px'; }
    for (const el of [grille, calque]) el.setAttribute('viewBox', `0 0 ${c.largeur} ${c.hauteur}`);
    const lm = Math.min(MASQUE_MAX, c.largeur);
    const hm = Math.max(1, Math.round(c.hauteur * lm / c.largeur));
    if (masque.width !== lm || masque.height !== hm) { masque.width = lm; masque.height = hm; }
    peindreBrouillard(masque, c);
    peindreGrille(c);
    peindreAnnotations(c);
    placer();
  }

  // Une forme en cours (le pinceau qu'on passe, le rectangle qu'on glisse) : le brouillard se repeint avec elle, en direct,
  // sans la garder (demande du MJ, 2026-11-03 : voir le résultat tout de suite) ; apercuForme(null) l'efface. Une
  // repeinte par image au plus.
  let formeEnCours = null, repeinteDemandee = false;
  function apercuForme(f) {
    formeEnCours = f;
    if (repeinteDemandee) return;
    repeinteDemandee = true;
    requestAnimationFrame(() => { repeinteDemandee = false; const c = courante?.carte; if (c && !scene.hidden) peindreBrouillard(masque, c, formeEnCours); });
  }

  // Un ping à (x, y) en px de carte : trois ondes, deux secondes.
  function ping(x, y) {
    const r = Math.max(24 / s, (courante?.carte?.echelle?.px_case || 60) * 0.8);
    const g = svg('g', { class: 'cm-proj__ping', transform: `translate(${x} ${y})` },
      [0, 1, 2].map(i => svg('circle', { r, class: 'cm-proj__ping-onde', style: `animation-delay: ${i * 0.35}s` })),
      svg('circle', { r: r / 6, class: 'cm-proj__ping-coeur' }));
    calque.append(g);
    setTimeout(() => g.remove(), 2200);
  }

  // Un point de la fenêtre (événement pointeur) en px de carte.
  function versCarte(ev) {
    const r = conteneur.getBoundingClientRect();
    const p = matrice.inverse().transformPoint(new DOMPoint(ev.clientX - r.left, ev.clientY - r.top));
    return { x: p.x, y: p.y };
  }

  // La vue du MJ. zoomerVue(f, ev) : f fois plus près, le point de carte sous le pointeur ne bouge pas (sans ev : le centre).
  // deplacerVue(p0, ev) : amène sous le pointeur le point de carte p0 (celui saisi au début du glisser). ajusterVue() : la
  // carte entière.
  const K_MAX = 12;
  function zoomerVue(f, ev = null) {
    const c = courante?.carte;
    if (!c || !mj) return;
    figerVue(c);
    // On ne dézoome pas au-delà de la vue qui montre tout (carte et cadre des joueurs).
    const kMin = vueEntiere(c).k;
    const k = Math.min(K_MAX, Math.max(kMin, vueK * f));
    if (k === vueK) return;
    const p = ev ? versCarte(ev) : centreDe(c);
    const centre = vueCentre || centreDe(c);
    const ff = k / vueK;
    vueK = k;
    vueCentre = { x: p.x - (p.x - centre.x) / ff, y: p.y - (p.y - centre.y) / ff };
    if (k <= kMin) { vueAuto = true; }   // revenu à la vue entière : elle suit de nouveau le cadre
    placer();
  }
  function deplacerVue(p0, ev) {
    const c = courante?.carte;
    if (!c || !mj) return;
    figerVue(c);
    const p = versCarte(ev);
    const centre = vueCentre || centreDe(c);
    vueCentre = { x: centre.x - (p.x - p0.x), y: centre.y - (p.y - p0.y) };
    placer();
  }
  // glisserFond(p0, ev) : la carte glisse sous un cadre immobile à l'écran (retour du MJ, 2026-11-03) : la vue suit le pointeur
  // comme deplacerVue(), à tout zoom, et renvoie le décalage appliqué (px de carte), que l'appelant retire aussi du cadrage pour
  // que le cadre ne bouge pas à l'écran ; il redessine ensuite (rien n'est replacé ici).
  function glisserFond(p0, ev) {
    const c = courante?.carte;
    if (!c || !mj) return null;
    figerVue(c);
    const p = versCarte(ev);
    const d = { x: p.x - p0.x, y: p.y - p0.y };
    const centre = vueCentre || centreDe(c);
    vueCentre = { x: centre.x - d.x, y: centre.y - d.y };
    return d;
  }
  // La vue qui montre tout (carte et cadre), et qui suit le cadre jusqu'au prochain geste.
  function ajusterVue() { vueAuto = true; placer(); }
  const estVueEntiere = () => vueAuto || (courante?.carte ? vueK <= vueEntiere(courante.carte).k + 1e-6 : true);
  // La vue sur le cadre des joueurs : la zone projetée remplit le conteneur (avec une marge), centrée sur le cadrage.
  function ajusterVueSurCadre() {
    const c = courante?.carte;
    if (!c || !mj) return;
    const { w, h: hh } = taille();
    const t = tournee(c, c.rotation || 0), kd = cadreJoueurs(courante);
    const entiere = Math.min(w / t.w, hh / t.h);
    vueAuto = false;
    vueK = Math.min(K_MAX, Math.max(vueEntiere(c).k, Math.min(w / kd.w, hh / kd.h) * 0.92 / entiere));
    vueCentre = { ...(c.cadrage || centreDe(c)) };
    placer();
  }
  // Le cadre des joueurs à l'écran (mode MJ) : son centre et ses demi-côtés en px du conteneur (droit à l'écran).
  function cadreEcran() {
    const c = courante?.carte;
    if (!c || !mj) return null;
    const kd = cadreJoueurs(courante);
    const o = c.cadrage || centreDe(c);
    const p = matrice.transformPoint(new DOMPoint(o.x, o.y));
    return { cx: p.x, cy: p.y, hw: kd.w * s / 2, hh: kd.h * s / 2 };
  }

  const redim = new ResizeObserver(() => { if (conteneur.isConnected) { if (courante?.affichage === 'mire') maj(courante); else placer(); } else redim.disconnect(); });
  redim.observe(conteneur);
  return { maj, ping, versCarte, echelle: () => s, calque, cadre: () => (courante ? cadreJoueurs(courante) : null), scene: () => courante,
    zoomerVue, deplacerVue, glisserFond, ajusterVue, ajusterVueSurCadre, cadreEcran, vueK: () => vueK, estVueEntiere, apercuForme, apercuMesure };
}
