// Campagne ouverte : son manifeste (manifeste.json, formats/campagne.md), lu une fois au démarrage par chargerCampagne().
// lancer.ps1 sert chaque campagne sous son adresse (http://localhost:8735/<id>/) : les lectures relatives de la page
// (data/, etat/, wiki/, musique/, manifeste.json, carte.json, bibliotheque.json) vont au dossier campagnes/<id>/, le reste est commun.
// La liste des campagnes du poste : /campagnes.json (accueil.html, bouton de l'en-tête).
// Rien dans app/ ne nomme une campagne : ce qui lui est propre (titre, sources, vocabulaire, réglages…) vient d'ici.

const DEFAUT = {
  schema: 1,
  id: null,
  titre: 'The Screen',
  sous_titre: '',
  icone: 'd20',
  charte: 'barovie-neon',
  theme: 'nuit',
  sources: {},
  vocabulaire: {},
  reglages: {},
  couleurs_factions: {},
  livres_beyond: null,

};

let manifeste = null;

// Le manifeste, complété des valeurs par défaut. Sans manifeste (adresse sans campagne, sans dossier campagnes/), les
// valeurs par défaut : le gestionnaire marche comme avant les campagnes.
export async function chargerCampagne() {
  if (manifeste) return manifeste;
  let lu = {};
  try {
    const r = await fetch('manifeste.json', { cache: 'no-store' });
    if (r.ok) lu = await r.json();
  } catch { /* serveur injoignable : app/etat.js le dira */ }
  manifeste = { ...DEFAUT, ...lu };
  if (manifeste.id) try { localStorage.setItem('cm:campagne', manifeste.id); } catch { /* stockage refusé : l'accueil listera */ }
  return manifeste;
}

// La charte de la campagne (`charte` du manifeste) : Barovie Néon est celle de base (design-system/tokens.css et
// barovie.css, chargés par index.html) ; une autre charte, dans design-system/chartes/<id>/, ajoute ses jetons (tokens.css,
// générés par build-tokens.ps1) et ses effets (charte.css) par-dessus. La page attend qu'ils soient chargés.
export const CHARTE_DE_BASE = 'barovie-neon';
export async function appliquerCharte(m = campagneOuverte()) {
  const id = /^[a-z0-9-]+$/.test(m.charte || '') ? m.charte : CHARTE_DE_BASE;
  document.documentElement.dataset.charte = id;
  if (id === CHARTE_DE_BASE) return;
  await Promise.all(['tokens.css', 'charte.css'].map(f => new Promise(fini => {
    const lien = Object.assign(document.createElement('link'), { rel: 'stylesheet', href: `design-system/chartes/${id}/${f}` });
    lien.addEventListener('load', fini);
    lien.addEventListener('error', () => { console.error(`Charte « ${id} » : design-system/chartes/${id}/${f} introuvable.`); fini(); });
    document.head.append(lien);
  })));
}

// Après chargerCampagne() : le manifeste lu (les valeurs par défaut avant).
export const campagneOuverte = () => manifeste || DEFAUT;

// Un réglage de la campagne (`reglages` du manifeste), avec sa valeur par défaut.
export const reglage = (cle, defaut) => campagneOuverte().reglages?.[cle] ?? defaut;

// Sources des données (`source` d'un élément : « LIVRE », « SUPP », « MJ »…) : libellé court et couleur de badge, d'après
// `sources` du manifeste ; une source inconnue garde son identifiant.
export const libelleSource = id => campagneOuverte().sources?.[id]?.court || id;
export const couleurSource = id => campagneOuverte().sources?.[id]?.couleur || null;
// Les sources de la campagne, sauf le MJ : [[id, libellé court]] (filtre par source des images…).
export const sourcesLivres = () => Object.entries(campagneOuverte().sources || {}).filter(([id, s]) => id !== 'MJ' && !s.mj).map(([id, s]) => [id, s.court || id]);

// Vocabulaire du monde de la campagne (`vocabulaire` du manifeste : monde, de_monde, dans_le_monde, habitant, habitants) :
// « Bêtes {de_monde} » -> « Bêtes d'Aurval ». null si un mot manque : l'appelant prend alors un texte neutre.
export function vocabulaire(gabarit) {
  if (typeof gabarit !== 'string') return gabarit ?? null;
  const v = campagneOuverte().vocabulaire || {};
  let manque = false;
  const texte = gabarit.replace(/\{(\w+)\}/g, (_, cle) => {
    if (v[cle]) return v[cle];
    manque = true;
    return '';
  });
  return manque ? null : texte;
}

// Couleur de pastille d'une faction (`couleurs_factions` du manifeste, sinon `couleur` de factions.json) : le nom d'un
// jeton de la charte (`fac-zarovich`, `cierge`…), ou null.
export const couleurFaction = f => f?.couleur || campagneOuverte().couleurs_factions?.[f?.id] || null;

// Wiki de la campagne (vvd.world, importé dans wiki/ par « outils/Importer le wiki.cmd ») : facultatif. Sans `wiki.url` dans le
// manifeste, le gestionnaire ne lit pas wiki/ et ne montre ni portraits du wiki, ni onglet VVD, ni liens vers ses pages.
export const wikiActif = () => !!campagneOuverte().wiki?.url;

// Enregistre le manifeste de la campagne ouverte (lancer.ps1 : PUT manifeste.json). Erreur : le message du serveur.
export async function enregistrerManifeste(m) {
  const r = await fetch('manifeste.json', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(m, null, 2) + '\n' });
  if (!r.ok) throw new Error(await r.text());
}

// Crée une campagne (lancer.ps1 : POST /campagnes.json) : son dossier, son manifeste, data/ et etat/ avec leurs guides.
// `musique` : { sources, pistes }, les textes de musique/ (fusionnerPaquets() de app/musique-paquets.js), ou null.
export async function creerCampagne(m, { musique = null } = {}) {
  const r = await fetch('/campagnes.json', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: m.id, manifeste: JSON.stringify(m, null, 2) + '\n', musique }) });
  if (!r.ok) throw new Error(await r.text());
  return m.id;
}

// Les météos réelles fournies aux campagnes (modeles/meteos/index.json : [{ id, nom, climat, description }]).
export async function listerMeteos() {
  try {
    const r = await fetch('/modeles/meteos/index.json', { cache: 'no-store' });
    return r.ok ? (await r.json()).meteos || [] : [];
  } catch { return []; }
}

// Les chartes du poste ([{ id, nom }]).
export async function listerChartes() {
  try {
    const r = await fetch('/chartes.json', { cache: 'no-store' });
    return r.ok ? await r.json() : [{ id: CHARTE_DE_BASE, nom: 'Barovie Néon' }];
  } catch { return [{ id: CHARTE_DE_BASE, nom: 'Barovie Néon' }]; }
}

// Version du gestionnaire (/version.json, lancer.ps1) : { version, date, modifie, mainteneur }, ou null.
export async function lireVersion() {
  try {
    const r = await fetch('/version.json', { cache: 'no-store' });
    return r.ok ? await r.json() : null;
  } catch { return null; }
}

// Les campagnes du poste ([{ id, titre, sous_titre, charte, icone, defaut }]) ; [] si le serveur n'en a pas.
export async function listerCampagnes() {
  try {
    const r = await fetch('/campagnes.json', { cache: 'no-store' });
    return r.ok ? await r.json() : [];
  } catch { return []; }
}
