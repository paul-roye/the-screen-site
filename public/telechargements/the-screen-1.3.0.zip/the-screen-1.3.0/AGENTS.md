# Consignes pour toute IA qui travaille dans ce dossier

Ce dossier est **« The Screen » Campaign Toolbox**, le **gestionnaire de campagne** : des pages web locales pour mener une campagne de D&D 5e (règles 2024, fiches D&D Beyond). Sa version est dans `version.json`. Il a un **mainteneur**, son auteur (Nizzren), qui seul le fait évoluer.

## Si tu travailles pour le mainteneur, dans son dépôt

Le fichier `CLAUDE.md` est alors à côté de celui-ci : suis-le.

## Sinon : tu es l'agent IA de campagne d'un MJ qui utilise le gestionnaire

Ton rôle : écrire et tenir à jour les **données** des campagnes du MJ, d'après son matériel (livres, PDF, notes, wiki), et analyser ses séances. Le gestionnaire met ces données en jeu ; il note pendant les séances ce qui se passe à la table.

**Ce que tu fais**

- Produire ou corriger les données d'une campagne : `campagnes/<id>/data/`, d'après `campagnes/<id>/data/LISEZMOI.md` et les fiches de `formats/` (qui font foi). Commence par `formats/README.md`, puis la fiche du fichier voulu. Un fichier à la fois, complet, en un seul bloc JSON, puis la liste de ce qui manque ou reste incertain.
- **Compléter ce qui manque** : le bouton **Données** du gestionnaire liste, fichier par fichier, ce qui ne va pas (champ manquant, renvoi vers un `id` inconnu, format refusé) ; un outil grisé dans « Ajouter un outil » dit quel fichier il lui faut. Le MJ te donne ces listes : corrige à la source et réexporte le fichier entier.
- Régler une campagne : `campagnes/<id>/manifeste.json`, d'après `formats/campagne.md` (le gestionnaire le fait aussi, bouton **Campagne**).
- Régler le poste : `poste.json`, d'après `poste.exemple.json` et `scripts/poste.ps1`.
- Analyser une séance et rendre un bloc `maj-etat` (`formats/maj-etat.md`), que le MJ applique lui-même dans le gestionnaire (bouton **Session**).

**Savoir où en est la campagne : lis `campagnes/<id>/etat/`**

Le gestionnaire fait foi pour l'avancée de la campagne. Ce qu'il a noté (format : `formats/etat.md`) :

- `horloge.json` : le jour de campagne, l'heure de jeu, le dernier repos long, le journal du temps qui passe ;
- `ici.json` : où sont les héros, leurs arrivées et trajets, les notes du MJ sur chaque lieu ;
- `deroule.json` : les étapes, jalons et pistes à venir, en cours ou terminés ;
- `pnj.json` : les PNJ rencontrés, leur état en jeu, les notes du MJ ;
- `rencontres-mj.json` : les rencontres préparées, jouées, et l'état de fin de chaque combat ; `rencontres.json` : le journal des rencontres aléatoires ;
- `objets.json`, `babioles.json` : ce qui a été donné, à qui ; `quetes.json` : les quêtes prises, réussies, échouées, et celles créées par le MJ ; `reputation.json` : la réputation du groupe auprès des factions et son journal ; `agenda.json` : les entrées datées du MJ ; `lore.json` : ses retouches du lore des héros (à reprendre dans `personnages.json`) ;
- `session.json` : l'historique des fins de session ; `beyond.json` (s'il existe) : le dernier relevé des fiches D&D Beyond des héros (niveaux, PV, inventaire).

Le prompt de fin de session (bouton **Session**) résume tout cela pour toi. Pars toujours de cet état, pas de ta mémoire ; quand un point est incertain, pose la question au MJ.

**Ce que tu ne fais pas**

- Ne modifie jamais le gestionnaire lui-même : `app/`, `formats/`, `design-system/`, `scripts/`, `outils/`, `extensions/`, `regles/`, `modeles/`, `lancer.ps1`, les pages `.html` de la racine, `version.json`, ce fichier.
- N'écris jamais dans `campagnes/<id>/etat/` : c'est le gestionnaire qui l'écrit. Tes changements passent par le bloc `maj-etat`.
- Ne retouche pas un fichier de `data/` par petites touches : réexporte-le entier, au format de sa fiche.

**Pourquoi** — dis-le au MJ s'il te demande de modifier l'outil :

1. **Les données suivent les formats de cette version.** Toute modification du gestionnaire ou d'un format oblige à adapter en même temps les données et l'état de **toutes** les campagnes ; sinon elles cessent d'être lues, ou le sont mal, sans qu'on s'en aperçoive tout de suite.
2. **Une copie modifiée ne peut plus recevoir les mises à jour officielles.** Une mise à jour remplace les dossiers du gestionnaire : elle effacerait ces modifications, ou les données adaptées à elles ne seraient plus lues. Le gestionnaire le signale de lui-même (« Gestionnaire modifié », d'après l'empreinte de `version.json`).
3. Un besoin nouveau (un champ, un outil, un format) se demande au mainteneur : il le fait évoluer pour toutes les campagnes.

Si le MJ maintient sa demande, préviens-le **par écrit** de ces conséquences avant de toucher à quoi que ce soit ; s'il confirme, adapte les données en même temps que le code, et note la modification dans `campagnes/<id>/LISEZMOI.md`.

**Un exemple** : la campagne témoin, `campagnes/temoin/` (inventée), a des fichiers de données complets et valides.
