﻿# Lance le gestionnaire de campagne : petit serveur local, puis ouverture du navigateur.
# Usage : powershell -ExecutionPolicy Bypass -File .\lancer.ps1   (ou double-clic sur « Lancer le gestionnaire.cmd »)
#         ... -Port 8735 -SansNavigateur
# Port : -Port, sinon `port` de poste.json, sinon 8735.
#
# - Sert les fichiers du dossier (lecture seule), uniquement sur localhost.
# - Une campagne par adresse (formats/campagne.md) : http://localhost:8735/<id>/ sert la page du gestionnaire, et ses
#   lectures relatives (data/, etat/, wiki/, musique/, manifeste.json, carte.json, bibliotheque.json) vont au dossier campagnes/<id>/ ; le
#   reste (app/, design-system/, modeles/…) est commun. Une campagne `dossiers_a_la_racine` garde data/, etat/, wiki/ et
#   musique/ à la racine (les premières campagnes). Une adresse sans campagne va à la campagne par
#   défaut (`campagne` de poste.json, sinon celle à la racine, sinon la première) : l'extension du MJ et les anciens liens
#   continuent de marcher.
#   La racine (/) sert accueil.html, qui rouvre la dernière campagne ou les liste ; /campagnes.json les décrit.
# - Accepte l'écriture (PUT) dans etat/<nom>.json de la campagne et nulle part ailleurs : data/ reste intouché.
# - Avant d'écraser un fichier d'état, garde la première version du jour dans etat/sauvegardes/AAAA-MM-JJ/.
# - Sert sous images-library/ la bibliothèque d'images de la campagne (campagnes/<id>/images-library/, ou réglée dans
#   poste.json : propre au poste). Y accepte des images envoyées par la page (<campagne>/ajout-images.json, Ajout-Images).
param(
    [int]$Port = 0,
    [switch]$SansNavigateur
)
$ErrorActionPreference = 'Stop'
$racine = $PSScriptRoot
$dossierCampagnes = Join-Path $racine 'campagnes'
. (Join-Path $racine 'scripts\poste.ps1')
. (Join-Path $racine 'scripts\campagnes.ps1')
. (Join-Path $racine 'scripts\version.ps1')
$poste = Lire-Poste $racine
if (-not $Port) { $Port = $poste.port }
$utf8 = New-Object Text.UTF8Encoding $false

# Version du gestionnaire (/version.json) : celle de version.json, et si le code a changé depuis (empreinte calculée au
# lancement, scripts/version.ps1). `mainteneur` (poste.json) : le poste qui développe le gestionnaire, sans avertissement.
$script:version = & {
    $officielle = $null
    $f = Join-Path $racine 'version.json'
    if (Test-Path $f) { try { $officielle = [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8) | ConvertFrom-Json } catch { } }
    $actuelle = Empreinte-Gestionnaire $racine
    ConvertTo-Json -Compress -InputObject ([ordered]@{
        version = if ($officielle) { [string]$officielle.version } else { $null }
        date = if ($officielle) { [string]$officielle.date } else { $null }
        modifie = -not $officielle -or $officielle.empreinte -ne $actuelle
        mainteneur = [bool]$poste.mainteneur
    })
}

# Entrées propres à une campagne, sous son dossier ; tout le reste est commun à toutes les campagnes.
$propres = @('data', 'etat', 'wiki', 'musique', 'manifeste.json', 'carte.json', 'bibliotheque.json')
# Noms interdits pour une campagne : ils masqueraient un dossier commun.
$reserves = @('app', 'design-system', 'data', 'etat', 'wiki', 'musique', 'images-library', 'icones-beyond', 'sources', 'formats', 'modeles',
    'extensions', 'scripts', 'regles', 'prompts', 'etudes', 'campagnes', 'releases', 'outils', 'mainteneur')

# Campagnes : campagnes/<id>/manifeste.json, relues toutes les 5 s au plus (une campagne ajoutée se voit sans relancer).
# Sans dossier campagnes/ : une seule campagne implicite, à la racine (comme avant les campagnes).
$script:campagnes = $null; $script:luesLe = [datetime]::MinValue
function Campagnes {
    if ($script:campagnes -and ((Get-Date) - $script:luesLe).TotalSeconds -lt 5) { return $script:campagnes }
    $liste = [ordered]@{}
    if (Test-Path $dossierCampagnes -PathType Container) {
        foreach ($d in Get-ChildItem $dossierCampagnes -Directory | Sort-Object Name) {
            if ($d.Name -notmatch '^[a-z0-9][a-z0-9-]{0,63}$' -or $reserves -contains $d.Name) { continue }
            $f = Join-Path $d.FullName 'manifeste.json'
            if (-not (Test-Path $f -PathType Leaf)) { continue }
            try { $m = [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8) | ConvertFrom-Json }
            catch { Write-Warning "Campagne $($d.Name) ignorée : manifeste.json illisible ($($_.Exception.Message))."; continue }
            $liste[$d.Name] = @{ id = $d.Name; dossier = $d.FullName; aLaRacine = [bool]$m.dossiers_a_la_racine; manifeste = $m }
        }
    }
    $script:campagnes = $liste; $script:luesLe = Get-Date
    return $liste
}
function Campagne-Defaut($liste) {
    if ($poste.campagne -and $liste.Contains($poste.campagne)) { return $liste[$poste.campagne] }
    foreach ($c in $liste.Values) { if ($c.aLaRacine) { return $c } }
    foreach ($c in $liste.Values) { return $c }
    return @{ id = $null; dossier = $racine; aLaRacine = $true; manifeste = $null }
}
# Dossier qui contient une entrée propre (data, etat, wiki, musique) de la campagne ; manifeste.json, carte.json et
# bibliotheque.json sont toujours dans le dossier de la campagne.
function Dossier-Propre($camp, [string]$entree) {
    if ($entree -in @('manifeste.json', 'carte.json', 'bibliotheque.json')) { return $camp.dossier }
    if ($camp.aLaRacine) { return $racine }
    return $camp.dossier
}
# Bibliothèque d'images de la campagne (propre au poste, scripts/campagnes.ps1) : campagnes/<id>/images-library\, sauf
# `bibliotheques.<id>` de poste.json, ou `bibliotheque` pour la campagne par défaut.
function Bibliotheque-De($camp) { return Bibliotheque-Campagne $racine $poste $camp (Campagne-Defaut (Campagnes)).id }

$types = @{
    '.html' = 'text/html; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'
    '.json' = 'application/json; charset=utf-8'; '.md' = 'text/markdown; charset=utf-8'; '.txt' = 'text/plain; charset=utf-8'
    '.pdf' = 'application/pdf'; '.svg' = 'image/svg+xml'; '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.jpeg' = 'image/jpeg'; '.webp' = 'image/webp'
    '.gif' = 'image/gif'; '.ico' = 'image/x-icon'; '.ttf' = 'font/ttf'; '.otf' = 'font/otf'; '.woff' = 'font/woff'; '.woff2' = 'font/woff2'
}

function Repondre($ctx, [int]$code, [byte[]]$corps, [string]$type = 'text/plain; charset=utf-8') {
    $r = $ctx.Response
    $r.StatusCode = $code
    $r.ContentType = $type
    $r.Headers['Cache-Control'] = 'no-store'
    $r.Headers['X-Content-Type-Options'] = 'nosniff'
    $r.ContentLength64 = $corps.Length
    # HEAD (un fichier existe-t-il ?) : la longueur sans le contenu, sinon la réponse ne se termine jamais.
    if ($corps.Length -and $ctx.Request.HttpMethod -ne 'HEAD') { $r.OutputStream.Write($corps, 0, $corps.Length) }
    $r.OutputStream.Close()
}
function Texte($ctx, [int]$code, [string]$msg) { Repondre $ctx $code $utf8.GetBytes($msg) }
function Rediriger($ctx, [string]$vers) {
    $ctx.Response.Headers['Cache-Control'] = 'no-store'
    $ctx.Response.Redirect($vers)
    $ctx.Response.Close()
}

# /campagnes.json : les campagnes du poste (accueil.html, bouton de l'en-tête), la campagne par défaut en premier rang.
function Liste-Campagnes($liste) {
    $defaut = (Campagne-Defaut $liste).id
    $sortie = @(foreach ($c in $liste.Values) {
        [ordered]@{ id = $c.id; titre = [string]$c.manifeste.titre; sous_titre = [string]$c.manifeste.sous_titre
            charte = [string]$c.manifeste.charte; icone = [string]$c.manifeste.icone; defaut = ($c.id -eq $defaut) }
    })
    return ConvertTo-Json -InputObject $sortie -Depth 4 -Compress
}

# /chartes.json : la charte de base et celles de design-system/chartes/<id>/ (nom pris dans leur tokens.json).
function Liste-Chartes {
    $sortie = @([ordered]@{ id = 'barovie-neon'; nom = 'Barovie Néon' })
    $dossier = Join-Path $racine 'design-system\chartes'
    if (Test-Path $dossier -PathType Container) {
        foreach ($d in Get-ChildItem $dossier -Directory | Sort-Object Name) {
            $nom = $d.Name
            try { $nom = ([IO.File]::ReadAllText((Join-Path $d.FullName 'tokens.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json).name } catch { }
            $sortie += [ordered]@{ id = $d.Name; nom = $nom }
        }
    }
    return ConvertTo-Json -InputObject $sortie -Compress
}

function Lire-Corps($req) {
    $lecteur = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $t = $lecteur.ReadToEnd(); $lecteur.Close()
    return $t
}
function Ecrire-Fichier([string]$cible, [string]$texte) {
    $tmp = "$cible.tmp"
    [IO.File]::WriteAllText($tmp, $texte, $utf8)
    Move-Item -Force $tmp $cible
}

# PUT <campagne>/manifeste.json : les réglages de la campagne, depuis la fenêtre Campagne. Le manifeste entier ; son `id`,
# `dossiers_a_la_racine` et `modules` ne changent pas ici (ils engagent les dossiers et les données de la campagne).
function Ecrire-Manifeste($ctx, $camp) {
    if (-not $camp.id) { return Texte $ctx 403 "Pas de campagne : rien à enregistrer." }
    $texte = Lire-Corps $ctx.Request
    if ($texte.Length -gt 1MB) { return Texte $ctx 413 "Manifeste trop gros." }
    try { $m = $texte | ConvertFrom-Json } catch { return Texte $ctx 400 "JSON invalide : $($_.Exception.Message)" }
    if ($m.id -ne $camp.id) { return Texte $ctx 400 "L'id du manifeste doit rester « $($camp.id) »." }
    if (-not ([string]$m.titre).Trim()) { return Texte $ctx 400 "Le titre est obligatoire." }
    foreach ($cle in 'dossiers_a_la_racine', 'modules') {
        if ((ConvertTo-Json -Compress -InputObject $m.$cle) -ne (ConvertTo-Json -Compress -InputObject $camp.manifeste.$cle)) {
            return Texte $ctx 409 "« $cle » ne se change pas depuis le gestionnaire : modifiez manifeste.json à la main, en connaissance de cause."
        }
    }
    Ecrire-Fichier (Join-Path $camp.dossier 'manifeste.json') $texte
    $script:campagnes = $null
    return Texte $ctx 204 ''
}

# POST /campagnes.json { id, manifeste: "<texte JSON>" } : une nouvelle campagne, campagnes/<id>/ avec son manifeste, data/
# et etat/, et les guides pour l'IA qui produira ses données (modèles de formats/modeles/).
function Creer-Campagne($ctx, $liste) {
    try { $corps = (Lire-Corps $ctx.Request) | ConvertFrom-Json } catch { return Texte $ctx 400 "JSON invalide : $($_.Exception.Message)" }
    $id = [string]$corps.id
    if ($id -notmatch '^[a-z0-9][a-z0-9-]{0,63}$') { return Texte $ctx 400 "Identifiant : minuscules, chiffres et tirets (« ma-campagne »)." }
    if ($reserves -contains $id) { return Texte $ctx 400 "« $id » est un nom réservé (dossier du gestionnaire)." }
    $dossier = Join-Path $dossierCampagnes $id
    if ($liste.Contains($id) -or (Test-Path $dossier)) { return Texte $ctx 409 "La campagne « $id » existe déjà." }
    try { $m = [string]$corps.manifeste | ConvertFrom-Json } catch { return Texte $ctx 400 "Manifeste illisible : $($_.Exception.Message)" }
    if ($m.id -ne $id) { return Texte $ctx 400 "L'id du manifeste doit être « $id »." }
    if (-not ([string]$m.titre).Trim()) { return Texte $ctx 400 "Le titre est obligatoire." }
    # Musique de départ : les paquets cochés (modeles/musique/), fusionnés par la page.
    if ($corps.musique) {
        foreach ($f in 'sources', 'pistes') {
            $t = [string]$corps.musique.$f
            try { $null = $t | ConvertFrom-Json } catch { return Texte $ctx 400 "Musique ($f.json) illisible : $($_.Exception.Message)" }
            if ($t.Length -gt 8MB) { return Texte $ctx 413 "Musique trop grosse." }
        }
    }
    foreach ($d in 'data', 'etat') { New-Item -ItemType Directory -Force -Path (Join-Path $dossier $d) | Out-Null }
    Ecrire-Fichier (Join-Path $dossier 'manifeste.json') ([string]$corps.manifeste)
    # L'aide de démarrage (app/main.js) : montrée à chaque ouverture, jusqu'à « Ne plus montrer ».
    Ecrire-Fichier (Join-Path $dossier 'etat\demarrage.json') '{ "schema": 1, "montrer": true }'
    if ($corps.musique) {
        New-Item -ItemType Directory -Force -Path (Join-Path $dossier 'musique') | Out-Null
        foreach ($f in 'sources', 'pistes') { Ecrire-Fichier (Join-Path $dossier "musique\$f.json") ([string]$corps.musique.$f) }
    }
    foreach ($p in @(@('LISEZMOI-data.md', 'data\LISEZMOI.md'), @('LISEZMOI-etat.md', 'etat\LISEZMOI.md'), @('LISEZMOI-campagne.md', 'LISEZMOI.md'))) {
        $modele = Join-Path $racine "formats\modeles\$($p[0])"
        if (Test-Path $modele) { Copy-Item $modele (Join-Path $dossier $p[1]) }
    }
    $script:campagnes = $null
    Write-Host "  Campagne créée : $dossier" -ForegroundColor DarkCyan
    return Repondre $ctx 201 $utf8.GetBytes((ConvertTo-Json -Compress -InputObject @{ id = $id })) $types['.json']
}

# <campagne>/import-wiki.json : l'import du wiki de la campagne (scripts/import-wiki/importer-wiki.ps1), depuis la fenêtre
# Campagne. GET : son état { url, en_cours, importe_le, journal } (journal : les dernières lignes qu'il a affichées) ;
# POST : le lance en arrière-plan, s'il ne tourne pas déjà (son verrou wiki/.import-en-cours est tenu tant qu'il tourne).
function Import-Wiki($ctx, $camp) {
    if (-not $camp.id) { return Texte $ctx 403 "Pas de campagne." }
    $url = [string]$camp.manifeste.wiki.url
    $dossier = Join-Path (Dossier-Propre $camp 'wiki') 'wiki'
    $verrou = Join-Path $dossier '.import-en-cours'
    $journal = Join-Path $dossier '.import-journal.txt'
    $enCours = $false
    if (Test-Path $verrou) { try { ([IO.File]::Open($verrou, 'Open', 'ReadWrite', 'None')).Dispose() } catch { $enCours = $true } }
    if ($ctx.Request.HttpMethod -eq 'POST') {
        if (-not $url) { return Texte $ctx 409 "La campagne n'a pas de wiki : son adresse s'enregistre d'abord (onglet Campagne)." }
        if ($enCours) { return Texte $ctx 409 "Un import du wiki est déjà en cours." }
        New-Item -ItemType Directory -Force -Path $dossier | Out-Null
        Remove-Item $journal -ErrorAction SilentlyContinue
        $script = Join-Path $racine 'scripts\import-wiki\importer-wiki.ps1'
        Start-Process powershell -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$script`"", '-Campagne', $camp.id, '-Journal', "`"$journal`""
        Write-Host ("  {0:HH:mm:ss}  import du wiki lancé ({1})" -f (Get-Date), $camp.id) -ForegroundColor DarkCyan
        return Texte $ctx 202 ''
    }
    $r = [ordered]@{ url = $url; en_cours = $enCours; importe_le = $null; journal = @() }
    $f = Join-Path $dossier 'wiki.json'
    if ((Test-Path $f) -and ((@(Get-Content $f -TotalCount 15 -Encoding UTF8) -join "`n") -match '"importe_le"\s*:\s*"([^"]+)"')) { $r.importe_le = $Matches[1] }
    # Le journal est la transcription de l'import : seules ses lignes à lui (en retrait), pas l'en-tête de PowerShell.
    if (Test-Path $journal) { $r.journal = @(Get-Content $journal -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_ -match '^\s+\S' } | Select-Object -Last 60 | ForEach-Object { [string]$_ }) }
    return Repondre $ctx 200 $utf8.GetBytes((ConvertTo-Json -Compress -InputObject $r)) $types['.json']
}

# <campagne>/import-images.json : l'import des images de la campagne (scripts/import-images/importer-images.ps1, sources de
# `images.sources` du manifeste), depuis la fenêtre Campagne, onglet « Images ». GET : { bibliotheque, en_cours, journal,
# sources: [{ dossier, images, liste, importe_le }] } (images : le nombre d'images de son dossier ; liste : `releve` ou
# `fournie` pour un livre D&D Beyond dont on a la liste d'images). POST ?source=<n°> (sans : toutes) : le lance en
# arrière-plan ; pour un livre, le corps est la liste relevée par l'extension du MJ, écrite dans .liste-beyond.txt de son
# dossier. POST ?ouvrir=<n°> (ou ?ouvrir=bibliotheque) : ouvre le dossier dans l'Explorateur, créé au besoin.
function Import-Images($ctx, $camp) {
    if (-not $camp.id) { return Texte $ctx 403 "Pas de campagne." }
    $biblio = Bibliotheque-De $camp
    $sources = @($camp.manifeste.images.sources | Where-Object { $_ })
    $dossierDe = { param($s) $d = ([string]$s.dossier).Trim(); if (-not $d -or $d -match '[\\/:*?"<>|]' -or $d.StartsWith('.')) { $null } else { $d } }
    $verrou = Join-Path $biblio '.import-en-cours'
    $journal = Join-Path $biblio '.import-journal.txt'
    $enCours = $false
    if (Test-Path $verrou) { try { ([IO.File]::Open($verrou, 'Open', 'ReadWrite', 'None')).Dispose() } catch { $enCours = $true } }
    $q = $ctx.Request.QueryString
    if ($ctx.Request.HttpMethod -eq 'POST') {
        if (-not (Bibliotheque-Valide $racine $biblio)) { return Texte $ctx 409 "Bibliothèque refusée : $biblio (poste.json)." }
        if ($q['ouvrir']) {
            $cible = $biblio
            if ($q['ouvrir'] -ne 'bibliotheque') {
                $d = & $dossierDe $sources[[int]$q['ouvrir']]
                if (-not $d) { return Texte $ctx 400 "Source inconnue." }
                $cible = Join-Path $biblio $d
            }
            New-Item -ItemType Directory -Force $cible | Out-Null
            Start-Process explorer.exe "`"$cible`""
            return Texte $ctx 204 ''
        }
        if ($enCours) { return Texte $ctx 409 "Un import des images est déjà en cours." }
        $n = -1
        if ($q['source']) {
            $n = [int]$q['source']
            $d = if ($n -ge 0 -and $n -lt $sources.Count) { & $dossierDe $sources[$n] } else { $null }
            if (-not $d) { return Texte $ctx 400 "Source inconnue ou sans dossier valide (manifeste, « images.sources »)." }
            $liste = (Lire-Corps $ctx.Request).Trim()
            if ($liste) {
                if ($sources[$n].type -ne 'beyond' -or $liste.Length -gt 2MB) { return Texte $ctx 400 "Liste d'images refusée." }
                New-Item -ItemType Directory -Force (Join-Path $biblio $d) | Out-Null
                Ecrire-Fichier (Join-Path (Join-Path $biblio $d) '.liste-beyond.txt') ($liste + "`n")
            }
        }
        New-Item -ItemType Directory -Force $biblio | Out-Null
        Remove-Item $journal -ErrorAction SilentlyContinue
        $script = Join-Path $racine 'scripts\import-images\importer-images.ps1'
        Start-Process powershell -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$script`"", '-Campagne', $camp.id, '-Source', $n, '-Journal', "`"$journal`""
        Write-Host ("  {0:HH:mm:ss}  import des images lancé ({1})" -f (Get-Date), $camp.id) -ForegroundColor DarkCyan
        return Texte $ctx 202 ''
    }
    $r = [ordered]@{ bibliotheque = $biblio; en_cours = $enCours; journal = @(); sources = @() }
    foreach ($s in $sources) {
        $d = & $dossierDe $s
        $e = [ordered]@{ dossier = $d; images = 0; liste = $null; importe_le = $null }
        if ($d) {
            $dd = Join-Path $biblio $d
            if (Test-Path $dd -PathType Container) {
                $e.images = @(Get-ChildItem $dd -Recurse -File -Include *.jpg, *.jpeg, *.png, *.webp, *.gif -ErrorAction SilentlyContinue).Count
                $f = Join-Path $dd '.importe-le'
                if (Test-Path $f) { $e.importe_le = ([IO.File]::ReadAllText($f)).Trim() }
            }
            if ($s.type -eq 'beyond') {
                $livre = $(try { ([Uri][string]$s.adresse).Segments[-1].Trim('/') } catch { '' })
                if (Test-Path (Join-Path $dd '.liste-beyond.txt')) { $e.liste = 'releve' }
                elseif ($livre -and (Test-Path (Join-Path $racine "scripts\dndbeyond_image_scraper\listes\$livre.txt"))) { $e.liste = 'fournie' }
            }
        }
        $r.sources += $e
    }
    # Le journal : ce que l'import a affiché après son repère, sans l'en-tête ni le pied de la transcription de PowerShell.
    if (Test-Path $journal) {
        $lignes = @(Get-Content $journal -Encoding UTF8 -ErrorAction SilentlyContinue)
        $debut = [Array]::LastIndexOf($lignes, '=== Import des images ===')
        # La transcription recopie aussi les erreurs rattrapées (« PS>Erreur de terminaison… », jusqu'à « » » : la page 404
        # entière d'un hébergeur) : l'import les dit déjà en une ligne (« échec (404) : … »).
        $gardees = New-Object System.Collections.ArrayList
        $dansErreur = $false
        if ($debut -ge 0 -and $debut -lt $lignes.Count - 1) {
            foreach ($l in $lignes[($debut + 1)..($lignes.Count - 1)]) {
                if ($l -match '^PS>(Erreur de terminaison|TerminatingError)') { $dansErreur = $true; continue }
                if ($dansErreur) { if ($l -match '^\s*[»"]\s*$') { $dansErreur = $false }; continue }
                if ($l.Trim() -and $l -notmatch '^\*{10}' -and $l -notmatch '^(Fin de la transcription|Windows PowerShell transcript end|Heure de fin|End time)') { [void]$gardees.Add([string]$l) }
            }
        }
        $r.journal = @($gardees | Select-Object -Last 80)
    }
    return Repondre $ctx 200 $utf8.GetBytes((ConvertTo-Json -Compress -Depth 4 -InputObject $r)) $types['.json']
}

# <campagne>/ajout-images.json : ajouter des images à la bibliothèque de la campagne depuis la page (widget Images,
# « Ajouter des images », app/ajout-images.js). GET : { bibliotheque, en_cours, dossiers } (dossiers : ceux de premier niveau,
# un par source). POST ?chemin=<Source/…/fichier.ext> (le corps : le fichier) : l'écrit dans la bibliothèque, jamais hors
# d'elle, dans le dossier d'une source (deux niveaux au moins), seulement une image JPEG, PNG ou WebP (vérifiée sur ses
# premiers octets) de 50 Mo au plus ; un fichier du même nom et différent est gardé, le nouveau prend « (2) ». Renvoie
# { chemin, deja } (deja : le même fichier était déjà là). POST ?indexer=1 : réindexe la bibliothèque (attend la fin).
$script:extensionsImages = @('.jpg', '.jpeg', '.png', '.webp')
function Ajout-Images($ctx, $camp) {
    if (-not $camp.id) { return Texte $ctx 403 "Pas de campagne." }
    $biblio = Bibliotheque-De $camp
    $enCours = $false
    $verrou = Join-Path $biblio '.import-en-cours'
    if (Test-Path $verrou) { try { ([IO.File]::Open($verrou, 'Open', 'ReadWrite', 'None')).Dispose() } catch { $enCours = $true } }
    $req = $ctx.Request
    if ($req.HttpMethod -eq 'GET') {
        $dossiers = @()
        if (Test-Path $biblio -PathType Container) { $dossiers = @(Get-ChildItem $biblio -Directory | Where-Object { -not $_.Name.StartsWith('.') } | Sort-Object Name | ForEach-Object { $_.Name }) }
        return Repondre $ctx 200 $utf8.GetBytes((ConvertTo-Json -Compress -InputObject ([ordered]@{ bibliotheque = $biblio; en_cours = $enCours; dossiers = $dossiers }))) $types['.json']
    }
    if ($req.HttpMethod -ne 'POST') { return Texte $ctx 405 'Méthode non prise en charge.' }
    if (-not (Bibliotheque-Valide $racine $biblio)) { return Texte $ctx 409 "Bibliothèque refusée : $biblio (poste.json)." }
    if ($enCours) { return Texte $ctx 409 "Un import des images est en cours : attendez qu'il se termine (fenêtre Campagne, onglet « Images »)." }
    # Paramètres lus dans l'adresse brute, en UTF-8 : QueryString de HttpListener décode les accents dans la page de code du système.
    $q = @{}
    $brut = ($req.RawUrl -split '\?', 2)[1]
    if ($brut) { foreach ($p in $brut -split '&') { $kv = $p -split '=', 2; $q[[Uri]::UnescapeDataString($kv[0])] = $(if ($kv.Count -gt 1) { [Uri]::UnescapeDataString($kv[1].Replace('+', ' ')) } else { '' }) } }
    if ($q['indexer']) {
        $indexeur = Join-Path $racine 'scripts\indexer-images\indexer-images.ps1'
        $p = Start-Process powershell -WindowStyle Hidden -Wait -PassThru -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$indexeur`"", '-Bibliotheque', "`"$biblio`"", '-Silencieux'
        if ($p.ExitCode) { return Texte $ctx 500 "L'indexation a échoué (code $($p.ExitCode)) : lancez « outils/Indexer les images.cmd » pour voir l'erreur." }
        Write-Host ("  {0:HH:mm:ss}  bibliothèque réindexée ({1})" -f (Get-Date), $camp.id) -ForegroundColor DarkCyan
        return Texte $ctx 204 ''
    }
    # Le chemin : des noms simples, sans « . » en tête (ni « .. », ni .miniatures), dans le dossier d'une source.
    $segments = @(([string]$q['chemin']).Split('/') | ForEach-Object { $_.Trim() })
    if ($segments.Count -lt 2 -or $segments.Count -gt 8) { return Texte $ctx 400 "Chemin refusé : « Source/fichier.png » attendu." }
    foreach ($s in $segments) {
        if (-not $s -or $s.StartsWith('.') -or $s.Length -gt 150 -or $s -match '[\\:*?"<>|\x00-\x1f]') { return Texte $ctx 400 "Nom refusé : « $s »." }
    }
    $ext = [IO.Path]::GetExtension($segments[-1]).ToLowerInvariant()
    if ($script:extensionsImages -notcontains $ext) { return Texte $ctx 415 "Type refusé : $($segments[-1]) (JPEG, PNG ou WebP seulement)." }
    if ($req.ContentLength64 -le 0) { return Texte $ctx 400 "Fichier vide." }
    if ($req.ContentLength64 -gt 50MB) { return Texte $ctx 413 "Image trop grosse : 50 Mo au plus." }
    $ms = New-Object IO.MemoryStream
    $req.InputStream.CopyTo($ms); $req.InputStream.Close()
    $octets = $ms.ToArray()
    if ($octets.Length -ne $req.ContentLength64) { return Texte $ctx 400 "Fichier incomplet." }
    $ascii = { param($de, $n) [Text.Encoding]::ASCII.GetString($octets, $de, $n) }
    $estImage = $octets.Length -gt 12 -and (
        ($octets[0] -eq 0xFF -and $octets[1] -eq 0xD8 -and $octets[2] -eq 0xFF) -or
        ($octets[0] -eq 0x89 -and (& $ascii 1 3) -eq 'PNG') -or
        ((& $ascii 0 4) -eq 'RIFF' -and (& $ascii 8 4) -eq 'WEBP'))
    if (-not $estImage) { return Texte $ctx 415 "$($segments[-1]) n'est pas une image JPEG, PNG ou WebP." }
    $base = [IO.Path]::GetFullPath($biblio).TrimEnd('\')
    $cible = [IO.Path]::GetFullPath((Join-Path $base ($segments -join '\')))
    if (-not $cible.StartsWith($base + '\', [StringComparison]::OrdinalIgnoreCase)) { return Texte $ctx 403 'Hors de la bibliothèque.' }
    $dossier = Split-Path $cible -Parent
    New-Item -ItemType Directory -Force $dossier | Out-Null
    $deja = $false
    $nom = [IO.Path]::GetFileNameWithoutExtension($cible); $n = 1
    $md5 = [Security.Cryptography.MD5]::Create()
    $empreinte = [Convert]::ToBase64String($md5.ComputeHash($octets))
    while (Test-Path $cible) {
        if ((Get-Item $cible).Length -eq $octets.Length -and [Convert]::ToBase64String($md5.ComputeHash([IO.File]::ReadAllBytes($cible))) -eq $empreinte) { $deja = $true; break }
        $n++
        $cible = Join-Path $dossier "$nom ($n)$ext"
    }
    if (-not $deja) {
        $tmp = "$cible.envoi"
        [IO.File]::WriteAllBytes($tmp, $octets)
        Move-Item -Force $tmp $cible
    }
    $rel = 'images-library/' + ($cible.Substring($base.Length + 1) -replace '\\', '/')
    return Repondre $ctx 200 $utf8.GetBytes((ConvertTo-Json -Compress -InputObject ([ordered]@{ chemin = $rel; deja = $deja }))) $types['.json']
}

function Servir($ctx) {
    $req = $ctx.Request
    $chemin = [Uri]::UnescapeDataString($req.Url.AbsolutePath).TrimStart('/')
    $liste = Campagnes
    if ($chemin -eq '') { $chemin = if ($liste.Count) { 'accueil.html' } else { 'index.html' } }
    if ($chemin -eq 'campagnes.json') {
        if ($req.HttpMethod -eq 'POST') { return Creer-Campagne $ctx $liste }
        return Repondre $ctx 200 $utf8.GetBytes((Liste-Campagnes $liste)) $types['.json']
    }
    if ($chemin -eq 'chartes.json') { return Repondre $ctx 200 $utf8.GetBytes((Liste-Chartes)) $types['.json'] }
    if ($chemin -eq 'version.json') { return Repondre $ctx 200 $utf8.GetBytes($script:version) $types['.json'] }

    # La campagne : le premier segment de l'adresse, sinon celle par défaut.
    $morceaux = $chemin -split '/', 2
    if ($liste.Contains($morceaux[0])) {
        $camp = $liste[$morceaux[0]]
        if ($morceaux.Count -eq 1) { return Rediriger $ctx "/$($camp.id)/" }   # sans « / » final, les adresses relatives tomberaient à côté
        $chemin = $morceaux[1]
        if ($chemin -eq '') { $chemin = 'index.html' }
    } else { $camp = Campagne-Defaut $liste }
    $entree = ($chemin -split '/', 2)[0]
    if ($chemin -eq 'import-wiki.json') { return Import-Wiki $ctx $camp }
    if ($chemin -eq 'import-images.json') { return Import-Images $ctx $camp }
    if ($chemin -eq 'ajout-images.json') { return Ajout-Images $ctx $camp }

    # Écriture : seulement etat/<nom>.json, dans la campagne, et son manifeste (fenêtre Campagne)
    if ($req.HttpMethod -eq 'PUT') {
        if ($chemin -eq 'manifeste.json') { return Ecrire-Manifeste $ctx $camp }
        if ($chemin -notmatch '^etat/([a-z0-9][a-z0-9-]{0,63})\.json$') { return Texte $ctx 403 "Écriture refusée : seul etat/<nom>.json est accepté." }
        $nom = $Matches[1]
        $dossierEtat = Join-Path (Dossier-Propre $camp 'etat') 'etat'
        New-Item -ItemType Directory -Force -Path $dossierEtat | Out-Null
        $lecteur = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
        $json = $lecteur.ReadToEnd(); $lecteur.Close()
        if ($json.Length -gt 5MB) { return Texte $ctx 413 "Fichier d'état trop gros (5 Mo au plus)." }
        try { $null = $json | ConvertFrom-Json } catch { return Texte $ctx 400 "JSON invalide : $($_.Exception.Message)" }
        $cible = Join-Path $dossierEtat "$nom.json"
        if (Test-Path $cible) {
            $jour = Join-Path $dossierEtat ('sauvegardes\' + (Get-Date -Format 'yyyy-MM-dd'))
            $copie = Join-Path $jour "$nom.json"
            if (-not (Test-Path $copie)) { New-Item -ItemType Directory -Force -Path $jour | Out-Null; Copy-Item $cible $copie }
        }
        $tmp = "$cible.tmp"
        [IO.File]::WriteAllText($tmp, $json, $utf8)
        Move-Item -Force $tmp $cible
        return Texte $ctx 204 ''
    }
    if ($req.HttpMethod -ne 'GET' -and $req.HttpMethod -ne 'HEAD') { return Texte $ctx 405 'Méthode non prise en charge.' }

    # Lecture : tout fichier sous la racine, sans sortir du dossier ; images-library/ est la bibliothèque de la campagne
    # (Bibliotheque-De) ; les entrées propres viennent du dossier de la campagne
    $base = $racine
    if ($entree -eq 'images-library') {
        $base = Bibliotheque-De $camp
        $chemin = $chemin.Substring(14).TrimStart('/')
    }
    elseif ($propres -contains $entree) { $base = Dossier-Propre $camp $entree }
    $complet = [IO.Path]::GetFullPath((Join-Path $base $chemin))
    if (-not ($complet + '\').StartsWith($base.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { return Texte $ctx 403 'Hors du dossier.' }
    if (Test-Path $complet -PathType Container) { $complet = Join-Path $complet 'index.html' }
    if (-not (Test-Path $complet -PathType Leaf)) { return Texte $ctx 404 "Introuvable : $chemin" }
    $ext = [IO.Path]::GetExtension($complet).ToLowerInvariant()
    $type = $types[$ext]; if (-not $type) { $type = 'application/octet-stream' }
    Repondre $ctx 200 ([IO.File]::ReadAllBytes($complet)) $type
}

$ecoute = New-Object Net.HttpListener
$adresse = "http://localhost:$Port/"
$ecoute.Prefixes.Add($adresse)
try { $ecoute.Start() } catch {
    Write-Host "Impossible d'ouvrir le port $Port : $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Un autre gestionnaire tourne peut-être déjà sur ce port. Sinon, choisissez-en un autre (pas 8736, l'assistant de règles) : `"port`": 8740 dans poste.json, ou .\lancer.ps1 -Port 8740"
    exit 1
}
Write-Host ''
Write-Host '  Gestionnaire de campagne' -ForegroundColor Magenta
Write-Host "  $adresse" -ForegroundColor Cyan
foreach ($c in (Campagnes).Values) {
    $titre = if ($c.manifeste.titre) { $c.manifeste.titre } else { $c.id }
    Write-Host ("    {0,-40} {1}{2}/" -f $titre, $adresse, $c.id) -ForegroundColor DarkCyan
}
Write-Host '  Ctrl+C pour arrêter.' -ForegroundColor DarkGray
Write-Host ''
if (-not $SansNavigateur) { Start-Process $adresse }

# Index des bibliothèques d'images du poste (widget Images), en arrière-plan : seules les images nouvelles sont traitées.
$indexeur = Join-Path $racine 'scripts\indexer-images\indexer-images.ps1'
if ((Test-Path $indexeur) -and (Bibliotheques-Existantes $racine $poste).Count) {
    Start-Process powershell -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$indexeur`"", '-Silencieux'
}

# Service de règles (widget Règles), s'il est installé sur ce poste (« outils/Installer l'assistant de règles.cmd ») : il lance
# lui-même son instance d'Ollama. Arrêté avec le gestionnaire (Ctrl+C) ; déjà lancé, le second s'arrête de lui-même.
$regles = $null
$dossierRegles = Join-Path $racine 'regles'
$uv = Get-Command uv -ErrorAction SilentlyContinue
if ($uv -and (Test-Path (Join-Path $dossierRegles '.venv')) -and (Test-Path (Join-Path $dossierRegles 'index\manifeste.json'))) {
    $regles = Start-Process $uv.Source -ArgumentList 'run', '--quiet', 'serveur.py' -WorkingDirectory $dossierRegles -WindowStyle Hidden -PassThru
    Write-Host '  Service de règles lancé (widget Règles).' -ForegroundColor DarkGray
}

try {
    while ($ecoute.IsListening) {
        $attente = $ecoute.BeginGetContext($null, $null)
        while (-not $attente.AsyncWaitHandle.WaitOne(300)) { }   # boucle courte : Ctrl+C reste possible
        $ctx = $ecoute.EndGetContext($attente)
        try { Servir $ctx }
        catch {
            Write-Host "Erreur : $($_.Exception.Message)" -ForegroundColor Red
            try { Texte $ctx 500 "Erreur du serveur : $($_.Exception.Message)" } catch { }
        }
        if ($ctx.Request.HttpMethod -eq 'PUT') { Write-Host ("  {0:HH:mm:ss}  enregistré  {1}" -f (Get-Date), $ctx.Request.Url.AbsolutePath) -ForegroundColor DarkGray }
    }
} finally {
    $ecoute.Stop(); $ecoute.Close()
    # Tout l'arbre : uv, le serveur Python et son Ollama.
    if ($regles -and -not $regles.HasExited) { & taskkill.exe /T /F /PID $regles.Id 2>&1 | Out-Null }
}
