// Extension « The Screen · relevé D&D Beyond » : tâche de fond.
// Toutes les 20 s, si le gestionnaire répond : lit les fiches de la campagne avec la session D&D Beyond du navigateur,
// les résume (resumer.js, le même module que le gestionnaire) et écrit etat/beyond.json par le serveur local (PUT).
// Le badge de l'icône affiche le temps écoulé depuis le dernier relevé réussi.

import { resumer, resumerGroupe, detailler, texte, OBJET_EPUISEMENT_ID, OBJET_ENCOMBRE_ID, OBJET_LOURD_ID, OBJET_LOURD_ANCIEN_ID, OBJET_ENCOMBRE_ANCIEN_ID } from './resumer.js';

const PERIODE_MS = 20000;   // entre deux relevés (depuis 1.18.0 ; 30 s avant) : un minuteur de la tâche de fond, que le badge tient éveillée
const PERIODE_MIN = 0.5;    // 30 s, le minimum de chrome.alarms : le filet, qui réveille la tâche de fond si Chrome l'a arrêtée
// La ligne que le MJ met dans les notes publiques de sa campagne pour les extensions des joueurs (formats/note-compagnon.md).
const LIGNE_BANDEAU = /\[\s*Bandeau\s*\(\s*MJ\s*\)\s*:[^\]\n]*\]/iu;
const REGLAGES = { gestionnaire: 'http://localhost:8735', actif: true, fiche: '' };
// Couleurs du badge (API Chrome : valeurs fixes), reprises de design-system/tokens.json, thème Nuit.
const COULEURS = { ok: '#4de8ff', vieux: '#ffb23e', erreur: '#ff2d6f', arret: '#aca2b8' };
const API = 'https://character-service.dndbeyond.com/character/v5/character/';

let enCours = null;
let dernierLance = 0;   // quand le dernier relevé est parti

// Jeton de session D&D Beyond (cookies du navigateur), ou null. Gardé jusqu'à une minute avant son expiration
// (le widget Combat relit sa rencontre toutes les 5 s).
let jetonGarde = null;   // { jeton, jusqua }
async function jetonBeyond() {
  if (jetonGarde && Date.now() < jetonGarde.jusqua) return jetonGarde.jeton;
  try {
    const r = await fetch('https://auth-service.dndbeyond.com/v1/cobalt-token', { method: 'POST', credentials: 'include' });
    const j = r.ok ? await r.json() : null;
    jetonGarde = j?.token ? { jeton: j.token, jusqua: Date.now() + Math.max(0, (j.ttl || 300) - 60) * 1000 } : null;
    return jetonGarde?.jeton || null;
  } catch { return null; }   // hors ligne
}

async function lire() {
  const { reglages, dernier } = await chrome.storage.local.get(['reglages', 'dernier']);
  return { reglages: { ...REGLAGES, ...reglages }, dernier: dernier || null };
}

async function noter(dernier) {
  await chrome.storage.local.set({ dernier });
  await badge();
}

// ───── Relevé ─────

function relever() {
  dernierLance = Date.now();
  enCours ||= faireReleve().finally(() => { enCours = null; });
  return enCours;
}

async function faireReleve() {
  const { reglages, dernier } = await lire();
  if (!reglages.actif) return badge();
  const base = reglages.gestionnaire.replace(/\/+$/, '');
  const garder = { quand: dernier?.quand || null, fiches: dernier?.fiches || [] };

  // 1. Le gestionnaire tourne-t-il ? Son état donne aussi les fiches déjà connues.
  let etat;
  try {
    const r = await fetch(`${base}/etat/beyond.json`, { cache: 'no-store' });
    etat = r.ok ? await r.json() : r.status === 404 ? { schema: 1, campagne: null, fiches: {} } : null;
    if (!etat) throw new Error(`réponse ${r.status}`);
  } catch (e) {
    return noter({ ...garder, statut: 'gestionnaire', message: `Gestionnaire injoignable sur ${base} : lancez lancer.ps1.`, essai: Date.now() });
  }
  const departs = new Set(Object.keys(etat.fiches || {}));
  try {
    const p = await fetch(`${base}/data/personnages.json`, { cache: 'no-store' }).then(r => (r.ok ? r.json() : null));
    for (const x of p?.personnages || []) {
      const id = String(x.liens?.feuille || '').match(/characters\/(\d+)/)?.[1];
      if (id) departs.add(id);
    }
  } catch { /* facultatif */ }
  if (/^\d+$/.test(reglages.fiche)) departs.add(reglages.fiche);
  if (!departs.size) {
    return noter({ ...garder, statut: 'config', message: 'Aucune fiche connue : indiquez l\'identifiant d\'une fiche de la campagne (le nombre à la fin de son adresse).', essai: Date.now() });
  }

  // 2. Jeton de session D&D Beyond (cookies du navigateur).
  const jeton = await jetonBeyond();
  if (!jeton) {
    return noter({ ...garder, statut: 'session', message: 'Pas de session D&D Beyond : connectez-vous sur dndbeyond.com dans ce navigateur.', essai: Date.now() });
  }

  // 3. Fiches : une fiche connue donne la liste des personnages assignés de sa campagne.
  const brutes = [], erreurs = [];
  const lireFiche = async id => {
    try {
      const j = await fetch(API + id, { headers: { Authorization: 'Bearer ' + jeton } }).then(r => r.json());
      if (j?.data?.id) brutes.push(j.data);
      else erreurs.push(`${id} : ${j?.data?.serverMessage || j?.message || 'illisible'}`);
    } catch (e) { erreurs.push(`${id} : ${e.message}`); }
  };
  let premier = null;
  for (const id of departs) { await lireFiche(id); if (brutes.length) { premier = id; break; } }
  if (!brutes.length) return noter({ ...garder, statut: 'erreur', message: 'Aucune fiche lisible. ' + erreurs.join(' · '), essai: Date.now() });
  erreurs.length = 0;
  const equipe = (brutes[0].campaign?.characters || []).filter(c => c.isAssigned).map(c => String(c.characterId));
  await Promise.all((equipe.length ? equipe : [...departs]).filter(id => id !== premier).map(lireFiche));

  // 3 bis. Règles des fiches, selon les options de la campagne (etat/campagne.json, `regles_fiches`, fenêtre Campagne du
  //        gestionnaire ; voir plus bas) : réglages imposés aux fiches (encombrement, homebrew, poids des pièces) et objets
  //        d'état tenus à jour (« Exhaustion Level », « Encumbered », « Heavily Encumbered »). Une fiche corrigée est relue,
  //        pour que la suite et le résumé partent à jour. Ce qui bloque part en alerte dans beyond.json.
  const options = await optionsFiches(base);
  const notesEpuisement = [], alertes = [];
  const relire = async i => { try { const j = await appelBeyond(API + brutes[i].id); if (j?.data?.id) brutes[i] = j.data; } catch { /* le relevé suivant la reprendra */ } return brutes[i]; };
  // Chaque objet d'état activé doit être dans la collection homebrew du MJ (son catalogue) : sans lui, D&D Beyond ne
  // l'ajoute à aucune fiche. Absent : une alerte, et aucun essai sur les fiches pour lui. Un objet abandonné (`ancien`) ne
  // fait que partir des fiches : pas besoin de la collection. Option décochée, les objets d'encombrement partent aussi
  // (`retireSansOption`) : avec la variante de la fiche, leur vitesse compterait deux fois.
  const actifs = [];
  for (const objet of OBJETS_ETAT) {
    if (!options[objet.reglage]) { if (objet.retireSansOption) actifs.push({ ...objet, voulu: () => 0 }); continue; }
    if (objet.ancien) { actifs.push(objet); continue; }
    const present = await objetDansCollection(objet, brutes.find(b => b.campaign)?.campaign?.id);
    if (present === false) alertes.push(alerteCollection(objet));
    else actifs.push(objet);
  }
  for (const i of brutes.keys()) {
    let d = brutes[i];
    const reglage = await imposerReglages(d, options);
    if (reglage) notesEpuisement.push(reglage.texte);
    if (reglage?.erreur) alertes.push({ fiche: d.id, nom: String(d.name || d.id).trim(), joueur: null, type: 'reglage-refuse', texte: `D&D Beyond a refusé de régler la fiche (${reglage.erreur}). Réglez-la à la main dans « Preferences » ; nouvel essai toutes les 5 min.` });
    if (reglage?.change) d = await relire(i);   // la fiche tout juste réglée (pièces comptées) compte pour l'encombrement
    const notes = new Map();
    for (const objet of actifs) {
      const note = await synchroniserObjet(d, objet, options.regles);
      if (!note) continue;
      notes.set(objet.cle, note);
      notesEpuisement.push(note.texte);
      if (note.change) d = await relire(i);
    }
    for (const objet of actifs) alertes.push(...alertesObjet(d, objet, notes.get(objet.cle), options.regles));
    if (actifs.some(o => options[o.reglage]) && !options.homebrew && d.preferences?.useHomebrewContent === false) alertes.push(alerteHomebrew(d));
  }

  // 4. Détails à la demande (historique, espèce, dons…) : demandés par le gestionnaire (etat/beyond-demande.json)
  //    ou par la fenêtre de l'extension. Calculés sur les fiches déjà lues : aucune requête de plus.
  const demande = await fetch(`${base}/etat/beyond-demande.json`, { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  const { detailsDemandes } = await chrome.storage.local.get('detailsDemandes');
  const aTraiter = detailsDemandes || (demande?.details && (!demande.traite || demande.traite < demande.details));
  let messageDetails = '';
  if (aTraiter) {
    try {
      const details = { schema: 1, maj: new Date().toISOString(), fiches: Object.fromEntries(brutes.map(detailler).map(x => [x.id, x])) };
      const r = await fetch(`${base}/etat/beyond-details.json`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(details, null, 2) });
      if (!r.ok) throw new Error(await r.text());
      if (demande?.details) {
        await fetch(`${base}/etat/beyond-demande.json`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...demande, traite: details.maj, maj: details.maj }, null, 2) });
      }
      await chrome.storage.local.set({ detailsDemandes: false, detailsReleves: Date.now() });
      messageDetails = 'Détails relevés.';
    } catch (e) {
      messageDetails = `Détails non enregistrés : ${e.message}`;
    }
  }

  // 5. Écriture de etat/beyond.json.
  const resumes = brutes.map(d => resumer(d, options.regles));
  const camp = brutes.find(b => b.campaign)?.campaign;
  // Inventaire du groupe (party inventory) : sa bourse et ses objets ; sans réponse, celui d'avant reste.
  let groupe = etat.groupe || null;
  if (camp?.id) {
    try {
      const j = await fetch(`${PERSONNAGES}v5/party/inventory/${camp.id}`, { headers: { Authorization: 'Bearer ' + jeton } }).then(r => r.json());
      if (j?.data) groupe = resumerGroupe(j.data);
    } catch { /* garder l'ancien */ }
  }
  const valeur = {
    ...etat,
    schema: 1,
    // bandeau : la ligne « [Bandeau (MJ) : …] » lue dans les notes publiques de la campagne (null : pas de ligne ;
    // absent : la fiche ne porte pas ces notes), pour que le gestionnaire dise si elle est en place (depuis 1.18.0).
    campagne: camp ? { id: camp.id, nom: camp.name, ...('publicNotes' in camp ? { bandeau: LIGNE_BANDEAU.exec(texte(camp.publicNotes))?.[0] || null } : {}) } : etat.campagne || null,
    groupe,
    fiches: { ...(etat.fiches || {}), ...Object.fromEntries(resumes.map(r => [r.id, r])) },
    source: 'extension',
    extension: chrome.runtime.getManifest().version,   // le widget repère une extension à recharger
    extension_id: chrome.runtime.id,                   // le gestionnaire s'adresse directement à l'extension (rencontres)
    alertes,                                           // depuis 1.11.0 : ce que le MJ doit régler (widget Personnages)
    maj: new Date().toISOString(),
  };
  try {
    const r = await fetch(`${base}/etat/beyond.json`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(valeur, null, 2) });
    if (!r.ok) throw new Error(await r.text());
  } catch (e) {
    return noter({ ...garder, statut: 'erreur', message: `Écriture refusée par le gestionnaire : ${e.message}`, essai: Date.now() });
  }
  return noter({
    quand: Date.now(), essai: Date.now(), statut: erreurs.length ? 'partiel' : 'ok', message: [...erreurs, ...notesEpuisement, messageDetails].filter(Boolean).join(' · '),
    fiches: resumes.map(r => ({ nom: r.nom, pv: `${r.pv.actuels}/${r.pv.max}` })),
  });
}

// ───── Monstres de D&D Beyond, à la demande du gestionnaire (rencontres du MJ, widget Combat) ─────
// La page du gestionnaire (http://localhost, voir externally_connectable dans manifest.json) appelle
// chrome.runtime.sendMessage(<extension_id noté dans etat/beyond.json>, { type, … }) ; réponse { ok: true, resultat } ou { ok: false, erreur }.
// Avec la session du MJ, monster-service rend les fiches complètes des livres qu'il possède (sans elle, CA, PV et capacités
// sont vides pour les autres).

const MONSTRES = 'https://monster-service.dndbeyond.com/v1/Monster';
let configBeyond = null;

async function appelBeyond(url, { methode = 'GET', corps } = {}, nouvelEssai = true) {
  const jeton = await jetonBeyond();
  if (!jeton) throw new Error('Pas de session D&D Beyond : connectez-vous sur dndbeyond.com dans ce navigateur.');
  const r = await fetch(url, {
    method: methode,
    headers: { Authorization: 'Bearer ' + jeton, ...(corps ? { 'Content-Type': 'application/json' } : {}) },
    body: corps ? JSON.stringify(corps) : undefined,
  });
  if (r.status === 401 && nouvelEssai) { jetonGarde = null; return appelBeyond(url, { methode, corps }, false); }   // jeton expiré
  if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status} (${methode} ${new URL(url).pathname}).`);
  const t = await r.text();
  return t ? JSON.parse(t) : null;
}

async function lireMonstres(ids) {
  const propres = [...new Set((ids || []).map(Number).filter(n => Number.isInteger(n) && n > 0))].slice(0, 50);
  if (!propres.length) return [];
  // « ids=a&ids=b » : D&D Beyond refuse « ids=a,b » (400, relevé le 2026-10-23).
  return (await appelBeyond(`${MONSTRES}?${propres.map(id => `ids=${id}`).join('&')}`))?.data || [];
}

// Tous les monstres de quelques livres (sources : id de sources de D&D Beyond, comme le filtre « Source » de la page
// Monsters), en résumé léger pour la recherche du gestionnaire ; la fiche complète se lit ensuite par « monstres ».
// homebrew (depuis 1.11.0) : en plus, les monstres homebrew du MJ (sa collection), par une requête à part
// (`showHomebrew=t` sans livre : mêlé à un filtre de livre, D&D Beyond ne rend rien), marqués `homebrew`.
async function lireBestiaire(sources, homebrew = false) {
  const ids = [...new Set((sources || []).map(Number).filter(n => Number.isInteger(n) && n > 0))].slice(0, 30);
  const tous = new Map();
  const lire = async (filtre, maison) => {
    for (let skip = 0, garde = 0; garde < 60; garde++) {
      const q = new URLSearchParams({ search: '', skip: String(skip), take: '100', showHomebrew: maison ? 't' : 'f' });
      filtre.forEach(id => q.append('sources', String(id)));
      const j = await appelBeyond(`${MONSTRES}?${q}`);
      const page = Array.isArray(j?.data) ? j.data : [];
      const avant = tous.size;
      page.forEach(m => tous.set(m.id, {
        id: m.id, nom: String(m.name || '').trim(), fp: m.challengeRatingId, type: m.typeId, taille: m.sizeId,
        ca: m.armorClass || null, pv: m.averageHitPoints || null, source: m.sourceId, sources: (m.sources || []).map(s => s.sourceId),
        avatar: m.avatarUrl || null, image: m.largeAvatarUrl || null, legacy: !!m.isLegacy, legendaire: !!m.isLegendary,
        acces: j.accessType?.[m.id] ?? null, url: m.url || null, homebrew: !!m.isHomebrew,
      }));
      skip += page.length;
      if (!page.length || tous.size === avant || skip >= (j?.pagination?.total ?? 0)) break;
    }
  };
  if (ids.length) await lire(ids, false);
  if (homebrew) await lire([], true);
  return [...tous.values()];
}

// Dictionnaire de D&D Beyond (tailles, types, sens, dégâts…), pour lire les fiches de monstres. Public, gardé en mémoire.
async function lireConfig() {
  if (!configBeyond) {
    const r = await fetch('https://www.dndbeyond.com/api/config/json');
    if (!r.ok) throw new Error(`Dictionnaire de D&D Beyond illisible (${r.status}).`);
    const j = await r.json();
    const liste = (l, f) => (l || []).map(f);
    configBeyond = {
      tailles: liste(j.creatureSizes, x => ({ id: x.id, nom: x.name })),
      types: liste(j.monsterTypes, x => ({ id: x.id, nom: x.name })),
      alignements: liste(j.alignments, x => ({ id: x.id, nom: x.name })),
      mouvements: liste(j.movements, x => ({ id: x.id, nom: x.name })),
      sens: liste(j.senses, x => ({ id: x.id, nom: x.name })),
      carac: liste(j.stats, x => ({ id: x.id, cle: x.key })),
      etats: liste(j.conditions, x => ({ id: x.definition?.id, nom: x.definition?.name })),
      ajustements: liste(j.damageAdjustments, x => ({ id: x.id, nom: x.name, type: x.type })),
      puissances: liste(j.challengeRatings, x => ({ id: x.id, valeur: x.value, px: x.xp, maitrise: x.proficiencyBonus })),
      // Livres (depuis 1.8.0) : réglage des livres du gestionnaire (bouton Campagne). `partenaire` : catégorie d'un éditeur
      // partenaire (Partnered Content : MCDM, Kobold Press…), que D&D Beyond laisse masquer.
      sources: liste(j.sources, x => ({ id: x.id, sigle: x.name, titre: x.description, categorie: x.sourceCategoryId, publie: !!x.isReleased })),
      categories: liste(j.sourceCategories, x => ({ id: x.id, nom: x.name, partenaire: !!x.isHideable })),
    };
  }
  return configBeyond;
}

// ───── Objet personnalisé dans un inventaire D&D Beyond (bouton « Donner » d'une babiole) ─────
// Comme « Add Custom Item » de la fiche (Manage Inventory) : POST character/v5.1/custom/item, puis la note de l'objet
// (valeur NOTES, typeId 9) par PUT character/v5/custom/value, comme le fait la fiche. Dans l'inventaire du groupe
// (party) : conteneur de la campagne et partyId = l'id de la campagne ; la fiche d'un membre porte la requête.
// Relevé dans le code de la fiche (character-app, 2026-10-15).
const PERSONNAGES = 'https://character-service.dndbeyond.com/character/';
const CONTENEUR = { personnage: 1581111423, campagne: 618115330 };   // ContainerTypeEnum de la fiche
const VALEUR_NOTES = 9;

// Objet du catalogue de D&D Beyond (depuis 1.8.0, objets du gestionnaire) : comme « Add » de la boutique de la fiche
// (Manage Inventory), POST character/v5/inventory/item { characterId, equipment: [{ containerEntityId,
// containerEntityTypeId, entityId, entityTypeId, quantity }] } ; le conteneur dit la fiche ou le groupe (sans partyId).
// Relevé dans le code de la fiche (character-app, 2026-10-21).
// m : { personnage (id de la fiche), groupe (booléen), campagne (id, pour le groupe), nom, description, note, quantite,
// poids (livres, objet personnalisé, depuis 1.8.0), definition ({ id, type } : objet du catalogue, depuis 1.8.0),
// cout (po, objet personnalisé, depuis 1.9.0), nomBeyond (nom de l'objet du catalogue dans l'inventaire, depuis 1.9.0) }.
async function ajouterObjet(m) {
  const perso = Number(m.personnage);
  const campagne = m.groupe ? Number(m.campagne) : null;
  const nom = String(m.nom || '').trim().slice(0, 255);
  if (!Number.isInteger(perso) || perso <= 0) throw new Error('Fiche D&D Beyond inconnue.');
  if (m.groupe && !(Number.isInteger(campagne) && campagne > 0)) throw new Error('Campagne D&D Beyond inconnue (inventaire du groupe).');
  const def = m.definition ? { id: Number(m.definition.id), type: Number(m.definition.type) } : null;
  if (def && !(Number.isInteger(def.id) && def.id > 0 && Number.isInteger(def.type) && def.type > 0)) throw new Error('Objet de D&D Beyond inconnu.');
  if (!def && !nom) throw new Error('Objet sans nom.');
  const note = String(m.note || '').trim();
  const quantite = Number.isInteger(m.quantite) && m.quantite > 0 ? m.quantite : 1;
  const conteneur = { containerEntityId: campagne || perso, containerEntityTypeId: campagne ? CONTENEUR.campagne : CONTENEUR.personnage };
  // Poids (livres) et coût (po) d'un objet personnalisé : entiers positifs ou nuls (D&D Beyond refuse les décimales).
  const entier = x => (x != null && x !== '' && Number.isFinite(Number(x)) && Number(x) >= 0 ? Math.round(Number(x)) : null);
  const r = def
    ? await appelBeyond(`${PERSONNAGES}v5/inventory/item`, { methode: 'POST', corps: {
      characterId: perso, equipment: [{ ...conteneur, entityId: def.id, entityTypeId: def.type, quantity: quantite }] } })
    : await appelBeyond(`${PERSONNAGES}v5.1/custom/item`, { methode: 'POST', corps: {
      characterId: perso, name: nom, description: String(m.description || '').trim(), notes: note || null,
      quantity: quantite, cost: entier(m.cout), weight: entier(m.poids),
      ...conteneur, partyId: campagne,
    } });
  verifier(r, 'l\'objet');
  const objet = (r?.data ?? r)?.addItems?.[0];
  if (!objet) throw new Error('D&D Beyond n\'a pas renvoyé l\'objet ajouté : vérifiez l\'inventaire.');
  let noteEcrite = !note;
  if (note) {
    try {
      await ecrireValeurObjet(perso, campagne, objet.id, objet.entityTypeId, VALEUR_NOTES, note);
      noteEcrite = true;
    } catch { /* l'objet est créé ; la note passée à la création suffit peut-être */ }
  }
  // Objet du catalogue, depuis 1.9.0 : son nom dans l'inventaire (le nom VF de la campagne), comme « Customize » → « Name »
  // de la fiche. Un échec laisse l'objet donné : nomEcrit faux, le gestionnaire le dit.
  const nomBeyond = def ? String(m.nomBeyond || '').trim().slice(0, 255) : '';
  let nomEcrit = !nomBeyond;
  if (nomBeyond) {
    try {
      await ecrireValeurObjet(perso, campagne, objet.id, objet.entityTypeId, VALEUR_NOM, nomBeyond);
      nomEcrit = true;
    } catch { /* gardé faux */ }
  }
  releverApres().catch(() => {});   // l'inventaire du gestionnaire (widget Personnages) suit sans attendre 20 s
  return { id: objet.id, entityTypeId: objet.entityTypeId, definitionId: objet.definition?.id ?? null, groupe: !!campagne, noteEcrite, nomEcrit };
}

// ───── Pièces (depuis 1.20.0, « Donner de l'or » du gestionnaire : récompenses des quêtes, butins des rencontres) ─────
// Comme « Adjust Coin » de la fiche : PUT character/v5/inventory/currency/transaction { characterId, destinationEntityId,
// destinationEntityTypeId, cp, sp, ep, gp, pp } ; les montants s'AJOUTENT à la bourse (une transaction, pas un total). La
// destination : la fiche (conteneur personnage) ou la bourse du groupe (conteneur campagne, la fiche d'un membre porte la
// requête). Relevé dans le code de la fiche (character-app, main.187aa7b7.js, 2026-11-12 : putCharacterInventoryCurrencyTransaction,
// currencyTransactionSet avec destinationEntityId et destinationEntityTypeId) ; pas encore essayé sur une vraie fiche.
// m : { personnage, groupe, campagne, pieces: { pc, pa, pe, po, pp } (entiers positifs) }.
const PIECES_BEYOND = { pc: 'cp', pa: 'sp', pe: 'ep', po: 'gp', pp: 'pp' };
async function donnerPieces(m) {
  const perso = Number(m.personnage);
  const campagne = m.groupe ? Number(m.campagne) : null;
  if (!Number.isInteger(perso) || perso <= 0) throw new Error('Fiche D&D Beyond inconnue.');
  if (m.groupe && !(Number.isInteger(campagne) && campagne > 0)) throw new Error('Campagne D&D Beyond inconnue (bourse du groupe).');
  const montants = { cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 };
  for (const [fr, en] of Object.entries(PIECES_BEYOND)) {
    const n = Number(m.pieces?.[fr] ?? 0);
    if (!Number.isInteger(n) || n < 0 || n > 1e7) throw new Error(`Montant refusé : ${m.pieces?.[fr]} ${fr}.`);
    montants[en] = n;
  }
  if (!Object.values(montants).some(Boolean)) throw new Error('Aucune pièce à donner.');
  const r = verifier(await appelBeyond(`${PERSONNAGES}v5/inventory/currency/transaction`, { methode: 'PUT', corps: {
    characterId: perso, destinationEntityId: campagne || perso, destinationEntityTypeId: campagne ? CONTENEUR.campagne : CONTENEUR.personnage, ...montants,
  } }), 'les pièces');
  releverApres().catch(() => {});   // la bourse du gestionnaire (widget Personnages) suit sans attendre 20 s
  return { groupe: !!campagne, bourse: r?.data ?? null };
}

// Une valeur personnalisée d'un objet d'inventaire (sa note, son nom) : PUT character/v5/custom/value, avec l'id de l'objet
// dans l'inventaire et son entityTypeId (les clés de la fiche) ; partyId pour un objet de l'inventaire du groupe.
const VALEUR_NOM = 8;   // NAME_OVERRIDE (CharacterValueTypeEnum de la fiche, character-app, relevé le 2026-10-21)
async function ecrireValeurObjet(perso, campagne, id, entityTypeId, typeId, valeur) {
  verifier(await appelBeyond(`${PERSONNAGES}v5/custom/value`, { methode: 'PUT', corps: {
    characterId: perso, typeId, value: valeur, notes: null, valueId: String(id), valueTypeId: String(entityTypeId),
    contextId: null, contextTypeId: null, partyId: campagne,
  } }), typeId === VALEUR_NOM ? 'le nom de l\'objet' : 'la valeur de l\'objet');
}

// m : { personnage (la fiche, ou celle d'un membre pour le groupe), groupe, campagne, objet (id dans l'inventaire), typeObjet
// (son entityTypeId ; relu dans l'inventaire s'il manque), nom (vide : le nom de D&D Beyond revient) }. Depuis 1.9.0 :
// renommer un objet déjà donné (bouton « Renommer sur D&D Beyond » d'un objet du gestionnaire).
async function renommerObjet(m) {
  const perso = Number(m.personnage);
  const campagne = m.groupe ? Number(m.campagne) : null;
  const id = Number(m.objet);
  if (!Number.isInteger(perso) || perso <= 0) throw new Error('Fiche D&D Beyond inconnue.');
  if (m.groupe && !(Number.isInteger(campagne) && campagne > 0)) throw new Error('Campagne D&D Beyond inconnue (inventaire du groupe).');
  if (!Number.isInteger(id) || id <= 0) throw new Error('Objet d\'inventaire inconnu.');
  let type = Number(m.typeObjet) || null;
  if (!type) {
    const liste = campagne
      ? (await appelBeyond(`${PERSONNAGES}v5/party/inventory/${campagne}`))?.data?.partyItems
      : (await appelBeyond(API + perso))?.data?.inventory;
    type = (liste || []).find(i => i.id === id)?.entityTypeId || null;
    if (!type) throw new Error('Objet introuvable dans l\'inventaire : retiré de la fiche ?');
  }
  const nom = String(m.nom || '').trim().slice(0, 255);
  const cle = { characterId: perso, typeId: VALEUR_NOM, valueId: String(id), valueTypeId: String(type), contextId: null, contextTypeId: null, partyId: campagne };
  verifier(await appelBeyond(`${PERSONNAGES}v5/custom/value`, nom
    ? { methode: 'PUT', corps: { ...cle, value: nom, notes: null } }
    : { methode: 'DELETE', corps: cle }), 'le nom de l\'objet');
  releverApres().catch(() => {});
  return { objet: id, type, nom };
}

// ───── Catalogue des objets de D&D Beyond (objets du gestionnaire, depuis 1.8.0) ─────
// Comme la boutique de la fiche (Manage Inventory) : GET character/v5.1/game-data/items?sharingSetting=2&campaignId=…,
// par pages de 1 000 (`page` à partir de 0 et `pageSize`, comme la fiche ; 1.8.0 commençait à 1 et sautait les 100 premiers
// objets) : équipement et objets magiques de tout ce que le compte du MJ a débloqué
// (livres, contenu partenaire, Drops) et les homebrews partagés dans la campagne. Gardé une heure en mémoire ; le
// gestionnaire garde le résumé léger un jour (et filtre par livres), les textes se demandent par « objets-fiches ».
let catalogue = null;   // { campagne, quand, parCle: Map("id:type" -> définition brute) }

async function lireCatalogue(campagneId) {
  const campagne = Number(campagneId) || null;
  if (catalogue && catalogue.campagne === campagne && Date.now() - catalogue.quand < 3600e3) return catalogue;
  const parCle = new Map();
  for (let page = 0; page < 20; page++) {
    const q = new URLSearchParams({ sharingSetting: '2', page: String(page), pageSize: '1000' });
    if (campagne) q.set('campaignId', String(campagne));
    const j = await appelBeyond(`${PERSONNAGES}v5.1/game-data/items?${q}`);
    const liste = Array.isArray(j?.data) ? j.data : [];
    const avant = parCle.size;
    liste.forEach(d => parCle.set(`${d.id}:${d.entityTypeId}`, d));
    if (!liste.length || parCle.size === avant || parCle.size >= (j?.pagination?.total ?? Infinity)) break;
  }
  if (!parCle.size) throw new Error('Catalogue d\'objets de D&D Beyond vide : session ou campagne à vérifier.');
  catalogue = { campagne, quand: Date.now(), parCle };
  return catalogue;
}

// Résumé léger d'un objet, pour la recherche du gestionnaire.
function resumerObjet(d) {
  const sources = (d.sources || []).map(s => s.sourceId).filter(Boolean);
  return {
    id: d.id, type: d.entityTypeId, nom: String(d.name || '').trim(), genre: d.filterType || d.type || null, sousType: d.subType || null,
    rarete: d.rarity || null, magique: !!d.magic, poids: d.weight ?? null, cout: d.cost ?? null, harmonisation: !!d.canAttune,
    sources, source: sources[0] ?? d.sourceId ?? null, homebrew: !!d.isHomebrew, legacy: !!d.isLegacy, avatar: d.avatarUrl || null,
    ajoutable: d.canBeAddedToInventory !== false, conteneur: !!d.isContainer, lot: d.bundleSize || 1,
    // Variante d'un objet générique (« Silvered Dagger » de « Silvered Weapon », qui ne s'ajoute pas) : l'id du générique.
    groupe: d.groupedId || null,
  };
}

// m : { campagne (id de la campagne D&D Beyond) } -> résumés de tous les objets.
async function lireObjets(m) {
  return [...(await lireCatalogue(m.campagne)).parCle.values()].map(resumerObjet);
}

// m : { campagne, cles: ["id:type", …] } (50 au plus) -> le résumé et le texte de chacun (description HTML de D&D Beyond,
// harmonisation, propriétés d'arme), ou null s'il n'est plus au catalogue.
async function lireFichesObjets(m) {
  const c = await lireCatalogue(m.campagne);
  return (m.cles || []).slice(0, 50).map(String).map(cle => {
    const d = c.parCle.get(cle);
    if (!d) return null;
    return {
      ...resumerObjet(d), cle, description: d.description || '', harmonisationTexte: d.attunementDescription || '',
      typeLibelle: d.type || null, ca: d.armorClass || null, degats: d.damage?.diceString || null, degatsType: d.damageType || null,
      proprietes: (d.properties || []).map(p => p.name).filter(Boolean), image: d.largeAvatarUrl || d.avatarUrl || null, consommable: !!d.isConsumable,
    };
  });
}

// ───── États et inspiration héroïque d'un héros (widget Personnages) ─────
// Comme la fiche : PUT character/v5/condition { characterId, id, level, totalHp } pose un état (ou change le niveau
// d'Épuisement), DELETE character/v5/condition { characterId, id } le retire, PUT character/v5/character/inspiration
// { characterId, inspiration } donne ou retire l'inspiration héroïque. Relevé dans le code de la fiche (character-app
// 1.72.9, 2026-10-20). Seules les fiches déjà relevées (etat/beyond.json) sont écrites ; un relevé suit aussitôt, pour que
// le gestionnaire voie le changement.
const ETAT_EPUISEMENT = 4, EPUISEMENT_MAX = 6, NB_ETATS = 15;

async function ficheConnue(m) {
  const perso = Number(m.personnage);
  if (!Number.isInteger(perso) || perso <= 0) throw new Error('Fiche D&D Beyond inconnue.');
  const { reglages } = await lire();
  const base = reglages.gestionnaire.replace(/\/+$/, '');
  const etat = await fetch(`${base}/etat/beyond.json`, { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  if (!etat?.fiches?.[perso]) throw new Error('Cette fiche n\'est pas dans le relevé de la campagne : rien n\'a été écrit.');
  return perso;
}

const verifier = (r, quoi) => {
  if (r && r.success === false) throw new Error(`D&D Beyond a refusé ${quoi}${r.message ? ` : ${r.message}` : '.'}`);
  return r;
};

// Un relevé déjà en cours a pu lire la fiche avant l'écriture : on l'attend, puis on relève de nouveau.
async function releverApres() {
  if (enCours) await enCours.catch(() => {});
  await relever();
}

// m : { personnage (id de la fiche), id (état, 1 à 15), niveau (Épuisement, 1 à 6), retirer (booléen) }.
async function changerEtat(m) {
  const perso = await ficheConnue(m);
  const id = Number(m.id);
  if (!Number.isInteger(id) || id < 1 || id > NB_ETATS) throw new Error('État inconnu.');
  if (m.retirer) {
    verifier(await appelBeyond(`${PERSONNAGES}v5/condition`, { methode: 'DELETE', corps: { characterId: perso, id } }), 'de retirer l\'état');
  } else {
    const niveau = id === ETAT_EPUISEMENT ? Math.min(EPUISEMENT_MAX, Math.max(1, Math.round(Number(m.niveau) || 1))) : null;
    const brute = await appelBeyond(API + perso);
    if (!brute?.data?.id) throw new Error('Fiche D&D Beyond illisible : rien n\'a été écrit.');
    verifier(await appelBeyond(`${PERSONNAGES}v5/condition`, { methode: 'PUT', corps: { characterId: perso, id, level: niveau, totalHp: resumer(brute.data).pv.max } }), 'l\'état');
  }
  await releverApres();
  return { personnage: perso, id, retire: !!m.retirer };
}

// m : { personnage, valeur (booléen) }.
async function changerInspiration(m) {
  const perso = await ficheConnue(m);
  verifier(await appelBeyond(`${PERSONNAGES}v5/character/inspiration`, { methode: 'PUT', corps: { characterId: perso, inspiration: !!m.valeur } }), 'l\'inspiration');
  await releverApres();
  return { personnage: perso, inspiration: !!m.valeur };
}

// ───── Objets d'état homebrew du MJ (Épuisement depuis 1.10.0, encombrement depuis 1.12.0, à deux objets depuis 1.16.0) ─────
// D&D Beyond pose l'Épuisement sans en appliquer les malus (2026-10-21), et son encombrement n'a que des seuils fixes
// (variante : 5 et 10 × For). Le MJ a créé des objets homebrew qui portent les malus :
// - « Exhaustion Level » (https://www.dndbeyond.com/magic-items/11959069-exhaustion-level : −2 aux tests, sauvegardes et
//   attaques, −5 ft), un exemplaire par niveau d'Épuisement ;
// - « Encumbered » (https://www.dndbeyond.com/magic-items/12142792-encumbered) et « Heavily Encumbered »
//   (https://www.dndbeyond.com/magic-items/12140026-heavily-encumbered), les malus de l'encombrement et de l'encombrement
//   lourd, vitesse comprise : un seul des deux, selon l'état calculé par le relevé avec les seuils de la campagne
//   (`encombrement` de resumer.js), aucun sinon. La fiche est en « Use Encumbrance », qui ne touche pas à la vitesse.
// - l'ancien « Heavily Encumbered » (12111887, de 1.12.0 à 1.15.1, avec la variante de la fiche) et le premier
//   « Encumbered » (12140046, 1.16.0, ses malus ne s'appliquaient pas) : retirés des fiches.
// À chaque relevé, chaque fiche doit en avoir autant, équipés, qu'il en faut (état posé par le gestionnaire ou le joueur,
// retiré par un repos long, inventaire allégé) : l'extension ajoute ce qui manque, retire le surplus (ceux qui ne sont pas
// équipés d'abord) et équipe le reste. Comme la fiche : POST character/v5/inventory/item, DELETE …/inventory/item
// { characterId, id, removeContainerContents }, PUT …/inventory/item/equipped { characterId, id, value } (relevés dans le
// code de la fiche, character-app, le 2026-10-21). Après un échec, la fiche est laissée cinq minutes, pour ne pas
// insister à chaque relevé. Chaque objet dépend d'une option (`reglage`, voir optionsFiches) et doit être dans la
// collection homebrew du MJ. voulu(d, regles) : le nombre d'exemplaires voulus sur la fiche brute d.
const etatEncombrement = (d, regles) => resumer(d, regles).encombrement?.etat;
const OPTION_ENCOMBREMENT = 'Encombrement par les objets homebrew';
const OBJETS_ETAT = [
  { cle: 'epuisement', reglage: 'epuisement', id: OBJET_EPUISEMENT_ID, type: 112130694, nom: 'Exhaustion Level', url: 'dndbeyond.com/magic-items/11959069-exhaustion-level',
    option: 'Épuisement par l\'objet homebrew', effet: 'les malus de l\'Épuisement',
    voulu: d => (d.conditions || []).find(c => c.id === ETAT_EPUISEMENT)?.level || 0,
    etat: n => `Épuisement ${n}` },
  { cle: 'encombre', reglage: 'encombrement', retireSansOption: true, id: OBJET_ENCOMBRE_ID, type: 112130694, nom: 'Encumbered', url: 'dndbeyond.com/magic-items/12142792-encumbered',
    option: OPTION_ENCOMBREMENT, effet: 'les malus de l\'encombrement',
    voulu: (d, regles) => (etatEncombrement(d, regles) === 'encombre' ? 1 : 0),
    etat: n => (n ? 'Encombré' : 'Pas encombré') },
  { cle: 'lourd', reglage: 'encombrement', retireSansOption: true, id: OBJET_LOURD_ID, type: 112130694, nom: 'Heavily Encumbered', url: 'dndbeyond.com/magic-items/12140026-heavily-encumbered',
    option: OPTION_ENCOMBREMENT, effet: 'les malus de l\'encombrement lourd',
    voulu: (d, regles) => (etatEncombrement(d, regles) === 'lourd' ? 1 : 0),
    etat: n => (n ? 'Lourdement encombré' : 'Pas lourdement encombré') },
  { cle: 'lourd-ancien', reglage: 'encombrement', ancien: true, retireSansOption: true, id: OBJET_LOURD_ANCIEN_ID, type: 112130694, nom: 'Heavily Encumbered (ancien)',
    voulu: () => 0, etat: () => 'Ancien objet d\'encombrement' },
  { cle: 'encombre-ancien', reglage: 'encombrement', ancien: true, retireSansOption: true, id: OBJET_ENCOMBRE_ANCIEN_ID, type: 112130694, nom: 'Encumbered (ancien)',
    voulu: () => 0, etat: () => 'Ancien objet d\'encombrement' },
];
const echecsEpuisement = new Map();   // « <id d'objet>:<id de fiche> » ou « pref:<id de fiche> » -> date du dernier échec

// ───── Options de la campagne pour les fiches (depuis 1.11.0) ─────
// etat/campagne.json du gestionnaire, `regles_fiches` (fenêtre Campagne, onglet « Fiches D&D Beyond ») :
// - `epuisement_homebrew` (vrai d'office) : tenir les objets « Exhaustion Level » ;
// - `encombrement_homebrew` (vrai d'office, depuis 1.12.0 ; deux objets depuis 1.16.0) : tenir les objets « Encumbered »
//   et « Heavily Encumbered » selon les seuils de la campagne, `encombrement_seuils` { encombre, lourd } (multiples de la
//   Force, 5 et 10 d'office, ceux de la variante) ; impose « Use Encumbrance » (`preferences.encumbranceType` 1, sans effet
//   sur la vitesse : ce sont les objets qui la réduisent) aux fiches qui ne l'ont pas (avant 1.16.0 : la variante, imposée
//   aussi par l'Épuisement) ;
// - `homebrew` (vrai d'office) : le contenu homebrew autorisé sur les fiches (`preferences.useHomebrewContent` vrai) ;
// - `pieces` (faux d'office) : les pièces comptent dans le poids porté, imposé aux fiches qui les ignorent
//   (`preferences.ignoreCoinWeight` faux).
// Comme la fiche (« Preferences ») : PUT character/v5/character/preferences { characterId, <réglage>: valeur } (relevé dans
// le code de la fiche, character-app, le 2026-10-21).
async function optionsFiches(base) {
  const c = await fetch(`${base}/etat/campagne.json`, { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  const r = c?.regles_fiches || {};
  const encombrement = r.encombrement_homebrew !== false;
  const multiple = (v, defaut) => (Number(v) > 0 ? Number(v) : defaut);
  const seuils = { encombre: multiple(r.encombrement_seuils?.encombre, 5), lourd: multiple(r.encombrement_seuils?.lourd, 10) };
  if (seuils.lourd <= seuils.encombre) seuils.lourd = seuils.encombre * 2;
  return { epuisement: r.epuisement_homebrew !== false, encombrement, pieces: r.pieces === true, homebrew: r.homebrew !== false,
    regles: encombrement ? { encombrement: seuils } : {} };   // pour resumer()
}

const ENCOMBREMENT_STANDARD = 1;   // « Use Encumbrance »
async function imposerReglages(d, options) {
  const p = d.preferences || {};
  const voulus = {
    ...(options.encombrement && p.encumbranceType !== ENCOMBREMENT_STANDARD ? { encumbranceType: ENCOMBREMENT_STANDARD } : {}),
    ...(options.pieces && p.ignoreCoinWeight !== false ? { ignoreCoinWeight: false } : {}),
    ...(options.homebrew && p.useHomebrewContent !== true ? { useHomebrewContent: true } : {}),
  };
  const cles = Object.keys(voulus);
  if (!cles.length || Date.now() - (echecsEpuisement.get('pref:' + d.id) || 0) < 300e3) return null;
  const nom = String(d.name || d.id).trim();
  const libelles = { encumbranceType: 'encombrement « Use Encumbrance »', ignoreCoinWeight: 'pièces comptées dans le poids', useHomebrewContent: 'contenu homebrew autorisé' };
  let change = false;
  try {
    for (const cle of cles) {
      verifier(await appelBeyond(`${PERSONNAGES}v5/character/preferences`, { methode: 'PUT', corps: { characterId: d.id, [cle]: voulus[cle] } }), `le réglage ${libelles[cle]}`);
      change = true;
    }
    return { change, texte: `${nom} : réglé sur ${cles.map(c => libelles[c]).join(' et ')}.` };
  } catch (e) {
    echecsEpuisement.set('pref:' + d.id, Date.now());
    return { change, erreur: e.message, texte: `${nom} : réglage pas appliqué (${e.message}) ; nouvel essai dans 5 min.` };
  }
}

// Un objet d'état est-il dans la collection homebrew du MJ ? Le catalogue (lireCatalogue, gardé une heure) le dit ; absent,
// le catalogue est relu au bout de 5 min (le MJ vient peut-être de l'ajouter). → true, false, ou null (catalogue
// illisible : on ne sait pas, rien n'est bloqué).
let controleCollection = 0;
async function objetDansCollection(objet, campagne) {
  try {
    let c = await lireCatalogue(campagne);
    const cle = `${objet.id}:${objet.type}`;
    if (!c.parCle.has(cle) && Date.now() - controleCollection > 300e3 && Date.now() - c.quand > 300e3) {
      controleCollection = Date.now();
      catalogue = null;
      c = await lireCatalogue(campagne);
    }
    return c.parCle.has(cle);
  } catch { return null; }
}
const alerteCollection = objet => ({ fiche: null, nom: null, joueur: null, type: `${objet.cle}-collection`, objet: objet.nom,
  texte: `L'objet homebrew « ${objet.nom} » n'est pas dans votre collection D&D Beyond : sans lui, l'extension ne peut pas l'ajouter aux fiches, et ${objet.effet} ne s'appliquent pas. Ajoutez-le à votre collection (${objet.url}, « Add to Collection »), ou décochez « ${objet.option} » dans la fenêtre Campagne (onglet « Fiches D&D Beyond »).` });

// Ce que le MJ doit régler lui-même pour un objet d'état sur une fiche : des exemplaires qui manquent encore (D&D Beyond a
// refusé de les ajouter). d : la fiche relue ; note : le résultat de synchroniserObjet() ; regles : celles de resumer().
function alertesObjet(d, objet, note, regles) {
  const voulu = objet.voulu(d, regles);
  const n = (d.inventory || []).filter(i => i.definition?.id === objet.id).length;
  if (n >= voulu) return [];
  const joueur = d.campaign?.characters?.find(c => c.characterId === d.id)?.username || d.username || null;
  const raison = note?.texte && /pas ajustés/.test(note.texte) ? ` (${note.texte.replace(/^.*?\(/, '').replace(/\) ;.*$/, '')})` : '';
  return [{ fiche: d.id, nom: String(d.name || d.id).trim(), joueur, type: `${objet.cle}-objet`, objet: objet.nom,
    texte: `${objet.etat(voulu)}, mais ${n} objet${n > 1 ? 's' : ''} ${objet.nom} sur la fiche (${voulu} attendu${voulu > 1 ? 's' : ''}) : D&D Beyond a refusé d'en ajouter${raison}. Nouvel essai toutes les 5 min ; sinon, ajoutez-les à la main sur la fiche.` }];
}
// Le contenu homebrew désactivé sur une fiche, quand l'option qui l'impose est décochée : les objets d'état restent sans effet.
const alerteHomebrew = d => ({ fiche: d.id, nom: String(d.name || d.id).trim(), joueur: null, type: 'homebrew-desactive',
  texte: 'Le contenu homebrew est désactivé sur la fiche (« Preferences », « Homebrew ») : les objets homebrew (Exhaustion Level, Encumbered, Heavily Encumbered) ne s\'appliquent pas.' });

// d : fiche brute ; objet : l'un des OBJETS_ETAT. → null (rien à faire), ou { texte, change } : ce qui a été fait (ou
// l'erreur), et si l'inventaire a changé.
async function synchroniserObjet(d, objet, regles) {
  const voulu = objet.voulu(d, regles);
  const objets = (d.inventory || []).filter(i => i.definition?.id === objet.id);
  if (objets.length === voulu && objets.every(i => i.equipped)) return null;
  const cleEchec = `${objet.id}:${d.id}`;
  if (Date.now() - (echecsEpuisement.get(cleEchec) || 0) < 300e3) return null;
  const nom = String(d.name || d.id).trim();
  let change = false;
  try {
    const ranges = [...objets].sort((a, b) => Number(a.equipped) - Number(b.equipped));   // les non équipés partent d'abord
    const surplus = ranges.slice(0, Math.max(0, objets.length - voulu));
    const gardes = ranges.slice(surplus.length);
    for (const o of surplus) {
      verifier(await appelBeyond(`${PERSONNAGES}v5/inventory/item`, { methode: 'DELETE', corps: { characterId: d.id, id: o.id, removeContainerContents: false } }), `de retirer un objet ${objet.nom}`);
      change = true;
    }
    let ajoutes = [];
    const manque = voulu - objets.length;
    if (manque > 0) {
      const r = verifier(await appelBeyond(`${PERSONNAGES}v5/inventory/item`, { methode: 'POST', corps: { characterId: d.id,
        equipment: Array.from({ length: manque }, () => ({ containerEntityId: d.id, containerEntityTypeId: CONTENEUR.personnage, entityId: objet.id, entityTypeId: objet.type, quantity: 1 })) } }), `d'ajouter les objets ${objet.nom}`);
      ajoutes = (r?.data ?? r)?.addItems || [];
      change = true;
      if (ajoutes.length < manque) throw new Error(`D&D Beyond n'a rendu que ${ajoutes.length} objet(s) sur ${manque}.`);
    }
    for (const o of [...gardes.filter(x => !x.equipped), ...ajoutes.filter(x => !x.equipped)]) {
      verifier(await appelBeyond(`${PERSONNAGES}v5/inventory/item/equipped`, { methode: 'PUT', corps: { characterId: d.id, id: o.id, value: true } }), `d'équiper un objet ${objet.nom}`);
      change = true;
    }
    echecsEpuisement.delete(cleEchec);
    return { change, texte: objets.length === voulu ? `${nom} : objets ${objet.nom} équipés (${objet.etat(voulu)}).`
      : `${nom} : ${objet.etat(voulu)}, objets ${objet.nom} ajustés (${objets.length} → ${voulu}).` };
  } catch (e) {
    echecsEpuisement.set(cleEchec, Date.now());
    return { change, texte: `${nom} : objets ${objet.nom} pas ajustés (${e.message}) ; nouvel essai dans 5 min.` };
  }
}

// ───── États d'une créature (familier, compagnon), recopiés dans sa note (formats/note-compagnon.md) ─────
// D&D Beyond n'en pose pas sur les créatures : le gestionnaire les garde (etat/etats-creatures.json) et les recopie dans
// la note de la créature (« Customize », Notes : characterValues typeId 47, CREATURE_NOTES), où l'extension du joueur
// (extensions/compagnon/) les lit. Une ligne « [États (MJ) : À terre, Épuisement 2] », remplacée ou ajoutée à la fin ; le
// reste de la note (écrit par le joueur) est gardé. Note vide : retirée. Comme la fiche : PUT character/v5/custom/value
// (VALUE_SET), DELETE du même chemin (VALUE_REMOVE). Relevé dans le code de la fiche (character-app 1.72.9, 2026-10-20).
const VALEUR_NOTES_CREATURE = 47;
const LIGNE_ETATS = /\[\s*États \(MJ\)\s*:[^\]]*\]/giu;

// m : { personnage (id de la fiche du maître), creature (id de la créature), etats (noms VF, du plus grave au moins grave,
// « Épuisement 2 » avec son niveau) }.
async function changerEtatsCreature(m) {
  const perso = await ficheConnue(m);
  const d = (await appelBeyond(API + perso))?.data;
  if (!d?.id) throw new Error('Fiche D&D Beyond illisible : rien n\'a été écrit.');
  const cr = (d.creatures || []).find(c => String(c.id) === String(m.creature));
  if (!cr) throw new Error('Créature introuvable sur la fiche : rien n\'a été écrit.');
  const avant = String((d.characterValues || []).find(v => v.typeId === VALEUR_NOTES_CREATURE && String(v.valueId) === String(cr.id))?.value || '');
  const noms = (Array.isArray(m.etats) ? m.etats : []).map(x => String(x).replace(/[[\],]/g, '').trim()).filter(Boolean).slice(0, NB_ETATS);
  const ligne = noms.length ? `[États (MJ) : ${noms.join(', ')}]` : '';
  const note = [avant.replace(LIGNE_ETATS, '').replace(/\n{3,}/g, '\n\n').trim(), ligne].filter(Boolean).join('\n');
  if (note === avant.trim()) return { personnage: perso, creature: cr.id, note, inchangee: true };
  const cle = { characterId: perso, typeId: VALEUR_NOTES_CREATURE, valueId: String(cr.id), valueTypeId: String(cr.entityTypeId), contextId: null, contextTypeId: null, partyId: null };
  verifier(await appelBeyond(`${PERSONNAGES}v5/custom/value`, note
    ? { methode: 'PUT', corps: { ...cle, value: note, notes: null } }
    : { methode: 'DELETE', corps: cle }), 'la note de la créature');
  await releverApres();
  return { personnage: perso, creature: cr.id, note };
}

// ───── PV d'un héros ou d'une créature (widget Combat, comme ceux d'un monstre) ─────
// Comme la fiche : PUT character/v5/life/hp/damage-taken { characterId, removedHitPoints, temporaryHitPoints } pour un
// héros, PUT character/v5/creature/hp { characterId, id, removedHitPoints, temporaryHitPoints } pour une créature
// (HIT_POINTS_SET et CREATURE_HIT_POINTS_SET du code de la fiche, character-app 1.72.9, relevés le 2026-10-20 ; jamais
// essayés sur une vraie fiche avant). Puis un relevé aussitôt.
// m : { personnage (id de la fiche), creature (id, pour une créature), perdus (PV perdus, ≥ 0), temporaires (≥ 0) }.
async function changerPv(m) {
  const perso = await ficheConnue(m);
  const perdus = Math.max(0, Math.round(Number(m.perdus) || 0)), temporaires = Math.max(0, Math.round(Number(m.temporaires) || 0));
  if (m.creature != null) {
    const id = Number(m.creature);
    if (!Number.isInteger(id) || id <= 0) throw new Error('Créature inconnue.');
    verifier(await appelBeyond(`${PERSONNAGES}v5/creature/hp`, { methode: 'PUT', corps: { characterId: perso, id, removedHitPoints: perdus, temporaryHitPoints: temporaires } }), 'les PV de la créature');
  } else {
    verifier(await appelBeyond(`${PERSONNAGES}v5/life/hp/damage-taken`, { methode: 'PUT', corps: { characterId: perso, removedHitPoints: perdus, temporaryHitPoints: temporaires } }), 'les PV');
  }
  await releverApres();
  return { personnage: perso, creature: m.creature ?? null, perdus, temporaires };
}

// ───── Images d'un livre (depuis 1.15.0, bibliothèque d'images du gestionnaire, fenêtre Campagne) ─────
// Comme scripts/dndbeyond_image_scraper/1-collecter-urls.js : lit la page d'accueil du livre, puis chacune de ses pages
// (4 à 8 s entre deux), avec la session du MJ ; relève les images en pleine taille (liens vers une image, sinon l'image
// affichée) et marque les cartes (nom en « map », ou suivies d'une « Player Version »). Un relevé dure quelques minutes :
// la commande le lance et rend aussitôt son avancement ; la page la rappelle avec `etat` pour le suivre. Résultat : une
// ligne par image, « page|carte (0/1)|url|libellé », lue par 2-telecharger-images.ps1.
let releveLivre = null;   // { adresse, en_cours, pages, faites, images, cartes, erreur, liste }
const IMAGE = /\.(jpe?g|png|webp|gif)(\?.*)?$/i;
const pause = ms => new Promise(r => setTimeout(r, ms));
const texteHtml = t => String(t || '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, '\'')
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
const attribut = (balise, nom) => texteHtml(balise.match(new RegExp(`\\s${nom}="([^"]*)"`, 'i'))?.[1] || '');

async function imagesLivre(m) {
  const adresse = String(m?.adresse || '').trim().replace(/[?#].*$/, '').replace(/\/$/, '');
  if (m?.etat) return releveLivre?.adresse === adresse ? { ...releveLivre } : null;
  if (releveLivre?.en_cours) {
    if (releveLivre.adresse === adresse) return { ...releveLivre };
    throw new Error('Un autre livre est en cours de relevé : attendez qu\'il finisse.');
  }
  const livre = adresse.match(/^https:\/\/www\.dndbeyond\.com\/sources\/(?:dnd\/)?([a-z0-9-]+)$/i)?.[1];
  if (!livre) throw new Error('Adresse du livre : sa page d\'accueil sur D&D Beyond (https://www.dndbeyond.com/sources/dnd/phb-2024, par exemple).');
  releveLivre = { adresse, en_cours: true, pages: 0, faites: 0, images: 0, cartes: 0, erreur: null, liste: null };
  const r = releveLivre;
  (async () => {
    const lirePage = async url => {
      const rep = await fetch(url, { credentials: 'include' });
      if (rep.status === 429) throw new Error('D&D Beyond demande de ralentir (429) : réessayez dans quelques minutes.');
      if (!rep.ok) throw new Error(`D&D Beyond a répondu ${rep.status} pour ${new URL(url).pathname}.`);
      return { html: await rep.text(), url: rep.url.replace(/[?#].*$/, '').replace(/\/$/, '') };
    };
    const accueil = await lirePage(adresse);
    if (/sign in|connexion/i.test(accueil.html.match(/<title>([^<]*)/i)?.[1] || '')) throw new Error('Pas de session D&D Beyond : connectez-vous sur dndbeyond.com dans ce navigateur.');
    // Le livre a pu changer d'adresse (free-rules mène à br-2024) : ses pages sont sous celle où l'on arrive.
    const nom = accueil.url.split('/').pop() || livre;
    const liens = [...accueil.html.matchAll(new RegExp(`href="((?:https://(?:www\\.)?dndbeyond\\.com)?/sources/(?:dnd/)?${nom}/[^"#?]+)"`, 'gi'))]
      .map(x => new URL(x[1], 'https://www.dndbeyond.com').href.replace('://dndbeyond.com', '://www.dndbeyond.com').replace(/\/$/, ''));
    const pages = [...new Set([accueil.url, ...liens])];
    r.pages = pages.length;
    const trouvees = new Map();   // url -> { url, page, libelle, carte }
    let precedente = null;
    const ajouter = (url, page, libelle) => {
      if (!url || !IMAGE.test(url) || trouvees.has(url)) return;
      const fichier = url.split('/').pop();
      const joueurs = /player version/i.test(libelle) || /-player\./i.test(fichier);
      if (joueurs && precedente) precedente.carte = true;   // une « Player Version » suit toujours la carte du MJ
      precedente = { url, page, libelle: libelle || '', carte: joueurs || /(^|[-.])map/i.test(fichier) };
      trouvees.set(url, precedente);
    };
    for (const [i, url] of pages.entries()) {
      const { html } = i ? await lirePage(url) : accueil;
      const page = String(i).padStart(2, '0') + '-' + (i ? url.split('/').pop() : 'accueil');
      const absolue = href => { try { return new URL(href.replace(/&amp;/g, '&'), url).href; } catch { return null; } };
      // Le texte du livre, sans l'en-tête ni le pied du site : son conteneur (p-article-content), jusqu'au pied de l'article.
      const debut = html.search(/class="[^"]*\bp-article-content\b/);
      const fin = debut >= 0 ? html.indexOf('p-article-footer', debut) : -1;
      const corps = debut >= 0 ? html.slice(debut, fin > debut ? fin : undefined) : html;
      for (const x of corps.matchAll(/<a\s[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>|<img\s[^>]*>/gi)) {
        if (x[1] !== undefined) {
          const href = absolue(x[1]);
          const imgs = [...x[2].matchAll(/<img\s[^>]*>/gi)].map(y => y[0]);
          if (href && IMAGE.test(href)) ajouter(href, page, texteHtml(x[2]) || attribut(imgs[0] || '', 'alt'));
          else imgs.forEach(b => ajouter(absolue(attribut(b, 'data-src') || attribut(b, 'src')), page, attribut(b, 'alt')));
        } else ajouter(absolue(attribut(x[0], 'data-src') || attribut(x[0], 'src')), page, attribut(x[0], 'alt'));
      }
      r.faites = i + 1;
      r.images = trouvees.size;
      r.cartes = [...trouvees.values()].filter(t => t.carte).length;
      if (i < pages.length - 1) await pause(4000 + Math.random() * 4000);
    }
    r.liste = [...trouvees.values()].map(t => [t.page, t.carte ? 1 : 0, t.url, t.libelle.replace(/[|\n]/g, '/')].join('|')).join('\n');
  })().catch(e => { r.erreur = e.message; }).finally(() => { r.en_cours = false; });
  return { ...r };
}

// ───── Notes publiques de la campagne (depuis 1.19.0 : la ligne du bandeau des joueurs, formats/note-compagnon.md) ─────
// Le formulaire « Edit Campaign » de D&D Beyond est une page classique, pas une API : l'extension en lit la page avec la
// session du MJ (`campagne-edition`), la page du gestionnaire y repère le formulaire et le champ des notes publiques
// (DOMParser, que la tâche de fond n'a pas), y place la ligne, et l'extension renvoie le formulaire entier, tous ses champs
// tels qu'ils étaient (`campagne-enregistrer`), comme le bouton « Save ». Seule une adresse de la campagne est acceptée.
const ADRESSE_CAMPAGNE = id => `https://www.dndbeyond.com/campaigns/${id}`;
const idCampagne = m => { const id = String(m?.campagne || ''); if (!/^\d+$/.test(id)) throw new Error('Campagne D&D Beyond inconnue : attendez un relevé.'); return id; };

async function editionCampagne(m) {
  const id = idCampagne(m);
  const r = await fetch(`${ADRESSE_CAMPAGNE(id)}/edit`, { credentials: 'include', cache: 'no-store' });
  if (!r.ok) throw new Error(`D&D Beyond a répondu ${r.status} pour la page « Edit Campaign ».`);
  const html = await r.text();
  if (!r.url.startsWith(ADRESSE_CAMPAGNE(id))) throw new Error('D&D Beyond n\'ouvre pas la page « Edit Campaign » : connectez-vous sur dndbeyond.com avec le compte du MJ de la campagne.');
  return { html, url: r.url };
}

async function enregistrerCampagne(m) {
  const id = idCampagne(m);
  const action = new URL(String(m.action || ''));
  if (action.origin !== 'https://www.dndbeyond.com' || !action.pathname.startsWith(`/campaigns/${id}`)) throw new Error('Formulaire inattendu : il n\'envoie pas à la page de la campagne.');
  if (!Array.isArray(m.champs) || m.champs.some(c => !Array.isArray(c) || typeof c[0] !== 'string')) throw new Error('Champs du formulaire illisibles.');
  let corps;
  if (/multipart/i.test(m.enctype || '')) {
    corps = new FormData();
    for (const [nom, valeur, fichier] of m.champs) {
      if (fichier) corps.append(nom, new Blob([], { type: 'application/octet-stream' }), '');   // fichier non choisi, comme le navigateur
      else corps.append(nom, String(valeur ?? ''));
    }
  } else {
    corps = new URLSearchParams();
    for (const [nom, valeur, fichier] of m.champs) if (!fichier) corps.append(nom, String(valeur ?? ''));
  }
  const r = await fetch(action.href, { method: 'POST', credentials: 'include', body: corps, referrer: `${ADRESSE_CAMPAGNE(id)}/edit` });
  if (!r.ok) throw new Error(`D&D Beyond a refusé l'enregistrement (${r.status}).`);
  relever();   // le relevé dira la ligne en place
  return { statut: r.status, url: r.url };
}

const COMMANDES = {
  ping: async () => ({ version: chrome.runtime.getManifest().version }),
  'campagne-edition': m => editionCampagne(m),
  'campagne-enregistrer': m => enregistrerCampagne(m),
  'images-livre': m => imagesLivre(m),
  objet: m => ajouterObjet(m),
  renommer: m => renommerObjet(m),
  pieces: m => donnerPieces(m),
  objets: m => lireObjets(m),
  'objets-fiches': m => lireFichesObjets(m),
  etat: m => changerEtat(m),
  'etats-creature': m => changerEtatsCreature(m),
  pv: m => changerPv(m),
  inspiration: m => changerInspiration(m),
  monstres: m => lireMonstres(m.ids),
  bestiaire: m => lireBestiaire(m.sources, !!m.homebrew),
  config: () => lireConfig(),
};

chrome.runtime.onMessageExternal.addListener((msg, expediteur, repondre) => {
  const commande = COMMANDES[msg?.type];
  if (!commande || !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//.test(expediteur?.url || '')) {
    repondre({ ok: false, erreur: 'Demande inconnue.' });
    return false;
  }
  Promise.resolve().then(() => commande(msg)).then(resultat => repondre({ ok: true, resultat }), e => repondre({ ok: false, erreur: e.message }));
  return true;   // réponse asynchrone
});

// ───── Badge : secondes depuis le dernier relevé réussi ─────

function age(quand) {
  if (!quand) return '';
  const s = Math.max(0, Math.round((Date.now() - quand) / 1000));
  return s < 100 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}m` : `${Math.floor(s / 3600)}h`;
}

async function badge() {
  const { reglages, dernier } = await lire();
  const s = dernier?.quand ? (Date.now() - dernier.quand) / 1000 : Infinity;
  let texte = age(dernier?.quand), couleur = s < 50 ? COULEURS.ok : COULEURS.vieux;
  if (!reglages.actif) { texte = 'II'; couleur = COULEURS.arret; }
  else if (dernier?.statut && !['ok', 'partiel'].includes(dernier.statut) && dernier.essai >= (dernier.quand || 0)) {
    couleur = dernier.statut === 'gestionnaire' ? COULEURS.arret : COULEURS.erreur;
    if (!texte || dernier.statut === 'gestionnaire') texte = dernier.statut === 'gestionnaire' ? 'off' : '!';
  }
  await chrome.action.setBadgeText({ text: texte });
  await chrome.action.setBadgeBackgroundColor({ color: couleur });
  await chrome.action.setTitle({ title: `Relevé D&D Beyond${dernier?.message ? ' · ' + dernier.message : dernier?.quand ? ' · il y a ' + age(dernier.quand) : ''}` });
}

// ───── Déclencheurs ─────

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create('releve', { periodInMinutes: PERIODE_MIN, delayInMinutes: 0 }));
chrome.runtime.onStartup.addListener(() => chrome.alarms.create('releve', { periodInMinutes: PERIODE_MIN, delayInMinutes: 0 }));
const releverSiDu = () => { if (Date.now() - dernierLance >= PERIODE_MS) relever(); };
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'releve') releverSiDu(); });
chrome.runtime.onMessage.addListener((msg, _exp, repondre) => {
  if (msg?.type === 'relever') { relever().then(() => repondre(true)); return true; }
  if (msg?.type === 'details') { chrome.storage.local.set({ detailsDemandes: true }).then(relever).then(() => repondre(true)); return true; }
  if (msg?.type === 'badge') { badge().then(() => repondre(true)); return true; }
  return false;
});
// Mise à jour du badge chaque seconde (chaque appel à l'API garde la tâche de fond éveillée).
setInterval(() => { badge(); releverSiDu(); }, 1000);
chrome.alarms.get('releve').then(a => a || chrome.alarms.create('releve', { periodInMinutes: PERIODE_MIN }));
relever();
