Barovie Néon est la charte de base du gestionnaire de campagne, née pour une campagne d'horreur gothique : suivi de combat, fiches de PNJ, carte du monde, tirage de cartes, journal de séance. Le gothique donne la structure (lettres brisées, coins coupés, filets ornés), le néon signale ce qui compte maintenant : le tour en cours, la vie qui baisse, la magie active. Tout le reste reste dans l'ombre.

## Principes

- **L'ombre par défaut, la lumière pour l'urgence.** Un écran au repos est sombre et calme. Seuls l'élément actif et ce qui demande une décision brillent. Si trois choses luisent à la fois, deux sont de trop.
- **Lisible à un mètre, dans le noir.** Le MJ jette un œil à l'écran entre deux répliques. Chiffres grands et tabulaires, libellés en capitales courtes, contraste AA partout.
- **Le vocabulaire de la table.** On écrit « PV », « CA », « Ensanglanté », « Round 3 », « Jour 7 ». Jamais de jargon logiciel : on « ajoute un combattant », on ne « crée pas une entité ».
- **Les personnages ont leur voix.** L'écriture manuscrite est réservée à ce qu'un personnage écrit lui-même (une lettre, une signature). Elle ne sert jamais de décoration.

## Contenu et ton

- Français, vouvoiement dans l'interface (« Indiquez le vrai nom »), tutoiement interdit.
- Boutons à l'infinitif ou à l'impératif, verbe d'abord : « Lancer le combat », « Tour suivant », « Retourner la carte ».
- Capitale initiale seulement (« Ajouter un PNJ »), sauf surtitres et étiquettes, mis en capitales par le CSS (`text-transform`), jamais tapés en capitales.
- Noms propres de l'aventure en français quand une traduction existe et est usuelle ; sinon le nom original.
- Distances de jeu en pieds, comme sur les fiches D&D Beyond : « 30 ft ». Au survol, l'équivalent en mètres et en cases (1 case = 5 ft) dans une [infobulle](components/Infobulle/README.md) bleue : « 9 m · 6 cases » (`distance()` de `app/ui.js`). Les trajets restent en miles ou en km, l'autre unité en infobulle. Dés en notation `2d6+3`, en JetBrains Mono.
- L'unité reste collée à son nombre par une espace fine insécable (U+202F, `FINE` de `app/ui.js`) : « 30 ft », « 16 miles », « ~26 km », et « DD 12 » (le nombre après). Jamais de retour à la ligne entre les deux.
- Pas d'emoji. Les icônes de la bibliothèque les remplacent.
- Messages d'erreur : ce qui manque et comment le corriger. « Indiquez le vrai nom, même s'il reste secret. »
- Dates de jeu : le jour de campagne, puis la date au calendrier de la campagne et l'année : « Jour 1 · Lundi 6 octobre · 1009 » (« Calendrier classique » en infobulle sur l'année). Un clic sur la date ouvre la fenêtre du jour (fiche [Horloge](components/Horloge/README.md)). En titre de fenêtre : « Jour 1 · 1009 du calendrier classique » en surtitre, la date en titre.

## Chartes

Barovie Néon est la charte de base : ses composants `bn-*` servent à toutes les campagnes. Une autre charte (`design-system/chartes/<id>/`, choisie par le manifeste de la campagne) redonne les **mêmes jetons** avec d'autres valeurs (`tokens.json`, `tokens.css` généré), et quelques effets dans `charte.css` (polices, pas de néon, coins droits : `coupe-*` à 0). Les noms des jetons sont des rôles : `sang` est l'accent et le danger, `ultra` la magie, `brume` le stable, `cierge` l'alerte, `soleil` le jour, `mousse` la nature. Chartes : [Médiéval glorieux](chartes/medieval-glorieux/LISEZMOI.md).

## Couleur

Deux thèmes : **Nuit** (défaut, `data-theme="nuit"`) pour jouer, **Parchemin** (`data-theme="parchemin"`) pour imprimer ou travailler en plein jour. Les halos néon valent `transparent` en Parchemin : aucun composant n'a besoin de règle spécifique au thème.

- Fond d'application : `void` sous la classe `.bn-brume` (deux nappes `aura-1` / `aura-2`). Panneaux sur `crypte`, cartes et lignes sur `pierre`, survol et champs sur `pierre-haute`.
- Texte : `os` pour le contenu, `cendre` pour le secondaire, `fane` pour désactivé et placeholders. Les trois passent 4.5:1 sur toutes les surfaces, dans les deux thèmes.
- Filets : `trait` pour séparer, `trait-fort` pour les bordures de contrôles (3:1).
- Néons, un rôle chacun :
  - `sang` : action principale, le grand méchant, danger, dégâts. C'est l'accent de la marque.
  - `ultra` : magie, sorts, concentration, information.
  - `brume` : spectral, état stable ou réussite.
  - `cierge` : avertissement, lumière de bougie, voyageurs, trésor.
  - `soleil` : jour, radiant, sacré.
  - `mousse` : nature, pleine nature (terrain des héros), forêt. Avec `mousse-voile` et `halo-mousse`.
- Sur un aplat de néon, le texte est `sur-accent`. Sur `sang-profond`, il est `os-clair`.
- `abysse` : le pire (zone TPK de la jauge de difficulté, rang Haï de la réputation), un rouge si sombre qu'il paraît noir. Toujours en aplat liséré de `sang`, texte `os-clair` ; jamais en texte (un texte « abysse » s'écrit en `sang`).
- Fonds teintés (badges, alertes) : `*-voile` posé sur une surface opaque, texte dans le néon correspondant.
- Lueurs : `halo-*` pour `text-shadow` et `drop-shadow`, ombres `lueur-sang`, `lueur-ultra`, `lueur-brume` pour l'élément actif.
- Les états ne reposent jamais sur la couleur seule : chaque badge ou barre porte un mot (« Ensanglanté », « Stable ») ou une icône. Danger (`sang`) et réussite (`brume`) s'opposent sur l'axe rouge/bleu, pas rouge/vert.
- `velin` et `encre` sont fixes dans les deux thèmes : ils représentent un objet physique, la lettre.
- Factions : `fac-zarovich`, `fac-vistani`, `fac-argynvost`, `fac-plume`, `fac-matinal`, `fac-loups`, uniquement en pastille (`.bn-badge__point`) ou en puce, jamais en fond.

Atmosphère inspirée des traitements néon de l'horreur gothique ; la palette est une interprétation, pas une reprise.

## Typographie

| Famille | Jeton | Rôle |
| --- | --- | --- |
| Grenze Gotisch | `--font-display` | Nommer : écrans, lieux, PNJ, monstres. Styles `titre-xl`, `titre-l`, `titre-m`. |
| Barlow Semi Condensed | `--font-ui` | Opérer : boutons, onglets, tableaux, champs. Styles `surtitre`, `ui-l`, `ui`, `ui-s`, `etiquette`, `chiffre`. |
| Spectral | `--font-text` | Lire : textes à voix haute, notes, descriptions. Styles `lecture`, `texte`, `aparte`. |
| JetBrains Mono | `--font-mono` | Dés et formules. Style `des`. |
| 1805 Austerlitz Script | `--font-script` | Écriture manuscrite (lettres d'un personnage). Style `lettre`. Repli : Pinyon Script. |

- Un seul `titre-xl` par écran. Les titres reçoivent `text-wrap: balance`.
- Un `surtitre` au-dessus d'un titre situe le contexte (« Combat · Round 3 », « Chapitre 5 · Valombre »).
- Chiffres de jeu (PV, CA, initiative) en `chiffre` ou en Barlow 600 avec `font-variant-numeric: tabular-nums`.
- Prose : 68 caractères par ligne au plus.
- L'écriture manuscrite : jamais sous 28px, trois lignes au plus. Pour une lettre longue, salutation et signature en script, corps en Spectral italique (`.bn-lettre`). La police est installée localement sous le nom `1805AusterlitzScriptW01-Lt` ; sa licence interdit de la publier sur le web, d'où le repli Pinyon Script.

## Formes, espace, profondeur

- **La coupe de cercueil.** Coins coupés à 45° sur les boutons, badges, panneaux et cartes Tarokka : `coupe-s` (5px) pour badges et petits boutons, `coupe-m` (9px) pour boutons et cartes, `coupe-l` (16px) pour panneaux. C'est la signature visuelle. Les champs, tableaux et cartes simples restent à angle droit (`radius-0`).
- Arrondi complet (`radius-rond`) seulement pour les pastilles de faction.
- Espacements sur une base de 4 : `space-1` 4 · `space-2` 8 · `space-3` 12 · `space-4` 16 · `space-5` 24 · `space-6` 32 · `space-7` 48 · `space-8` 72. Gouttière mobile `space-4`, padding de panneau `space-5`, écart entre sections `space-6` à `space-8`.
- Pas d'ombres décoratives. La profondeur vient de l'empilement des surfaces (`void` → `crypte` → `pierre`). `ombre-panneau` seulement pour ce qui flotte (dialogues, menus, lettre).
- Filet orné `.bn-filet` (losange central) pour séparer les blocs d'un bloc de stats ou d'une fiche ; `.bn-filet--sang` dans les blocs de monstres.
- Texture : `.bn-grain` ajoute un grain de pellicule très léger sur toute l'application ; ne jamais l'empiler.

## Mouvement

- Durées `--duree-1` 120ms (survol), `--duree-2` 240ms (onglet, PV qui baissent), `--duree-3` 700ms (apparition d'une carte). Courbe `--courbe`.
- Deux animations seulement : `.bn-gresille` (néon qui grésille, un seul élément par écran, en général le titre) et le pouls de la barre de PV critique.
- `prefers-reduced-motion` coupe les deux et les transitions de déplacement.

## États et focus

- Focus clavier : contour plein de 2px en `focus`, décalé de 2px, sur tout élément interactif.
- Actif / en cours : bordure `sang` + `lueur-sang` (tour d'initiative, panneau de combat, onglet sélectionné).
- Survol d'un bouton : la bordure passe au `sang` et le bouton s'illumine (`drop-shadow` en `halo-sang`).
- Désactivé : opacité 0.45, pas de lueur.
- Erreur de champ : bordure `sang`, message `.bn-champ__erreur` avec icône `crane`.
- PV : `data-etat` vaut rien (sain, `brume`), `ensanglante` (≤ 50 %, `soleil`), `critique` (< 20 %, `sang` qui pulse), `mort` (`fane`). PV temporaires en `ultra`.

## Iconographie

- 42 icônes thématiques maison (`assets/Icons`) : 24 × 24, trait 1.5, bouts et angles arrondis, `currentColor`. Dans ce système les fichiers sont encrés en `sang` (#ff2d6f) pour l'aperçu ; dans le projet local (`icons/`), ils héritent de la couleur du texte.
- Usage web : charger `icons.js` (injecte le sprite), puis `<svg class="bn-icone"><use href="#bn-cierge"/></svg>`, ou `BN.icone('cierge', { taille: 20, titre: 'Lumière' })`.
- Tailles : `.bn-icone--s` 16, défaut 20, `--l` 28, `--xl` 40. Une icône seule dans un bouton porte un `aria-label`.
- Correspondances fixes : PV `coeur`, CA `bouclier`, initiative `sablier`, jet `d20`, PNJ dangereux `crocs`, lieu `epingle`, carte `carte`, notes `livre`, lettre `lettre`, mort `crane`, jour `soleil`, nuit `lune`. Couleurs du Tarokka : Épées `epee`, Étoiles `etoile`, Pièces `piece`, Glyphes `glyphe`, haut jeu `tarokka`.
- Pour les icônes d'interface génériques (fermer, rechercher, flèches, réglages), utiliser **Lucide** : même grille, même trait, elles se mélangent sans couture. Pour des silhouettes de monstres ou de sorts, **game-icons.net** (CC BY 3.0, créditer les auteurs), en remplissage `currentColor`.

## Composants

Classes préfixées `bn-`, décrites dans chaque fiche : Bouton (et sa bascule), Badge, Champ, Onglets, Panneau, Tableau, Alerte, BarrePV, Initiative, JetsMort, Etat, BlocStats, Tarokka, ALire, Lettre, Horloge (avec la météo et la fenêtre du jour), Icone, Widget (grille du tableau de bord), Dialogue, Flottant, DD, Infobulle, Menu, Jalon (lignes d'une frise), LienDeroule, Lieu (carte d'un lieu). Charger `tokens.css` puis `bundle.css` (dans le projet : `barovie.css`) et donner `class="bn-app bn-brume"` au `body`.
