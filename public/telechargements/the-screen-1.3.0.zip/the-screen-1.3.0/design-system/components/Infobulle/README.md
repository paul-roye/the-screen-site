Une précision courte au survol ou au focus d'un élément : l'équivalent d'une distance (« 9 m · 6 cases »), la note du MJ sur un trajet, le détail d'un lieu de la carte : `.bn-bulle`.

**Le consommateur fournit** : en option un titre `<b>` (« Vitesse », le nom d'un lieu), puis le texte dans un `<span>`. Dans le gestionnaire, `infobulle(el, texte, { titre, ton })` de `app/ui.js` pose `data-bulle` sur l'élément ; une seule infobulle de page (popover, au-dessus des dialogues) le suit au survol et au focus, au-dessus de l'élément, dessous s'il manque de place. Une infobulle posée sur une carte se place elle-même (`position: absolute`, voir la carte des trajets).

- Le filet prend **la couleur de l'élément qu'elle détaille** (demande du MJ, 2026-10-23) : un badge orange, une infobulle orange ; un lieu jaune de la carte des trajets, une infobulle jaune. Variantes `.bn-bulle--sang`, `--ultra`, `--cierge`, `--soleil`, `--mousse`, `--brume`, `--abysse` (fond `abysse`, filet `sang`, texte `os-clair`) pour le pire, la zone TPK ou le rang Haï, et `--nuit` (fond `void`, filet `os`) pour un autre élément noir. Dans le gestionnaire, `infobulle()` sans `ton` laisse `activerInfobulles()` choisir le néon le plus proche de la couleur du texte de l'élément, sinon de sa bordure, sinon de son fond.
- Filet **bleu** (`brume`, le défaut) : un élément neutre (texte `os` ou `cendre`, filets), le cas courant (distances, conversions, phase de la lune).
- Filet **rouge** (`.bn-bulle--sang`), donné à la main : une information importante sur un élément neutre.
- Surface `crypte`, bordure `trait-fort`, `ombre-panneau` : elle flotte. Texte `cendre` en 13px, titre `os` en 14px. 320px de large au plus.
- L'élément porteur d'une distance est souligné en pointillé (`.cm-distance`), curseur d'aide : il annonce qu'une infobulle existe.
- Jamais d'action dans une infobulle (elle ne prend pas le pointeur) ; jamais d'information indispensable seulement là.
