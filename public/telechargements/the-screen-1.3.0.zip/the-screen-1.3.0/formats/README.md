# formats/ : le contrat entre l'agent IA de campagne et le gestionnaire

L'agent IA de chaque campagne (un projet Claude, ou une autre IA) **produit** les fichiers de `data/` de la campagne. Le gestionnaire de campagne les **lit**. Ce dossier décrit exactement ce que chaque fichier doit contenir, pour que l'export tombe juste du premier coup. Il vaut pour toutes les campagnes ; les exemples sont inventés (le royaume d'Aurval, comme la campagne témoin `campagnes/temoin/`), sauf ceux des fonctions propres à *Curse of Strahd* (module Tarokka, calendrier Barovien). Les règles de travail de l'agent sont dans `AGENTS.md`, à la racine.

- Une fiche par fichier de `data/` : `formats/<jeu>.md`.
- Ces fiches font foi. Si l'export et la fiche ne disent pas la même chose, l'un des deux est à corriger.
- Pour exporter, donnez à l'agent IA de campagne cette page **et** la fiche du fichier voulu (voir « Demander un export »).

| Fichier de `data/` | Fiche | Format | État |
|---|---|---|---|
| `rencontres-aleatoires.json` | [rencontres-aleatoires.md](rencontres-aleatoires.md) | 3 | En service (widget Rencontres, passage du temps) ; format 3 le 2026-10-24 (modificateurs de la procédure, plus d'espions ; un fichier au format 2 est converti au chargement) |
| `tarokka.json` | [tarokka.md](tarokka.md) | 1 | Module de campagne Tarokka (Curse of Strahd : `app/modules/tarokka.js`, `modules` du manifeste) |
| `noms.json` | [noms.md](noms.md) | 1 | En service (widget Noms) |
| `occupants-maisons.json` | [occupants-maisons.md](occupants-maisons.md) | 1 | En service (widget Maisons) |
| `faune.json` | [faune.md](faune.md) | 1 | En service (widget Faune) |
| `temps-de-voyage.json` | [temps-de-voyage.md](temps-de-voyage.md) | 1 | En service (widget Trajets) |
| `pnj.json` | [pnj.md](pnj.md) | 2 | En service (widgets PNJ, Marchands) ; format 2 le 2026-10-24 (`savoirs` ; un fichier au format 1 est converti au chargement) |
| `marchands.json` | [marchands.md](marchands.md) | 1 | En service (widget Marchands) |
| `lieux.json` | [lieux.md](lieux.md) | 1 | En service (référentiel commun des lieux) |
| `deroule-campagne.json` | [deroule-campagne.md](deroule-campagne.md) | 2 | En service (widgets Déroulé, Ici, Personnages, Rencontres, fin de session) ; format 2 exporté le 2026-10-14 |
| `connaissances.json` | [connaissances.md](connaissances.md) | 2 | En service (widget Qui sait quoi, savoirs des PNJ) ; format 2 le 2026-10-24 (intrigues secrètes ; un fichier au format 1 est converti au chargement) |
| `personnages.json` | [personnages.md](personnages.md) | 2 | En service (widget Personnages ; pistes prises dans le déroulé) ; format 2 exporté le 2026-10-14 |
| `factions.json` | [factions.md](factions.md) | 1 | En service (widget Factions, filtres du widget PNJ, Qui sait quoi) |
| `evenements.json` | [evenements.md](evenements.md) | 1 | Événements de campagne du widget Rencontres, facultatif (2026-10-25). |
| `babioles.json` | [babioles.md](babioles.md) | 2 | En service (widget Babioles) ; format 2 le 2026-10-24 (éléments d'intrigue ; un fichier au format 1 est converti au chargement) |
| `calendrier.json` | [calendrier.md](calendrier.md) | 2 | Calendrier importé, facultatif (widget Horloge : date, lune, jours marqués ; fin de session) : la plupart des campagnes prennent un calendrier fourni (`modeles/calendriers/`). Format 2 le 2026-10-24 : 365 jours. |
| `jours-marques.json` | [jours-marques.md](jours-marques.md) | 1 | Fêtes et anniversaires propres à la campagne, ajoutés au calendrier choisi (2026-10-24). |
| `agenda.json` | [agenda.md](agenda.md) | 1 | Agenda : entrées datées (une fois, à une date), facultatif ; le MJ le complète dans l'Horloge (2026-10-25). |
| `meteo.json` | [meteo.md](meteo.md) | 2 | Météo importée, facultative (widget Horloge ; rappels de Trajets et Rencontres ; fin de session) : la plupart des campagnes prennent une météo fournie (`modeles/meteos/`). Format 2 le 2026-10-24 (`dans_le_monde`, `regle_du_monde`, `type` : `releve` ; un fichier au format 1 est converti au chargement). |
| `objets.json` | [objets.md](objets.md) | 1 | Exporté le 2026-10-21 : widget Objets, Ici, Déroulé, préparation des rencontres, fin de session |
| `quetes.json` | [quetes.md](quetes.md) | 1 | Catalogue des quêtes, facultatif (2026-11-11) : widget Quêtes, Déroulé, panneau de l'écran des joueurs, fin de session ; à activer dans la fenêtre Campagne (onglet « Quêtes et réputation »). |

Chaque campagne a son dossier, `campagnes/<id>/`, avec son manifeste tenu à la main (titre, charte…) : voir [campagne.md](campagne.md). Ce n'est pas un export. Ses fichiers de `data/` et d'`etat/` sont dans ce dossier.

Ce que les outils écrivent eux-mêmes (tirages, journal, disposition) est décrit dans [etat.md](etat.md). Ce n'est pas un export.

L'index de la bibliothèque d'images est écrit par un script local : voir [images.md](images.md). Ce n'est pas un export.

La musique d'ambiance (playlists YouTube étiquetées, `musique/`) est tirée d'un fichier tenu à la main par un script local : voir [musique.md](musique.md). Ce n'est pas un export.

En fin de session, le bouton **Session** du gestionnaire donne à l'agent l'état de la campagne (le gestionnaire fait foi), et l'agent rend ses changements dans un bloc JSON `maj-etat` : voir [maj-etat.md](maj-etat.md).

Les états du compagnon d'un héros (son familier, par exemple), posés par le MJ, passent à l'extension du joueur par la note de la créature sur D&D Beyond : voir [note-compagnon.md](note-compagnon.md). Ce n'est pas un export.

Les plugins (une connexion à un appareil ou à un service, comme The Table, le ruban LED de la table de jeu) et les événements que le gestionnaire leur envoie sont décrits dans [plugins.md](plugins.md). Ce n'est pas un export.

L'import du wiki de campagne écrit `wiki/` : voir [wiki.md](wiki.md). Ce n'est pas non plus un export : c'est une copie du wiki, que l'on **donne** à l'agent IA de campagne (`wiki/wiki-complet.md`, `wiki/changements.md`).

## Conventions communes à tous les fichiers

### Enveloppe

Chaque fichier est un objet JSON, encodé en UTF-8, qui commence par :

| Champ | Type | Contenu |
|---|---|---|
| `schema` | entier | Numéro du format (colonne « Format » ci-dessus). |
| `jeu` | chaîne | Nom du fichier sans `.json` (`"tarokka"`). |
| `titre` | chaîne | Titre lisible, affiché dans le gestionnaire. |
| `genere_le` | chaîne | Date de l'export, `AAAA-MM-JJ`. |
| `avertissement` | chaîne | Rappel « fichier généré, ne pas modifier à la main ». |
| `priorite_sources` | chaînes | Les sources de la campagne, de la plus haute à la plus basse. Par exemple : `["MJ", "SUPP", "LIVRE"]` (les décisions du MJ, puis un supplément, puis le livre de l'aventure). Leurs libellés courts sont dans `sources` du manifeste ([campagne.md](campagne.md)). |
| `sources` | objet | Pour chaque source utilisée : `nom` et `fiche` (ou `fiches`). |
| `conditions` | objet, facultatif | Libellé de chaque condition d'écart : `{ "reliques_reunies": "Les trois reliques sont réunies" }`. Sans lui, l'outil affiche l'identifiant. |

### Provenance

Tout élément de contenu porte `source` (une des sources de `priorite_sources` : `"LIVRE"`, `"SUPP"` ou `"MJ"` dans l'exemple) et `fiche` (chemin de la fiche de l'agent d'où vient l'élément). Facultatif : `pages_livre` (`"28-33"`) ou `pages_pdf`.

### Écarts entre sources

Priorité : celle de `priorite_sources` (dans l'exemple : `MJ` > `SUPP` > `LIVRE`). Le contenu de base vient de la `source` de l'élément ; ce qu'une source plus haute change va dans son tableau `ecarts` (toujours présent, vide s'il n'y a rien).

| Champ | Obligatoire | Contenu |
|---|---|---|
| `source`, `fiche` | oui | Qui change quoi, et où c'est écrit. |
| `sujet` | oui | Trois à six mots (« Nature des marchands nomades »). |
| `texte` | oui | Ce qui s'applique. |
| `original` | conseillé | Ce que disait la source plus basse. |
| `statut` | oui | `applique`, `conditionnel` ou `a_trancher`. |
| `condition` | si `conditionnel` | Identifiant en `snake_case` d'un fait de campagne (`reliques_reunies`), affiché en clair (dictionnaire `conditions`). Le MJ juge lui-même s'il est vrai : rien ne se coche dans le gestionnaire (depuis le 2026-10-23). |
| `question` | si `a_trancher` | La question posée au MJ. Rien n'est appliqué tant qu'elle reste ouverte. |
| `note`, `date` | non | Précision, date de la décision (`AAAA-MM-JJ`). |

Le gestionnaire ouvre les écarts `applique`, replie les `conditionnel` comme une information (« Sous condition », la condition en clair), et affiche les `a_trancher` comme une alerte.

### Fichiers « déjà arbitrés »

Les fichiers de référence de la campagne (noms, trajets, PNJ, marchands, connaissances, factions, déroulé, faune, occupants, babioles, objets) suivent une convention plus simple : leur contenu est **déjà celui qui s'applique**, arbitré entre les sources par l'agent. Ils n'ont pas de tableau `ecarts`. À la place :

| Champ | Obligatoire | Contenu |
|---|---|---|
| `source`, `fiche` | oui | D'où vient l'élément (ou le fichier entier, au premier niveau). |
| `original` | non | Ce que disait le livre, quand une source plus haute (un supplément, le MJ) l'a changé. Affiché replié (« Version d'origine »). |
| `decision_mj` | non | `{ texte, source: "MJ", fiche, date? }` : la décision du MJ qui touche l'élément. |

Une décision encore ouverte ne va pas dans ces fichiers : elle reste chez l'agent jusqu'à ce que le MJ tranche.

### Lieux

Les lieux portent les mêmes `id` dans tous les fichiers (`aurval`, `port-d-aurval`, `gue-du-cerf`…). Le référentiel commun est [lieux.json](lieux.md) : tout lieu cité ailleurs doit y exister, et le gestionnaire y prend les noms, zones et niveaux. Les autres fichiers citent les lieux par leur `id` et ne recopient pas leur nom ni leur zone (sauf `pnj.lieux`, toléré, et `occupants-maisons`, où `lieu` est un objet).

### Liens vers le wiki

Un élément qui a une page sur le wiki des joueurs (`wiki/wiki.json`) peut porter le champ facultatif `wiki` :

| Champ | Contenu |
|---|---|
| `id` | `id` de la page dans `wiki.json` (UUID). C'est lui qui fait foi. |
| `url` | Adresse de la page, pour l'ouvrir en un clic. |

Le gestionnaire ouvre `url` dans un nouvel onglet, ou retrouve la page dans `wiki.json` par son `id` (portrait, texte). Ce que montre le wiki est le point de vue des joueurs : le contenu de `data/` reste la référence du MJ. La correspondance est tenue par l'agent IA de campagne. Déjà présent dans `pnj.json`, `lieux.json` et `personnages.json`.

### Identifiants

- Minuscules, sans accents, mots séparés par des tirets : `loups-sanguinaires`, `epees-maitre`.
- **Stables** : l'état de la campagne (`etat/`) s'y réfère. Renommer un `id` fait perdre le lien (tirage du Tarokka, rencontres retirées). Si c'est inévitable, le signaler dans le message d'export.

### Valeurs

- Dés en notation `XdY+Z` dans des chaînes : `"3d6"`, `"1d4+1"`, `"1d12+1d8"`, `"1"`. Une quantité non lançable (`"2 ou 3"`) est affichée telle quelle.
- Textes : résumés reformulés, jamais de texte recopié du livre. Les textes à lire à voix haute sont ceux du MJ.
- Noms propres : noms officiels de la VF.
- Champs absents plutôt que `null` pour le facultatif ; tableaux vides plutôt qu'absents quand la fiche dit « toujours présent ».

## Demander un export

Dans l'agent IA de campagne, joindre ou citer `formats/README.md` et `formats/<jeu>.md`, puis par exemple :

> Exporte `data/tarokka.json` au format 1 décrit dans `formats/tarokka.md`, en respectant les conventions de `formats/README.md`. Un seul bloc JSON, complet, sans commentaire. Ensuite, liste ce qui manque ou reste à trancher.

Puis :

1. Copier le JSON dans `data/<jeu>.json` (remplacer le fichier entier).
2. Recharger le gestionnaire. Le bouton **Données** de l'en-tête affiche une pastille s'il y a un souci, et la liste des problèmes trouvés (référence vers un `id` inconnu, statut d'écart invalide, mauvais format…).
3. Une erreur se corrige à sa source (la fiche de l'agent), puis on réexporte. On ne retouche pas `data/` à la main.

## Faire évoluer un format

- **Ajouter un champ facultatif** : compléter la fiche ici, sans changer le numéro de format. Les outils ignorent les champs qu'ils ne connaissent pas.
- **Changer un champ existant** (renommer, changer de type, rendre obligatoire) : augmenter `schema` dans la fiche et dans l'outil (`app/donnees.js`, table `FORMATS`), adapter l'outil, puis réexporter. Un fichier au mauvais numéro est refusé avec un message clair.
- **Nouveau fichier** : créer `formats/<jeu>.md` sur le modèle des autres, l'ajouter au tableau ci-dessus et à `FORMATS` dans `app/donnees.js` (avec sa fonction de vérification).
- Après chaque changement, redonner la fiche à jour à l'agent IA de campagne. Le gestionnaire est tenu par son mainteneur : une copie chez un autre MJ ne change pas les formats (voir `AGENTS.md`).
