# `data/quetes.json` — format 1

Le **catalogue des quêtes** de la campagne (2026-11-11) : celles qu'on propose aux héros (le panneau de la garde d'une ville, les contrats d'une guilde, les demandes d'un PNJ), chacune avec qui la donne, son importance, le niveau conseillé, ses récompenses et ce qu'il faut pour la proposer. Facultatif : sans lui, le widget **Quêtes** ne montre que les quêtes que le MJ crée dans le gestionnaire. Les quêtes s'activent dans la fenêtre Campagne (onglet « Quêtes et réputation »).

Ce n'est pas le déroulé : une quête est une offre, que les héros prennent ou non. Quand une quête a sa part de trame (une enquête sur plusieurs lieux, un combat prévu), elle **renvoie** au déroulé ([deroule-campagne.md](deroule-campagne.md)) par ses `etapes` : accepter la quête démarre la première. Les jalons et les pistes d'une quête ne paraissent pas dans le Déroulé tant que la quête n'est pas prise.

Ce qu'en fait le MJ (quêtes prises, réussies, cachées, récompenses versées, quêtes créées) va dans `etat/quetes.json` ([etat.md](etat.md)) ; ce fichier n'est jamais modifié. La réputation que donnent les quêtes : `etat/reputation.json`.

Fichier « déjà arbitré » : conventions dans [README.md](README.md) (enveloppe, provenance, `original`, `decision_mj`, pas d'`ecarts`).

## Contenu

| Champ | Obligatoire | Contenu |
|---|---|---|
| `resume` | conseillé | Ce que contient le fichier. |
| `types` | non | `{ "<id>": "Libellé" }` : les genres de quêtes de la campagne. Absent : les types d'office du gestionnaire (voir « Types de quêtes » plus bas) ; donné, il les remplace tous. |
| `importances` | non | Pour renommer ou recolorer les quatre importances : `{ "<importance>": { "libelle": "…", "couleur": "<jeton de la charte>" } }` (un système de couleurs propre à la campagne : `{ "anecdotique": { "libelle": "Blanche", "couleur": "cendre" } }`). Le MJ peut aussi les régler dans la fenêtre Campagne, qui l'emporte. |
| `quetes` | oui | Voir ci-dessous. Tableau, dans l'ordre où le MJ les découvrirait (par donneur, puis par importance). |

### `quetes[]`

| Champ | Obligatoire | Contenu |
|---|---|---|
| `id` | oui | Identifiant stable (`loups-du-col`, `escorte-du-convoi-de-sel`). Jamais `mj-…` (réservé aux quêtes créées par le MJ). |
| `nom` | oui | Le titre de l'annonce, tel que les joueurs le lisent (« Des loups au col de Brenn »). |
| `faction` | conseillé | `id` de [factions.json](factions.md) : la faction qui propose la quête (la garde, une guilde). Le widget range les quêtes par donneur. |
| `pnj` | non | `id` de [pnj.json](pnj.md) : la personne qui la propose ou à qui s'adresser. Une quête a une `faction`, un `pnj`, ou les deux. |
| `lieu` | non | `id` de [lieux.json](lieux.md) : où on la prend (le poste de garde, le panneau de la place). |
| `importance` | oui | `anecdotique`, `mineure`, `majeure` ou `epique`. Sa couleur sur le panneau (renommable : `importances`). |
| `type` | non | Une clé de `types`. |
| `niveau` | conseillé | Le **niveau optimal** de la quête : un entier de 1 à 20 (`3`). Le gestionnaire le compare au niveau moyen des héros (difficulté pour le groupe, pour le MJ seul : facile à deux niveaux au-dessus ou plus, adaptée au niveau ou un au-dessus, difficile un ou deux en dessous, dangereuse trois ou plus). Avant le 2026-11-12, un intervalle `{ "min": 3, "max": 5 }` : encore lu (son milieu), avec un avertissement du bouton Données. |
| `description` | oui | Ce que lisent les joueurs : l'annonce, la demande. Jamais de secret. |
| `mj` | non | Pour le MJ seul : ce qui se passe vraiment, comment la mener, les pièges. |
| `objectifs` | non | Des chaînes : ce qu'il faut faire (« Ramener la tête du loup alpha »). Visibles des joueurs. |
| `recompenses` | conseillé | Voir ci-dessous. |
| `recompenses_cachees` | non | `true` : aucune récompense n'est montrée aux joueurs (« à négocier »). Le MJ peut le changer dans le gestionnaire. |
| `conditions` | non | Ce qu'il faut pour que la quête soit proposée. Voir ci-dessous. Toutes doivent être remplies. Sans conditions : proposée d'office. |
| `etapes` | non | Ce qu'accepter la quête démarre, et la suite : `[{ "jalon": "<id>" }, { "piste": "<id>" }…]`, dans l'ordre, chaque élément un jalon **ou** une piste de [deroule-campagne.json](deroule-campagne.md). Accepter la quête démarre (ou commence) le premier ; les suivants se jouent dans le Déroulé. L'avancée de la quête : ses étapes terminées sur le total. Une quête simple n'en a pas. |
| `jalon` | non | `id` d'un jalon auquel la quête se **rattache**, sans le démarrer (« Les quêtes de la garde » : le jalon où les héros découvrent le panneau). La quête est citée dans la fenêtre du jalon. |
| `rencontres` | non | `id` de `rencontres_scenarisees[]` de [rencontres-aleatoires.json](rencontres-aleatoires.md) que la quête prévoit : à lancer depuis la fenêtre de la quête. |
| `agenda` | non | `id` d'une entrée de [agenda.json](agenda.md) liée à la quête (un délai, une date). |
| `echeance_jours` | non | Nombre de jours de jeu pour la mener, à compter de son acceptation : le widget le rappelle (jours restants, dépassée). |
| `rejouable` | non | `true` : une fois réussie ou échouée, la quête revient au panneau (une chasse qui revient chaque saison). Sa fiche garde chaque fois qu'elle a été faite. |
| `secret` | non | `true` : la quête n'est pas montrée aux joueurs d'office (le MJ la sort quand il veut, dans le gestionnaire). |
| `original`, `decision_mj` | non | Voir [README.md](README.md). |
| `source`, `fiche` | oui | |

### `recompenses[]`

Chaque récompense a un `type` et, au besoin, `cachee: true` (pas montrée aux joueurs, les autres oui).

| `type` | Champs | Contenu |
|---|---|---|
| `or` | `montant` (nombre entier, en po), `texte` (facultatif) | « 50 po ». Marquée réussie, la quête ouvre « Donner de l'or » (depuis le 2026-11-12) : à un héros, partagé entre les héros ou à la bourse du groupe, écrit sur D&D Beyond par l'extension du MJ, ou seulement noté. |
| `objet` | `objet` (`id` de [objets.json](objets.md)) | L'objet, à donner par « Donner » (widget Objets) quand la quête est réussie. |
| `reputation` | `faction` (`id` de factions.json), `valeur` (nombre entier, positif ou négatif) | La réputation gagnée ou perdue auprès de cette faction (échelle de −1000 à +1000 par défaut : +25 pour une petite quête, +100 pour une grande). Appliquée quand le MJ coche la récompense, si la réputation est activée. |
| `autre` | `texte` | Tout le reste : une faveur, un titre, un droit de passage, une information. |

Une réputation **perdue** à l'échec d'une quête : `{ "type": "reputation", "faction": "…", "valeur": -50, "si": "echec" }` (`si` : `reussite`, d'office, ou `echec`). De même pour les autres types.

### `conditions[]`

| `type` | Champs | Remplie quand… |
|---|---|---|
| `reputation` | `faction`, et `rang` (`id` d'un rang de réputation, voir ci-dessous) ou `valeur` (nombre) | la réputation du groupe auprès de la faction atteint ce rang ou cette valeur. Ignorée si la réputation n'est pas activée. |
| `quete` | `quete` (`id` d'une quête de ce fichier) | cette quête a été réussie. |
| `jalon` | `jalon`, `statut` (facultatif : `en-cours` ou `termine`, d'office `termine`) | le jalon du déroulé a ce statut (ou l'a dépassé). |
| `piste` | `piste`, `statut` (facultatif : `en-cours` ou `termine`, d'office `en-cours`) | la piste est commencée (ou terminée). |
| `etape` | `etape`, `statut` (comme `jalon`, d'office `en-cours`) | l'étape du déroulé a ce statut. |
| `niveau` | `min` | le niveau moyen des héros atteint `min`. |

Une quête dont les conditions ne sont pas remplies est « verrouillée » : le MJ la voit (grisée, avec ce qui manque), les joueurs non.

## Types de quêtes

Le type dit **la nature** d'une quête (ce qu'on y fait) ; l'importance dit **son enjeu** (sa couleur sur le panneau). Ce sont deux axes séparés : une livraison peut être épique, une enquête anecdotique.

Sans `types` dans le fichier, le gestionnaire propose ceux-ci, d'office :

| `id` | Libellé | Ce qu'on y fait |
|---|---|---|
| `chasse` | Chasse | Abattre une bête, une meute, un monstre ; une prime. |
| `escorte` | Escorte | Accompagner quelqu'un ou un convoi d'un point à un autre. |
| `enquete` | Enquête | Trouver un coupable, un secret, la cause de quelque chose. |
| `livraison` | Livraison | Porter un objet, un message, des fonds. |
| `protection` | Protection | Tenir un lieu, une personne, un événement contre une menace. |
| `recuperation` | Récupération | Retrouver ou reprendre un objet perdu, volé, caché. |
| `sauvetage` | Sauvetage | Ramener des disparus, des prisonniers, des otages. |
| `exploration` | Exploration | Atteindre, cartographier ou fouiller un lieu inconnu. |
| `diplomatie` | Diplomatie | Négocier, convaincre, porter une parole, réconcilier. |
| `infiltration` | Infiltration | Entrer quelque part sans être vu, espionner, voler. |

**Pour l'agent IA de campagne** : réutiliser ces `id` quand ils conviennent (le gestionnaire les connaît d'office). Ne donner `types` que si la campagne en a besoin d'autres, et alors les donner **tous** (ceux d'office qu'on garde compris : `types` les remplace). Pistes selon le genre de campagne : `contrat` ou `prime` pour une guilde de mercenaires, `rituel` ou `exorcisme` pour une campagne d'horreur, `commerce` pour une campagne marchande, `course` ou `tournoi` pour des épreuves, `quete-personnelle` pour le fil d'un héros. Un `id` en minuscules, sans accent, avec des tirets ; un libellé court (un ou deux mots), il tient dans un badge. Une quête n'a qu'un type : choisir ce qu'on y fait le plus (une escorte qui tourne à l'embuscade reste une escorte).

## Rangs de réputation

La réputation (option de campagne, fenêtre Campagne) va de −1000 à +1000 par défaut, en sept rangs que le MJ peut renommer et redécouper : `hai` (Haï), `hostile` (Hostile), `mefiant` (Méfiant), `neutre` (Neutre), `apprecie` (Apprécié), `honore` (Honoré), `exalte` (Exalté). Une condition `rang` cite l'un de ces `id`, ou celui d'un rang créé par le MJ.

## Exemple

```json
{
  "jeu": "quetes", "schema": 1, "titre": "Quêtes d'Aurval", "genere_le": "2026-11-11",
  "types": { "chasse": "Chasse", "escorte": "Escorte", "enquete": "Enquête" },
  "quetes": [
    {
      "id": "loups-du-col", "nom": "Des loups au col de Brenn",
      "faction": "guet-de-castelroc", "lieu": "castelroc", "importance": "mineure", "type": "chasse", "niveau": 2,
      "description": "Une meute attaque les bergers du col. Le guet paie pour chaque loup abattu.",
      "recompenses": [{ "type": "or", "montant": 40 }, { "type": "reputation", "faction": "guet-de-castelroc", "valeur": 30 }],
      "rejouable": true, "source": "MJ", "fiche": "Quêtes du guet"
    },
    {
      "id": "voleur-des-archives", "nom": "Le voleur des archives",
      "faction": "guet-de-castelroc", "pnj": "capitaine-orvel", "importance": "majeure", "type": "enquete", "niveau": 4,
      "description": "Des registres ont disparu des archives du guet. Discrétion exigée.",
      "mj": "Le voleur est le greffier lui-même, payé par le Cercle du Chardon.",
      "conditions": [{ "type": "reputation", "faction": "guet-de-castelroc", "rang": "apprecie" }],
      "etapes": [{ "piste": "indices-des-archives" }, { "jalon": "confronter-le-greffier" }],
      "recompenses": [{ "type": "or", "montant": 150 }, { "type": "objet", "objet": "insigne-du-guet" }, { "type": "reputation", "faction": "guet-de-castelroc", "valeur": 100 }],
      "source": "MJ", "fiche": "Quêtes du guet"
    }
  ]
}
```

## Ce que fait le gestionnaire

- Widget **Quêtes** : les quêtes par donneur (faction, PNJ), triées par importance, avec leur couleur, le niveau optimal et une pastille de difficulté pour le groupe (facile, adaptée, difficile, dangereuse, d'après le niveau moyen des héros relevé sur D&D Beyond) ; filtres (statut, importance, donneur) ; « + Quête » pour une quête simple créée par le MJ. Un clic ouvre la fenêtre de la quête : « Accepter » (démarre la première étape), « Réussie », « Échouée », « Abandonner », la remarque du MJ, les récompenses à cocher (réputation appliquée, objet à donner), la cacher aux joueurs, cacher ses récompenses.
- Déroulé : les jalons et pistes des `etapes` d'une quête ne paraissent qu'une fois la quête prise (ou s'ils sont déjà commencés).
- Écran des joueurs (plugin) : des panneaux des quêtes proposées, réglés dans le gestionnaire (`quetes.panneaux` de `etat/campagne.json`, pas dans `data/`) : donneurs, importances, intervalle de niveau optimal, ce que les joueurs voient du niveau (niveau, difficulté pour le groupe, rien) ; sans les quêtes cachées ni la partie MJ.
- Fin de session : les quêtes prises, réussies ou échouées, et la réputation gagnée ou perdue.

## Contrôles faits par le gestionnaire

`id` uniques, jamais `mj-…` ; `nom`, `description` et `importance` (l'une des quatre) présents ; `type` connu de `types` s'il y en a ; `faction`, `pnj`, `lieu`, `jalon`, `rencontres`, `agenda`, les `etapes` et les renvois des `recompenses` et `conditions` existent dans leurs fichiers (avertissement seulement si le fichier visé n'est pas chargé) ; `niveau` est un entier de 1 à 20 (un ancien `{ min, max }` : avertissement) ; `montant` et `valeur` sont des entiers ; une condition `quete` ne cite pas la quête elle-même.
