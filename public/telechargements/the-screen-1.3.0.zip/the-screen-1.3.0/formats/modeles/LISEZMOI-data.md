# Données de la campagne : instructions pour l'IA qui les produit

Ce dossier contient les **données de jeu** de la campagne, en JSON, lues par le gestionnaire de campagne (lieux, PNJ, factions, déroulé, rencontres…). Tu es l'IA (un projet Claude, ou une autre) chargée de les **produire** à partir du matériel du MJ (livres, PDF, notes). Ce fichier te dit comment.

## Le contrat : `formats/`

Chaque fichier de ce dossier suit **exactement** sa fiche de format, dans le dossier `formats/` du gestionnaire (trois niveaux au-dessus d'ici : `../../../formats/`) :

1. Lis d'abord `formats/README.md` : l'enveloppe commune à tous les fichiers (`schema`, `jeu`, `titre`, `genere_le`, `avertissement`, `priorite_sources`, `sources`), la provenance de chaque élément (`source`, `fiche`), les écarts entre sources, les identifiants.
2. Puis la fiche du fichier à produire : `formats/<jeu>.md` (`formats/lieux.md` pour `lieux.json`…). Elle donne chaque champ, s'il est obligatoire, et les contrôles que fait le gestionnaire.
3. Un champ qui n'est pas dans la fiche n'est pas lu. Un format qui ne suffit pas se signale au MJ : il ne s'invente pas ici.

## Tes sources

Le matériel du MJ : ses livres, PDF et notes (souvent dans `../sources/`, à côté de ce dossier), et, si la campagne a un wiki, son import : `../wiki/wiki-complet.md` (toutes les pages, en Markdown ; `<secret>…</secret>` : connu du MJ, pas des joueurs) et `../wiki/changements.md` après une séance ([formats/wiki.md](../../../formats/wiki.md)). Le gestionnaire ne lit pas ces sources : c'est toi qui les traduis dans les fichiers de ce dossier.

## Par où commencer

Produis un fichier à la fois, **en un seul bloc JSON complet**, puis liste ce qui manque ou reste incertain. Dans cet ordre (chaque fichier renvoie aux précédents par leurs `id`) :

| Niveau | Fichiers | Ce que le MJ obtient |
|---|---|---|
| **Minimum** | `lieux.json`, `pnj.json`, `deroule-campagne.json` | Ici, PNJ, Déroulé : une campagne jouable |
| **Confortable** | `factions.json`, `personnages.json`, `temps-de-voyage.json`, `rencontres-aleatoires.json`, `objets.json`, `quetes.json` (si le MJ a activé les quêtes : catalogue des quêtes proposées par les factions et les PNJ), `marchands.json`, `calendrier.json` | Factions, héros, voyages, rencontres aléatoires, objets à trouver, boutiques, calendrier |
| **Complet** | `connaissances.json` (intrigues secrètes, savoir commun), `babioles.json`, `noms.json`, `faune.json`, `occupants-maisons.json`, `meteo.json` | Le reste des outils |

Une campagne n'a pas besoin de tout : un fichier absent retire simplement l'outil qui le lit.

Le **calendrier** et la **météo** sont des réglages de la campagne (fenêtre Campagne, onglet « Campagne ») : le gestionnaire fournit les calendriers Classique, Barovien (pour *Curse of Strahd*) et Royaumes oubliés, et deux météos réelles (Carcassonne et Tallinn, deux ans chacune ; une autre ville avec `outils/Importer la météo.cmd`). Les fêtes et anniversaires propres à la campagne (l'anniversaire d'un PNJ, une fête locale) vont dans `jours-marques.json` ([formats/jours-marques.md](../../../formats/jours-marques.md)), qui s'ajoute au calendrier choisi ; ce qui arrive **une fois**, à une date (un délai, un rendez-vous, une fête de l'année en cours), va dans l'agenda, `agenda.json` ([formats/agenda.md](../../../formats/agenda.md)), que le MJ complète aussi dans l'Horloge. N'écris `calendrier.json` que pour un calendrier propre au monde (365 jours, ses mois, sa semaine, sa lune, ses fêtes) : l'Horloge n'en montre que les textes que tu donnes (présentation, sens et divinité des jours, coutumes, règle de la lune, jours marqués), rien d'autre à leur place. N'écris pas `meteo.json` : la météo vient d'une ville réelle.

## Règles qui ne se discutent pas

- **Les `id` sont stables** : minuscules, chiffres et tirets (`cite-d-aurval`), uniques, jamais renommés d'un export à l'autre (l'état de la campagne, dans `etat/`, s'y réfère).
- **Chaque renvoi existe** : un lieu cité dans `pnj.json` existe dans `lieux.json`, un PNJ cité dans le déroulé existe dans `pnj.json`…
- **Les secrets restent au MJ** : ce que les joueurs ne doivent pas savoir va dans les champs réservés au MJ que nomment les fiches (`secret_mj`, `note_mj`, factions `secret`…), jamais dans un texte à lire.
- **Noms officiels** de la langue de la campagne, tels que le MJ les emploie.
- **Ne modifie jamais un fichier de ce dossier « à la main » par petites touches** : réexporte le fichier entier, au format de sa fiche.
- **Ne touche jamais au gestionnaire** (`app/`, `formats/`, `design-system/`, `scripts/`, `lancer.ps1`…) ni à `etat/` : voir `AGENTS.md` à la racine du gestionnaire. Si le MJ veut un champ ou un outil de plus, il le demande au mainteneur du gestionnaire ; un gestionnaire modifié ne reçoit plus les mises à jour officielles.

## Les personnages joueurs

`personnages.json` est le lore des héros tel que le gestionnaire le montre (onglets Lore et Secret de leurs fiches) : `accroche`, `apparence`, `personnalite`, `origine`, `motivations`, `allegeances`, `objets_notables`, et `secrets` pour ce que les autres joueurs ignorent. Tire-le des sources (fiches du wiki, notes des joueurs). `portrait` (facultatif) : le chemin d'une image depuis le dossier de la campagne, ou son adresse ; sans lui, le gestionnaire prend l'avatar de la feuille D&D Beyond.

Le MJ peut retoucher ce lore dans le gestionnaire. Ses retouches te reviennent dans le prompt de fin de session (« Lore retouché par le MJ ») : **reprends-les** dans `personnages.json`, dans les mêmes champs, mot pour mot, au prochain export (le gestionnaire ne les oublie que lorsque le fichier dit exactement la même chose) ; elles font foi sur le wiki.

## Vérifier

Le MJ recharge la page du gestionnaire, puis ouvre le bouton **Données** de l'en-tête : chaque fichier y est marqué « À jour », ou la liste précise de ce qui ne va pas (champ manquant, renvoi inconnu, `id` en double). Corrige d'après cette liste et réexporte le fichier entier.

## Après chaque séance

Le gestionnaire fait foi pour l'avancée de la campagne. Son bouton **Session** donne un prompt avec l'état noté pendant la séance ; ton analyse se termine par un bloc `maj-etat` (`formats/maj-etat.md`), que le MJ colle dans le gestionnaire et valide. Tu n'écris jamais dans `etat/` toi-même.
