// Fiche d'un PNJ de data/pnj.json, avec son suivi de campagne (etat/pnj.json).
// Partagée par le widget PNJ, les marchands (tenanciers), le Déroulé, Qui sait quoi et Factions. Elle s'ouvre dans une
// fenêtre flottante (une par PNJ), jamais dépliée dans la liste.
// Rang (vip, majeur, mineur) : puce VIP / M / m, cliquable pour le changer en jeu. Factions : data/factions.json.

import { h, icone, badge, section, provenance, blocOriginal, flottant, flottantOuvert, lienFlottant } from './ui.js';
import { nomLieu } from './lieux.js';
import { couleurFaction, wikiActif } from './campagne.js';
import { chargerBibliotheque } from './bibliotheque.js';
import { chargerDonnees } from './donnees.js';
import { etat } from './etat.js';
import { reputationChargee, reputationActive, factionSuivie, blocReputation } from './reputation.js';
import { ouvrirQuete } from './quetes.js';

export const ETATS_EN_JEU = [
  ['', '— Comme dans le fichier —'],
  ['vivant', 'Vivant'],
  ['mort', 'Mort'],
  ['mort-vivant', 'Mort-vivant'],
  ['disparu', 'Disparu'],
  ['absent', 'Absent'],
];
const LIBELLE_ETAT = Object.fromEntries(ETATS_EN_JEU);

export const RANGS = ['vip', 'majeur', 'mineur'];
export const RANG_COURT = { vip: 'VIP', majeur: 'M', mineur: 'm' };
const LIBELLE_RANG = { vip: 'VIP', majeur: 'Majeur', mineur: 'Mineur' };

export async function etatPnj(etat) {
  const s = await etat('pnj', { schema: 1, pnj: {} });
  s.valeur.pnj ||= {};
  return s;
}

// data/factions.json : { parId: Map, types } ou null s'il n'est pas là.
// Intrigues secrètes de la campagne (`intrigues` de connaissances.json) : nom et icône, pour les savoirs des PNJ. Lues avec
// les factions, que chargent tous les widgets qui montrent des PNJ.
const INTRIGUES = new Map();
const intrigue = id => INTRIGUES.get(id) || { id, nom: String(id).charAt(0).toUpperCase() + String(id).slice(1).replace(/[-_]/g, ' '), icone: 'glyphe' };
export const intriguesConnues = () => [...INTRIGUES.values()];

export async function chargerFactions(donnees) {
  for (const x of (await donnees('connaissances')).donnees?.intrigues || []) INTRIGUES.set(x.id, { id: x.id, nom: x.nom || x.id, court: x.court, icone: x.icone || 'glyphe' });
  const f = (await donnees('factions')).donnees;
  return f?.factions ? { parId: new Map(f.factions.map(x => [x.id, x])), types: f.types || {}, liste: f.factions } : null;
}

export function suiviDe(s, id) { return s.valeur.pnj[id] || {}; }

// État retenu : celui noté en jeu (etat/pnj.json), sinon celui du fichier (pnj.etat), sinon vivant.
export function etatEffectif(p, suivi) { return suivi.etat || p.etat || 'vivant'; }

// Rang du fichier : rang, sinon déduit de « important » (anciens exports).
export function rangFichier(p) { return RANGS.includes(p.rang) ? p.rang : p.important ? 'majeur' : 'mineur'; }

// Rang retenu : celui choisi en jeu (etat/pnj.json, « rang »), sinon le fichier. Un ancien choix « important » compte encore.
export function rangDe(p, suivi) {
  if (RANGS.includes(suivi.rang)) return suivi.rang;
  const f = rangFichier(p);
  if (typeof suivi.important === 'boolean') return suivi.important ? (f === 'mineur' ? 'majeur' : f) : 'mineur';
  return f;
}

// Important : VIP ou majeur, au rang retenu.
export function estImportant(p, suivi) { return rangDe(p, suivi) !== 'mineur'; }

// Badges courts pour une ligne de liste ou une fiche (le rang et « rencontré » ont leurs boutons).
// L'état n'apparaît que s'il n'est pas « vivant », ou s'il a été changé en jeu ; « statut » le précise (sauf statut: false).
export function badgesPnj(p, suivi, { statut = true } = {}) {
  const etat = etatEffectif(p, suivi);
  const change = suivi.etat && suivi.etat !== (p.etat || 'vivant');
  return [
    etat !== 'vivant' || change ? badge(LIBELLE_ETAT[etat] + (change ? ' (en jeu)' : ''), etat === 'vivant' ? 'brume' : change ? 'sang' : 'cierge') : null,
    statut && p.statut && !change ? badge(p.statut, null) : null,
  ];
}

// Factions affichables d'un PNJ : les secrètes seulement si secrets est vrai.
export function factionsDe(p, factions, secrets = false) {
  if (!factions) return [];
  return (p.factions || []).map(id => factions.parId.get(id)).filter(f => f && (secrets || !f.secret));
}

// Badge de faction (composant Badge, variante faction). surClic : le badge devient un bouton (filtrer sur la faction).
export function badgeFaction(f, { surClic, petit = false } = {}) {
  const fac = couleurFaction(f);   // un jeton de la charte (app/campagne.js) ; sans couleur, la pastille reste en cendre
  const attrs = { class: `bn-badge bn-badge--faction${petit ? ' cm-badge-mini' : ''}${f.secret ? ' cm-faction-secrete' : ''}`, style: fac ? `--fac: var(--${fac})` : null, title: f.secret ? `${f.nom} (secret de campagne)` : f.nom };
  const contenu = [h('span', { class: 'bn-badge__point' }), f.nom, f.secret ? icone('lu-eye-off', 'bn-icone--s') : null];
  return surClic
    ? h('button', { type: 'button', ...attrs, class: attrs.class + ' cm-faction-bouton', title: `Voir les PNJ : ${f.nom}`, onclick: e => { e.preventDefault(); e.stopPropagation(); surClic(f); } }, contenu)
    : h('span', attrs, contenu);
}

// Repère des savoirs : ce PNJ peut faire avancer les PJ sur une intrigue secrète (où sont les reliques, par exemple).
export function repereSavoirs(p) {
  const ids = Object.keys(p.savoirs || {});
  if (!ids.length) return null;
  return h('span', { class: 'cm-repere-savoir', title: `Peut renseigner : ${ids.map(id => intrigue(id).nom).join(', ')}` }, icone(intrigue(ids[0]).icone, 'bn-icone--s'));
}

// Puce de rang VIP / M / m (VIP en puce rose néon, M orange, m gris) : un clic passe au rang suivant. Revenir au rang du fichier efface le choix.
export function boutonRang(p, s, surChange, typesRang = {}) {
  const suivi = suiviDe(s, p.id);
  const rang = rangDe(p, suivi);
  const change = rang !== rangFichier(p);
  const suivant = RANGS[(RANGS.indexOf(rang) + 1) % RANGS.length];
  const libelle = typesRang[rang] || LIBELLE_RANG[rang];
  return h('button', {
    type: 'button', class: `cm-vu cm-rang cm-rang--${rang}${change ? ' est-change' : ''}`,
    'aria-label': `${p.nom} : ${libelle}${change ? ' (changé en jeu)' : ''}. Cliquer pour passer à ${LIBELLE_RANG[suivant].toLowerCase()}.`,
    title: `${libelle}${change ? ` · changé en jeu (fichier : ${LIBELLE_RANG[rangFichier(p)].toLowerCase()})` : ''}\nCliquer : ${LIBELLE_RANG[suivant].toLowerCase()}`,
    onclick: e => {
      e.preventDefault();
      e.stopPropagation();
      const sv = (s.valeur.pnj[p.id] ||= {});
      delete sv.important;
      if (suivant === rangFichier(p)) delete sv.rang; else sv.rang = suivant;
      if (!Object.keys(sv).length) delete s.valeur.pnj[p.id];
      s.enregistrer(0);
      surChange?.();
    },
  }, RANG_COURT[rang]);
}

// Bouton « Vu » : le PNJ a été rencontré. Cliquable au bout d'une ligne de liste, sans ouvrir la fiche.
export function boutonVu(p, s, surChange) {
  const vu = !!suiviDe(s, p.id).rencontre;
  return h('button', {
    type: 'button', class: 'cm-vu' + (vu ? ' est-vu' : ''), 'aria-pressed': String(vu),
    'aria-label': vu ? `${p.nom} : déjà rencontré (cliquer pour annuler)` : `Marquer ${p.nom} comme rencontré`,
    title: vu ? 'Déjà rencontré' : 'Pas encore rencontré',
    onclick: e => {
      e.preventDefault();
      e.stopPropagation();
      const suivi = (s.valeur.pnj[p.id] ||= {});
      if (vu) delete suivi.rencontre; else suivi.rencontre = true;
      if (!Object.keys(suivi).length) delete s.valeur.pnj[p.id];
      s.enregistrer(0);
      surChange?.();
    },
  }, icone(vu ? 'oeil' : 'lu-eye-off', 'bn-icone--s'), h('span', {}, 'Vu'));
}

// surChange() : appelé après chaque modification du suivi (pour redessiner les autres vues).
// factions (chargerFactions), secrets (montrer les factions secrètes), surFaction(f) (clic sur une faction), typesRang.
export function fichePnj(p, { lieux, s, surChange, factions = null, secrets = false, surFaction = null, typesRang = {} }) {
  const suivi = () => (s.valeur.pnj[p.id] ||= {});
  const maj = (cle, val, delai = 0) => {
    if (val === '' || val === false) delete suivi()[cle]; else suivi()[cle] = val;
    if (!Object.keys(suivi()).length) delete s.valeur.pnj[p.id];
    s.enregistrer(delai);
    surChange?.();
  };
  const sousLieu = lieux.get(p.sous_lieu);
  const ou = [nomLieu(lieux, p.lieu), sousLieu && sousLieu.nom !== nomLieu(lieux, p.lieu) ? sousLieu.nom : null, sousLieu?.zone ? `zone ${sousLieu.zone}` : null].filter(Boolean).join(', ');
  const etatSelect = h('select', { class: 'bn-select', onchange: e => maj('etat', e.target.value) },
    ETATS_EN_JEU.map(([val, txt]) => h('option', { value: val }, val ? txt : `— Comme dans le fichier : ${LIBELLE_ETAT[p.etat || 'vivant'].toLowerCase()} —`)));
  etatSelect.value = suiviDe(s, p.id).etat || '';
  const tete = h('div', { class: 'bn-groupe cm-fiche-pnj__tete' });
  const ligneRang = h('p', { class: 'ui-s' });
  const apres = () => { majTete(); surChange?.(); };
  const majTete = () => {
    tete.replaceChildren(...[boutonRang(p, s, apres, typesRang), p.profil ? (b => { b.classList.add('cm-badge-profil'); return b; })(badge(p.profil, 'ultra')) : null, ...badgesPnj(p, suiviDe(s, p.id)), boutonVu(p, s, apres)].filter(Boolean));
    const r = rangDe(p, suiviDe(s, p.id));
    ligneRang.replaceChildren(h('b', {}, 'Rang : '), typesRang[r] || LIBELLE_RANG[r], r !== rangFichier(p) ? ` (changé en jeu ; fichier : ${LIBELLE_RANG[rangFichier(p)].toLowerCase()})` : '');
  };
  majTete();
  const fs = factionsDe(p, factions, secrets);
  const cachees = factions ? (p.factions || []).filter(id => factions.parId.get(id)?.secret).length - fs.filter(f => f.secret).length : 0;
  // Ses images de la galerie (demande du MJ, 2026-10-25) : rapprochées d'après le nom du fichier ou étiquetées à son nom par le
  // MJ (app/bibliotheque.js, comme le filtre PNJ du widget Images), sans les versions joueurs ; un clic ouvre l'image. Rien si
  // la bibliothèque n'est pas indexée sur ce poste.
  const images = h('div', { class: 'cm-fiche-pnj__images' });
  chargerBibliotheque(chargerDonnees, etat).then(b => {
    const liste = b ? b.index.images.filter(i => !i.joueurs && b.pnjDe(i).includes(p.id)) : [];
    if (liste.length) images.replaceChildren(section(`Images (${liste.length})`, 'carte', h('div', { class: 'cm-vignettes' }, liste.map(b.vignette))));
  }).catch(() => {});
  return h('div', { class: 'cm-pile cm-fiche-pnj' },
    tete,
    h('p', { class: 'cm-lieu' }, icone('epingle', 'bn-icone--s'), ou),
    p.role ? h('p', { class: 'ui-l' }, p.role) : null,
    p.description ? h('p', { class: 'texte' }, p.description) : null,
    ligneRang,
    fs.length || cachees ? h('div', { class: 'bn-groupe cm-badges' }, h('span', { class: 'ui-s' }, h('b', {}, 'Factions : ')),
      fs.map(f => badgeFaction(f, { surClic: surFaction })),
      cachees ? h('span', { class: 'ui-s cm-sourdine', title: 'Faction secrète : « Afficher les secrets » dans le widget PNJ' }, icone('lu-eye-off', 'bn-icone--s'), ` ${cachees} secrète${cachees > 1 ? 's' : ''}`) : null) : null,
    h('p', { class: 'ui-s' }, h('b', {}, 'État : '), LIBELLE_ETAT[p.etat || 'vivant'].toLowerCase(), p.statut ? ` (${p.statut})` : '', ' au début de la campagne'),
    p.alias?.length ? h('p', { class: 'ui-s cm-sourdine' }, 'Aussi appelé : ' + p.alias.join(', ')) : null,
    wikiActif() && p.wiki?.url ? h('p', { class: 'ui-s' }, h('a', { class: 'bn-lien', href: p.wiki.url, target: '_blank', rel: 'noopener' }, 'Page du wiki des joueurs')) : null,
    p.aussi?.length ? h('p', { class: 'ui-s cm-sourdine' }, 'Se croise aussi : ' + p.aussi.map(id => nomLieu(lieux, id)).join(', ')) : null,
    Object.entries(p.savoirs || {}).map(([id, texte]) => section(`Ce qu'il sait : ${intrigue(id).nom}`, intrigue(id).icone, h('p', { class: 'ui' }, texte))),
    p.decision_mj ? h('div', { class: 'cm-decision' }, badge('Décision du MJ', 'sang'), h('p', { class: 'ui' }, p.decision_mj.texte)) : null,
    blocOriginal(p.original),
    images,
    section('Suivi de campagne', 'livre',
      h('label', { class: 'bn-champ cm-champ-court' }, h('span', { class: 'bn-champ__label' }, 'État en jeu'), etatSelect),
      h('textarea', { class: 'bn-textarea cm-notes', rows: 2, 'aria-label': `Notes sur ${p.nom}`, placeholder: 'Ce que les PJ savent de lui, ce qu\'il pense d\'eux…', oninput: e => maj('note', e.target.value.trim() ? e.target.value : '', 800) }, suiviDe(s, p.id).note || '')),
    provenance(p));
}

// Badges d'une ligne de liste : l'état seul, en petit badge devant le rôle (les factions ont leur ligne, factionEnLigne).
export function badgesLignePnj(p, s) {
  return badgesPnj(p, suiviDe(s, p.id), { statut: false }).filter(Boolean).map(b => { b.classList.add('cm-badge-mini'); return b; });
}

// Faction dans une ligne de liste : pastille de couleur et nom, sans cadre (le badge complet est dans la fiche).
function factionEnLigne(f) {
  const fac = couleurFaction(f);
  return h('span', { class: 'cm-pnj__faction' + (f.secret ? ' cm-faction-secrete' : ''), style: fac ? `--fac: var(--${fac})` : null, title: f.secret ? `${f.nom} (secret de campagne)` : null },
    h('span', { class: 'bn-badge__point' }), f.nom, f.secret ? icone('lu-eye-off', 'bn-icone--s') : null);
}

// Ligne d'un PNJ (widgets PNJ et Ici) : le nom sur toute la largeur, puis l'état (petit badge) et le rôle, puis les factions
// en pastilles ; rang et « Vu » à droite. Un clic ouvre la fiche dans une fenêtre flottante.
// aussi : PNJ rangé ailleurs (« d'ordinaire : … »). complement : précision ajoutée au rôle (le sous-lieu).
// Les autres options sont celles de fichePnj.
export function lignePnj(p, { lieux, s, surChange, factions = null, secrets = false, surFaction = null, typesRang = {}, aussi = false, complement = '' }) {
  const role = [p.role, aussi ? `d'ordinaire : ${nomLieu(lieux, p.lieu)}` : '', complement].filter(Boolean).join(' · ');
  const fs = factionsDe(p, factions, secrets);
  const ligne = h('div', { class: 'cm-pnj cm-ouvre', 'data-id': p.id, onclick: () => ouvrirFichePnj(p, { lieux, s, surChange, factions, secrets, surFaction, typesRang }) },
    h('button', { type: 'button', class: 'cm-pnj__nom cm-ouvre__nom', title: 'Ouvrir la fiche' }, p.nom, repereSavoirs(p)),
    h('span', { class: 'cm-pnj__role' }, h('span', { class: 'cm-pnj__badges' }, badgesLignePnj(p, s)), role),
    fs.length ? h('span', { class: 'cm-pnj__factions' }, fs.map(factionEnLigne)) : null,
    h('span', { class: 'cm-pnj__vu' }, boutonRang(p, s, surChange, typesRang), boutonVu(p, s, surChange)));
  return lienFlottant(ligne, 'pnj:' + p.id);
}

// Après un changement de suivi : badges, rang et « Vu » de la ligne, et de sa fiche si elle est ouverte.
export function majLignePnj(ligne, p, { s, surChange, typesRang = {} }) {
  ligne.querySelector('.cm-pnj__badges').replaceChildren(...badgesLignePnj(p, s));
  ligne.querySelector('.cm-pnj__vu').replaceChildren(boutonRang(p, s, surChange, typesRang), boutonVu(p, s, surChange));
  const tete = flottantOuvert('pnj:' + p.id)?.el.querySelector('.cm-fiche-pnj__tete');
  if (tete) { tete.querySelector('.cm-rang')?.replaceWith(boutonRang(p, s, surChange, typesRang)); tete.querySelector('.cm-vu:not(.cm-rang)')?.replaceWith(boutonVu(p, s, surChange)); }
}

// Fiche d'un PNJ dans une fenêtre flottante (une par PNJ : rouverte, elle revient devant). Options de fichePnj ;
// sans surChange, les autres widgets sont prévenus (s.signaler()).
export function ouvrirFichePnj(p, opts) {
  const surChange = opts.surChange || (() => opts.s.signaler());
  flottant('pnj:' + p.id, { surtitre: nomLieu(opts.lieux, p.lieu), titre: p.nom, pictogramme: 'crocs', contenu: fichePnj(p, { ...opts, surChange }) });
}

// Ancienne forme (Déroulé, Marchands, Qui sait quoi…) : même fenêtre flottante.
export function dialoguePnj(dialogue, p, { lieux, s, factions = null, typesRang = {} }) {
  ouvrirFichePnj(p, { lieux, s, factions, typesRang });
}

// Fiche d'une faction dans une fenêtre flottante (widgets Factions, Ici, Babioles) : un clic sur un membre ouvre sa fiche.
export function ouvrirFaction(f, { pnj, s, lieux, factions = null, typesRang = {} }) {
  const ouvrirPnj = p => ouvrirFichePnj(p, { lieux, s, factions, typesRang });
  flottant('faction:' + f.id, { surtitre: factions?.types?.[f.type] || 'Faction', titre: f.nom,
    contenu: h('div', { class: 'cm-pile cm-fiche-faction' }, h('div', { class: 'bn-groupe' }, badgeFaction(f)), ficheFaction(f, { pnj, s, lieux, ouvrirPnj })) });
}

// Membres d'une faction (pnj.json, champ factions), du plus important au plus discret, à rang égal dans l'ordre du fichier.
export function membresFaction(f, pnj, s) {
  return pnj.filter(p => (p.factions || []).includes(f.id))
    .map((p, i) => ({ p, i, r: RANGS.indexOf(rangDe(p, suiviDe(s, p.id))) }))
    .sort((a, b) => a.r - b.r || a.i - b.i).map(x => x.p);
}

// Fiche d'une faction : description, lieux (page du wiki), décision du MJ, membres. Widget Factions, liens des Babioles.
// ouvrirPnj(p) : clic sur un membre.
// Membres avec leur bouton « Vu » (il se redessine seul ; surChange() prévient le widget qui affiche la fiche).
export function ficheFaction(f, { pnj, s, lieux, ouvrirPnj, surChange = null }) {
  const gens = membresFaction(f, pnj, s);
  const vu = p => {
    const b = boutonVu(p, s, () => { b.replaceWith(vu(p)); if (surChange) surChange(); else s.signaler(); });
    b.classList.add('cm-vu--petit');
    return b;
  };
  const lienLieu = id => {
    const url = wikiActif() ? lieux.get(id)?.wiki?.url : null;
    return url ? h('a', { class: 'bn-lien', href: url, target: '_blank', rel: 'noopener', title: 'Page du wiki des joueurs' }, nomLieu(lieux, id)) : h('span', {}, nomLieu(lieux, id));
  };
  return h('div', { class: 'cm-pile' },
    h('p', { class: 'ui' }, f.description),
    f.lieux?.length ? h('p', { class: 'cm-lieu' }, icone('epingle', 'bn-icone--s'), h('span', { class: 'cm-tenanciers' }, f.lieux.map(lienLieu))) : null,
    // Réputation du groupe auprès de la faction (option de campagne, app/reputation.js).
    reputationChargee() && reputationActive() && factionSuivie(f) ? section('Réputation', 'lu-handshake', blocReputation(f, { surQuete: ouvrirQuete })) : null,
    f.decision_mj ? h('div', { class: 'cm-decision' }, badge('Décision du MJ', 'sang'), h('p', { class: 'ui' }, f.decision_mj.texte)) : null,
    blocOriginal(f.original),
    gens.length ? section('Membres', 'lu-users', h('ul', { class: 'cm-membres' }, gens.map(p => h('li', {},
      repereRang(rangDe(p, suiviDe(s, p.id))),
      h('span', { class: 'cm-membres__nom' },
        h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPnj(p) }, p.nom),
        repereSavoirs(p),
        h('span', { class: 'ui-s cm-sourdine' }, ' ', nomLieu(lieux, p.lieu))),
      vu(p))))) : h('p', { class: 'ui-s cm-sourdine' }, 'Aucun PNJ de pnj.json dans cette faction.'),
    provenance(f));
}

// Repère de rang non cliquable (listes de Qui sait quoi et de Factions).
export function repereRang(rang) {
  return h('span', { class: `cm-rang-repere cm-rang--${rang}`, title: LIBELLE_RANG[rang] }, RANG_COURT[rang]);
}
