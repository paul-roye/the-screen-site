// Trame de la campagne (deroule-campagne.json, format 2) : icônes des jalons et des pistes, et le suivi du déroulé
// (etat/deroule.json : étapes, jalons et pistes à venir, en cours ou terminés). Ce qu'un module de campagne ajoute à une
// étape (le Tarokka) : emplacements etapeRepere et etapeBloc (app/modules.js).
// Partagé par les widgets Déroulé, Ici et Personnages, la fin de session et le bouton Données.

import { h, icone, bouton } from './ui.js';

export const ICONES_JALON = { trajet: 'lu-route', rencontre: 'lu-swords', evenement: 'lu-bell', amorce: 'lu-sparkles', halte: 'chateau' };
export const ICONE_PISTE = 'lu-waypoints';

// Ouvrir un jalon, une piste ou une étape dans le widget Déroulé, s'il est dans la grille du mode affiché (pas en réserve).
export const derouleSurLeTableau = () => !!document.querySelector('.cm-tableau .bn-widget[data-type="deroule"]');
// `depuis` : l'élément cliqué, pour placer la fenêtre d'un jalon ou d'une piste qui n'a pas de ligne dans le Déroulé (quête pas prise).
export const voirJalon = (id, depuis = null) => document.dispatchEvent(new CustomEvent('cm:voir-jalon', { detail: { id, depuis } }));
export const voirPiste = (id, depuis = null) => document.dispatchEvent(new CustomEvent('cm:voir-piste', { detail: { id, depuis } }));
// Le Déroulé monté quelque part (sur le tableau, ou dans la réserve d'un autre mode) : il peut ouvrir la fenêtre d'un jalon ou d'une piste.
export const derouleMonte = () => !!document.querySelector('.bn-widget[data-type="deroule"]');
export const voirEtape = id => document.dispatchEvent(new CustomEvent('cm:voir-etape', { detail: { id } }));

// ───── Suivi du déroulé (etat/deroule.json, formats/etat.md) ─────
// suivi.etapes, suivi.jalons, suivi.pistes : { "<id>": { debut, fin } } (dates ISO). Sans entrée : à venir ; debut sans
// fin : en cours (une piste : commencée) ; fin : terminé. Plusieurs étapes, jalons et pistes peuvent être en cours à la fois.
// valide : sur un élément terminé (date ISO), le MJ a confirmé que tout est bon, même s'il reste quelque chose (app/restes.js).
// etape : l'étape de référence, la dernière démarrée (en-tête du Déroulé, « Étape suivante », fin de session). Elle ne dit
// rien des autres étapes : l'ordre des étapes n'est qu'indicatif.

export const GENRES = { etape: 'etapes', jalon: 'jalons', piste: 'pistes' };
export const LIBELLES_STATUT = {
  etape: { 'a-venir': 'à venir', 'en-cours': 'en cours', termine: 'terminée' },
  jalon: { 'a-venir': 'à venir', 'en-cours': 'en cours', termine: 'terminé' },
  piste: { 'a-venir': 'à venir', 'en-cours': 'commencée', termine: 'terminée' },
};

// Jalons devenus pistes sous un autre id à la refonte du format 2 (2026-10-13) : leur suivi passe à la piste.
// Ceux qui ont gardé leur id passent d'eux-mêmes (un id de suivi.jalons qui est maintenant une piste).
const RENOMMES = { 'pistes-vers-le-temple-d-ambre': 'semer-le-temple-d-ambre' };

// Le suivi, complété au besoin. L'ancien « jalon en cours » unique devient un jalon en cours parmi d'autres.
export function preparerSuivi(v) {
  if (!v.suivi || typeof v.suivi !== 'object') v.suivi = { etapes: v.etape ? { [v.etape]: { debut: new Date().toISOString() } } : {} };
  for (const g of Object.values(GENRES)) if (!v.suivi[g] || typeof v.suivi[g] !== 'object') v.suivi[g] = {};
  if (v.jalon) {
    v.suivi.jalons[v.jalon] ||= { debut: new Date().toISOString() };
    delete v.jalon;
  }
  return v.suivi;
}

// Jalons devenus pistes (format 2) : leur suivi passe dans suivi.pistes, mêmes dates. Renvoie [{ avant, apres }].
export function migrerSuivi(v, d) {
  const suivi = preparerSuivi(v);
  const faits = [];
  if (!d?.pistes) return faits;
  const jalons = new Set((d.jalons || []).map(j => j.id));
  const pistes = new Set(d.pistes.map(p => p.id));
  for (const [id, x] of Object.entries(suivi.jalons)) {
    if (jalons.has(id)) continue;
    const cible = pistes.has(id) ? id : pistes.has(RENOMMES[id]) ? RENOMMES[id] : null;
    if (!cible) continue;
    if (!suivi.pistes[cible]) suivi.pistes[cible] = x;
    delete suivi.jalons[id];
    faits.push({ avant: id, apres: cible });
  }
  return faits;
}

export function statutDe(v, genre, id) {
  const x = v.suivi?.[GENRES[genre]]?.[id];
  return x?.fin ? 'termine' : x?.debut ? 'en-cours' : 'a-venir';
}

// Commencer (ou rouvrir : la fin est retirée).
export function commencer(v, genre, id, quand = new Date().toISOString()) {
  const x = (preparerSuivi(v)[GENRES[genre]][id] ||= {});
  x.debut ||= quand;
  delete x.fin;
}
// Terminer : un élément jamais commencé compte comme commencé au même moment.
export function terminer(v, genre, id, quand = new Date().toISOString()) {
  const x = (preparerSuivi(v)[GENRES[genre]][id] ||= {});
  x.debut ||= quand;
  x.fin ||= quand;
}
// Rouvrir : terminé -> en cours.
export function rouvrir(v, genre, id) {
  const x = v.suivi?.[GENRES[genre]]?.[id];
  if (x) { delete x.fin; delete x.valide; }
}
// Plus en cours : l'élément redevient à venir.
export function oublier(v, genre, id) { delete v.suivi?.[GENRES[genre]]?.[id]; }

// Remarque du MJ sur une étape, un jalon ou une piste (demande du MJ, 2026-11-02 : un jalon sans rencontre a aussi son histoire) :
// remarques.jalons["<id>"] = { texte, maj } de etat/deroule.json, à part du suivi (elle survit à « Plus en cours »).
export const remarqueDe = (v, genre, id) => v.remarques?.[GENRES[genre]]?.[id] || null;
export function noterRemarque(v, genre, id, texte) {
  const propre = String(texte || '').trim();
  v.remarques ||= {};
  v.remarques[GENRES[genre]] ||= {};
  if (propre) v.remarques[GENRES[genre]][id] = { texte: propre, maj: new Date().toISOString() };
  else delete v.remarques[GENRES[genre]][id];
}

// ───── Résurgences jouées (demande du MJ, 2026-11-05) ─────
// Une résurgence (« manifestation » des données) n'a pas toujours d'`id` : sa clé est son `id`, sinon une empreinte de son
// texte (elle tient à un réordonnancement, pas à une réécriture du texte). suivi.resurgences["<piste>"]["<clé>"] = { jouee }.
function empreinte(texte) {
  const t = String(texte || '').toLowerCase().replace(/\s+/g, ' ').trim();
  let x = 5381;
  for (let i = 0; i < t.length; i++) x = ((x << 5) + x + t.charCodeAt(i)) >>> 0;
  return x.toString(36);
}
const cleTexte = m => 'r' + empreinte(m.texte);
export const cleResurgence = m => (m.id ? String(m.id) : cleTexte(m));
// Lecture : sous son `id`, sinon sous l'empreinte de son texte. Une résurgence cochée ou remarquée avant de recevoir son
// `id` garde ainsi son suivi, tant que l'export qui lui donne l'`id` ne retouche pas son texte ; la prochaine écriture le
// range sous l'`id`.
const lue = (table, m) => table?.[cleResurgence(m)] ?? (m.id ? table?.[cleTexte(m)] : undefined);
const retirer = (table, m) => { delete table[cleResurgence(m)]; if (m.id) delete table[cleTexte(m)]; };
export const suiviResurgence = (v, pisteId, m) => lue(v.suivi?.resurgences?.[pisteId], m) || null;
export const resurgenceJouee = (v, pisteId, m) => !!suiviResurgence(v, pisteId, m)?.jouee;
export function jouerResurgence(v, pisteId, m, oui = true, quand = new Date().toISOString()) {
  const s = preparerSuivi(v);
  s.resurgences ||= {};
  const p = (s.resurgences[pisteId] ||= {});
  retirer(p, m);
  if (oui) p[cleResurgence(m)] = { jouee: quand, texte: String(m.texte || '').slice(0, 80) };   // le début du texte : pour s'y retrouver dans le fichier
  else if (!Object.keys(p).length) delete s.resurgences[pisteId];
}
// Remarque du MJ sur une résurgence, jouée ou non (demande du 2026-11-05 : ce qui s'est passé, ou pourquoi elle a été
// sautée) : remarques.resurgences["<piste>"]["<clé>"] = { texte, maj, de (le début du texte de la résurgence) }, à part du
// suivi comme les autres remarques (décocher la résurgence ne l'efface pas).
export const remarqueResurgence = (v, pisteId, m) => lue(v.remarques?.resurgences?.[pisteId], m) || null;
export function noterRemarqueResurgence(v, pisteId, m, texte) {
  const propre = String(texte || '').trim();
  v.remarques ||= {};
  const tout = (v.remarques.resurgences ||= {});
  const p = (tout[pisteId] ||= {});
  retirer(p, m);
  if (propre) p[cleResurgence(m)] = { texte: propre, maj: new Date().toISOString(), de: String(m.texte || '').slice(0, 80) };
  if (!Object.keys(p).length) delete tout[pisteId];
}
// Le dialogue de cette remarque, le même d'où qu'on l'ouvre (Déroulé, ce qui reste) : `dialogue` de la page, `enregistrer`
// après un changement. piste : { id, nom }.
export function saisirRemarqueResurgence(dialogue, v, piste, m, enregistrer) {
  let dlg;
  const avant = remarqueResurgence(v, piste.id, m)?.texte || '';
  const champ = h('textarea', { class: 'bn-textarea', rows: 5, placeholder: 'Ce qui s\'est passé, ou pourquoi elle n\'a pas été jouée…', 'aria-label': 'Remarque du MJ sur cette résurgence' }, avant);
  dlg = dialogue('Remarque sur une résurgence', piste.nom, h('div', { class: 'cm-pile' }, h('p', { class: 'ui-s cm-sourdine' }, m.texte), champ), h('div', { class: 'bn-groupe' },
    bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => {
      if (champ.value.trim() !== avant) { noterRemarqueResurgence(v, piste.id, m, champ.value); enregistrer(); }
      dlg.close();
    } }),
    bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
  setTimeout(() => { champ.focus(); champ.setSelectionRange(champ.value.length, champ.value.length); }, 0);
}
// Le crayon d'une résurgence : plein quand elle a une remarque.
export function crayonResurgence(v, piste, m, ouvrir) {
  const a = !!remarqueResurgence(v, piste.id, m);
  const titre = a ? 'Modifier la remarque sur cette résurgence' : 'Ajouter une remarque sur cette résurgence';
  return h('button', { type: 'button', class: 'cm-res-crayon' + (a ? ' a-remarque' : ''), 'aria-label': titre, title: titre, onclick: ev => { ev.stopPropagation(); ouvrir(); } }, icone('lu-pencil'));
}

// Le début et la fin d'une piste ont aussi leur remarque (demande du MJ, 2026-11-05 : « la résurgence 0 »), rangée avec
// celles des résurgences sous les clés réservées « debut » et « fin » : boutPiste(p, 'debut') tient lieu de résurgence
// pour remarqueResurgence(), saisirRemarqueResurgence() et crayonResurgence(). Pas de case « jouée » : commencer et
// terminer la piste le disent déjà.
export const BOUTS_PISTE = { debut: 'Début', fin: 'Fin' };
export const boutPiste = (p, quel) => ({ id: quel, texte: `${BOUTS_PISTE[quel]} : ${p[quel]?.texte || 'non décrit'}` });

// L'étape d'une résurgence : la sienne, ou celle de son jalon ; null pour une résurgence libre, d'un lieu ou d'une route.
export const etapeDeResurgence = (m, jalonParId) => m.etape || (m.jalon ? jalonParId.get(m.jalon)?.etape || null : null);

export const estValide = (v, genre, id) => !!v.suivi?.[GENRES[genre]]?.[id]?.valide;
export function valider(v, genre, id, quand = new Date().toISOString()) { (preparerSuivi(v)[GENRES[genre]][id] ||= {}).valide = quand; }
export function devalider(v, genre, id) { delete v.suivi?.[GENRES[genre]]?.[id]?.valide; }

// Suivi qui renvoie à un élément disparu des données (id renommé ou retiré à un export) : gardé dans l'état, signalé par
// le bouton Données, qui permet de le retirer. [{ genre: 'etape' | 'jalon' | 'piste' | 'reference', id }]
export function orphelinsDeroule(v, d) {
  if (!d) return [];
  const connus = { etape: new Set((d.etapes || []).map(x => x.id)), jalon: new Set((d.jalons || []).map(x => x.id)), piste: new Set((d.pistes || []).map(x => x.id)) };
  const res = [];
  if (v.etape && !connus.etape.has(v.etape)) res.push({ genre: 'reference', id: v.etape });
  for (const [genre, champ] of Object.entries(GENRES)) {
    for (const id of Object.keys(v.suivi?.[champ] || {})) if (!connus[genre].has(id)) res.push({ genre, id });
  }
  return res;
}
export function retirerOrphelin(v, { genre, id }) {
  if (genre === 'reference') { if (v.etape === id) v.etape = null; }
  else oublier(v, genre, id);
}

// Rencontres (etat/rencontres-mj.json) dont le rattachement à un jalon ou une étape ne vaut plus d'après les données : un jalon
// ou une étape disparus, ou une rencontre prévue qu'un jalon ne cite plus (le lien fait foi dans deroule-campagne.json). Périmé :
// ignoré, jamais effacé d'office, signalé par le bouton Données. [{ id, nom, jalon?, etape? }]
export function rattachementsPerimes(rencontres, d) {
  if (!d) return [];
  const jalons = new Map((d.jalons || []).map(x => [x.id, x]));
  const etapes = new Set((d.etapes || []).map(x => x.id));
  const res = [];
  for (const e of rencontres || []) {
    const { jalon, etape } = e.rattachement || {};
    if (jalon && (!jalons.has(jalon) || (e.origine === 'prevue' && !(jalons.get(jalon).rencontres || []).includes(e.id)))) res.push({ id: e.id, nom: e.nom || e.id, jalon });
    else if (etape && !etapes.has(etape)) res.push({ id: e.id, nom: e.nom || e.id, etape });
  }
  return res;
}

// etat/deroule.json, ouvert une fois pour tous, suivi complété et migré d'après les données (format 2 seulement : un fichier
// refusé n'a pas de données). Les jalons devenus pistes sont notés dans `migration` (annonce du tableau de bord).
let promesse = null;
export function etatDeroule(etat, donnees) {
  promesse ||= (async () => {
    const s = await etat('deroule', { schema: 1, etape: null });
    const d = (await donnees('deroule-campagne')).donnees;
    const avant = JSON.stringify(s.valeur.suivi ?? null) + (s.valeur.jalon || '');
    s.migration = migrerSuivi(s.valeur, d);
    if (JSON.stringify(s.valeur.suivi) !== avant) s.enregistrer(0);
    return s;
  })();
  return promesse;
}

// ───── Dans quelles étapes va un élément d'un lieu ? (retours du MJ, 2026-11-05) ─────
// Plusieurs étapes peuvent se jouer au même lieu (la maison, puis son sous-sol) : un PNJ, une rencontre ou un objet rangé à
// ce lieu ne sont pas de toutes pour autant. rangeurEtapes(d) le décide, en un seul endroit, pour l'arbre d'une étape et
// pour ce qui reste. Dans l'ordre :
// 1. ce que disent les données : `etapes` de l'élément (facultatif) ;
// 2. les étapes du lieu qui déclarent sa pièce (`sous_lieux` de l'étape, facultatif) ou dont un jalon le cite ;
// 3. à défaut, celles dont un jalon se passe dans sa pièce ;
// 4. à défaut, toutes les étapes du lieu : rien n'est jamais perdu, au pire montré partout comme avant.
// Un élément : { genre ('pnj' | 'rencontre' | 'objet'), id, lieu, sous_lieu?, etapes? }.
export function rangeurEtapes(d) {
  const parLieu = new Map();
  for (const e of d?.etapes || []) for (const l of e.lieux || []) { if (!parLieu.has(l)) parLieu.set(l, []); parLieu.get(l).push(e); }
  const pieces = new Map(), cites = new Map();
  const dans = (m, k) => { if (!m.has(k)) m.set(k, new Set()); return m.get(k); };
  for (const j of d?.jalons || []) {
    if (j.sous_lieu) dans(pieces, j.etape).add(j.sous_lieu);
    for (const id of j.pnj || []) dans(cites, j.etape).add('pnj:' + id);
    for (const id of j.rencontres || []) dans(cites, j.etape).add('rencontre:' + id);
  }
  function etapesDe(x) {
    if (Array.isArray(x.etapes) && x.etapes.length) return new Set(x.etapes);
    const candidates = parLieu.get(x.lieu) || [];
    if (candidates.length <= 1) return new Set(candidates.map(e => e.id));
    const cle = `${x.genre}:${x.id}`;
    const dites = candidates.filter(e => cites.get(e.id)?.has(cle) || (x.sous_lieu && Array.isArray(e.sous_lieux) && e.sous_lieux.includes(x.sous_lieu)));
    if (dites.length) return new Set(dites.map(e => e.id));
    const deduites = x.sous_lieu ? candidates.filter(e => pieces.get(e.id)?.has(x.sous_lieu)) : [];
    return new Set((deduites.length ? deduites : candidates).map(e => e.id));
  }
  return { etapesDe, estDe: (x, etapeId) => etapesDe(x).has(etapeId) };
}
// Les éléments, tels que le rangeur les attend : un PNJ des données, une rencontre (sa vue, app/rencontres-mj.js), un objet
// (sa vue, app/objets.js ; sans lieu, celui du PNJ qui le porte).
export const elementPnj = p => ({ genre: 'pnj', id: p.id, lieu: p.lieu, sous_lieu: p.sous_lieu, etapes: p.etapes });
export const elementRencontre = vue => (vue.scen
  ? { genre: 'rencontre', id: vue.id, lieu: vue.scen.lieu, sous_lieu: vue.scen.sous_lieu, etapes: vue.scen.etapes }
  : { genre: 'rencontre', id: vue.id, lieu: vue.e?.rattachement?.lieu, sous_lieu: vue.e?.rattachement?.sous_lieu });
export function elementObjet(o, pnjParId) {
  const r = o.rattachement || {};
  const p = !r.lieu && r.pnj ? pnjParId?.get(r.pnj) : null;
  return { genre: 'objet', id: o.id, lieu: r.lieu || p?.lieu, sous_lieu: r.lieu ? r.sous_lieu : p?.sous_lieu, etapes: o.etapes };
}
