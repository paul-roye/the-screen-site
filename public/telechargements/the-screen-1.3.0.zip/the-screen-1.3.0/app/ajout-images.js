// Ajouter des images à la bibliothèque de la campagne depuis la page (demande du MJ, 2026-11-10) : des fichiers choisis, un
// dossier entier ou ce qu'on glisse sur la fenêtre. Ils vont dans le dossier d'une source de la bibliothèque (d'office la
// première source « Mes images » du manifeste), chaque fichier envoyé au serveur (<campagne>/ajout-images.json, lancer.ps1),
// puis la bibliothèque est réindexée et relue (rechargerBibliotheque) : les images paraissent tout de suite.
// Catégorie du lot : une carte va dans un sous-dossier « Cartes » (déduite carte, sur tout poste) ; une autre catégorie
// s'applique en étiquette du MJ (etat/images.json), modifiable ensuite image par image ; « D'après les dossiers » laisse
// faire la déduction (un sous-dossier « Cartes » du dossier choisi). Format : formats/images.md.

import { h, icone, bouton, alerte } from './ui.js';
import { campagneOuverte } from './campagne.js';
import { chargerBibliotheque, rechargerBibliotheque, CATEGORIES } from './bibliotheque.js';

const EXTENSIONS = /\.(jpe?g|png|webp)$/i;
const DOSSIER_CARTES = /^(cartes?|maps?|plans?)$/i;
const DOSSIER_TEXTURES = /^textures?$/i;
// Un nom de dossier ou de fichier que le serveur accepte (lancer.ps1, Ajout-Images).
const nomPropre = t => t.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-').trim().replace(/^\.+/, '').slice(0, 150) || '_';

// Le contenu d'un dossier glissé sur la fenêtre (API des entrées du glisser-déposer de Chrome).
async function lireEntree(entree, prefixe = '') {
  if (entree.isFile) return [await new Promise((ok, ko) => entree.file(f => ok({ fichier: f, rel: prefixe + f.name }), ko))];
  if (!entree.isDirectory) return [];
  const lecteur = entree.createReader(), enfants = [];
  for (;;) {
    const lot = await new Promise((ok, ko) => lecteur.readEntries(ok, ko));
    if (!lot.length) break;
    enfants.push(...lot);
  }
  return (await Promise.all(enfants.map(e => lireEntree(e, `${prefixe}${entree.name}/`)))).flat();
}

// dialogue : celui des widgets (app/main.js) ; surAjout({ source, chemins }) : après un ajout réussi.
export async function ouvrirAjoutImages({ dialogue, donnees, etat, surAjout = null }) {
  await chargerBibliotheque(donnees, etat).catch(() => null);   // les catégories propres à la campagne
  const serveur = await fetch('ajout-images.json', { cache: 'no-store' }).then(r => (r.ok ? r.json() : null)).catch(() => null);
  const sourcesMj = (campagneOuverte().images?.sources || []).filter(s => s.type === 'dossier' && s.dossier).map(s => s.dossier);
  const dossiers = [...new Set([...sourcesMj, ...(sourcesMj.length ? [] : ['Mes images']), ...(serveur?.dossiers || [])])];

  let lot = { items: [], dossier: null, ignores: 0 };
  let occupe = false;
  const message = h('div');
  const resume = h('div', { class: 'cm-pile' });
  const dire = (couleur, titre, texte, ...extra) => message.replaceChildren(couleur ? alerte(couleur, couleur === 'sang' ? 'lu-triangle-alert' : couleur === 'brume' ? 'lu-check' : 'lu-info', titre, texte, ...extra) : '');

  // Où ranger : une source de la bibliothèque, ou un nouveau dossier.
  const selSource = h('select', { class: 'bn-select', 'aria-label': 'Ranger dans', onchange: () => { autre.hidden = selSource.value !== '+'; majBouton(); } },
    dossiers.map(d => h('option', { value: d }, d)), h('option', { value: '+' }, 'Autre dossier…'));
  const autre = h('input', { class: 'bn-input', type: 'text', placeholder: 'Nom du nouveau dossier', hidden: true, oninput: () => majBouton() });
  const source = () => nomPropre(selSource.value === '+' ? autre.value : selSource.value);

  // La catégorie choisie par le MJ reste d'un lot à l'autre ; sinon, « D'après les dossiers » pour un dossier, Illustrations pour des fichiers.
  let categorieChoisie = null;
  const selCategorie = h('select', { class: 'bn-select', 'aria-label': 'Catégorie du lot', onchange: e => { categorieChoisie = e.target.value; } });
  function majCategories() {
    const avant = categorieChoisie;
    const options = [
      ...(lot.dossier ? [['auto', 'D\'après les dossiers']] : []),
      ['carte', CATEGORIES.carte], ['illustration', CATEGORIES.illustration],
      ...Object.entries(CATEGORIES).filter(([k]) => k !== 'carte' && k !== 'illustration'),
    ];
    selCategorie.replaceChildren(...options.map(([k, v]) => h('option', { value: k }, v)));
    selCategorie.value = options.some(([k]) => k === avant) ? avant : lot.dossier ? 'auto' : 'illustration';
  }

  const inputFichiers = h('input', { type: 'file', multiple: true, accept: 'image/jpeg,image/png,image/webp', hidden: true,
    onchange: e => choisir([...e.target.files].map(f => ({ fichier: f, rel: f.name })), null) });
  const inputDossier = h('input', { type: 'file', multiple: true, hidden: true,
    onchange: e => { const l = [...e.target.files]; choisir(l.map(f => ({ fichier: f, rel: f.webkitRelativePath || f.name })), l[0]?.webkitRelativePath?.split('/')[0] || null); } });
  inputDossier.webkitdirectory = true;

  function choisir(items, dossier) {
    if (occupe) return;
    const gardes = items.filter(x => EXTENSIONS.test(x.fichier.name) && !x.rel.split('/').some(s => s.startsWith('.')));
    lot = { items: gardes, dossier, ignores: items.length - gardes.length };
    dire(null);
    majCategories();
    rendreResume();
    majBouton();
  }

  function rendreResume() {
    if (!lot.items.length && !lot.ignores) { resume.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Aucune image choisie. Vous pouvez aussi glisser des images ou un dossier sur cette fenêtre.')); return; }
    const mo = lot.items.reduce((t, x) => t + x.fichier.size, 0) / 1048576;
    resume.replaceChildren(
      h('p', { class: 'ui' }, icone(lot.dossier ? 'lu-folder-open' : 'lu-image', 'bn-icone--s'), ' ',
        h('b', {}, `${lot.items.length} image${lot.items.length > 1 ? 's' : ''}`),
        lot.dossier ? ` du dossier « ${lot.dossier} »` : '',
        ` · ${mo < 1 ? `${Math.max(1, Math.round(mo * 1024))} Ko` : `${mo.toLocaleString('fr-FR', { maximumFractionDigits: 1 })} Mo`}`,
        lot.ignores ? h('span', { class: 'cm-sourdine' }, ` · ${lot.ignores} fichier${lot.ignores > 1 ? 's' : ''} ignoré${lot.ignores > 1 ? 's' : ''} (pas en JPEG, PNG ou WebP)`) : ''),
      lot.items.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'Fichiers'),
        h('ul', { class: 'ui-s cm-ajout-images__liste' }, lot.items.slice(0, 200).map(x => h('li', {}, x.rel)),
          lot.items.length > 200 ? h('li', { class: 'cm-sourdine' }, `… et ${lot.items.length - 200} autres`) : null)) : null);
  }

  // Le chemin d'une image dans la bibliothèque : la source, « Cartes » pour une carte (sauf si le dossier choisi en est un),
  // puis le chemin dans le dossier choisi.
  function cheminDe(x, categorie) {
    const rel = x.rel.split('/').map(nomPropre);
    // De même, une texture dans un sous-dossier « Textures » (déduite texture sur tout poste, 2026-11-12).
    const cartes = categorie === 'carte' && !rel.slice(0, -1).some(s => DOSSIER_CARTES.test(s)) ? ['Cartes']
      : categorie === 'texture' && !rel.slice(0, -1).some(s => DOSSIER_TEXTURES.test(s)) ? ['Textures'] : [];
    return [source(), ...cartes, ...rel].join('/');
  }

  const btnAjouter = bouton('Ajouter', { classe: 'bn-btn--primaire', icone: 'lu-plus', onclick: () => ajouter() });
  function majBouton() { btnAjouter.disabled = occupe || !lot.items.length || (selSource.value === '+' && !autre.value.trim()); }

  async function ajouter() {
    const categorie = selCategorie.value, dest = source();
    occupe = true; majBouton();
    const chemins = [], erreurs = [];
    let deja = 0;
    try {
      for (const [n, x] of lot.items.entries()) {
        dire('brume', 'Envoi des images', `${n + 1} sur ${lot.items.length} : ${x.rel}`);
        try {
          const r = await fetch(`ajout-images.json?chemin=${encodeURIComponent(cheminDe(x, categorie))}`, { method: 'POST', body: x.fichier });
          if (!r.ok) throw new Error(await r.text());
          const j = await r.json();
          chemins.push(j.chemin);
          if (j.deja) deja++;
        } catch (e) {
          erreurs.push(`${x.rel} : ${e.message || 'le serveur ne répond pas'}`);
          if (/import des images est en cours|Bibliothèque refusée/.test(e.message)) break;
        }
      }
      if (chemins.length) {
        dire('brume', 'Indexation', `${chemins.length} image${chemins.length > 1 ? 's' : ''} dans « ${dest} » : miniatures et index…`);
        const r = await fetch('ajout-images.json?indexer=1', { method: 'POST' }).catch(() => null);
        if (!r?.ok) throw new Error(r ? await r.text() : 'Le serveur ne répond pas.');
        const b = await rechargerBibliotheque(donnees, etat);
        if (b && categorie !== 'auto') b.classerLot(chemins, categorie);
        surAjout?.({ source: dest, chemins });
      }
      const nouvelles = chemins.length - deja;
      const titre = chemins.length ? `${nouvelles} image${nouvelles > 1 ? 's' : ''} ajoutée${nouvelles > 1 ? 's' : ''} dans « ${dest} »` : 'Aucune image ajoutée';
      const texte = [deja ? `${deja} déjà dans la bibliothèque.` : '', chemins.length ? 'Leur catégorie, leurs lieux et leurs PNJ se règlent ensuite dans la fenêtre de chaque image.' : ''].filter(Boolean).join(' ');
      dire(erreurs.length ? (chemins.length ? 'cierge' : 'sang') : 'brume', titre, texte,
        erreurs.length ? h('ul', { class: 'ui-s cm-ajout-images__liste' }, erreurs.slice(0, 20).map(e => h('li', {}, e))) : '');
      if (chemins.length) { lot = { items: [], dossier: null, ignores: 0 }; majCategories(); rendreResume(); }
    } catch (e) {
      dire('sang', 'Ajout interrompu', e.message);
    } finally { occupe = false; majBouton(); }
  }

  const contenu = h('div', { class: 'cm-pile cm-ajout-images' },
    serveur ? null : alerte('cierge', 'lu-triangle-alert', 'Serveur trop ancien', 'Relancez le gestionnaire (lancer.ps1) : son serveur ne sait pas encore recevoir des images.'),
    serveur?.en_cours ? alerte('cierge', 'lu-info', 'Import en cours', 'Un import des images tourne (fenêtre Campagne, onglet « Images ») : attendez qu\'il se termine.') : null,
    h('div', { class: 'bn-groupe' },
      bouton('Des images…', { icone: 'lu-image-plus', titre: 'Choisir une ou plusieurs images (JPEG, PNG, WebP)', onclick: () => inputFichiers.click() }),
      bouton('Un dossier…', { icone: 'lu-folder-plus', titre: 'Choisir un dossier : toutes ses images, sous-dossiers compris, avec leur rangement', onclick: () => inputDossier.click() }),
      inputFichiers, inputDossier),
    resume,
    h('div', { class: 'bn-ligne-champs' },
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Ranger dans'), selSource, autre),
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Catégorie'), selCategorie)),
    h('p', { class: 'ui-s cm-sourdine' }, 'Une texture va dans un sous-dossier « Textures », une carte dans « Cartes ». La version joueurs d\'une carte : le même nom de fichier terminé par « -player » (« crypte.jpg » et « crypte-player.jpg »). Les noms des dossiers et des fichiers donnent les lieux et les PNJ ; le reste se règle ensuite, image par image.'),
    message);
  // Glisser des images ou un dossier sur la fenêtre.
  contenu.addEventListener('dragover', e => { e.preventDefault(); contenu.classList.add('est-survole'); });
  contenu.addEventListener('dragleave', e => { if (!contenu.contains(e.relatedTarget)) contenu.classList.remove('est-survole'); });
  contenu.addEventListener('drop', async e => {
    e.preventDefault();
    contenu.classList.remove('est-survole');
    const entrees = [...(e.dataTransfer.items || [])].map(i => i.webkitGetAsEntry?.()).filter(Boolean);
    if (!entrees.length) return choisir([...e.dataTransfer.files].map(f => ({ fichier: f, rel: f.name })), null);
    const items = (await Promise.all(entrees.map(x => lireEntree(x)))).flat();
    choisir(items, entrees.length === 1 && entrees[0].isDirectory ? entrees[0].name : null);
  });
  majCategories();
  rendreResume();
  majBouton();
  return dialogue('Bibliothèque d\'images', 'Ajouter des images', contenu, h('div', { class: 'bn-groupe' }, btnAjouter));
}
