// Plugin The Table : le boîtier ESP32 qui pilote le ruban LED autour de la table de jeu (ambiances, place du joueur dont
// c'est le tour, cadre rouge au tour des monstres, effets ponctuels). API HTTP + JSON sur le réseau local (contrat :
// mainteneur/the-table/api/, firmware 0.2.0) ; le gestionnaire est servi en http://localhost, donc aucun blocage
// « mixed content » vers http://the-table.local.
// - Combats (réglage « Piloter The Table pendant les combats ») : à chaque changement du combat mené dans le widget Combat
//   (événement combat:etat, app/evenements.js), l'instantané complet (combattants dans l'ordre, tour, round) est envoyé à
//   POST /api/combat, fusionné à 150 ms, gardé et renvoyé dès que la table répond si l'envoi échoue ; battement de cœur
//   toutes les 60 s, bail de 15 min ; « Reprendre la main » sur la page de The Table est détecté (mode local) et respecté
//   jusqu'à « Reconnecter ». Fin, annulation ou remise à zéro du combat : {active: false}.
// - Effets (réglage « Effets lumineux ») : dégâts et soins d'un héros sur sa place, 20 naturel d'un héros (éclat or),
//   20 naturel d'un monstre (flash rouge sur toute la table).
// - Widget The Table : l'état de la connexion, les ambiances (lues sur la table, jamais codées en dur), les effets à la main.
// - Correspondance héros → joueur installé sur The Table : par le nom d'office, réglable dans l'onglet Plugins.
// Jamais de fenêtre bloquante pendant un combat : la table absente, le combat continue, le point passe à l'orange.

import { h, icone, bouton, alerte, infobulle, section, normaliser, flottant, flottantOuvert } from '../ui.js';
import { annoncer } from '../horloge.js';

const ID = 'the-table';
const SOURCE = 'The Screen';           // « Combat piloté par The Screen » sur la page MJ de The Table (31 caractères gardés)
const LEASE_S = 900;                   // bail conseillé par The Table : 15 min, avec un battement de cœur
const COEUR_MS = 60000;
const VEILLE_MS = 10000;               // pendant un combat piloté : GET /api/combat, pour voir une reprise de la main
const RELANCE_MS = 5000;               // nouvel essai quand la table ne répond pas
const FUSION_MS = 150;                 // envois rapprochés fusionnés
const DELAI_MS = 3000;                 // une requête qui dure plus : la table ne répond pas
const ID_MAX = 23, NOM_MAX = 23;
const EFFETS = [
  ['crit', 'Critique', 'Éclat or (2,2 s)', 'lu-sparkles'],
  ['dmg', 'Dégâts', 'Flash rouge (1,2 s)', 'epee'],
  ['heal', 'Soins', 'Vague verte (2,6 s)', 'coeur'],
  ['bolt', 'Éclair', 'Éclair sur un côté (1,3 s)', 'lu-cloud-rain-wind'],
];
const DEFAUTS = { actif: false, adresse: 'http://the-table.local', jeton: '', combats: true, effets: true, joueurs: {}, joueurs_table: [], version: null };

// ───── Client ─────

let lire = () => DEFAUTS;              // les réglages (ctx.reglages.lire), posés au démarrage ou à l'ouverture des réglages
const adresse = () => String(lire().adresse || DEFAUTS.adresse).trim().replace(/\/+$/, '');

function messageDe(statut, j) {
  const erreur = j?.error || '';
  if (statut === 401) return 'Jeton refusé : réglez ici le même jeton que dans la page de The Table (Boîtier, Accès).';
  if (statut === 404 && erreur === 'route') return 'Route inconnue : cette adresse n\'est pas celle d\'un boîtier The Table (ou son firmware est trop ancien).';
  if (statut === 404) return `Inconnu de The Table : ${erreur}.`;
  return `Refusé par The Table : ${erreur || `HTTP ${statut}`}.`;
}

// Une requête à The Table. corps : envoyé en JSON (POST). Erreur : e.code = 'injoignable' (ne répond pas, pas sur ce réseau,
// bloqué), 'jeton' (401), 'refus' (400, 404), avec un message en français.
async function appeler(chemin, { methode = 'GET', corps = null, delai = DELAI_MS, keepalive = false } = {}) {
  const ctl = new AbortController();
  const minuterie = setTimeout(() => ctl.abort(), delai);
  const headers = {};
  if (corps !== null) headers['Content-Type'] = 'application/json';
  const jeton = String(lire().jeton || '').trim();
  if (jeton && methode !== 'GET') headers['X-Token'] = jeton;
  try {
    const r = await fetch(adresse() + chemin, { method: methode, headers, body: corps === null ? undefined : JSON.stringify(corps), signal: ctl.signal, keepalive, cache: 'no-store' });
    let j = null;
    try { j = await r.json(); } catch { /* 400 sans corps */ }
    if (!r.ok) {
      const e = new Error(messageDe(r.status, j));
      e.code = r.status === 401 ? 'jeton' : 'refus';
      e.statut = r.status;
      e.reponse = j;
      throw e;
    }
    return j;
  } catch (e) {
    if (e.code) throw e;
    const err = new Error(ctl.signal.aborted ? `The Table ne répond pas (${adresse()}, ${delai / 1000} s).`
      : `The Table injoignable à ${adresse()} : même Wi‑Fi ? adresse exacte ? Chrome a-t-il l'autorisation d'accéder aux appareils du réseau local ?`);
    err.code = 'injoignable';
    err.cause = e;
    throw err;
  } finally { clearTimeout(minuterie); }
}

// Test de connexion : la version, les joueurs installés, le mode du combat. Les joueurs sont gardés dans les réglages
// (la correspondance des héros se règle même table éteinte).
async function tester(ecrire) {
  const s = await appeler('/api/state');
  // La place de chacun autour de la table (`seat` : side 0 haut, 1 droite, 2 bas, 3 gauche ; from, to de 0 à 1 le long du
  // côté), installée dans la page de The Table : elle place aussi d'office les médaillons des héros de l'écran des joueurs.
  const joueurs = (s.table?.players || []).map(p => ({ id: p.id, name: p.name, present: p.present !== false, seat: p.seat ? { side: p.seat.side, from: p.seat.from, to: p.seat.to } : null }));
  ecrire?.({ joueurs_table: joueurs, cote_mj: s.table?.gm_side ?? null, version: s.version || null });
  return { version: s.version, joueurs, mode: s.combat?.mode || 'local', source: s.combat?.source || null, scene: s.light?.scene || null };
}

// ───── État de la connexion ─────
// code : repos (pas de combat), preparation (combat pas commencé), synchro, attente (la table ne répond pas), reprise (le MJ
// a repris la main sur la page de The Table), erreur (jeton ou envoi refusé), inactif (combats non pilotés).
const STATUTS = {
  inactif: { libelle: 'Combats non pilotés', ton: 'cendre' },
  repos: { libelle: 'Pas de combat', ton: 'cendre' },
  preparation: { libelle: 'Combat pas commencé', ton: 'cendre' },
  synchro: { libelle: 'The Table synchronisée', ton: 'mousse' },
  attente: { libelle: 'The Table en attente', ton: 'cierge' },
  reprise: { libelle: 'Reprise par le MJ sur The Table', ton: 'cierge' },
  erreur: { libelle: 'The Table refuse l\'envoi', ton: 'sang' },
};
let statut = { code: 'repos', texte: '' };
const surStatutFns = new Set();
const elementsStatut = new Set();   // les points d'état posés dans l'en-tête de Combat, redessinés à chaque changement
function majStatut(code, texte = '') {
  if (statut.code === code && statut.texte === texte) return;
  statut = { code, texte };
  for (const el of elementsStatut) { if (el.isConnected) peindreStatut(el); else elementsStatut.delete(el); }
  surStatutFns.forEach(fn => { try { fn(statut); } catch (e) { console.error(e); } });
}
const texteStatut = () => [STATUTS[statut.code]?.libelle || statut.code, statut.texte].filter(Boolean).join(' · ');

// ───── Combat piloté ─────

let instantane = null;      // le dernier combat:etat reçu (null : pas de combat)
let envoye = null;          // JSON du dernier instantané accepté par la table
let pilote = false;         // la table est en mode remote, par nous
let reprise = false;        // le MJ a repris la main : on n'insiste pas avant « Reconnecter »
let fusion = null, relance = null, coeur = null, veille = null;
let aFinir = false;         // {active: false} à envoyer dès que la table répond

const hash = t => { let n = 5381; for (const c of String(t)) n = ((n * 33) ^ c.charCodeAt(0)) >>> 0; return n.toString(36); };
const idDe = x => (x.type === 'pj' ? `pj-${x.fiche || hash(x.cle)}` : 'm-' + hash(x.cle)).slice(0, ID_MAX);
// Le joueur de The Table d'un héros : réglé (joueurs[perso]), sinon par le nom (The Table le refait aussi de son côté).
function joueurDe(x) {
  const r = lire();
  const regle = x.perso && r.joueurs?.[x.perso];
  if (regle) return regle;
  return joueurParNom(x.nom);
}
function joueurParNom(nom, r = lire()) {
  const n = normaliser(String(nom || '')), premier = n.split(/\s+/)[0];
  const l = r.joueurs_table || [];
  return l.find(p => normaliser(p.name) === n)?.id || l.find(p => normaliser(p.name).split(/\s+/)[0] === premier)?.id || l.find(p => normaliser(p.id) === n)?.id || null;
}
// La place d'un héros autour de The Table, d'après les réglages du plugin (r : ses réglages, lus même plugin coupé) :
// { side, from, to } (côtés : 0 haut, 1 droite, 2 bas, 3 gauche), ou null. Pour les médaillons de l'écran des joueurs
// (app/plugins/ecran-joueurs.js). Une place gardée d'un ancien « Tester » (un booléen) ne compte pas : « Tester » de nouveau.
export function placeSurLaTable(r, perso, nom) {
  const id = r?.joueurs?.[perso] || joueurParNom(nom, r || DEFAUTS);
  const j = id ? (r?.joueurs_table || []).find(x => x.id === id) : null;
  return j?.present !== false && j?.seat && typeof j.seat === 'object' ? j.seat : null;
}
function corpsDe(inst) {
  const garde = inst.ordre.filter(x => !x.hors_combat || x.cle === inst.tour).slice(0, 32);
  const courant = garde.find(x => x.cle === inst.tour);
  return {
    source: SOURCE, round: Math.max(1, Math.min(999, inst.round || 1)), current: courant ? idDe(courant) : '', lease_s: LEASE_S,
    combatants: garde.map(x => ({ id: idDe(x), name: String(x.nom || x.cle).slice(0, NOM_MAX), kind: x.type === 'pj' ? 'pc' : 'monster',
      ...(x.type === 'pj' && joueurDe(x) ? { player: joueurDe(x) } : {}) })),
  };
}

function surCombat({ combat }) {
  instantane = combat;
  planifier();
}
function planifier(delai = FUSION_MS) {
  clearTimeout(fusion);
  fusion = setTimeout(() => synchroniser().catch(e => console.error(e)), delai);
}
function arreterMinuteries() { clearTimeout(fusion); clearTimeout(relance); clearInterval(coeur); clearInterval(veille); fusion = relance = coeur = veille = null; }

// L'instantané du moment, ou la fin du combat, envoyé à la table ; échec : gardé et réessayé.
async function synchroniser() {
  clearTimeout(relance);
  if (!lire().combats) { majStatut('inactif'); return; }
  const inst = instantane;
  const enCombat = !!inst && inst.phase === 'combat';
  if (!enCombat) {
    if (pilote || aFinir) await finir();
    else majStatut(inst ? 'preparation' : 'repos');
    return;
  }
  if (reprise) { majStatut('reprise'); return; }
  const corps = corpsDe(inst);
  const json = JSON.stringify(corps);
  if (json === envoye && statut.code === 'synchro') return;
  try {
    await appeler('/api/combat', { methode: 'POST', corps });
    envoye = json;
    pilote = true;
    aFinir = false;
    majStatut('synchro', `round ${corps.round}`);
    armer();
  } catch (e) { echec(e); }
}
async function finir({ keepalive = false } = {}) {
  aFinir = true;
  try {
    await appeler('/api/combat', { methode: 'POST', corps: { active: false }, keepalive });
    aFinir = false;
    pilote = false;
    envoye = null;
    arreterMinuteries();
    majStatut(instantane ? 'preparation' : 'repos');
  } catch (e) {
    if (e.code === 'refus') { aFinir = false; pilote = false; envoye = null; arreterMinuteries(); majStatut(instantane ? 'preparation' : 'repos'); }   // déjà en mode local
    else echec(e);
  }
}
function echec(e) {
  if (e.code === 'injoignable') { majStatut('attente', e.message); relance = setTimeout(() => synchroniser().catch(() => {}), RELANCE_MS); }
  else majStatut('erreur', e.message);   // jeton refusé, instantané refusé : réessayer ne changera rien, le prochain changement du combat le fera
}
// Pendant un combat piloté : le battement de cœur, et la veille d'une reprise de la main sur la page de The Table.
function armer() {
  if (coeur) return;
  coeur = setInterval(async () => {
    if (!pilote) return;
    try { await appeler('/api/combat', { methode: 'POST', corps: { heartbeat: true } }); }
    catch (e) { if (e.code === 'refus') perdreLaMain(); else echec(e); }
  }, COEUR_MS);
  veille = setInterval(async () => {
    if (!pilote) return;
    try {
      const c = await appeler('/api/combat');
      if (c?.mode !== 'remote' || (c.source && c.source !== SOURCE)) perdreLaMain();
    } catch { /* l'envoi suivant le dira */ }
  }, VEILLE_MS);
}
// « Reprendre la main » (ou une autre source) sur The Table : on n'insiste pas, le combat continue ici.
function perdreLaMain() {
  if (reprise) return;
  reprise = true;
  pilote = false;
  envoye = null;
  arreterMinuteries();
  majStatut('reprise');
  annoncer({ cle: 'the-table', titre: 'The Table déconnectée du combat', icone: 'lu-lamp', couleur: 'cierge',
    texte: 'La main a été reprise sur la page de The Table. Le combat continue ici ; « Reconnecter » (point The Table dans Combat, ou widget The Table) la repilote.' });
}
function reconnecter() {
  reprise = false;
  envoye = null;
  planifier(0);
}

// ───── Effets ─────

function seatDe(x) {
  const joueur = joueurDe(x);
  if (joueur) return joueur;
  const c = pilote ? instantane?.ordre.find(y => y.cle === x.cle) : null;   // le combattant envoyé : The Table connaît sa place
  return c ? idDe(c) : null;
}
async function effet(effect, seat = null) {
  try { await appeler('/api/overlay', { methode: 'POST', corps: seat ? { effect, seat } : { effect } }); }
  catch (e) { console.warn(`The Table, effet ${effect}${seat ? ` sur ${seat}` : ''} : ${e.message}`); }
}
function surPv(d) {
  if (!lire().effets || d.type !== 'pj' || d.quoi === 'temp' || !(d.montant > 0)) return;
  const seat = seatDe(d);
  if (seat) effet(d.quoi === 'degats' ? 'dmg' : 'heal', seat);
}
function surDes(d) {
  if (!lire().effets) return;
  for (const j of d.jets || []) {
    if (j.critique !== 'reussite') continue;
    const seat = joueurParNom(j.libelle);
    if (seat) effet('crit', seat);
    else if (d.couleur === 'ultra') effet('dmg');   // le 20 naturel d'un monstre : toute la table
  }
}

// ───── Vues ─────

function peindreStatut(el) {
  el.dataset.statut = statut.code;
  el.setAttribute('aria-label', texteStatut());
  el.dataset.bulle = texteStatut();   // l'infobulle (app/ui.js) lit data-bulle au survol
}
// Le point d'état dans l'en-tête de Combat (emplacement combatEntete) : un clic ouvre la fenêtre The Table.
function pointStatut() {
  const el = h('button', { type: 'button', class: 'bn-btn bn-btn--s bn-btn--fantome bn-btn--icone cm-plugin-statut', onclick: e => ouvrirFenetre(e.currentTarget) },
    icone('lu-lamp'), h('span', { class: 'cm-plugin-statut__point', 'aria-hidden': 'true' }));
  peindreStatut(el);
  elementsStatut.add(el);
  return infobulle(el, texteStatut(), { titre: 'The Table' });
}

// Les ambiances de The Table (jamais codées en dur) et l'ambiance en cours : lues sur la table.
let scenes = [];
let sceneCourante = null;
async function lireScenes() {
  const [l, s] = await Promise.all([appeler('/api/scenes'), appeler('/api/state')]);
  scenes = Array.isArray(l) ? l : [];
  sceneCourante = s?.light?.scene || null;
  return scenes;
}

// La vue complète (fenêtre du point d'état, widget) : l'état, Reconnecter ou Tester, les ambiances, les effets.
function vueTable({ compacte = false } = {}) {
  const racine = h('div', { class: 'cm-pile cm-table' + (compacte ? ' cm-table--compacte' : '') });
  const ligneStatut = h('div', { class: 'cm-table__statut' });
  const zoneScenes = h('div', { class: 'cm-table__ambiances' });
  const erreur = h('div');
  const peindre = () => {
    const s = STATUTS[statut.code] || STATUTS.repos;
    ligneStatut.replaceChildren(...[   // replaceChildren écrirait « null » : filtré
      h('span', { class: 'cm-table__point', 'data-ton': s.ton, 'aria-hidden': 'true' }),
      h('span', { class: 'cm-table__texte' }, h('b', {}, s.libelle), statut.texte ? h('span', { class: 'ui-s cm-sourdine' }, ' · ' + statut.texte) : null),
      statut.code === 'reprise' ? bouton('Reconnecter', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-refresh-cw', titre: 'Repiloter The Table avec le combat en cours', onclick: reconnecter })
        : statut.code === 'attente' || statut.code === 'erreur' ? bouton('Réessayer', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', onclick: () => { envoye = null; planifier(0); } }) : null,
    ].filter(Boolean));
  };
  const peindreScenes = () => {
    zoneScenes.replaceChildren(...scenes.map(sc => {
      const b = h('button', { type: 'button', class: 'bn-btn bn-btn--s' + (sc.id === sceneCourante ? ' bn-btn--primaire' : ' bn-btn--fantome'), 'aria-pressed': String(sc.id === sceneCourante),
        onclick: async () => {
          try { await appeler(`/api/scenes/${encodeURIComponent(sc.id)}/activate`, { methode: 'POST', corps: {} }); sceneCourante = sc.id; peindreScenes(); erreur.replaceChildren(); }
          catch (e) { erreur.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Ambiance non changée', e.message)); }
        } }, h('span', {}, sc.name || sc.id));
      if (sc.palette?.length) b.style.setProperty('--_amb', sc.palette[1] || sc.palette[0]);   // sa couleur, en liseré
      return b;
    }));
    if (!scenes.length) zoneScenes.replaceChildren(h('span', { class: 'ui-s cm-sourdine' }, 'Ambiances inconnues : « Actualiser » quand The Table répond.'));
  };
  const actualiser = async () => {
    try { await lireScenes(); erreur.replaceChildren(); }
    catch (e) { erreur.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'The Table ne répond pas', e.message)); }
    peindreScenes();
  };
  peindre();
  peindreScenes();
  if (!scenes.length) actualiser();
  // Redessinée à chaque changement d'état, tant qu'elle est dans la page.
  const abonne = () => { if (racine.isConnected) peindre(); else surStatutFns.delete(abonne); };
  surStatutFns.add(abonne);
  racine.append(ligneStatut, erreur,
    section('Ambiances', 'lu-lamp', zoneScenes,
      h('div', { class: 'bn-groupe' }, bouton('Actualiser', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-refresh-cw', titre: 'Relire les ambiances et l\'ambiance en cours sur The Table', onclick: actualiser }))),
    section('Effets sur toute la table', 'lu-sparkles',
      h('div', { class: 'bn-groupe cm-table__effets' }, EFFETS.map(([id, nom, titre, ic]) => bouton(compacte ? '' : nom, { classe: 'bn-btn--s bn-btn--fantome', icone: ic, titre: `${nom} : ${titre}`, onclick: () => effet(id) })))));
  return racine;
}
const ouvrirFenetre = depuis => flottant('plugin:the-table', { surtitre: 'Plugin', titre: 'The Table', largeur: 420, depuis, contenu: vueTable() });

// ───── Réglages (onglet Plugins de la fenêtre Campagne) ─────

function vueReglages(ctx) {
  lire = ctx.reglages.lire;
  const ecrire = ctx.reglages.ecrire;
  const r = lire();
  const resultat = h('div');
  const champ = (cle, libelle, attrs = {}) => h('label', { class: 'cm-plugin__champ' }, libelle,
    h('input', { class: 'bn-input', type: 'text', value: r[cle] || '', autocomplete: 'off', spellcheck: 'false', ...attrs, onchange: e => ecrire({ [cle]: e.target.value.trim() }) }));
  const zoneJoueurs = h('div', { class: 'cm-plugin__joueurs' });
  const caseDe = (cle, titre, texte) => h('label', { class: 'cm-case' },
    h('input', { type: 'checkbox', class: 'bn-case', checked: r[cle] !== false, onchange: e => { ecrire({ [cle]: e.target.checked }); planifier(0); } }),
    h('span', {}, h('b', {}, titre), h('br'), h('span', { class: 'ui-s cm-sourdine' }, texte)));

  // La correspondance héros → joueur installé sur The Table : d'office par le nom, réglable.
  async function remplirJoueurs() {
    const persos = ((await ctx.donnees('personnages')).donnees?.personnages || []).filter(p => p.role === 'personnage');
    const joueurs = lire().joueurs_table || [];
    if (!persos.length) { zoneJoueurs.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Aucun héros dans data/personnages.json : The Table fera correspondre les combattants à ses joueurs par le nom.')); return; }
    zoneJoueurs.replaceChildren(h('div', { class: 'cm-plugin__champs' }, persos.map(p => {
      const nom = p.nom_court || p.nom;
      const choisi = lire().joueurs?.[p.id] || '';
      const auto = joueurs.find(j => j.id === joueurParNom(nom));
      const sel = h('select', { class: 'bn-select', 'aria-label': `Joueur de The Table pour ${nom}`, onchange: e => {
        const j = { ...(lire().joueurs || {}) };
        if (e.target.value) j[p.id] = e.target.value; else delete j[p.id];
        ecrire({ joueurs: j });
        envoye = null; planifier(0);
      } },
        h('option', { value: '' }, auto ? `D'après le nom : ${auto.name}` : joueurs.length ? 'Aucun (par le nom, côté The Table)' : 'Joueurs inconnus : « Tester »'),
        ...joueurs.map(j => h('option', { value: j.id, selected: j.id === choisi }, `${j.name}${j.seat ? '' : ' (sans place)'}`)));
      return h('label', { class: 'cm-plugin__champ' }, nom, sel);
    })));
  }
  remplirJoueurs();

  const btnTester = bouton('Tester', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-refresh-cw', titre: 'Lire la version, les joueurs installés et le mode du combat', onclick: async () => {
    btnTester.disabled = true;
    resultat.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Connexion…'));
    try {
      const t = await tester(ecrire);
      resultat.replaceChildren(alerte('brume', 'lu-check', `The Table répond (firmware ${t.version || '?'})`,
        `${t.joueurs.length} joueur${t.joueurs.length > 1 ? 's' : ''} installé${t.joueurs.length > 1 ? 's' : ''}${t.joueurs.length ? ` : ${t.joueurs.map(j => j.name).join(', ')}` : ''} · combat ${t.mode === 'remote' ? `piloté par ${t.source || 'un outil'}` : 'géré par la page de The Table'}${t.scene ? ` · ambiance « ${t.scene} »` : ''}.`));
      remplirJoueurs();
    } catch (e) {
      resultat.replaceChildren(alerte('sang', 'lu-triangle-alert', e.code === 'jeton' ? 'Jeton refusé' : 'The Table ne répond pas', e.message));
    } finally { btnTester.disabled = false; }
  } });
  const version = r.version ? h('span', { class: 'ui-s cm-sourdine' }, `Dernier test : firmware ${r.version}`) : null;

  return h('div', { class: 'cm-pile' },
    h('div', { class: 'cm-plugin__champs' },
      champ('adresse', 'Adresse de The Table', { placeholder: DEFAUTS.adresse }),
      champ('jeton', 'Jeton (si réglé sur The Table)', { placeholder: 'aucun' })),
    h('div', { class: 'bn-groupe' }, btnTester, version),
    resultat,
    caseDe('combats', 'Piloter The Table pendant les combats', 'Le combat mené dans le widget Combat est envoyé à The Table à chaque changement : la place du joueur dont c\'est le tour s\'éclaire, le cadre passe au rouge au tour d\'un monstre. Un point dans l\'en-tête de Combat dit où en est la connexion ; si la table ne répond pas, le combat continue sans elle.'),
    caseDe('effets', 'Effets lumineux', 'Dégâts et soins d\'un héros sur sa place, 20 naturel d\'un héros (éclat or sur sa place), 20 naturel d\'un monstre (flash rouge sur toute la table).'),
    section('Héros et joueurs installés sur The Table', 'lu-users', zoneJoueurs,
      h('p', { class: 'ui-s cm-sourdine' }, 'Les joueurs et leurs places se règlent sur la page de The Table. D\'office, un héros est relié au joueur de même nom ; choisissez-le ici quand les noms diffèrent.')),
    section('Brancher', 'lu-circle-help',
      h('ul', { class: 'cm-liste ui-s' },
        h('li', {}, 'Le PC et The Table sur le même Wi‑Fi. Adresse : http://the-table.local (ou l\'IP affichée dans sa page, onglet Boîtier) ; http://192.168.4.1 quand elle est en mode autonome (Wi‑Fi « The-Table », sans Internet).'),
        h('li', {}, 'Si « Tester » échoue : vérifier l\'adresse dans un onglet du navigateur ; essayer l\'IP à la place de the-table.local ; accepter dans Chrome l\'accès aux appareils du réseau local s\'il le demande ; vérifier le jeton (Boîtier, Accès).'),
        h('li', {}, '« Reprendre la main » sur la page de The Table coupe le pilotage : le gestionnaire le voit et attend « Reconnecter ». Sans nouvelle du gestionnaire pendant 15 min (page fermée), The Table repasse d\'elle-même en mode local.'))));
}

// ───── Widget ─────

const widget = {
  type: 'the-table',
  titre: 'The Table',
  icone: 'lu-lamp',
  plugin: ID,
  description: 'L\'état de la connexion à The Table (le ruban LED de la table), ses ambiances d\'un clic, les effets lumineux à la main. Plugin The Table (fenêtre Campagne, onglet Plugins).',
  taille: { w: 3, h: 6 },
  min: { w: 2, h: 3 },
  unique: true,
  compact: true,
  async monter({ corps, actions, resume }) {
    const { pluginActif, surChangementPlugins } = await import('../plugins.js');
    resume.dataset.quand = 'reduit';
    const peindreResume = () => resume.replaceChildren(h('span', { class: 'cm-table__point', 'data-ton': (STATUTS[statut.code] || STATUTS.repos).ton, title: texteStatut(), 'aria-label': texteStatut() }));
    const rendre = () => {
      if (!pluginActif(ID)) { corps.replaceChildren(alerte('cierge', 'lu-plug', 'Plugin désactivé', 'Activez le plugin The Table dans la fenêtre Campagne, onglet Plugins.')); return; }
      corps.replaceChildren(vueTable({ compacte: true }));
    };
    rendre();
    peindreResume();
    surStatutFns.add(peindreResume);
    const off = surChangementPlugins(() => { if (corps.isConnected) rendre(); else off(); });
    // L'ambiance en cours suit la table (changée sur sa page, ou par un autre outil), tant que le widget est sur le tableau.
    const minuterie = setInterval(async () => {
      if (!corps.isConnected) { clearInterval(minuterie); surStatutFns.delete(peindreResume); return; }
      if (!corps.closest('.cm-tableau') || !pluginActif(ID)) return;
      try { const s = await appeler('/api/state'); const sc = s?.light?.scene || null; if (sc !== sceneCourante) { sceneCourante = sc; rendre(); } } catch { /* au prochain tour */ }
    }, 15000);
    actions.append(bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', titre: 'Réglages du plugin : fenêtre Campagne, onglet Plugins',
      onclick: () => document.querySelector('.cm-entete__outils .bn-btn[title="Réglages de la campagne"]')?.click() }));
    return {};
  },
};

// ───── Le plugin ─────

export default {
  id: ID,
  titre: 'The Table',
  icone: 'lu-lamp',
  description: 'Le boîtier qui pilote le ruban LED autour de votre table de jeu (ESP32, réseau local) : pendant un combat, la place du joueur dont c\'est le tour s\'éclaire et le cadre passe au rouge au tour des monstres ; dégâts, soins et critiques en effets lumineux ; ses ambiances d\'un clic.',
  defauts: DEFAUTS,
  widgets: [widget],
  emplacements: {
    combatEntete: () => pointStatut(),
  },
  reglages: vueReglages,

  async demarrer(ctx) {
    lire = ctx.reglages.lire;
    ctx.reglages.surChangement(() => planifier(0));
    ctx.ecouter('combat:etat', surCombat);
    ctx.ecouter('combat:pv', surPv);
    ctx.ecouter('des:resultat', surDes);
    majStatut(lire().combats ? 'repos' : 'inactif');
    // Page fermée en plein combat : la fin part au mieux (keepalive) ; sinon le bail de 15 min la couvre.
    window.addEventListener('pagehide', surFermeture);
    // Un combat piloté par The Screen resté sur la table (page fermée brutalement) sans combat ici : fin. Le widget Combat
    // a eu le temps d'émettre son état.
    setTimeout(async () => {
      try {
        const c = await appeler('/api/combat');
        if (c?.mode === 'remote' && c.source === SOURCE && !(instantane?.phase === 'combat')) await finir();
      } catch { /* table absente : rien à faire */ }
    }, 4000);
  },
  arreter() {
    window.removeEventListener('pagehide', surFermeture);
    arreterMinuteries();
    if (pilote) finir().catch(() => {});
    pilote = false; envoye = null; reprise = false; aFinir = false;
    majStatut('repos');
    flottantOuvert('plugin:the-table')?.fermer();
  },
};
function surFermeture() { if (pilote) finir({ keepalive: true }).catch(() => {}); }
