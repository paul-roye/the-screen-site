// Quêtes (demande du MJ, 2026-11-11) : le catalogue des quêtes proposées aux héros (data/quetes.json, formats/quetes.md) et
// celles que le MJ crée, leur suivi (etat/quetes.json, formats/etat.md). Une option de campagne (`quetes` de etat/campagne.json,
// fenêtre Campagne, onglet « Quêtes et réputation »), à part de la réputation (app/reputation.js), qu'elle nourrit.
// Une quête : qui la donne (faction, PNJ), son importance (anecdotique, mineure, majeure, épique : sa couleur), son niveau
// optimal (et la difficulté pour le groupe, pour le MJ), ses récompenses (or, objet, réputation, autre ; chacune cachable aux
// joueurs), ses conditions (rang de réputation, quête réussie, jalon, piste, étape, niveau), et ses étapes dans le déroulé :
// accepter la quête démarre la première. Les jalons et pistes d'une quête pas encore prise ne paraissent pas dans le Déroulé
// (cacheDansDeroule()). Rejouable : réussie ou échouée, elle revient au panneau. Cachée : pas sur le panneau des joueurs.
// Partagé : widget Quêtes, Déroulé, fiche d'une faction, fin de session, panneau de l'écran des joueurs.

import { h, icone, bouton, badge, alerte, flottant, flottantOuvert, lienFlottant, sansRamener, identifiant, infobulle, FINE } from './ui.js';
import { chargerLieux, nomLieu } from './lieux.js';
import { etatDeroule, statutDe, commencer, terminer, voirJalon, voirPiste, derouleSurLeTableau, derouleMonte, ICONES_JALON, ICONE_PISTE } from './trame.js';
import { etatHorloge, horlogeEnService, maintenant, libelleMoment, annoncer } from './horloge.js';
import { lireBeyond } from './beyond.js';
import { chargerReputation, reputationActive, ajuster, retirerLigne, ligneDeRecompense, rangParId, valeurDe, rangDe, signe, surReputation, teinte } from './reputation.js';
import { donnerOr, libelleDon } from './or.js';

export const IMPORTANCES = {
  anecdotique: { libelle: 'Anecdotique', couleur: 'cendre', ordre: 0 },
  mineure: { libelle: 'Mineure', couleur: 'brume', ordre: 1 },
  majeure: { libelle: 'Majeure', couleur: 'cierge', ordre: 2 },
  epique: { libelle: 'Épique', couleur: 'ultra', ordre: 3 },
};
// Les genres de quêtes d'office, quand data/quetes.json n'en donne pas (`types`) : le formulaire les propose, les quêtes les
// affichent (demande du MJ, 2026-11-12). Une campagne qui donne les siens les remplace tous.
export const TYPES_DEFAUT = { chasse: 'Chasse', escorte: 'Escorte', enquete: 'Enquête', livraison: 'Livraison', protection: 'Protection', recuperation: 'Récupération', sauvetage: 'Sauvetage', exploration: 'Exploration', diplomatie: 'Diplomatie', infiltration: 'Infiltration' };
export const TYPES_RECOMPENSES = { or: 'Or', objet: 'Objet', reputation: 'Réputation', autre: 'Autre' };
export const STATUTS = {
  disponible: { libelle: 'Proposée', couleur: 'brume', icone: 'lu-scroll-text' },
  verrouillee: { libelle: 'Verrouillée', couleur: null, icone: 'lu-lock' },
  prise: { libelle: 'Prise', couleur: 'cierge', icone: 'lu-flag' },
  reussie: { libelle: 'Réussie', couleur: 'soleil', icone: 'lu-check' },
  echouee: { libelle: 'Échouée', couleur: 'sang', icone: 'lu-x' },
};
// Difficulté pour le groupe : le niveau moyen des héros contre le niveau optimal de la quête (demande du MJ, 2026-11-12 : un
// niveau optimal plutôt qu'un intervalle). Relative : elle change quand le groupe monte de niveau.
export const DIFFICULTES = {
  facile: { libelle: 'Facile', couleur: 'mousse', aide: 'Le groupe a deux niveaux ou plus au-dessus du niveau optimal.' },
  adaptee: { libelle: 'Adaptée', couleur: 'brume', aide: 'Le groupe est au niveau optimal, ou un niveau au-dessus.' },
  difficile: { libelle: 'Difficile', couleur: 'cierge', aide: 'Le groupe a un ou deux niveaux de moins que le niveau optimal.' },
  dangereuse: { libelle: 'Dangereuse', couleur: 'sang', aide: 'Le groupe a trois niveaux ou plus de moins que le niveau optimal.' },
};

// Les statuts qu'on coche pour filtrer (demande du MJ, 2026-11-12) : le widget Quêtes (proposées et prises d'office) et chaque
// panneau des joueurs (proposées d'office). Proposées : disponibles, et dans le widget les verrouillées aussi (jamais sur un
// panneau) ; terminées : réussies ou échouées, et dans le widget une rejouable déjà faite une fois.
const ORDRE_PANNEAU = { prise: 0, disponible: 1, verrouillee: 1, reussie: 2, echouee: 2 };
export const GROUPES_STATUT = [['proposees', 'Proposées'], ['prises', 'Prises'], ['terminees', 'Terminées']];
export function dansStatuts(x, groupes, { panneau = false } = {}) {
  const st = x.statut;
  if (groupes.includes('proposees') && (st === 'disponible' || (!panneau && st === 'verrouillee'))) return true;
  if (groupes.includes('prises') && st === 'prise') return true;
  if (groupes.includes('terminees') && (st === 'reussie' || st === 'echouee' || (!panneau && (x.x.historique || []).length > 0))) return true;
  return false;
}
// Une case par statut, sur une ligne ; changer(groupes) à chaque clic.
export function casesStatuts(groupes, changer) {
  let cur = [...groupes];
  return h('div', { class: 'cm-quetes-statuts', role: 'group', 'aria-label': 'Statuts' }, GROUPES_STATUT.map(([val, lib]) => h('label', { class: 'cm-case' },
    h('input', { type: 'checkbox', class: 'bn-case', checked: cur.includes(val), onchange: e => { cur = e.target.checked ? [...new Set([...cur, val])] : cur.filter(g => g !== val); changer(cur); } }),
    h('span', {}, lib))));
}

export const etatQuetes = etat => etat('quetes', { schema: 1, quetes: {} });
let sCampagne = null;
export const quetesActives = () => !!sCampagne?.valeur.quetes?.actif;

// Le niveau optimal d'une quête (un entier) ; l'ancien intervalle { min, max } des premières données donne son milieu.
export const niveauOptimal = n => (n == null || n === '' ? null : typeof n === 'object' ? Math.round(((+n.min || 1) + (+n.max || +n.min || 1)) / 2) : Math.round(+n) || null);
export const libelleNiveau = n => { const o = niveauOptimal(n); return o ? `Niv.${FINE}${o}` : ''; };
export function difficultePour(niveau, groupe) {
  const o = niveauOptimal(niveau);
  if (!o || !groupe) return null;
  const ecart = groupe - o;
  return ecart >= 2 ? 'facile' : ecart >= 0 ? 'adaptee' : ecart >= -2 ? 'difficile' : 'dangereuse';
}

let promesse = null;
export function outilsQuetes(ctx) {
  promesse ||= creer(ctx);
  return promesse;
}
// Ouvrir une quête d'ailleurs (journal de réputation d'une faction) : seulement si les outils sont déjà là.
export function ouvrirQuete(id) { promesse?.then(Q => Q.ouvrir(id)); }

async function creer({ donnees, etat, dialogue }) {
  const s = await etatQuetes(etat);
  s.valeur.quetes ||= {};
  const v = () => s.valeur;
  sCampagne = await etat('campagne', { schema: 1 });
  await chargerReputation(etat);
  const dE = await etatDeroule(etat, donnees);
  const sH = await etatHorloge(etat);
  const lire = async j => (await donnees(j)).donnees;
  const [d, deroule, factionsD, pnjD, persosD, lectR, agendaD, lieux] = await Promise.all([
    lire('quetes'), lire('deroule-campagne'), lire('factions'), lire('pnj'), lire('personnages'), lire('rencontres-aleatoires'), lire('agenda'), chargerLieux(donnees)]);
  const donneesQuetes = d?.quetes || [];
  const typesQuetes = d?.types && Object.keys(d.types).length ? d.types : TYPES_DEFAUT;
  const parIdDonnees = new Map(donneesQuetes.map(q => [q.id, q]));
  const factions = factionsD?.factions || [];
  const factionParId = new Map(factions.map(f => [f.id, f]));
  const pnjParId = new Map((pnjD?.pnj || []).map(p => [p.id, p]));
  const jalonParId = new Map((deroule?.jalons || []).map(j => [j.id, j]));
  const pisteParId = new Map((deroule?.pistes || []).map(p => [p.id, p]));
  const etapeParId = new Map((deroule?.etapes || []).map(e => [e.id, e]));
  const scenarisees = new Map((lectR?.rencontres_scenarisees || []).map(r => [r.id, r]));
  const agendaParId = new Map((agendaD?.entrees || []).map(e => [e.id, e]));
  // Les objets (« Donner » une récompense) et les rencontres (« Lancer ») : chargés à la première demande, ils sont lourds.
  let O = null, R = null;
  const objets = async () => (O ||= await (await import('./objets.js')).outilsObjets({ donnees, etat, dialogue }));
  const rencontres = async () => (R ||= await (await import('./rencontres-mj.js')).outilsRencontresMj({ donnees, etat, dialogue }));
  const objetsD = (await lire('objets'))?.objets || [];
  const objetParId = new Map(objetsD.map(o => [o.id, o]));

  // Niveau moyen des héros : le relevé D&D Beyond, sinon `groupe.niveau` de personnages.json. Relu à la demande.
  let niveauGroupe = persosD?.groupe?.niveau || null;
  async function rafraichirNiveau() {
    const b = await lireBeyond().catch(() => null);
    const fiches = Object.values(b?.fiches || {}).filter(f => f.niveau);
    const n = fiches.length ? Math.max(1, Math.floor(fiches.reduce((a, f) => a + f.niveau, 0) / fiches.length)) : (persosD?.groupe?.niveau || null);
    const change = n !== niveauGroupe;
    niveauGroupe = n;
    return change;
  }
  await rafraichirNiveau();

  const reglages = () => sCampagne.valeur.quetes || {};
  function ecrireReglages(patch) {
    sCampagne.valeur.quetes = { ...reglages(), ...patch };
    sCampagne.enregistrer(0);
    sCampagne.signaler();
  }
  // L'importance, renommée ou recolorée par le fichier puis par le MJ.
  const importance = id => ({ ...IMPORTANCES[id] || IMPORTANCES.mineure, ...(d?.importances?.[id] || {}), ...(reglages().importances?.[id] || {}) });
  const nomFaction = id => factionParId.get(id)?.nom || id;
  const nomPnj = id => pnjParId.get(id)?.nom || id;

  // ───── Vues ─────
  const suiviDe = id => v().quetes[id] || {};
  const reussieUneFois = id => { const x = suiviDe(id); return x.statut === 'reussie' || (x.historique || []).some(e => e.issue === 'reussie'); };
  // Ce qui manque pour qu'une quête soit proposée : [texte].
  function manques(q) {
    const res = [];
    for (const c of q.conditions || []) {
      if (c.type === 'reputation') {
        if (!reputationActive()) continue;
        const val = valeurDe(c.faction);
        const rang = c.rang ? rangParId(c.rang) : null;
        const seuil = rang ? rang.min : +c.valeur;
        if (!(val >= seuil)) res.push(`Réputation ${rang ? rang.nom : signe(seuil)} auprès de ${nomFaction(c.faction)} (${rangDe(val).nom}, ${signe(val)})`);
      } else if (c.type === 'quete') {
        if (!reussieUneFois(c.quete)) res.push(`Avoir réussi « ${vueBrute(c.quete)?.nom || c.quete} »`);
      } else if (c.type === 'jalon' || c.type === 'piste' || c.type === 'etape') {
        const voulu = c.statut || (c.type === 'jalon' ? 'termine' : 'en-cours');
        const st = statutDe(dE.valeur, c.type, c[c.type]);
        const ok = voulu === 'termine' ? st === 'termine' : st !== 'a-venir';
        const nom = (c.type === 'jalon' ? jalonParId : c.type === 'piste' ? pisteParId : etapeParId).get(c[c.type])?.nom || c[c.type];
        if (!ok) res.push(`${{ jalon: 'Jalon', piste: 'Piste', etape: 'Étape' }[c.type]} « ${nom} » ${voulu === 'termine' ? 'terminé' : c.type === 'piste' ? 'commencée' : 'en cours'}`);
      } else if (c.type === 'niveau') {
        if (!(niveauGroupe >= +c.min)) res.push(`Niveau ${c.min} du groupe (${niveauGroupe ?? '?'})`);
      }
    }
    return res;
  }
  // La quête elle-même (données, ou créée par le MJ), sans son suivi.
  function vueBrute(id) {
    const x = v().quetes[id];
    if (x?.cree) return { ...x, id };
    return parIdDonnees.get(id) || null;
  }
  function vueDe(id) {
    const q = vueBrute(id);
    if (!q) return null;
    const x = suiviDe(id);
    const ms = manques(q);
    const statut = x.statut || (ms.length ? 'verrouillee' : 'disponible');
    const etapes = (q.etapes || []).map(e => (e.jalon ? { genre: 'jalon', id: e.jalon, el: jalonParId.get(e.jalon) } : { genre: 'piste', id: e.piste, el: pisteParId.get(e.piste) }));
    etapes.forEach(e => { e.statut = statutDe(dE.valeur, e.genre, e.id); });
    const faites = etapes.filter(e => e.statut === 'termine').length;
    const recompenses = (q.recompenses || []).map((r, i) => ({ ...r, i, cachee: recompenseCachee(q, x, r, i), versee: (x.versees || []).includes(i) }));
    const echeance = x.statut === 'prise' && q.echeance_jours && x.prise?.horloge ? x.prise.horloge.jour + q.echeance_jours : null;
    return {
      id, q, x, nom: q.nom, origine: x.cree ? 'cree' : 'donnees', statut, manques: ms,
      importance: q.importance in IMPORTANCES ? q.importance : 'mineure',
      difficulte: difficultePour(q.niveau, niveauGroupe),
      cachee: x.cachee ?? !!q.secret,
      recompensesCachees: x.recompenses_cachees ?? !!q.recompenses_cachees,
      recompenses, etapes, faites,
      // Prise et toutes ses étapes terminées : la quête attend d'être réglée (réussie ou échouée).
      aRegler: x.statut === 'prise' && etapes.length > 0 && faites === etapes.length,
      echeance, joursRestants: echeance && sH ? echeance - sH.valeur.jour : null,
      donneur: q.faction ? { cle: 'f:' + q.faction, nom: nomFaction(q.faction) } : q.pnj ? { cle: 'p:' + q.pnj, nom: nomPnj(q.pnj) } : { cle: '', nom: 'Sans donneur' },
    };
  }
  function recompenseCachee(q, x, r, i) {
    if (x.recompenses_cachees ?? q.recompenses_cachees) return true;
    if (Array.isArray(x.cachees)) return x.cachees.includes(i);
    return !!r.cachee;
  }
  const ids = () => [...new Set([...donneesQuetes.map(q => q.id), ...Object.keys(v().quetes).filter(id => v().quetes[id]?.cree)])];
  const tous = () => ids().map(vueDe).filter(Boolean);

  // ───── Le Déroulé : les jalons et pistes d'une quête pas prise n'y paraissent pas ─────
  // Un élément cité par les étapes d'une quête est caché tant qu'aucune de ses quêtes n'a été prise (en cours, réussie, échouée,
  // ou faite une fois) et qu'il n'est pas lui-même commencé.
  function cacheDansDeroule(genre, id) {
    if (!quetesActives()) return false;
    let cite = false;
    for (const qid of ids()) {
      const q = vueBrute(qid);
      if (!(q?.etapes || []).some(e => e[genre] === id)) continue;
      cite = true;
      const x = suiviDe(qid);
      if (x.statut || x.historique?.length) return false;
    }
    return cite && statutDe(dE.valeur, genre, id) === 'a-venir';
  }
  // Les quêtes qui se rattachent à un jalon (sans le démarrer) ou le démarrent : pour la fenêtre du jalon.
  const duJalon = jid => tous().filter(x => x.q.jalon === jid || (x.q.etapes || []).some(e => e.jalon === jid));
  const deLaFaction = fid => tous().filter(x => x.q.faction === fid);

  // ───── Changer le suivi ─────
  const quandMaintenant = () => ({ quand: new Date().toISOString(), ...(horlogeEnService() && sH ? { horloge: maintenant(sH.valeur) } : {}) });
  const entree = id => (v().quetes[id] ||= {});
  function enregistrer() {
    // Une entrée vide (rien de changé) disparaît.
    for (const [id, x] of Object.entries(v().quetes)) if (!x.cree && !Object.keys(x).length) delete v().quetes[id];
    s.enregistrer(0);
    s.signaler();
    rafraichirFenetres();
  }
  const ouvertes = new Set();
  const rafraichirFenetres = () => sansRamener(() => [...ouvertes].forEach(id => ouvrir(id)));

  // Accepter : la quête est prise, sa première étape démarre (jalon en cours, piste commencée) ; le Déroulé la montre.
  function accepter(id) {
    const vue = vueDe(id);
    if (!vue) return;
    const x = entree(id);
    x.statut = 'prise';
    x.prise = quandMaintenant();
    delete x.fin;
    x.versees = []; delete x.dons_or;
    const premiere = vue.etapes.find(e => e.el && e.statut !== 'termine');
    if (premiere) {
      commencer(dE.valeur, premiere.genre, premiere.id);
      dE.enregistrer(0);
      dE.signaler();
    }
    enregistrer();
    if (premiere && derouleSurLeTableau()) (premiere.genre === 'jalon' ? voirJalon : voirPiste)(premiere.id);
  }
  // Réussie ou échouée : la fenêtre de fin (récompenses à régler, étapes en cours à terminer), puis la fin notée.
  function finir(id, issue) {
    const vue = vueDe(id);
    if (!vue) return;
    const siOk = r => (r.si || 'reussite') === (issue === 'reussie' ? 'reussite' : 'echec');
    const aRegler = vue.recompenses.filter(siOk);
    const enCours = vue.etapes.filter(e => e.el && e.statut !== 'termine' && e.statut !== 'a-venir');
    // Cochées d'office : la réputation (si elle est suivie) et l'or d'une réussite, pas encore réglés.
    const casesR = aRegler.map(r => ({ r, input: h('input', { type: 'checkbox', class: 'bn-case', checked: r.type === 'reputation' ? reputationActive() && !r.versee : r.type === 'or' && issue === 'reussie' ? !r.versee : r.versee, disabled: r.type === 'reputation' && !reputationActive() }) }));
    const casesE = enCours.map(e => ({ e, input: h('input', { type: 'checkbox', class: 'bn-case', checked: issue === 'reussie' }) }));
    const remarque = h('textarea', { class: 'bn-textarea', rows: 3, placeholder: 'Ce qui s\'est passé (facultatif)', 'aria-label': 'Remarque' }, suiviDe(id).remarque?.texte || '');
    let dlg;
    dlg = dialogue('Quête', `${vue.nom} : ${issue === 'reussie' ? 'réussie' : 'échouée'}`, h('div', { class: 'cm-pile' },
      aRegler.length ? h('div', { class: 'cm-pile' }, h('p', { class: 'etiquette' }, issue === 'reussie' ? 'Récompenses' : 'Ce que coûte l\'échec'),
        casesR.map(({ r, input }) => h('label', { class: 'cm-case' }, input, h('span', {}, libelleRecompense(r),
          r.type === 'reputation' && !reputationActive() ? h('span', { class: 'ui-s cm-sourdine' }, ' (réputation désactivée)') : null,
          r.type === 'or' && issue === 'reussie' ? h('span', { class: 'ui-s cm-sourdine' }, ' : à donner ensuite (sur D&D Beyond, ou noté)') : null,
          r.type === 'objet' ? h('span', { class: 'ui-s cm-sourdine' }, ' : à donner ensuite (fenêtre de l\'objet)') : null)))) : h('p', { class: 'ui-s cm-sourdine' }, 'Pas de récompense prévue pour cette issue.'),
      casesE.length ? h('div', { class: 'cm-pile' }, h('p', { class: 'etiquette' }, 'Terminer aussi dans le Déroulé'),
        casesE.map(({ e, input }) => h('label', { class: 'cm-case' }, input, h('span', {}, icone(e.genre === 'jalon' ? ICONES_JALON[e.el.type] || 'lu-flag' : ICONE_PISTE, 'bn-icone--s'), ' ', e.el.nom)))) : null,
      vue.q.rejouable ? h('p', { class: 'ui-s cm-sourdine' }, 'Quête rejouable : elle revient au panneau, et cette fois est notée dans son historique.') : null,
      remarque),
    h('div', { class: 'bn-groupe' },
      bouton(issue === 'reussie' ? 'Marquer réussie' : 'Marquer échouée', { classe: 'bn-btn--primaire', icone: issue === 'reussie' ? 'lu-check' : 'lu-x', onclick: () => {
        // L'or d'une réussite se donne ensuite (fenêtre « Donner de l'or ») : réglé seulement une fois donné.
        const orADonner = issue === 'reussie' ? casesR.filter(c => c.r.type === 'or' && c.input.checked && !c.r.versee) : [];
        for (const { r, input } of casesR) if (!orADonner.some(c => c.r === r)) verser(id, r.i, input.checked, { sans: true });
        for (const { e, input } of casesE) if (input.checked) terminer(dE.valeur, e.genre, e.id);
        if (casesE.some(c => c.input.checked)) { dE.enregistrer(0); dE.signaler(); }
        const x = entree(id);
        const texte = remarque.value.trim();
        if (texte) x.remarque = { texte, maj: new Date().toISOString() }; else delete x.remarque;
        x.fin = quandMaintenant();
        if (vue.q.rejouable) {
          (x.historique ||= []).push({ issue, prise: x.prise || null, fin: x.fin, ...(texte ? { remarque: texte } : {}) });
          delete x.statut; delete x.prise; delete x.fin; delete x.remarque; x.versees = []; delete x.dons_or;
        } else x.statut = issue;
        enregistrer();
        dlg.close();
        const objetsADonner = casesR.filter(c => c.input.checked && c.r.type === 'objet' && objetParId.has(c.r.objet));
        if (objetsADonner.length) objets().then(o => objetsADonner.forEach(c => o.ouvrir(c.r.objet)));
        (async () => { for (const c of orADonner) await donnerOrRecompense(id, c.r, vue); })();
      } }),
      bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
  }
  // Donner l'or d'une récompense (app/or.js) : sur D&D Beyond ou noté ; le don est gardé avec la récompense, qui est réglée.
  // Une quête rejouable revenue au panneau garde le don dans sa dernière fois (historique).
  async function donnerOrRecompense(id, r, vue = vueDe(id)) {
    const don = await donnerOr({ donnees, dialogue, pieces: { po: +r.montant || 0 }, motif: `Quête « ${vue.nom} »` });
    if (!don) return;
    const x = entree(id);
    if (!x.statut && x.historique?.length) ((x.historique.at(-1).dons_or ||= {}))[r.i] = don;
    else { (x.dons_or ||= {})[r.i] = don; if (!(x.versees || []).includes(r.i)) x.versees = [...(x.versees || []), r.i]; }
    enregistrer();
  }
  const donDe = (x, i) => x.dons_or?.[i] || null;
  const nomHeros = hid => { const p = (persosD?.personnages || []).find(y => y.id === hid); return p?.nom_court || p?.nom || hid; };

  // Abandonner : la quête revient au panneau, la fois est notée (les étapes du Déroulé restent où elles en sont).
  function abandonner(id) {
    const x = entree(id);
    (x.historique ||= []).push({ issue: 'abandonnee', prise: x.prise || null, fin: quandMaintenant() });
    delete x.statut; delete x.prise; delete x.fin; x.versees = []; delete x.dons_or;
    enregistrer();
  }
  // Rouvrir une quête réussie ou échouée : de nouveau prise (les récompenses déjà réglées le restent).
  function rouvrir(id) { const x = entree(id); x.statut = 'prise'; delete x.fin; enregistrer(); }
  // Régler une récompense (ou la défaire) : la réputation s'applique au journal (et s'en retire), le reste est noté.
  function verser(id, i, oui, { sans = false } = {}) {
    const vue = vueDe(id);
    const r = vue?.recompenses[i];
    if (!r) return;
    const x = entree(id);
    const deja = (x.versees || []).includes(i);
    if (oui === deja) return;
    if (r.type === 'reputation' && reputationActive()) {
      if (oui) ajuster(r.faction, +r.valeur, { motif: vue.nom, quete: id, recompense: i });
      else { const l = ligneDeRecompense(id, i); if (l) retirerLigne(l.id); }
    }
    x.versees = oui ? [...(x.versees || []), i] : (x.versees || []).filter(k => k !== i);
    if (!oui && x.dons_or?.[i]) delete x.dons_or[i];   // le don noté s'efface (rien n'est repris sur D&D Beyond)
    if (!sans) enregistrer();
  }
  function basculerCachee(id) { const vue = vueDe(id); entree(id).cachee = !vue.cachee; enregistrer(); }
  function basculerRecompensesCachees(id) { const vue = vueDe(id); const x = entree(id); x.recompenses_cachees = !vue.recompensesCachees; enregistrer(); }
  function basculerRecompenseCachee(id, i) {
    const vue = vueDe(id);
    const x = entree(id);
    const cachees = new Set(vue.recompenses.filter(r => r.cachee).map(r => r.i));
    if (cachees.has(i)) cachees.delete(i); else cachees.add(i);
    x.cachees = [...cachees];
    if (vue.recompensesCachees) x.recompenses_cachees = false;
    enregistrer();
  }
  function noterRemarque(id, texte) {
    const x = entree(id);
    const t = String(texte || '').trim();
    if (t) x.remarque = { texte: t, maj: new Date().toISOString() }; else delete x.remarque;
    enregistrer();
  }

  // ───── Libellés ─────
  function libelleRecompense(r) {
    if (r.type === 'or') return `${r.montant ?? '?'}${FINE}po${r.texte ? ` (${r.texte})` : ''}`;
    if (r.type === 'objet') { const o = objetParId.get(r.objet); return o ? (o.nom_joueurs && o.nom_joueurs !== o.nom ? `${o.nom} (« ${o.nom_joueurs} »)` : o.nom) : r.objet; }
    if (r.type === 'reputation') return `Réputation ${signe(+r.valeur || 0)} auprès de ${nomFaction(r.faction)}`;
    return r.texte || 'Autre';
  }
  const iconeRecompense = r => ({ or: 'lu-coins', objet: 'amulette', reputation: 'lu-handshake', autre: 'lu-gift' }[r.type] || 'lu-gift');
  const badgeImportance = id => { const imp = importance(id); return h('span', { class: `cm-quete-imp cm-rep--${imp.couleur}` }, imp.libelle); };
  const badgeStatut = vue => { const st = STATUTS[vue.statut]; return vue.aRegler ? badge('À régler', 'cierge', 'lu-triangle-alert') : badge(st.libelle, st.couleur, st.icone); };
  function badgeDifficulte(vue) {
    if (!vue.difficulte) return null;
    const df = DIFFICULTES[vue.difficulte];
    return infobulle(h('span', { class: `cm-quete-diff cm-rep--${df.couleur}` }, libelleNiveau(vue.q.niveau)), `${df.libelle} pour le groupe (niveau moyen ${niveauGroupe}). ${df.aide}`, { titre: df.libelle });
  }

  // ───── Ligne d'une quête ─────
  function ligne(vue) {
    const imp = importance(vue.importance);
    const meta = [vue.q.type ? (typesQuetes[vue.q.type] || vue.q.type) : null, vue.q.lieu ? nomLieu(lieux, vue.q.lieu) : null,
      vue.etapes.length && vue.statut === 'prise' ? `${vue.faites}/${vue.etapes.length} étapes` : null,
      vue.joursRestants != null ? (vue.joursRestants < 0 ? `échéance dépassée de ${-vue.joursRestants} j` : `${vue.joursRestants} j restants`) : null].filter(Boolean).join(' · ');
    const btn = h('button', { type: 'button', class: `bn-carte cm-quete cm-ouvre cm-quete--${vue.statut}`, style: { '--quete-c': `var(--${teinte(imp.couleur)})` }, title: 'Ouvrir la quête', onclick: () => ouvrir(vue.id) },
      h('span', { class: 'cm-quete__nom cm-ouvre__nom' }, vue.statut === 'verrouillee' ? icone('lu-lock', 'bn-icone--s') : null, h('span', {}, vue.nom),
        vue.cachee ? icone('lu-eye-off', 'bn-icone--s cm-quete__cachee') : null),
      h('span', { class: 'cm-quete__badges' }, badgeDifficulte(vue) || (vue.q.niveau ? h('span', { class: 'cm-quete-diff' }, libelleNiveau(vue.q.niveau)) : null),
        vue.statut !== 'disponible' && vue.statut !== 'verrouillee' || vue.aRegler ? badgeStatut(vue) : null,
        vue.origine === 'cree' ? badge('MJ', 'sang', 'lu-pencil') : null),
      meta ? h('span', { class: 'cm-quete__meta' }, meta) : null);
    return lienFlottant(btn, 'quete:' + vue.id);
  }

  // Un jalon ou une piste d'une quête : sa fenêtre, ouverte par le Déroulé (sur le tableau ou dans la réserve d'un autre mode).
  // Une quête pas prise : ses jalons et pistes n'ont pas de ligne dans le Déroulé, seulement leur fenêtre.
  function voirDansDeroule(genre, eid, depuis) {
    if (!derouleMonte()) { annoncer({ cle: 'quete-sans-deroule', titre: 'Widget Déroulé absent', icone: 'lu-flag', couleur: 'brume', texte: 'Ajoutez le widget Déroulé au tableau pour ouvrir les jalons et les pistes d\'une quête.' }); return; }
    (genre === 'jalon' ? voirJalon : voirPiste)(eid, depuis);
  }
  // ───── Fenêtre d'une quête ─────
  function ouvrir(id, { depuis = null } = {}) {
    const vue = vueDe(id);
    if (!vue) return null;
    ouvertes.add(id);
    const q = vue.q, x = vue.x;
    const imp = importance(vue.importance);
    const lienFaction = fid => factionParId.has(fid) ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => voirFaction(fid) }, nomFaction(fid)) : h('span', {}, fid);
    const donneur = h('p', { class: 'ui-s cm-quete-donneur' }, icone('bouclier', 'bn-icone--s'), ' ',
      q.faction ? lienFaction(q.faction) : null, q.faction && q.pnj ? ' · ' : null, q.pnj ? h('span', {}, nomPnj(q.pnj)) : null,
      !q.faction && !q.pnj ? h('span', { class: 'cm-sourdine' }, 'Sans donneur') : null,
      q.lieu ? [h('span', { class: 'cm-sourdine' }, ' · '), icone('epingle', 'bn-icone--s'), ' ', nomLieu(lieux, q.lieu)] : null);
    const tete = h('div', { class: 'bn-groupe cm-quete-fiche__badges' }, badgeImportance(vue.importance), q.type ? badge(typesQuetes[q.type] || q.type, null) : null,
      badgeDifficulte(vue) || (q.niveau ? badge(libelleNiveau(q.niveau), null) : null), badgeStatut(vue),
      q.rejouable ? badge('Rejouable', null, 'lu-repeat') : null, vue.cachee ? badge('Cachée aux joueurs', 'ultra', 'lu-eye-off') : null);
    const conditions = (q.conditions || []).length ? h('div', { class: 'cm-quete-bloc' }, h('p', { class: 'etiquette' }, 'Conditions'),
      h('ul', { class: 'cm-quete-conditions' }, (vue.manques.length ? vue.manques.map(t => h('li', { class: 'est-manque' }, icone('lu-x', 'bn-icone--s'), t)) : [h('li', {}, icone('lu-check', 'bn-icone--s'), 'Remplies')]))) : null;
    const etapes = vue.etapes.length ? h('div', { class: 'cm-quete-bloc' }, h('p', { class: 'etiquette' }, `Dans le déroulé (${vue.faites}/${vue.etapes.length})`),
      h('ul', { class: 'cm-quete-etapes' }, vue.etapes.map(e => h('li', { class: `est-${e.statut}` },
        icone(e.genre === 'jalon' ? ICONES_JALON[e.el?.type] || 'lu-flag' : ICONE_PISTE, 'bn-icone--s'),
        e.el ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: e.genre === 'jalon' ? 'Ouvrir le jalon' : 'Ouvrir la piste', onclick: ev => voirDansDeroule(e.genre, e.id, ev.currentTarget) }, e.el.nom) : h('span', { class: 'cm-sourdine' }, `${e.id} (absent du déroulé)`),
        h('span', { class: 'ui-s cm-sourdine' }, ` · ${{ 'a-venir': 'à venir', 'en-cours': e.genre === 'piste' ? 'commencée' : 'en cours', termine: e.genre === 'piste' ? 'terminée' : 'terminé' }[e.statut]}`))))) : null;
    const liens = [
      q.jalon && jalonParId.has(q.jalon) ? h('li', {}, icone('lu-flag', 'bn-icone--s'), ' Rattachée au jalon ', h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Ouvrir le jalon', onclick: ev => voirDansDeroule('jalon', q.jalon, ev.currentTarget) }, jalonParId.get(q.jalon).nom)) : null,
      q.agenda && agendaParId.has(q.agenda) ? h('li', {}, icone('lu-calendar', 'bn-icone--s'), ' ', agendaParId.get(q.agenda).nom) : null,
    ].filter(Boolean);
    const zoneRencontres = h('div', { class: 'cm-quete-bloc' });
    if ((q.rencontres || []).length) rencontres().then(Rm => zoneRencontres.replaceChildren(h('p', { class: 'etiquette' }, 'Rencontres'),
      ...q.rencontres.map(rid => { const rv = Rm.vueDe(rid); return rv ? Rm.ligne(rv, { compacte: true }) : h('p', { class: 'ui-s cm-sourdine' }, `${scenarisees.get(rid)?.nom || rid} (absente)`); })));
    const prise = vue.statut === 'prise', finie = vue.statut === 'reussie' || vue.statut === 'echouee';
    const recompenses = h('div', { class: 'cm-quete-bloc' },
      h('div', { class: 'cm-quete-sous-titre' }, h('p', { class: 'etiquette' }, 'Récompenses'),
        q.recompenses?.length ? bouton('', { icone: vue.recompensesCachees ? 'lu-eye-off' : 'lu-eye', classe: 'bn-btn--s bn-btn--fantome' + (vue.recompensesCachees ? ' est-actif' : ''), titre: vue.recompensesCachees ? 'Récompenses cachées aux joueurs : les montrer' : 'Cacher toutes les récompenses aux joueurs', onclick: () => basculerRecompensesCachees(id) }) : null),
      vue.recompenses.length ? h('ul', { class: 'cm-quete-recompenses' }, vue.recompenses.map(r => h('li', { class: r.cachee ? 'est-cachee' : '' },
        // Les récompenses se règlent en marquant la quête réussie ou échouée (sa fenêtre) ; la case ne paraît qu'ensuite, pour
        // corriger, ou sur une récompense déjà réglée (pour la défaire).
        finie || r.versee ? h('input', { type: 'checkbox', class: 'bn-case', checked: r.versee, disabled: r.type === 'reputation' && !reputationActive(), title: r.type === 'reputation' ? 'Appliquer cette réputation (au journal)' : 'Réglée', 'aria-label': `Réglée : ${libelleRecompense(r)}`, onchange: e => verser(id, r.i, e.target.checked) }) : null,
        icone(iconeRecompense(r), 'bn-icone--s'),
        h('span', { class: 'ui-s' }, libelleRecompense(r), r.si === 'echec' ? h('span', { class: 'cm-sourdine' }, ' (si échec)') : null,
          r.type === 'or' && donDe(x, r.i) ? h('span', { class: 'cm-sourdine' }, ` · donné : ${libelleDon(donDe(x, r.i), nomHeros)}`) : null),
        r.type === 'objet' && objetParId.has(r.objet) ? bouton('', { icone: 'lu-gift', classe: 'bn-btn--s bn-btn--fantome', titre: 'Ouvrir l\'objet : le donner', onclick: () => objets().then(o => o.ouvrir(r.objet)) })
          // L'or d'une quête réussie pas encore donné : la pièce, qui ouvre « Donner de l'or ».
          : r.type === 'or' && vue.statut === 'reussie' && !r.versee && (r.si || 'reussite') === 'reussite' ? bouton('', { icone: 'lu-coins', classe: 'bn-btn--s bn-btn--fantome', titre: 'Donner cet or (sur D&D Beyond, ou noté)', onclick: () => donnerOrRecompense(id, r) }) : null,
        bouton('', { icone: r.cachee ? 'lu-eye-off' : 'lu-eye', classe: 'bn-btn--s bn-btn--fantome cm-quete-oeil', titre: r.cachee ? 'Cachée aux joueurs : la montrer' : 'Cacher cette récompense aux joueurs', onclick: () => basculerRecompenseCachee(id, r.i) }))))
        : h('p', { class: 'ui-s cm-sourdine' }, 'Aucune.'));
    const historique = (x.historique || []).length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `Historique (${x.historique.length})`),
      h('ul', { class: 'cm-liste ui-s' }, x.historique.map(e => h('li', {}, `${{ reussie: 'Réussie', echouee: 'Échouée', abandonnee: 'Abandonnée' }[e.issue]}, ${e.fin?.horloge ? libelleMoment(e.fin.horloge) : new Date(e.fin?.quand || Date.now()).toLocaleDateString('fr-FR')}${e.remarque ? ` : ${e.remarque}` : ''}`)))) : null;
    const remarque = x.remarque?.texte ? h('div', { class: 'cm-quete-remarque' }, icone('lu-pencil', 'bn-icone--s'), h('p', { class: 'ui-s' }, x.remarque.texte)) : null;
    const quand = t => (t?.horloge ? libelleMoment(t.horloge) : t?.quand ? new Date(t.quand).toLocaleDateString('fr-FR') : '');
    const actions = h('div', { class: 'cm-quete-actions' },
      vue.statut === 'disponible' || vue.statut === 'verrouillee' ? bouton('Accepter', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-flag', titre: vue.statut === 'verrouillee' ? 'Conditions non remplies : accepter quand même' : (vue.etapes.length ? 'Les héros prennent la quête : sa première étape démarre dans le Déroulé' : 'Les héros prennent la quête'), onclick: () => accepter(id) }) : null,
      prise ? bouton('Réussie', { classe: 'bn-btn--s cm-btn-reussie' + (vue.aRegler ? ' est-plein' : ''), icone: 'lu-check', titre: 'Marquer la quête réussie : régler ses récompenses', onclick: () => finir(id, 'reussie') }) : null,
      prise ? bouton('Échouée', { classe: 'bn-btn--s bn-btn--danger', icone: 'lu-x', titre: 'Marquer la quête échouée', onclick: () => finir(id, 'echouee') }) : null,
      prise ? bouton('', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-undo-2', titre: 'Abandonner : les héros renoncent : la quête revient au panneau (noté dans son historique)', onclick: () => abandonner(id) }) : null,
      finie ? bouton('Rouvrir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', titre: 'De nouveau prise', onclick: () => rouvrir(id) }) : null,
      bouton('', { icone: 'lu-pencil', classe: 'bn-btn--s bn-btn--fantome', titre: x.remarque ? 'Modifier la remarque' : 'Ajouter une remarque', onclick: () => saisirRemarque(id) }),
      bouton('', { icone: vue.cachee ? 'lu-eye-off' : 'lu-eye', classe: 'bn-btn--s bn-btn--fantome' + (vue.cachee ? ' est-actif' : ''), titre: vue.cachee ? 'Cachée aux joueurs (panneau des quêtes) : la montrer' : 'Cacher la quête aux joueurs (panneau des quêtes)', onclick: () => basculerCachee(id) }),
      vue.origine === 'cree' ? bouton('', { icone: 'lu-settings-2', classe: 'bn-btn--s bn-btn--fantome', titre: 'Modifier la quête', onclick: () => formulaire(id) }) : null,
      vue.origine === 'cree' ? bouton('', { icone: 'lu-trash-2', classe: 'bn-btn--s bn-btn--fantome', titre: 'Supprimer la quête', onclick: () => supprimer(id) }) : null);
    const contenu = h('div', { class: 'cm-pile cm-quete-fiche', style: { '--quete-c': `var(--${teinte(imp.couleur)})` } },
      tete, h('div', { class: 'cm-quete-qui' }, donneur,
      prise || finie ? h('p', { class: 'ui-s cm-sourdine' }, prise ? `Prise ${quand(x.prise)}` : `${vue.statut === 'reussie' ? 'Réussie' : 'Échouée'} ${quand(x.fin)}`,
        vue.joursRestants != null ? h('span', { class: vue.joursRestants < 0 ? 'cm-quete-retard' : '' }, vue.joursRestants < 0 ? ` · échéance dépassée de ${-vue.joursRestants} jour${vue.joursRestants < -1 ? 's' : ''}` : ` · ${vue.joursRestants} jour${vue.joursRestants > 1 ? 's' : ''} pour la mener`) : null) : null),
      vue.aRegler ? alerte('cierge', 'lu-triangle-alert', 'Toutes ses étapes sont terminées', 'Marquez-la réussie ou échouée pour régler ses récompenses.') : null,
      h('p', { class: 'ui' }, q.description || h('span', { class: 'cm-sourdine' }, 'Pas de description.')),
      q.objectifs?.length ? h('ul', { class: 'cm-liste ui-s' }, q.objectifs.map(o => h('li', {}, o))) : null,
      q.mj ? h('div', { class: 'cm-pour-mj' }, h('p', { class: 'etiquette cm-pour-mj__titre' }, icone('lu-eye-off', 'bn-icone--s'), 'Pour le MJ, ne pas lire'), h('p', { class: 'ui-s' }, q.mj)) : null,
      q.decision_mj ? h('div', { class: 'cm-decision' }, badge('Décision du MJ', 'sang'), h('p', { class: 'ui-s' }, q.decision_mj.texte)) : null,
      conditions, etapes, liens.length ? h('ul', { class: 'cm-quete-liens ui-s' }, liens) : null, zoneRencontres, recompenses, remarque, historique, actions);
    const f = flottant('quete:' + id, { surtitre: `Quête · ${vue.donneur.nom}`, titre: vue.nom, contenu, largeur: 460, depuis, pictogramme: 'lu-scroll-text',
      surFermeture: () => ouvertes.delete(id) });
    return f;
  }
  function saisirRemarque(id) {
    const avant = suiviDe(id).remarque?.texte || '';
    const champ = h('textarea', { class: 'bn-textarea', rows: 5, placeholder: 'Ce qui s\'est passé, ce qui a été promis…', 'aria-label': 'Remarque du MJ' }, avant);
    let dlg;
    dlg = dialogue('Remarque sur une quête', vueBrute(id)?.nom || id, champ, h('div', { class: 'bn-groupe' },
      bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => { if (champ.value.trim() !== avant) noterRemarque(id, champ.value); dlg.close(); } }),
      bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    setTimeout(() => champ.focus(), 0);
  }

  // La liste du niveau optimal (1 à 20, ou aucun) : chaque niveau avec sa difficulté pour le groupe d'aujourd'hui, et dessous
  // celle du niveau choisi. Renvoie { el, valeur() }.
  function selectNiveau(niveau) {
    const n = niveauOptimal(niveau);
    const sel = h('select', { class: 'bn-select', 'aria-label': 'Niveau optimal' },
      h('option', { value: '', selected: !n }, '—'),
      Array.from({ length: 20 }, (_, i) => i + 1).map(k => { const df = difficultePour(k, niveauGroupe); return h('option', { value: k, selected: k === n }, df ? `${k} · ${DIFFICULTES[df].libelle}` : String(k)); }));
    const info = h('span', { class: 'ui-s cm-quete-niv-info' });
    const maj = () => {
      const df = difficultePour(+sel.value, niveauGroupe);
      info.replaceChildren(...(!sel.value ? [h('span', { class: 'cm-sourdine' }, niveauGroupe ? `Groupe au niveau ${niveauGroupe}.` : 'Niveau du groupe inconnu.')]
        : df ? [h('span', { class: `cm-quete-diff cm-rep--${DIFFICULTES[df].couleur}` }, DIFFICULTES[df].libelle), ` pour le groupe (niveau ${niveauGroupe})`]
          : [h('span', { class: 'cm-sourdine' }, 'Niveau du groupe inconnu : pas de difficulté.')]));
    };
    sel.addEventListener('change', maj);
    maj();
    return { el: h('div', { class: 'cm-quete-niv' }, sel, info), valeur: () => Math.round(+sel.value) || null };
  }

  // ───── Créer une quête (formulaire simple : pas d'étapes ni de conditions) ─────
  function nouvelle(defaut = {}) { formulaire(null, defaut); }
  function formulaire(id, defaut = {}) {
    const q = id ? v().quetes[id] : { importance: 'mineure', recompenses: [], ...defaut };
    // Chaque libellé dit si le champ est obligatoire (le titre, l'importance) ou facultatif (tout le reste, jalon compris).
    const marque = oblig => h('span', { class: 'cm-champ-marque' + (oblig ? ' est-obligatoire' : '') }, oblig ? 'obligatoire' : 'facultatif');
    const etiquette = (libelle, oblig = false) => h('span', { class: 'bn-champ__label' }, libelle, marque(oblig));
    const champ = (libelle, input, aide, oblig = false) => h('label', { class: 'bn-champ' }, etiquette(libelle, oblig), input, aide ? h('span', { class: 'ui-s cm-sourdine' }, aide) : null);
    const choix = (valeur, options, label) => h('select', { class: 'bn-select', 'aria-label': label }, options.map(([val, lib]) => h('option', { value: val, selected: val === (valeur || '') }, lib)));
    const nom = h('input', { class: 'bn-input', type: 'text', value: q.nom || '', placeholder: 'Des loups au col de Brenn', required: true });
    const faction = choix(q.faction, [['', '—'], ...factions.map(f => [f.id, f.nom])], 'Faction');
    const pnj = choix(q.pnj, [['', '—'], ...[...pnjParId.values()].sort((a, b) => a.nom.localeCompare(b.nom, 'fr')).map(p => [p.id, p.nom])], 'PNJ');
    const lieu = choix(q.lieu, [['', '—'], ...[...lieux.values()].filter(l => !l.parent).sort((a, b) => a.nom.localeCompare(b.nom, 'fr')).map(l => [l.id, l.nom])], 'Lieu');
    const imp = choix(q.importance, Object.keys(IMPORTANCES).map(k => [k, importance(k).libelle]), 'Importance');
    // Les types de la campagne (ou d'office) ; un type d'une ancienne quête qui n'y est plus reste choisi.
    const types = Object.entries(typesQuetes);
    if (q.type && !typesQuetes[q.type]) types.push([q.type, q.type]);
    const type = choix(q.type, [['', '—'], ...types], 'Type');
    // Le niveau optimal : chaque niveau de la liste dit ce qu'il serait pour le groupe aujourd'hui (« 4 · Difficile ») ; sous la
    // liste, la difficulté du niveau choisi, à sa couleur.
    const niv = selectNiveau(q.niveau);
    const desc = h('textarea', { class: 'bn-textarea', rows: 3, placeholder: 'Ce que lisent les joueurs' }, q.description || '');
    const mj = h('textarea', { class: 'bn-textarea', rows: 2, placeholder: 'Pour le MJ seul' }, q.mj || '');
    const jalon = choix(q.jalon, [['', '—'], ...[...jalonParId.values()].map(j => [j.id, j.nom])], 'Jalon');
    const echeance = h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '1', value: q.echeance_jours || '', 'aria-label': 'Échéance en jours' });
    const rejouable = h('input', { type: 'checkbox', class: 'bn-case', checked: !!q.rejouable });
    // Récompenses : une ligne par récompense, son type puis ses champs.
    const recs = (q.recompenses || []).map(r => ({ ...r }));
    const zoneRecs = h('div', { class: 'cm-pile' });
    const dessinerRecs = () => zoneRecs.replaceChildren(...recs.map((r, i) => {
      const typeR = choix(r.type, Object.entries(TYPES_RECOMPENSES), 'Type de récompense');
      typeR.addEventListener('change', () => { recs[i] = { type: typeR.value }; dessinerRecs(); });
      const champs = r.type === 'or' ? [h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '0', value: r.montant ?? '', placeholder: 'po', 'aria-label': 'Montant en po', oninput: e => { recs[i].montant = Math.round(+e.target.value) || 0; } })]
        : r.type === 'objet' ? [choix(r.objet, [['', '— un objet de objets.json —'], ...objetsD.map(o => [o.id, o.nom])], 'Objet')]
        : r.type === 'reputation' ? [choix(r.faction, [['', '— faction —'], ...factions.map(f => [f.id, f.nom])], 'Faction'), h('input', { class: 'bn-input bn-input--nombre', type: 'number', step: '5', value: r.valeur ?? '', placeholder: '+25', 'aria-label': 'Réputation', oninput: e => { recs[i].valeur = Math.round(+e.target.value) || 0; } })]
        : [h('input', { class: 'bn-input', type: 'text', value: r.texte || '', placeholder: 'Une faveur, un titre…', 'aria-label': 'Récompense', oninput: e => { recs[i].texte = e.target.value; } })];
      champs.filter(c => c.tagName === 'SELECT').forEach(c => c.addEventListener('change', () => { recs[i][r.type === 'objet' ? 'objet' : 'faction'] = c.value; }));
      return h('div', { class: 'cm-quete-form-rec' }, typeR, ...champs, bouton('', { icone: 'lu-x', classe: 'bn-btn--s bn-btn--fantome', titre: 'Retirer', onclick: () => { recs.splice(i, 1); dessinerRecs(); } }));
    }), bouton('Récompense', { icone: 'lu-plus', classe: 'bn-btn--s bn-btn--fantome', onclick: () => { recs.push({ type: 'or' }); dessinerRecs(); } }));
    dessinerRecs();
    const erreur = h('div');
    let dlg;
    dlg = dialogue('Quête', id ? 'Modifier la quête' : 'Nouvelle quête', h('div', { class: 'cm-pile cm-config' },
      champ('Titre', nom, null, true),
      h('div', { class: 'bn-ligne-champs' }, champ('Faction', faction), champ('PNJ', pnj), champ('Lieu', lieu)),
      h('div', { class: 'bn-ligne-champs' }, champ('Importance', imp, null, true), champ('Type', type),
        h('div', { class: 'bn-champ' }, etiquette('Niveau optimal'), niv.el)),
      champ('Description', desc), champ('Note du MJ', mj),
      h('div', { class: 'bn-champ' }, etiquette('Récompenses'), zoneRecs),
      h('div', { class: 'bn-ligne-champs' }, champ('Rattachée au jalon', jalon, 'Sans le démarrer.'), champ('Échéance (jours)', echeance)),
      h('label', { class: 'cm-case' }, rejouable, h('span', {}, h('b', {}, 'Rejouable'), marque(false), h('br'), h('span', { class: 'ui-s cm-sourdine' }, 'Réussie ou échouée, elle revient au panneau.'))),
      erreur),
    h('div', { class: 'bn-groupe' },
      bouton(id ? 'Enregistrer' : 'Créer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => {
        if (!nom.value.trim()) { erreur.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Titre manquant', 'Donnez un titre à la quête.')); return; }
        const quete = {
          ...(id ? v().quetes[id] : { creee: new Date().toISOString() }), cree: true,
          nom: nom.value.trim(), faction: faction.value || undefined, pnj: pnj.value || undefined, lieu: lieu.value || undefined,
          importance: imp.value, type: type.value.trim() || undefined,
          niveau: niv.valeur() || undefined,
          description: desc.value.trim(), mj: mj.value.trim() || undefined, jalon: jalon.value || undefined,
          echeance_jours: Math.round(+echeance.value) || undefined, rejouable: rejouable.checked || undefined,
          recompenses: recs.filter(r => (r.type === 'or' && r.montant) || (r.type === 'objet' && r.objet) || (r.type === 'reputation' && r.faction && r.valeur) || (r.type === 'autre' && r.texte?.trim())),
        };
        const nid = id || 'mj-' + identifiant();
        v().quetes[nid] = JSON.parse(JSON.stringify(quete));
        enregistrer();
        dlg.close();
        ouvrir(nid);
      } }),
      bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })), { large: true });
    setTimeout(() => nom.focus(), 0);
  }
  function supprimer(id) {
    let dlg;
    dlg = dialogue('Quête', 'Supprimer la quête ?', h('p', { class: 'ui' }, `« ${vueBrute(id)?.nom} » et son suivi seront supprimés. La réputation déjà appliquée reste au journal.`), h('div', { class: 'bn-groupe' },
      bouton('Supprimer', { classe: 'bn-btn--primaire', icone: 'lu-trash-2', onclick: () => { delete v().quetes[id]; flottantOuvert('quete:' + id)?.fermer(); enregistrer(); dlg.close(); } }),
      bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
  }

  // ───── Panneaux des joueurs ─────
  // Plusieurs panneaux, propres au gestionnaire (demande du MJ, 2026-11-12 : le panneau de la garde, celui de la guilde…),
  // dans `quetes.panneaux` de etat/campagne.json : { id, titre, factions, importances, quetes, niveau_min, niveau_max,
  // niveau_affiche ('niveau' | 'difficulte' | 'rien') }. L'ancien panneau unique (`quetes.panneau`) devient le premier.
  function panneaux() {
    const r = reglages();
    if (Array.isArray(r.panneaux)) return r.panneaux;
    return r.panneau ? [{ id: 'panneau', titre: r.panneau.titre || '', ...r.panneau }] : [];
  }
  function ecrirePanneaux(liste) {
    const r = { ...reglages(), panneaux: liste };
    delete r.panneau;
    sCampagne.valeur.quetes = r;
    sCampagne.enregistrer(0);
    sCampagne.signaler();
  }
  const titrePanneau = p => p?.titre?.trim() || 'Quêtes proposées';
  // Les quêtes que voient les joueurs : pas cachées, des statuts cochés du panneau (`statuts`, d'office les proposées ; une
  // verrouillée jamais), selon ses filtres ; le niveau optimal dans l'intervalle du panneau (une quête sans niveau passe
  // toujours). Les prises d'abord, puis les proposées, puis les terminées.
  function panneau(reglage = panneaux()[0] || {}) {
    const fs = reglage.factions || [], qs = reglage.quetes || [], imps = reglage.importances || [];
    return tous().filter(x => {
      if (x.cachee || !dansStatuts(x, reglage.statuts?.length ? reglage.statuts : ['proposees'], { panneau: true })) return false;
      if (qs.length) return qs.includes(x.id);
      const o = niveauOptimal(x.q.niveau);
      return (!fs.length || fs.includes(x.q.faction)) && (!imps.length || imps.includes(x.importance))
        && (o == null || ((reglage.niveau_min == null || o >= reglage.niveau_min) && (reglage.niveau_max == null || o <= reglage.niveau_max)));
    }).sort((a, b) => ORDRE_PANNEAU[a.statut] - ORDRE_PANNEAU[b.statut] || importance(b.importance).ordre - importance(a.importance).ordre || a.nom.localeCompare(b.nom, 'fr'));
  }

  // Une étape de quête terminée ailleurs (Déroulé) : la quête est à régler, une annonce le dit (une fois).
  let aReglerConnus = new Set(tous().filter(x => x.aRegler).map(x => x.id));
  dE.abonner(() => {
    const maintenantARegler = tous().filter(x => x.aRegler);
    for (const x of maintenantARegler) if (!aReglerConnus.has(x.id)) annoncer({ cle: 'quete-a-regler-' + x.id, titre: `Quête « ${x.nom} » : toutes ses étapes sont terminées`, icone: 'lu-scroll-text', couleur: 'cierge', texte: 'Marquez-la réussie ou échouée dans le widget Quêtes, pour régler ses récompenses.' });
    aReglerConnus = new Set(maintenantARegler.map(x => x.id));
    s.signaler();
    rafraichirFenetres();
  });
  surReputation(() => { s.signaler(); rafraichirFenetres(); });

  return {
    s, v, d, sCampagne, donneesPresentes: !!d, factions, factionParId, nomFaction, nomPnj,
    tous, vueDe, duJalon, deLaFaction, ligne, ouvrir, nouvelle, formulaire, accepter, finir, abandonner, verser,
    basculerCachee, cacheDansDeroule, panneau, panneaux, ecrirePanneaux, titrePanneau, importance, reglages, ecrireReglages, libelleRecompense,
    niveauGroupe: () => niveauGroupe, rafraichirNiveau,
  };
}

// La fin de session : les quêtes prises, réussies, échouées ou abandonnées depuis une date, et celles en cours.
export function resumeSessionQuetes(Q, depuis) {
  if (!Q || !quetesActives()) return { faites: [], enCours: [] };
  const apres = t => t?.quand && (!depuis || t.quand > depuis);
  const faites = [];
  for (const x of Q.tous()) {
    if (apres(x.x.prise)) faites.push(`« ${x.nom} » (${x.donneur.nom}) : prise${x.x.prise.horloge ? `, ${libelleMoment(x.x.prise.horloge)}` : ''}.`);
    if ((x.statut === 'reussie' || x.statut === 'echouee') && apres(x.x.fin)) faites.push(`« ${x.nom} » : ${x.statut === 'reussie' ? 'réussie' : 'échouée'}${x.x.remarque ? ` (${x.x.remarque.texte})` : ''}.`);
    for (const e of x.x.historique || []) if (apres(e.fin)) faites.push(`« ${x.nom} » : ${{ reussie: 'réussie', echouee: 'échouée', abandonnee: 'abandonnée' }[e.issue]}${e.remarque ? ` (${e.remarque})` : ''}.`);
  }
  const enCours = Q.tous().filter(x => x.statut === 'prise').map(x => `« ${x.nom} » (${x.donneur.nom})${x.etapes.length ? `, ${x.faites}/${x.etapes.length} étapes` : ''}${x.x.remarque ? ` : ${x.x.remarque.texte}` : ''}`);
  return { faites, enCours };
}

// Réglages des quêtes (fenêtre Campagne, onglet « Quêtes et réputation ») : les activer, et renommer ou recolorer les quatre
// importances (le système de couleurs de la campagne). sC : etat/campagne.json ; importancesFichier : `importances` de quetes.json.
export function contenuReglagesQuetes(sC, { importancesFichier = {}, couleurs = [] } = {}) {
  const el = h('div', { class: 'cm-pile' });
  const lire = () => sC.valeur.quetes || {};
  const ecrire = patch => { sC.valeur.quetes = { ...lire(), ...patch }; sC.enregistrer(0); sC.signaler(); rendre(); };
  function rendre() {
    const r = lire();
    const imp = id => ({ ...IMPORTANCES[id], ...(importancesFichier[id] || {}), ...(r.importances?.[id] || {}) });
    const ecrireImp = (id, patch) => ecrire({ importances: { ...(r.importances || {}), [id]: { ...(r.importances?.[id] || {}), ...patch } } });
    const zone = h('div', { class: 'cm-reglage__sous cm-pile' + (r.actif ? '' : ' est-eteint') },
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Importances : leur nom et leur couleur'),
        h('div', { class: 'cm-pile' }, Object.keys(IMPORTANCES).map(id => h('div', { class: 'cm-rep-reglage-rang cm-rep-reglage-rang--court' },
          h('span', { class: `cm-rep-pastille cm-rep--${imp(id).couleur}`, 'aria-hidden': 'true' }),
          h('input', { class: 'bn-input', type: 'text', value: imp(id).libelle, 'aria-label': `Nom de l'importance ${IMPORTANCES[id].libelle}`, onchange: e => ecrireImp(id, { libelle: e.target.value.trim() || IMPORTANCES[id].libelle }) }),
          h('select', { class: 'bn-select', 'aria-label': 'Couleur', onchange: e => ecrireImp(id, { couleur: e.target.value }) }, couleurs.map(([c, lib]) => h('option', { value: c, selected: c === imp(id).couleur }, lib)))))),
        h('div', { class: 'bn-groupe' }, bouton('Par défaut', { icone: 'lu-rotate-ccw', classe: 'bn-btn--s bn-btn--fantome', titre: 'Anecdotique, Mineure, Majeure, Épique, aux couleurs de départ (ou celles de data/quetes.json)', onclick: () => ecrire({ importances: null }) })),
        h('span', { class: 'ui-s cm-sourdine' }, 'La couleur d\'une quête sur le panneau. Un système propre à votre campagne (« blanche, verte, rouge, noire ») : renommez-les ici.')));
    zone.inert = !r.actif;
    el.replaceChildren(h('div', { class: 'cm-reglage' },
      h('label', { class: 'cm-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: !!r.actif, onchange: e => ecrire({ actif: e.target.checked }) }),
        h('span', {}, h('b', {}, 'Catalogue de quêtes'), h('br'),
          h('span', { class: 'ui-s cm-sourdine' }, 'Le widget Quêtes : les quêtes proposées aux héros par les factions et les PNJ (data/quetes.json, et celles que vous créez), leur importance, leurs récompenses, leurs conditions, le panneau pour l\'écran des joueurs. Accepter une quête démarre ses étapes dans le Déroulé, qui ne les montre pas avant.'))),
      zone));
  }
  rendre();
  return el;
}

// La fiche d'une faction, ouverte par le widget Factions (cm:voir-faction) ; sans lui, une annonce le dit.
export function voirFaction(id) {
  const ev = new CustomEvent('cm:voir-faction', { detail: { id, ouvert: false } });
  document.dispatchEvent(ev);
  if (!ev.detail.ouvert) annoncer({ cle: 'factions-absent', titre: 'Widget Factions absent', icone: 'bouclier', couleur: 'brume', texte: 'Ajoutez le widget Factions au tableau pour ouvrir la fiche d\'une faction (et sa réputation).' });
}
