// Donner de l'or (demande du MJ, 2026-11-12) : des pièces (pc, pa, pe, po, pp) à un héros, partagées à parts égales entre des
// héros (le reste à la bourse du groupe), ou à la bourse du groupe, écrites sur D&D Beyond par l'extension du MJ (commande
// `pieces`, depuis 1.20.0) ; ou seulement notées (les joueurs les ajoutent eux-mêmes). Ce qui est donné revient à l'appelant,
// qui le garde (le « donné » d'une récompense de quête, du butin d'une rencontre).
// Partagé : quêtes (récompenses), rencontres (butin), fiche du groupe (Personnages).
//
// Un don : { quand, pieces { pc, pa, pe, po, pp }, a ('groupe' | id de personnages.json | 'partage'), heros [id] (partage),
// beyond (vrai : écrit sur D&D Beyond ; faux : noté seulement), motif }.

import { h, icone, bouton, alerte, FINE } from './ui.js';
import { lireBeyond, demanderExtension, ficheDe } from './beyond.js';

export const PIECES = [['pp', 'pp'], ['po', 'po'], ['pe', 'pe'], ['pa', 'pa'], ['pc', 'pc']];
const VALEUR_PC = { pc: 1, pa: 10, pe: 50, po: 100, pp: 1000 };

// « 12 po, 5 pa » ; « rien ».
export const libellePieces = p => PIECES.filter(([k]) => p?.[k]).map(([k]) => `${p[k]}${FINE}${k}`).join(', ') || 'rien';
export const valeurPc = p => PIECES.reduce((s, [k]) => s + (p?.[k] || 0) * VALEUR_PC[k], 0);

// Un don en une ligne : « 40 po au groupe », « 120 po partagées entre Ine, Lise », « 15 po à Gaspard (noté) ».
export function libelleDon(d, nomPerso = id => id) {
  const a = d.a === 'groupe' ? 'au groupe' : d.a === 'partage' ? `partagées entre ${(d.heros || []).map(nomPerso).join(', ')}` : `à ${nomPerso(d.a)}`;
  return `${libellePieces(d.pieces)} ${a}${d.beyond ? '' : ' (noté)'}`;
}

// Le partage à parts égales : chaque pièce divisée entre k héros, le reste au groupe. → { parHeros, reste }
export function partager(pieces, k) {
  const parHeros = {}, reste = {};
  for (const [c] of PIECES) {
    const n = Math.max(0, Math.round(pieces?.[c] || 0));
    parHeros[c] = k ? Math.floor(n / k) : 0;
    reste[c] = n - parHeros[c] * k;
  }
  return { parHeros, reste };
}

// La fenêtre « Donner de l'or ». Résout le don fait, ou null (fermée, annulée).
// { donnees, dialogue, pieces (préremplies), motif (« Quête : Des loups… »), titre }
export async function donnerOr({ donnees, dialogue, pieces = {}, motif = '', titre = 'Donner de l\'or' }) {
  const persosD = (await donnees('personnages')).donnees;
  const heros = (persosD?.personnages || []).filter(p => p.role === 'personnage');
  const nomPerso = id => { const p = heros.find(x => x.id === id); return p?.nom_court || p?.nom || id; };
  const beyond = await lireBeyond().catch(() => null);
  const ficheBeyond = id => { const p = heros.find(x => x.id === id); return p && beyond ? ficheDe(p, beyond) : null; };
  const campagneBeyond = beyond?.campagne?.id || null;
  const membre = beyond ? Object.keys(beyond.fiches || {})[0] : null;

  return new Promise(resoudre => {
    let fini = false;
    const fin = v => { if (fini) return; fini = true; resoudre(v); dlg.close(); };
    const montants = Object.fromEntries(PIECES.map(([k]) => [k, h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '0', step: '1', value: pieces[k] || '', 'aria-label': k, oninput: maj })]));
    const lire = () => Object.fromEntries(PIECES.map(([k]) => [k, Math.max(0, Math.round(+montants[k].value) || 0)]));
    let mode = 'partage';
    const choixHeros = h('select', { class: 'bn-select', 'aria-label': 'Héros', onchange: maj }, heros.map(p => h('option', { value: p.id }, nomPerso(p.id))));
    const cases = heros.map(p => ({ id: p.id, input: h('input', { type: 'checkbox', class: 'bn-case', checked: true, onchange: maj }) }));
    const radio = (val, lib) => h('label', { class: 'cm-case' }, h('input', { type: 'radio', name: 'or-a', class: 'bn-case', checked: val === mode, onchange: () => { mode = val; maj(); } }), h('span', {}, lib));
    const zoneHeros = h('div', { class: 'cm-or__heros' });
    const apercu = h('p', { class: 'ui-s cm-sourdine' });
    const erreur = h('div');
    const choisis = () => cases.filter(c => c.input.checked).map(c => c.id);
    function maj() {
      zoneHeros.replaceChildren(...(mode === 'heros' ? [choixHeros] : mode === 'partage' ? [h('div', { class: 'cm-quetes-cases' }, cases.map(c => h('label', { class: 'cm-case' }, c.input, h('span', {}, nomPerso(c.id)))))] : []));
      const p = lire();
      if (mode === 'partage') {
        const k = choisis().length;
        const { parHeros, reste } = partager(p, k);
        apercu.textContent = k ? `Chacun : ${libellePieces(parHeros)}${valeurPc(reste) ? ` ; au groupe, le reste : ${libellePieces(reste)}` : ''}.` : 'Cochez au moins un héros.';
      } else apercu.textContent = valeurPc(p) ? `${libellePieces(p)} ${mode === 'groupe' ? 'à la bourse commune du groupe' : `à ${nomPerso(choixHeros.value)}`}.` : '';
    }
    // Les appels à l'extension : une fiche (heros), la bourse du groupe ; sur D&D Beyond, les montants s'ajoutent.
    async function versBeyond(a, p) {
      if (!valeurPc(p)) return;
      if (a === 'groupe') {
        if (!membre || !campagneBeyond) throw new Error('Campagne D&D Beyond pas encore relevée par l\'extension.');
        await demanderExtension({ type: 'pieces', personnage: membre, groupe: true, campagne: campagneBeyond, pieces: p });
      } else {
        const f = ficheBeyond(a);
        if (!f) throw new Error(`Fiche D&D Beyond de ${nomPerso(a)} introuvable dans les relevés de l'extension.`);
        await demanderExtension({ type: 'pieces', personnage: f.id, groupe: false, pieces: p });
      }
    }
    async function valider(surBeyond) {
      const p = lire();
      if (!valeurPc(p)) { erreur.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Aucune pièce', 'Indiquez au moins un montant.')); return; }
      const a = mode === 'heros' ? choixHeros.value : mode;
      const herosPartage = mode === 'partage' ? choisis() : null;
      if (mode === 'partage' && !herosPartage.length) { erreur.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Aucun héros', 'Cochez au moins un héros pour le partage.')); return; }
      const don = { quand: new Date().toISOString(), pieces: p, a, ...(herosPartage ? { heros: herosPartage } : {}), beyond: surBeyond, motif };
      if (!surBeyond) { fin(don); return; }
      boutons.forEach(b => { b.disabled = true; });
      erreur.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Écriture sur D&D Beyond…'));
      // Fait pas à pas : un échec en route dit ce qui a déjà été donné, pour ne rien donner deux fois.
      const faits = [];
      try {
        if (mode === 'partage') {
          const { parHeros, reste } = partager(p, herosPartage.length);
          for (const id of herosPartage) { await versBeyond(id, parHeros); faits.push(nomPerso(id)); }
          if (valeurPc(reste)) { await versBeyond('groupe', reste); faits.push('le groupe'); }
        } else { await versBeyond(a, p); faits.push(a === 'groupe' ? 'le groupe' : nomPerso(a)); }
        fin(don);
      } catch (e) {
        boutons.forEach(b => { b.disabled = false; });
        const msg = /Demande inconnue/.test(e.message) ? 'L\'extension ne sait pas encore donner des pièces : rechargez-la dans chrome://extensions (version 1.20.0).' : e.message;
        erreur.replaceChildren(alerte('sang', 'lu-triangle-alert', 'Pas tout donné sur D&D Beyond', `${msg}${faits.length ? ` Déjà donné : ${faits.join(', ')} ; ne le redonnez pas.` : ''}`));
      }
    }
    const boutons = [
      bouton('Donner sur D&D Beyond', { classe: 'bn-btn--primaire', icone: 'lu-coins', titre: 'Ajouter ces pièces aux bourses sur D&D Beyond (extension du MJ), et noter le don', onclick: () => valider(true) }),
      bouton('Noter seulement', { icone: 'lu-check', titre: 'Noter le don sans rien écrire sur D&D Beyond : les joueurs ajoutent les pièces eux-mêmes', onclick: () => valider(false) }),
    ];
    const dlg = dialogue(motif || 'Or', titre, h('div', { class: 'cm-pile cm-config' },
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Pièces'),
        h('div', { class: 'cm-or__pieces' }, PIECES.map(([k, lib]) => h('label', { class: 'cm-or__piece' }, montants[k], h('span', {}, lib))))),
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'À qui'),
        h('div', { class: 'cm-quetes-statuts' }, radio('partage', 'Partagées entre les héros'), radio('heros', 'Un héros'), radio('groupe', 'Bourse du groupe'))),
      zoneHeros, apercu,
      !beyond ? h('p', { class: 'ui-s cm-sourdine' }, icone('lu-info', 'bn-icone--s'), ' Pas de relevé D&D Beyond : « Noter seulement ».') : null,
      erreur),
      h('div', { class: 'bn-groupe' }, ...boutons, bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => fin(null) })));
    if (!beyond) boutons[0].disabled = true;
    dlg.addEventListener('close', () => { if (!fini) { fini = true; resoudre(null); } });
    maj();
  });
}
