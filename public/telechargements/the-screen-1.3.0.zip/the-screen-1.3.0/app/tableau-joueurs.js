// Le tableau des joueurs : ce que l'écran des joueurs montre quand aucune carte n'est affichée (plugin
// app/plugins/ecran-joueurs.js, étude mainteneur/etudes/ecran-joueurs.md, section 9). Un fond (l'image choisie pour le
// lieu, sinon les nappes de couleur de la charte) ; en haut, la météo à gauche, le titre de la campagne au centre, le moment de la
// journée à droite (la nuit, la phase de la lune, telle que le ciel la laisse voir) ; les héros tels que les joueurs les
// voient à la table : santé en mots (jamais un chiffre), états et encombrement en icônes, équipement porté ; l'inventaire
// commun en bande. Ce qui n'y est jamais : PV, CA, niveau, passives, sorts, inspiration, argent de chacun, objets non
// équipés, lore, secrets, notes du MJ (retours du MJ, 2026-11-03 : ni niveau ni inspiration).
//
// resumeJoueurs() calcule, côté MJ, un résumé sérialisable (envoyé par le canal) ; rendreTableau() le dessine, dans la page
// joueurs et dans la projection du widget (le même code).

import { h, icone, jetsContreLaMort, marqueMort } from './ui.js';
import { ficheDe, compagnonsAvecFiches, aTerre, estMort, bourse } from './beyond.js';
import { portraitDuPersonnage } from './wiki.js';
import { etatsDe, etatDe, iconeEtat, nomEtat, encombrementDe, iconeEncombrement, ENCOMBREMENTS } from './etats.js';
import { iconeMeteo, libelleTemperature } from './calendrier.js';
import { reglage } from './campagne.js';

export const SEUILS_DEFAUT = { ensanglante: 50, critique: 25 };

export const SANTES = {
  forme: 'En forme',
  ensanglante: 'Ensanglanté',
  critique: 'Critique',
  'a-terre': 'À terre',
  mort: 'Mort',
};

// La santé en mots, d'après les PV de la fiche et les seuils (en % des PV max) : « Ensanglanté » à la moitié ou moins
// (la règle « Bloodied » de 2024), « Critique » au quart ou moins, « À terre » à 0 PV, « Mort » après trois échecs.
export function santeDe(f, seuils = SEUILS_DEFAUT) {
  if (!f?.pv || !(f.pv.max > 0)) return null;
  if (estMort(f)) return 'mort';
  if (aTerre(f) || f.pv.actuels <= 0) return 'a-terre';
  const pct = (f.pv.actuels / f.pv.max) * 100;
  if (pct <= (seuils.critique ?? SEUILS_DEFAUT.critique)) return 'critique';
  if (pct <= (seuils.ensanglante ?? SEUILS_DEFAUT.ensanglante)) return 'ensanglante';
  return 'forme';
}

const prenom = p => p.nom_court || String(p.nom).split(' ')[0];
const ICONES_EQUIPEMENT = [[/sac|backpack|pack\b|besace|bag/i, 'lu-backpack'], [/bouclier|shield/i, 'bouclier']];
function iconeEquipement(o) {
  for (const [re, ic] of ICONES_EQUIPEMENT) if (re.test(o.nom)) return ic;
  return o.type === 'arme' ? 'epee' : o.type === 'armure' ? 'bouclier' : o.magique ? 'etoile' : 'lu-box';
}

// Sous le nom, l'une sous l'autre (demande du MJ, 2026-11-03) : espèce, classe, sous-classe, origine (l'historique) ; des
// données de la campagne d'abord, de la fiche D&D Beyond à défaut.
function lignesIdentite(p, f) {
  const classes = f?.classes || [];
  return [
    p.race || f?.espece || null,
    p.classe || classes.map(c => c.nom).filter(Boolean).join(' / ') || null,
    classes.map(c => c.sous_classe).filter(Boolean).join(' / ') || null,
    p.historique || f?.historique || null,
  ].filter(Boolean);
}

// Le résumé joueurs d'un héros : rien que ce qui se voit à la table ou sur sa propre fiche.
function resumeHeros(p, f, wiki, seuils) {
  const sante = santeDe(f, seuils);
  return {
    id: p.id, nom: p.nom, prenom: prenom(p),
    lignes: lignesIdentite(p, f),
    forme: f?.forme_sauvage?.nom || null,
    portrait: f?.forme_sauvage?.avatar || portraitDuPersonnage(p, wiki, f?.avatar) || null,   // transformé : le portrait de sa forme
    sante,
    jds: sante === 'a-terre' ? { succes: f.jets_contre_la_mort?.succes || 0, echecs: f.jets_contre_la_mort?.echecs || 0, stabilise: !!f.jets_contre_la_mort?.stabilise } : null,
    etats: f ? etatsDe(f).map(e => ({ slug: e.slug, nom: nomEtat(e), court: e.court, niveau: e.niveau || null })) : [],
    encombrement: f && encombrementDe(f) ? { etat: f.encombrement.etat, nom: ENCOMBREMENTS[f.encombrement.etat].nom } : null,
    // Équipement porté : armes, armure, bouclier, conteneurs équipés (un sac à dos équipé est sur le dos), objets magiques équipés.
    equipement: f ? [
      ...(f.objets_equipes || []).map(o => ({ nom: o.nom, type: o.type || null, quantite: o.quantite || 1, magique: false })),
      ...(f.objets_magiques || []).filter(o => o.equipe).map(o => ({ nom: o.nom, type: null, quantite: o.quantite || 1, magique: true })),
    ] : [],
  };
}

// Le compagnon d'un héros (créature de sa fiche), en mots lui aussi ; ses états sont ceux du gestionnaire
// (etat/etats-creatures.json, D&D Beyond n'en pose pas sur les créatures).
function resumeCompagnon(p, cr, wiki, seuils, etatsCreatures) {
  const f = cr ? { pv: cr.pv, jets_contre_la_mort: null } : null;
  const nom = p?.nom || cr?.nom || '';
  return {
    id: p?.id || `creature:${cr?.id}`, nom, prenom: p ? prenom(p) : nom,
    identite: p?.classe || cr?.groupe || 'compagnon',
    portrait: p ? portraitDuPersonnage(p, wiki, null) : null,
    sante: f ? santeDe(f, seuils) : null,
    etats: (cr && etatsCreatures?.[cr.id] ? etatsCreatures[cr.id] : []).map(etatDe).filter(Boolean).map(e => ({ slug: e.slug, nom: nomEtat(e), court: e.court, niveau: e.niveau || null })),
    compagnon: true,
  };
}

// Le moment de la journée pour les joueurs : aube, matin, après-midi, crépuscule, nuit (le « jour » de l'horloge coupé à
// midi), avec son icône. La nuit, c'est la lune qui tient lieu d'icône.
const MOMENTS_TABLEAU = { aube: ['Aube', 'lu-sunrise'], matin: ['Matin', 'soleil'], 'apres-midi': ['Après-midi', 'lu-sun'], crepuscule: ['Crépuscule', 'lu-sunset'], nuit: ['Nuit', 'lune'] };
export function momentTableau(minute, moment) {
  const id = moment === 'jour' ? (minute < 12 * 60 ? 'matin' : 'apres-midi') : moment;
  const [nom, ic] = MOMENTS_TABLEAU[id] || MOMENTS_TABLEAU.nuit;
  return { id, nom, icone: ic };
}

// L'ambiance du tableau, côté MJ : v (etat/horloge.json) et l = lecture(v) de app/horloge.js. { moment, meteo (icône du
// ciel, texte, température ; null sans météo), lune (la nuit seulement : nom, pleine, avancement, visibilite) }. La lune se
// voit selon le ciel du créneau : « visible » (dégagé, quelques nuages), « voilee » (nuageux, ou le ciel toujours voilé du
// monde), « cachee » (couvert, nuages bas, brouillard, précipitation).
export function ambianceDe(v, l) {
  const nuit = l.moment === 'nuit';
  const c = l.meteo?.creneau || null;
  const meteo = c ? { icone: iconeMeteo(c, nuit), texte: c.texte, temperature: libelleTemperature(c.min, c.max) } : null;
  let visibilite = 'visible';
  if (c && (c.precipitation || ['couvert', 'nuages_bas', 'brouillard'].includes(c.ciel))) visibilite = 'cachee';
  else if (c?.ciel === 'nuageux' || reglage('ciel_voile', false)) visibilite = 'voilee';   // un ciel toujours voilé la laisse deviner, au mieux
  const lune = nuit && l.lune ? { nom: l.lune.nom, pleine: !!l.lune.pleine, avancement: l.lune.avancement ?? 0, visibilite } : null;
  return { moment: momentTableau(v.minute, l.moment), meteo, lune };
}

// { beyond (etat/beyond.json), personnages (personnages.json), wiki, seuils, fond (chemin ou null), titre, etatsCreatures
// (`creatures` de etat/etats-creatures.json), ambiance (ambianceDe) } → le tableau.
export function resumeJoueurs({ beyond, personnages, wiki = null, seuils = SEUILS_DEFAUT, fond = null, titre = '', etatsCreatures = null, ambiance = null }) {
  const tous = personnages?.personnages || [];
  const heros = tous.filter(p => p.role === 'personnage').map(p => {
    const f = ficheDe(p, beyond);
    const r = resumeHeros(p, f, wiki, seuils);
    const comps = compagnonsAvecFiches(tous.filter(c => c.role === 'compagnon' && c.compagnon_de === p.id), f)
      .filter(({ p: cp, creature }) => cp || creature?.actif !== false)
      .map(({ p: cp, creature }) => resumeCompagnon(cp, creature, wiki, seuils, etatsCreatures));
    return comps.length ? { ...r, compagnons: comps } : r;
  });
  const g = beyond?.groupe;
  return {
    titre, fond, ambiance,
    heros,
    groupe: g ? { argent: g.argent || null, objets: (g.objets || []).map(o => ({ nom: o.nom, quantite: o.quantite || 1 })) } : null,
    releve: beyond?.maj || null,
  };
}

// ───── Rendu ─────

function portrait(x, taille = 'l') {
  const initiale = String(x.prenom || '?').charAt(0).toUpperCase();
  return h('span', { class: `cm-portrait cm-portrait--${taille} cm-tj__portrait` },
    x.portrait ? h('img', { src: x.portrait, alt: '', onerror: e => e.target.replaceWith(document.createTextNode(initiale)) }) : initiale);
}

const svgEl = (tag, attrs = {}, ...enfants) => { const el = document.createElementNS('http://www.w3.org/2000/svg', tag); for (const [k, val] of Object.entries(attrs)) el.setAttribute(k, val); el.append(...enfants); return el; };

// La lune dessinée à sa phase : le disque sombre, et la part éclairée (avancement : 0 pleine, 0,5 nouvelle ; croissante,
// elle s'éclaire par la droite, comme dans l'hémisphère nord). Voilée : un petit nuage sur son coin ; cachée : un nuage devant.
export function dessinLune(l) {
  const r = 10, th = 2 * Math.PI * (l.avancement || 0), f = (1 + Math.cos(th)) / 2;   // part éclairée
  const droite = (l.avancement || 0) > 0.5, rx = Math.abs(r * Math.cos(th)).toFixed(2);
  let d = '';
  if (l.pleine || f > 0.97) d = `M12 2 A${r} ${r} 0 1 1 12 22 A${r} ${r} 0 1 1 12 2`;
  else if (f > 0.03) d = droite ? `M12 2 A${r} ${r} 0 0 1 12 22 A${rx} ${r} 0 0 ${f > 0.5 ? 1 : 0} 12 2` : `M12 2 A${r} ${r} 0 0 0 12 22 A${rx} ${r} 0 0 ${f > 0.5 ? 0 : 1} 12 2`;
  const svg = svgEl('svg', { class: 'cm-tj__lune', viewBox: '0 0 24 24', role: 'img', 'aria-label': l.nom },
    svgEl('circle', { class: 'cm-tj__lune-disque', cx: 12, cy: 12, r }),
    d ? svgEl('path', { class: 'cm-tj__lune-clarte', d }) : null);
  return h('span', { class: `cm-tj__astre cm-tj__astre--${l.visibilite || 'visible'}` }, svg,
    l.visibilite && l.visibilite !== 'visible' ? icone('lu-cloud', 'cm-tj__nuage') : null);
}

// Le haut du tableau : la météo à gauche, le titre au centre, le moment à droite (la lune, la nuit).
function enTete(t) {
  const a = t.ambiance;
  const textes = (classe, ...l) => h('div', { class: `cm-tj__coin-textes ${classe}`.trim() }, l.filter(Boolean).map((x, i) => h('span', { class: i ? 'cm-tj__coin-sous' : '' }, x)));
  const lune = a?.lune;
  const sousMoment = lune ? `${lune.nom}${lune.visibilite === 'cachee' ? ', cachée' : lune.visibilite === 'voilee' ? ', voilée' : ''}` : null;
  return h('header', { class: 'cm-tj__entete' },
    a?.meteo ? h('div', { class: 'cm-tj__coin' }, icone(a.meteo.icone, 'cm-tj__coin-icone'), textes('', a.meteo.texte, a.meteo.temperature)) : h('span'),
    h('p', { class: 'cm-tj__titre bn-neon' }, t.titre || ''),
    a?.moment ? h('div', { class: 'cm-tj__coin cm-tj__coin--droite' }, textes('cm-tj__coin-textes--droite', a.moment.nom, sousMoment),
      lune ? dessinLune(lune) : h('span', { class: 'cm-tj__astre' }, icone(a.moment.icone, 'cm-tj__coin-icone'))) : h('span'));
}

// Une carte de héros, cadrée pareil pour tous (demande du MJ, 2026-11-03) : à gauche le portrait, sur toute la hauteur de
// la tête, les états en icônes sur son bas (comme sur les cartes de Personnages : un seul en grand, sinon deux de front,
// quatre au plus, sans texte) ; à droite le nom, les lignes d'identité, puis la santé centrée dans l'espace qui reste ;
// puis, sur toute la largeur, l'équipement et le compagnon.
function carteHeros(x) {
  const sante = x.sante ? SANTES[x.sante] : null;
  const icones = [
    ...x.etats.map(e => iconeEtat({ slug: e.slug, court: e.court, niveau: e.niveau })),
    x.encombrement ? iconeEncombrement({ etat: x.encombrement.etat }) : null,
  ].filter(Boolean).slice(0, 4);
  const etats = icones.length ? h('span', { class: 'cm-tj__portrait-etats', 'data-nb': String(icones.length), title: [...x.etats.map(e => e.nom), x.encombrement?.nom].filter(Boolean).join(', ') }, icones) : null;
  const equipement = h('ul', { class: 'cm-tj__equipement' },
    (x.equipement || []).map(o => h('li', { class: o.magique ? 'est-magique' : '' }, icone(iconeEquipement(o), 'bn-icone--s'), h('span', {}, o.nom + (o.quantite > 1 ? ` ×${o.quantite}` : '')))));
  return h('article', { class: 'cm-tj__carte', 'data-sante': x.sante || 'inconnue' },
    h('div', { class: 'cm-tj__tete' },
      h('span', { class: 'cm-tj__portrait-cadre' }, portrait(x), etats),
      h('div', { class: 'cm-tj__droite' },
        h('div', { class: 'cm-tj__titres' },
          h('p', { class: 'cm-tj__nom' }, x.prenom),
          x.forme ? h('p', { class: 'cm-tj__ligne cm-tj__forme' }, icone('griffe', 'bn-icone--s'), ' ', x.forme)
            : (x.lignes || (x.identite ? [x.identite] : [])).map(l => h('p', { class: 'cm-tj__ligne' }, l))),
        h('div', { class: 'cm-tj__sante' },
          x.sante === 'mort' ? marqueMort({ grand: true })
            : x.sante === 'a-terre' ? [h('span', { class: 'cm-tj__sante-mot' }, sante), x.jds ? jetsContreLaMort(x.jds) : null]
              : sante ? h('span', { class: 'cm-tj__sante-mot' }, sante) : null))),
    equipement,
    x.compagnons?.length ? h('div', { class: 'cm-tj__compagnons' }, x.compagnons.map(c => h('div', { class: 'cm-tj__compagnon', 'data-sante': c.sante || 'inconnue' },
      portrait(c, 'm'), h('span', { class: 'cm-tj__compagnon-nom' }, c.prenom), c.sante ? h('span', { class: 'cm-tj__sante-mot cm-tj__sante-mot--s' }, SANTES[c.sante]) : null,
      c.etats?.length ? h('span', { class: 'cm-tj__etats cm-tj__etats--s' }, c.etats.map(e => h('span', { class: 'cm-tj__etat', title: e.nom }, iconeEtat({ slug: e.slug, court: e.court, niveau: e.niveau })))) : null))) : null);
}

// Un médaillon de héros, posé sur le bord de la carte à l'écran des joueurs (option du plugin, demande du MJ, 2026-11-11) :
// le portrait dans un rond cerclé de la couleur de sa santé (vert en forme, orange ensanglanté, rouge critique, rouge qui
// bat à terre, gris éteint mort), ses états en petites icônes sur le bas du rond (trois au plus), le prénom au-dessus ; un
// compagnon en petit rond sur son flanc. Tourné par la projection, son haut vers le bord : le prénom contre le bord, le
// portrait vers l'intérieur, lus depuis le centre de la TV. x : un héros de resumeJoueurs(). La projection (app/projection.js) le place et
// le tourne vers le joueur du bord où il est.
export function rendreMedaillon(x) {
  const icones = [
    ...(x.etats || []).map(e => iconeEtat({ slug: e.slug, court: e.court, niveau: e.niveau })),
    x.encombrement ? iconeEncombrement({ etat: x.encombrement.etat }) : null,
  ].filter(Boolean).slice(0, 3);
  const rond = (y, classe) => h('span', { class: classe, 'data-sante': y.sante || 'inconnue' }, portrait(y, 'l'),
    y.sante === 'mort' ? h('span', { class: 'cm-med__crane' }, icone('crane')) : null);
  return h('div', { class: 'cm-med', 'data-sante': x.sante || 'inconnue', 'data-id': x.id, role: 'img',
    'aria-label': [x.prenom, x.sante ? SANTES[x.sante] : null, ...(x.etats || []).map(e => e.nom), x.encombrement?.nom].filter(Boolean).join(', ') },
    h('span', { class: 'cm-med__corps' },
      rond(x, 'cm-med__rond'),
      icones.length ? h('span', { class: 'cm-med__etats', 'data-nb': String(icones.length) }, icones) : null,
      (x.compagnons || []).slice(0, 1).map(c => rond(c, 'cm-med__rond cm-med__compagnon'))),
    h('span', { class: 'cm-med__nom' }, x.prenom));
}

// Le tableau entier : le fond, l'en-tête (météo, titre, moment), les cartes des héros, la bande de l'inventaire commun.
export function rendreTableau(t, { mj = false } = {}) {
  const g = t.groupe;
  // Le fond (t.fond) est dessiné par la projection, sous le tableau, avec sa propre rotation : ici, le tableau se fait transparent.
  return h('div', { class: 'cm-tj' + (t.fond ? ' a-fond' : '') + (mj ? ' cm-tj--mj' : '') },
    enTete(t),
    h('div', { class: 'cm-tj__heros', 'data-nb': String(t.heros.length) }, t.heros.map(carteHeros)),
    g ? h('div', { class: 'cm-tj__groupe' },
      h('span', { class: 'cm-tj__groupe-titre' }, icone('lu-box', 'bn-icone--s'), 'Inventaire commun'),
      g.argent ? h('span', { class: 'cm-tj__argent' }, icone('piece', 'bn-icone--s'), bourse(g.argent)) : null,
      g.objets.length ? h('ul', { class: 'cm-tj__objets' }, g.objets.map(o => h('li', {}, o.nom + (o.quantite > 1 ? ` ×${o.quantite}` : '')))) : h('span', { class: 'cm-tj__vide' }, 'rien')) : h('span'));
}
