// Fin de session : l'état de la campagne pour l'agent IA de campagne, et le retour de son analyse.
// 1. « Avant l'analyse » : un prompt Markdown (état du gestionnaire, qui fait foi, et format de la réponse attendue).
// 2. « Après l'analyse » : le bloc JSON « maj-etat » rendu par l'agent (formats/maj-etat.md) ; chaque changement
//    est montré avant d'être appliqué à etat/ (deroule, pnj, rencontres, rencontres-mj, babioles, objets, ici, horloge,
//    et les fichiers des modules de campagne : tarokka). Historique : etat/session.json.
// Les modules de campagne (app/modules.js) ajoutent leur section au prompt, leurs clés au bloc maj-etat et les appliquent :
// emplacements sessionEtats, sessionPrompt, sessionExemple, sessionAide, sessionAppliquer.

import { h, icone, bouton, badge, alerte, onglets, bascule } from './ui.js';
import { etat, etatOuvert } from './etat.js';
import { outilsObjets } from './objets.js';
import { outilsRestes } from './restes.js';
import { chargerLieux, nomLieu } from './lieux.js';
import { RANGS, rangDe, rangFichier } from './fiche-pnj.js';
import { lireBeyond, lireDetails, ficheDe, idFeuille, originesEnMarkdown, ficheEnMarkdown, enPo, bourse } from './beyond.js';
import { jourBabiole } from './babioles.js';
import { nomExterne } from './rencontres-moteur.js';
import { DEPART, MOMENTS_LIBELLES, lecture as lectureHorloge, libelleMoment, libelleDuree, enMinutes, depuisHHMM, chargerCalendrier } from './horloge.js';
import { libelleDateComplete, nomJourMarque, libelleTemperature, meteoDeLaJournee } from './calendrier.js';
import { campagneOuverte, wikiActif } from './campagne.js';
import { contributions } from './modules.js';
import { retouchesEnMarkdown } from './lore.js';
import { fusionnerAgenda, rangAgenda } from './agenda.js';
import { resurgenceJouee, remarqueResurgence } from './trame.js';
import { outilsQuetes, quetesActives, resumeSessionQuetes } from './quetes.js';
import { reputationActive, resumeSession as resumeReputation, etatSession as etatReputation } from './reputation.js';

const ETATS_PNJ = ['vivant', 'mort', 'mort-vivant', 'disparu', 'absent'];
const LIB_RANG = { vip: 'VIP', majeur: 'majeur', mineur: 'mineur' };
const HISTORIQUE_MAX = 50;

// ───── Lecture et écriture de etat/ sans imposer de valeur par défaut aux widgets ─────

async function lireEtat(nom) {
  const ouvert = etatOuvert(nom);
  if (ouvert) return structuredClone((await ouvert).valeur);
  try {
    const r = await fetch(`etat/${nom}.json`, { cache: 'no-store' });
    return r.ok ? await r.json() : null;
  } catch { return null; }
}

async function ecrireEtat(nom, valeur) {
  const ouvert = etatOuvert(nom);
  if (ouvert) { const s = await ouvert; s.valeur = valeur; await s.sauverMaintenant(); return; }
  valeur.maj = new Date().toISOString();
  const r = await fetch(`etat/${nom}.json`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(valeur, null, 2) });
  if (!r.ok) throw new Error(`etat/${nom}.json : ${await r.text()}`);
}

// Une date seule (« 2026-10-21 », posée par un bloc maj-etat) s'affiche sans heure.
const date = iso => /T/.test(iso) ? new Date(iso).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }) : new Date(iso).toLocaleDateString('fr-FR', { dateStyle: 'medium' });
const ajouterNote = (avant, texte, session) => [avant?.trim(), `[${session || new Date().toISOString().slice(0, 10)}] ${texte.trim()}`].filter(Boolean).join('\n\n');

export async function ouvrirSession({ dialogue, donnees }) {
  const lire = async j => (await donnees(j)).donnees;
  const [deroule, pnjD, rencontresD, personnages, babiolesD, objetsD] = await Promise.all(['deroule-campagne', 'pnj', 'rencontres-aleatoires', 'personnages', 'babioles', 'objets'].map(lire));
  const lieux = await chargerLieux(donnees);
  const { cal: calD, meteo: meteoD } = await chargerCalendrier(donnees);   // date au calendrier, lune et météo de l'horloge
  const calendrierMin = (t => t.charAt(0).toLowerCase() + t.slice(1))(calD?.titre || 'Calendrier');   // « calendrier Classique »
  const nomsEtats = ['deroule', 'pnj', 'rencontres', 'rencontres-mj', 'babioles', 'objets', 'ici', 'horloge', 'session', 'lore', 'agenda', ...contributions('sessionEtats').flat()];
  const agendaD = (await donnees('agenda')).donnees?.entrees || [];   // data/agenda.json (facultatif) ; la surcouche du MJ : etats.agenda
  const charger = async () => Object.fromEntries(await Promise.all(nomsEtats.map(async n => [n, (await lireEtat(n)) || { schema: 1 }])));
  let etats = await charger();
  // Fiches D&D Beyond (relevé de l'extension), origines (relevées à la demande), noms retenus, dernier itinéraire.
  const [beyond, details, noms, trajets] = await Promise.all([lireBeyond(), lireDetails(), lireEtat('noms'), lireEtat('trajets')]);
  // Les origines sont jointes d'office si elles ont été relevées depuis le dernier envoi.
  let joindreOrigines = !!details.maj && (!etats.session?.dernier_export || details.maj > etats.session.dernier_export);
  // Portée de l'export (demande du MJ, 2026-11-01) : depuis le dernier envoi (la fin de session), ou toute la campagne (tout
  // le déroulé, avec ce qui a été ajouté après coup : remarques des rencontres) ; celui-ci ne compte pas comme un envoi.
  let complet = false;
  const restesOutils = await outilsRestes({ donnees, etat, dialogue });
  const Q = await outilsQuetes({ donnees, etat, dialogue });   // quêtes et réputation (options de campagne)

  const pnjParId = new Map((pnjD?.pnj || []).map(p => [p.id, p]));
  const etapes = [...(deroule?.etapes || [])].sort((a, b) => a.ordre - b.ordre);
  const jalons = deroule?.jalons || [];
  const pistes = deroule?.pistes || [];
  const fichesRencontres = new Map([...(rencontresD?.rencontres || []), ...(rencontresD?.rencontres_scenarisees || [])].map(r => [r.id, r]));
  const nomPnj = id => pnjParId.get(id)?.nom || id;
  const nomEtape = id => etapes.find(e => e.id === id)?.nom || id;
  const nomJalon = id => jalons.find(j => j.id === id)?.nom || id;
  const nomPiste = id => pistes.find(p => p.id === id)?.nom || id;
  const nomRencontre = id => fichesRencontres.get(id)?.nom || id;
  // Babioles (widget Babioles) : nom, sinon début du texte ; « à qui » : personnage, groupe ou non précisé.
  const babioleParId = new Map((babiolesD?.tables || []).flatMap(t => (t.lignes || []).map(l => [l.id, { l, t }])));
  const persoParId = new Map((personnages?.personnages || []).map(p => [p.id, p]));
  const nomBabiole = id => {
    const l = babioleParId.get(id)?.l;
    if (!l) return id;
    const t = l.nom?.trim() || l.texte?.trim() || id;
    return t.length > 90 ? t.slice(0, 88) + '…' : t;
  };
  const aQui = a => a === 'groupe' ? 'au groupe' : a ? `à ${persoParId.get(a)?.nom || a}` : 'sans préciser à qui';
  const distribution = x => `${aQui(x.a)}${x.note?.trim() ? ` (${x.note.trim()})` : ''}`;
  // Objets (app/objets.js) : ceux des données, et ceux créés par le MJ (etat/objets.json, `cree`). Nom du gestionnaire.
  const objetParId = new Map((objetsD?.objets || []).map(o => [o.id, o]));
  const nomObjet = id => objetParId.get(id)?.nom || etats.objets?.objets?.[id]?.nom?.trim() || id;

  // ───── 1. Le prompt pour l'agent ─────

  // Toute la campagne : le déroulé élément par élément (dates, validation du MJ, rencontres avec leur état de fin et leur
  // remarque, ce qui reste à faire).
  function deroulEnDetail(ligne, dE) {
    const suivi = dE?.suivi || {};
    const jourDe = iso => (iso ? date(iso) : '');
    const statutEl = (genre, id, fem) => {
      const x = suivi[genre]?.[id];
      if (x?.fin) return `${fem ? 'terminée' : 'terminé'} (${jourDe(x.fin)})${x.valide ? ', validé par le MJ' : ''}`;
      return x?.debut ? `en cours (depuis ${jourDe(x.debut)})` : 'à venir';
    };
    const rencontresEtat = etats['rencontres-mj']?.rencontres || [];
    const ligneRencontre = (e, nom) => {
      const b = e?.bilan?.monstres?.length ? ` · fin du combat${e.bilan.round ? ` au round ${e.bilan.round}` : ''} : ${e.bilan.monstres.map(m => `${m.nom} ${m.mort ? 'mort' : `vivant (${m.pv}/${m.pv_max} PV)`}`).join(', ')}` : '';
      return `${nom} : ${e?.statut === 'terminee' ? 'terminée' : e?.statut === 'en-cours' ? 'en cours' : 'pas jouée'}${b}${e?.remarque ? ` · remarque du MJ : ${e.remarque.replace(/\n+/g, ' ')}` : ''}`;
    };
    const rencontresDe = cle => id => rencontresEtat.filter(e => e.rattachement?.[cle] === id);
    const creeesDuJalon = rencontresDe('jalon'), creeesDeLEtape = rencontresDe('etape');
    const reste = quoi => { const r = restesOutils.restes(quoi); return restesOutils.aRegler(r) ? restesOutils.resume(r) : ''; };
    const remarque = (genre, id) => dE?.remarques?.[genre]?.[id]?.texte?.replace(/\n+/g, ' ');
    ligne('### Déroulé, élément par élément');
    ligne('Toute la trame telle que je la tiens : chaque étape, ses jalons, leurs rencontres avec leur état de fin et **mes remarques, ajoutées parfois après coup**. « Reste » : ce qui n\'est pas fait (rencontres pas jouées, PNJ pas rencontrés, objets pas donnés).');
    for (const e of etapes) {
      const x = suivi.etapes?.[e.id];
      const js = jalons.filter(j => j.etape === e.id).sort((a, b) => a.rang - b.rang);
      ligne('');
      ligne(`#### Étape ${e.ordre} : ${e.nom} (\`${e.id}\`) : ${statutEl('etapes', e.id, true)}`);
      if (x?.fin) { const r = reste({ etape: e.id }); if (r) ligne(`- Reste : ${r}.`); }
      if (remarque('etapes', e.id)) ligne(`- Remarque du MJ : ${remarque('etapes', e.id)}`);
      creeesDeLEtape(e.id).forEach(c => ligne(`- Rencontre : ${ligneRencontre(c, c.nom || 'Rencontre sans nom')}`));
      for (const j of js) {
        ligne(`- Jalon **${j.nom}** (\`${j.id}\`${j.facultatif ? ', facultatif' : ''}) : ${statutEl('jalons', j.id)}`);
        if (suivi.jalons?.[j.id]?.fin) { const r = reste({ jalon: j.id }); if (r) ligne(`  - Reste : ${r}.`); }
        if (remarque('jalons', j.id)) ligne(`  - Remarque du MJ : ${remarque('jalons', j.id)}`);
        (j.rencontres || []).forEach(id => { const c = rencontresEtat.find(y => y.id === id); if (c || suivi.jalons?.[j.id]?.fin) ligne(`  - Rencontre : ${ligneRencontre(c, nomRencontre(id))}`); });
        creeesDuJalon(j.id).forEach(c => ligne(`  - Rencontre : ${ligneRencontre(c, c.nom || 'Rencontre sans nom')}`));
      }
    }
    const pistesVues = pistes.filter(p => suivi.pistes?.[p.id] || remarque('pistes', p.id) || dE?.remarques?.resurgences?.[p.id]);
    if (pistesVues.length) {
      ligne('');
      ligne('#### Pistes commencées ou terminées');
      pistesVues.forEach(p => { ligne(`- **${p.nom}** (\`${p.id}\`${p.personnage ? `, quête de ${nomPerso(p.personnage)}` : ''}) : ${statutEl('pistes', p.id, true)}${remarque('pistes', p.id) ? ` · remarque du MJ : ${remarque('pistes', p.id)}` : ''}`);
        // Ses résurgences jouées (cochées par le MJ, 2026-11-05), et combien il en reste.
        const ms = p.manifestations || [], faites = ms.filter(m => resurgenceJouee(dE || {}, p.id, m));
        if (faites.length) ligne(`  - Résurgences jouées (${faites.length} sur ${ms.length}) : ${faites.map(m => `« ${m.texte.replace(/\n+/g, ' ')} »`).join(' ; ')}`);
        // Mes remarques sur son début et sa fin (comment elle s'est vraiment ouverte, conclue).
        for (const [quel, lib] of [['debut', 'le début'], ['fin', 'la fin']]) { const r = dE?.remarques?.resurgences?.[p.id]?.[quel]; if (r) ligne(`  - Remarque du MJ sur ${lib} de la piste : ${r.texte.replace(/\n+/g, ' ')}`); }
        // Mes remarques sur ses résurgences, jouées ou non (ce qui s'est passé, pourquoi je l'ai sautée).
        ms.forEach(m => { const r = remarqueResurgence(dE || {}, p.id, m); if (r) ligne(`  - Remarque du MJ sur la résurgence « ${m.texte.replace(/\n+/g, ' ')} » (${resurgenceJouee(dE || {}, p.id, m) ? 'jouée' : 'pas jouée'}) : ${r.texte.replace(/\n+/g, ' ')}`); });
      });
    }
    // Un rattachement périmé (jalon ou étape disparus) ne range plus la rencontre : elle reste ici, pour ne pas la perdre.
    const ailleurs = rencontresEtat.filter(c => c.statut && !jalons.some(j => j.id === c.rattachement?.jalon) && !etapes.some(e => e.id === c.rattachement?.etape) && !jalons.some(j => (j.rencontres || []).includes(c.id)));
    if (ailleurs.length) {
      ligne('');
      ligne('#### Autres rencontres jouées (tirages, lieux, routes)');
      ailleurs.forEach(c => ligne(`- ${ligneRencontre(c, c.origine === 'prevue' ? nomRencontre(c.id) : c.nom || 'Rencontre sans nom')}`));
    }
    ligne('');
  }
  const nomPerso = id => persoParId.get(id)?.nom || id;

  function prompt() {
    const l = [];
    const ligne = (...t) => l.push(t.join(''));
    const maintenant = new Date();
    const dE = etats.deroule, dP = etats.pnj?.pnj || {}, dR = etats.rencontres;
    ligne(complet ? '# État de la campagne, depuis le début' : '# État de la campagne, pour l\'analyse de fin de session');
    ligne('');
    ligne(`Écrit par le gestionnaire de campagne le ${date(maintenant.toISOString())}. **Le gestionnaire fait foi** pour l'avancée de la campagne : ce qui suit est ce que j'ai noté pendant les séances. Les \`id\` sont ceux des fichiers de \`data/\`.`);
    if (complet) { ligne(''); ligne('**Export complet** : tout ce que je tiens depuis le début de la campagne, pas seulement la dernière séance. Reprends-le pour vérifier et compléter ce que tu sais, en particulier mes remarques sur les rencontres.'); }
    ligne('');
    ligne('## Ce que je te demande');
    ligne('');
    ligne(complet ? `1. Compare cet état à ce que tu sais de la campagne (${wikiActif() ? 'wiki, ' : ''}journal des joueurs, notes) et signale les écarts.` : `1. Analyse les retours de la séance (${wikiActif() ? 'wiki, ' : ''}journal des joueurs, notes) **en partant de cet état**.`);
    ligne('2. Si quelque chose est incertain (un PNJ mort ou seulement blessé, une étape franchie ou non, un objet trouvé ou seulement vu), **pose-moi la question** au lieu de deviner.');
    ligne(`3. Ce message est l'état de la campagne tel que je le tiens dans le gestionnaire : sers-t'en pour mettre à jour ce que tu sais de la campagne (ta mémoire, tes fiches, les PNJ…), à toi de voir comment ; le \`groupe\` de \`personnages.json\` suivra au prochain export (voir les écarts plus bas). Dans un compte rendu de séance, situe les faits par jour de jeu, avec la date du calendrier et le temps qu'il faisait (« Jours de jeu », section « Lieu et temps »).`);
    ligne(`4. Mets à jour les fiches des personnages joueurs d\'après le relevé D&D Beyond (section « Personnages ») : niveau, objets magiques, compagnons, liens de feuille et historique manquants. Les feuilles D&D Beyond font foi pour la mécanique ; ${wikiActif() ? 'le wiki et ' : ''}mes décisions (dont mes retouches du lore, plus bas), pour l\'histoire.`);
    ligne(`5. ${joindreOrigines ? 'Les origines des personnages (historique, espèce, dons, textes de leurs fiches) sont jointes en fin de message : sers-t\'en pour enrichir leur lore, et **propose** des pistes de campagne qui s\'y rattachent, sans les ajouter aux pistes validées tant que je ne les ai pas acceptées.' : 'Les origines des personnages ne sont pas jointes cette fois : elles n\'ont pas changé depuis le dernier envoi.'}`);
    ligne('6. Termine ta réponse par **un seul bloc ```json** au format `maj-etat` décrit en bas, avec **seulement ce que la séance a changé**. Je le collerai dans le gestionnaire, qui me montrera chaque changement avant de l\'appliquer.');
    ligne('');
    ligne('## État actuel');
    ligne('');
    ligne('### Déroulé');
    // Les étapes sont indicatives : plusieurs peuvent être en cours. L'étape de référence est la dernière démarrée.
    const e = etapes.find(x => x.id === dE?.etape);
    const suivi = dE?.suivi || {};
    // Sans déroulé lisible, le suivi seul : ses id, sans nom.
    const elements = (liste, genre) => (deroule ? liste : Object.keys(suivi[genre] || {}).map(id => ({ id, nom: id })));
    const enCours = (liste, genre) => elements(liste, genre).filter(x => suivi[genre]?.[x.id]?.debut && !suivi[genre]?.[x.id]?.fin);
    const termines = (liste, genre) => elements(liste, genre).filter(x => suivi[genre]?.[x.id]?.fin);
    if (!deroule) ligne('- Le déroulé (`deroule-campagne.json`) n\'est pas lisible par le gestionnaire (absent, ou pas encore au format 2) : le suivi ci-dessous ne donne que des `id`.');
    ligne(e ? `- Étape de référence (la dernière démarrée) : **${e.nom}** (\`${e.id}\`), étape ${e.ordre} sur ${etapes.length} dans l'ordre conseillé, niveau du groupe ${e.niveau_groupe}.` : dE?.etape ? `- Étape de référence : \`${dE.etape}\`.` : '- Aucune étape de référence notée.');
    const etapesEnCours = enCours(etapes, 'etapes');
    ligne(`- Étapes en cours : ${etapesEnCours.map(x => `**${x.nom}** (\`${x.id}\`)`).join(', ') || 'aucune'}.`);
    const jalonsEnCours = enCours(jalons, 'jalons');
    ligne(jalonsEnCours.length ? `- Jalons en cours : ${jalonsEnCours.map(x => `**${x.nom}** (\`${x.id}\`${x.type ? `, ${deroule?.types_jalons?.[x.type] || x.type}` : ''})`).join(', ')}.` : '- Pas de jalon en cours.');
    const pistesCommencees = enCours(pistes, 'pistes');
    ligne(`- Pistes commencées (fils à faire reparaître) : ${pistesCommencees.map(x => `**${x.nom}** (\`${x.id}\`)`).join(', ') || 'aucune'}.`);
    ligne(`- Étapes terminées : ${termines(etapes, 'etapes').map(x => `\`${x.id}\``).join(', ') || 'aucune notée'}.`);
    ligne(`- Jalons terminés : ${termines(jalons, 'jalons').map(x => `${x.nom} (\`${x.id}\`)`).join(', ') || 'aucun noté'}.`);
    ligne(`- Pistes terminées : ${termines(pistes, 'pistes').map(x => `${x.nom} (\`${x.id}\`)`).join(', ') || 'aucune notée'}.`);
    ligne('');
    if (complet && deroule) deroulEnDetail(ligne, dE);
    // Remarques du MJ sur les étapes, jalons et pistes, écrites ou modifiées depuis le dernier envoi (export complet : dans le détail).
    if (!complet) {
      const noms = { etapes: nomEtape, jalons: nomJalon, pistes: nomPiste };
      const envoi = etats.session?.dernier_export;
      // Les remarques des résurgences sont rangées par piste, puis par résurgence (`de` : le début de son texte).
      const notes = Object.entries(dE?.remarques || {}).flatMap(([genre, m]) => (genre === 'resurgences'
        ? Object.entries(m || {}).flatMap(([id, parCle]) => Object.values(parCle || {}).map(r => ({ genre, id, r })))
        : Object.entries(m || {}).map(([id, r]) => ({ genre, id, r })))).filter(x => !envoi || (x.r.maj || '') > envoi);
      if (notes.length) {
        ligne(`### Remarques du MJ sur le déroulé${envoi ? ' depuis le dernier envoi' : ''}`);
        notes.forEach(({ genre, id, r }) => ligne(genre === 'resurgences'
          ? `- Résurgence de la piste ${nomPiste(id) || id} (\`${id}\`), « ${r.de || ''}… » : ${r.texte.replace(/\n+/g, ' ')}`
          : `- ${noms[genre]?.(id) || id} (\`${id}\`) : ${r.texte.replace(/\n+/g, ' ')}`));
        ligne('');
      }
    }
    // Lieu (widget Ici, « Arriver » de Trajets) et temps de jeu (widget Horloge).
    ligne('### Lieu et temps');
    const dI = etats.ici, dH = etats.horloge, dernierEnvoi = complet ? null : etats.session?.dernier_export;
    if (dI?.lieu) ligne(`- Les héros sont à **${nomLieu(lieux, dI.lieu)}** (\`${dI.lieu}\`)${dI.sous_lieu ? `, ${nomLieu(lieux, dI.sous_lieu)} (\`${dI.sous_lieu}\`)` : ''}.`);
    else ligne('- Lieu actuel : pas noté dans le gestionnaire.');
    const arrivees = (dI?.visites || []).filter(x => x.quand && (!dernierEnvoi || x.quand > dernierEnvoi));
    if (arrivees.length) ligne(`- Arrivées notées${dernierEnvoi ? ' depuis le dernier envoi' : ''}, dans l'ordre : ${arrivees.map(x => `${nomLieu(lieux, x.lieu)} (\`${x.lieu}\`${x.jour ? `, ${libelleMoment(x)}` : ''})`).join(' ; ')}.`);
    const notesLieux = Object.entries(dI?.notes || {}).filter(([, t]) => t?.trim());
    if (notesLieux.length) { ligne('- Notes du MJ sur les lieux :'); notesLieux.forEach(([id, t]) => ligne(`  - **${nomLieu(lieux, id)}** (\`${id}\`) : ${t.trim().replace(/\n+/g, ' ')}`)); }
    if (dH?.maj) {
      const lu = lectureHorloge({ ...DEPART, ...dH });
      // La date au calendrier (data/calendrier.json) et la météo du jour (data/meteo.json) à côté du jour de campagne.
      const marque = lu.marques.find(x => x.dans === 0);
      ligne(`- Horloge : **${libelleMoment({ ...DEPART, ...dH })}**${lu.date ? `, ${libelleDateComplete(lu.date)} du ${calendrierMin}` : ''} (${MOMENTS_LIBELLES[lu.moment]})${marque ? `, jour marqué : ${nomJourMarque(marque)}` : ''}${lu.lune ? ` ; ${lu.lune.nom.toLowerCase()}` : ''}${dH.repos_long ? ` ; dernier repos long terminé ${libelleMoment(dH.repos_long)}` : ''}.`);
      if (lu.meteo) {
        const c = lu.meteo.creneau;
        ligne(`- Météo du jour ${dH.jour ?? DEPART.jour} : ${lu.meteo.jour.resume} En ce moment (${lu.meteo.nom.toLowerCase()}) : ${c.texte}, ${libelleTemperature(c.min, c.max)}.`);
      }
      for (const a of dH.activites || []) {
        ligne(`- En cours à la fin de la séance : **${a.titre}**, ${libelleDuree(a.fait)} sur ${libelleDuree(a.total)}${a.type === 'voyage' ? ` (itinéraire : ${a.itineraire.map(id => nomLieu(lieux, id)).join(' → ')})` : ''}.`);
      }
      const ecoules = (dH.journal || []).filter(e => !dernierEnvoi || e.quand > dernierEnvoi);
      if (ecoules.length) {
        const total = ecoules.reduce((a, e) => a + enMinutes(e.apres) - enMinutes(e.avant), 0);
        ligne(`- Temps de jeu écoulé${dernierEnvoi ? ' depuis le dernier envoi' : ''} : ${libelleDuree(total)} (${libelleMoment(ecoules[0].avant)} → ${libelleMoment(ecoules.at(-1).apres)}) :`);
        (complet ? ecoules : ecoules.slice(-20)).forEach(e => ligne(`  - ${e.motif} : ${libelleMoment(e.avant)} → ${libelleMoment(e.apres)}`));
      }
      // Chaque jour de jeu de la séance avec sa date et sa météo, créneau par créneau (demande du MJ, 2026-10-22 : situer le
      // compte rendu dans le temps). Les jours depuis le dernier envoi, dix au plus.
      const fin = dH.jour ?? DEPART.jour;
      const debut = complet ? 1 : Math.max(fin - 9, Math.min(fin, ...ecoules.map(e => e.avant.jour)));
      const jours = [];
      // L'agenda (data/agenda.json et les retouches du MJ, 2026-10-25) : ses entrées de chaque jour, et des deux semaines à venir.
      const agendaTout = calD ? fusionnerAgenda(agendaD, etats.agenda) : [];
      const agendaDu = n => { const r = lectureHorloge({ ...DEPART, ...dH, jour: n, minute: 720 }).date?.rang; return r == null ? [] : agendaTout.filter(e => rangAgenda(calD, e) === r); };
      const texteAgenda = e => `« ${e.nom} »${e.secret ? ' (secret)' : ''}${e.details ? ` : ${e.details}` : ''}`;
      for (let n = debut; n <= fin; n++) {
        const d = lectureHorloge({ ...DEPART, ...dH, jour: n, minute: 720 });
        const m = meteoD && meteoDeLaJournee(meteoD, n);
        const marqueJ = d.marques?.find(x => x.dans === 0);
        const ag = agendaDu(n);
        jours.push(`  - Jour ${n}${d.date ? `, ${libelleDateComplete(d.date)}` : ''}${marqueJ ? ` (jour marqué : ${nomJourMarque(marqueJ)})` : ''} : ${m ? m.texte : 'pas de météo dans les données'}.${ag.length ? ` Agenda : ${ag.map(texteAgenda).join(' ; ')}.` : ''}`);
      }
      ligne(`- Jours de jeu${dernierEnvoi ? ' depuis le dernier envoi' : ''}, avec leur météo (pour situer les faits du compte rendu dans le temps) :`);
      jours.forEach(x => ligne(x));
      const aVenir = [];
      for (let n = fin + 1; n <= fin + 14; n++) agendaDu(n).forEach(e => aVenir.push(`  - Jour ${n} (dans ${n - fin} j) : ${texteAgenda(e)}`));
      if (aVenir.length) { ligne('- Agenda des deux semaines à venir :'); aVenir.forEach(x => ligne(x)); }
    } else ligne('- Horloge : pas encore utilisée.');
    ligne('');
    ligne('### PNJ');
    const suivis = Object.entries(dP).filter(([id]) => pnjParId.has(id));
    const vus = suivis.filter(([, s]) => s.rencontre).map(([id]) => `${nomPnj(id)} (\`${id}\`)`);
    ligne(`- Rencontrés (${vus.length}) : ${vus.join(', ') || 'aucun noté'}.`);
    const etatsChanges = suivis.filter(([, s]) => s.etat).map(([id, s]) => `${nomPnj(id)} (\`${id}\`) : ${s.etat}${pnjParId.get(id).etat && pnjParId.get(id).etat !== s.etat ? ` (fichier : ${pnjParId.get(id).etat})` : ''}`);
    ligne(`- États notés en jeu : ${etatsChanges.join(' ; ') || 'aucun'}.`);
    const rangs = suivis.filter(([id, s]) => rangDe(pnjParId.get(id), s) !== rangFichier(pnjParId.get(id))).map(([id, s]) => `${nomPnj(id)} (\`${id}\`) : ${LIB_RANG[rangDe(pnjParId.get(id), s)]} (fichier : ${LIB_RANG[rangFichier(pnjParId.get(id))]})`);
    ligne(`- Rangs changés en jeu : ${rangs.join(' ; ') || 'aucun'}.`);
    const notes = suivis.filter(([, s]) => s.note?.trim());
    if (notes.length) { ligne('- Notes du MJ :'); notes.forEach(([id, s]) => ligne(`  - **${nomPnj(id)}** (\`${id}\`) : ${s.note.trim().replace(/\n+/g, ' ')}`)); }
    else ligne('- Notes du MJ : aucune.');
    ligne('');
    if (quetesActives() || reputationActive()) {
      // Quêtes et réputation (2026-11-11) : ce qui a changé depuis le dernier envoi (tout, pour l'export complet), et où on en est.
      const depuisEnvoi = complet ? null : etats.session?.dernier_export || null;
      ligne('### Quêtes et réputation');
      if (quetesActives()) {
        const rq = resumeSessionQuetes(Q, depuisEnvoi);
        ligne(`- Quêtes ${complet ? '' : 'depuis le dernier envoi '}: ${rq.faites.length ? '' : 'rien de noté.'}`);
        rq.faites.forEach(t => ligne(`  - ${t}`));
        ligne(`- Quêtes en cours : ${rq.enCours.join(' ; ') || 'aucune'}.`);
      }
      if (reputationActive()) {
        const ch = resumeReputation(depuisEnvoi, id => Q.nomFaction(id));
        ligne(`- Réputation ${complet ? '' : 'depuis le dernier envoi '}: ${ch.length ? '' : 'pas de changement.'}`);
        ch.forEach(t => ligne(`  - ${t}`));
        ligne(`- Réputation actuelle : ${etatReputation(Q.factions).join(' ; ') || 'aucune faction suivie'}.`);
      }
      ligne('');
    }
    contributions('sessionPrompt', { etats, ligne, date });   // sections des modules de campagne (le Tarokka)
    ligne('### Rencontres');
    const retirees = dR?.retirees || [];
    const unique = id => fichesRencontres.get(id)?.unique;
    const rencontrees = dR?.rencontrees || retirees.filter(unique);   // avant rencontrees[] : les uniques de retirees[]
    const listeRencontres = ids => ids.map(id => `${nomRencontre(id)} (\`${id}\`)`).join(', ');
    ligne(`- Rencontres uniques déjà rencontrées (cachées des tables) : ${listeRencontres(rencontrees) || 'aucune'}.`);
    ligne(`- Autres rencontres cachées des tables : ${listeRencontres(retirees.filter(id => !rencontrees.includes(id))) || 'aucune'}.`);
    const ouverts = (dR?.suivis || []).filter(s => !s.resolu);
    ligne(`- Suites à jouer : ${ouverts.length ? '' : 'aucune.'}`);
    ouverts.forEach(s => ligne(`  - \`${s.id}\` · ${nomRencontre(s.rencontre)} : ${s.texte}`));
    const depuis = complet ? null : etats.session?.dernier_export;
    // Celles qui ont eu lieu : pas une rencontre d'un test restée proposée, ni écartée (2026-10-25).
    const sorties = (dR?.journal || []).filter(x => x.rencontre && !x.sans_effet && !x.proposee && !x.ecartee && (!depuis || x.quand > depuis));
    // Une entrée peut passer par des sous-tables (tirages[] : table principale, puis chaque sous-table) et faire tirer un
    // objet dans un autre fichier (tirage_externe : une babiole) ; les entrées plus anciennes n'ont que « tirage ».
    const nomTable = id => (rencontresD?.tables || []).find(t => t.id === id)?.nom || id;
    const via = x => (x.tirages || []).slice(1).map(t => nomTable(t.table));
    const objet = x => x.tirage_externe?.id ? `, objet trouvé : ${nomExterne(x.tirage_externe)} (\`${x.tirage_externe.id}\`, ${x.tirage_externe.jeu}.json)` : '';
    ligne(`- Rencontres tirées${depuis ? ` depuis le dernier envoi (${date(depuis)})` : ''} : ${sorties.length ? '' : 'aucune.'}`);
    (complet ? sorties : sorties.slice(-30)).forEach(x => ligne(`  - ${date(x.quand)}${x.horloge ? ` (en jeu : ${libelleMoment(x.horloge)})` : ''} · ${nomRencontre(x.rencontre)} (\`${x.rencontre}\`${via(x).length ? `, sous-table ${via(x).join(' puis ')}` : ''})${(x.quantites || []).length ? ` (${x.quantites.map(q => `${q.total ?? q.formule} ${q.nom}`).join(', ')})` : ''}${objet(x)}${x.note?.trim() ? ` : ${x.note.trim()}` : ''}`));
    // Rencontres menées dans le widget Combat ou notées terminées (jouées dans Maps, sans combat…) : etat/rencontres-mj.json.
    // Une remarque modifiée depuis (`remarque_maj`) : la rencontre revient, même jouée avant le dernier envoi.
    const remarqueRevue = e => depuis && (e.remarque_maj || '') > depuis && (e.fin?.quand || e.debut?.quand || '') <= depuis;
    const jouees = (etats['rencontres-mj']?.rencontres || []).filter(e => (e.statut === 'terminee' || e.statut === 'en-cours') && (!depuis || (e.fin?.quand || e.debut?.quand || '') > depuis || remarqueRevue(e)));
    const origineRmj = e => (e.origine === 'prevue' ? `\`${e.id}\`` : e.origine === 'aleatoire' ? 'tirée au hasard' : e.origine === 'maison' ? `les occupants d'une maison, ${e.maison?.resultat || ''}`.replace(/, $/, '') : 'créée par le MJ');
    const quandRmj = q => (q?.horloge ? ` (en jeu : ${libelleMoment(q.horloge)})` : q?.quand ? ` (${date(q.quand)})` : '');
    ligne(`- Rencontres jouées${depuis ? ' depuis le dernier envoi' : ''} (menées dans le gestionnaire ou notées terminées) : ${jouees.length ? '' : 'aucune.'}`);
    // Fin d'un combat mené dans le widget Combat (`bilan`, 2026-10-23) : chaque monstre mort ou ses PV, les héros tombés.
    const bilanRmj = b => {
      if (!b?.monstres?.length) return '';
      const monstres = b.monstres.map(m => `${m.nom} ${m.mort ? 'mort' : `vivant (${m.pv}/${m.pv_max} PV${m.etats?.length ? `, ${m.etats.join(', ')}` : ''})`}`);
      const tombes = (b.heros || []).filter(x => x.mort || x.a_terre).map(x => `${x.nom} ${x.mort ? 'mort' : 'à terre'}`);
      return ` · fin du combat${b.round ? ` au round ${b.round}` : ''} : ${monstres.join(', ')}${tombes.length ? ` ; ${tombes.join(', ')}` : ''}`;
    };
    jouees.forEach(e => ligne(`  - ${e.origine === 'prevue' ? nomRencontre(e.id) : e.nom || 'Rencontre sans nom'} (${origineRmj(e)}) · ${e.statut === 'terminee' ? 'terminée' : 'en cours'}${quandRmj(e.fin || e.debut)}${(e.groupes || []).length ? ` · ${e.groupes.map(g => `${g.quantite} ${g.nom}${g.nom !== g.nom_beyond ? ` (${g.nom_beyond})` : ''}`).join(', ')}` : ''}${bilanRmj(e.bilan)}${e.remarque ? ` : ${e.remarque}` : ''}${remarqueRevue(e) ? ' (déjà envoyée : remarque modifiée depuis)' : ''}`));
    // Une remarque du MJ sur une rencontre pas jouée (une trouvaille, une scène sans combat, des notes prises d'avance :
    // demande du 2026-11-05) : depuis le dernier envoi, ou toutes pour l'export complet.
    const annotees = (etats['rencontres-mj']?.rencontres || []).filter(e => e.remarque && e.statut !== 'terminee' && e.statut !== 'en-cours' && (!depuis || (e.remarque_maj || '') > depuis));
    if (annotees.length) {
      ligne(`- Remarques du MJ sur des rencontres pas jouées${depuis ? ' (depuis le dernier envoi)' : ''} :`);
      annotees.forEach(e => ligne(`  - ${e.origine === 'prevue' ? nomRencontre(e.id) : e.nom || 'Rencontre sans nom'} (${origineRmj(e)}) : ${e.remarque.replace(/\n+/g, ' ')}`));
    }
    ligne('');
    // Personnages : relevé D&D Beyond (extension du gestionnaire, toutes les 30 s pendant les séances).
    const pjs = (personnages?.personnages || []).filter(p => p.role === 'personnage');
    const fichesPj = pjs.map(p => [p, ficheDe(p, beyond)]);
    ligne('### Personnages (fiches D&D Beyond)');
    if (beyond.maj) {
      ligne(`Relevé automatique du ${date(beyond.maj)}, par l'extension du gestionnaire. Valeurs au moment du relevé (PV et ressources peuvent avoir bougé depuis la fin de séance).`);
      ligne('');
      for (const [p, f] of fichesPj) {
        if (!f) { ligne(`- **${p.nom}** (\`${p.id}\`) : pas de fiche D&D Beyond relevée.`); continue; }
        const [premiere, ...suite] = ficheEnMarkdown(f);
        ligne(`- **${p.nom}** (\`${p.id}\`, fiche D&D Beyond ${f.url}${f.joueur ? `, joueur ${f.joueur}` : ''}) : ${premiere}.`);
        suite.forEach(x => ligne(`  - ${x}.`));
      }
      // Inventaire commun de la campagne D&D Beyond (party inventory) : son argent compte dans la bourse du groupe.
      const commun = beyond.groupe;
      if (commun) ligne(`- Inventaire commun du groupe : argent ${bourse(commun.argent)} ; objets : ${(commun.objets || []).map(o => `${o.nom}${o.quantite > 1 ? ` ×${o.quantite}` : ''}`).join(', ') || 'aucun'}.`);
      const avecFiche = fichesPj.filter(([, f]) => f);
      if (avecFiche.length) ligne(`- Bourse du groupe : ${(avecFiche.reduce((s, [, f]) => s + enPo(f.argent), 0) + enPo(commun?.argent)).toLocaleString('fr-FR', { maximumFractionDigits: 2 })} po en tout${commun ? ', inventaire commun compris' : ''}.`);
    } else ligne('- Pas de relevé D&D Beyond (extension non installée ou gestionnaire arrêté pendant les séances).');
    ligne(details.maj ? `- Origines (historique, espèce, dons) relevées le ${date(details.maj)}${joindreOrigines ? ' : jointes en fin de message.' : ', déjà envoyées : non jointes.'}` : '- Origines : pas encore relevées.');
    ligne('');
    // Noms improvisés à la table (widget Noms) : retenus depuis le dernier envoi.
    const depuisExport = complet ? null : etats.session?.dernier_export;
    const retenus = (noms?.historique || []).filter(n => n.retenu && (!depuisExport || n.quand > depuisExport));
    if (retenus.length) {
      ligne('### Noms retenus en séance');
      ligne('Noms tirés au widget Noms et gardés pour un PNJ improvisé. S\'il a compté, ajoute-le à tes fiches (et à `pnj.json` au prochain export).');
      retenus.forEach(n => ligne(`- ${n.prenom} ${n.famille}${n.note?.trim() ? ` : ${n.note.trim().replace(/\n+/g, ' ')}` : ''}`));
      ligne('');
    }
    // Babioles données aux personnages (widget Babioles) depuis le dernier envoi.
    const babioles = Object.entries(etats.babioles?.distribuees || {}).filter(([, x]) => !depuisExport || (x.quand || '') > depuisExport)
      .sort(([, a], [, b]) => String(a.quand).localeCompare(String(b.quand)));
    if (babioles.length) {
      ligne(`### Babioles distribuées${depuisExport ? ' depuis le dernier envoi' : ''}`);
      ligne('Petits objets tirés au widget Babioles et donnés aux personnages. S\'ils comptent pour la suite, reporte-les dans les fiches des personnages.');
      babioles.forEach(([id, x]) => ligne(`- ${jourBabiole(x.quand)} · **${nomBabiole(id)}** (\`${id}\`${babioleParId.has(id) ? `, ${babioleParId.get(id).t.nom}` : ', absente de babioles.json'}) : ${distribution(x).replace(/\n+/g, ' ')}`));
      ligne('');
    }
    // Objets donnés (app/objets.js : widget Objets, Ici, Déroulé, rencontres) depuis le dernier envoi.
    const dons = Object.entries(etats.objets?.objets || {}).flatMap(([id, e]) => (e.dons || []).map(x => ({ id, e, x })))
      .filter(({ x }) => !depuisExport || (x.quand || '') > depuisExport).sort((a, b) => String(a.x.quand).localeCompare(String(b.x.quand)));
    if (dons.length) {
      ligne(`### Objets donnés${depuisExport ? ' depuis le dernier envoi' : ''}`);
      ligne('Objets trouvés ou reçus, donnés dans le gestionnaire. Un objet créé par le MJ (`mj-…`) n\'est pas dans `objets.json` : s\'il compte, ajoute-le à tes fiches. Un objet à `nom_joueurs` est d\'abord donné en objet personnalisé sous ce nom, puis « identifié » : l\'objet de D&D Beyond le rejoint.');
      dons.forEach(({ id, e, x }) => {
        const nom = nomObjet(id);
        // Le nom écrit sur D&D Beyond, celui que voient les joueurs, quand il diffère du nom du gestionnaire.
        const ecrit = x.beyond?.catalogue ? x.beyond.nom || e.beyond?.nom : x.beyond ? e.nom?.trim() || objetParId.get(id)?.nom_joueurs || nom : null;
        const beyond = x.beyond ? `, sur D&D Beyond ${x.beyond.catalogue ? 'depuis le catalogue' : 'en objet personnalisé'}${ecrit && ecrit !== nom ? ` sous le nom « ${ecrit} »` : ''}` : ', noté seulement (pas ajouté sur D&D Beyond par le gestionnaire)';
        ligne(`- ${x.horloge ? libelleMoment(x.horloge) : date(x.quand)} · **${nom}** (\`${id}\`)${x.quantite > 1 ? ` ×${x.quantite}` : ''} : ${x.identification ? 'identifié, ' : ''}${aQui(x.a)}${beyond}${e.commentaire ? ` (${e.commentaire.replace(/\n+/g, ' ')})` : ''}`);
      });
      ligne('');
    }
    if (trajets?.itineraire?.length > 1) {
      ligne('### Dernier itinéraire préparé (widget Trajets)');
      ligne(`- ${trajets.itineraire.map(id => nomLieu(lieux, id)).join(' → ')}${trajets.maj ? ` (le ${date(trajets.maj)})` : ''}. ${trajets.arrive
        ? `**Parcouru** : j'ai fait arriver les héros (${date(trajets.arrive.quand)}${trajets.arrive.jour ? `, en jeu : ${libelleMoment(trajets.arrive)}` : ''}) ; les lieux traversés sont dans les arrivées plus haut.`
        : 'Calcul de temps de trajet, **pas forcément parcouru** : à confirmer avec le récit de séance avant d\'en tirer des lieux visités.'}`);
      ligne('');
    }
    const g = personnages?.groupe;
    if (g) {
      const ecarts = [];
      for (const [p, f] of fichesPj) {
        if (!f) continue;
        if (!idFeuille(p.liens?.feuille)) ecarts.push(`${p.nom} (\`${p.id}\`) : \`liens.feuille\` absent ; sa fiche D&D Beyond est ${f.url}`);
        if (!p.historique && f.historique) ecarts.push(`${p.nom} (\`${p.id}\`) : \`historique\` absent ; sur sa fiche D&D Beyond : ${f.historique}`);
      }
      const niveaux = fichesPj.filter(([, f]) => f).map(([, f]) => f.niveau);
      if (niveaux.length && g.niveau != null && Math.max(...niveaux) !== g.niveau) ecarts.push(`niveau du groupe : ${g.niveau} dans le fichier, ${Math.min(...niveaux) === Math.max(...niveaux) ? niveaux[0] : `${Math.min(...niveaux)} à ${Math.max(...niveaux)}`} sur les fiches D&D Beyond`);
      if (niveaux.length && g.niveau == null) ecarts.push(`niveau du groupe absent du fichier ; ${Math.max(...niveaux)} sur les fiches D&D Beyond`);
      if (g.etape && g.etape !== dE?.etape) ecarts.push(`étape : \`${g.etape}\` dans le fichier, \`${dE?.etape || 'aucune'}\` ici`);
      if (dI?.lieu && g.lieu_actuel !== dI.lieu) ecarts.push(`lieu actuel : \`${g.lieu_actuel || 'aucun'}\` dans le fichier, \`${dI.lieu}\` ici`);
      const visitesIci = [...new Set((dI?.visites || []).map(x => x.lieu))].filter(id => !(g.lieux_visites || []).includes(id));
      if (visitesIci.length) ecarts.push(`lieux visités notés ici mais absents de \`groupe.lieux_visites\` : ${visitesIci.map(id => `${nomLieu(lieux, id)} (\`${id}\`)`).join(', ')}`);
      const fichier = new Set(g.pnj_rencontres || []);
      const ici = new Set(suivis.filter(([, s]) => s.rencontre).map(([id]) => id));
      const seulFichier = [...fichier].filter(id => !ici.has(id));
      const seulIci = [...ici].filter(id => !fichier.has(id));
      if (seulFichier.length) ecarts.push(`PNJ rencontrés dans le fichier mais pas notés ici : ${seulFichier.map(id => `${nomPnj(id)} (\`${id}\`)`).join(', ')} (s'ils ont bien été rencontrés, mets-les dans \`pnj\` du bloc maj-etat)`);
      if (seulIci.length) ecarts.push(`PNJ notés rencontrés ici mais absents de \`groupe.pnj_rencontres\` : ${seulIci.map(id => `${nomPnj(id)} (\`${id}\`)`).join(', ')}`);
      ligne('### Écarts avec `data/personnages.json`');
      ligne(ecarts.length ? ecarts.map(x => `- ${x}.`).join('\n') : '- Aucun.');
      ligne('');
    }
    // Lore et secrets écrits par le MJ (onglets Lore et Secret des fiches, app/lore.js) : à reprendre dans personnages.json.
    const retouches = retouchesEnMarkdown(personnages?.personnages, { valeur: etats.lore });
    if (retouches.length) {
      ligne('### Lore retouché par le MJ');
      ligne('Ce que j\'ai écrit moi-même dans les fiches des personnages (onglets Lore et Secret du gestionnaire). **Reprends-le** dans `personnages.json` au prochain export, dans les mêmes champs, **mot pour mot** : le gestionnaire l\'affiche par-dessus le fichier et ne l\'oublie que lorsque le fichier dit exactement la même chose. Il fait foi sur le wiki.');
      retouches.forEach(x => ligne(x));
      ligne('');
    }
    // L'agenda tenu par le MJ (Horloge, 2026-10-25) : ses entrées ajoutées ou modifiées, et celles du fichier qu'il a retirées.
    const surAgenda = etats.agenda || {};
    const ajoutsAgenda = Object.entries(surAgenda.entrees || {}), retraitsAgenda = surAgenda.retirees || [];
    if (ajoutsAgenda.length || retraitsAgenda.length) {
      const dateAgenda = x => (x.date ? `${x.date.jour} ${calD?.mois.find(m => m.id === x.date.mois)?.nom || x.date.mois} ${x.date.annee} (\`{ annee: ${x.date.annee}, mois: "${x.date.mois}", jour: ${x.date.jour} }\`)` : '?');
      ligne('### Agenda tenu par le MJ');
      ligne('Ce que j\'ai noté dans l\'agenda du gestionnaire. **Reprends-le** dans `agenda.json` au prochain export (`formats/agenda.md`) : une entrée `mj-…` devient une entrée du fichier (donne-lui un `id` à toi), une retouche remplace le texte de l\'entrée du même `id`, une entrée retirée sort du fichier.');
      ajoutsAgenda.forEach(([id, x]) => ligne(`- ${id.startsWith('mj-') ? 'Ajoutée' : `Retouchée (\`${id}\`)`} : ${dateAgenda(x)} · « ${x.nom} »${x.details ? ` : ${x.details}` : ''}${x.alertes ? ` (alertes : \`{ jour_meme: ${x.alertes.jour_meme}, avant: [${(x.alertes.avant || []).join(', ')}] }\`)` : ''}`));
      retraitsAgenda.forEach(id => ligne(`- Retirée : \`${id}\`${agendaD.find(e => e.id === id) ? ` (« ${agendaD.find(e => e.id === id).nom} »)` : ''}`));
      ligne('');
    }
    ligne('## Format du bloc à me rendre : `maj-etat`, format 1');
    ligne('');
    ligne('Contrat complet : `formats/maj-etat.md` du gestionnaire. Tous les champs sont facultatifs : n\'écris que ce qui change. Les `id` sont ceux de `data/`.');
    ligne('');
    ligne('```json');
    ligne(JSON.stringify({
      schema: 1, jeu: 'maj-etat', session: maintenant.toISOString().slice(0, 10), resume: 'Une ou deux phrases sur la séance.',
      deroule: { etape: e?.id || etapes[0]?.id || 'id-d-etape', jalon: 'id-de-jalon', pistes: ['id-de-piste'], termines: ['id-d-etape-de-jalon-ou-de-piste'] },
      lieu: { actuel: dI?.lieu || 'id-de-lieu', sous_lieu: null, visites: [] },
      horloge: { jour: dH?.jour || 1, heure: '21:30' },
      pnj: { 'id-du-pnj': { rencontre: true, etat: 'mort', rang: 'majeur', note: 'Ce qui s\'est passé avec lui (ajouté à la suite des notes).' } },
      ...Object.assign({}, ...contributions('sessionExemple')),   // clés des modules de campagne (le Tarokka)
      rencontres: { retirer: ['id-de-rencontre'], remettre: [], suivis_resolus: ['id-de-suite'], terminees: { 'id-de-rencontre-prevue': 'Ce qui s\'est passé.' } },
      babioles: { distribuer: { 'id-de-babiole': { a: 'id-de-personnage', note: 'Où, comment.' } }, remettre: [] },
      objets: { donner: { 'id-d-objet': { a: 'id-de-personnage', quantite: 1 } } },
    }, null, 2));
    ligne('```');
    ligne('');
    ligne('- `deroule.etape` : `id` d\'une étape démarrée pendant la séance (`deroule-campagne.json`), qui devient l\'étape de référence ; les étapes sont indicatives, plusieurs peuvent être en cours. `deroule.jalon` : `id` d\'un jalon à marquer en cours (plusieurs jalons peuvent l\'être). `deroule.pistes` : `id` de pistes à marquer commencées. `deroule.termines` : `id` d\'étapes, de jalons ou de pistes faits ou finis pendant la séance. N\'écris que ce qui a changé.');
    ligne('- `lieu.actuel` : `id` de `lieux.json` où sont les héros à la fin de la séance (un sous-lieu est accepté : il passe par son lieu) ; `lieu.sous_lieu` : `id` d\'un sous-lieu de ce lieu, ou `null` ; `lieu.visites` : lieux traversés en chemin, à noter comme visités. N\'écris `lieu` que s\'ils ont bougé sans que je le note.');
    ligne('- `horloge` : jour de campagne (`jour`, entier) et heure de jeu (`heure`, `"HH:MM"`) à la fin de la séance, seulement si le récit permet de les situer et qu\'ils diffèrent de l\'horloge ci-dessus.');
    ligne(`- \`pnj.<id>.etat\` : ${ETATS_PNJ.join(', ')}, ou \`""\` pour revenir à l'état du fichier. \`rang\` : ${RANGS.join(', ')}. \`note\` s'ajoute aux notes existantes, datée de \`session\`.`);
    contributions('sessionAide').flat().forEach(t => ligne(t));
    ligne('- `rencontres.retirer` : rencontres **des tables aléatoires** jouées hors du tirage (une unique) ou devenues sans objet, à cacher des tables. `rencontres.suivis_resolus` : `id` des suites listées plus haut.');
    ligne('- `rencontres.terminees` : rencontres prévues (`rencontres_scenarisees` de `rencontres-aleatoires.json`) ou créées par le MJ (`mj-…`) jouées sans que je les aie marquées terminées (en ligne, dans Maps, par exemple), avec ce qui s\'est passé (`""` sinon). Pas celles des « Rencontres jouées » plus haut.');
    ligne('- `babioles.distribuer` : babioles données en séance sans passer par le widget (`id` de ligne de `babioles.json`) ; `a` : `id` de `personnages.json`, `"groupe"`, ou `""` si on ne sait pas. `babioles.remettre` : babioles notées données par erreur.');
    ligne('- `objets.donner` : objets trouvés ou reçus en séance (`id` de `objets.json`, ou d\'un objet créé par le MJ, `mj-…`) que je n\'ai pas donnés dans le gestionnaire ; `a` : `id` de `personnages.json` ou `"groupe"` ; `quantite` : 1 d\'office. Pas ceux des « Objets donnés » plus haut. Le don est seulement noté : l\'inventaire D&D Beyond ne change pas.');
    ligne('- Niveau, PV, inventaire D&D Beyond et origines des personnages ne passent pas par ce bloc : le gestionnaire les relit lui-même sur D&D Beyond. Reporte-les dans tes fiches et dans `personnages.json` au prochain export.');
    if (joindreOrigines) {
      ligne('');
      ligne(`## Origines des personnages (D&D Beyond, relevées le ${date(details.maj)})`);
      ligne('');
      ligne(originesEnMarkdown(details, beyond, 3));
    }
    return l.join('\n');
  }

  // ───── 2. Lecture du bloc maj-etat et liste des changements ─────

  function extraire(texte) {
    const blocs = [...String(texte).matchAll(/```(?:json)?\s*([\s\S]*?)```/g)].map(m => m[1]);
    for (const b of [...blocs.filter(b => b.includes('maj-etat')), ...blocs, texte]) {
      try { const o = JSON.parse(String(b).trim()); if (o && typeof o === 'object') return o; } catch { /* suivant */ }
    }
    throw new Error('Aucun bloc JSON lisible. Copiez la réponse de l\'agent IA en entier, ou seulement le bloc ```json.');
  }

  // Chaque changement : { fichier, quoi, avant, apres, appliquer(etats) } ; les refus vont dans `ignores`.
  function changements(m) {
    const liste = [], ignores = [];
    const oui = v => v ? 'oui' : 'non';
    const session = typeof m.session === 'string' ? m.session : null;
    const jour = session || new Date().toISOString().slice(0, 10);   // date des dons et des fins de rencontre notés par le bloc
    if (m.schema !== 1 || m.jeu !== 'maj-etat') ignores.push(`En-tête : « schema » ${m.schema}, « jeu » ${m.jeu} (attendu : 1 et « maj-etat »). Le bloc est lu quand même.`);

    if (m.deroule && typeof m.deroule === 'object') {
      const dE = etats.deroule || {};
      const suiviDe = (E, genre, id) => { E.deroule.suivi ||= {}; E.deroule.suivi[genre] ||= {}; return (E.deroule.suivi[genre][id] ||= {}); };
      const maintenant = new Date().toISOString();
      if (!deroule && ['etape', 'jalon', 'pistes', 'termines'].some(k => k in m.deroule)) ignores.push('« deroule » : deroule-campagne.json n\'est pas lisible (absent, ou pas encore au format 2), le suivi du déroulé n\'est pas changé.');
      // L'étape démarrée devient l'étape de référence ; elle compte comme commencée (et n'est plus terminée).
      if (deroule && 'etape' in m.deroule) {
        const id = m.deroule.etape;
        if (id !== null && !etapes.some(x => x.id === id)) ignores.push(`Étape « ${id} » inconnue de deroule-campagne.json.`);
        else if (id !== (dE.etape ?? null)) liste.push({ fichier: 'deroule', quoi: 'Étape de référence (démarrée)', avant: dE.etape ? nomEtape(dE.etape) : 'aucune', apres: id ? nomEtape(id) : 'aucune',
          appliquer: E => { E.deroule.etape = id; if (id) { const y = suiviDe(E, 'etapes', id); y.debut ||= maintenant; delete y.fin; } } });
      }
      // Pistes à marquer commencées.
      for (const id of deroule && Array.isArray(m.deroule.pistes) ? m.deroule.pistes : []) {
        const x = dE.suivi?.pistes?.[id];
        if (!pistes.some(p => p.id === id)) ignores.push(`Piste « ${id} » (deroule.pistes) inconnue de deroule-campagne.json.`);
        else if (!(x?.debut && !x.fin)) liste.push({ fichier: 'deroule', quoi: `Piste commencée : ${nomPiste(id)}`, avant: x?.fin ? 'terminée' : 'à venir', apres: 'commencée',
          appliquer: E => { const y = suiviDe(E, 'pistes', id); y.debut ||= maintenant; delete y.fin; } });
      }
      // Un jalon à mettre en cours (il s'ajoute à ceux qui le sont déjà) ; l'étape en cours ne change pas.
      if (deroule && 'jalon' in m.deroule && m.deroule.jalon !== null) {
        const id = m.deroule.jalon;
        const x = dE.suivi?.jalons?.[id];
        if (!jalons.some(j => j.id === id)) ignores.push(`Jalon « ${id} » inconnu de deroule-campagne.json.`);
        else if (!(x?.debut && !x.fin)) liste.push({ fichier: 'deroule', quoi: `Jalon en cours : ${nomJalon(id)}`, avant: x?.fin ? 'terminé' : 'à venir', apres: 'en cours',
          appliquer: E => { const y = suiviDe(E, 'jalons', id); y.debut ||= maintenant; delete y.fin; } });
      }
      // Étapes, jalons et pistes faits ou finis pendant la séance.
      for (const id of deroule && Array.isArray(m.deroule.termines) ? m.deroule.termines : []) {
        const genre = etapes.some(x => x.id === id) ? 'etapes' : jalons.some(x => x.id === id) ? 'jalons' : pistes.some(x => x.id === id) ? 'pistes' : null;
        if (!genre) { ignores.push(`« ${id} » (deroule.termines) : ni étape, ni jalon, ni piste de deroule-campagne.json.`); continue; }
        if (dE.suivi?.[genre]?.[id]?.fin) continue;
        liste.push({ fichier: 'deroule', quoi: `Terminé : ${{ etapes: nomEtape, jalons: nomJalon, pistes: nomPiste }[genre](id)}${genre === 'pistes' ? ' (piste)' : ''}`, avant: 'non', apres: 'oui', termine: { genre, id },
          appliquer: E => { const y = suiviDe(E, genre, id); y.debut ||= maintenant; y.fin ||= maintenant; } });
      }
    }

    // Horloge d'abord : l'heure retenue date aussi l'arrivée au nouveau lieu.
    let horlogeVisee = null;
    if (m.horloge && typeof m.horloge === 'object') {
      const dH = { ...DEPART, ...(etats.horloge || {}) };
      const jour = 'jour' in m.horloge ? m.horloge.jour : dH.jour;
      const minute = 'heure' in m.horloge ? depuisHHMM(m.horloge.heure) : dH.minute;
      if (!(Number.isInteger(jour) && jour >= 1)) ignores.push(`Horloge : « jour » vaut ${JSON.stringify(m.horloge.jour)}, un entier de 1 ou plus est attendu.`);
      else if (minute === null) ignores.push(`Horloge : « heure » vaut ${JSON.stringify(m.horloge.heure)}, « HH:MM » est attendu.`);
      else {
        horlogeVisee = { jour, minute };
        const avant = { jour: dH.jour, minute: dH.minute };
        if (enMinutes(avant) !== enMinutes(horlogeVisee)) liste.push({ fichier: 'horloge', quoi: 'Horloge', avant: etats.horloge?.maj ? libelleMoment(avant) : 'pas réglée', apres: libelleMoment(horlogeVisee),
          appliquer: E => {
            const a = { jour: E.horloge.jour ?? DEPART.jour, minute: E.horloge.minute ?? DEPART.minute };
            Object.assign(E.horloge, horlogeVisee);
            E.horloge.journal = [...(E.horloge.journal || []), { quand: new Date().toISOString(), avant: a, apres: { ...horlogeVisee }, motif: `Séance du ${session || 'jour'}` }].slice(-200);
          } });
      }
    }

    // Lieu des héros (etat/ici.json) : un lieu, ou un sous-lieu qui passe par son lieu.
    if (m.lieu && typeof m.lieu === 'object') {
      const dI = etats.ici || {};
      const quandArrivee = { quand: session || new Date().toISOString().slice(0, 10), ...(horlogeVisee || {}) };
      // etat/ici.json pas encore créé : les lieux visités partent de personnages.json, comme dans le widget Ici.
      const preparer = E => { E.ici.notes ||= {}; if (!Array.isArray(E.ici.visites)) E.ici.visites = (personnages?.groupe?.lieux_visites || []).map(lieu => ({ lieu })); };
      const libelle = (l, sl) => l ? nomLieu(lieux, l) + (sl ? `, ${nomLieu(lieux, sl)}` : '') : 'aucun';
      let lieuVise = dI.lieu ?? null, sousVise = dI.sous_lieu ?? null;
      if ('actuel' in m.lieu) {
        const l = lieux.get(m.lieu.actuel);
        if (!l) ignores.push(`Lieu « ${m.lieu.actuel} » inconnu de lieux.json.`);
        else { lieuVise = l.parent || l.id; sousVise = l.parent ? l.id : null; }
      }
      if ('sous_lieu' in m.lieu) {
        const id = m.lieu.sous_lieu;
        if (id !== null && lieux.get(id)?.parent !== lieuVise) ignores.push(`Sous-lieu « ${id} » : ce n'est pas un sous-lieu de ${libelle(lieuVise)}.`);
        else sousVise = id;
      }
      // Lieux traversés en chemin, avant le lieu d'arrivée (les visites restent dans l'ordre).
      const dejaVus = new Set((dI.visites || []).map(x => x.lieu));
      for (const id of Array.isArray(m.lieu.visites) ? m.lieu.visites : []) {
        const l = lieux.get(id);
        if (!l || l.parent) { ignores.push(`Lieu visité « ${id} » : ${l ? 'c\'est un sous-lieu, indiquez son lieu' : 'inconnu de lieux.json'}.`); continue; }
        if (!dejaVus.has(id) && id !== lieuVise) liste.push({ fichier: 'ici', quoi: `Lieu visité : ${nomLieu(lieux, id)}`, avant: 'pas noté', apres: 'visité',
          appliquer: E => { preparer(E); if (!E.ici.visites.some(x => x.lieu === id)) E.ici.visites.push({ lieu: id, quand: quandArrivee.quand }); } });
      }
      if (lieuVise && lieuVise !== (dI.lieu ?? null))
        liste.push({ fichier: 'ici', quoi: 'Lieu des héros', avant: libelle(dI.lieu, dI.sous_lieu), apres: libelle(lieuVise, sousVise),
          appliquer: E => { preparer(E); E.ici.visites.push({ lieu: lieuVise, ...quandArrivee }); E.ici.lieu = lieuVise; E.ici.sous_lieu = sousVise; } });
      else if (lieuVise && sousVise !== (dI.sous_lieu ?? null))
        liste.push({ fichier: 'ici', quoi: 'Sous-lieu des héros', avant: libelle(dI.sous_lieu ? dI.lieu : null, dI.sous_lieu), apres: libelle(lieuVise, sousVise),
          appliquer: E => { preparer(E); E.ici.sous_lieu = sousVise; } });
    }

    for (const [id, c] of Object.entries(m.pnj || {})) {
      const p = pnjParId.get(id);
      if (!p) { ignores.push(`PNJ « ${id} » inconnu de pnj.json.`); continue; }
      const s = etats.pnj?.pnj?.[id] || {};
      const pour = fn => E => { E.pnj.pnj ||= {}; const sv = (E.pnj.pnj[id] ||= {}); fn(sv); if (!Object.keys(sv).length) delete E.pnj.pnj[id]; };
      if (typeof c.rencontre === 'boolean' && c.rencontre !== !!s.rencontre)
        liste.push({ fichier: 'pnj', quoi: `${p.nom} : rencontré`, avant: oui(s.rencontre), apres: oui(c.rencontre), appliquer: pour(sv => { if (c.rencontre) sv.rencontre = true; else delete sv.rencontre; }) });
      if ('etat' in c) {
        if (c.etat !== '' && !ETATS_PNJ.includes(c.etat)) ignores.push(`${p.nom} : état « ${c.etat} » inconnu.`);
        else {
          // Un état égal à celui du fichier revient à « comme le fichier ».
          const fichier = p.etat || 'vivant';
          const voulu = c.etat && c.etat !== fichier ? c.etat : '';
          if (voulu !== (s.etat && s.etat !== fichier ? s.etat : ''))
            liste.push({ fichier: 'pnj', quoi: `${p.nom} : état en jeu`, avant: s.etat || `comme le fichier (${fichier})`, apres: voulu || `comme le fichier (${fichier})`, appliquer: pour(sv => { if (voulu) sv.etat = voulu; else delete sv.etat; }) });
        }
      }
      if ('rang' in c) {
        if (!RANGS.includes(c.rang)) ignores.push(`${p.nom} : rang « ${c.rang} » inconnu.`);
        else if (c.rang !== rangDe(p, s))
          liste.push({ fichier: 'pnj', quoi: `${p.nom} : rang`, avant: LIB_RANG[rangDe(p, s)], apres: LIB_RANG[c.rang], appliquer: pour(sv => { delete sv.important; if (c.rang === rangFichier(p)) delete sv.rang; else sv.rang = c.rang; }) });
      }
      if (typeof c.note === 'string' && c.note.trim())
        liste.push({ fichier: 'pnj', quoi: `${p.nom} : note ajoutée`, avant: null, apres: c.note.trim(), appliquer: pour(sv => { sv.note = ajouterNote(sv.note, c.note, session); }) });
    }

    // Clés des modules de campagne (le Tarokka) : chacun les vérifie et ajoute ses changements à la liste.
    contributions('sessionAppliquer', { m, etats, liste, ignores, oui, ajouterNote, session });

    // Conditions de campagne : retirées du gestionnaire (2026-10-23), le MJ juge lui-même des écarts conditionnels.
    if ('conditions' in m) ignores.push('« conditions » : le gestionnaire ne note plus de conditions de campagne, la clé est ignorée.');

    const r = m.rencontres || {};
    // retirer : cachée des tables, et marquée rencontrée si c'est une unique ; remettre : ni l'une ni l'autre.
    const retirees = new Set([...(etats.rencontres?.retirees || []), ...(etats.rencontres?.rencontrees || [])]);
    const desTables = new Set((rencontresD?.rencontres || []).map(x => x.id));
    const uniqueR = id => fichesRencontres.get(id)?.unique;
    for (const id of r.retirer || []) {
      if (!desTables.has(id)) ignores.push(fichesRencontres.has(id) ? `« ${nomRencontre(id)} » n'est pas dans les tables aléatoires : rien à retirer.` : `Rencontre « ${id} » inconnue.`);
      else if (!retirees.has(id)) liste.push({ fichier: 'rencontres', quoi: `Rencontre ${uniqueR(id) ? 'rencontrée, cachée' : 'cachée'} des tables : ${nomRencontre(id)}`, avant: 'dans les tables', apres: uniqueR(id) ? 'rencontrée' : 'cachée', appliquer: E => {
        E.rencontres.retirees ||= [];
        if (!E.rencontres.retirees.includes(id)) E.rencontres.retirees.push(id);
        if (uniqueR(id)) { E.rencontres.rencontrees ||= E.rencontres.retirees.filter(x => x !== id && uniqueR(x)); if (!E.rencontres.rencontrees.includes(id)) E.rencontres.rencontrees.push(id); }
      } });
    }
    for (const id of r.remettre || []) {
      if (retirees.has(id)) liste.push({ fichier: 'rencontres', quoi: `Rencontre remise dans les tables : ${nomRencontre(id)}`, avant: 'cachée', apres: 'dans les tables', appliquer: E => {
        E.rencontres.retirees = (E.rencontres.retirees || []).filter(x => x !== id);
        if (E.rencontres.rencontrees) E.rencontres.rencontrees = E.rencontres.rencontrees.filter(x => x !== id);
      } });
    }
    for (const id of r.suivis_resolus || []) {
      const s = (etats.rencontres?.suivis || []).find(x => x.id === id);
      if (!s) ignores.push(`Suite « ${id} » inconnue.`);
      else if (!s.resolu) liste.push({ fichier: 'rencontres', quoi: `Suite résolue : ${nomRencontre(s.rencontre)}`, avant: 'à jouer', apres: 'résolue', appliquer: E => { const x = (E.rencontres.suivis || []).find(y => y.id === id); if (x) x.resolu = true; } });
    }
    // Rencontres prévues ou créées par le MJ jouées sans être marquées terminées (en ligne, dans Maps) : etat/rencontres-mj.json,
    // comme « Marquer terminée » (app/rencontres-mj.js), datées du jour de la séance.
    const scenarisees = new Set((rencontresD?.rencontres_scenarisees || []).map(x => x.id));
    const entreesMj = etats['rencontres-mj']?.rencontres || [];
    for (const [id, remarque] of Object.entries(r.terminees && typeof r.terminees === 'object' ? r.terminees : {})) {
      const e = entreesMj.find(x => x.id === id);
      if (!scenarisees.has(id) && e?.origine !== 'creee') {
        ignores.push(desTables.has(id) ? `« ${nomRencontre(id)} » (rencontres.terminees) est une rencontre des tables aléatoires : « rencontres.retirer » la cache des tables.` : `Rencontre « ${id} » (rencontres.terminees) : ni prévue dans les données, ni créée dans le gestionnaire.`);
        continue;
      }
      if (e?.statut === 'terminee') continue;
      const texte = typeof remarque === 'string' ? remarque.trim() : '';
      liste.push({ fichier: 'rencontres-mj', quoi: `Rencontre jouée : ${scenarisees.has(id) ? nomRencontre(id) : e.nom?.trim() || id}`, avant: e?.statut === 'en-cours' ? 'en cours' : 'à jouer', apres: texte ? `terminée : ${texte}` : 'terminée',
        appliquer: E => {
          const R = E['rencontres-mj'];
          R.rencontres ||= [];
          let x = R.rencontres.find(y => y.id === id);
          if (!x) R.rencontres.push(x = { id, origine: 'prevue', groupes: [], creee: new Date().toISOString() });
          Object.assign(x, { statut: 'terminee', fin: { quand: jour }, remarque: texte || x.remarque || null });
          if (R.combat?.rencontre === id) R.combat = null;
        } });
    }

    const b = m.babioles || {};
    const dejaDonnees = etats.babioles?.distribuees || {};
    for (const [id, c] of Object.entries(b.distribuer || {})) {
      const trouve = babioleParId.get(id);
      if (!trouve) { ignores.push(`Babiole « ${id} » inconnue de babioles.json.`); continue; }
      if (trouve.l.a_remplir) { ignores.push(`Babiole « ${id} » : emplacement vierge (« a_remplir »), rien à donner.`); continue; }
      const a = typeof c?.a === 'string' ? c.a : '';
      if (a && a !== 'groupe' && !persoParId.has(a)) { ignores.push(`Babiole « ${nomBabiole(id)} » : « a » vaut « ${a} », ni un id de personnages.json, ni « groupe », ni "".`); continue; }
      const note = typeof c?.note === 'string' ? c.note.trim() : '';
      const avant = dejaDonnees[id];
      if (avant && (avant.a || '') === a && (avant.note || '') === note) continue;
      liste.push({ fichier: 'babioles', quoi: `Babiole donnée : ${nomBabiole(id)}`, avant: avant ? `${distribution(avant)}, le ${jourBabiole(avant.quand)}` : 'pas donnée', apres: distribution({ a, note }),
        appliquer: E => { E.babioles.distribuees ||= {}; E.babioles.distribuees[id] = { quand: session || new Date().toISOString().slice(0, 10), a, note }; } });
    }
    for (const id of b.remettre || []) {
      if (!dejaDonnees[id]) { ignores.push(babioleParId.has(id) ? `Babiole « ${nomBabiole(id)} » : pas notée comme donnée, rien à remettre.` : `Babiole « ${id} » inconnue.`); continue; }
      liste.push({ fichier: 'babioles', quoi: `Babiole reprise : ${nomBabiole(id)}`, avant: `${distribution(dejaDonnees[id])}, le ${jourBabiole(dejaDonnees[id].quand)}`, apres: 'pas donnée',
        appliquer: E => { delete E.babioles.distribuees?.[id]; } });
    }

    // Objets donnés en séance sans passer par le gestionnaire : un don noté seulement (rien sur D&D Beyond), etat/objets.json.
    const dejaDons = etats.objets?.objets || {};
    for (const [id, c] of Object.entries(m.objets?.donner && typeof m.objets.donner === 'object' ? m.objets.donner : {})) {
      if (!objetParId.has(id) && !dejaDons[id]?.cree) { ignores.push(`Objet « ${id} » (objets.donner) : ni dans objets.json, ni créé dans le gestionnaire.`); continue; }
      const a = typeof c?.a === 'string' ? c.a : '';
      if (a !== 'groupe' && !persoParId.has(a)) { ignores.push(`Objet « ${nomObjet(id)} » : « a » vaut « ${a} », ni un id de personnages.json, ni « groupe ».`); continue; }
      const quantite = Number.isInteger(c?.quantite) && c.quantite > 0 ? c.quantite : 1;
      const avant = (dejaDons[id]?.dons || []).filter(x => !x.identification);
      liste.push({ fichier: 'objets', quoi: `Objet donné : ${nomObjet(id)}`, avant: avant.length ? `déjà donné ${[...new Set(avant.map(x => aQui(x.a)))].join(', ')}` : 'pas donné',
        apres: `${quantite > 1 ? `×${quantite} ` : ''}${aQui(a)} (noté seulement, pas sur D&D Beyond)`, donne: id,
        decoche: avant.some(x => x.a === a),   // déjà donné aux mêmes mains : sans doute le même don, décoché d'office
        appliquer: E => { E.objets.objets ||= {}; const e = (E.objets.objets[id] ||= {}); e.dons ||= []; e.dons.push({ a, quantite, quand: jour }); } });
    }
    return { liste, ignores };
  }

  // ───── Vues ─────

  let ongletActif = 'avant';
  let texteColle = '';
  let lecture = null;   // { m, liste, ignores, coches: Set } ou { erreur }
  const zone = h('div', { class: 'cm-pile cm-session' });

  function vueAvant() {
    const texte = prompt();
    const aire = h('textarea', { class: 'bn-textarea cm-session__texte', rows: 14, readonly: true, 'aria-label': 'Prompt pour l\'agent IA de campagne' }, texte);
    const statut = h('span', { class: 'ui-s cm-sourdine', 'aria-live': 'polite' });
    const marquer = async () => {
      if (complet) return;   // l'export complet ne remplace pas l'envoi de fin de session
      etats.session.dernier_export = new Date().toISOString();
      await ecrireEtat('session', etats.session).catch(() => {});
    };
    return h('div', { class: 'cm-pile' },
      h('p', { class: 'ui' }, 'Vous pouvez utiliser cet export pour alimenter votre agent IA de campagne avant son analyse de fin de session ; vous pourrez aussi y joindre les retours récupérés du wiki, si vous avez activé cette option. L\'état noté ici fait foi ; l\'agent répond par un bloc JSON à coller dans l\'onglet « Après l\'analyse ».'),
      bascule('Portée de l\'export', [[false, 'Depuis le dernier envoi', 'lu-clock'], [true, 'Toute la campagne', 'lu-list']], complet, x => { complet = x; rendre(); }),
      complet ? h('p', { class: 'ui-s cm-sourdine' }, 'Tout le déroulé, élément par élément, avec vos remarques sur les rencontres, même ajoutées après coup, et tout ce qui a été noté depuis le début. Il ne compte pas comme un envoi : le prochain export de fin de session reprendra au même point.')
        : etats.session?.dernier_export ? h('p', { class: 'ui-s cm-sourdine' }, `Dernier envoi : ${date(etats.session.dernier_export)}.`) : null,
      details.maj ? h('label', { class: 'cm-case' },
        h('input', { type: 'checkbox', class: 'bn-case', checked: joindreOrigines, onchange: e => { joindreOrigines = e.target.checked; rendre(); } }),
        h('span', {}, `Joindre les origines des personnages (D&D Beyond, relevées le ${date(details.maj)}) : historique, espèce, dons, avec leurs textes`))
        : h('p', { class: 'ui-s cm-sourdine' }, 'Origines des personnages pas encore relevées : widget Personnages, bouton d20, « Relever les détails ».'),
      aire,
      h('div', { class: 'bn-groupe' },
        bouton('Copier', { classe: 'bn-btn--primaire', icone: 'lu-copy', onclick: async () => {
          try { await navigator.clipboard.writeText(texte); statut.textContent = 'Copié.'; }
          catch { aire.select(); document.execCommand('copy'); statut.textContent = 'Copié.'; }
          marquer();
        } }),
        bouton('Télécharger (.md)', { classe: 'bn-btn--fantome', icone: 'livre', onclick: () => {
          const a = h('a', { href: URL.createObjectURL(new Blob([texte], { type: 'text/markdown' })), download: `etat-campagne${complet ? '-complet' : ''}-${new Date().toISOString().slice(0, 10)}.md` });
          document.body.append(a); a.click(); a.remove();
          statut.textContent = 'Téléchargé.';
          marquer();
        } }),
        statut));
  }

  function vueApres() {
    const aire = h('textarea', { class: 'bn-textarea cm-session__texte', rows: 8, placeholder: 'Collez ici la réponse de l\'agent IA (ou seulement son bloc ```json).', 'aria-label': 'Réponse de l\'agent IA de campagne', oninput: e => { texteColle = e.target.value; } }, texteColle);
    const lire = () => {
      try {
        const m = extraire(texteColle);
        const { liste, ignores } = changements(m);
        lecture = { m, liste, ignores, coches: new Set(liste.map((_, i) => i).filter(i => !liste[i].decoche)) };
      } catch (e) { lecture = { erreur: e.message }; }
      rendre();
    };
    return h('div', { class: 'cm-pile' },
      h('p', { class: 'ui' }, 'Collez la réponse de votre agent IA de campagne après son analyse. Chaque changement est listé : décochez ce que vous ne voulez pas, puis appliquez. Les notes s\'ajoutent à la suite, rien n\'est effacé.'),
      aire,
      h('div', { class: 'bn-groupe' }, bouton('Lire les changements', { classe: 'bn-btn--primaire', icone: 'lu-list', onclick: lire })),
      lecture ? vueLecture() : null,
      historique());
  }

  function vueLecture() {
    if (lecture.erreur) return alerte('sang', 'lu-triangle-alert', 'Réponse illisible', lecture.erreur);
    const { m, liste, ignores, coches } = lecture;
    const appliquer = bouton(`Appliquer ${coches.size} changement${coches.size > 1 ? 's' : ''}`, { classe: 'bn-btn--primaire', icone: 'lu-check', disabled: !coches.size, onclick: async () => {
      // Jalons et étapes terminés par le bloc : d'abord les objets pas encore donnés qui y tiennent (app/objets.js).
      // Ceux que le bloc donne (objets.donner) ne comptent pas.
      const termines = liste.filter((c, i) => coches.has(i) && c.termine && c.termine.genre !== 'pistes').map(c => c.termine);
      if (termines.length) {
        const O = await outilsObjets({ donnees, etat, dialogue });
        const donnes = liste.filter((c, i) => coches.has(i) && c.donne).map(c => c.donne);
        if (!(await O.avantDeTerminer({ jalons: termines.filter(t => t.genre === 'jalons').map(t => t.id), etapes: termines.filter(t => t.genre === 'etapes').map(t => t.id), donnes }))) return;
      }
      appliquer.disabled = true;
      try {
        const E = await charger();
        const touches = new Set();
        liste.forEach((c, i) => { if (coches.has(i)) { E[c.fichier] ||= { schema: 1 }; c.appliquer(E); touches.add(c.fichier); } });
        for (const f of touches) await ecrireEtat(f, E[f]);
        E.session.historique = [...(E.session.historique || []), { quand: new Date().toISOString(), session: m.session || null, resume: m.resume || '', changements: coches.size }].slice(-HISTORIQUE_MAX);
        await ecrireEtat('session', E.session);
        location.reload();   // tous les widgets relisent l'état
      } catch (e) {
        appliquer.disabled = false;
        zone.prepend(alerte('sang', 'lu-triangle-alert', 'Enregistrement impossible', String(e.message || e)));
      }
    } });
    return h('div', { class: 'cm-pile' },
      h('div', { class: 'bn-carte' },
        h('span', { class: 'surtitre' }, m.session ? `Séance du ${m.session}` : 'Séance'),
        m.resume ? h('p', { class: 'ui' }, m.resume) : null),
      liste.length ? h('ul', { class: 'cm-session__changements' }, liste.map((c, i) => h('li', {},
        h('label', { class: 'cm-case' },
          h('input', { type: 'checkbox', class: 'bn-case', checked: coches.has(i), onchange: e => { if (e.target.checked) coches.add(i); else coches.delete(i); rendre(); } }),
          h('span', {}, h('b', {}, c.quoi), c.avant !== null ? h('span', { class: 'cm-sourdine' }, ` : ${c.avant} → `) : h('span', { class: 'cm-sourdine' }, ' : '), h('span', {}, c.apres)))))) : h('p', { class: 'ui cm-sourdine' }, 'Rien ne change par rapport à l\'état actuel.'),
      ignores.length ? alerte('cierge', 'lu-triangle-alert', `${ignores.length} élément${ignores.length > 1 ? 's' : ''} ignoré${ignores.length > 1 ? 's' : ''}`, h('ul', { class: 'ui-s cm-liste' }, ignores.map(x => h('li', {}, x)))) : null,
      liste.length ? h('div', { class: 'bn-groupe' }, appliquer, h('span', { class: 'ui-s cm-sourdine' }, 'La page se recharge ensuite. Une copie du jour est gardée dans etat/sauvegardes/.')) : null);
  }

  function historique() {
    const hs = [...(etats.session?.historique || [])].reverse().slice(0, 5);
    return hs.length ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, 'Mises à jour déjà appliquées'),
      h('ul', { class: 'ui-s cm-liste' }, hs.map(x => h('li', {}, `${date(x.quand)}${x.session ? ` · séance du ${x.session}` : ''} · ${x.changements} changement${x.changements > 1 ? 's' : ''}${x.resume ? ` · ${x.resume}` : ''}`)))) : null;
  }

  function rendre() {
    const o = onglets('Session', [
      { id: 'avant', libelle: 'Avant l\'analyse', icone: 'lu-copy', rendu: vueAvant },
      { id: 'apres', libelle: 'Après l\'analyse', icone: 'lu-check', rendu: vueApres },
    ], ongletActif, id => { ongletActif = id; });
    zone.replaceChildren(o.barre, o.zone);
  }
  rendre();
  dialogue('Fin de session', 'État pour l\'agent IA de campagne', zone, null, { large: true });
}
