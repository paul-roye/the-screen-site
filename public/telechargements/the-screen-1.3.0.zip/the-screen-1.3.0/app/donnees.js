// Lecture des fichiers de data/ et contrôle de leur format (formats/<jeu>.md).
// Chaque lecture renvoie { jeu, fichier, statut: 'ok' | 'absent' | 'erreur', donnees, problemes: [], converti }.
// Un fichier à un ancien format est converti au chargement quand une conversion existe (app/conversions.js) : `converti`
// donne son format d'origine. `alias` : les anciens noms d'un fichier, lus quand le nouveau n'existe pas.

import { enchainer } from './voyage.js';
import { dateDuJour, rangDate, joursMarques } from './calendrier.js';
import { chargerWiki } from './wiki.js';
import { champsModules } from './modules.js';
import { convertir } from './conversions.js';

// Les fichiers des modules de campagne (app/modules.js : le Tarokka…) s'y ajoutent au démarrage (app/main.js).
export const FORMATS = {
  'rencontres-aleatoires': { schema: 3, verifier: verifierRencontres },
  'noms': { schema: 1, verifier: verifierNoms },
  'occupants-maisons': { schema: 1, verifier: verifierOccupants },
  'faune': { schema: 1, verifier: verifierFaune },
  'temps-de-voyage': { schema: 1, verifier: verifierTrajets },
  'pnj': { schema: 2, verifier: verifierPnj },
  'marchands': { schema: 1, verifier: verifierMarchands },
  'lieux': { schema: 1, verifier: verifierLieux },
  'deroule-campagne': { schema: 2, verifier: verifierDeroule },
  'connaissances': { schema: 2, verifier: verifierConnaissances },
  'personnages': { schema: 2, verifier: verifierPersonnages },
  'factions': { schema: 1, verifier: verifierFactions },
  'babioles': { schema: 2, verifier: verifierBabioles },
  'evenements': { schema: 1, verifier: verifierEvenements, facultatif: 'Seulement pour les événements de campagne du widget Rencontres (des espions qui suivent les héros…), à activer dans la fenêtre Campagne.' },
  // `facultatif` : un fichier dont l'absence est normale (le gestionnaire fournit de quoi s'en passer) ; le texte dit pourquoi.
  'calendrier': { schema: 2, verifier: verifierCalendrier, facultatif: 'Seulement pour un calendrier propre au monde : la campagne peut prendre un calendrier du gestionnaire (fenêtre Campagne, section « Le temps »).' },
  'jours-marques': { schema: 1, verifier: verifierJoursMarques, facultatif: 'Seulement pour des fêtes ou anniversaires propres à la campagne, en plus de ceux du calendrier choisi (un calendrier fourni a déjà ses fêtes : équinoxes, solstices…).' },
  'meteo': { schema: 2, verifier: verifierMeteo, facultatif: 'Seulement pour une météo importée : la campagne peut prendre une météo du gestionnaire (fenêtre Campagne, section « Le temps »).' },
  'objets': { schema: 1, verifier: verifierObjets },
  'quetes': { schema: 1, verifier: verifierQuetes, facultatif: 'Seulement pour le catalogue des quêtes (widget Quêtes, à activer dans la fenêtre Campagne, onglet « Quêtes et réputation ») : le MJ peut aussi créer des quêtes dans le gestionnaire.' },
  'agenda': { schema: 1, verifier: verifierAgenda, facultatif: 'Seulement pour des entrées datées écrites par l\'agent IA de campagne (fêtes, délais, rendez-vous) : le MJ peut aussi tenir l\'agenda dans le gestionnaire (bouton « Agenda » de l\'Horloge).' },
};

const cache = new Map();
const bruts = new Map();   // fichiers lus, pas encore vérifiés

export function chargerDonnees(jeu) {
  if (!cache.has(jeu)) cache.set(jeu, lire(jeu));
  return cache.get(jeu);
}

export function lecturesFaites() { return [...cache.values()]; }

function lireBrut(jeu) {
  if (!bruts.has(jeu)) bruts.set(jeu, telecharger(jeu));
  return bruts.get(jeu);
}

async function telecharger(jeu) {
  const f = FORMATS[jeu];
  const noms = [jeu, ...(f?.alias || [])];
  const res = { jeu, fichier: `data/${jeu}.json`, statut: 'ok', donnees: null, problemes: [], converti: null };
  let r = null;
  for (const nom of noms) {
    const fichier = `data/${nom}.json`;
    try { r = await fetch(fichier, { cache: 'no-store' }); }
    catch (e) { return { ...res, statut: 'erreur', problemes: ['Le serveur local ne répond pas. Lancez lancer.ps1.'] }; }
    if (r.status === 404) continue;
    res.fichier = fichier;
    break;
  }
  if (!r || r.status === 404) return { ...res, statut: 'absent', facultatif: !!FORMATS[jeu]?.facultatif, problemes: [FORMATS[jeu]?.facultatif ? `Facultatif. ${FORMATS[jeu].facultatif}` : `${res.fichier} n'existe pas encore. Écrivez-le, à la main ou avec votre agent IA de campagne (format : formats/${jeu}.md).`] };
  if (!r.ok) return { ...res, statut: 'erreur', problemes: [`Lecture de ${res.fichier} : ${r.status}.`] };
  try { res.donnees = JSON.parse(await r.text()); }
  catch (e) { return { ...res, statut: 'erreur', problemes: [`${res.fichier} n'est pas un JSON valide : ${e.message}`] }; }
  // Ancien nom du fichier (`alias` de FORMATS) : il se lit sous son nouveau nom.
  if (res.fichier !== `data/${jeu}.json` && res.donnees && typeof res.donnees === 'object') res.donnees = { ...res.donnees, jeu };
  // Ancien format : converti en mémoire, s'il y a une conversion (app/conversions.js).
  if (f && res.donnees?.schema < f.schema) {
    const c = convertir(jeu, res.donnees, f.schema);
    res.donnees = c.donnees;
    res.converti = c.depuis;
  }
  return res;
}

async function lire(jeu) {
  const brut = await lireBrut(jeu);
  const res = { ...brut, problemes: [...brut.problemes] };
  if (res.statut !== 'ok') return res;

  const d = res.donnees;
  const f = FORMATS[jeu];
  if (d.jeu !== jeu) res.problemes.push(`Le champ « jeu » vaut « ${d.jeu} » au lieu de « ${jeu} ».`);
  if (f && d.schema !== f.schema) {
    // Refusé : les widgets le voient comme absent (pas de lecture de secours d'un autre format), le bouton Données dit pourquoi.
    res.statut = 'erreur';
    res.schemaRecu = d.schema;
    res.donnees = null;
    res.problemes.push(d.schema < f.schema
      ? `Fichier encore au format ${d.schema} : l'outil lit le format ${f.schema}. Mettez-le à jour selon formats/${jeu}.md, à la main ou avec votre agent IA de campagne.`
      : `Format ${d.schema} reçu, l'outil lit le format ${f.schema}. Régénérez le fichier selon formats/${jeu}.md, ou mettez l'outil à jour.`);
    return res;
  }
  // Les vérifications peuvent consulter un autre fichier (autre('lieux')), tel qu'il a été lu, sans attendre sa propre
  // vérification : deux fichiers peuvent se citer l'un l'autre (deroule-campagne et personnages). Un fichier au mauvais
  // format compte comme absent.
  const autre = async j => {
    if (j === jeu) return null;
    const x = (await lireBrut(j)).donnees;
    return x && (!FORMATS[j] || x.schema === FORMATS[j].schema) ? x : null;
  };
  if (f) await f.verifier(d, res.problemes, autre);
  // Les champs que les modules de campagne posent dans ce fichier (etapes[].tarokka…) : vérifiés par eux.
  for (const v of champsModules(jeu)) await v(d, res.problemes, autre);
  return res;
}

// Libellé d'une condition d'écart (« reliques_reunies ») : dictionnaire `conditions` du fichier, sinon l'identifiant lisible.
export function libelleCondition(id, ...fichiers) {
  for (const d of fichiers) if (d && d.conditions && d.conditions[id]) return d.conditions[id];
  const t = String(id).replace(/_/g, ' ');
  return t.charAt(0).toUpperCase() + t.slice(1);
}

export function verifierEcarts(ecarts, ou, p) {
  for (const e of ecarts || []) {
    if (!['applique', 'conditionnel', 'a_trancher'].includes(e.statut)) p.push(`${ou} : statut d'écart inconnu « ${e.statut} ».`);
    if (e.statut === 'conditionnel' && !e.condition) p.push(`${ou} : écart conditionnel sans « condition ».`);
    if (e.statut === 'a_trancher' && !e.question) p.push(`${ou} : écart à trancher sans « question ».`);
  }
}

// ───── Outils communs aux vérifications ─────

// Plus petit et plus grand résultat d'un dé (« 1d20+1d12 » -> [2, 32]), ou null s'il est illisible.
function bornesDe(formule) {
  const f = String(formule ?? '').replace(/\s+/g, '').toLowerCase();
  if (!/^[+-]?(\d+d\d+|\d+)([+-](\d+d\d+|\d+))*$/.test(f)) return null;
  let min = 0, max = 0;
  for (const [, signe, n, faces, k] of f.matchAll(/([+-]?)(?:(\d+)d(\d+)|(\d+))/g)) {
    const [a, b] = k ? [Number(k), Number(k)] : [Number(n), Number(n) * Number(faces)];
    if (signe === '-') { min -= b; max -= a; } else { min += a; max += b; }
  }
  return [min, max];
}

const estListe = (v, chaines) => Array.isArray(v) && v.length > 0 && (!chaines || v.every(x => typeof x === 'string' && x.trim()));

function exiger(liste, chemin, p, chaines = false) {
  if (!estListe(liste, chaines)) p.push(`« ${chemin} » manquant, vide${chaines ? ' ou avec des valeurs qui ne sont pas du texte' : ''}.`);
  return Array.isArray(liste) ? liste : [];
}

function idsUniques(liste, chemin, p) {
  const vus = new Set();
  for (const x of liste || []) {
    if (!x?.id) p.push(`${chemin} : un élément n'a pas d'« id ».`);
    else if (vus.has(x.id)) p.push(`${chemin} : « ${x.id} » en double.`);
    vus.add(x?.id);
  }
  return vus;
}

// Référentiel des lieux (lieux.json) : { lieux, sous, sousDe (lieu -> ses sous-lieux), parent (sous-lieu -> lieu) },
// ou null si le fichier n'est pas là.
async function referentiel(autre) {
  const l = await autre('lieux');
  if (!l?.lieux) return null;
  const sousDe = new Map(l.lieux.map(x => [x.id, new Set((x.sous_lieux || []).map(s => s.id))]));
  const parent = new Map(l.lieux.flatMap(x => (x.sous_lieux || []).map(s => [s.id, x.id])));
  return { lieux: new Set(sousDe.keys()), sous: new Set(parent.keys()), sousDe, parent };
}

function verifierLieu(id, ref, ou, p) {
  if (!ref || ref.lieux.has(id)) return;
  p.push(ref.sous.has(id) ? `${ou} : « ${id} » est un sous-lieu de « ${ref.parent.get(id)} » dans lieux.json, pas un lieu.` : `${ou} : lieu « ${id} » absent de lieux.json.`);
}

// Un sous-lieu cité avec son lieu (jalon, rencontre, PNJ) : il doit être l'un des sous-lieux de ce lieu dans lieux.json.
// memeIdPermis : pnj.json donne à un lieu sans sous-lieu un sous-lieu de même id que lui (formats/pnj.md).
function verifierSousLieu(sousLieu, lieu, ref, ou, p, memeIdPermis = false) {
  if (!ref || !ref.lieux.has(lieu)) return;
  const sls = ref.sousDe.get(lieu);
  if (sls.has(sousLieu) || (memeIdPermis && sousLieu === lieu && !sls.size)) return;
  const ailleurs = ref.parent.get(sousLieu);
  p.push(`${ou} : sous-lieu « ${sousLieu} » ${ailleurs ? `rangé sous « ${ailleurs} » dans lieux.json, pas sous « ${lieu} »` : `absent des sous-lieux de « ${lieu} » dans lieux.json`}.`);
}

// `etapes` d'un PNJ, d'une rencontre scénarisée ou d'un objet (facultatif, 2026-11-05) : les étapes où il se joue, quand
// plusieurs étapes partagent son lieu (rangeurEtapes de app/trame.js). Des id d'étapes du déroulé.
async function verifierEtapesDe(liste, nomDe, autre, p) {
  if (!liste.some(x => x?.etapes !== undefined)) return;
  const deroule = await autre('deroule-campagne');
  const connues = deroule?.etapes ? new Set(deroule.etapes.map(e => e.id)) : null;
  for (const x of liste) {
    if (x?.etapes === undefined) continue;
    if (!Array.isArray(x.etapes)) { p.push(`${nomDe(x)} : « etapes » doit être un tableau d'id d'étapes.`); continue; }
    if (connues) for (const id of x.etapes) if (!connues.has(id)) p.push(`${nomDe(x)} : étape « ${id} » absente de deroule-campagne.json.`);
  }
}

// ───── Par fichier ─────

function verifierLieux(d, p) {
  const types = d.types && typeof d.types === 'object' ? d.types : null;
  if (!types) p.push('« types » manquant : le libellé de chaque type de lieu.');
  const ids = idsUniques(exiger(d.lieux, 'lieux', p), 'lieux', p);
  const sous = new Set();
  for (const l of d.lieux || []) {
    if (!l.nom) p.push(`Lieu ${l.id} : « nom » manquant.`);
    if (types && !types[l.type]) p.push(`Lieu ${l.id} : type « ${l.type} » absent de « types ».`);
    if (l.situe_dans && (!ids.has(l.situe_dans) || l.situe_dans === l.id)) p.push(`Lieu ${l.id} : « situe_dans » vaut « ${l.situe_dans} », qui n'est pas un autre lieu du fichier.`);
    for (const s of l.sous_lieux || []) {
      if (!s.id || !s.nom) p.push(`Lieu ${l.id} : un sous-lieu n'a pas d'« id » ou de « nom ».`);
      else if (ids.has(s.id) || sous.has(s.id)) p.push(`Sous-lieu « ${s.id} » (dans ${l.id}) : cet id est déjà pris.`);
      sous.add(s.id);
    }
  }
}

const TYPES_JALONS = ['trajet', 'rencontre', 'evenement', 'amorce', 'halte'];

// deroule-campagne.json, format 2 (formats/deroule-campagne.md) : arcs, étapes indicatives, jalons et pistes, et leurs
// renvois vers lieux, temps-de-voyage, rencontres_scenarisees, pnj et personnages (etapes[].tarokka : le module Tarokka). Un fichier visé absent ne donne
// qu'un avertissement (une fois), pas une erreur par renvoi.
async function verifierDeroule(d, p, autre) {
  const ref = await referentiel(autre);
  const [voyage, rencontres, pnj, personnages] = await Promise.all(['temps-de-voyage', 'rencontres-aleatoires', 'pnj', 'personnages'].map(autre));
  const absents = new Set();
  const ensemble = (donnees, liste) => (donnees ? new Set((liste || []).map(x => x.id)) : null);
  const cibles = {
    trajet: [ensemble(voyage, voyage?.trajets), 'temps-de-voyage.json', 'trajet', 'absent'],
    rencontre: [ensemble(rencontres, rencontres?.rencontres_scenarisees), 'rencontres-aleatoires.json (rencontres_scenarisees)', 'rencontre', 'absente'],
    pnj: [ensemble(pnj, pnj?.pnj), 'pnj.json', 'PNJ', 'absent'],
    personnage: [ensemble(personnages, personnages?.personnages), 'personnages.json', 'personnage', 'absent'],
  };
  // Renvoi vers un autre fichier : erreur si l'id est inconnu, un seul avertissement si le fichier n'est pas chargé.
  function renvoi(genre, id, ou) {
    if (id === undefined || id === null) return;
    if (genre === 'lieu') { if (ref) verifierLieu(id, ref, ou, p); else absents.add('lieux.json'); return; }
    const [ids, fichier, quoi, absent] = cibles[genre];
    if (!ids) absents.add(fichier);
    else if (!ids.has(id)) p.push(`${ou} : ${quoi} « ${id} » ${absent} de ${fichier}.`);
  }
  const renvois = (genre, liste, ou) => (Array.isArray(liste) ? liste : []).forEach(id => renvoi(genre, id, ou));

  const arcs = idsUniques(exiger(d.arcs, 'arcs', p), 'arcs', p);
  const etapes = idsUniques(exiger(d.etapes, 'etapes', p), 'etapes', p);
  if (!Array.isArray(d.jalons)) p.push('« jalons » doit être un tableau (vide s\'il n\'y en a pas).');
  if (!Array.isArray(d.pistes)) p.push('« pistes » doit être un tableau (vide s\'il n\'y en a pas).');
  const listeJalons = Array.isArray(d.jalons) ? d.jalons : [];
  const listePistes = Array.isArray(d.pistes) ? d.pistes : [];
  const jalons = idsUniques(listeJalons, 'jalons', p);
  const pistes = idsUniques(listePistes, 'pistes', p);
  for (const id of jalons) if (pistes.has(id)) p.push(`« ${id} » est à la fois un jalon et une piste : un id n'appartient qu'à l'un des deux.`);
  if (!d.types_jalons || typeof d.types_jalons !== 'object') p.push(`« types_jalons » manquant : le libellé de chaque type de jalon (${TYPES_JALONS.join(', ')}).`);
  const types = { ...Object.fromEntries(TYPES_JALONS.map(t => [t, true])), ...(d.types_jalons || {}) };

  for (const a of d.arcs || []) {
    for (const e of a.etapes || []) if (!etapes.has(e)) p.push(`Arc ${a.id} : étape « ${e} » inconnue.`);
    renvois('lieu', a.lieux, `Arc ${a.id}`);
    if (typeof a.niveaux?.min !== 'number' || typeof a.niveaux?.max !== 'number') p.push(`Arc ${a.id} : « niveaux » doit être { min, max } en nombres.`);
  }

  // Étapes : ordre conseillé unique, fin (texte, jalons clés), pistes attendues.
  const ordres = new Set();
  for (const e of d.etapes || []) {
    const ou = `Étape ${e.id}`;
    if (!arcs.has(e.arc)) p.push(`${ou} : arc « ${e.arc} » inconnu.`);
    if (typeof e.ordre !== 'number') p.push(`${ou} : « ordre » doit être un nombre.`);
    else if (ordres.has(e.ordre)) p.push(`${ou} : ordre ${e.ordre} déjà pris.`);
    ordres.add(e.ordre);
    if (typeof e.niveau_groupe !== 'number') p.push(`${ou} : « niveau_groupe » doit être un nombre.`);
    if (!Array.isArray(e.lieux)) p.push(`${ou} : « lieux » manquant (tableau vide s'il n'y en a pas).`);
    // `sous_lieux` (facultatif, 2026-11-05) : les pièces de ses lieux où elle se joue, quand une autre étape partage le lieu.
    if (e.sous_lieux !== undefined) {
      if (!Array.isArray(e.sous_lieux)) p.push(`${ou} : « sous_lieux » doit être un tableau d'id de sous-lieux.`);
      else if (ref) for (const sl of e.sous_lieux) {
        const mere = ref.parent.get(sl);
        if (!mere) p.push(`${ou} : sous-lieu « ${sl} » absent de lieux.json.`);
        else if (!(e.lieux || []).includes(mere)) p.push(`${ou} : sous-lieu « ${sl} » rangé sous « ${mere} », qui n'est pas un lieu de l'étape.`);
      }
    }
    renvois('lieu', e.lieux, ou);
    if (typeof e.fin?.texte !== 'string' || !e.fin.texte.trim()) p.push(`${ou} : « fin.texte » manquant (ce qui marque la fin de l'étape).`);
    for (const id of e.fin?.jalons_cles || []) {
      if (!jalons.has(id)) p.push(`${ou} : jalon clé « ${id} » (fin.jalons_cles) ${pistes.has(id) ? 'est une piste, pas un jalon' : 'absent de « jalons »'}.`);
    }
    for (const pa of e.pistes_attendues || []) {
      if (!pistes.has(pa?.piste)) p.push(`${ou} : piste attendue « ${pa?.piste} » ${jalons.has(pa?.piste) ? 'est un jalon, pas une piste' : 'absente de « pistes »'}.`);
      if (typeof pa?.texte !== 'string' || !pa.texte.trim()) p.push(`${ou} : piste attendue « ${pa?.piste} » sans « texte ».`);
    }
  }

  // Jalons : étape qui les ouvre, lieu et sous-lieu, itinéraire, renvois.
  for (const j of listeJalons) {
    const ou = `Jalon ${j.id}`;
    if (!etapes.has(j.etape)) p.push(j.etape === undefined && j.apres !== undefined ? `${ou} : « apres » (format 1) au lieu de « etape ».` : `${ou} : « etape » vaut « ${j.etape} », qui n'est pas une étape.`);
    if (typeof j.rang !== 'number') p.push(`${ou} : « rang » doit être un nombre.`);
    if (!types[j.type]) p.push(`${ou} : type « ${j.type} » inconnu (attendu : ${TYPES_JALONS.join(', ')}).`);
    if (!j.nom || !j.description) p.push(`${ou} : « nom » et « description » sont obligatoires.`);
    renvoi('lieu', j.lieu, ou);
    if (j.sous_lieu !== undefined) {
      if (!j.lieu) p.push(`${ou} : « sous_lieu » sans « lieu ».`);
      else verifierSousLieu(j.sous_lieu, j.lieu, ref, ou, p);
    }
    renvois('lieu', [...(j.lieux || []), j.de, j.vers].filter(Boolean), ou);
    renvois('rencontre', j.rencontres, ou);
    renvois('pnj', j.pnj, ou);
    renvoi('personnage', j.personnage, ou);
    if (j.type === 'trajet' && !j.rencontres?.length) p.push(`Avertissement : ${ou} : trajet sans rencontre prévue. Un trajet simple n'est pas un jalon (il se prépare dans le widget Trajets) : à garder seulement s'il porte un événement.`);
    // Itinéraire : libre (sans trajets), un seul (trajets) ou plusieurs au choix (variantes) ; les trajets doivent se suivre.
    if (j.itineraire_libre && (j.trajets?.length || j.variantes?.length)) p.push(`${ou} : itinéraire libre, il ne doit avoir ni « trajets » ni « variantes ».`);
    if (j.trajets?.length && j.variantes?.length) p.push(`${ou} : « trajets » et « variantes » à la fois (un seul des deux).`);
    if (j.variantes !== undefined && !Array.isArray(j.variantes)) p.push(`${ou} : « variantes » doit être un tableau.`);
    const routes = [...(j.trajets?.length ? [{ de: j.de, ids: j.trajets, ou }] : []),
      ...(Array.isArray(j.variantes) ? j.variantes : []).map((v, i) => ({ de: v.de || j.de, ids: v.trajets, ou: `${ou}, variante ${v.nom || i + 1}`, v }))];
    for (const r of routes) {
      if (r.v) {
        if (!r.v.nom) p.push(`${r.ou} : « nom » manquant.`);
        renvoi('lieu', r.v.de, r.ou);
        if (!r.ids?.length) { p.push(`${r.ou} : « trajets » manquant ou vide.`); continue; }
      }
      renvois('trajet', r.ids, r.ou);
      if (!voyage) continue;
      const ts = r.ids.map(id => voyage.trajets?.find(t => t.id === id));
      if (ts.every(Boolean) && !enchainer(ts, r.de, j.vers)) {
        p.push(`${r.ou} : les trajets ne se suivent pas${r.de ? ` depuis « ${r.de} »` : ''}${j.vers ? ` jusqu'à « ${j.vers} »` : ''}. Plusieurs routes possibles : « variantes » ; route au choix des joueurs : « itineraire_libre ».`);
      }
    }
  }

  // Pistes : étape qui les ouvre, début et fin (jalons), manifestations (un renvoi au plus), renvois.
  for (const pi of listePistes) {
    const ou = `Piste ${pi.id}`;
    if (!etapes.has(pi.etape)) p.push(`${ou} : « etape » vaut « ${pi.etape} », qui n'est pas une étape.`);
    if (!pi.nom || !pi.description) p.push(`${ou} : « nom » et « description » sont obligatoires.`);
    for (const bout of ['debut', 'fin']) {
      const b = pi[bout];
      if (typeof b?.texte !== 'string' || !b.texte.trim()) p.push(`${ou} : « ${bout}.texte » manquant.`);
      if (b?.jalon !== undefined && !jalons.has(b.jalon)) p.push(`${ou} : « ${bout}.jalon » vaut « ${b.jalon} », ${pistes.has(b.jalon) ? 'qui est une piste, pas un jalon' : 'absent de « jalons »'}.`);
    }
    if (pi.manifestations !== undefined && !Array.isArray(pi.manifestations)) p.push(`${ou} : « manifestations » doit être un tableau.`);
    (Array.isArray(pi.manifestations) ? pi.manifestations : []).forEach((m, i) => {
      const om = `${ou}, manifestation ${i + 1}`;
      if (typeof m?.texte !== 'string' || !m.texte.trim()) p.push(`${om} : « texte » manquant.`);
      const champs = ['etape', 'jalon', 'lieu', 'trajet'].filter(c => m?.[c] !== undefined);
      if (champs.length > 1) p.push(`${om} : ${champs.length} renvois (${champs.join(', ')}), un seul au plus.`);
      // `id` facultatif (2026-11-05) : il suit la résurgence cochée « jouée » d'un export à l'autre ; unique dans la piste.
      if (m?.id !== undefined && pi.manifestations.some((x, k) => k < i && x?.id === m.id)) p.push(`${om} : id « ${m.id} » déjà pris par une autre manifestation de la piste.`);
      // « debut » et « fin » : réservés aux remarques du MJ sur le début et la fin de la piste.
      if (m?.id === 'debut' || m?.id === 'fin') p.push(`${om} : id « ${m.id} » réservé (le début et la fin de la piste).`);
      if (m?.etape !== undefined && !etapes.has(m.etape)) p.push(`${om} : étape « ${m.etape} » inconnue.`);
      if (m?.jalon !== undefined && !jalons.has(m.jalon)) p.push(`${om} : jalon « ${m.jalon} » absent de « jalons ».`);
      renvoi('lieu', m?.lieu, om);
      renvoi('trajet', m?.trajet, om);
    });
    renvois('lieu', pi.lieux, ou);
    renvois('pnj', pi.pnj, ou);
    renvois('rencontre', pi.rencontres, ou);
    renvoi('personnage', pi.personnage, ou);
  }
  for (const f of absents) p.push(`Avertissement : ${f} n'est pas chargé, les renvois vers ce fichier ne sont pas vérifiés.`);
}

// personnages.json, format 2 (formats/personnages.md). Un renvoi vers un fichier absent, une étape de quête dont le jalon
// ou la piste est introuvable, une page du wiki inconnue : avertissement seulement.
async function verifierPersonnages(d, p, autre) {
  idsUniques(exiger(d.personnages, 'personnages', p), 'personnages', p);
  const joueurs = new Set((d.personnages || []).filter(x => x.role === 'personnage').map(x => x.id));
  const deroule = await autre('deroule-campagne');
  const jalons = deroule ? new Set((deroule.jalons || []).map(j => j.id)) : null;
  const pistes = deroule ? new Set((deroule.pistes || []).map(x => x.id)) : null;
  const absents = new Set();
  for (const x of d.personnages || []) {
    if (!['personnage', 'compagnon'].includes(x.role)) p.push(`Personnage ${x.id} : « role » vaut « ${x.role} » (attendu : personnage ou compagnon).`);
    if (x.role === 'compagnon' && !joueurs.has(x.compagnon_de)) p.push(`Compagnon ${x.id} : « compagnon_de » vaut « ${x.compagnon_de} », qui n'est pas un personnage du fichier.`);
    if (!Array.isArray(x.secrets)) p.push(`Personnage ${x.id} : « secrets » manquant (tableau vide s'il n'y a rien).`);
    if (x.pistes !== undefined) p.push(`Avertissement : Personnage ${x.id} : « pistes » est retiré au format 2 (les pistes d'un personnage sont dans deroule-campagne.json, avec « personnage ») ; ignoré.`);
    // Secret qui se lit comme une suite d'étapes (quête personnelle) : numéros entiers uniques, un jalon ou une piste du déroulé.
    for (const sec of Array.isArray(x.secrets) ? x.secrets : []) {
      if (sec.etapes === undefined) continue;
      const ou = `Personnage ${x.id}, secret « ${sec.sujet} »`;
      if (!Array.isArray(sec.etapes)) { p.push(`${ou} : « etapes » doit être un tableau.`); continue; }
      const numeros = new Set();
      sec.etapes.forEach((e, i) => {
        const oe = Number.isInteger(e?.numero) ? `${ou}, étape ${e.numero}` : `${ou}, ${i + 1}${i ? 'e' : 're'} étape`;
        if (!Number.isInteger(e?.numero)) p.push(`${oe} : « numero » vaut « ${e?.numero} » (attendu : un entier).`);
        else if (numeros.has(e.numero)) p.push(`${ou} : numéro ${e.numero} en double.`);
        numeros.add(e?.numero);
        if (typeof e?.texte !== 'string' || !e.texte.trim()) p.push(`${oe} : « texte » manquant ou vide.`);
        if (e?.jalon !== undefined && e?.piste !== undefined) p.push(`${oe} : « jalon » et « piste » à la fois (un seul des deux).`);
        for (const [champ, ids, quoi] of [['jalon', jalons, 'jalon « %s » absent'], ['piste', pistes, 'piste « %s » absente']]) {
          if (e?.[champ] === undefined) continue;
          if (!ids) absents.add('deroule-campagne.json');
          else if (!ids.has(e[champ])) p.push(`Avertissement : ${oe} : ${quoi.replace('%s', e[champ])} de deroule-campagne.json (l'étape s'affiche sans lien).`);
        }
      });
    }
  }
  // Pages du wiki (wiki/wiki.json, écrit par l'import du wiki : il peut manquer).
  const wiki = await chargerWiki();
  if (wiki) for (const x of d.personnages || []) {
    const id = x.liens?.wiki?.id;
    if (id && !wiki.parId.has(id)) p.push(`Avertissement : Personnage ${x.id} : page du wiki « ${id} » absente de wiki/wiki.json.`);
  }
  const g = d.groupe;
  if (!g) p.push('« groupe » manquant.');
  else {
    const ref = await referentiel(autre);
    const lieuxCites = [g.lieu_actuel, ...(Array.isArray(g.lieux_visites) ? g.lieux_visites : [])].filter(Boolean);
    if (!Array.isArray(g.lieux_visites)) p.push('« groupe.lieux_visites » manquant (tableau vide s\'il n\'y en a pas).');
    if (lieuxCites.length && !ref) absents.add('lieux.json');
    if (g.lieu_actuel) verifierLieu(g.lieu_actuel, ref, 'groupe.lieu_actuel', p);
    (Array.isArray(g.lieux_visites) ? g.lieux_visites : []).forEach(id => verifierLieu(id, ref, 'groupe.lieux_visites', p));
    if (g.etape) {
      if (!deroule) absents.add('deroule-campagne.json');
      else if (!deroule.etapes?.some(e => e.id === g.etape)) p.push(`groupe.etape : « ${g.etape} » absente de deroule-campagne.json.`);
    }
    if (g.pnj_rencontres?.length) {
      const pnj = await autre('pnj');
      if (!pnj) absents.add('pnj.json');
      else for (const id of g.pnj_rencontres) if (!pnj.pnj?.some(x => x.id === id)) p.push(`groupe.pnj_rencontres : « ${id} » absent de pnj.json.`);
    }
  }
  for (const f of absents) p.push(`Avertissement : ${f} n'est pas chargé, les renvois vers ce fichier ne sont pas vérifiés.`);
}

// factions.json : référentiel des factions, cité par pnj.json et connaissances.json (formats/factions.md).
async function verifierFactions(d, p, autre) {
  const ref = await referentiel(autre);
  const types = d.types && typeof d.types === 'object' ? d.types : null;
  if (!types) p.push('« types » manquant : le libellé de chaque type de faction.');
  idsUniques(exiger(d.factions, 'factions', p), 'factions', p);
  for (const f of d.factions || []) {
    if (!f.nom || !f.description) p.push(`Faction ${f.id} : « nom » et « description » sont obligatoires.`);
    if (types && !types[f.type]) p.push(`Faction ${f.id} : type « ${f.type} » absent de « types ».`);
    if (!Array.isArray(f.lieux)) p.push(`Faction ${f.id} : « lieux » manquant (tableau vide s'il n'y a pas de lieu précis).`);
    (f.lieux || []).forEach(id => verifierLieu(id, ref, `Faction ${f.id}`, p));
  }
}

// Factions citées par un autre fichier : erreur si l'id est inconnu, un seul avertissement si factions.json manque.
async function verifierRenvoisFactions(liste, autre, p) {
  const citees = liste.filter(([, ids]) => ids?.length);
  if (!citees.length) return;
  const f = await autre('factions');
  if (!f?.factions) { p.push('Avertissement : factions.json n\'est pas chargé, les factions citées ne sont pas vérifiées.'); return; }
  const ids = new Set(f.factions.map(x => x.id));
  for (const [ou, fs] of citees) for (const id of fs) if (!ids.has(id)) p.push(`${ou} : faction « ${id} » absente de factions.json.`);
}
// babioles.json, format 2 : tables de petits objets à tirer (formats/babioles.md). Un fichier visé absent ne donne qu'un
// avertissement. Types de liens connus : TYPES_LIENS_BABIOLES ; chacun de ceux qui servent a un libellé dans `types_liens`.
export const TYPES_LIENS_BABIOLES = ['lieu', 'sous_lieu', 'pnj', 'faction', 'element_intrigue', 'personnage'];

async function verifierBabioles(d, p, autre) {
  const typesLiens = d.types_liens && typeof d.types_liens === 'object' ? d.types_liens : null;
  if (!typesLiens) p.push('« types_liens » manquant : le libellé de chaque type de lien.');
  const themes = d.themes && typeof d.themes === 'object' ? d.themes : null;
  if (!themes) p.push('« themes » manquant : le libellé de chaque thème.');

  const ref = await referentiel(autre);
  const pnj = await autre('pnj');
  const factions = await autre('factions');
  const personnages = await autre('personnages');
  const ensemble = (donnees, liste) => donnees ? new Set((liste || []).map(x => x.id)) : null;
  const idsPnj = ensemble(pnj, pnj?.pnj);
  const idsPersos = ensemble(personnages, personnages?.personnages);
  const absents = new Set();

  // Éléments d'une intrigue secrète (trois reliques à retrouver, par exemple) : facultatifs, cités par les liens.
  if (d.elements_intrigue !== undefined && !Array.isArray(d.elements_intrigue)) p.push('« elements_intrigue » doit être un tableau.');
  const elements = idsUniques(Array.isArray(d.elements_intrigue) ? d.elements_intrigue : [], 'elements_intrigue', p);
  for (const f of Array.isArray(d.elements_intrigue) ? d.elements_intrigue : []) {
    const ou = `Élément d'intrigue ${f.id}`;
    if (!f.nom) p.push(`${ou} : « nom » manquant.`);
    if (f.pnj) {
      if (!idsPnj) absents.add('pnj.json');
      else if (!idsPnj.has(f.pnj)) p.push(`${ou} : PNJ « ${f.pnj} » absent de pnj.json.`);
    }
    if (f.lieu) verifierLieu(f.lieu, ref, ou, p);
    if (f.sous_lieu && ref && !ref.sous.has(f.sous_lieu)) p.push(`${ou} : sous-lieu « ${f.sous_lieu} » absent de lieux.json.`);
  }

  // Fichier visé par chaque type de lien : ensemble d'id (null si le fichier n'est pas chargé).
  const cibles = {
    lieu: [ref?.lieux, 'lieux.json'],
    sous_lieu: [ref?.sous, 'lieux.json (sous_lieux)'],
    pnj: [idsPnj, 'pnj.json'],
    faction: [ensemble(factions, factions?.factions), 'factions.json'],
    element_intrigue: [elements, '« elements_intrigue »'],
    personnage: [idsPersos, 'personnages.json'],
  };

  idsUniques(exiger(d.tables, 'tables', p), 'tables', p);
  const idsLignes = new Set();
  for (const t of d.tables || []) {
    const faces = Number(String(t.de).match(DE)?.[1]);
    if (!faces) p.push(`Table ${t.id} : dé « ${t.de} » illisible (attendu : 1d100).`);
    const couvert = new Map();   // résultat -> jet de la ligne qui le couvre
    for (const l of exiger(t.lignes, `tables[${t.id}].lignes`, p)) {
      const ou = `Table ${t.id}, jet ${l.jet}`;
      if (!l.id) p.push(`${ou} : « id » manquant.`);
      else if (idsLignes.has(l.id)) p.push(`${ou} : « ${l.id} » en double dans le fichier.`);
      idsLignes.add(l.id);
      const max = l.jet_max ?? l.jet;
      if (!Number.isInteger(l.jet) || !Number.isInteger(max) || max < l.jet) p.push(`${ou} : « jet » et « jet_max » doivent être des entiers, « jet_max » au moins égal à « jet ».`);
      else if (faces) {
        if (l.jet < 1 || max > faces) p.push(`${ou} : hors des bornes du dé (1 à ${faces}).`);
        for (let n = l.jet; n <= max; n++) {
          if (couvert.has(n)) p.push(couvert.get(n) === l.jet ? `Table ${t.id} : jet ${l.jet} en double.` : `${ou} : le résultat ${n} est déjà couvert par la ligne du jet ${couvert.get(n)}.`);
          else couvert.set(n, l.jet);
        }
      }
      if (typeof l.texte !== 'string' || (!l.texte.trim() && !l.a_remplir)) p.push(`${ou} : « texte » manquant ou vide (une ligne vierge porte « a_remplir »).`);
      if (l.theme && themes && !themes[l.theme]) p.push(`${ou} : thème « ${l.theme} » absent de « themes ».`);
      if (l.personnage) {
        if (!idsPersos) absents.add('personnages.json');
        else if (!idsPersos.has(l.personnage)) p.push(`${ou} : personnage « ${l.personnage} » absent de personnages.json.`);
      }
      if (!Array.isArray(l.lore_links)) { p.push(`${ou} : « lore_links » manquant (tableau vide s'il n'y a rien).`); continue; }
      for (const lien of l.lore_links) {
        const cible = cibles[lien?.type];
        if (!cible || (typesLiens && !typesLiens[lien.type])) { p.push(`${ou} : type de lien « ${lien?.type} » inconnu.`); continue; }
        const [ids, fichier] = cible;
        if (!ids) absents.add(fichier);
        else if (!ids.has(lien.id)) p.push(`${ou} : ${typesLiens?.[lien.type] || lien.type} « ${lien.id} » absent de ${fichier}.`);
      }
    }
  }
  for (const f of absents) p.push(`Avertissement : ${f} n'est pas chargé, les renvois vers ce fichier ne sont pas vérifiés.`);
}

const VALEURS_SAVOIR = ['oui', 'non', 'partiel'];

// connaissances.json, format 2 : les intrigues secrètes (qui sait quoi, grille groupes × sujets) et le savoir commun.
async function verifierConnaissances(d, p, autre) {
  if (!Array.isArray(d.intrigues)) p.push('« intrigues » doit être un tableau (vide s\'il n\'y en a pas).');
  idsUniques(Array.isArray(d.intrigues) ? d.intrigues : [], 'intrigues', p);
  for (const f of Array.isArray(d.intrigues) ? d.intrigues : []) {
    const ou = `Intrigue ${f.id}`;
    if (!f.nom) p.push(`${ou} : « nom » manquant.`);
    const sujets = idsUniques(exiger(f.sujets, `${ou} : sujets`, p), `${ou} : sujets`, p);
    for (const s of f.sujets || []) for (const k of ['court', 'icone']) if (s[k] !== undefined && typeof s[k] !== 'string') p.push(`${ou}, sujet ${s.id} : « ${k} » doit être un texte.`);
    idsUniques(exiger(f.groupes, `${ou} : groupes`, p), `${ou} : groupes`, p);
    for (const g of f.groupes || []) {
      for (const s of sujets) if (!VALEURS_SAVOIR.includes(g.sait?.[s])) p.push(`${ou}, groupe ${g.id} : « sait.${s} » vaut « ${g.sait?.[s]} » (attendu : oui, non ou partiel).`);
      for (const s of Object.keys(g.sait || {})) if (!sujets.has(s)) p.push(`${ou}, groupe ${g.id} : sujet « ${s} » inconnu.`);
      for (const s of Object.keys(g.ajustements || {})) if (!sujets.has(s)) p.push(`${ou}, groupe ${g.id} : ajustement sur un sujet inconnu « ${s} ».`);
      if (g.factions !== undefined && !Array.isArray(g.factions)) p.push(`${ou}, groupe ${g.id} : « factions » doit être un tableau.`);
      if (g.court !== undefined && typeof g.court !== 'string') p.push(`${ou}, groupe ${g.id} : « court » doit être un texte.`);
    }
    await verifierRenvoisFactions((f.groupes || []).filter(g => Array.isArray(g.factions)).map(g => [`${ou}, groupe ${g.id}`, g.factions]), autre, p);
  }
  const sc = d.savoir_commun;
  if (!sc && !d.intrigues?.length) p.push('Ni « intrigues » ni « savoir_commun » : le fichier ne dit rien.');
  if (sc) {
    const themes = idsUniques(exiger(sc.themes, 'savoir_commun.themes', p), 'themes', p);
    exiger(sc.elements, 'savoir_commun.elements', p).forEach((e, i) => {
      if (!themes.has(e.theme)) p.push(`Élément ${i + 1} du savoir commun : thème « ${e.theme} » inconnu.`);
      if (!e.texte) p.push(`Élément ${i + 1} du savoir commun : « texte » manquant.`);
    });
  }
}

function verifierNoms(d, p) {
  exiger(d.prenoms?.masculins, 'prenoms.masculins', p, true);
  exiger(d.prenoms?.feminins, 'prenoms.feminins', p, true);
  exiger(d.familles, 'familles', p).forEach((f, i) => {
    if (!f?.masculin || !f?.feminin) p.push(`familles[${i}] : il faut les deux formes, « masculin » et « feminin ».`);
  });
}

const DE = /^\s*\d*d(\d+)\s*$/i;
const QUANTITE = /^\s*[+-]?\s*(\d+d\d+|\d+)(\s*[+-]\s*(\d+d\d+|\d+))*\s*$/i;

async function verifierOccupants(d, p, autre) {
  const ref = await referentiel(autre);
  idsUniques(exiger(d.tables, 'tables', p), 'tables', p);
  for (const t of d.tables || []) {
    if (!t.lieu?.id) p.push(`Table ${t.id} : « lieu.id » manquant.`);
    else verifierLieu(t.lieu.id, ref, `Table ${t.id}`, p);
    const faces = Number(String(t.de).match(DE)?.[1]);
    if (!faces) { p.push(`Table ${t.id} : dé « ${t.de} » illisible (attendu : 1d20).`); continue; }
    const couvert = new Array(faces + 1).fill(0);
    for (const l of exiger(t.lignes, `tables[${t.id}].lignes`, p)) {
      const [a, b] = String(l.jet).split('-').map(Number);
      if (!a || (b !== undefined && !b)) { p.push(`Table ${t.id} : jet « ${l.jet} » illisible.`); continue; }
      for (let n = a; n <= (b || a); n++) if (n <= faces) couvert[n]++;
      for (const c of l.creatures || []) {
        if (!QUANTITE.test(String(c.quantite))) p.push(`Table ${t.id}, jet ${l.jet} : quantité « ${c.quantite} » illisible.`);
        for (const k of ['nom_en', 'note_mj']) if (c[k] !== undefined && typeof c[k] !== 'string') p.push(`Table ${t.id}, jet ${l.jet}, ${c.nom} : « ${k} » doit être un texte.`);
      }
      if (l.comment_jouer !== undefined && typeof l.comment_jouer !== 'string') p.push(`Table ${t.id}, jet ${l.jet} : « comment_jouer » doit être un texte.`);
    }
    const trous = couvert.map((n, i) => i && n === 0 ? i : null).filter(Boolean);
    const doubles = couvert.map((n, i) => n > 1 ? i : null).filter(Boolean);
    if (trous.length) p.push(`Table ${t.id} : aucun résultat pour ${trous.join(', ')}.`);
    if (doubles.length) p.push(`Table ${t.id} : plusieurs lignes pour ${doubles.join(', ')}.`);
  }
}

function verifierFaune(d, p) {
  idsUniques(exiger(d.milieux, 'milieux', p), 'milieux', p);
  for (const m of d.milieux || []) {
    for (const c of ['predateurs', 'gibier', 'oiseaux', 'autres']) {
      if (!Array.isArray(m[c])) p.push(`Milieu ${m.id} : « ${c} » manquant (tableau vide s'il n'y a rien).`);
    }
    if (!['predateurs', 'gibier', 'oiseaux'].some(c => m[c]?.length)) p.push(`Milieu ${m.id} : ni prédateur, ni gibier, ni oiseau.`);
  }
}

async function verifierTrajets(d, p, autre) {
  // Les lieux d'un trajet doivent exister dans lieux.json ; temps-de-voyage.lieux est facultatif (ancien format).
  const ref = await referentiel(autre);
  const locaux = new Set((d.lieux || []).map(l => typeof l === 'string' ? l : l.id));
  const connu = id => ref ? ref.lieux.has(id) : locaux.has(id);
  for (const t of exiger(d.trajets, 'trajets', p)) {
    for (const bout of ['de', 'vers']) if (!connu(t[bout])) p.push(`Trajet ${t.id} : lieu « ${t[bout]} » absent de ${ref ? 'lieux.json' : '« lieux »'}.`);
    if (typeof t.miles !== 'number') p.push(`Trajet ${t.id} : « miles » doit être un nombre.`);
    if (typeof t.terrain_difficile !== 'boolean') p.push(`Trajet ${t.id} : « terrain_difficile » doit valoir true ou false.`);
  }
  exiger(d.regles, 'regles', p).forEach((r, i) => { if (!r?.texte) p.push(`regles[${i}] : « texte » manquant.`); });
}

const ETATS_PNJ = ['vivant', 'mort', 'mort-vivant', 'disparu', 'absent'];
const RANGS_PNJ = ['vip', 'majeur', 'mineur'];

async function verifierPnj(d, p, autre) {
  const ref = await referentiel(autre);
  await verifierEtapesDe(d.pnj || [], x => `PNJ ${x.id}`, autre, p);
  const lieux = new Map(exiger(d.lieux, 'lieux', p).map(l => [l.id, l]));
  idsUniques(d.lieux, 'lieux', p);
  const sousLieux = new Set();
  for (const l of d.lieux || []) {
    idsUniques(exiger(l.sous_lieux, `lieux[${l.id}].sous_lieux`, p), `lieux[${l.id}].sous_lieux`, p).forEach(id => sousLieux.add(id));
  }
  const ids = idsUniques(exiger(d.pnj, 'pnj', p), 'pnj', p);
  for (const l of d.lieux || []) for (const id of l.pnj || []) if (!ids.has(id)) p.push(`lieux[${l.id}].pnj cite « ${id} », absent de « pnj ».`);
  for (const x of d.pnj || []) {
    const l = lieux.get(x.lieu);
    if (!l) { p.push(`PNJ ${x.id} : lieu « ${x.lieu} » inconnu.`); continue; }
    if (!(l.sous_lieux || []).some(sl => sl.id === x.sous_lieu)) p.push(`PNJ ${x.id} : sous-lieu « ${x.sous_lieu} » absent de ${l.id}.`);
    if (!(l.pnj || []).includes(x.id)) p.push(`PNJ ${x.id} : absent de lieux[${l.id}].pnj.`);
    verifierLieu(x.lieu, ref, `PNJ ${x.id}`, p);
    // lieux.json est le référentiel des sous-lieux : celui du PNJ doit y être un sous-lieu de son lieu.
    if (x.sous_lieu) verifierSousLieu(x.sous_lieu, x.lieu, ref, `PNJ ${x.id}`, p, true);
    // « aussi » : tout lieu ou sous-lieu de lieux.json (décision du MJ), ou à défaut de pnj.lieux.
    for (const a of x.aussi || []) {
      const connu = ref ? (ref.lieux.has(a) || ref.sous.has(a)) : (lieux.has(a) || sousLieux.has(a));
      if (!connu) p.push(`PNJ ${x.id} : « aussi » cite « ${a} », ni lieu ni sous-lieu de ${ref ? 'lieux.json' : 'pnj.lieux'}.`);
    }
    if (!ETATS_PNJ.includes(x.etat)) p.push(`PNJ ${x.id} : « etat » vaut « ${x.etat} » (attendu : ${ETATS_PNJ.join(', ')}).`);
    if (typeof x.important !== 'boolean') p.push(`PNJ ${x.id} : « important » doit valoir true ou false.`);
    if (x.rang !== undefined && !RANGS_PNJ.includes(x.rang)) p.push(`PNJ ${x.id} : « rang » vaut « ${x.rang} » (attendu : ${RANGS_PNJ.join(', ')}).`);
    if (x.factions !== undefined && !Array.isArray(x.factions)) p.push(`PNJ ${x.id} : « factions » doit être un tableau.`);
    // Ce qu'il sait des intrigues secrètes (format 2) : { "<id d'intrigue>": "ce qu'il sait ou peut transmettre" }.
    if (x.savoirs !== undefined && (!x.savoirs || typeof x.savoirs !== 'object' || Array.isArray(x.savoirs)
      || Object.values(x.savoirs).some(t => typeof t !== 'string' || !t.trim()))) p.push(`PNJ ${x.id} : « savoirs » doit être { "<id d'intrigue>": "ce qu'il sait" }, des textes non vides.`);
  }
  await verifierRenvoisFactions((d.pnj || []).filter(x => Array.isArray(x.factions)).map(x => [`PNJ ${x.id}`, x.factions]), autre, p);
}

async function verifierMarchands(d, p, autre) {
  const ref = await referentiel(autre);
  for (const m of ['pc', 'pa', 'po']) if (typeof d.monnaies?.[m] !== 'number') p.push(`« monnaies.${m} » manquant ou non numérique.`);
  idsUniques(exiger(d.marchands, 'marchands', p), 'marchands', p);
  for (const m of d.marchands || []) {
    if (!m.lieu) p.push(`Marchand ${m.id} : « lieu » manquant.`);
    else verifierLieu(m.lieu, ref, `Marchand ${m.id}`, p);
    // Un marchand qui est un sous-lieu en porte l'id (formats/marchands.md) : ce sous-lieu doit être de son lieu.
    if (m.lieu && ref?.sous.has(m.id)) verifierSousLieu(m.id, m.lieu, ref, `Marchand ${m.id}`, p);
    if (!Array.isArray(m.articles)) p.push(`Marchand ${m.id} : « articles » manquant (tableau vide s'il n'y a pas de liste).`);
    else if (!m.articles.length && !m.regle_de_prix) p.push(`Marchand ${m.id} : ni articles ni « regle_de_prix ».`);
    if (!Array.isArray(m.tenanciers)) p.push(`Marchand ${m.id} : « tenanciers » manquant (tableau vide s'il n'y a personne).`);
    (m.articles || []).forEach((a, i) => {
      if (!a.nom || !a.prix) p.push(`Marchand ${m.id}, article ${i + 1} : « nom » et « prix » sont obligatoires.`);
      if ('prix_pc' in a && typeof a.prix_pc !== 'number') p.push(`Marchand ${m.id}, ${a.nom} : « prix_pc » doit être un nombre.`);
    });
  }
}

async function verifierRencontres(d, p, autre) {
  const ids = new Set((d.rencontres || []).map(r => r.id));
  const ref = await referentiel(autre);
  await verifierEtapesDe(d.rencontres_scenarisees || [], x => `Rencontre scénarisée ${x.id}`, autre, p);
  idsUniques(d.rencontres_scenarisees, 'rencontres_scenarisees', p);
  // Rencontre de trajet (de, vers) : sur le jalon de ce trajet dans le déroulé ; sur place (lieu, sous_lieu) : au lieu même.
  const deroule = (d.rencontres_scenarisees || []).some(r => r.vers) ? await autre('deroule-campagne') : null;
  const citees = new Set((deroule?.jalons || []).filter(j => j.type === 'trajet').flatMap(j => j.rencontres || []));
  let sansDeroule = false;
  const pnjCites = (d.rencontres_scenarisees || []).some(r => [...(r.creatures || []), ...(r.si || []).flatMap(x => x.creatures || [])].some(c => c.pnj)) ? await autre('pnj') : null;
  const idsPnj = pnjCites?.pnj ? new Set(pnjCites.pnj.map(x => x.id)) : null;
  for (const r of d.rencontres_scenarisees || []) {
    const ou = `Rencontre scénarisée ${r.id}`;
    if (idsPnj) for (const c of [...(r.creatures || []), ...(r.si || []).flatMap(x => x.creatures || [])]) for (const id of [c.pnj || []].flat()) if (!idsPnj.has(id)) p.push(`${ou} : créature « ${c.nom} » : PNJ « ${id} » absent de pnj.json.`);
    for (const champ of ['de', 'vers', 'lieu']) if (r[champ]) verifierLieu(r[champ], ref, `${ou} (${champ})`, p);
    if (r.sous_lieu !== undefined) {
      if (!r.lieu) p.push(`${ou} : « sous_lieu » sans « lieu ».`);
      else verifierSousLieu(r.sous_lieu, r.lieu, ref, ou, p);
    }
    if (r.vers && !deroule) sansDeroule = true;
    else if (r.vers && !citees.has(r.id)) p.push(`Avertissement : ${ou} : rencontre de trajet (« vers ») qu'aucun jalon de trajet du déroulé ne cite.`);
  }
  if (sansDeroule) p.push('Avertissement : deroule-campagne.json n\'est pas chargé, les rencontres de trajet ne sont pas comparées aux jalons.');
  if (!d.procedure) p.push('« procedure » manquant.');
  else verifierEcarts(d.procedure.ecarts, 'procedure', p);
  // Modificateurs de la procédure (format 3 ; par exemple un guide qui connaît les sentiers) : une case du contexte qui change le tirage
  // dans certains terrains (`tirage`) et peut neutraliser des rencontres (`neutralise_par` d'une fiche).
  const mods = d.procedure?.modificateurs;
  if (mods !== undefined && !Array.isArray(mods)) p.push('« procedure.modificateurs » doit être un tableau.');
  const idsMods = idsUniques(Array.isArray(mods) ? mods : [], 'procedure.modificateurs', p);
  for (const m of Array.isArray(mods) ? mods : []) {
    const ou = `Modificateur ${m.id}`;
    if (!m.nom || !m.regle) p.push(`${ou} : « nom » et « regle » sont obligatoires.`);
    if (m.tirage !== undefined && !bornesDe(m.tirage)) p.push(`${ou} : « tirage » illisible (« ${m.tirage} »).`);
    if (m.terrains !== undefined && !Array.isArray(m.terrains)) p.push(`${ou} : « terrains » doit être un tableau.`);
  }
  for (const r of d.rencontres || []) for (const id of r.neutralise_par || []) if (!idsMods.has(id)) p.push(`Rencontre ${r.id} : « neutralise_par » cite « ${id} », absent de procedure.modificateurs.`);
  if (!Array.isArray(d.tables) || !d.tables.length) p.push('« tables » manquant ou vide.');
  idsUniques(d.tables, 'tables', p);
  const tables = new Map((d.tables || []).map(t => [t.id, t]));
  for (const moment of ['jour', 'nuit']) {
    const id = d.procedure?.tirage?.tables?.[moment];
    if (!tables.has(id)) p.push(`procedure.tirage.tables.${moment} : table « ${id} » absente de « tables ».`);
    else if (tables.get(id).role !== 'principale') p.push(`procedure.tirage.tables.${moment} : « ${id} » n'est pas une table de rôle « principale ».`);
  }
  // Sous-tables : appelées par options[].table (jamais une table principale ni elle-même), sans boucle.
  const appels = new Map();   // table -> sous-tables qu'elle appelle
  const externes = new Map();   // jeu -> [{ table, ou }]
  for (const t of d.tables || []) {
    if (!['principale', 'sous-table'].includes(t.role)) p.push(`Table ${t.id} : rôle « ${t.role} » inconnu (« principale » ou « sous-table »).`);
    const bornes = bornesDe(t.de);
    if (!bornes) p.push(`Table ${t.id} : dé « ${t.de} » illisible.`);
    verifierEcarts(t.ecarts, `Table ${t.id}`, p);
    appels.set(t.id, new Set());
    const couvert = new Map();   // résultat -> jet de la ligne qui le couvre
    for (const l of exiger(t.lignes, `tables[${t.id}].lignes`, p)) {
      const ou = `${t.id}, jet ${l.jet}`;
      const max = l.jet_max ?? l.jet;
      if (!Number.isInteger(l.jet) || !Number.isInteger(max) || max < l.jet) p.push(`${ou} : « jet » et « jet_max » doivent être des entiers, « jet_max » au moins égal à « jet ».`);
      else {
        if (bornes && (l.jet < bornes[0] || max > bornes[1])) p.push(`${ou} : hors des bornes du dé (${bornes[0]} à ${bornes[1]}).`);
        for (let n = l.jet; n <= max; n++) {
          if (couvert.has(n)) p.push(couvert.get(n) === l.jet ? `Table ${t.id} : jet ${l.jet} en double.` : `${ou} : le résultat ${n} est déjà couvert par la ligne du jet ${couvert.get(n)}.`);
          else couvert.set(n, l.jet);
        }
      }
      for (const o of exiger(l.options, `${ou} (options)`, p)) {
        if (!o.rencontre === !o.table) p.push(`${ou} : une option porte exactement un de « rencontre » ou « table » (ici ${o.rencontre ? 'les deux' : 'aucun'}).`);
        if (o.rencontre && !ids.has(o.rencontre)) p.push(`${ou} : la rencontre « ${o.rencontre} » n'existe pas dans « rencontres ».`);
        if (o.table) {
          const st = tables.get(o.table);
          if (!st) p.push(`${ou} : la sous-table « ${o.table} » n'existe pas dans « tables ».`);
          else if (st.role !== 'sous-table') p.push(`${ou} : « ${o.table} » n'est pas une table de rôle « sous-table ».`);
          else if (o.table === t.id) p.push(`${ou} : la sous-table s'appelle elle-même.`);
          else appels.get(t.id).add(o.table);
          if (o.creatures?.length) p.push(`Avertissement : ${ou} : renvoi à « ${o.table} » avec des « creatures » (ce sont celles de la sous-table qui comptent).`);
        }
        if (!Array.isArray(o.creatures)) p.push(`${ou} : « creatures » manquant (tableau vide s'il n'y a rien).`);
        if (o.tirage_externe) {
          const { jeu, table } = o.tirage_externe;
          if (!jeu || !table) p.push(`${ou} : « tirage_externe » demande « jeu » et « table ».`);
          else externes.set(jeu, [...(externes.get(jeu) || []), { table, ou }]);
          if (!o.rencontre) p.push(`${ou} : « tirage_externe » va avec « rencontre ».`);
        }
      }
    }
  }
  // Boucle : une sous-table qui finit par se rappeler elle-même.
  const vu = new Map();   // table -> 1 en cours, 2 vue
  const boucles = new Set();
  const visiter = (id, chemin) => {
    if (vu.get(id) === 2) return;
    if (vu.get(id) === 1) { boucles.add([...chemin.slice(chemin.indexOf(id)), id].join(' → ')); return; }
    vu.set(id, 1);
    for (const s of appels.get(id) || []) visiter(s, [...chemin, id]);
    vu.set(id, 2);
  };
  for (const id of appels.keys()) visiter(id, []);
  for (const b of boucles) p.push(`Sous-tables en boucle : ${b}.`);
  const appelees = new Set([...appels.values()].flatMap(s => [...s]));
  for (const t of d.tables || []) if (t.role === 'sous-table' && !appelees.has(t.id)) p.push(`Avertissement : sous-table « ${t.id} » qu'aucune ligne n'appelle.`);
  // Tirage dans un autre fichier de data/ : une table de lignes à jet / jet_max.
  for (const [jeu, renvois] of externes) {
    const x = await autre(jeu);
    if (!x) { p.push(`Avertissement : ${jeu}.json n'est pas chargé, les tirages externes vers ce fichier ne sont pas vérifiés.`); continue; }
    const ext = new Map((x.tables || []).map(t => [t.id, t]));
    for (const { table, ou } of renvois) {
      if (!ext.has(table)) p.push(`${ou} : « tirage_externe » : table « ${table} » absente de ${jeu}.json.`);
      else if (!Array.isArray(ext.get(table).lignes) || !bornesDe(ext.get(table).de)) p.push(`${ou} : « tirage_externe » : la table « ${table} » de ${jeu}.json n'a pas de « lignes » ou de dé lisible.`);
    }
  }
  for (const r of d.rencontres || []) verifierEcarts(r.ecarts, r.id, p);
}

// Calendrier de la campagne (formats/calendrier.md) : structure, renvois aux mois et aux jours, puis les `exemples` recalculés.
function verifierCalendrier(d, p) {
  const avant = p.length;
  const semaine = idsUniques(exiger(d.semaine, 'semaine', p), 'semaine', p);
  if (d.annee?.jours !== 365) p.push(`« annee.jours » : ${d.annee?.jours ?? 'absent'}. Tous les calendriers ont 365 jours (années égales, sans jour bissextile), comme les météos réelles : réduisez des mois, ou faites d'un jour en trop un jour marqué (formats/calendrier.md).`);
  const mois = new Map(exiger(d.mois, 'mois', p).map(m => [m.id, m]));
  idsUniques(d.mois, 'mois', p);
  for (const m of d.mois || []) if (!(Number.isInteger(m.jours) && m.jours >= 1)) p.push(`Mois ${m.id} : « jours » doit être un nombre entier, 1 ou plus.`);
  if (d.lune?.cycle) {
    if (!(d.lune.cycle.jours > 1)) p.push('« lune.cycle.jours » : la durée d\'une lunaison en jours (29.53 sur Terre).');
    if (!d.lune.cycle.pleine) p.push('« lune.cycle.pleine » manquant : une date de pleine lune { annee, mois, jour }.');
  }
  const total = (d.mois || []).reduce((a, m) => a + (m.jours || 0), 0);
  if (total !== d.annee?.jours) p.push(`Les mois comptent ${total} jours, « annee.jours » en annonce ${d.annee?.jours}.`);
  const date = (x, ou) => {
    const m = mois.get(x?.mois);
    if (!m) p.push(`${ou} : mois « ${x?.mois} » absent de « mois ».`);
    else if (!(Number.isInteger(x.jour) && x.jour >= 1 && x.jour <= m.jours)) p.push(`${ou} : le ${x.jour} ${m.nom} n'existe pas (${m.jours} jours).`);
  };
  // La date du jour 1 : celle du manifeste d'abord (fenêtre Campagne), sinon celle du fichier, facultative.
  if (d.debut_campagne) date(d.debut_campagne, 'debut_campagne');
  for (const s of d.saisons || []) date(s.debut, `Saison ${s.id}`);
  if (d.lune?.cycle?.pleine) date(d.lune.cycle.pleine, 'lune.cycle.pleine');
  const types = d.types_jours_marques || {};
  for (const jm of d.jours_marques || []) {
    date(jm, `Jour marqué ${jm.id}`);
    if (!types[jm.type]) p.push(`Jour marqué ${jm.id} : type « ${jm.type} » absent de « types_jours_marques ».`);
  }
  for (const [ou, j] of [['annee.premier_jour', d.annee?.premier_jour?.jour_semaine], ['debut_campagne', d.debut_campagne?.jour_semaine]]) {
    if (j !== undefined || ou === 'annee.premier_jour') if (!semaine.has(j)) p.push(`${ou} : jour de la semaine « ${j} » absent de « semaine ».`);
  }
  if (p.length > avant || !d.debut_campagne) return;   // les calculs supposent une structure saine, et une date de départ
  for (const x of d.exemples || []) {
    const c = dateDuJour(d, x.jour_campagne);
    const attendu = `${x.jour_semaine} ${x.jour} ${x.mois} ${x.annee}`, calcule = `${c.semaine.id} ${c.jour} ${c.mois.id} ${c.annee}`;
    if (attendu !== calcule) p.push(`Exemple du jour de campagne ${x.jour_campagne} : le fichier dit ${attendu}, le calcul donne ${calcule}.`);
  }
  // Textes courts (l'Horloge les montre en infobulle et en tête de la fenêtre du jour) : vérifiés dès que `resume` existe.
  for (const j of d.semaine) {
    if (!j.resume) continue;
    if (j.resume.length > 120) p.push(`Jour ${j.id} : « resume » fait ${j.resume.length} caractères (100 attendus, 120 au plus).`);
    if (j.sens?.length > 400) p.push(`Jour ${j.id} : « sens » fait ${j.sens.length} caractères (350 attendus, 400 au plus) ; les secrets vont dans « secret_mj ».`);
  }
  // Champs « pour contrôle » des jours marqués (jour de la semaine en 735, premier jour de campagne, numéro d'anniversaire).
  for (const jm of d.jours_marques || []) {
    const occ = jm.premier_jour_campagne ? joursMarques(d, jm.premier_jour_campagne).find(x => x.jm === jm) : null;
    if (occ && occ.dans !== 0) p.push(`Jour marqué ${jm.id} : « premier_jour_campagne » ${jm.premier_jour_campagne} ne tombe pas le ${jm.jour} ${mois.get(jm.mois).nom}.`);
    if (occ && jm.anniversaire_numero && occ.numero !== jm.anniversaire_numero) p.push(`Jour marqué ${jm.id} : anniversaire n° ${occ.numero} au calcul, ${jm.anniversaire_numero} dans le fichier.`);
    if (jm.jour_semaine_735) {
      const r = rangDate(d, { annee: 735, mois: jm.mois, jour: jm.jour });
      const j = dateDuJour(d, r - rangDate(d, d.debut_campagne) + d.debut_campagne.jour_campagne).semaine.id;
      if (j !== jm.jour_semaine_735) p.push(`Jour marqué ${jm.id} : ${j} en 735 au calcul, « ${jm.jour_semaine_735} » dans le fichier.`);
    }
  }
}

// Événements de campagne (formats/evenements.md) : le bouton du widget Rencontres. Une piste citée doit exister dans le déroulé.
async function verifierEvenements(d, p, autre) {
  idsUniques(exiger(d.evenements, 'evenements', p), 'evenements', p);
  const deroule = await autre('deroule-campagne');
  for (const ev of d.evenements || []) {
    if (!ev.nom) p.push(`Événement ${ev.id} : « nom » manquant.`);
    if (ev.court && ev.court.length > 16) p.push(`Avertissement : Événement ${ev.id} : « court » fait ${ev.court.length} caractères (le libellé du bouton : 16 au plus).`);
    for (const x of ev.sections || []) if (!x.titre || !(x.texte || x.points?.length)) p.push(`Événement ${ev.id} : une section sans « titre », ou sans « texte » ni « points ».`);
    if (ev.piste && deroule && !(deroule.pistes || []).some(x => x.id === ev.piste)) p.push(`Avertissement : Événement ${ev.id} : piste « ${ev.piste} » absente de deroule-campagne.json.`);
  }
}

// Jours marqués propres à la campagne (formats/jours-marques.md : anniversaires, fêtes locales), ajoutés au calendrier choisi.
// Les mois et jours ne se vérifient pas ici : le calendrier vient du manifeste (un jour hors calendrier ne s'affiche pas).
// agenda.json, format 1 (formats/agenda.md) : des entrées datées, par leur date au calendrier ou leur jour de campagne.
function verifierAgenda(d, p) {
  // Vide, c'est permis (formats/agenda.md : « vide s'il n'y en a pas ») : l'agenda n'a alors que ce que le MJ y écrit.
  if (!Array.isArray(d.entrees)) p.push('« entrees » doit être un tableau (vide s\'il n\'y en a pas).');
  const l = Array.isArray(d.entrees) ? d.entrees : [];
  idsUniques(l, 'entrees', p);
  for (const e of l) {
    const ou = `Entrée ${e.id}`;
    if (String(e.id || '').startsWith('mj-')) p.push(`${ou} : un « id » en « mj- » est réservé aux entrées du MJ.`);
    if (!e.nom) p.push(`${ou} : « nom » manquant.`);
    const date = e.date && Number.isInteger(e.date.annee) && Number.isInteger(e.date.jour) && typeof e.date.mois === 'string';
    if (!date && !Number.isInteger(e.jour_campagne)) p.push(`${ou} : il faut une « date » { annee, mois, jour } ou un « jour_campagne » entier.`);
    if (e.alertes !== undefined && (typeof e.alertes !== 'object' || (e.alertes.avant !== undefined && !(Array.isArray(e.alertes.avant) && e.alertes.avant.every(n => Number.isInteger(n) && n > 0)))))
      p.push(`${ou} : « alertes » vaut { jour_meme: vrai ou faux, avant: [des nombres de jours, entiers et positifs] }.`);
  }
}

function verifierJoursMarques(d, p) {
  const types = d.types_jours_marques || {};
  idsUniques(exiger(d.jours_marques, 'jours_marques', p), 'jours_marques', p);
  for (const jm of d.jours_marques || []) {
    if (!jm.nom || !jm.mois || !Number.isInteger(jm.jour)) p.push(`Jour marqué ${jm.id} : « nom », « mois » et « jour » sont obligatoires.`);
    if (!types[jm.type] && !['equinoxe', 'solstice', 'special', 'fete'].includes(jm.type)) p.push(`Jour marqué ${jm.id} : type « ${jm.type} » absent de « types_jours_marques ».`);
  }
}

// Météo jour par jour (formats/meteo.md) : dates du calendrier, jours de campagne, quatre créneaux, ciels et précipitations connus.
// Un relevé réel (`type` : `releve`) n'est daté que par ses dates réelles : le gestionnaire le pose sur la campagne.
async function verifierMeteo(d, p, autre) {
  const releve = d.type === 'releve';
  if (d.type && !releve && d.type !== 'campagne') p.push(`« type » : « ${d.type} » inconnu (releve, ou campagne par défaut).`);
  const cal = releve ? null : await autre('calendrier');
  const ordre = exiger(d.creneaux, 'creneaux', p).map(c => c.id);
  const ciels = d.types_ciel || {}, precip = d.types_precipitation || {};
  if (!d.types_ciel) p.push('« types_ciel » manquant.');
  if (!d.types_precipitation) p.push('« types_precipitation » manquant.');
  const debut = cal?.debut_campagne && cal.mois?.length && cal.annee ? rangDate(cal, cal.debut_campagne) : null;
  for (const j of exiger(d.jours, 'jours', p)) {
    const ou = releve ? `Jour ${j.date_reelle}` : `Jour ${j.jour} ${j.mois} ${j.annee}`;
    if (releve && !/^\d{4}-\d{2}-\d{2}$/.test(j.date_reelle || '')) p.push(`${ou} : « date_reelle » (AAAA-MM-JJ) manquante.`);
    if (debut !== null) {
      const m = cal.mois.find(x => x.id === j.mois);
      if (!m || !(j.jour >= 1 && j.jour <= m.jours)) p.push(`${ou} : cette date n'existe pas dans calendrier.json.`);
      else {
        const n = rangDate(cal, j) - debut + cal.debut_campagne.jour_campagne;
        if (n !== j.jour_campagne) p.push(`${ou} : jour de campagne ${j.jour_campagne}, le calendrier donne ${n}.`);
      }
    }
    if (!(j.min <= j.max)) p.push(`${ou} : « min » (${j.min}) plus haut que « max » (${j.max}).`);
    if (!ciels[j.ciel]) p.push(`${ou} : ciel « ${j.ciel} » absent de « types_ciel ».`);
    for (const x of j.precipitations || []) if (!precip[x]) p.push(`${ou} : précipitation « ${x} » absente de « types_precipitation ».`);
    const cs = j.creneaux || [];
    if (cs.map(c => c.creneau).join() !== ordre.join()) p.push(`${ou} : créneaux ${cs.map(c => c.creneau).join(', ') || 'absents'} (attendus : ${ordre.join(', ')}).`);
    for (const c of cs) {
      if (!ciels[c.ciel]) p.push(`${ou}, ${c.creneau} : ciel « ${c.ciel} » absent de « types_ciel ».`);
      if (c.precipitation && !precip[c.precipitation]) p.push(`${ou}, ${c.creneau} : précipitation « ${c.precipitation} » absente de « types_precipitation ».`);
      if (!(c.min <= c.max)) p.push(`${ou}, ${c.creneau} : « min » (${c.min}) plus haut que « max » (${c.max}).`);
    }
  }
}

// objets.json : objets à trouver ou à recevoir (formats/objets.md). Un fichier visé absent ne donne qu'un avertissement.
export const GENRES_OBJETS = ['magique', 'equipement', 'tresor', 'document', 'cle', 'pieces', 'autre'];
const PIECES_OBJETS = ['pp', 'po', 'pe', 'pa', 'pc'];
const RARETES_OBJETS = ['courant', 'peu courant', 'rare', 'très rare', 'légendaire'];

async function verifierObjets(d, p, autre) {
  idsUniques(exiger(d.objets, 'objets', p), 'objets', p);
  const ref = await referentiel(autre);
  await verifierEtapesDe(d.objets || [], x => `Objet ${x.id}`, autre, p);
  const [rencontres, deroule, pnj, personnages] = await Promise.all(['rencontres-aleatoires', 'deroule-campagne', 'pnj', 'personnages'].map(autre));
  const ensemble = (donnees, liste) => (donnees ? new Set((liste || []).map(x => x.id)) : null);
  const cibles = {
    rencontre: [ensemble(rencontres, rencontres?.rencontres_scenarisees), 'rencontres-aleatoires.json (rencontres_scenarisees)'],
    jalon: [ensemble(deroule, deroule?.jalons), 'deroule-campagne.json (jalons)'],
    etape: [ensemble(deroule, deroule?.etapes), 'deroule-campagne.json (etapes)'],
    pnj: [ensemble(pnj, pnj?.pnj), 'pnj.json'],
    personnage: [ensemble(personnages, personnages?.personnages), 'personnages.json'],
  };
  const absents = new Set();
  let sansRattachement = 0;
  for (const o of d.objets || []) {
    const ou = `Objet ${o.id}`;
    if (!o.nom?.trim()) p.push(`${ou} : « nom » manquant.`);
    if (!o.description?.trim()) p.push(`${ou} : « description » manquante (ce que voient les joueurs).`);
    if (!GENRES_OBJETS.includes(o.genre)) p.push(`${ou} : « genre » vaut « ${o.genre} », attendu : ${GENRES_OBJETS.join(', ')}.`);
    if (typeof o.beyond !== 'boolean') p.push(`${ou} : « beyond » doit valoir true ou false.`);
    else if (o.beyond && !o.nom_en?.trim()) p.push(`${ou} : « beyond » vrai sans « nom_en » (le nom à chercher sur D&D Beyond).`);
    if (o.rarete != null && !RARETES_OBJETS.includes(o.rarete)) p.push(`Avertissement : ${ou} : « rarete » vaut « ${o.rarete} », attendu : ${RARETES_OBJETS.join(', ')}.`);
    if (o.poids != null && !(Number.isInteger(o.poids) && o.poids >= 0)) p.push(`${ou} : « poids » doit être un nombre entier de livres (D&D Beyond refuse les décimales).`);
    if (o.cout != null && !(Number.isInteger(o.cout) && o.cout >= 0)) p.push(`${ou} : « cout » doit être un nombre entier de po.`);
    if (o.cout_estime != null && typeof o.cout_estime !== 'boolean') p.push(`${ou} : « cout_estime » doit valoir true ou false.`);
    if (o.quantite != null && !bornesDe(o.quantite)) p.push(`${ou} : « quantite » illisible (« ${o.quantite} »).`);
    // Des pièces (genre « pieces », 2026-11-12) : `pieces` { pp, po, pe, pa, pc } en entiers, au moins une ; jamais sur le catalogue.
    if (o.genre === 'pieces') {
      const pc = o.pieces && typeof o.pieces === 'object' ? o.pieces : null;
      if (!pc) p.push(`${ou} : genre « pieces » sans « pieces » ({ "po": 35, "pa": 120 }).`);
      else {
        const fausses = Object.entries(pc).filter(([k, n]) => !PIECES_OBJETS.includes(k) || !(Number.isInteger(n) && n >= 0));
        if (fausses.length) p.push(`${ou} : « pieces » : des nombres entiers pour ${PIECES_OBJETS.join(', ')} seulement (${fausses.map(([k]) => k).join(', ')}).`);
        else if (!Object.values(pc).some(n => n > 0)) p.push(`${ou} : « pieces » sans aucune pièce.`);
      }
      if (o.beyond === true) p.push(`${ou} : des pièces ne sont pas un objet du catalogue de D&D Beyond : « beyond » vaut false.`);
    } else if (o.pieces != null) p.push(`Avertissement : ${ou} : « pieces » ignoré, le genre n'est pas « pieces ».`);
    if (!o.source) p.push(`${ou} : « source » manquante.`);
    if (o.lieu) verifierLieu(o.lieu, ref, ou, p);
    if (o.sous_lieu) {
      if (!o.lieu) p.push(`${ou} : « sous_lieu » sans « lieu ».`);
      else verifierSousLieu(o.sous_lieu, o.lieu, ref, ou, p);
    }
    for (const [champ, [ids, fichier]] of Object.entries(cibles)) {
      if (!o[champ]) continue;
      if (!ids) absents.add(fichier.split(' ')[0]);
      else if (!ids.has(o[champ])) p.push(`${ou} : ${champ} « ${o[champ]} » absent de ${fichier}.`);
    }
    if (!o.lieu && !o.rencontre && !o.jalon && !o.etape && !o.pnj) sansRattachement++;
    if (o.personnage && !o.jalon && !o.etape && !o.rencontre) p.push(`Avertissement : ${ou} : objet de quête personnelle (« personnage ») sans « jalon », « etape » ni « rencontre » : pas d'alerte de fin pour lui.`);
  }
  if (sansRattachement) p.push(`Avertissement : ${sansRattachement} objet${sansRattachement > 1 ? 's' : ''} sans « lieu », « rencontre », « jalon », « etape » ni « pnj » : seulement dans le widget Objets.`);
  for (const f of absents) p.push(`Avertissement : ${f} n'est pas chargé, les renvois vers ce fichier ne sont pas vérifiés.`);
}

// quetes.json : le catalogue des quêtes (formats/quetes.md). Un fichier visé absent ne donne qu'un avertissement.
const IMPORTANCES_QUETES = ['anecdotique', 'mineure', 'majeure', 'epique'];
async function verifierQuetes(d, p, autre) {
  idsUniques(exiger(d.quetes, 'quetes', p), 'quetes', p);
  const ref = await referentiel(autre);
  const [factions, pnj, deroule, rencontres, objets, agenda] = await Promise.all(['factions', 'pnj', 'deroule-campagne', 'rencontres-aleatoires', 'objets', 'agenda'].map(autre));
  const ensemble = (donnees, liste) => (donnees ? new Set((liste || []).map(x => x.id)) : null);
  const ids = {
    faction: [ensemble(factions, factions?.factions), 'factions.json'],
    pnj: [ensemble(pnj, pnj?.pnj), 'pnj.json'],
    jalon: [ensemble(deroule, deroule?.jalons), 'deroule-campagne.json (jalons)'],
    piste: [ensemble(deroule, deroule?.pistes), 'deroule-campagne.json (pistes)'],
    etape: [ensemble(deroule, deroule?.etapes), 'deroule-campagne.json (etapes)'],
    rencontre: [ensemble(rencontres, rencontres?.rencontres_scenarisees), 'rencontres-aleatoires.json (rencontres_scenarisees)'],
    objet: [ensemble(objets, objets?.objets), 'objets.json'],
    agenda: [ensemble(agenda, agenda?.entrees), 'agenda.json'],
  };
  const quetes = new Set((d.quetes || []).map(q => q.id));
  const absents = new Set();
  const renvoi = (genre, id, ou) => {
    if (!id) return;
    const [ens, fichier] = ids[genre];
    if (!ens) absents.add(fichier.split(' ')[0]);
    else if (!ens.has(id)) p.push(`${ou} : ${genre} « ${id} » absent de ${fichier}.`);
  };
  const entier = v => Number.isInteger(v);
  for (const q of d.quetes || []) {
    const ou = `Quête ${q.id}`;
    if (String(q.id || '').startsWith('mj-')) p.push(`${ou} : un « id » en « mj- » est réservé aux quêtes créées par le MJ.`);
    if (!q.nom?.trim()) p.push(`${ou} : « nom » manquant.`);
    if (!q.description?.trim()) p.push(`${ou} : « description » manquante (ce que lisent les joueurs).`);
    if (!IMPORTANCES_QUETES.includes(q.importance)) p.push(`${ou} : « importance » vaut « ${q.importance} », attendu : ${IMPORTANCES_QUETES.join(', ')}.`);
    if (q.type && d.types && !d.types[q.type]) p.push(`${ou} : type « ${q.type} » absent de « types ».`);
    if (!q.faction && !q.pnj) p.push(`Avertissement : ${ou} : ni « faction » ni « pnj » : rangée « Sans donneur ».`);
    if (q.niveau != null) {
      const okN = n => entier(n) && n >= 1 && n <= 20;
      // Le niveau optimal (2026-11-12) ; l'ancien intervalle { min, max } est encore lu (son milieu), avec un avertissement.
      if (typeof q.niveau === 'object') p.push(`Avertissement : ${ou} : « niveau » en { min, max } : un seul entier, le niveau optimal, est attendu (pris au milieu : ${Math.round(((+q.niveau.min || 1) + (+q.niveau.max || +q.niveau.min || 1)) / 2)}).`);
      else if (!okN(q.niveau)) p.push(`${ou} : « niveau » : le niveau optimal, un entier de 1 à 20.`);
    }
    renvoi('faction', q.faction, ou); renvoi('pnj', q.pnj, ou); renvoi('jalon', q.jalon, ou); renvoi('agenda', q.agenda, ou);
    if (q.lieu) verifierLieu(q.lieu, ref, ou, p);
    for (const r of q.rencontres || []) renvoi('rencontre', r, ou);
    for (const e of q.etapes || []) {
      if (!!e.jalon === !!e.piste) p.push(`${ou} : chaque élément de « etapes » a un « jalon » ou une « piste » (pas les deux).`);
      renvoi('jalon', e.jalon, ou); renvoi('piste', e.piste, ou);
    }
    if (q.echeance_jours != null && !(entier(q.echeance_jours) && q.echeance_jours > 0)) p.push(`${ou} : « echeance_jours » : un nombre entier de jours, 1 ou plus.`);
    for (const r of q.recompenses || []) {
      if (!['or', 'objet', 'reputation', 'autre'].includes(r.type)) { p.push(`${ou} : récompense de type « ${r.type} » inconnu (or, objet, reputation, autre).`); continue; }
      if (r.si && !['reussite', 'echec'].includes(r.si)) p.push(`${ou} : récompense : « si » vaut reussite ou echec.`);
      if (r.type === 'or' && !(entier(r.montant) && r.montant >= 0)) p.push(`${ou} : récompense en or : « montant » entier (po).`);
      if (r.type === 'objet') { if (!r.objet) p.push(`${ou} : récompense « objet » sans « objet ».`); renvoi('objet', r.objet, ou); }
      if (r.type === 'reputation') { if (!entier(r.valeur)) p.push(`${ou} : récompense de réputation : « valeur » entière.`); if (!r.faction) p.push(`${ou} : récompense de réputation sans « faction ».`); renvoi('faction', r.faction, ou); }
      if (r.type === 'autre' && !r.texte?.trim()) p.push(`${ou} : récompense « autre » sans « texte ».`);
    }
    for (const c of q.conditions || []) {
      if (c.type === 'reputation') { renvoi('faction', c.faction, ou); if (!c.rang && !entier(c.valeur)) p.push(`${ou} : condition de réputation sans « rang » ni « valeur ».`); }
      else if (c.type === 'quete') { if (c.quete === q.id) p.push(`${ou} : une condition cite la quête elle-même.`); else if (!quetes.has(c.quete)) p.push(`${ou} : condition : quête « ${c.quete} » absente de ce fichier.`); }
      else if (['jalon', 'piste', 'etape'].includes(c.type)) renvoi(c.type, c[c.type], ou);
      else if (c.type === 'niveau') { if (!entier(c.min)) p.push(`${ou} : condition de niveau sans « min » entier.`); }
      else p.push(`${ou} : condition de type « ${c.type} » inconnu (reputation, quete, jalon, piste, etape, niveau).`);
    }
  }
  for (const f of absents) p.push(`Avertissement : ${f} n'est pas chargé, les renvois vers ce fichier ne sont pas vérifiés.`);
}
