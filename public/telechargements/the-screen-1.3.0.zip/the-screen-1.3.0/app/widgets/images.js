// Widget Images : parcourir la bibliothèque d'images de la campagne, filtrer par source, catégorie, lieu (ou là où sont
// les héros : « Ici »), PNJ, trier ou regrouper, ouvrir une image dans une fenêtre flottante, l'étiqueter.
// Index, fenêtre et étiquettes : app/bibliotheque.js (formats/images.md). État : etat/images.json.

import { h, icone, alerte, bouton, infobulle, ouvrirMenu, normaliser } from '../ui.js';
import { nomLieu, etatIci } from '../lieux.js';
import { chargerBibliotheque, CATEGORIES } from '../bibliotheque.js';
import { ouvrirAjoutImages } from '../ajout-images.js';

// Regrouper ou trier (le bouton à flèche de tri) : par lieu, par source, par catégorie, ou tout par titre.
const TRIS = [['lieu', 'Par lieu'], ['source', 'Par source'], ['categorie', 'Par catégorie'], ['titre', 'Par titre, de A à Z']];

export default {
  type: 'images',
  titre: 'Images',
  icone: 'carte',
  description: 'Les cartes et illustrations de la campagne : par lieu, par PNJ, par source, avec la version joueurs des cartes.',
  taille: { w: 6, h: 14 },
  min: { w: 3, h: 6 },
  unique: true,

  async monter({ corps, actions, resume, donnees, etat, dialogue }) {
    // Ajouter des images (demande du MJ, 2026-11-10, app/ajout-images.js) : le widget se refait ensuite (événement
    // cm:bibliotheque), filtré sur la source où elles sont allées.
    let sourceAjoutee = null, desabonner = [], btnFiltresAncien = null;
    const ajouter = () => ouvrirAjoutImages({ dialogue, donnees, etat, surAjout: ({ source }) => { sourceAjoutee = source; } });
    actions.prepend(bouton('', { icone: 'lu-image-plus', titre: 'Ajouter des images (fichiers ou dossier)', classe: 'bn-btn--s bn-btn--fantome cm-si-deplie', onclick: ajouter }));
    document.addEventListener('cm:bibliotheque', () => { if (corps.isConnected) construire(); });
    await construire();
    return {};

    async function construire() {
      desabonner.forEach(f => f()); desabonner = [];
      btnFiltresAncien?.remove();
      const b = await chargerBibliotheque(donnees, etat);
      if (!b) {
        corps.replaceChildren(alerte('cierge', 'lu-database', 'Bibliothèque vide ou pas encore indexée',
          'Ajoutez des images, ou rangez-les dans le dossier de la bibliothèque (fenêtre Campagne, onglet « Images »). L\'index se fait au démarrage du gestionnaire : si ce message reste, lancez « outils/Indexer les images.cmd », puis rechargez la page.',
          h('div', { class: 'bn-groupe' }, bouton('Ajouter des images', { classe: 'bn-btn--s', icone: 'lu-image-plus', onclick: ajouter }))));
        resume.replaceChildren();
        return;
      }
      const { index, lieux, titre, lieuxDe, pnjDe, nomPnj, vignette } = b;
      const sIci = await etatIci(etat, donnees);
      const filtre = { source: sourceAjoutee || '', categorie: '', lieu: '', pnj: '', texte: '', tri: 'lieu', joueurs: false, ici: false };
      sourceAjoutee = null;
      const liste = h('div', { class: 'cm-pile' });

      // « Ici » (demande du MJ, 2026-10-25) : les images du lieu où sont les héros, celles de ses sous-lieux comprises.
      const lieuIci = () => sIci.valeur.lieu || null;
      const dansIci = i => { const l = lieuIci(); return !!l && lieuxDe(i).some(id => id === l || lieux.get(id)?.parent === l); };

      function correspond(i) {
        if (i.joueurs && !filtre.joueurs) return false;
        if (filtre.source && i.source !== filtre.source) return false;
        if (filtre.categorie && i.categorie !== filtre.categorie) return false;
        if (filtre.ici) { if (!dansIci(i)) return false; }
        else if (filtre.lieu === '-' ? lieuxDe(i).length : filtre.lieu && !lieuxDe(i).includes(filtre.lieu)) return false;
        if (filtre.pnj && !pnjDe(i).includes(filtre.pnj)) return false;
        if (filtre.texte) {
          const q = normaliser(filtre.texte);
          if (![titre(i), i.titre, i.dossier, ...pnjDe(i).map(nomPnj)].some(t => normaliser(t).includes(q))) return false;
        }
        return true;
      }

      // Le nombre d'images dans l'en-tête (demande du MJ, 2026-10-25), « 12 sur 276 » quand un filtre en écarte.
      function majResume(n) {
        const total = index.images.filter(i => filtre.joueurs || !i.joueurs).length;
        resume.replaceChildren(h('span', { class: 'cm-images-compte' }, icone('carte', 'bn-icone--s'), n === total ? `${total}` : `${n} sur ${total}`));
      }

      function rendreListe() {
        const choisies = index.images.filter(correspond);
        majResume(choisies.length);
        if (!choisies.length) { liste.replaceChildren(h('p', { class: 'ui cm-sourdine' }, filtre.ici && !lieuIci() ? 'Le lieu des héros n\'est pas noté (widget Ici).' : 'Aucune image ne correspond.')); return; }
        if (filtre.tri === 'titre') {
          liste.replaceChildren(h('div', { class: 'cm-vignettes' }, [...choisies].sort((a, c) => titre(a).localeCompare(titre(c), 'fr')).map(vignette)));
          return;
        }
        const cle = i => filtre.tri === 'lieu' ? (lieuxDe(i)[0] || '') : filtre.tri === 'source' ? (i.source || '') : i.categorie;
        const libelle = k => filtre.tri === 'lieu' ? (k ? nomLieu(lieux, k) : 'Sans lieu') : filtre.tri === 'source' ? (k || 'Sans source') : CATEGORIES[k] || k;
        const groupes = new Map();
        for (const i of choisies) { const k = cle(i); if (!groupes.has(k)) groupes.set(k, []); groupes.get(k).push(i); }
        const ordre = [...groupes.keys()].sort((a, c) => (a === '' ? 1 : c === '' ? -1 : libelle(a).localeCompare(libelle(c), 'fr')));
        liste.replaceChildren(...ordre.map(k => h('section', { class: 'cm-pile cm-images-groupe' },
          h('h3', { class: 'etiquette cm-section__titre' }, libelle(k), h('span', { class: 'cm-sourdine' }, ` · ${groupes.get(k).length}`)),
          h('div', { class: 'cm-vignettes' }, groupes.get(k).map(vignette)))));
      }

      // Une liste déroulante précédée de son icône (comme Objets) : sur une ligne de quatre, qui se resserrent sans passer à la ligne ;
      // sans choix, elle dit seulement ce qu'elle filtre (« Source »), pour rester lisible dans un widget étroit.
      const choix = (cle, options, etiquette, ic) => {
        const sel = h('select', { class: 'bn-select', 'aria-label': etiquette, onchange: e => { filtre[cle] = e.target.value; rendre(); } },
          options.map(([val, lib]) => h('option', { value: val }, lib)));
        return { sel, el: infobulle(h('span', { class: 'cm-filtre' }, icone(ic, 'bn-icone--s'), sel), etiquette) };
      };
      const compte = f => index.images.filter(i => !i.joueurs && f(i)).length;
      // Sources : les dossiers de premier niveau de la bibliothèque, un par source d'images (app/bibliotheque.js).
      const sourcesPresentes = [...new Set(index.images.map(i => i.source).filter(Boolean))].sort((a, c) => a.localeCompare(c, 'fr'));
      const source = choix('source', [['', 'Source'], ...sourcesPresentes.map(id => [id, `${id} (${compte(i => i.source === id)})`])], 'Source', 'livre');
      const categorie = choix('categorie', [['', 'Catégorie'], ...Object.entries(CATEGORIES).filter(([k]) => compte(i => i.categorie === k)).map(([k, v]) => [k, `${v} (${compte(i => i.categorie === k)})`])], 'Catégorie', 'lu-layout-grid');
      const lieuxPresents = [...new Set(index.images.flatMap(lieuxDe))].sort((a, c) => nomLieu(lieux, a).localeCompare(nomLieu(lieux, c), 'fr'));
      const lieu = choix('lieu', [['', 'Lieu'], ...lieuxPresents.map(id => [id, nomLieu(lieux, id)]), ['-', 'Sans lieu']], 'Lieu', 'epingle');
      const pnjPresents = [...new Set(index.images.flatMap(pnjDe))].sort((a, c) => nomPnj(a).localeCompare(nomPnj(c), 'fr'));
      const pnj = choix('pnj', [['', 'PNJ'], ...pnjPresents.map(id => [id, nomPnj(id)])], 'PNJ', 'crocs');

      // Boutons à bascule de la ligne de recherche : Ici, versions joueurs ; le tri ouvre un menu.
      const bascule = (ic, texte, aide, cle) => {
        const btn = bouton('', { icone: ic, classe: 'bn-btn--s bn-btn--fantome cm-filtre-bouton', onclick: () => { filtre[cle] = !filtre[cle]; rendre(); } });
        btn.setAttribute('aria-label', texte);
        return infobulle(btn, aide, { titre: texte });
      };
      const btnIci = bascule('epingle', 'Ici', 'Seulement les images du lieu où sont les héros (sous-lieux compris).', 'ici');
      const btnJoueurs = bascule('lu-eye', 'Versions joueurs', 'Montrer aussi les versions joueurs des cartes (sans les secrets du MJ).', 'joueurs');
      const btnTri = infobulle(bouton('', { icone: 'lu-arrow-down-wide-narrow', classe: 'bn-btn--s bn-btn--fantome cm-filtre-bouton',
        onclick: ev => ouvrirMenu(ev.currentTarget, TRIS.map(([k, lib]) => [k === filtre.tri ? `${lib} ✓` : lib, '', () => { filtre.tri = k; rendre(); }]), 'Trier les images') }), 'Regrouper par lieu, source ou catégorie, ou tout trier par titre.', { titre: 'Tri' });
      btnTri.setAttribute('aria-label', 'Trier les images');

      const recherche = h('input', { class: 'bn-input', type: 'search', placeholder: 'Titre, PNJ, dossier…', 'aria-label': 'Chercher une image', oninput: e => { filtre.texte = e.target.value; rendre(); } });
      const filtres = h('div', { class: 'cm-pnj-filtres' },
        h('div', { class: 'cm-filtres-ligne' }, h('div', { class: 'cm-recherche' }, icone('lu-search', 'bn-icone--s'), recherche), btnIci, btnJoueurs, btnTri),
        h('div', { class: 'cm-pnj-selects cm-pnj-selects--fixes' }, source.el, categorie.el, lieu.el, pnj.el));

      // Recherche et filtres masquables (comme PNJ et Objets) ; masqués, ils filtrent encore : le bouton le rappelle en orange.
      const CLE_FILTRES = 'cm:images:filtres';
      let filtresVisibles = true;
      try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* pas de stockage : visibles */ }
      const filtresActifs = () => !!(filtre.texte.trim() || filtre.source || filtre.categorie || filtre.lieu || filtre.pnj || filtre.ici);
      const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
        filtresVisibles = !filtresVisibles;
        try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* le choix vaut pour la session */ }
        rendre();
      } });
      actions.prepend(btnFiltres);
      btnFiltresAncien = btnFiltres;

      function rendre() {
        filtres.hidden = !filtresVisibles;
        btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
        btnFiltres.classList.toggle('est-filtre', !filtresVisibles && filtresActifs());
        const aide = (filtresVisibles ? 'Masquer la recherche et les filtres' : 'Afficher la recherche et les filtres') + (!filtresVisibles && filtresActifs() ? ' (des filtres sont actifs)' : '');
        btnFiltres.title = aide;
        btnFiltres.setAttribute('aria-label', aide);
        btnIci.setAttribute('aria-pressed', String(filtre.ici));
        btnIci.dataset.bulle = filtre.ici && lieuIci() ? `Seulement les images de ${nomLieu(lieux, lieuIci())} (sous-lieux compris), où sont les héros.` : 'Seulement les images du lieu où sont les héros (sous-lieux compris).';
        btnJoueurs.setAttribute('aria-pressed', String(filtre.joueurs));
        btnTri.classList.toggle('est-filtre', filtre.tri !== 'lieu');
        lieu.sel.disabled = filtre.ici;   // « Ici » remplace le choix du lieu
        rendreListe();
      }
      source.sel.value = filtre.source;
      corps.replaceChildren(filtres, liste);
      rendre();
      // Une étiquette changée (ici ou depuis le widget Ici), ou les héros qui changent de lieu : la liste suit.
      desabonner.push(b.s.abonner(rendreListe), sIci.abonner(() => { if (filtre.ici) rendre(); }));
    }
  },
};
