// Widget Quêtes (demande du MJ, 2026-11-11) : le catalogue des quêtes (data/quetes.json, formats/quetes.md) et celles que le MJ
// crée, rangées par donneur (faction ou PNJ, avec la réputation du groupe auprès de la faction), triées par statut puis par
// importance (sa couleur). Sur chaque ligne, le niveau optimal dans la couleur de la difficulté pour le groupe. Un clic ouvre
// la fenêtre de la quête (app/quetes.js) : accepter, réussie, échouée, récompenses, cacher aux joueurs.
// Filtres masquables (comme Objets) ; « + Quête » ; « Panneaux » : les panneaux des quêtes de l'écran des joueurs (plusieurs,
// réglés dans le gestionnaire) ; « Diffuser » : lequel montrer.
// Dans l'en-tête, même réduit : les quêtes prises, et celles à régler.
// Une option de campagne : coupée, le widget le dit et propose de l'activer.

import { h, icone, bouton, alerte, normaliser, infobulle, identifiant, ouvrirMenu, ecranJoueursActif, montrerPanneauAuxJoueurs, ecranPanneauInfos } from '../ui.js';
import { outilsQuetes, quetesActives, IMPORTANCES, DIFFICULTES, niveauOptimal, voirFaction, dansStatuts, casesStatuts, STATUTS } from '../quetes.js';
import { reputationActive, badgeRang, reglagesReputation, rangDeFaction, valeurDe, signe, factionSuivie } from '../reputation.js';
import { rendrePanneau } from '../panneau-quetes.js';
import { chargerBibliotheque } from '../bibliotheque.js';

// Les statuts montrés, cochés (demande du MJ, 2026-11-12) : proposées et prises d'office.
const STATUTS_DEFAUT = ['proposees', 'prises'];
const ORDRE_STATUT = { prise: 0, disponible: 1, verrouillee: 2, reussie: 3, echouee: 4 };

export default {
  type: 'quetes',
  titre: 'Quêtes',
  icone: 'lu-scroll-text',
  description: 'Le catalogue des quêtes proposées aux héros (panneau de la garde, contrats, demandes), par donneur et par importance : niveau optimal et difficulté pour le groupe, récompenses (or, objet, réputation), étapes dans le Déroulé, et les panneaux à montrer aux joueurs.',
  taille: { w: 4, h: 14 },
  min: { w: 3, h: 6 },
  unique: true,

  async monter({ corps, actions, resume, donnees, etat, dialogue }) {
    const Q = await outilsQuetes({ donnees, etat, dialogue });
    // La bibliothèque d'images : ses textures (catégorie « Textures ») se proposent en fond d'un panneau. Null sans index.
    let biblio = null;
    chargerBibliotheque(donnees, etat).then(b => { biblio = b; }).catch(() => {});
    const textures = () => (biblio?.index.images || []).filter(i => i.categorie === 'texture' && !i.joueurs);
    const filtre = { texte: '', statuts: [...STATUTS_DEFAUT], importance: '', donneur: '' };
    const liste = h('div', { class: 'cm-quetes-liste' });
    const compteur = h('span', { class: 'ui-s cm-sourdine' });

    const recherche = h('input', { class: 'bn-input', type: 'search', placeholder: 'Titre, donneur, lieu', 'aria-label': 'Chercher une quête',
      oninput: e => { filtre.texte = e.target.value; rendreListe(); majFiltres(); } });
    const selects = {};
    const choix = (cle, options, etiquette, ic) => h('span', { class: 'cm-filtre', title: etiquette }, icone(ic, 'bn-icone--s'),
      selects[cle] = h('select', { class: 'bn-select', 'aria-label': etiquette, onchange: e => { filtre[cle] = e.target.value; rendreListe(); majFiltres(); } },
        options.map(([val, lib]) => h('option', { value: val, selected: val === filtre[cle] }, lib))));
    const donneurs = () => {
      const m = new Map();
      for (const x of Q.tous()) if (x.donneur.cle) m.set(x.donneur.cle, x.donneur.nom);
      return [...m].sort((a, b) => a[1].localeCompare(b[1], 'fr'));
    };
    const filtres = h('div', { class: 'cm-pnj-filtres' });
    const dessinerFiltres = () => filtres.replaceChildren(
      h('div', { class: 'cm-filtres-ligne' }, h('div', { class: 'cm-recherche' }, icone('lu-search', 'bn-icone--s'), recherche)),
      casesStatuts(filtre.statuts, g => { filtre.statuts = g; rendreListe(); majFiltres(); }),
      h('div', { class: 'cm-pnj-selects' },
        choix('importance', [['', 'Toutes importances'], ...Object.keys(IMPORTANCES).map(k => [k, Q.importance(k).libelle])], 'Importance', 'lu-sparkles'),
        choix('donneur', [['', 'Tous les donneurs'], ...donneurs()], 'Donneur', 'bouclier')));
    dessinerFiltres();

    const CLE_FILTRES = 'cm:quetes:filtres';
    let filtresVisibles = true;
    try { filtresVisibles = localStorage.getItem(CLE_FILTRES) !== 'masques'; } catch { /* visibles */ }
    const filtresActifs = () => !!(filtre.texte.trim() || filtre.statuts.slice().sort().join() !== STATUTS_DEFAUT.slice().sort().join() || filtre.importance || filtre.donneur);
    const btnFiltres = bouton('', { icone: 'lu-sliders-horizontal', classe: 'bn-btn--s bn-btn--fantome cm-pnj-bouton-filtres cm-si-deplie', onclick: () => {
      filtresVisibles = !filtresVisibles;
      try { localStorage.setItem(CLE_FILTRES, filtresVisibles ? 'visibles' : 'masques'); } catch { /* pour la session */ }
      majFiltres();
    } });
    function majFiltres() {
      filtres.hidden = !filtresVisibles;
      btnFiltres.setAttribute('aria-pressed', String(filtresVisibles));
      btnFiltres.classList.toggle('est-filtre', !filtresVisibles && filtresActifs());
      const titre = (filtresVisibles ? 'Masquer la recherche et les filtres' : 'Afficher la recherche et les filtres') + (!filtresVisibles && filtresActifs() ? ' (des filtres sont actifs)' : '');
      btnFiltres.title = titre;
      btnFiltres.setAttribute('aria-label', titre);
    }
    actions.prepend(btnFiltres);

    const garde = x => {
      const mots = normaliser(filtre.texte).split(/\s+/).filter(Boolean);
      const texte = normaliser(`${x.nom} ${x.donneur.nom} ${x.q.lieu || ''} ${x.q.type || ''}`);
      if (!mots.every(m => texte.includes(m))) return false;
      if (!dansStatuts(x, filtre.statuts)) return false;
      if (filtre.importance && x.importance !== filtre.importance) return false;
      if (filtre.donneur && x.donneur.cle !== filtre.donneur) return false;
      return true;
    };
    const tri = (a, b) => ORDRE_STATUT[a.statut] - ORDRE_STATUT[b.statut] || (b.aRegler - a.aRegler)
      || Q.importance(b.importance).ordre - Q.importance(a.importance).ordre || a.nom.localeCompare(b.nom, 'fr');

    // La tête d'un groupe : le donneur, et la réputation du groupe auprès de lui (une faction suivie).
    function teteGroupe(cle, nom) {
      const fid = cle.startsWith('f:') ? cle.slice(2) : null;
      const f = fid ? Q.factionParId.get(fid) : null;
      return h('div', { class: 'cm-quetes-groupe__tete' },
        f ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton etiquette', title: 'Ouvrir la fiche de la faction', onclick: () => voirFaction(fid) }, nom)
          : h('span', { class: 'etiquette' }, nom),
        f && reputationActive() && factionSuivie(f) ? badgeRang(fid) : null);
    }

    function rendreListe() {
      const toutes = Q.tous();
      const vues = toutes.filter(garde).sort(tri);
      const groupes = new Map();
      for (const x of vues) { if (!groupes.has(x.donneur.cle)) groupes.set(x.donneur.cle, { nom: x.donneur.nom, vues: [] }); groupes.get(x.donneur.cle).vues.push(x); }
      const ordre = [...groupes].sort((a, b) => (a[0] ? 0 : 1) - (b[0] ? 0 : 1) || a[1].nom.localeCompare(b[1].nom, 'fr'));
      liste.replaceChildren(...(vues.length ? ordre.map(([cle, g]) => h('section', { class: 'cm-quetes-groupe' }, teteGroupe(cle, g.nom), g.vues.map(Q.ligne)))
        : [h('p', { class: 'ui-s cm-sourdine' }, toutes.length ? 'Aucune quête ne correspond.' : 'Pas encore de quête : « + Quête », ou data/quetes.json écrit à la main ou avec votre agent IA de campagne (formats/quetes.md).')]));
      compteur.textContent = vues.length === toutes.length ? `${toutes.length} quête${toutes.length > 1 ? 's' : ''}` : `${vues.length} sur ${toutes.length}`;
    }

    function majResume() {
      if (!quetesActives()) { resume.replaceChildren(); return; }
      const xs = Q.tous();
      const prises = xs.filter(x => x.statut === 'prise').length;
      const aRegler = xs.filter(x => x.aRegler).length;
      const retard = xs.filter(x => x.joursRestants != null && x.joursRestants < 0).length;
      resume.replaceChildren(...[
        prises ? infobulle(h('span', { class: 'cm-quetes-resume' }, icone('lu-flag', 'bn-icone--s'), String(prises)), `${prises} quête${prises > 1 ? 's' : ''} en cours`) : null,
        aRegler ? infobulle(h('span', { class: 'cm-quetes-resume est-alerte' }, icone('lu-triangle-alert', 'bn-icone--s'), String(aRegler)), `${aRegler} quête${aRegler > 1 ? 's' : ''} à régler : toutes leurs étapes sont terminées`, { ton: 'cierge' }) : null,
        retard ? infobulle(h('span', { class: 'cm-quetes-resume est-retard' }, icone('lu-hourglass', 'bn-icone--s'), String(retard)), `${retard} quête${retard > 1 ? 's' : ''} dont l'échéance est dépassée`, { ton: 'sang' }) : null,
      ].filter(Boolean));
    }

    // ───── Les panneaux de l'écran des joueurs (plusieurs, propres au gestionnaire : demande du MJ, 2026-11-12) ─────
    // Ce que montre le niveau d'une quête sur un panneau : son niveau optimal, sa difficulté pour le groupe (relative : elle
    // change quand le groupe monte de niveau), ou rien.
    const NIVEAUX_AFFICHES = [['niveau', 'Le niveau optimal'], ['difficulte', 'La difficulté pour le groupe'], ['rien', 'Rien']];
    // Le fond du panneau : celui de la charte, ou une texture fournie par le gestionnaire (app/images/textures/, essai du MJ,
    // 2026-11-12 : un panneau de bois où sont épinglés les post-its).
    // Puis les textures de la bibliothèque (« img:<id> »).
    const FONDS = [['charte', 'Celui de la charte'], ['bois-clair', 'Bois clair'], ['bois-sombre', 'Bois sombre']];
    const fondsPossibles = () => [...FONDS, ...textures().map(i => ['img:' + i.id, biblio.titre(i)])];
    // Ce que reçoit la page joueurs : le nom d'une texture du gestionnaire, ou le chemin d'une texture de la bibliothèque.
    function fondDe(p) {
      const f = p.fond || 'charte';
      if (!f.startsWith('img:')) return { fond: f };
      const i = (biblio?.index.images || []).find(x => x.id === f.slice(4));
      // En adresse complète : une url() dans une variable CSS se lit par rapport à la feuille de style, pas à la page.
      return i ? { fond: 'texture', texture: new URL(encodeURI(i.chemin), document.baseURI).href } : { fond: 'charte' };
    }
    function cartesPanneau(vues, p = {}) {
      const rep = reglagesReputation();
      const aff = p.niveau_affiche || 'niveau';
      return vues.map(x => {
        const imp = Q.importance(x.importance);
        const f = x.q.faction ? Q.factionParId.get(x.q.faction) : null;
        const rang = f && reputationActive() && factionSuivie(f) && rep.joueurs !== 'rien'
          ? { ...rangDeFaction(f.id), nombre: rep.joueurs === 'nombre' ? signe(valeurDe(f.id)) : null } : null;
        const recs = x.recompenses.filter(r => !r.cachee && (r.si || 'reussite') === 'reussite');
        const o = niveauOptimal(x.q.niveau);
        const niveau = aff === 'rien' || !o ? null
          : aff === 'difficulte' ? (x.difficulte ? { texte: DIFFICULTES[x.difficulte].libelle, couleur: DIFFICULTES[x.difficulte].couleur } : { texte: `Niveau ${o}` })
            : { texte: `Niveau ${o}` };
        return {
          id: x.id, nom: x.nom, donneur: x.donneur.nom, rang, couleur: imp.couleur, importance: imp.libelle, niveau,
          statut: x.statut !== 'disponible' && STATUTS[x.statut] ? { texte: STATUTS[x.statut].libelle, couleur: STATUTS[x.statut].couleur || 'cendre', fini: x.statut === 'reussie' || x.statut === 'echouee' } : null,
          description: x.q.description || '', objectifs: x.q.objectifs || [],
          recompenses: recs.map(Q.libelleRecompense), recompensesCachees: x.recompensesCachees || (x.recompenses.length > 0 && !recs.length),
        };
      });
    }
    const donneesPanneau = p => ({ id: p.id, titre: Q.titrePanneau(p), ...fondDe(p), cartes: cartesPanneau(Q.panneau(p), p) });
    const diffuser = p => montrerPanneauAuxJoueurs(donneesPanneau(p));
    const nouveauPanneau = () => ({ id: 'pan-' + identifiant().slice(0, 8), titre: '', factions: [], importances: [], quetes: [], niveau_min: null, niveau_max: null, niveau_affiche: 'niveau', statuts: ['proposees'] });

    // « Diffuser » du widget : le panneau à montrer, dans un menu ; sans panneau, la fenêtre pour en créer un.
    function choisirEtDiffuser(ancre) {
      const liste = Q.panneaux();
      if (!liste.length) { ouvrirPanneaux(); return; }
      ouvrirMenu(ancre, [
        ...liste.map(p => [Q.titrePanneau(p), `${Q.panneau(p).length} quête(s) : le montrer sur l'écran des joueurs`, () => diffuser(p)]),
        ['Gérer les panneaux…', 'Créer, modifier ou supprimer un panneau', () => ouvrirPanneaux()],
      ], 'Quel panneau diffuser ?');
    }

    // La fenêtre des panneaux : choisir un panneau (ou en créer un), le régler (titre, donneurs, importances, niveaux, niveau
    // affiché, ou des quêtes choisies), l'aperçu tel que le verront les joueurs ; « Enregistrer », « Diffuser » (qui enregistre).
    function ouvrirPanneaux(idChoisi = null) {
      const liste = structuredClone(Q.panneaux());
      if (!liste.length) liste.push(nouveauPanneau());
      let r = liste.find(p => p.id === idChoisi) || liste[0];
      const corpsP = h('div', { class: 'cm-pile cm-config' });
      const apercu = h('div', { class: 'cm-quetes-apercu', 'aria-label': 'Aperçu du panneau, tel que le verront les joueurs' });
      const nb = h('p', { class: 'ui-s cm-sourdine' });
      const majApercu = () => {
        for (const k of ['factions', 'quetes', 'importances']) r[k] ||= [];
        const vues = Q.panneau(r);
        nb.textContent = `${vues.length} quête${vues.length > 1 ? 's' : ''} sur ce panneau${r.quetes.length ? ' (choisies une à une)' : ''}.`;
        const infos = ecranPanneauInfos();
        const portrait = (infos.rotation(r.id) || 0) % 180 !== 0;
        apercu.style.setProperty('--rapport', String(portrait ? 1 / infos.rapport : infos.rapport));
        apercu.classList.toggle('est-portrait', portrait);
        // Dessiné à la taille d'une TV en 1080p (1 920 px de large en paysage), puis réduit : les tailles de texte minimales
        // ne faussent pas la mise en page d'un petit aperçu.
        const L = portrait ? 1080 : 1920, H = Math.round(portrait ? 1080 * infos.rapport : 1920 / infos.rapport);
        // Un cadre à la taille de l'écran (le conteneur du panneau, comme la projection chez les joueurs), réduit d'un coup.
        const vue = h('div', { class: 'cm-quetes-apercu__ecran', style: { width: L + 'px', height: H + 'px' } }, rendrePanneau(donneesPanneau(r)));
        apercu.replaceChildren(vue);
        caler();
      };
      const caler = () => { const vue = apercu.firstElementChild; if (vue && apercu.clientWidth) vue.style.transform = `scale(${apercu.clientWidth / parseFloat(vue.style.width)})`; };
      new ResizeObserver(caler).observe(apercu);
      function dessiner() {
        for (const k of ['factions', 'quetes', 'importances']) r[k] ||= [];
        const caseListe = (cle, val, lib) => h('label', { class: 'cm-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: r[cle].includes(val),
          onchange: e => { r[cle] = e.target.checked ? [...r[cle], val] : r[cle].filter(x => x !== val); majApercu(); } }), h('span', {}, lib));
        const choixPanneau = h('select', { class: 'bn-select', 'aria-label': 'Panneau', onchange: e => { r = liste.find(p => p.id === e.target.value) || r; dessiner(); } },
          liste.map(p => h('option', { value: p.id, selected: p === r }, Q.titrePanneau(p))));
        const titre = h('input', { class: 'bn-input', type: 'text', value: r.titre || '', placeholder: 'Quêtes proposées',
          oninput: e => { r.titre = e.target.value; choixPanneau.selectedOptions[0].textContent = Q.titrePanneau(r); majApercu(); } });
        const nombre = (cle, label) => h('input', { class: 'bn-input bn-input--nombre', type: 'number', min: '1', max: '20', value: r[cle] ?? '', 'aria-label': label,
          oninput: e => { const v = Math.round(+e.target.value); r[cle] = v >= 1 ? v : null; majApercu(); } });
        const affiche = h('select', { class: 'bn-select', 'aria-label': 'Niveau affiché', onchange: e => { r.niveau_affiche = e.target.value; majApercu(); } },
          NIVEAUX_AFFICHES.map(([val, lib]) => h('option', { value: val, selected: val === (r.niveau_affiche || 'niveau') }, lib)));
        const fond = h('select', { class: 'bn-select', 'aria-label': 'Fond du panneau', onchange: e => { r.fond = e.target.value; majApercu(); } },
          fondsPossibles().map(([val, lib]) => h('option', { value: val, selected: val === (r.fond || 'charte') }, lib)));
        const factionsAvecQuetes = [...new Set(Q.tous().map(x => x.q.faction).filter(Boolean))].map(id => [id, Q.nomFaction(id)]);
        const proposees = Q.tous().filter(x => !x.cachee && dansStatuts(x, r.statuts?.length ? r.statuts : ['proposees'], { panneau: true }));
        corpsP.replaceChildren(...[
          h('div', { class: 'cm-quetes-panneaux__choix' },
            h('span', { class: 'bn-champ__label' }, 'Panneau'), choixPanneau,
            bouton('', { icone: 'lu-plus', classe: 'bn-btn--s bn-btn--fantome', titre: 'Nouveau panneau', onclick: () => { r = nouveauPanneau(); liste.push(r); dessiner(); setTimeout(() => corpsP.querySelector('input.bn-input')?.focus(), 0); } }),
            bouton('', { icone: 'lu-copy', classe: 'bn-btn--s bn-btn--fantome', titre: 'Dupliquer ce panneau', onclick: () => { r = { ...structuredClone(r), id: nouveauPanneau().id, titre: `${Q.titrePanneau(r)} (copie)` }; liste.push(r); dessiner(); } }),
            bouton('', { icone: 'lu-trash-2', classe: 'bn-btn--s bn-btn--fantome', titre: 'Supprimer ce panneau (à l\'enregistrement)', onclick: () => {
              liste.splice(liste.indexOf(r), 1);
              if (!liste.length) liste.push(nouveauPanneau());
              r = liste[0]; dessiner();
            } })),
          h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Titre du panneau'), titre),
          h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Quêtes montrées'), casesStatuts(r.statuts?.length ? r.statuts : ['proposees'], g => { r.statuts = g; dessiner(); })),
          factionsAvecQuetes.length ? h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Donneurs (aucun coché : tous)'), h('div', { class: 'cm-quetes-cases' }, factionsAvecQuetes.map(([id, nom]) => caseListe('factions', id, nom)))) : null,
          h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Importances (aucune cochée : toutes)'), h('div', { class: 'cm-quetes-cases' }, Object.keys(IMPORTANCES).map(k => caseListe('importances', k, Q.importance(k).libelle)))),
          h('div', { class: 'bn-ligne-champs' },
            h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Niveau optimal des quêtes'), h('div', { class: 'cm-phrase' }, h('span', {}, 'de'), nombre('niveau_min', 'Niveau optimal minimum'), h('span', {}, 'à'), nombre('niveau_max', 'Niveau optimal maximum'))),
            h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Les joueurs voient'), affiche),
            h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Fond'), fond)),
          proposees.length ? h('details', { class: 'cm-repli', open: r.quetes.length > 0 }, h('summary', { class: 'etiquette' }, 'Ou choisir les quêtes une à une'),
            h('div', { class: 'cm-quetes-cases' }, proposees.map(x => caseListe('quetes', x.id, x.nom)))) : null,
          h('p', { class: 'ui-s cm-sourdine' }, 'Jamais sur un panneau : les quêtes verrouillées, celles cachées aux joueurs (œil de leur fenêtre), la note du MJ, les récompenses cachées. La difficulté se lit d\'après le niveau du groupe au moment de la diffusion.'),
          nb, apercu,
        ].filter(Boolean));
        majApercu();
      }
      dessiner();
      const enregistrer = () => Q.ecrirePanneaux(liste.map(p => ({ ...p, titre: (p.titre || '').trim() })));
      let dlg;
      dlg = dialogue('Écran des joueurs', 'Panneaux des quêtes', corpsP, h('div', { class: 'bn-groupe' },
        bouton('Diffuser', { classe: 'bn-btn--primaire', icone: 'lu-cast', titre: 'Enregistrer, puis montrer ce panneau sur l\'écran des joueurs (par-dessus ce qu\'il y a ; « Retirer » dans le widget de l\'écran)', disabled: !ecranJoueursActif(), onclick: () => { enregistrer(); diffuser(r); dlg.close(); } }),
        bouton('Enregistrer', { icone: 'lu-check', titre: 'Enregistrer les panneaux, sans rien montrer', onclick: () => { enregistrer(); dlg.close(); } }),
        bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })), { large: true });
    }

    function rendre() {
      const haut = corps.scrollTop;
      majResume();
      btnFiltres.hidden = !quetesActives();
      if (!quetesActives()) {
        corps.replaceChildren(alerte('cierge', 'lu-power', 'Quêtes désactivées pour cette campagne',
          'Les quêtes sont une option de campagne (fenêtre Campagne, onglet « Quêtes et réputation »).', ' ',
          bouton('Activer les quêtes', { classe: 'bn-btn--s', icone: 'lu-check', onclick: () => Q.ecrireReglages({ actif: true }) })));
        return;
      }
      if (filtresVisibles) dessinerFiltres();
      rendreListe();
      corps.replaceChildren(...[
        Q.donneesPresentes ? null : h('p', { class: 'ui-s cm-sourdine' }, 'Pas de data/quetes.json : seulement les quêtes créées ici (« + Quête »). Le catalogue s\'écrit à la main ou avec votre agent IA de campagne (formats/quetes.md).'),
        filtres,
        liste,
        h('div', { class: 'cm-contexte' },
          bouton('Quête', { icone: 'lu-plus', classe: 'bn-btn--s', titre: 'Créer une quête simple', onclick: () => Q.nouvelle() }),
          ecranJoueursActif() ? bouton('Panneaux', { icone: 'lu-layout-grid', classe: 'bn-btn--s bn-btn--fantome', titre: 'Les panneaux des quêtes de l\'écran des joueurs : en créer, les modifier', onclick: () => ouvrirPanneaux() }) : null,
          ecranJoueursActif() ? bouton('Diffuser', { icone: 'lu-cast', classe: 'bn-btn--s bn-btn--fantome', titre: 'Montrer un panneau des quêtes sur l\'écran des joueurs : lequel ?', onclick: e => choisirEtDiffuser(e.currentTarget) }) : null,
          compteur),
      ].filter(Boolean));
      corps.scrollTop = haut;
    }

    majFiltres();
    rendre();
    Q.s.abonner(rendre);
    Q.sCampagne.abonner(rendre);
    // Le niveau du groupe (relevé D&D Beyond) change la difficulté : relu de temps en temps, tant que le widget est là.
    const minuterie = setInterval(async () => {
      if (!corps.isConnected) { clearInterval(minuterie); return; }
      if (await Q.rafraichirNiveau()) rendre();
    }, 30000);
    return {};
  },
};
