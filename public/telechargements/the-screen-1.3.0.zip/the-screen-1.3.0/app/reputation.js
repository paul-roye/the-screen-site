// Réputation du groupe auprès des factions (demande du MJ, 2026-11-11) : une option de campagne, réglée dans la fenêtre Campagne
// (onglet « Quêtes et réputation » : `reputation` de etat/campagne.json), et son suivi dans etat/reputation.json (formats/etat.md).
// Échelle de −1000 à +1000 par défaut, en rangs nommés (sept par défaut) que le MJ renomme, redécoupe et décrit : chaque rang dit
// ce qu'il provoque, en général ou pour une faction précise. Le MJ voit toujours le nombre et le rang ; les joueurs, selon le
// réglage (rang, nombre ou rien). Chaque changement est noté au journal, avec son motif (une quête, la main du MJ).
// Partagé : fiche d'une faction et widget Factions, quêtes (récompenses et conditions), fin de session, écran des joueurs.

import { h, bouton, alerte, infobulle, identifiant } from './ui.js';
import { etatHorloge, horlogeEnService, maintenant, libelleMoment } from './horloge.js';

export const BORNES = { min: -1000, max: 1000 };
export const RANGS_DEFAUT = [
  { id: 'hai', nom: 'Haï', min: -1000, couleur: 'abysse', description: 'La faction veut la perte des héros : elle les chasse, les dénonce, refuse tout marché.' },
  { id: 'hostile', nom: 'Hostile', min: -600, couleur: 'sang', description: 'Les portes se ferment, les prix doublent, les menaces sont ouvertes.' },
  { id: 'mefiant', nom: 'Méfiant', min: -250, couleur: 'cierge', description: 'On les surveille, on leur parle peu, on vérifie ce qu\'ils disent.' },
  { id: 'neutre', nom: 'Neutre', min: -50, couleur: 'cendre', description: 'Des inconnus comme les autres.' },
  { id: 'apprecie', nom: 'Apprécié', min: 50, couleur: 'brume', description: 'On les écoute, on leur confie de petites affaires.' },
  { id: 'honore', nom: 'Honoré', min: 250, couleur: 'mousse', description: 'On leur ouvre les portes, on leur confie des missions sérieuses.' },
  { id: 'exalte', nom: 'Exalté', min: 600, couleur: 'ultra', description: 'Des héros pour la faction : sa protection, ses secrets, ses meilleures quêtes.' },
];
export const COULEURS = [['sang', 'Rouge'], ['cierge', 'Orange'], ['soleil', 'Jaune'], ['mousse', 'Vert'], ['brume', 'Bleu'], ['ultra', 'Violet'], ['cendre', 'Gris'], ['os', 'Blanc'], ['abysse', 'Noir']];
// La couleur d'un rang en texte ou en liseré : l'abysse (rouge presque noir, en aplat seulement) s'écrit en sang.
export const teinte = c => (c === 'abysse' ? 'sang' : c);
export const VUES_JOUEURS = [['rang', 'Le rang'], ['nombre', 'Le rang et le nombre'], ['rien', 'Rien']];

let sC = null, sR = null, sH = null;
let promesse = null;
// Ouvert une fois pour toute la page : etat/campagne.json (les réglages) et etat/reputation.json (les valeurs, le journal).
export function chargerReputation(etat) {
  promesse ||= (async () => {
    sC = await etat('campagne', { schema: 1 });
    sR = await etat('reputation', { schema: 1, valeurs: {}, journal: [] });
    sR.valeur.valeurs ||= {};
    sR.valeur.journal ||= [];
    sH = await etatHorloge(etat);
    return { sC, sR };
  })();
  return promesse;
}
export const reputationChargee = () => !!sR;
// Redessiner quand la réputation ou ses réglages changent (fn appelée sans argument). Renvoie de quoi se désabonner.
export function surReputation(fn) {
  if (!sR) return () => {};
  const a = sR.abonner(fn), b = sC.abonner(fn);
  return () => { a(); b(); };
}
const prevenir = () => { sR.signaler(); sC.signaler(); };

export const reputationActive = () => !!sC?.valeur.reputation?.actif;

// Les rangs valides, du plus bas au plus haut : un `id`, un nom, un min entier (le premier part toujours de la borne basse).
function rangsValides(liste, min) {
  const ok = Array.isArray(liste) ? liste.filter(r => r && r.id && r.nom && Number.isFinite(+r.min)).map(r => ({ ...r, min: +r.min })) : [];
  const rangs = (ok.length ? ok : RANGS_DEFAUT).slice().sort((a, b) => a.min - b.min);
  return rangs.map((r, i) => (i === 0 ? { ...r, min } : r));
}
export function reglagesReputation() {
  const r = sC?.valeur.reputation || {};
  const min = Number.isFinite(+r.min) && r.min !== null && r.min !== '' ? +r.min : BORNES.min;
  const max = Number.isFinite(+r.max) && r.max !== null && r.max !== '' && +r.max > min ? +r.max : Math.max(BORNES.max, min + 1);
  return { actif: !!r.actif, min, max, rangs: rangsValides(r.rangs, min), factions: Array.isArray(r.factions) ? r.factions : null, joueurs: VUES_JOUEURS.some(([v]) => v === r.joueurs) ? r.joueurs : 'rang', descriptions: r.descriptions || {} };
}
function ecrireReglages(patch) {
  sC.valeur.reputation = { ...(sC.valeur.reputation || {}), ...patch };
  sC.enregistrer(0);
  prevenir();
}

// Une faction est-elle suivie ? (`factions` du réglage ; null : toutes, sauf les secrètes)
export function factionSuivie(f) {
  const r = reglagesReputation();
  return r.factions ? r.factions.includes(f.id) : !f.secret;
}

export const valeurDe = faction => sR?.valeur.valeurs?.[faction] ?? 0;
export function rangDe(valeur) {
  const rs = reglagesReputation().rangs;
  return [...rs].reverse().find(r => valeur >= r.min) || rs[0];
}
export const rangParId = id => reglagesReputation().rangs.find(r => r.id === id) || null;
export const rangDeFaction = faction => rangDe(valeurDe(faction));
// Ce que provoque un rang auprès d'une faction : sa description propre, sinon celle du rang.
export function descriptionRang(faction, rang) {
  return reglagesReputation().descriptions?.[faction]?.[rang.id] || rang.description || '';
}
export const descriptionPropre = (faction, rang) => reglagesReputation().descriptions?.[faction]?.[rang.id] || '';
export function ecrireDescription(faction, rangId, texte) {
  const d = structuredClone(reglagesReputation().descriptions || {});
  const propre = String(texte || '').trim();
  d[faction] ||= {};
  if (propre) d[faction][rangId] = propre; else delete d[faction][rangId];
  if (!Object.keys(d[faction]).length) delete d[faction];
  ecrireReglages({ descriptions: d });
}

const borner = v => { const r = reglagesReputation(); return Math.max(r.min, Math.min(r.max, Math.round(v))); };
// Changer la réputation : delta (positif ou négatif), motif, quete (id) et recompense (rang dans ses récompenses), au journal.
// Renvoie l'entrée du journal (null si rien n'a bougé : déjà à la borne).
export function ajuster(faction, delta, { motif = '', quete = null, recompense = null } = {}) {
  if (!sR || !faction || !Number.isFinite(+delta) || !+delta) return null;
  const avant = valeurDe(faction);
  const apres = borner(avant + +delta);
  const e = { id: identifiant(), quand: new Date().toISOString(), faction, avant, apres, motif: String(motif || '').trim() };
  if (horlogeEnService() && sH) e.horloge = maintenant(sH.valeur);
  if (quete) e.quete = quete;
  if (recompense != null) e.recompense = recompense;
  sR.valeur.valeurs[faction] = apres;
  sR.valeur.journal.push(e);
  sR.enregistrer(0);
  prevenir();
  return e;
}
// Régler la valeur directement (le MJ corrige) : noté au journal comme un changement.
export const definir = (faction, valeur, motif = 'Réglée par le MJ') => ajuster(faction, borner(valeur) - valeurDe(faction), { motif });
// Retirer une ligne du journal : la réputation revient de la différence (bornée).
export function retirerLigne(id) {
  const i = sR?.valeur.journal.findIndex(e => e.id === id) ?? -1;
  if (i < 0) return false;
  const [e] = sR.valeur.journal.splice(i, 1);
  sR.valeur.valeurs[e.faction] = borner(valeurDe(e.faction) - (e.apres - e.avant));
  sR.enregistrer(0);
  prevenir();
  return true;
}
// La ligne du journal qu'une récompense de quête a donnée (pour la défaire en décochant).
export const ligneDeRecompense = (quete, recompense) => sR?.valeur.journal.find(e => e.quete === quete && e.recompense === recompense) || null;
export const journal = () => sR?.valeur.journal || [];

// ───── Affichage ─────

// Badge du rang, à sa couleur ; le nombre à côté si `nombre`.
export function badgeRang(faction, { nombre = true } = {}) {
  const v = valeurDe(faction), r = rangDe(v);
  return infobulle(h('span', { class: `cm-rep-badge cm-rep--${r.couleur}` }, h('span', {}, r.nom), nombre ? h('span', { class: 'cm-rep-badge__n' }, signe(v)) : null),
    descriptionRang(faction, r) || r.nom, { titre: `${r.nom} (${signe(v)})`, ton: r.couleur === 'abysse' ? 'abysse' : undefined });
}
export const signe = v => (v > 0 ? `+${v}` : String(v));

// La jauge : l'échelle de min à max, chaque rang à sa couleur et à sa largeur, le curseur à la valeur.
export function jaugeReputation(faction) {
  const r = reglagesReputation(), v = valeurDe(faction), rang = rangDe(v);
  const etendue = r.max - r.min;
  const pc = x => `${((x - r.min) / etendue) * 100}%`;
  const zones = r.rangs.map((x, i) => {
    const fin = r.rangs[i + 1]?.min ?? r.max;
    return h('span', { class: `cm-rep-jauge__zone cm-rep--${x.couleur}` + (x.id === rang.id ? ' est-actif' : ''), style: { left: pc(x.min), width: `calc(${pc(fin)} - ${pc(x.min)})` }, title: `${x.nom} : de ${signe(x.min)} à ${signe(fin)}` });
  });
  return h('div', { class: 'cm-rep-jauge', role: 'img', 'aria-label': `Réputation : ${rang.nom}, ${signe(v)} sur une échelle de ${signe(r.min)} à ${signe(r.max)}` },
    h('div', { class: 'cm-rep-jauge__barre' }, zones, h('span', { class: 'cm-rep-jauge__curseur', style: { left: pc(v) } })),
    h('div', { class: 'cm-rep-jauge__bornes ui-s cm-sourdine' }, h('span', {}, signe(r.min)), h('span', {}, '0'), h('span', {}, signe(r.max))));
}

// Le bloc de la fiche d'une faction : rang, jauge, ce que provoque le rang (modifiable pour cette faction), changer la valeur, et
// les derniers changements. surQuete(id) : ouvrir la quête d'une ligne du journal.
export function blocReputation(f, { surQuete = null } = {}) {
  const el = h('div', { class: 'cm-rep-bloc cm-pile' });
  function rendre() {
    const v = valeurDe(f.id), rang = rangDe(v);
    const montant = h('input', { class: 'bn-input bn-input--nombre', type: 'number', step: '5', placeholder: '+25', 'aria-label': 'Réputation gagnée ou perdue' });
    const motif = h('input', { class: 'bn-input', type: 'text', placeholder: 'Motif (facultatif)', 'aria-label': 'Motif du changement' });
    const appliquer = () => { const n = Math.round(+montant.value); if (n) ajuster(f.id, n, { motif: motif.value || 'Décision du MJ' }); };
    montant.addEventListener('keydown', e => { if (e.key === 'Enter') appliquer(); });
    motif.addEventListener('keydown', e => { if (e.key === 'Enter') appliquer(); });
    const propre = descriptionPropre(f.id, rang);
    const texte = descriptionRang(f.id, rang);
    let edition = false;
    const zoneDesc = h('div', { class: 'cm-rep-desc' });
    const dessinerDesc = () => {
      if (edition) {
        const champ = h('textarea', { class: 'bn-textarea', rows: 3, placeholder: rang.description || 'Ce que provoque ce rang auprès de cette faction', 'aria-label': `Ce que provoque le rang ${rang.nom} auprès de ${f.nom}` }, propre);
        zoneDesc.replaceChildren(champ, h('div', { class: 'bn-groupe' },
          bouton('Enregistrer', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check', onclick: () => { edition = false; ecrireDescription(f.id, rang.id, champ.value); } }),
          bouton('Annuler', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { edition = false; dessinerDesc(); } })));
        setTimeout(() => champ.focus(), 0);
      } else {
        zoneDesc.replaceChildren(h('p', { class: 'ui-s' + (texte ? '' : ' cm-sourdine') }, texte || 'Pas de description pour ce rang.',
          propre ? h('span', { class: 'cm-sourdine' }, ' (propre à cette faction)') : null),
        bouton('', { icone: 'lu-pencil', classe: 'bn-btn--s bn-btn--fantome', titre: `Ce que provoque le rang ${rang.nom} auprès de ${f.nom}`, onclick: () => { edition = true; dessinerDesc(); } }));
      }
    };
    dessinerDesc();
    const lignes = journal().filter(e => e.faction === f.id).slice(-5).reverse();
    el.replaceChildren(
      h('div', { class: 'cm-rep-tete' }, badgeRang(f.id), h('span', { class: 'ui-s cm-sourdine' }, `${signe(v)} / ${signe(reglagesReputation().max)}`)),
      jaugeReputation(f.id),
      zoneDesc,
      h('div', { class: 'cm-rep-ajuster' }, montant, motif, bouton('', { icone: 'lu-check', classe: 'bn-btn--s', titre: 'Appliquer ce changement de réputation', onclick: appliquer })),
      lignes.length ? h('ul', { class: 'cm-rep-journal' }, lignes.map(e => ligneJournal(e, { surQuete }))) : null);
  }
  const stop = surReputation(() => { if (el.isConnected) rendre(); else stop(); });
  rendre();
  return el;
}

// Une ligne du journal : le changement, son motif, quand ; une croix la retire (la réputation revient d'autant).
export function ligneJournal(e, { surQuete = null, nomFaction = null } = {}) {
  const d = e.apres - e.avant;
  const quand = e.horloge ? libelleMoment(e.horloge) : new Date(e.quand).toLocaleDateString('fr-FR');
  return h('li', { class: 'cm-rep-ligne' },
    h('span', { class: 'cm-rep-ligne__delta ' + (d >= 0 ? 'est-gain' : 'est-perte') }, signe(d)),
    h('span', { class: 'ui-s cm-rep-ligne__motif' }, nomFaction ? h('b', {}, nomFaction(e.faction), ' · ') : null,
      e.quete && surQuete ? h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => surQuete(e.quete) }, e.motif || 'Quête') : (e.motif || '—'),
      h('span', { class: 'cm-sourdine' }, ` · ${quand}`)),
    bouton('', { icone: 'lu-x', classe: 'bn-btn--s bn-btn--fantome', titre: 'Retirer cette ligne : la réputation revient d\'autant', onclick: () => retirerLigne(e.id) }));
}

// ───── Réglages (fenêtre Campagne, onglet « Quêtes et réputation ») ─────
// factions : la liste de factions.json (pour choisir celles qui sont suivies).
export function contenuReglagesReputation({ factions = [] } = {}) {
  const el = h('div', { class: 'cm-pile' });
  function rendre() {
    const r = reglagesReputation();
    const actif = h('input', { type: 'checkbox', class: 'bn-case', checked: r.actif, onchange: e => ecrireReglages({ actif: e.target.checked }) });
    const nombre = (val, onchange, label) => h('input', { class: 'bn-input bn-input--nombre', type: 'number', step: '1', value: val, 'aria-label': label, onchange });
    const bornes = h('div', { class: 'cm-phrase' }, h('span', {}, 'De'), nombre(r.min, e => { const v = Math.round(+e.target.value); if (Number.isFinite(v) && v < r.max) ecrireReglages({ min: v }); else rendre(); }, 'Borne basse'),
      h('span', {}, 'à'), nombre(r.max, e => { const v = Math.round(+e.target.value); if (Number.isFinite(v) && v > r.min) ecrireReglages({ max: v }); else rendre(); }, 'Borne haute'));
    // Les rangs : nom, à partir de, couleur, ce qu'il provoque ; ajouter, retirer, revenir aux rangs par défaut.
    const ecrireRangs = rs => ecrireReglages({ rangs: rs });
    const rangs = r.rangs.map(x => ({ ...x }));
    const ligneRang = (x, i) => h('div', { class: 'cm-rep-reglage-rang' },
      h('span', { class: `cm-rep-pastille cm-rep--${x.couleur}`, 'aria-hidden': 'true' }),
      h('input', { class: 'bn-input', type: 'text', value: x.nom, 'aria-label': 'Nom du rang', onchange: e => { rangs[i].nom = e.target.value.trim() || x.nom; ecrireRangs(rangs); } }),
      i === 0 ? h('span', { class: 'ui-s cm-sourdine cm-rep-reglage-rang__min' }, `dès ${signe(r.min)}`)
        : h('input', { class: 'bn-input bn-input--nombre', type: 'number', step: '1', value: x.min, 'aria-label': `Le rang ${x.nom} commence à`, onchange: e => { const v = Math.round(+e.target.value); if (Number.isFinite(v) && v > r.min && v < r.max) { rangs[i].min = v; ecrireRangs(rangs); } else rendre(); } }),
      h('select', { class: 'bn-select', 'aria-label': 'Couleur', onchange: e => { rangs[i].couleur = e.target.value; ecrireRangs(rangs); } }, COULEURS.map(([c, lib]) => h('option', { value: c, selected: c === x.couleur }, lib))),
      bouton('', { icone: 'lu-trash-2', classe: 'bn-btn--s bn-btn--fantome', titre: `Retirer le rang ${x.nom}`, disabled: rangs.length <= 2, onclick: () => { rangs.splice(i, 1); ecrireRangs(rangs); } }),
      h('textarea', { class: 'bn-textarea cm-rep-reglage-rang__desc', rows: 1, placeholder: 'Ce que provoque ce rang', 'aria-label': `Ce que provoque le rang ${x.nom}`, onchange: e => { rangs[i].description = e.target.value.trim(); ecrireRangs(rangs); } }, x.description || ''));
    const ajouterRang = () => {
      const haut = rangs.at(-1);
      const min = Math.min(r.max - 1, Math.round((haut.min + r.max) / 2));
      rangs.push({ id: 'rang-' + identifiant().slice(0, 6), nom: 'Nouveau rang', min, couleur: 'os', description: '' });
      ecrireRangs(rangs);
    };
    // Factions suivies : toutes (sauf les secrètes) d'office, ou une liste.
    const toutes = r.factions === null;
    const cases = factions.map(f => h('label', { class: 'cm-case' },
      h('input', { type: 'checkbox', class: 'bn-case', checked: toutes ? !f.secret : r.factions.includes(f.id), disabled: toutes,
        onchange: e => ecrireReglages({ factions: [...new Set([...(r.factions || []).filter(x => x !== f.id), ...(e.target.checked ? [f.id] : [])])] }) }),
      h('span', {}, f.nom, f.secret ? h('span', { class: 'cm-sourdine' }, ' (secrète)') : null)));
    const zone = h('div', { class: 'cm-reglage__sous cm-pile' + (r.actif ? '' : ' est-eteint') },
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Échelle'), bornes),
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Rangs, du plus bas au plus haut'),
        h('div', { class: 'cm-pile cm-rep-reglage-rangs' }, rangs.map(ligneRang)),
        h('div', { class: 'bn-groupe' },
          bouton('Rang', { icone: 'lu-plus', classe: 'bn-btn--s bn-btn--fantome', titre: 'Ajouter un rang au-dessus du plus haut', onclick: ajouterRang }),
          bouton('Rangs par défaut', { icone: 'lu-rotate-ccw', classe: 'bn-btn--s bn-btn--fantome', titre: 'Revenir aux sept rangs par défaut (Haï, Hostile, Méfiant, Neutre, Apprécié, Honoré, Exalté)', onclick: () => ecrireReglages({ rangs: null }) })),
        h('span', { class: 'ui-s cm-sourdine' }, 'Ce que provoque un rang auprès d\'une faction précise se règle dans la fiche de la faction (crayon sous sa jauge).')),
      h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Ce que voient les joueurs (écran des joueurs)'),
        h('select', { class: 'bn-select', onchange: e => ecrireReglages({ joueurs: e.target.value }) }, VUES_JOUEURS.map(([v, lib]) => h('option', { value: v, selected: v === r.joueurs }, lib))),
        h('span', { class: 'ui-s cm-sourdine' }, 'Le MJ voit toujours le rang et le nombre.')),
      factions.length ? h('div', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Factions suivies'),
        h('label', { class: 'cm-case' }, h('input', { type: 'checkbox', class: 'bn-case', checked: toutes, onchange: e => ecrireReglages({ factions: e.target.checked ? null : factions.filter(f => !f.secret).map(f => f.id) }) }),
          h('span', {}, h('b', {}, 'Toutes'), h('span', { class: 'cm-sourdine' }, ' (sauf les secrètes)'))),
        h('div', { class: 'cm-rep-reglage-factions' }, cases)) : h('p', { class: 'ui-s cm-sourdine' }, 'Pas encore de data/factions.json : la réputation se suit faction par faction.'));
    zone.inert = !r.actif;
    el.replaceChildren(h('div', { class: 'cm-reglage' },
      h('label', { class: 'cm-case' }, actif, h('span', {}, h('b', {}, 'Réputation auprès des factions'), h('br'),
        h('span', { class: 'ui-s cm-sourdine' }, 'La réputation du groupe auprès de chaque faction, d\'une borne à l\'autre, en rangs qui disent ce qu\'ils provoquent : dans la fiche des factions, les récompenses et les conditions des quêtes, la fin de session et, selon votre choix, l\'écran des joueurs.'))),
      zone));
  }
  const stop = surReputation(() => { if (el.isConnected) rendre(); else stop(); });
  rendre();
  return el;
}

// Alerte quand la réputation est coupée, là où on en aurait besoin (rien sinon).
export const alerteReputationCoupee = () => (reputationActive() ? null
  : alerte('cierge', 'lu-power', 'Réputation désactivée', 'Activez-la dans la fenêtre Campagne, onglet « Quêtes et réputation ».'));

// Pour la fin de session : les changements depuis une date (ISO), par faction. nomFaction(id) -> nom.
export function resumeSession(depuis, nomFaction) {
  if (!reputationActive() || !sR) return [];
  const lignes = journal().filter(e => !depuis || e.quand > depuis);
  const parFaction = new Map();
  for (const e of lignes) { if (!parFaction.has(e.faction)) parFaction.set(e.faction, []); parFaction.get(e.faction).push(e); }
  const res = [];
  for (const [f, es] of parFaction) {
    const v = valeurDe(f), r = rangDe(v);
    res.push(`${nomFaction(f)} : ${signe(es.reduce((a, e) => a + e.apres - e.avant, 0))} (${es.map(e => `${signe(e.apres - e.avant)} ${e.motif || ''}`.trim()).join(' ; ')}), maintenant ${r.nom} (${signe(v)}).`);
  }
  return res;
}
// Toutes les factions suivies avec leur rang (fin de session : état actuel).
export function etatSession(factions) {
  if (!reputationActive() || !sR) return [];
  return factions.filter(factionSuivie).map(f => { const v = valeurDe(f.id); return `${f.nom} : ${rangDe(v).nom} (${signe(v)})`; });
}
