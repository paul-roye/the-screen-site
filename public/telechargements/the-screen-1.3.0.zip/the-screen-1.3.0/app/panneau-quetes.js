// Un panneau des quêtes pour l'écran des joueurs (2026-11-11 ; refait le 2026-11-12, retours du MJ) : une vue de la page
// joueurs, comme le tableau des joueurs, plutôt qu'une image dessinée. Il suit ainsi la charte de la campagne (fond, titre,
// polices, coins), et se met en page selon sa forme : tourné en portrait, ses cartes passent sur une ou deux colonnes.
// Seulement ce que les joueurs peuvent lire : le titre, qui la donne, l'importance (sa couleur), le niveau ou la difficulté
// selon le réglage du panneau, l'annonce, les objectifs et les récompenses qui ne sont pas cachées ; la réputation du donneur
// selon le réglage (rang, nombre ou rien).
//
// donnees : { titre, cartes: [{ nom, donneur, rang? ({ nom, couleur, nombre? }), couleur (jeton de l'importance), importance
// (libellé), niveau? ({ texte, couleur? }), description, objectifs[], recompenses[] (libellés), recompensesCachees }] }.
// Sérialisable : il part tel quel par le canal de la page joueurs. rendrePanneau() le dessine, chez les joueurs et dans les
// aperçus du MJ (le même code).

import { h } from './ui.js';

// Deux rangées de quatre en paysage, quatre de deux en portrait.
export const MAX_CARTES = 8;
// Une couleur d'importance en texte ou en liseré : l'abysse (rouge presque noir) se lit en sang.
const teinte = c => (c === 'abysse' ? 'sang' : c || 'cendre');

// L'angle et le clou d'un post-it : au hasard, mais tirés de l'id de la quête (retour du MJ, 2026-11-12 : des angles
// différents, et qui ne changent pas d'un affichage à l'autre). Entre −2° et +2°, jamais presque droit.
function graine(q) {
  let x = 2166136261;
  for (const c of String(q.id || q.nom || '')) x = Math.imul(x ^ c.charCodeAt(0), 16777619);
  return x >>> 0;
}
const angleDe = q => { const g = graine(q); const a = 0.5 + (g % 1500) / 1000; return Math.round((g & 0x10000 ? a : -a) * 100) / 100; };
const clouDe = q => 1 + (Math.floor(graine(q) / 7) % 4);

export function rendrePanneau(p = {}) {
  const cartes = p.cartes || [];
  const montrees = cartes.slice(0, MAX_CARTES);
  // Une quête prise ou terminée (si le panneau les montre) porte un tampon de son statut ; terminée, elle est estompée.
  const carte = q => h('article', { class: 'cm-pq__carte' + (q.statut?.fini ? ' est-finie' : ''), 'data-clou': String(clouDe(q)), style: { '--pq-c': `var(--${teinte(q.couleur)})`, '--pq-angle': `${angleDe(q)}deg` } },
    q.statut ? h('span', { class: 'cm-pq__tampon', style: { '--pq-t': `var(--${teinte(q.statut.couleur)})` } }, q.statut.texte) : '',
    h('p', { class: 'cm-pq__haut' },
      h('span', {}, q.importance || ''),
      q.niveau?.texte ? h('span', { class: 'cm-pq__niveau', style: q.niveau.couleur ? { color: `var(--${q.niveau.couleur})` } : null }, q.niveau.texte) : ''),
    h('h2', { class: 'cm-pq__nom' }, q.nom),
    h('p', { class: 'cm-pq__donneur' }, q.donneur || '',
      q.rang ? h('span', { style: { color: `var(--${teinte(q.rang.couleur)})` } }, ` · ${q.rang.nom}${q.rang.nombre != null ? ` (${q.rang.nombre})` : ''}`) : ''),
    q.description ? h('p', { class: 'cm-pq__texte' }, q.description) : '',
    (q.objectifs || []).length ? h('ul', { class: 'cm-pq__objectifs' }, q.objectifs.map(o => h('li', {}, o))) : '',
    q.recompensesCachees ? h('p', { class: 'cm-pq__recompenses' }, 'Récompense à négocier')
      : (q.recompenses || []).length ? h('p', { class: 'cm-pq__recompenses' }, q.recompenses.join(' · ')) : '');
  const zone = montrees.length ? h('div', { class: 'cm-pq__cartes', 'data-n': String(montrees.length) }, montrees.map(carte)) : null;
  // Le fond : celui de la charte, une texture du gestionnaire (data-fond), ou une texture de la bibliothèque (p.texture).
  const el = h('div', { class: 'cm-pq', 'data-fond': p.fond && p.fond !== 'charte' ? p.fond : null, style: p.fond === 'texture' && p.texture ? { '--pq-texture': `url("${p.texture}")` } : null },
    h('p', { class: 'cm-pq__titre bn-neon' }, p.titre || 'Quêtes proposées'),
    zone || h('p', { class: 'cm-pq__vide' }, 'Aucune quête proposée pour le moment.'),
    cartes.length > MAX_CARTES ? h('p', { class: 'cm-pq__suite' }, `… et ${cartes.length - MAX_CARTES} autre${cartes.length - MAX_CARTES > 1 ? 's' : ''} : demandez au MJ.`) : '');
  if (zone) resserrer(el, zone);
  return el;
}

// Trop de texte pour la place (huit quêtes, l'écran en portrait) : on resserre par degrés jusqu'à ce que les post-its tiennent
// (retour du MJ, 2026-11-12 : jamais de débordement) ; 1, le texte en deux lignes et sans objectifs ; 2, sans texte ; 3 et 4,
// les post-its réduits. Refait à chaque changement de taille (la fenêtre des joueurs, l'aperçu du MJ).
const SERRE_MAX = 4;
function resserrer(el, zone) {
  // Les post-its sont centrés dans leur zone : ils débordent en haut comme en bas. Mesuré dans le repère de la zone (offsetTop,
  // offsetHeight : sans la rotation des post-its ni la réduction d'un aperçu), avec un peu de marge.
  const deborde = () => {
    const h = zone.clientHeight;
    return [...zone.children].some(c => c.offsetTop < -2 || c.offsetTop + c.offsetHeight > h + 2) || zone.scrollHeight > h + 2;
  };
  let essais = 0;
  const ajuster = () => {
    if (!el.isConnected || !zone.clientHeight) { if (essais++ < 60) requestAnimationFrame(ajuster); return; }   // pas encore dans la page
    delete el.dataset.serre;
    for (let n = 1; n <= SERRE_MAX && deborde(); n++) el.dataset.serre = String(n);
  };
  new ResizeObserver(() => ajuster()).observe(el);
  requestAnimationFrame(ajuster);
  // Les polices de la charte, chargées après coup, changent la hauteur du texte.
  document.fonts?.addEventListener?.('loadingdone', () => { if (el.isConnected) ajuster(); });
  document.fonts?.ready.then(() => ajuster());
}
