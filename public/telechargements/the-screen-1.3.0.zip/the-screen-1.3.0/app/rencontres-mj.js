// Rencontres du MJ : les préparer (monstres de D&D Beyond, nombres, noms), les lancer dans le widget Combat (mode Rencontre)
// et noter celles qui sont jouées. Trois origines :
// - « prevue » : une rencontre scénarisée de data/rencontres-aleatoires.json (rencontres_scenarisees[]). Son texte vient des
//   données ; le gestionnaire n'y ajoute que la préparation et le statut. Elle ne se supprime pas.
// - « creee » : créée dans le gestionnaire, rattachée à un jalon, une étape, un lieu (et sous-lieu), ou à rien.
// - « aleatoire » : lancée depuis un tirage du widget Rencontres, rattachée au trajet en cours ou au lieu des héros. « Lancer »
//   l'ouvre d'abord en brouillon (`brouillon`) dans la fenêtre de préparation (monstres, difficulté) ; « Lancer le combat »
//   la note au journal des rencontres (le tirage est accepté : numéro, plafond) et la charge dans Combat ; fermer la fenêtre
//   avant, c'est l'abandonner. Annulée ou supprimée, elle sort aussi du journal (defaireRencontre).
// - « maison » : lancée depuis une table d'occupants des maisons (widgets Maisons et Ici, demande du MJ, 2026-10-25), même
//   brouillon puis « Lancer le combat » ; rattachée au lieu de la table, à part des rencontres aléatoires (ni journal, ni plafond).
// Une ligne de rencontre (ligne()) ouvre un petit menu : Ouvrir (fenêtre de préparation), Lancer, Marquer terminée,
// Supprimer. Les créatures des données (noms VF) se relient une fois à un monstre de D&D Beyond : la correspondance sert
// ensuite à toutes les rencontres. Monstres : bestiaire des livres choisis (app/livres-beyond.js), lu par l'extension (commande
// « bestiaire »), gardé un jour dans le navigateur ; fiches complètes à la demande (« monstres »).
// État : etat/rencontres-mj.json (formats/etat.md), qui garde aussi le combat lancé (widget Combat).

import { h, icone, bouton, badge, alerte, section, onglets, blocOriginal, flottant, flottantOuvert, lienFlottant, boutonMenu, identifiant, normaliser, heure, infobulle, FINE } from './ui.js';
import { lancer, estFixe, lisible } from './des.js';
import { chargerLieux, nomLieu, nomComplet, sousLieux, etatIci } from './lieux.js';
import { ouScenarisee, ordreDesScenarisees } from './scenarisees.js';
import { etatHorloge, horlogeEnService, maintenant, libelleMoment, enMinutes } from './horloge.js';
import { derouleSurLeTableau, voirJalon, voirEtape, etatDeroule, statutDe, commencer, terminer, valider } from './trame.js';
import { etatPnj, suiviDe as suiviPnj, etatEffectif } from './fiche-pnj.js';
import { demanderExtension, lireBeyond, aTerre, estMort } from './beyond.js';
import { evaluer, groupeAventuriers, roleDevine, reglerRoles, vueDifficulte, choixRole, badgeDifficulte, majAide, JOURNEE, DIFFICULTES } from './difficulte.js';
import { blocStats, puissanceDe, libellePuissance, typeCourt, modificateur, signe } from './monstres.js';
import { montrerJets } from './lancers.js';
import { chargerLivres, livres, surChangementLivres } from './livres-beyond.js';
import { outilsObjets } from './objets.js';
import { libelleSource, couleurSource } from './campagne.js';
import { etatRencontres, defaireRencontre } from './rencontres-moteur.js';
import { emettre } from './evenements.js';
import { donnerOr, libelleDon, libellePieces } from './or.js';

const FP_FILTRES = [['', 'Tous les FP'], ['0-1', 'FP 0 à 1'], ['2-4', 'FP 2 à 4'], ['5-8', 'FP 5 à 8'], ['9-12', 'FP 9 à 12'], ['13-30', 'FP 13 et plus']];
const PAR_PAGE = 25;
const STATUTS = { 'a-jouer': 'À jouer', 'en-cours': 'En cours', terminee: 'Terminée' };
const DEFAUT = { schema: 1, rencontres: [], correspondances: {}, combat: null };

export const etatRencontresMj = etat => etat('rencontres-mj', DEFAUT);
export const lettre = i => String.fromCharCode(65 + (i % 26)) + (i >= 26 ? Math.floor(i / 26) : '');
// Nom d'un monstre dans le combat : son nom propre, sinon « Zombi B » (une lettre dès qu'il y en a plusieurs).
// Seul dans son groupe : le nom du groupe.
export const nomIndividu = (g, i) => (g.quantite > 1 ? g.noms?.[i]?.trim() || `${g.nom} ${lettre(i)}` : g.nom);
const premiereMajuscule = t => String(t || '').replace(/^./, c => c.toUpperCase());

// ───── Monstres de D&D Beyond (par l'extension) ─────

let promesseConfig = null;
export function configBeyond() {
  promesseConfig ||= demanderExtension({ type: 'config' });
  promesseConfig.catch(() => { promesseConfig = null; });
  return promesseConfig;
}

// Bestiaire des livres choisis (réglage de la campagne, app/livres-beyond.js) : résumé léger de chaque monstre (nom, FP,
// type, CA, PV, images), gardé un jour dans le navigateur (localStorage : propre au poste, se reconstruit tout seul).
const CLE_BESTIAIRE = 'cm:bestiaire';
let promesseBestiaire = null;
surChangementLivres(() => { promesseBestiaire = null; });
export function chargerBestiaire({ forcer = false } = {}) {
  if (promesseBestiaire && !forcer) return promesseBestiaire;
  promesseBestiaire = (async () => {
    const cfg = await configBeyond();
    const sources = livres().ids;
    const homebrew = livres().homebrew_monstres;   // monstres homebrew du MJ (extension 1.11.0)
    let liste = null;
    if (!forcer) {
      try {
        const c = JSON.parse(localStorage.getItem(CLE_BESTIAIRE) || 'null');
        if (c && Date.now() - c.quand < 864e5 && String(c.sources) === String(sources) && !!c.homebrew === homebrew && Array.isArray(c.liste)) liste = c.liste;
      } catch { /* pas de cache */ }
    }
    if (!liste) {
      liste = await demanderExtension({ type: 'bestiaire', sources, homebrew }, 120000);
      try { localStorage.setItem(CLE_BESTIAIRE, JSON.stringify({ quand: Date.now(), sources, homebrew, liste })); } catch { /* cache impossible */ }
    }
    const puissance = new Map((cfg.puissances || []).map(p => [p.id, p]));
    for (const m of liste) { m.cle = normaliser(m.nom); m.valeurFp = puissance.get(m.fp)?.valeur ?? null; }
    return { liste, cfg, parId: new Map(liste.map(m => [m.id, m])) };
  })();
  promesseBestiaire.catch(() => { promesseBestiaire = null; });
  return promesseBestiaire;
}

const fiches = new Map();   // id de monstre -> fiche complète de D&D Beyond
export async function fichesMonstres(ids) {
  const manquantes = [...new Set(ids)].filter(id => id && !fiches.has(id));
  // Par lots de 50 depuis l'extension 1.13.0 ; avant, une fiche par demande : elle envoyait « ids=a,b », que D&D Beyond
  // refuse (400) ; il attend « ids=a&ids=b » (relevé le 2026-10-23).
  const version = String((await lireBeyond()).extension || '0').split('.').map(Number);
  const lots = (version[0] > 1 || (version[0] === 1 && version[1] >= 13))
    ? Array.from({ length: Math.ceil(manquantes.length / 50) }, (_, i) => manquantes.slice(i * 50, i * 50 + 50))
    : manquantes.map(id => [id]);
  (await Promise.all(lots.map(ids => demanderExtension({ type: 'monstres', ids })))).flat().forEach(f => fiches.set(f.id, f));
  return ids.map(id => fiches.get(id) || null);
}
export const ficheConnue = id => fiches.get(id) || null;
// Après la modification d'un monstre sur D&D Beyond (un homebrew) : oublier le bestiaire gardé un jour et les fiches
// gardées jusqu'au rechargement de la page.
export function oublierBeyond() {
  fiches.clear();
  promesseBestiaire = null;
  try { localStorage.removeItem(CLE_BESTIAIRE); } catch { /* pas de cache */ }
}

// Bonus d'initiative d'une fiche : celui de D&D Beyond (monstres 2024), sinon le modificateur de Dextérité.
function bonusInitiative(f) {
  if (!f) return 0;
  if (f.initiativeBonus != null) return f.initiativeBonus;
  const dex = (f.stats || []).find(s => s.statId === 2)?.value;
  return dex ? modificateur(dex) : 0;
}

// Ce que la rencontre garde d'un monstre (affiché sans relire D&D Beyond).
function instantane(f, idx, cfg) {
  return {
    monstre: f?.id ?? idx?.id, nom_beyond: (f?.name || idx?.nom || '').trim(), ca: f?.armorClass || idx?.ca || null,
    pv: f?.averageHitPoints || idx?.pv || 1, fp: (f ? puissanceDe(f, cfg)?.valeur : idx?.valeurFp) ?? null, init: bonusInitiative(f),
    avatar: f?.avatarUrl || idx?.avatar || null,
  };
}

const avatar = (url, nom, classe = '') => (url
  ? h('img', { class: 'cm-avatar ' + classe, src: url, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer', title: nom || null })
  : h('span', { class: 'cm-avatar cm-avatar--vide ' + classe }, icone('crane', 'bn-icone--s')));

// Quantité d'une créature des données : « 2d4 » lancé (le jet est rendu, pour le montrer en 3D), « 3 », ou le premier
// nombre (« 2 ou 3 », « 6 à 10 » : au MJ de juger). -> { n, jet }
function tirerQuantite(formule) {
  const j = lisible(formule) && !estFixe(formule) ? lancer(formule) : null;
  if (j) return { n: Math.max(1, j.total), jet: j };
  return { n: Math.max(1, parseInt(String(formule).match(/\d+/)?.[0] || '1', 10)), jet: null };
}

// ───── Outils partagés par les widgets (une seule instance) ─────

let promesseOutils = null;
// La note du MJ sur le profil D&D Beyond d'une créature (note_mj des données), sous elle, sans clic : discrète, sauf
// « À vérifier… » (profil choisi d'office par l'agent IA de campagne), en pastille orange. null sans note.
export function noteCreature(note) {
  if (!note) return null;
  const a = note.match(/^À vérifier\s*:?\s*/i);
  return h('span', { class: 'cm-note-creature' + (a ? ' est-a-verifier' : '') },
    a ? badge('À vérifier', 'cierge', 'lu-triangle-alert') : icone('lu-info', 'bn-icone--s'),
    h('span', {}, a ? note.slice(a[0].length).replace(/^./, x => x.toUpperCase()) : note));
}

export function outilsRencontresMj(ctx) {
  promesseOutils ||= creerOutils(ctx);
  return promesseOutils;
}

async function creerOutils({ donnees, etat, dialogue }) {
  const s = await etatRencontresMj(etat);
  await chargerLivres(etat);   // livres où chercher les monstres (réglage de la campagne)
  const O = await outilsObjets({ donnees, etat, dialogue });   // objets des rencontres : app/objets.js
  const v = () => s.valeur;
  const [lectR, deroule, lieux, sIci, sH] = await Promise.all([
    donnees('rencontres-aleatoires'), donnees('deroule-campagne').then(l => l.donnees), chargerLieux(donnees), etatIci(etat, donnees), etatHorloge(etat)]);
  const dR = lectR.donnees || {};
  const scenarisees = new Map((dR.rencontres_scenarisees || []).map(r => [r.id, r]));
  const fichesAleatoires = new Map((dR.rencontres || []).map(r => [r.id, r]));
  // Nom anglais (nom_en) et note du MJ sur le profil (note_mj) de chaque créature des données, par nom VF (le premier
  // trouvé) : ils servent aussi aux rencontres déjà créées (copiées d'un tirage avant que les données les aient), aux
  // créatures d'un tirage (le moteur ne copie que nom et nom_en) et à celles que le MJ nomme comme dans les données.
  const infosCreatures = new Map();
  for (const c of [
    ...(dR.tables || []).flatMap(t => (t.lignes || []).flatMap(l => (l.options || []).flatMap(o => o.creatures || []))),
    ...(dR.rencontres || []).flatMap(r => r.creatures_secondaires || []),
    ...(dR.rencontres_scenarisees || []).flatMap(r => [...(r.creatures || []), ...(r.si || []).flatMap(x => x.creatures || [])]),
  ]) {
    if (!c?.nom) continue;
    const x = infosCreatures.get(normaliser(c.nom)) || {};
    x.nom_en ||= c.nom_en || null;
    x.note_mj ||= c.note_mj?.trim() || null;
    infosCreatures.set(normaliser(c.nom), x);
  }
  const nomAnglais = c => c.nom_en || infosCreatures.get(normaliser(c.nom))?.nom_en || null;
  const noteMj = c => c.note_mj?.trim() || infosCreatures.get(normaliser(c.nom))?.note_mj || null;
  const etapes = [...(deroule?.etapes || [])].sort((a, b) => a.ordre - b.ordre);
  const etapeParId = new Map(etapes.map(e => [e.id, e]));
  const jalonParId = new Map((deroule?.jalons || []).map(j => [j.id, j]));
  const ordreScen = ordreDesScenarisees(deroule, dR.rencontres_scenarisees || []);
  const place = id => etapes.findIndex(e => e.id === id);

  // Migration douce : champs attendus. Un brouillon ne survit pas au rechargement (son tirage n'était que dans la page).
  v().rencontres = (v().rencontres || []).filter(e => !e.brouillon);
  v().correspondances ||= {};

  // ───── Difficulté (Flee, Mortals! : app/difficulte.js) ─────
  // Le groupe d'après les fiches relevées (etat/beyond.json, relu à l'ouverture d'une fenêtre de préparation) ; les compagnons
  // comptés comme un personnage de 2 niveaux de moins (1 au moins), sauf réglage contraire (etat/campagne.json, difficulte.compagnons).
  let beyond = await lireBeyond().catch(() => ({}));
  const sCampagne = await etat('campagne', { schema: 1 });
  const compterCompagnons = () => sCampagne.valeur.difficulte?.compagnons ?? true;   // un compagnon compte (niveau de son maître − 2)
  // Option de campagne (fenêtre Campagne, onglet Rencontres) : sans elle, ni difficulté, ni rôles, ni journée d'aventure.
  const difficulteActive = () => sCampagne.valeur.difficulte?.actif ?? true;
  // Sous-option « Rôles des monstres » (2026-10-23) : sans elle, pas de rôle (choix, conseils, sbires, solo) ; les rôles
  // déjà notés restent gardés, ignorés.
  const rolesActifs = () => difficulteActive() && (sCampagne.valeur.difficulte?.roles ?? true);
  reglerRoles(rolesActifs);
  sCampagne.abonner(() => s.signaler());   // option changée : préparations, lignes et widget Combat se redessinent
  // absents : héros et compagnons absents du combat (widget Combat) ; fiches : un relevé plus récent que celui gardé ici.
  function difficulteDe(vue, { absents = null, fiches = null } = {}) {
    if (!difficulteActive() || !vue?.groupes?.length) return null;
    const c = v().combat;
    const abs = absents || new Set(c?.rencontre === vue.id ? Object.entries(c.heros || {}).filter(([, x]) => x.absent).map(([k]) => k) : []);
    const groupe = groupeAventuriers(fiches || beyond, { absents: abs, compagnons: compterCompagnons() });
    return evaluer(vue.groupes.map(g => ({ nom: g.nom, fp: g.fp, quantite: g.quantite, role: rolesActifs() ? g.role || null : null })), groupe);
  }
  // Gardée avec la rencontre quand elle démarre et quand elle se termine (points de la journée d'aventure).
  function noterDifficulte(id) {
    const ev = difficulteDe(vueDe(id));
    const e = entree(id, true);
    if (ev?.niveau) e.difficulte = { niveau: ev.niveau, points: ev.points };
  }
  // La journée d'aventure : les rencontres commencées depuis la fin du dernier repos long (heure de jeu de l'Horloge), avec
  // leurs points ; sauf : la rencontre en cours, comptée à part avec sa difficulté du moment.
  function journee({ sauf = null } = {}) {
    const repos = sH.valeur.repos_long;
    const depuis = repos ? enMinutes(repos) : -Infinity;
    const l = v().rencontres.filter(e => e.id !== sauf && e.statut && e.debut?.horloge && enMinutes(e.debut.horloge) >= depuis && e.difficulte);
    return { rencontres: l, points: l.reduce((a, e) => a + (e.difficulte.points || 0), 0), depuisRepos: !!repos, repos };
  }
  // Le budget de la journée d'aventure (demande du MJ, 2026-10-23), sous le détail de la difficulté : le barème des points,
  // les rencontres commencées depuis le dernier repos long, puis celle-ci, et le total face au budget de 6 à 8 points.
  const pts = n => `${n}${FINE}pt${n > 1 ? 's' : ''}`;
  // Le total de la journée avec cette rencontre, sa couleur (bleu dans le budget, orange au-delà de 8, rouge au-delà de 12) et
  // ce qu'il en reste.
  function bilanJournee(vue, ev) {
    const j = journee({ sauf: vue.id });
    const total = j.points + (ev?.points || 0);
    const [ton, bilan] = total > JOURNEE.rude ? ['sang', `Au-delà de ${JOURNEE.rude} points : le groupe risque fort de ne pas survivre à la journée.`]
      : total > JOURNEE.max ? ['cierge', `Au-delà de ${JOURNEE.max} points : une journée éprouvante, la survie n'est plus garantie (${JOURNEE.rude} au plus).`]
        : total >= JOURNEE.min ? ['brume', `Dans le budget conseillé${total < JOURNEE.max ? ` : encore ${pts(JOURNEE.max - total)} au plus avant un repos long` : ' : la journée est pleine'}.`]
          : [null, `Il reste ${JOURNEE.min - total} à ${JOURNEE.max - total} points avant un repos long.`];
    return { j, total, ton, bilan };
  }
  const libelleTotal = total => `Total journée d'aventure : ${pts(total)}`;
  function vueJournee(vue, ev) {
    const { j, total, ton, bilan } = bilanJournee(vue, ev);
    const ligneR = (nom, quand, d, ici = false) => h('li', { class: ici ? 'est-ici' : null },
      h('span', { class: 'cm-journee__nom' }, nom), h('span', { class: 'cm-sourdine' }, quand || ''),
      badgeDifficulte(d, { court: true }) || h('span', {}), h('span', { class: 'cm-journee__pts' }, pts(d?.points ?? 0)));
    // Un bloc encadré, son titre bien lisible (demande du MJ, 2026-10-23 : l'intitulé se perdait sous les lignes en gras).
    return h('div', { class: 'cm-journee-bloc' },
      h('p', { class: 'cm-journee-bloc__titre' }, icone('lune', 'bn-icone--s'), 'Journée d\'aventure',
        j.repos ? h('span', { class: 'cm-journee-bloc__depuis' }, `depuis le repos long (${libelleMoment(j.repos)})`) : null),
      h('p', { class: 'ui-s cm-sourdine' }, `Budget de ${JOURNEE.min} à ${JOURNEE.max} points (${JOURNEE.rude} au plus) : `,
        Object.values(DIFFICULTES).map(d => `${d.nom === 'TPK' ? d.nom : d.nom.toLowerCase()} ${d.points}`).join(', '), '.'),
      h('ul', { class: 'cm-journee' },
        j.rencontres.map(e => ligneR(vueDe(e.id)?.nom || e.id, libelleQuand(e.debut), e.difficulte)),
        ligneR(`${vue.nom} (celle-ci)`, null, ev, true)),
      h('p', { class: 'ui cm-journee__total', 'data-ton': ton }, h('b', {}, libelleTotal(total)), ` sur ${JOURNEE.min} à ${JOURNEE.max}. ${bilan}`));
  }
  // Dans la préparation (demande du MJ, 2026-10-23) : la difficulté et le total de la journée sur une ligne ; « Voir le
  // détail » déplie la jauge, les chiffres, les alertes et la journée d'aventure. Replié à chaque ouverture de la fenêtre.
  const detailsOuverts = new Set();   // id des rencontres dont le détail est déplié, tant que leur fenêtre reste ouverte
  function blocDifficulte(vue) {
    const ev = difficulteDe(vue);
    if (!ev) return null;
    majAide(ev);   // l'aide ouverte suit le groupe du moment (case « Compter les compagnons »)
    const { total, ton, bilan } = bilanJournee(vue, ev);
    // Un dépliant (demande du MJ, 2026-10-23 : le bouton rose ne disait pas ce qu'il dépliait) : la ligne du badge et du
    // total, « Voir le détail » à droite, discret ; déplié, le total s'efface (il est en bas, dans la journée d'aventure).
    return section('Difficulté · Flee, Mortals!', 'crane',
      h('details', { class: 'cm-difficulte__repli', open: detailsOuverts.has(vue.id),
        ontoggle: e => { if (e.target.open) detailsOuverts.add(vue.id); else detailsOuverts.delete(vue.id); } },
        h('summary', {}, badgeDifficulte(ev),
          infobulle(h('span', { class: 'ui-s cm-difficulte__total', 'data-ton': ton }, `${libelleTotal(total)} sur ${JOURNEE.min} à ${JOURNEE.max}`), bilan, { titre: 'Journée d\'aventure' }),
          h('span', { class: 'cm-difficulte__deplier' }, h('span', { class: 'cm-si-ferme' }, 'Voir le détail'), h('span', { class: 'cm-si-ouvert' }, 'Masquer le détail'), icone('lu-chevron-down', 'bn-icone--s'))),
        vueDifficulte(ev, { avecBadge: false }), vueJournee(vue, ev)));
  }

  // Enregistre et prévient les widgets abonnés (et les fenêtres ouvertes, abonnées elles aussi : rafraichirFenetres).
  const enregistrer = (source = null) => { s.enregistrer(0); s.signaler(source); };
  const quandMaintenant = () => ({ horloge: horlogeEnService() ? maintenant(sH.valeur) : null, quand: new Date().toISOString() });
  const libelleQuand = q => (q ? (q.horloge ? libelleMoment(q.horloge) : heure(q.quand)) : '');

  // ───── L'or donné (demande du MJ, 2026-11-12) : butin d'une rencontre, sur D&D Beyond ou noté (app/or.js), gardé dans
  // `or` de son entrée d'état. Les pièces du texte du butin (« 35 po et 120 pa ») préremplissent la fenêtre.
  function piecesDuButin(texte) {
    const p = {};
    for (const m of String(texte || '').matchAll(/(\d[\d\s  ]*)\s*(pp|po|pe|pa|pc)\b/gi)) {
      const k = m[2].toLowerCase();
      p[k] = (p[k] || 0) + (parseInt(m[1].replace(/\D/g, ''), 10) || 0);
    }
    return p;
  }
  let nomsHeros = null;
  const nomHeros = id => nomsHeros?.get(id) || id;
  donnees('personnages').then(r => { nomsHeros = new Map((r.donnees?.personnages || []).map(p => [p.id, p.nom_court || p.nom])); }).catch(() => {});
  async function donnerOrRencontre(id) {
    const vue = vueDe(id);
    if (!vue) return;
    const don = await donnerOr({ donnees, dialogue, pieces: piecesDuButin(vue.scen?.butin), motif: `Rencontre « ${vue.nom} »`, titre: 'Donner le butin' });
    if (!don) return;
    const e = entree(id, true);
    if (!e) return;
    (e.or ||= []).push(don);
    enregistrer();
  }
  function retirerDon(id, i) { const e = entree(id); if (!e?.or) return; e.or.splice(i, 1); if (!e.or.length) delete e.or; enregistrer(); }
  // L'or donné d'une rencontre et « Donner de l'or » : sous son butin (contexte), dans la fenêtre de fin.
  function blocOr(vue, { titre = true, apres = null } = {}) {
    const dons = vue.e?.or || [];
    return h('div', { class: 'cm-pile cm-or' },
      dons.length ? h('ul', { class: 'cm-or__dons ui-s' }, dons.map((d, i) => h('li', {}, icone('lu-coins', 'bn-icone--s'), h('span', {}, `Donné : ${libelleDon(d, nomHeros)}`),
        bouton('', { icone: 'lu-x', classe: 'bn-btn--s bn-btn--fantome', titre: 'Retirer cette ligne (rien n\'est repris sur D&D Beyond)', onclick: () => { retirerDon(vue.id, i); apres?.(); } })))) : null,
      h('div', { class: 'bn-groupe' }, bouton(dons.length ? 'Donner encore de l\'or' : 'Donner de l\'or', { classe: 'bn-btn--s', icone: 'lu-coins', titre: titre ? 'Des pièces aux héros ou au groupe, sur D&D Beyond ou notées' : null, onclick: () => donnerOrRencontre(vue.id).then(() => apres?.()) })));
  }

  // L'entrée d'état d'une rencontre (créée au besoin pour une rencontre prévue).
  function entree(id, creer = false) {
    let e = v().rencontres.find(x => x.id === id);
    if (!e && creer && scenarisees.has(id)) {
      e = { id, origine: 'prevue', groupes: [], creee: new Date().toISOString() };
      v().rencontres.push(e);
    }
    return e || null;
  }

  // Vue d'une rencontre : ce qu'il faut pour l'afficher, quelle que soit son origine. null si elle n'existe pas.
  function vueDe(id) {
    const scen = scenarisees.get(id) || null;
    const e = entree(id);
    if (!scen && !e) return null;
    // Une rencontre prévue disparue des données (renommée ou retirée à un export) : gardée, et supprimable.
    const origine = scen ? 'prevue' : e.origine === 'prevue' ? 'orpheline' : e.origine;
    return {
      id, origine, scen, e,
      nom: scen ? scen.nom : origine === 'orpheline' ? `${id} (absente des données)` : (e.nom?.trim() || 'Rencontre sans nom'),
      statut: e?.statut || 'a-jouer',
      groupes: e?.groupes || [],
      // Créatures des données (noms VF, quantité en dés) : celles de la rencontre prévue, ou celles du tirage.
      creatures: scen ? (scen.creatures || []) : (e.creatures || []),
    };
  }

  // Où se passe la rencontre, en une ligne.
  function ouDe(vue) {
    if (vue.scen) return ouScenarisee(vue.scen, lieux);
    const r = vue.e.rattachement || {};
    if (r.jalon) return jalonParId.has(r.jalon) ? `Jalon « ${jalonParId.get(r.jalon).nom} »` : `Jalon ${r.jalon}`;
    if (r.etape) return etapeParId.has(r.etape) ? `Étape ${etapeParId.get(r.etape).ordre} : ${etapeParId.get(r.etape).nom}` : `Étape ${r.etape}`;
    if (r.de && r.vers) return `${nomLieu(lieux, r.de)} → ${nomLieu(lieux, r.vers)}`;
    if (r.lieu) return nomComplet(lieux, r.lieu, r.sous_lieu);
    return vue.e.brouillon ? 'Pas encore lancée' : vue.origine === 'aleatoire' ? 'Rencontre aléatoire' : 'Rattachée à rien';
  }

  // Jalon ou étape où la voir dans le Déroulé : { jalon } ou { etape }, ou null.
  function dansLeDeroule(vue) {
    if (vue.scen) { const o = ordreScen.get(vue.id); return o ? (o.jalon ? { jalon: o.jalon } : { etape: o.etape }) : null; }
    const r = vue.e.rattachement || {};
    if (r.jalon && jalonParId.has(r.jalon)) return { jalon: jalonParId.get(r.jalon) };
    if (r.etape && etapeParId.has(r.etape)) return { etape: etapeParId.get(r.etape) };
    return null;
  }

  // Rang dans l'ordre de la campagne (comme l'onglet Hors tables) : premier jalon qui la cite ou auquel elle est rattachée,
  // sinon son étape, sinon la première étape qui se joue à son lieu ; les autres à la fin.
  function rangDe(vue) {
    if (vue.scen) return ordreScen.get(vue.id)?.rang ?? Infinity;
    const r = vue.e.rattachement || {};
    if (r.jalon && jalonParId.has(r.jalon)) { const j = jalonParId.get(r.jalon); return place(j.etape) * 1000 + (j.rang || 0) + 0.5; }
    if (r.etape && place(r.etape) >= 0) return place(r.etape) * 1000 + 998;
    if (r.lieu) { const i = etapes.findIndex(e => (e.lieux || []).includes(r.lieu)); if (i >= 0) return i * 1000 + 999; }
    return Infinity;
  }

  // ───── Listes ─────

  const creees = () => v().rencontres.filter(e => e.origine === 'creee');
  // Toutes les rencontres à prévoir (données et créées), dans l'ordre de la campagne : onglet Hors tables.
  function prevues() {
    const l = [...scenarisees.keys(), ...creees().map(e => e.id)].map((id, i) => ({ vue: vueDe(id), i }));
    return l.sort((a, b) => rangDe(a.vue) - rangDe(b.vue) || a.i - b.i).map(x => x.vue);
  }
  const duJalon = j => [...(j.rencontres || []).filter(id => scenarisees.has(id)), ...creees().filter(e => e.rattachement?.jalon === j.id).map(e => e.id)].map(vueDe);
  const deLEtape = e => creees().filter(x => x.rattachement?.etape === e.id).map(x => vueDe(x.id));
  // Sur place à un lieu (au lieu général : celles de ses sous-lieux comprises ; dans un sous-lieu : les siennes).
  function duLieu(lieu, sous = null) {
    const donnees = [...scenarisees.values()].filter(r => r.lieu === lieu && !r.de && !r.vers && (!sous || r.sous_lieu === sous)).map(r => r.id);
    const miennes = creees().filter(e => e.rattachement?.lieu === lieu && (!sous || e.rattachement.sous_lieu === sous)).map(e => e.id);
    return [...donnees, ...miennes].map((id, i) => ({ vue: vueDe(id), i })).sort((a, b) => rangDe(a.vue) - rangDe(b.vue) || a.i - b.i).map(x => x.vue);
  }
  // Sur la route d'un trajet en cours (fenêtre du trajet, app/passage.js) : les rencontres prévues entre deux lieux de
  // l'itinéraire (`de` et `vers` tous deux dedans, dans un sens ou dans l'autre), données et créées, dans l'ordre de la route.
  // troncon : où sont les héros (de itineraire[troncon] à itineraire[troncon + 1]). → [{ vue, ici }] ; ici : sur ce tronçon.
  function duTrajet(itineraire, troncon) {
    const indice = id => itineraire.indexOf(id);
    // Une rencontre de trajet suit le jalon de trajet qui la cite (2026-11-07) : déplacée sur un autre jalon, elle quitte cette
    // route même si ses `de` et `vers` y sont encore. Citée par aucun jalon de trajet : ses `de` et `vers` décident seuls.
    const pointsDe = j => [j.de, j.vers, ...(j.lieux || []), ...[...(j.trajets || []), ...(j.variantes || []).flatMap(r => r.trajets || [])].flatMap(t => String(t).split('--'))];
    const suitLaRoute = id => {
      const siens = (deroule?.jalons || []).filter(j => j.type === 'trajet' && (j.rencontres || []).includes(id));
      return !siens.length || siens.some(j => pointsDe(j).some(l => indice(l) >= 0));
    };
    const routes = [...[...scenarisees.values()].map(r => ({ id: r.id, de: r.de, vers: r.vers })), ...creees().map(e => ({ id: e.id, de: e.rattachement?.de, vers: e.rattachement?.vers }))];
    return routes.filter(x => x.de && x.vers && indice(x.de) >= 0 && indice(x.vers) >= 0 && x.de !== x.vers && suitLaRoute(x.id))
      .map((x, i) => {
        const debut = Math.min(indice(x.de), indice(x.vers)), fin = Math.max(indice(x.de), indice(x.vers));
        return { vue: vueDe(x.id), ici: troncon >= debut && troncon < fin, debut, fin, i };
      })
      .sort((a, b) => a.debut - b.debut || a.fin - b.fin || rangDe(a.vue) - rangDe(b.vue) || a.i - b.i)
      .map(({ vue, ici }) => ({ vue, ici }));
  }
  // Rencontres jouées ou commencées, la plus récente d'abord ; pas celles des tirages lancées sans être jouées (demande du MJ,
  // 2026-10-25).
  const dateDe = e => e.fin?.quand || e.debut?.quand || e.creee || '';
  function historique() {
    return v().rencontres.filter(e => e.statut === 'en-cours' || e.statut === 'terminee')
      .sort((a, b) => dateDe(b).localeCompare(dateDe(a))).map(e => vueDe(e.id)).filter(Boolean);
  }
  // Préparées (des monstres) mais pas jouées : à lancer depuis le widget Combat.
  // Pas les aléatoires : tirées, elles ont lieu tout de suite ; elles ne se préparent pas d'avance (décision du MJ, 2026-10-25 :
  // seul le lien de leurs créatures à un monstre de D&D Beyond se fait d'avance, onglet Tables de Rencontres).
  const preparees = () => v().rencontres.filter(e => e.groupes?.length && !e.statut && e.origine !== 'aleatoire').map(e => vueDe(e.id)).filter(Boolean);
  // La rencontre lancée depuis une entrée du journal des rencontres aléatoires (etat/rencontres.json), s'il y en a une.
  const duTirage = idEntree => v().rencontres.find(e => e.tirage?.entree === idEntree && !e.brouillon) || null;

  // ───── Ligne et menu ─────

  function badgeOrigine(vue) {
    if (vue.origine === 'creee') return badge('MJ', 'sang', 'lu-pencil');
    if (vue.origine === 'aleatoire') return badge('Aléatoire', 'ultra', 'd20');
    if (vue.origine === 'maison') return badge('Maison', 'brume', 'porte');
    const r = vue.scen;
    return badge(libelleSource(r.source), couleurSource(r.source), 'livre');
  }
  function badgeStatut(vue) {
    if (vue.statut === 'terminee') return badge('Terminée', 'brume', 'lu-check');
    if (vue.statut === 'en-cours') return badge('En cours', 'soleil');
    if (v().combat?.rencontre === vue.id) return badge('Lancée', 'sang', 'epee');
    return vue.groupes.length ? badge('Préparée', null, 'lu-swords') : null;
  }
  // « 3 Zombie, 1 Will-o’-Wisp » (préparée), sinon les créatures des données (« 2d4 zombis »).
  function resumeMonstres(vue) {
    if (vue.groupes.length) return vue.groupes.map(g => `${g.quantite} ${g.nom}`).join(', ');
    return vue.creatures.map(c => `${c.total ?? c.quantite} ${c.nom}`).join(', ');
  }

  function choixMenu(vue, { voirDeroule = true } = {}) {
    const ou = voirDeroule ? dansLeDeroule(vue) : null;
    return [
      ['Ouvrir', 'Sa fiche et sa préparation : monstres, nombres, noms', () => ouvrir(vue.id)],
      // Lancer passe par la préparation (demande du MJ, 2026-10-25) : monstres et difficulté, puis « Lancer le combat ».
      v().combat?.rencontre === vue.id ? ['Voir le combat', 'Elle est dans le widget Combat', () => lancerRencontre(vue.id)]
        : ['Lancer', 'Sa préparation (monstres, nombres, difficulté), puis « Lancer le combat »', () => ouvrir(vue.id)],
      // La remarque du MJ, à tout moment (demande du 2026-11-05 : une trouvaille ou une scène sans combat se commente aussi,
      // sans avoir à la marquer terminée).
      [vue.e?.remarque ? 'Modifier la remarque…' : 'Ajouter une remarque…', 'Vos notes sur cette rencontre, reprises par la fin de session', () => modifierRemarque(vue.id)],
      vue.statut === 'terminee' ? ['Rouvrir', 'Elle n\'est pas terminée', () => rouvrir(vue.id)]
        : ['Marquer terminée…', 'Jouée ailleurs (Maps), sans combat, ou finie : avec une remarque', () => demanderFin(vue.id)],
      ou && derouleSurLeTableau() ? ['Voir dans le déroulé', ou.jalon ? `Jalon « ${ou.jalon.nom} »` : `Étape « ${ou.etape.nom} »`, () => (ou.jalon ? voirJalon(ou.jalon.id) : voirEtape(ou.etape.id))] : null,
      vue.origine !== 'prevue' ? ['Supprimer…', 'Créée dans le gestionnaire : la supprimer', () => supprimer(vue.id)] : null,
    ].filter(Boolean);
  }

  // Une rencontre dans une liste : un clic ouvre son menu. historique : la date et la remarque du MJ.
  function ligne(vue, { historique: hist = false, voirDeroule = true, compacte = false } = {}) {
    const quand = hist ? libelleQuand(vue.e?.fin || vue.e?.debut || (vue.e?.tirage ? { horloge: vue.e.tirage.horloge, quand: vue.e.tirage.quand } : null)) : '';
    const meta = [quand, compacte ? null : ouDe(vue), vue.scen?.niveau && !hist ? `niveau ${vue.scen.niveau}` : null].filter(Boolean).join(' · ');
    const monstres = resumeMonstres(vue);
    const btn = h('button', { type: 'button', class: `bn-carte cm-rmj cm-ouvre cm-rmj--${vue.statut}`, title: 'Ouvrir, lancer, marquer terminée…' },
      h('span', { class: 'cm-rmj__nom cm-ouvre__nom' }, vue.nom),
      h('span', { class: 'cm-rmj__badges' }, badgeStatut(vue), hist || compacte ? null : badgeOrigine(vue),
        // Difficulté (Flee, Mortals!) : celle notée quand elle a été jouée, sinon celle du moment.
        difficulteActive() ? badgeDifficulte(hist && vue.e?.difficulte ? vue.e.difficulte : difficulteDe(vue), { court: true }) : null),
      meta ? h('span', { class: 'cm-rmj__meta' }, icone(hist ? 'lu-clock' : 'epingle', 'bn-icone--s'), meta) : null,
      monstres ? h('span', { class: 'cm-rmj__meta' }, icone('crane', 'bn-icone--s'), monstres) : null,
      // Terminée après un combat mené ici : son issue (morts, héros tombés), dans le Déroulé comme dans l'historique.
      vue.statut === 'terminee' && vue.e?.bilan ? h('span', { class: 'cm-rmj__meta cm-rmj__bilan' }, icone('lu-check', 'bn-icone--s'), resumeBilan(vue.e.bilan)) : null,
      (hist || compacte) && vue.e?.remarque ? h('span', { class: 'cm-rmj__remarque' }, vue.e.remarque) : null);
    const [, menu] = boutonMenu(btn, choixMenu(vue, { voirDeroule }), `Rencontre « ${vue.nom} »`);
    return h('div', { class: 'cm-rmj-l' }, lienFlottant(btn, 'rmj:' + vue.id), menu);
  }

  // « + Rencontre » : en crée une, rattachée (jalon, étape, lieu…), et ouvre sa fenêtre.
  function boutonNouvelle(rattachement = {}, { libelle = 'Nouvelle rencontre', classe = 'bn-btn--s bn-btn--fantome' } = {}) {
    return bouton(libelle, { icone: 'lu-plus', classe, titre: 'Créer une rencontre ici : monstres de D&D Beyond, nombres, noms', onclick: () => nouvelle(rattachement) });
  }
  function nouvelle(rattachement = {}) {
    const e = { id: 'mj-' + identifiant(), origine: 'creee', nom: 'Nouvelle rencontre', rattachement: { ...rattachement }, note: '', groupes: [], creee: new Date().toISOString() };
    v().rencontres.push(e);
    enregistrer();
    ouvrir(e.id, { nommer: true });
    return e;
  }

  // ───── Statut ─────

  // État de fin d'un combat mené dans le widget Combat (demande du MJ, 2026-10-23) : chaque monstre (mort à 0 PV, ou ses
  // PV et ses états) et chaque héros présent (PV, à terre, mort, d'après son relevé D&D Beyond), gardé avec la rencontre
  // terminée (`bilan`) : lignes du Déroulé et de l'historique, fenêtre de la rencontre, prompt de fin de session.
  async function bilanCombat(c) {
    if (!c?.monstres?.length) return null;
    const beyond = await lireBeyond();
    const heros = Object.values(beyond.fiches || {}).flatMap(f => [
      c.heros?.['pj:' + f.id]?.absent ? null : { nom: String(f.nom || '').split(' ')[0], pv: f.pv?.actuels ?? null, pv_max: f.pv?.max ?? null, a_terre: aTerre(f) && !estMort(f), mort: estMort(f) },
      ...(f.creatures || []).filter(cr => !c.heros?.[`cr:${f.id}:${cr.id}`]?.absent)   // comme Combat : même « inactif »
        .map(cr => ({ nom: cr.nom, pv: cr.pv?.actuels ?? null, pv_max: cr.pv?.max ?? null, a_terre: (cr.pv?.actuels ?? 1) <= 0 })),
    ]).filter(Boolean);
    return {
      round: c.round || 0,
      monstres: c.monstres.map(m => ({ nom: m.nom, pv: m.pv, pv_max: m.pv_max, mort: m.pv <= 0, ...(m.etats?.length ? { etats: m.etats.map(x => x.nom) } : {}) })),
      heros,
    };
  }
  // « 3 morts sur 4 · Bertrand à terre » : la ligne d'une rencontre terminée.
  function resumeBilan(b) {
    if (!b?.monstres?.length) return '';
    const morts = b.monstres.filter(m => m.mort).length;
    const tombes = (b.heros || []).filter(x => x.mort || x.a_terre).map(x => `${x.nom} ${x.mort ? 'mort' : 'à terre'}`);
    return [morts === b.monstres.length ? (morts > 1 ? `tous morts (${morts})` : 'mort') : `${morts} mort${morts > 1 ? 's' : ''} sur ${b.monstres.length}`, ...tombes].join(' · ');
  }
  // Le détail (fenêtre de la rencontre, fenêtre de fin) : un monstre par ligne, puis les héros.
  // sansMonstres : le texte à la place de la liste quand elle est vide (fenêtre de fin : les autres ont leur alerte).
  function vueBilan(b, { sansMonstres = null } = {}) {
    if (!b?.monstres?.length && !sansMonstres) return null;
    const pv = x => (x.pv != null ? `${x.pv}/${x.pv_max} PV` : '');
    return h('div', { class: 'cm-pile cm-bilan' },
      b.monstres.length ? h('ul', { class: 'cm-liste ui' }, b.monstres.map(m => h('li', { class: m.mort ? 'cm-bilan--mort' : null },
        h('b', {}, m.nom), ' : ', m.mort ? 'mort' : [pv(m), m.etats?.length ? ` · ${m.etats.join(', ')}` : ''].join(''))))
        : h('p', { class: 'ui-s cm-sourdine' }, sansMonstres),
      b.heros?.length ? h('p', { class: 'ui-s' }, b.heros.map(x => `${x.nom} ${x.mort ? 'mort' : x.a_terre ? 'à terre' : pv(x)}`).join(' · ')) : null,
      b.round ? h('p', { class: 'ui-s cm-sourdine' }, `Fin au round ${b.round}.`) : null);
  }

  // Une case d'une proposition de la fenêtre de fin : { el, coche() }.
  function caseProposee(contenu, cochee, surChange = null) {
    const entreeCase = h('input', { type: 'checkbox', class: 'bn-case', checked: cochee, onchange: ev => surChange?.(ev.target.checked) });
    return { el: h('label', { class: 'cm-case' }, entreeCase, h('span', {}, contenu)), coche: () => entreeCase.checked };
  }

  // Les PNJ parmi les créatures tombées (demande du MJ, 2026-11-07). morts(i) : le i-e monstre du combat est-il mort ?
  // Dans l'ordre : son nom (ou un alias) est celui d'un PNJ ; sinon la créature des données les désigne (`pnj`, ou leurs noms
  // entre parenthèses : « garde (Aline, Berthe) »), cochés seulement si le groupe est assez tombé pour que ce soit sûr ;
  // sinon, seul de son groupe, il a le bloc de stats d'un PNJ du jalon ou du lieu : proposé, pas coché, c'est une déduction.
  // → [{ p, coche, deduit }], sans ceux déjà morts.
  async function pnjTombes(vue, c, morts) {
    const liste = (await donnees('pnj')).donnees?.pnj;
    if (!liste?.length || !vue.groupes.length) return [];
    const sP = await etatPnj(etat);
    const parId = new Map(liste.map(p => [p.id, p]));
    // « Aline, la meunière » se reconnaît aussi à « Aline ».
    const parNom = new Map(liste.flatMap(p => [p.nom, String(p.nom).split(/[,(]/)[0], ...(p.alias || [])].map(n => [normaliser(n).trim(), p])));
    const creaturesDonnees = [...(vue.scen?.creatures || []), ...(vue.scen?.si || []).flatMap(x => x.creatures || []), ...(vue.creatures || [])];
    const jalons = jalonsDeLaRencontre(vue);
    const res = new Map();
    const noter = (p, coche, deduit = false) => {
      if (!p || etatEffectif(p, suiviPnj(sP, p.id)) === 'mort') return;
      const x = res.get(p.id);
      if (x) { x.coche ||= coche; x.deduit &&= deduit; } else res.set(p.id, { p, coche, deduit });
    };
    for (const g of vue.groupes) {
      const siens = c.monstres.map((m, i) => ({ m, mort: morts(i) })).filter(x => x.m.groupe === g.cle);
      const nommes = siens.map(x => ({ ...x, p: parNom.get(normaliser(x.m.nom).trim()) }));
      nommes.filter(x => x.p && x.mort).forEach(x => noter(x.p, true));
      const restants = nommes.filter(x => !x.p && x.mort).length;
      if (!restants) continue;
      const pris = new Set(nommes.filter(x => x.p).map(x => x.p.id));
      const donnee = creaturesDonnees.find(x => x.nom === g.creature);
      const parCreature = (donnee?.pnj ? [donnee.pnj].flat().map(id => parId.get(id))
        : (String(g.creature || g.nom || '').match(/\(([^)]*)\)/)?.[1] || '').split(/,|\bet\b/).map(n => parNom.get(normaliser(n).trim()))).filter(p => p && !pris.has(p.id));
      if (parCreature.length) {
        parCreature.forEach(p => noter(p, restants >= parCreature.length));
        continue;
      }
      if (siens.length !== 1) continue;
      const blocs = [g.creature, g.nom, g.nom_beyond].filter(Boolean).map(n => normaliser(n).replace(/\(.*$/, '').trim());
      const lieu = vue.scen?.lieu || vue.e?.rattachement?.lieu;
      const proches = new Set(jalons.flatMap(j => j.pnj || []));
      const memes = liste.filter(p => p.profil && blocs.includes(normaliser(p.profil).trim()) && (proches.has(p.id) || (lieu && p.lieu === lieu)));
      if (memes.length === 1) noter(memes[0], false, true);
    }
    return [...res.values()];
  }

  // Les jalons que cite ou auxquels est rattachée une rencontre.
  const jalonsDeLaRencontre = vue => (deroule?.jalons || []).filter(j => (j.rencontres || []).includes(vue.id) || vue.e?.rattachement?.jalon === j.id);

  // Après « Marquer terminée » : les jalons cochés. Terminer passe par ce qui reste, comme le bouton du jalon (app/restes.js,
  // importé ici pour ne pas lier les deux modules au chargement). Le Déroulé, s'il est monté, propose la suite.
  async function appliquerJalons(aDemarrer, aTerminer) {
    if (!aDemarrer.length && !aTerminer.length) return;
    const sD = await etatDeroule(etat, donnees);
    const noter = () => { sD.enregistrer(0); sD.signaler(); };
    aDemarrer.forEach(j => commencer(sD.valeur, 'jalon', j.id));
    if (aDemarrer.length) noter();
    aDemarrer.filter(j => !aTerminer.includes(j)).forEach(j => document.dispatchEvent(new CustomEvent('cm:apres-jalon', { detail: { id: j.id, fini: false } })));
    if (!aTerminer.length) return;
    const { outilsRestes } = await import('./restes.js');
    const Restes = await outilsRestes({ donnees, etat, dialogue });
    for (const j of aTerminer) {
      const reponse = await Restes.demander({ jalon: j.id }, { genre: 'jalon', id: j.id, nom: j.nom });
      if (!reponse) continue;
      terminer(sD.valeur, 'jalon', j.id);
      if (reponse === 'valide') valider(sD.valeur, 'jalon', j.id);
      noter();
      document.dispatchEvent(new CustomEvent('cm:apres-jalon', { detail: { id: j.id, fini: true } }));
    }
  }

  async function demanderFin(id) {
    const vue = vueDe(id);
    if (!vue) return;
    let dlg;
    const enCombat = v().combat?.rencontre === id ? v().combat : null;
    const bilan = enCombat ? await bilanCombat(enCombat) : null;
    const champ = h('textarea', { class: 'bn-textarea', rows: 3, placeholder: 'Ce qui s\'est passé, ce qu\'il faudra en retenir…' }, vue.e?.remarque || '');
    // Des créatures encore debout (demande du MJ, 2026-11-01) : on le dit, et chacune peut passer à 0 PV ici même (morte sans
    // qu'on ait noté le dernier coup) ; une fuite ou une reddition se raconte dans la remarque.
    const debout = bilan ? bilan.monstres.filter(m => !m.mort) : [];
    const aTuer = new Set();
    const cases = debout.map(m => h('label', { class: 'cm-case' },
      h('input', { type: 'checkbox', class: 'bn-case', onchange: ev => { if (ev.target.checked) aTuer.add(m); else aTuer.delete(m); majPnj(); } }),
      h('span', {}, h('b', {}, m.nom), ` : ${m.pv}/${m.pv_max} PV${m.etats?.length ? ` · ${m.etats.join(', ')}` : ''}`)));
    const blocDebout = debout.length ? alerte('cierge', 'crane', `${debout.length} créature${debout.length > 1 ? 's' : ''} pas à 0 PV`, h('div', { class: 'cm-pile' },
      h('p', { class: 'ui-s' }, 'Cochez celles qui sont mortes : elles passent à 0 PV dans l\'état de fin. Les autres restent notées avec leurs PV.'),
      cases,
      debout.length > 1 ? h('div', { class: 'bn-groupe' }, bouton('Toutes à 0 PV', { classe: 'bn-btn--s bn-btn--fantome', icone: 'crane', onclick: () => cases.forEach(c => { const i = c.querySelector('input'); if (!i.checked) { i.checked = true; i.dispatchEvent(new Event('change')); } }) })) : null)) : null;
    // PNJ tombés : une case par PNJ, suivie à mesure que des créatures sont cochées mortes ci-dessus ; le choix du MJ est gardé.
    const zonePnj = h('div', {});
    const propositions = { pnj: [] };
    const choixPnj = new Map();
    async function majPnj() {
      if (!bilan) return;
      const trouves = await pnjTombes(vue, enCombat, i => bilan.monstres[i].mort || aTuer.has(bilan.monstres[i]));
      propositions.pnj = trouves.map(x => ({ p: x.p, ...caseProposee(
        [h('b', {}, x.p.nom), x.deduit ? h('span', { class: 'ui-s cm-sourdine' }, ' · même bloc de stats') : null],
        choixPnj.get(x.p.id) ?? x.coche, oui => choixPnj.set(x.p.id, oui)) }));
      zonePnj.replaceChildren(...(trouves.length ? [section('Marquer comme mort', 'crane', h('div', { class: 'cm-pile' }, propositions.pnj.map(x => x.el)))] : []));
    }
    await majPnj();
    // Le butin : son texte, l'or déjà donné, et « Donner de l'or » (demande du MJ, 2026-11-12).
    const zoneOr = h('div', {});
    const majOr = () => { const vu = vueDe(id); zoneOr.replaceChildren(section('Butin', 'piece', h('div', { class: 'cm-pile' }, vu.scen?.butin ? h('p', { class: 'ui' }, vu.scen.butin) : null, blocOr(vu, { apres: majOr })))); };
    majOr();
    // Le déroulé : le jalon de cette rencontre démarre (coché), et se termine si elle était sa dernière (pas coché : il peut
    // rester à fouiller, et terminer passe par ce qui reste).
    const sD = await etatDeroule(etat, donnees);
    const jalonsVises = jalonsDeLaRencontre(vue).filter(j => statutDe(sD.valeur, 'jalon', j.id) !== 'termine');
    const casesDemarrer = jalonsVises.filter(j => statutDe(sD.valeur, 'jalon', j.id) === 'a-venir').map(j => ({ j, ...caseProposee(['Démarrer le jalon « ', h('b', {}, j.nom), ' »'], true) }));
    const casesTerminer = jalonsVises.filter(j => duJalon(j).every(x => x.id === id || x.statut === 'terminee')).map(j => ({ j, ...caseProposee(['Terminer le jalon « ', h('b', {}, j.nom), ' » : toutes ses rencontres sont jouées'], false) }));
    const blocJalons = casesDemarrer.length || casesTerminer.length ? section('Déroulé', 'lu-list', h('div', { class: 'cm-pile' }, [...casesDemarrer, ...casesTerminer].map(x => x.el))) : null;
    const valider = () => {
      const e = entree(id, true);
      noterDifficulte(id);   // avec les renforts ajoutés en cours de combat
      const texte = champ.value.trim();
      Object.assign(e, { statut: 'terminee', fin: quandMaintenant(), remarque: texte || null });
      if (texte) e.remarque_maj = new Date().toISOString();
      aTuer.forEach(m => { m.pv = 0; m.mort = true; });
      if (bilan) e.bilan = bilan;
      if (v().combat?.rencontre === id) v().combat = null;
      enregistrer();
      const pnjMorts = propositions.pnj.filter(x => x.coche()).map(x => x.p);
      if (pnjMorts.length) etatPnj(etat).then(sP => {
        pnjMorts.forEach(p => { Object.assign(sP.valeur.pnj[p.id] ||= {}, { etat: 'mort', rencontre: true }); });
        sP.enregistrer(0);
        sP.signaler();
      });
      const aDemarrer = casesDemarrer.filter(x => x.coche()).map(x => x.j), aTerminer = casesTerminer.filter(x => x.coche()).map(x => x.j);
      dlg.close();
      emettre('rencontre:terminee', { id, nom: vue.nom, remarque: texte || null, bilan: e.bilan || null });
      appliquerJalons(aDemarrer, aTerminer);
    };
    dlg = dialogue('Rencontre', `Marquer terminée : ${vue.nom}`, h('div', { class: 'cm-pile' },
      h('p', { class: 'ui-s cm-sourdine' }, bilan ? 'L\'état de fin du combat reste avec la rencontre (Déroulé, historique du widget Combat, fin de session), avec la remarque.'
        : 'Jouée ici, dans Maps, ou sans combat. La remarque reste avec la rencontre (historique du widget Combat).'),
      blocDebout,
      bilan ? section('Fin du combat', 'crane', vueBilan({ ...bilan, monstres: bilan.monstres.filter(m => m.mort) }, { sansMonstres: 'Aucun monstre à 0 PV pour l\'instant.' })) : null,
      zoneOr,
      zonePnj,
      blocJalons,
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Remarque du MJ'), champ)),
    h('div', { class: 'bn-groupe' },
      bouton('Marquer terminée', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: valider }),
      bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    setTimeout(() => champ.focus(), 0);
  }
  // La remarque d'une rencontre, modifiable à tout moment : après coup sur une rencontre terminée (demande du MJ,
  // 2026-11-01), et aussi sans l'avoir terminée (2026-11-05 : une trouvaille, une scène sans combat). La fin de session la
  // reprend même si la rencontre a été jouée avant le dernier envoi (`remarque_maj`).
  function modifierRemarque(id) {
    const vue = vueDe(id);
    if (!vue) return;
    let dlg;
    const champ = h('textarea', { class: 'bn-textarea', rows: 6, placeholder: 'Ce qui s\'est passé, ce qu\'il faudra en retenir…', 'aria-label': 'Remarque du MJ' }, vue.e?.remarque || '');
    dlg = dialogue('Rencontre', `Remarque : ${vue.nom}`, champ, h('div', { class: 'bn-groupe' },
      bouton('Enregistrer', { classe: 'bn-btn--primaire', icone: 'lu-check', onclick: () => {
        const texte = champ.value.trim();
        // Une rencontre des données jamais touchée n'a pas encore d'entrée : elle la prend avec sa première remarque.
        const e = vue.e || (texte ? entree(id, true) : null);
        if (e && texte !== (e.remarque || '')) {
          e.remarque = texte || null;
          e.remarque_maj = new Date().toISOString();
          enregistrer();
        }
        dlg.close();
      } }),
      bouton('Annuler', { classe: 'bn-btn--fantome', onclick: () => dlg.close() })));
    setTimeout(() => { champ.focus(); champ.setSelectionRange(champ.value.length, champ.value.length); }, 0);
  }
  function rouvrir(id) {
    const e = entree(id);
    if (!e) return;
    e.statut = e.debut ? 'en-cours' : undefined;
    delete e.fin;
    delete e.bilan;
    enregistrer();
  }
  async function supprimer(id) {
    const vue = vueDe(id);
    if (!vue || vue.origine === 'prevue') return;
    const alea = vue.origine === 'aleatoire' && vue.e.tirage?.entree;
    if (!confirm(`Supprimer la rencontre « ${vue.nom} » ? Sa préparation et sa remarque sont perdues.${alea ? ' Elle sort aussi du journal des rencontres (son numéro et sa place dans le plafond sont rendus).' : ''}`)) return;
    if (alea) defaireRencontre(await etatRencontres(etat), vue.e.tirage.entree);
    v().rencontres = v().rencontres.filter(e => e.id !== id);
    if (v().combat?.rencontre === id) v().combat = null;
    flottantOuvert('rmj:' + id)?.fermer();
    enregistrer();
  }
  // Annuler une rencontre lancée qui n'a pas eu lieu (« Annuler » du widget Combat, demande du MJ, 2026-10-25) : tout est
  // défait. Aléatoire : retirée du journal des rencontres (numéro, plafond rendus) et supprimée ; prévue ou créée : sortie du
  // widget Combat et de nouveau « à jouer », sa préparation gardée.
  async function annuler(id) {
    const vue = vueDe(id);
    if (!vue) return;
    const alea = vue.origine === 'aleatoire' || vue.origine === 'maison';
    if (!confirm(alea ? `Annuler « ${vue.nom} » ? Elle n'a pas eu lieu : ${vue.origine === 'aleatoire' ? 'retirée du journal des rencontres (son numéro et sa place dans le plafond sont rendus) et ' : ''}supprimée.`
      : `Annuler « ${vue.nom} » ? Elle n'a pas eu lieu : retirée du widget Combat, de nouveau « à jouer » ; sa préparation reste.`)) return;
    if (v().combat?.rencontre === id) v().combat = null;
    if (alea) {
      if (vue.origine === 'aleatoire' && vue.e.tirage?.entree) defaireRencontre(await etatRencontres(etat), vue.e.tirage.entree);
      v().rencontres = v().rencontres.filter(e => e.id !== id);
      flottantOuvert('rmj:' + id)?.fermer();
    } else if (vue.e) ['statut', 'debut', 'fin', 'difficulte', 'bilan'].forEach(k => delete vue.e[k]);
    enregistrer();
    emettre('rencontre:annulee', { id, nom: vue.nom });
  }
  // Une ligne du journal effacée (onglet Journal de Rencontres) : la rencontre lancée depuis ce tirage disparaît avec elle.
  function oublierTirage(idEntree) {
    const e = v().rencontres.find(x => x.tirage?.entree === idEntree);
    if (!e) return;
    v().rencontres = v().rencontres.filter(x => x !== e);
    if (v().combat?.rencontre === e.id) v().combat = null;
    flottantOuvert('rmj:' + e.id)?.fermer();
    enregistrer();
  }
  // Rencontre prévue : retirer la préparation et le statut (les données ne changent pas).
  function effacerPreparation(id) {
    if (!confirm('Effacer la préparation de cette rencontre (monstres, statut, remarque) ? Son texte, qui vient des données, reste.')) return;
    v().rencontres = v().rencontres.filter(e => e.id !== id);
    if (v().combat?.rencontre === id) v().combat = null;
    enregistrer();
  }

  // ───── Monstres de la rencontre ─────

  // La correspondance d'une créature des données (nom VF) avec un monstre de D&D Beyond.
  const correspondance = nom => v().correspondances[normaliser(nom).trim()] || null;
  const dansGroupes = (vue, c) => vue.groupes.some(g => g.creature && normaliser(g.creature) === normaliser(c.nom));

  async function ajouterGroupe(id, monstreId, { creature = null, quantite = 1, formule = null } = {}) {
    const [{ cfg, parId }, [f]] = await Promise.all([chargerBestiaire(), fichesMonstres([monstreId])]);
    const snap = instantane(f, parId.get(monstreId), cfg);
    const e = entree(id, true);
    e.groupes ||= [];
    const meme = !creature && e.groupes.find(g => g.monstre === monstreId && !g.creature);
    if (meme) meme.quantite += quantite;
    else e.groupes.push({ cle: identifiant(), ...snap, nom: creature ? premiereMajuscule(creature) : snap.nom_beyond, quantite, formule, creature, noms: [], role: roleDevine(f) });
    if (creature) v().correspondances[normaliser(creature).trim()] = { monstre: monstreId, nom: snap.nom_beyond };
    synchroniserCombat();
    enregistrer();
  }
  // Relire D&D Beyond : le bestiaire, les fiches, et ce que la rencontre garde de ses monstres (nom, FP, CA, PV,
  // initiative, image, rôle s'il n'en a pas) ; un nom de groupe resté celui de D&D Beyond suit le nouveau.
  // Un homebrew modifié peut devenir sur D&D Beyond une nouvelle version, sous un autre id (et parfois un autre nom :
  // « Flesh Mound (Walter) (from…) » → « Flesh Mound (Walter) (PDF) ») ; l'ancienne se lit encore,
  // mais n'est plus dans les homebrews du MJ. Un monstre absent du bestiaire passe au seul homebrew de même nom avant
  // ses parenthèses, dans toutes les rencontres et les correspondances des créatures.
  async function relireMonstres(id) {
    oublierBeyond();
    const e = entree(id, true);
    const groupes = e.groupes || [];
    const { liste, cfg, parId } = await chargerBestiaire();
    const base = nom => normaliser(String(nom || '').replace(/\(.*$/, '')).trim();
    const nouvelles = new Map();   // ancien id -> homebrew qui le remplace
    for (const g of groupes) {
      if (parId.has(g.monstre) || nouvelles.has(g.monstre)) continue;
      const memes = liste.filter(m => m.homebrew && base(m.nom) === base(g.nom_beyond));
      if (memes.length === 1) nouvelles.set(g.monstre, memes[0]);
    }
    for (const [ancien, m] of nouvelles) {
      for (const r of v().rencontres) (r.groupes || []).forEach(g => { if (g.monstre === ancien && r !== e) g.monstre = m.id; });
      Object.values(v().correspondances).forEach(c => { if (c.monstre === ancien) Object.assign(c, { monstre: m.id, nom: m.nom }); });
      groupes.forEach(g => { if (g.monstre === ancien) g.monstre = m.id; });
    }
    const autres = v().rencontres.filter(r => r !== e).flatMap(r => (r.groupes || []).filter(g => [...nouvelles.values()].some(m => m.id === g.monstre)));
    const tous = [...groupes, ...autres];
    const fs = await fichesMonstres(tous.map(g => g.monstre));
    let changes = 0;
    tous.forEach((g, i) => {
      const snap = instantane(fs[i], parId.get(g.monstre), cfg);
      const role = g.role || roleDevine(fs[i]) || null;   // une étiquette ajoutée (« Solo ») ; un rôle choisi par le MJ reste
      if (i < groupes.length && (role !== (g.role ?? null) || ['nom_beyond', 'ca', 'pv', 'fp', 'init', 'avatar'].some(k => g[k] !== snap[k]))) changes++;
      if (g.nom === g.nom_beyond) g.nom = snap.nom_beyond;
      Object.assign(g, snap, { role });
    });
    synchroniserCombat();
    enregistrer();
    const versions = [...nouvelles.values()].map(m => `nouvelle version : ${m.nom}`);
    annonce('Relu sur D&D Beyond', [groupes.length
      ? (changes ? `${changes} monstre${changes > 1 ? 's' : ''} de la rencontre mis à jour.` : 'Les monstres de la rencontre n\'ont pas changé.')
      : 'Bestiaire et fiches relus.', ...versions].join(' ; '), 'brume');
  }
  // Des créatures des données déjà reliées : leur monstre, au nombre tiré (un tirage aléatoire l'a déjà fait), sinon lancé
  // ici : les dés roulent en 3D (app/lancers.js), puis les groupes s'ajoutent. depuis : le bouton d'où partent les dés.
  async function ajouterCreatures(id, creatures, { depuis = null } = {}) {
    const rect = depuis?.getBoundingClientRect?.() || depuis;
    const prets = creatures.map(c => ({ c, k: correspondance(c.nom) })).filter(p => p.k)
      .map(p => (p.c.total != null ? { ...p, n: p.c.total } : { ...p, ...tirerQuantite(p.c.quantite) }));
    const jets = prets.filter(p => p.jet).map(p => ({ libelle: p.c.nom, jet: p.jet, formule: String(p.c.quantite) }));
    if (jets.length) montrerJets(jets, { legende: jets.length === 1 ? `Nombre : ${jets[0].libelle}` : 'Nombre de monstres', depuis: rect });
    for (const p of prets) await ajouterGroupe(id, p.k.monstre, { creature: p.c.nom, quantite: p.n, formule: estFixe(p.c.quantite) ? null : String(p.c.quantite) });
  }
  // Nombre relancé d'un groupe (sa formule des données), les dés en 3D.
  function relancerQuantite(g, depuis) {
    const t = tirerQuantite(g.formule);
    if (t.jet) montrerJets([{ libelle: g.nom, jet: t.jet, formule: g.formule }], { legende: `Nombre : ${g.nom}`, depuis });
    g.quantite = t.n;
    synchroniserCombat();
    enregistrer();
  }
  function changerQuantite(id, g, delta) {
    g.quantite = Math.max(1, g.quantite + delta);
    synchroniserCombat();
    enregistrer();
  }
  function retirerGroupe(id, g) {
    const e = entree(id);
    e.groupes = e.groupes.filter(x => x !== g);
    synchroniserCombat();
    enregistrer();
  }

  // ───── Combat (widget Combat) ─────

  // Les monstres du combat lancé suivent la préparation (qui reste modifiable) : mêmes clés, initiative et PV gardés.
  function synchroniserCombat() {
    const c = v().combat;
    if (!c) return;
    const vue = vueDe(c.rencontre);
    if (!vue) { v().combat = null; return; }
    const avant = new Map((c.monstres || []).map(m => [m.cle, m]));
    c.monstres = vue.groupes.flatMap(g => Array.from({ length: g.quantite }, (_, i) => {
      const cle = `${g.cle}:${i}`, a = avant.get(cle), pvMax = g.pv || 1;
      return { cle, groupe: g.cle, monstre: g.monstre, nom: nomIndividu(g, i), ca: g.ca, bonus: g.init ?? 0,
        init: a?.init ?? null, pv: a ? (a.pv >= a.pv_max ? pvMax : Math.min(a.pv, pvMax)) : pvMax, pv_max: pvMax,   // indemne : au nouveau maximum pv_temp: a?.pv_temp || 0,
        ...(a?.etats?.length ? { etats: a.etats } : {}) };   // ses états (widget Combat), gardés eux aussi
    }));
    c.heros ||= {};
  }

  // Lancer : la rencontre dans le widget Combat, et le tableau en mode Rencontre. Sans monstres, d'abord ceux des données
  // déjà reliés ; s'il en manque encore, la fenêtre de préparation s'ouvre.
  async function lancerRencontre(id) {
    let vue = vueDe(id);
    if (!vue) return;
    const aRelier = vue.creatures.filter(c => !dansGroupes(vue, c));
    if (!vue.groupes.length && aRelier.length && aRelier.every(c => correspondance(c.nom))) {
      try { await ajouterCreatures(id, aRelier); } catch (err) { annonce('Monstres illisibles', err.message); }
      vue = vueDe(id);
    }
    if (!vue.groupes.length) {
      ouvrir(id);
      annonce('Choisissez d\'abord les monstres', `« ${vue.nom} » n'a pas encore de monstres de D&D Beyond : reliez ses créatures ou cherchez-les dans la fenêtre.`, 'cierge');
      return;
    }
    const c = v().combat;
    if (c && c.rencontre !== id && c.phase !== 'prete' && !confirm(`Un combat est en cours : « ${vueDe(c.rencontre)?.nom || '?'} ». Le remplacer ? Il reste noté « en cours ».`)) return;
    if (!c || c.rencontre !== id) v().combat = { rencontre: id, phase: vue.statut === 'en-cours' ? 'en-cours' : 'prete', round: 0, tour: null, monstres: [], heros: {} };
    synchroniserCombat();
    enregistrer();
    flottantOuvert('rmj:' + id)?.fermer();   // la rencontre se mène maintenant dans le widget Combat
    document.dispatchEvent(new CustomEvent('cm:mode', { detail: { mode: 'rencontre', widget: 'combat' } }));
  }
  // La rencontre commence (le combat ou non) : notée en cours, avec l'heure.
  function demarrer(id) {
    const e = entree(id, true);
    e.statut = 'en-cours';
    e.debut ||= quandMaintenant();
    noterDifficulte(id);
    if (v().combat?.rencontre === id && v().combat.phase === 'prete') v().combat.phase = 'en-cours';
    enregistrer();
    emettre('rencontre:demarree', { id, nom: vueDe(id)?.nom || id });
  }
  function annonce(titre, texte, couleur = 'cierge') {
    document.dispatchEvent(new CustomEvent('cm:annonce', { detail: { cle: 'rencontres-mj', titre, texte, couleur, icone: 'epee' } }));
  }

  // ───── Tirages aléatoires ─────

  // Une rencontre lancée depuis un tirage (entrée du journal de etat/rencontres.json) : créée une fois, rattachée au trajet en
  // cours ou au lieu des héros, avec ce que dit le tirage. Ses créatures déjà reliées entrent d'office ; sinon sa fenêtre s'ouvre.
  // Où a lieu une rencontre qui commence maintenant : le trajet en cours (Horloge), sinon le lieu des héros, sinon rien ({}).
  function lieuDuMoment() {
    const voyage = (sH.valeur.activites || []).find(a => a.type === 'voyage');
    return voyage?.itineraire?.length > 1
      ? { de: voyage.itineraire[Math.min(voyage.atteints || 0, voyage.itineraire.length - 2)], vers: voyage.itineraire[Math.min((voyage.atteints || 0) + 1, voyage.itineraire.length - 1)] }
      : sIci.valeur.lieu ? { lieu: sIci.valeur.lieu, sous_lieu: sIci.valeur.sous_lieu || null } : {};
  }

  // « Lancer » depuis un tirage : un brouillon s'ouvre dans la fenêtre de préparation (créatures reliées à leur nombre tiré,
  // modifiables ; difficulté). accepter(horloge) : celle du tirage (moteur des rencontres), qui le note au journal quand le MJ
  // lance le combat (lancerBrouillon) ; absent pour un tirage déjà noté. Fermer la fenêtre avant : le brouillon disparaît.
  const acceptations = new Map();   // id du brouillon -> accepter du tirage
  async function depuisTirage(entreeJournal, { jets = '', accepter = null } = {}) {
    const deja = duTirage(entreeJournal.id) || v().rencontres.find(e => e.brouillon && e.tirage?.entree === entreeJournal.id);
    if (deja) { ouvrir(deja.id); return deja; }
    const f = fichesAleatoires.get(entreeJournal.rencontre);
    const e = {
      id: 'al-' + identifiant(), origine: 'aleatoire', brouillon: true, nom: f?.nom || entreeJournal.rencontre, rattachement: {},
      tirage: { entree: entreeJournal.id, rencontre: entreeJournal.rencontre, moment: entreeJournal.moment, horloge: entreeJournal.horloge || null,
        quand: entreeJournal.quand, jets, variante: entreeJournal.variante || null },
      creatures: (entreeJournal.quantites || []).map(q => ({ nom: q.nom, ...(q.nom_en ? { nom_en: q.nom_en } : {}), ...(q.note_mj ? { note_mj: q.note_mj } : {}), quantite: q.formule, total: q.total ?? null })),
      groupes: [], creee: new Date().toISOString(),
    };
    v().rencontres.push(e);
    acceptations.set(e.id, accepter);
    try { await ajouterCreatures(e.id, e.creatures); } catch (err) { annonce('Monstres illisibles', err.message); }
    enregistrer();
    ouvrir(e.id);
    return e;
  }
  // « Lancer le combat » d'un brouillon : le tirage est noté au journal (numéro, plafond), la rencontre se rattache à l'endroit
  // où sont les héros, puis va dans le widget Combat.
  function lancerBrouillon(id) {
    const e = entree(id);
    if (!e?.brouillon) { lancerRencontre(id); return; }
    if (!e.groupes?.length) {
      annonce('Choisissez d\'abord les monstres', `« ${e.nom} » n'a pas encore de monstres de D&D Beyond : reliez ses créatures ou cherchez-les dans la fenêtre.`, 'cierge');
      return;
    }
    const j = acceptations.get(id)?.(quandMaintenant().horloge);
    if (j) Object.assign(e.tirage, { entree: j.id, moment: j.moment, horloge: j.horloge || null, quand: j.quand });
    // Aléatoire : là où sont les héros ; maison : le lieu de sa table, précisé du sous-lieu si les héros y sont.
    const ici = lieuDuMoment();
    if (e.origine === 'aleatoire') e.rattachement = ici;
    else if (ici.lieu && ici.lieu === e.rattachement?.lieu) e.rattachement = ici;
    delete e.brouillon;
    acceptations.delete(id);
    enregistrer();
    lancerRencontre(id);
  }
  // « Lancer » depuis une table d'occupants des maisons (r : tirerOccupants de app/widgets/maisons.js) : un brouillon, comme un
  // tirage, dans la préparation ; ses créatures à leur nombre tiré (sans celles à 0), leur nom anglais et la note du MJ des données.
  async function depuisMaison(t, r) {
    const deja = v().rencontres.find(e => e.brouillon && e.maison?.tirage === r);
    if (deja) { ouvrir(deja.id); return deja; }
    const infos = new Map((r.ligne?.creatures || []).map(c => [c.nom, c]));
    const e = {
      id: 'ma-' + identifiant(), origine: 'maison', brouillon: true, nom: r.ligne?.resultat || 'Occupants', rattachement: { lieu: t.lieu.id },
      maison: { table: t.id, lieu: t.lieu.id, de: t.de, jet: r.jet, ligne: r.ligne?.jet || null, resultat: r.ligne?.resultat || '', detail: r.ligne?.detail || null,
        comment_jouer: r.ligne?.comment_jouer || null, quand: new Date().toISOString() },
      creatures: r.quantites.filter(q => q.total !== 0).map(q => {
        const c = infos.get(q.nom) || {};
        return { nom: q.nom, ...(c.nom_en ? { nom_en: c.nom_en } : {}), ...(c.note_mj ? { note_mj: c.note_mj } : {}), quantite: q.formule, total: q.total ?? null };
      }),
      groupes: [], creee: new Date().toISOString(),
    };
    v().rencontres.push(e);
    Object.defineProperty(e.maison, 'tirage', { value: r, enumerable: false });   // le même jet rouvre ce brouillon (pas enregistré)
    try { await ajouterCreatures(e.id, e.creatures); } catch (err) { annonce('Monstres illisibles', err.message); }
    enregistrer();
    ouvrir(e.id);
    return e;
  }
  // Brouillon dont la fenêtre se ferme sans lancer le combat : abandonné, rien n'a eu lieu.
  function abandonnerBrouillon(id) {
    const e = entree(id);
    if (!e?.brouillon) return;
    v().rencontres = v().rencontres.filter(x => x !== e);
    acceptations.delete(id);
    enregistrer();
  }

  // ───── Contexte : ce qu'on sait de la rencontre ─────

  // replie : dans un <details> « Comment la jouer » (fenêtre de préparation, widget Combat). profils : les notes du MJ sur
  // les profils des créatures (widget Combat ; dans la préparation, elles sont sous chaque créature prévue).
  function blocContexte(vue, { replie = true, ouvert = false, profils = false } = {}) {
    let contenu = [];
    if (vue.scen) {
      const r = vue.scen;
      const jalons = (deroule?.jalons || []).filter(j => (j.rencontres || []).includes(r.id));
      contenu = [
        h('p', { class: 'texte' }, r.comment_jouer),
        r.butin || vue.e?.or?.length ? section('Butin', 'piece', h('div', { class: 'cm-pile' }, r.butin ? h('p', { class: 'ui' }, r.butin) : null, blocOr(vue))) : null,
        (r.si || []).map(x => alerte('sang', 'crane', 'Si ' + x.condition.replace(/\.$/, '').replace(/^./, m => m.toLowerCase()), x.effet)),
        jalons.length ? section('Dans le déroulé', 'sablier', h('p', { class: 'cm-tenanciers' }, jalons.map(j => lienDeroule({ jalon: j })))) : null,
        blocOriginal(r.original),
        h('p', { class: 'ui-s cm-sourdine' }, `${r.source}${r.pages_pdf ? ', p. ' + r.pages_pdf + ' du PDF' : r.pages_livre ? ', p. ' + r.pages_livre : ''}${r.meme_que_livre ? ' · identique au livre' : ''}`),
      ];
    } else if (vue.origine === 'maison') {
      const x = vue.e.maison || {};
      contenu = [
        h('p', { class: 'des cm-jets' }, icone('porte', 'bn-icone--s'), [nomLieu(lieux, x.lieu), x.de ? `${x.de} : ${x.jet}${x.ligne ? ` (${x.ligne})` : ''}` : null, vue.e.brouillon ? null : libelleQuand(vue.e.debut || null)].filter(Boolean).join(' · ')),
        x.detail ? h('p', { class: 'texte' }, x.detail) : null,
        x.comment_jouer ? section('Si ça tourne au combat', 'epee', h('p', { class: 'ui' }, x.comment_jouer)) : null,
      ];
    } else if (vue.origine === 'aleatoire') {
      const t = vue.e.tirage || {};
      const f = fichesAleatoires.get(t.rencontre);
      contenu = [
        h('p', { class: 'des cm-jets' }, icone('d20', 'bn-icone--s'), [t.moment === 'nuit' ? 'Nuit' : 'Jour', libelleQuand({ horloge: t.horloge, quand: t.quand }), t.jets].filter(Boolean).join(' · ')),
        f ? h('p', { class: 'texte' }, f.comment_jouer) : alerte('cierge', 'lu-database', 'Fiche introuvable', `« ${t.rencontre} » n'est plus dans data/rencontres-aleatoires.json.`),
        t.variante ? h('p', { class: 'cm-variante' }, badge('Suggestion', 'ultra'), ' ', t.variante) : null,
        f?.profil ? section('Profil', 'epee', h('p', { class: 'ui' }, f.profil)) : null,
        f?.tests?.length ? section('Tests', 'oeil', f.tests.map(x => h('p', { class: 'ui' }, x))) : null,
        f?.evitable ? section('Évitable', 'brume', h('p', { class: 'ui' }, f.evitable)) : null,
        f?.effets?.length ? section('Effets', 'lu-info', f.effets.map(x => h('p', { class: 'ui' }, x))) : null,
        f?.creatures_secondaires?.length ? section('Renfort possible', 'crane', f.creatures_secondaires.map(c => h('p', { class: 'ui' }, h('b', {}, c.declencheur), ` ${c.quantite} ${c.nom}`, noteCreature(noteMj(c))))) : null,
        vue.e.brouillon ? null : h('div', { class: 'bn-groupe' }, bouton('Voir le tirage', { classe: 'bn-btn--s bn-btn--fantome', icone: 'loup', titre: 'Sa ligne dans le journal du widget Rencontres',
          onclick: () => document.dispatchEvent(new CustomEvent('cm:voir-rencontre', { detail: { id: t.entree } })) })),
      ];
    } else {
      const ou = dansLeDeroule(vue);
      contenu = [
        vue.e.note?.trim() ? h('p', { class: 'texte cm-prep__note' }, vue.e.note) : h('p', { class: 'ui-s cm-sourdine' }, 'Pas de note.'),
        ou ? h('p', { class: 'cm-tenanciers' }, lienDeroule(ou)) : null,
      ];
    }
    const notes = profils ? vue.creatures.map(c => [c, noteMj(c)]).filter(([, n]) => n) : [];
    if (notes.length) contenu.push(section('Profils', 'crocs', h('ul', { class: 'cm-notes-profils' }, notes.map(([c, n]) => h('li', {}, h('b', {}, c.nom), noteCreature(n))))));
    contenu = contenu.flat().filter(Boolean);
    if (!replie) return contenu;
    return h('details', { class: 'cm-repli cm-prep__contexte', open: ouvert }, h('summary', { class: 'etiquette' }, vue.origine === 'creee' ? 'Note du MJ' : 'Comment la jouer'), ...contenu);
  }
  function lienDeroule(ou) {
    const nom = ou.jalon ? `Jalon « ${ou.jalon.nom} »` : `Étape ${ou.etape.ordre} : ${ou.etape.nom}`;
    if (!derouleSurLeTableau()) return h('span', { class: 'ui-s' }, nom);
    return h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', title: 'Voir dans le déroulé', onclick: () => (ou.jalon ? voirJalon(ou.jalon.id) : voirEtape(ou.etape.id)) }, nom);
  }

  // ───── Fenêtre de préparation ─────

  const recherches = new Map();   // id de rencontre -> { texte, fp, source, nombre, liaison (créature VF à relier) }
  const nomsOuverts = new Set();  // clés des groupes dont on nomme chaque créature
  const ouvertes = new Set();     // id des rencontres dont la fenêtre est ouverte

  function ouvrir(id, { nommer = false } = {}) {
    const vue = vueDe(id);
    if (!vue) return;
    if (!flottantOuvert('rmj:' + id)) { ongletsFenetres.delete(id); detailsOuverts.delete(id); }   // une fenêtre qui s'ouvre : Monstres, détail replié
    ouvertes.add(id);
    flottant('rmj:' + id, { surtitre: surtitreFenetre(vue), titre: vue.nom, largeur: 640, pictogramme: 'lu-swords', contenu: contenuFenetre(id), surFermeture: () => abandonnerBrouillon(id) });
    lireBeyond().then(b => { if (b?.maj !== beyond?.maj) { beyond = b; rafraichirFenetres(); } }, () => {});   // niveaux des héros à jour
    if (nommer) setTimeout(() => { const c = flottantOuvert('rmj:' + id)?.el.querySelector('.cm-prep__titre'); c?.focus(); c?.select(); }, 0);
  }
  const surtitreFenetre = vue => ['Rencontre', { prevue: 'prévue', creee: 'créée par le MJ', aleatoire: 'aléatoire', maison: 'dans une maison' }[vue.origine], vue.e?.brouillon ? 'pas encore lancée' : null,
    vue.statut !== 'a-jouer' ? STATUTS[vue.statut].toLowerCase() : null].filter(Boolean).join(' · ');

  // Redessine les fenêtres ouvertes (après un changement), sauf celle où l'on tape. forcer : id d'une rencontre à redessiner
  // quand même (un monstre ajouté pendant qu'on cherche), le champ de recherche reprenant la main.
  function rafraichirFenetres(forcer = null) {
    for (const id of [...ouvertes]) {
      const f = flottantOuvert('rmj:' + id);
      const vue = vueDe(id);
      if (!f || !vue) { f?.fermer(); ouvertes.delete(id); continue; }
      const tape = f.el.contains(document.activeElement) && document.activeElement.matches('input, textarea, select');
      if (tape && id !== forcer) continue;
      const cherchait = tape && document.activeElement.classList.contains('cm-recherche__champ');
      f.maj(contenuFenetre(id), vue.nom, surtitreFenetre(vue));
      if (cherchait) focusRecherche(id);
    }
  }
  s.abonner(rafraichirFenetres);
  O.s.abonner(() => rafraichirFenetres());   // objets de la rencontre créés ou donnés

  // Trois onglets (demande du MJ, 2026-10-23) : Monstres d'office, Objets, Comment la jouer (Note du MJ pour une rencontre
  // créée). L'onglet choisi tient tant que la fenêtre reste ouverte ; elle se rouvre sur Monstres.
  const ongletsFenetres = new Map();   // id de rencontre -> onglet choisi
  function contenuFenetre(id) {
    const vue = vueDe(id);
    const editable = vue.origine !== 'prevue' && !vue.e?.brouillon;
    const creee = vue.origine === 'creee';
    const objets = O.deLaRencontre(vue.id);
    const monstres = vue.groupes.reduce((a, g) => a + g.quantite, 0);
    const pile = (...x) => h('div', { class: 'cm-pile' }, x.flat().filter(Boolean));
    const ou = creee ? dansLeDeroule(vue) : null;
    const { barre, zone } = onglets(`Rencontre « ${vue.nom} »`, [
      { id: 'monstres', libelle: 'Monstres', icone: 'lu-swords', compte: monstres || null,
        rendu: () => pile(blocCreatures(vue), blocComposition(vue), blocDifficulte(vue), blocRecherche(vue)) },
      { id: 'objets', libelle: 'Objets', icone: 'amulette', compte: objets.length || null,
        rendu: () => pile(objets.length ? O.liste(objets) : h('p', { class: 'ui-s cm-sourdine' }, vue.origine === 'aleatoire' ? 'Aucun objet.' : 'Aucun objet. « Objet », en bas, en ajoute un.')) },
      { id: 'jouer', libelle: creee ? 'Note du MJ' : 'Comment la jouer', icone: 'livre',
        rendu: () => pile(creee ? [noteEditable(vue), ou ? h('p', { class: 'cm-tenanciers' }, lienDeroule(ou)) : null] : blocContexte(vue, { replie: false }),
          vue.e?.bilan ? section('Fin du combat', 'crane', vueBilan(vue.e.bilan)) : null,
          section('Remarque du MJ', 'livre',
            vue.e?.remarque ? h('p', { class: 'ui cm-rmj__remarque-texte' }, vue.e.remarque) : null,
            h('div', { class: 'bn-groupe' }, bouton(vue.e?.remarque ? 'Modifier' : 'Ajouter une remarque', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', onclick: () => modifierRemarque(id) })))) },
    ], ongletsFenetres.get(id) || 'monstres', o => ongletsFenetres.set(id, o));
    return h('div', { class: 'cm-pile cm-prep' },
      h('p', { class: 'cm-prep__ou' }, icone('epingle', 'bn-icone--s'), [ouDe(vue), vue.scen?.niveau ? `niveau ${vue.scen.niveau}` : null].filter(Boolean).join(' · '), ' ', badgeOrigine(vue), badgeStatut(vue)),
      editable ? champsEdition(vue) : null,
      // La remarque du MJ, visible quel que soit l'onglet (retour du MJ, 2026-11-05 : il ne la trouvait pas) : un clic la modifie.
      vue.e?.remarque ? infobulle(h('button', { type: 'button', class: 'cm-prep__remarque', onclick: () => modifierRemarque(id) },
        icone('livre', 'bn-icone--s'), h('span', { class: 'cm-rmj__remarque-texte' }, vue.e.remarque)), 'Un clic : la modifier.', { titre: 'Remarque du MJ' }) : null,
      barre, zone,
      piedFenetre(vue));
  }
  // La note d'une rencontre créée, à écrire dans l'onglet Note du MJ.
  function noteEditable(vue) {
    const e = vue.e;
    return h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Note du MJ'),
      h('textarea', { class: 'bn-textarea', rows: 5, placeholder: 'Ce qui se passe, comment la jouer…', onchange: ev => { e.note = ev.target.value; enregistrer(); } }, e.note || ''));
  }

  // Rencontre créée ou aléatoire : nom, rattachement, note.
  function champsEdition(vue) {
    const e = vue.e;
    const titre = h('input', { class: 'bn-input cm-prep__titre', value: e.nom || '', 'aria-label': 'Nom de la rencontre',
      onchange: ev => { e.nom = ev.target.value.trim() || 'Rencontre sans nom'; ev.target.blur(); enregistrer(); } });
    return h('div', { class: 'cm-prep__edition' },
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Nom'), titre),
      h('label', { class: 'bn-champ' }, h('span', { class: 'bn-champ__label' }, 'Rattachée à'), choixRattachement(e)));
  }

  // Un jalon, une étape, un lieu ou un sous-lieu (ou le trajet du tirage) : une liste à groupes.
  function choixRattachement(e) {
    const r = e.rattachement || {};
    const valeur = r.jalon ? 'jalon:' + r.jalon : r.etape ? 'etape:' + r.etape : r.de && r.vers ? 'trajet' : r.lieu ? `lieu:${r.lieu}${r.sous_lieu ? '/' + r.sous_lieu : ''}` : '';
    const lieuxPrincipaux = [...lieux.values()].filter(l => !l.parent).sort((a, b) => a.nom.localeCompare(b.nom, 'fr'));
    const sel = h('select', { class: 'bn-select', 'aria-label': 'Rattachement de la rencontre',
      onchange: ev => {
        ev.target.blur();   // sinon la fenêtre, où l'on vient de choisir, ne se redessine pas
        const [genre, reste] = [ev.target.value.split(':')[0], ev.target.value.slice(ev.target.value.indexOf(':') + 1)];
        if (genre === 'trajet') return;
        e.rattachement = genre === 'jalon' ? { jalon: reste } : genre === 'etape' ? { etape: reste }
          : genre === 'lieu' ? { lieu: reste.split('/')[0], sous_lieu: reste.split('/')[1] || null } : {};
        enregistrer();
      } },
    h('option', { value: '' }, 'Rien'),
    r.de && r.vers ? h('option', { value: 'trajet' }, `Trajet ${nomLieu(lieux, r.de)} → ${nomLieu(lieux, r.vers)}`) : null,
    h('optgroup', { label: 'Étapes' }, etapes.map(x => h('option', { value: 'etape:' + x.id }, `${x.ordre}. ${x.nom}`))),
    h('optgroup', { label: 'Jalons' }, [...(deroule?.jalons || [])].sort((a, b) => place(a.etape) - place(b.etape) || a.rang - b.rang)
      .map(j => h('option', { value: 'jalon:' + j.id }, `${etapeParId.get(j.etape)?.ordre ?? '?'}.${j.rang} ${j.nom}`))),
    h('optgroup', { label: 'Lieux' }, lieuxPrincipaux.flatMap(l => [h('option', { value: 'lieu:' + l.id }, l.nom),
      ...sousLieux(lieux, l.id).map(sl => h('option', { value: `lieu:${l.id}/${sl.id}` }, `${l.nom} – ${sl.nom}`))])));
    sel.value = valeur;
    return sel;
  }

  // Créatures des données (noms VF, quantités) : à relier une fois chacune à un monstre de D&D Beyond.
  function blocCreatures(vue) {
    if (!vue.creatures.length) return null;
    const rech = etatRecherche(vue.id);
    const reliables = vue.creatures.filter(c => !dansGroupes(vue, c) && correspondance(c.nom));
    return section('Créatures prévues', 'crocs',
      h('ul', { class: 'cm-prep__creatures' }, vue.creatures.map(c => {
        const k = correspondance(c.nom);
        const dedans = dansGroupes(vue, c);
        const enLiaison = rech.liaison && normaliser(rech.liaison.nom) === normaliser(c.nom);
        const en = nomAnglais(c);
        return h('li', { class: enLiaison ? 'est-actif' : null },
          h('span', { class: 'cm-prep__qte' }, c.total ?? c.quantite),
          h('span', { class: 'cm-prep__vf' }, c.nom, c.total != null && !estFixe(c.quantite) ? h('span', { class: 'des cm-sourdine' }, ` ${c.quantite}`) : null,
            // Pas encore reliée : le profil prévu par les données (nom anglais), pour savoir quoi chercher.
            !k && en ? h('span', { class: 'ui-s cm-sourdine', title: 'Profil prévu par les données (nom sur D&D Beyond)' }, ` · ${en}`) : null),
          k ? h('span', { class: 'ui-s cm-sourdine cm-prep__k' }, icone('lu-check', 'bn-icone--s'), ' ', h('button', { type: 'button', class: 'cm-lien-bouton', title: 'Voir la fiche', onclick: () => ouvrirMonstre(k.monstre, vue.id) }, k.nom)) : null,
          h('span', { class: 'bn-groupe' },
            dedans ? badge('Dans la rencontre', 'brume', 'lu-check')
              : k ? bouton('Ajouter', { classe: 'bn-btn--s', icone: 'lu-plus', titre: `${c.quantite} ${k.nom}`, onclick: ev => essayer(() => ajouterCreatures(vue.id, [c], { depuis: ev.currentTarget })) }) : null,
            bouton(k ? '' : 'Choisir le monstre', { classe: 'bn-btn--s' + (k ? ' bn-btn--fantome' : ''), icone: k ? 'lu-pencil' : 'lu-search', 'aria-pressed': String(!!enLiaison),
              titre: k ? 'Relier à un autre monstre de D&D Beyond' : 'Chercher ci-dessous le monstre de D&D Beyond qui correspond',
              onclick: () => {
                rech.liaison = enLiaison ? null : { nom: c.nom, quantite: c.total ?? c.quantite, formule: c.quantite };
                if (rech.liaison && en) Object.assign(rech, { texte: en, nombre: PAR_PAGE });   // nom anglais des données : la recherche est prête
                rafraichirFenetres(vue.id);
                focusRecherche(vue.id);
              } })),
          noteCreature(noteMj(c)));
      })),
      reliables.length > 1 ? h('div', { class: 'bn-groupe' }, bouton(`Ajouter les ${reliables.length} créatures reliées`, { classe: 'bn-btn--s', icone: 'lu-plus',
        onclick: ev => essayer(() => ajouterCreatures(vue.id, reliables, { depuis: ev.currentTarget })) })) : null);
  }

  function blocComposition(vue) {
    const total = vue.groupes.reduce((a, g) => a + g.quantite, 0);
    return section(total ? `Monstres · ${total}` : 'Monstres', 'lu-swords',
      vue.groupes.length ? h('ul', { class: 'cm-prep__groupes' }, vue.groupes.map(g => ligneGroupe(vue, g)))
        : h('p', { class: 'ui-s cm-sourdine' }, vue.creatures.length ? 'Reliez les créatures prévues, ou cherchez des monstres ci-dessous.' : 'Cherchez des monstres ci-dessous.'));
  }

  // Le champ de la ligne : le nom dans le combat (seul : celui de la créature ; à plusieurs : « Goule A », « Goule B »…).
  // À plusieurs, l'étiquette ouvre un nom propre par créature, au besoin (sinon, la lettre).
  function ligneGroupe(vue, g) {
    const plusieurs = g.quantite > 1;
    const nomme = plusieurs && nomsOuverts.has(g.cle);
    const relancable = g.formule && lisible(g.formule) && !estFixe(g.formule);
    return h('li', { class: 'cm-prep__groupe' },
      avatar(g.avatar, g.nom_beyond),
      h('div', { class: 'cm-prep__qui' },
        h('input', { class: 'bn-input cm-prep__nom', value: g.nom, placeholder: g.nom_beyond, 'aria-label': plusieurs ? 'Nom du groupe' : 'Nom de la créature',
          title: plusieurs ? `Nom dans le combat : « ${g.nom} A », « ${g.nom} B »…` : 'Nom dans le combat',
          onchange: ev => { g.nom = ev.target.value.trim() || g.nom_beyond; synchroniserCombat(); enregistrer(); } }),
        h('span', { class: 'cm-prep__stats' },
          h('button', { type: 'button', class: 'cm-lien-bouton', title: 'Ouvrir la fiche D&D Beyond', onclick: () => ouvrirMonstre(g.monstre, vue.id) }, g.nom_beyond),
          [g.fp != null ? libellePuissance({ valeur: g.fp }) : null, g.ca ? `CA ${g.ca}` : null, `${g.pv} PV`, `init. ${signe(g.init ?? 0)}`].filter(Boolean).map(t => ' · ' + t).join(''))),
      h('div', { class: 'cm-prep__nombre' },
        bouton('', { icone: 'lu-minus', titre: 'Un de moins', classe: 'bn-btn--s bn-btn--fantome', disabled: g.quantite <= 1, onclick: () => changerQuantite(vue.id, g, -1) }),
        h('span', { class: 'cm-prep__n', 'aria-label': `${g.quantite} ${g.nom}` }, g.quantite),
        bouton('', { icone: 'lu-plus', titre: 'Un de plus', classe: 'bn-btn--s bn-btn--fantome', onclick: () => changerQuantite(vue.id, g, 1) }),
        relancable ? bouton('', { icone: 'lu-refresh-cw', titre: `Relancer ${g.formule}`, classe: 'bn-btn--s bn-btn--fantome', onclick: ev => relancerQuantite(g, ev.currentTarget.getBoundingClientRect()) }) : null),
      h('div', { class: 'bn-groupe cm-prep__outils' },
        rolesActifs() ? choixRole(g.role, role => { g.role = role; enregistrer(); }) : null,
        plusieurs ? bouton('', { icone: 'lu-tag', titre: nomme ? 'Replier les noms propres' : `Un nom propre pour chaque ${g.nom}, au besoin`, classe: 'bn-btn--s bn-btn--fantome', 'aria-pressed': String(nomme),
          onclick: () => { if (nomme) nomsOuverts.delete(g.cle); else nomsOuverts.add(g.cle); rafraichirFenetres(); } }) : null,
        bouton('', { icone: 'lu-x', titre: 'Retirer ce groupe', classe: 'bn-btn--s bn-btn--fantome', onclick: () => retirerGroupe(vue.id, g) })),
      nomme ? h('div', { class: 'cm-prep__noms' },
        h('span', { class: 'etiquette cm-prep__plein' }, 'Noms propres, au besoin'),
        Array.from({ length: g.quantite }, (_, i) => h('label', { class: 'cm-prep__nom-ind' },
          h('span', { class: 'cm-prep__lettre' }, lettre(i)),
          h('input', { class: 'bn-input', value: g.noms?.[i] || '', placeholder: `${g.nom} ${lettre(i)}`, 'aria-label': `Nom propre de ${g.nom} ${lettre(i)}`,
            onchange: ev => { g.noms ||= []; g.noms[i] = ev.target.value.trim(); synchroniserCombat(); enregistrer(); } })))) : null);
  }

  // ───── Recherche dans le bestiaire ─────

  function etatRecherche(id) {
    if (!recherches.has(id)) recherches.set(id, { texte: '', fp: '', source: '', nombre: PAR_PAGE, liaison: null });
    return recherches.get(id);
  }
  const focusRecherche = id => setTimeout(() => flottantOuvert('rmj:' + id)?.el.querySelector('.cm-recherche__champ')?.focus(), 0);

  function filtrer(liste, rech) {
    const mots = normaliser(rech.texte).split(/\s+/).filter(Boolean);
    const [min, max] = rech.fp ? rech.fp.split('-').map(Number) : [null, null];
    const src = rech.source && rech.source !== 'homebrew' ? Number(rech.source) : null;
    const maison = rech.source === 'homebrew';
    if (!mots.length && min === null && !src && !maison) return null;
    const q = mots.join(' ');
    return liste
      .filter(m => mots.every(w => m.cle.includes(w)) && (min === null || (m.valeurFp ?? -1) >= min && m.valeurFp <= max) && (!src || m.sources.includes(src) || m.source === src) && (!maison || m.homebrew))
      .map(m => ({ m, rang: !q ? 3 : m.cle === q ? 0 : m.cle.startsWith(q) ? 1 : m.cle.split(/[\s,'’-]+/).some(w => w.startsWith(mots[0])) ? 2 : 3 }))
      .sort((a, b) => a.rang - b.rang || a.m.nom.localeCompare(b.m.nom, 'en') || Number(a.m.legacy) - Number(b.m.legacy))
      .map(x => x.m);
  }

  function blocRecherche(vue) {
    const rech = etatRecherche(vue.id);
    const resultats = h('div', { class: 'cm-recherche__resultats', 'aria-live': 'polite' }, h('p', { class: 'ui-s cm-sourdine' }, 'Chargement du bestiaire…'));
    let minuterie = null;
    const majResultats = () => chargerBestiaire().then(b => resultats.replaceChildren(...vueResultats(vue, b, rech)),
      err => resultats.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Bestiaire de D&D Beyond injoignable', err.message, ' ',
        bouton('Réessayer', { classe: 'bn-btn--s', icone: 'lu-refresh-cw', onclick: () => { resultats.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Chargement…')); majResultats(); } }))));
    const champ = h('input', { class: 'bn-input cm-recherche__champ', type: 'search', value: rech.texte, placeholder: 'Nom anglais : zombie, wolf, vampire spawn…', 'aria-label': 'Chercher un monstre',
      oninput: ev => { rech.texte = ev.target.value; rech.nombre = PAR_PAGE; clearTimeout(minuterie); minuterie = setTimeout(majResultats, 120); } });
    const choix = (cle, options, etiquette) => {
      const sel = h('select', { class: 'bn-select', 'aria-label': etiquette, onchange: ev => { rech[cle] = ev.target.value; rech.nombre = PAR_PAGE; majResultats(); } },
        options.map(([val, lib]) => h('option', { value: val }, lib)));
      sel.value = rech[cle];
      return sel;
    };
    majResultats();
    return section('Ajouter des monstres', 'lu-search',
      rech.liaison ? alerte('brume', 'lu-info', `Choisir le monstre pour : ${rech.liaison.nom}`, 'Le « + » d\'un monstre le relie à cette créature, pour toutes les rencontres.', ' ',
        bouton('Annuler', { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { rech.liaison = null; rafraichirFenetres(); } })) : null,
      h('div', { class: 'cm-recherche__filtres' }, champ,
        choix('fp', FP_FILTRES, 'Facteur de puissance'),
        choix('source', [['', 'Tous les livres'], ...livres().liste.map(([id, sigle, titre]) => [String(id), `${sigle} · ${titre}`]),
          ...(livres().homebrew_monstres ? [['homebrew', 'Homebrew']] : [])], 'Livre'),
        bouton('', { icone: 'lu-refresh-cw', classe: 'bn-btn--s bn-btn--fantome', titre: 'Relire D&D Beyond (un monstre homebrew modifié) : le bestiaire, les fiches et les monstres de cette rencontre',
          onclick: ev => { ev.currentTarget.disabled = true; resultats.replaceChildren(h('p', { class: 'ui-s cm-sourdine' }, 'Relecture de D&D Beyond…')); essayer(() => relireMonstres(vue.id)).finally(() => rafraichirFenetres(vue.id)); } })),
      resultats);
  }

  function vueResultats(vue, b, rech) {
    const trouves = filtrer(b.liste, rech);
    if (!trouves) return [h('p', { class: 'ui-s cm-sourdine' }, `${b.liste.length} monstres dans ${livres().liste.map(s => s[1]).join(', ')}${livres().homebrew_monstres ? ' et vos homebrews' : ''}. Tapez un nom, ou choisissez un FP ou un livre.`)];
    if (!trouves.length) return [h('p', { class: 'ui-s cm-sourdine' }, 'Aucun monstre ne correspond.')];
    const affiches = trouves.slice(0, rech.nombre);
    return [
      h('ul', { class: 'cm-recherche__liste' }, affiches.map(m => h('li', { class: 'cm-recherche__ligne' },
        avatar(m.avatar, m.nom),
        h('button', { type: 'button', class: 'cm-recherche__nom', title: 'Ouvrir la fiche', onclick: () => ouvrirMonstre(m.id, vue.id) },
          h('span', { class: 'cm-recherche__titre' }, m.nom, m.legacy ? h('span', { class: 'cm-sourdine' }, ' · 2014') : null),
          h('span', { class: 'ui-s cm-sourdine' }, [m.valeurFp != null ? libellePuissance({ valeur: m.valeurFp }) : null, typeCourt(m.type, m.taille, b.cfg),
            m.homebrew ? 'Homebrew' : m.sources.map(id => livres().sigle.get(id)).filter(Boolean).join(', ') || livres().sigle.get(m.source), m.acces === 4 ? 'non débloqué' : null].filter(Boolean).join(' · '))),
        bouton('', { icone: 'lu-plus', classe: 'bn-btn--s' + (rech.liaison ? ' bn-btn--primaire' : ''),
          titre: rech.liaison ? `Relier « ${rech.liaison.nom} » à ${m.nom}` : `Ajouter ${m.nom} à la rencontre`,
          onclick: () => essayer(() => ajouterDepuisRecherche(vue.id, m.id)) })))),
      trouves.length > affiches.length ? h('div', { class: 'bn-groupe' }, bouton(`Afficher plus (${trouves.length - affiches.length} de plus)`, { classe: 'bn-btn--s bn-btn--fantome',
        onclick: () => { rech.nombre += PAR_PAGE; rafraichirFenetres(); } })) : null,
    ].filter(Boolean);
  }

  async function ajouterDepuisRecherche(id, monstreId) {
    const rech = etatRecherche(id);
    const l = rech.liaison;
    rech.liaison = null;
    if (l) {
      // Relier : la créature prend ce monstre, ici et partout ; un groupe déjà fait pour elle change de monstre.
      const e = entree(id, true);
      const ancien = (e.groupes || []).find(g => g.creature && normaliser(g.creature) === normaliser(l.nom));
      if (ancien) e.groupes = e.groupes.filter(g => g !== ancien);
      let quantite = ancien?.quantite ?? (typeof l.quantite === 'number' ? l.quantite : null);   // déjà tiré (tirage aléatoire)
      if (quantite == null) {
        const t = tirerQuantite(l.formule);
        if (t.jet) montrerJets([{ libelle: l.nom, jet: t.jet, formule: String(l.formule) }], { legende: `Nombre : ${l.nom}`, depuis: document.activeElement });
        quantite = t.n;
      }
      await ajouterGroupe(id, monstreId, { creature: l.nom, quantite, formule: estFixe(l.formule) ? null : String(l.formule) });
    } else await ajouterGroupe(id, monstreId);
    rafraichirFenetres(id);
  }

  async function essayer(fn) {
    try { await fn(); } catch (err) { annonce('D&D Beyond injoignable', err.message, 'cierge'); }
  }

  // Fiche d'un monstre (Bloc de stats), son image en tête ; pour : rencontre à laquelle l'ajouter.
  async function ouvrirMonstre(monstreId, pour = null) {
    try {
      const [cfg, [f]] = await Promise.all([configBeyond(), fichesMonstres([monstreId])]);
      if (!f) return;
      const vue = pour ? vueDe(pour) : null;
      flottant('monstre-' + f.id, { surtitre: 'Monstre · D&D Beyond', titre: f.name, largeur: 620, miniature: f.avatarUrl || f.largeAvatarUrl || null, pictogramme: 'crane', contenu: [
        blocStats(f, cfg, { image: f.largeAvatarUrl || f.avatarUrl || null }),
        vue ? h('div', { class: 'bn-groupe' }, bouton(`Ajouter à « ${vue.nom} »`, { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-plus', onclick: () => essayer(() => ajouterDepuisRecherche(pour, f.id)) })) : null,
      ].filter(Boolean) });
    } catch (err) { annonce('Fiche illisible', err.message); }
  }

  const rattachementObjet = vue => ({ rencontre: vue.id, lieu: vue.scen?.lieu || vue.e?.rattachement?.lieu, sous_lieu: vue.scen?.sous_lieu || vue.e?.rattachement?.sous_lieu });

  function piedFenetre(vue) {
    const c = v().combat;
    // Tirée, pas encore lancée : la lancer (notée au journal à ce moment), ou l'abandonner (rien n'a eu lieu).
    if (vue.e?.brouillon) return h('div', { class: 'bn-groupe cm-prep__pied' },
      bouton('Lancer le combat', { classe: 'bn-btn--s bn-btn--primaire', icone: 'epee', onclick: () => lancerBrouillon(vue.id),
        titre: 'Elle a lieu : notée au journal des rencontres (numéro, plafond), rattachée à l\'endroit où sont les héros, chargée dans le widget Combat' }),
      bouton('Abandonner', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', titre: 'Elle n\'a pas lieu : rien n\'est noté', onclick: () => flottantOuvert('rmj:' + vue.id)?.fermer() }));
    return h('div', { class: 'bn-groupe cm-prep__pied' },
      c?.rencontre === vue.id ? badge('Dans le widget Combat', 'sang', 'epee')
        : bouton('Lancer le combat', { classe: 'bn-btn--s bn-btn--primaire', icone: 'epee', titre: 'La charger dans le widget Combat, en mode Rencontre', onclick: () => lancerRencontre(vue.id) }),
      vue.statut === 'terminee' ? bouton('Rouvrir', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: () => rouvrir(vue.id) })
        : bouton('Marquer terminée…', { classe: 'bn-btn--s', icone: 'lu-check', onclick: () => demanderFin(vue.id) }),
      // La remarque, à tout moment et depuis n'importe quel onglet (retour du MJ, 2026-11-05).
      bouton('Remarque', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-pencil', titre: vue.e?.remarque ? 'Modifier votre remarque sur cette rencontre' : 'Ajouter une remarque sur cette rencontre', onclick: () => modifierRemarque(vue.id) }),
      vue.origine === 'aleatoire' ? null : O.boutonNouveau(rattachementObjet(vue)),
      vue.origine === 'prevue' ? (vue.e ? bouton('Effacer la préparation', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-rotate-ccw', onclick: () => effacerPreparation(vue.id) }) : null)
        : bouton('Supprimer', { classe: 'bn-btn--s bn-btn--danger', icone: 'lu-trash-2', onclick: () => supprimer(vue.id) }));
  }

  // ───── Relier d'avance une créature des tables (demande du MJ, 2026-10-23) ─────
  // Onglet Tables de Rencontres : un clic sur une créature ouvre cette fenêtre, qui la relie à un monstre de D&D Beyond
  // (`correspondances`), sans préparer de rencontre (le nombre varie d'un tirage à l'autre). Un tirage qui la donne prendra
  // ce monstre d'office.
  const recherchesLiaison = new Map();   // nom normalisé -> { texte, fp, source, nombre }
  function ouvrirLiaison(c) {
    const cle = normaliser(c.nom).trim();
    if (!recherchesLiaison.has(cle)) recherchesLiaison.set(cle, { texte: nomAnglais(c) || '', fp: '', source: '', nombre: PAR_PAGE });
    const rech = recherchesLiaison.get(cle);
    const fenetre = 'relier:' + cle;
    const resultats = h('div', { class: 'cm-recherche__resultats', 'aria-live': 'polite' }, h('p', { class: 'ui-s cm-sourdine' }, 'Chargement du bestiaire…'));
    const relier = m => {
      v().correspondances[cle] = { monstre: m.id, nom: m.nom };
      enregistrer();
      ouvrirLiaison(c);
    };
    const majResultats = () => chargerBestiaire().then(b => {
      const trouves = filtrer(b.liste, rech);
      const k = correspondance(c.nom);
      resultats.replaceChildren(...(!trouves ? [h('p', { class: 'ui-s cm-sourdine' }, 'Tapez un nom anglais.')]
        : !trouves.length ? [h('p', { class: 'ui-s cm-sourdine' }, 'Aucun monstre ne correspond.')]
          : [h('ul', { class: 'cm-recherche__liste' }, trouves.slice(0, rech.nombre).map(m => h('li', { class: 'cm-recherche__ligne' + (k?.monstre === m.id ? ' est-actif' : '') },
            avatar(m.avatar, m.nom),
            h('button', { type: 'button', class: 'cm-recherche__nom', title: 'Ouvrir la fiche', onclick: () => ouvrirMonstre(m.id) },
              h('span', { class: 'cm-recherche__titre' }, m.nom, m.legacy ? h('span', { class: 'cm-sourdine' }, ' · 2014') : null),
              h('span', { class: 'ui-s cm-sourdine' }, [m.valeurFp != null ? libellePuissance({ valeur: m.valeurFp }) : null, typeCourt(m.type, m.taille, b.cfg),
                m.homebrew ? 'Homebrew' : m.sources.map(id => livres().sigle.get(id)).filter(Boolean).join(', ') || livres().sigle.get(m.source)].filter(Boolean).join(' · '))),
            bouton('', { icone: 'lu-check', classe: 'bn-btn--s bn-btn--primaire', titre: `Relier « ${c.nom} » à ${m.nom}`, onclick: () => relier(m) })))),
          trouves.length > rech.nombre ? bouton(`Afficher plus (${trouves.length - rech.nombre} de plus)`, { classe: 'bn-btn--s bn-btn--fantome', onclick: () => { rech.nombre += PAR_PAGE; majResultats(); } }) : null].filter(Boolean)));
    }, err => resultats.replaceChildren(alerte('cierge', 'lu-triangle-alert', 'Bestiaire de D&D Beyond injoignable', err.message)));
    let minuterie = null;
    const champ = h('input', { class: 'bn-input cm-recherche__champ', type: 'search', value: rech.texte, placeholder: 'Nom anglais : zombie, wolf, vampire spawn…', 'aria-label': 'Chercher un monstre',
      oninput: ev => { rech.texte = ev.target.value; rech.nombre = PAR_PAGE; clearTimeout(minuterie); minuterie = setTimeout(majResultats, 120); } });
    const k = correspondance(c.nom);
    const en = nomAnglais(c);
    majResultats();
    flottant(fenetre, { surtitre: 'Créature des tables', titre: premiereMajuscule(c.nom), largeur: 520, contenu: h('div', { class: 'cm-pile' },
      k ? h('p', { class: 'ui' }, icone('lu-check', 'bn-icone--s'), ' Reliée à ', h('button', { type: 'button', class: 'cm-lien-bouton', title: 'Voir la fiche', onclick: () => ouvrirMonstre(k.monstre) }, k.nom), ' ',
        bouton('', { icone: 'lu-x', classe: 'bn-btn--s bn-btn--fantome', titre: 'Retirer le lien', onclick: () => { delete v().correspondances[cle]; enregistrer(); ouvrirLiaison(c); } }))
        : h('p', { class: 'ui-s cm-sourdine' }, `Pas encore reliée${en ? ` ; profil prévu par les données : ${en}` : ''}. Le monstre choisi servira à chaque tirage qui la donne.`),
      noteCreature(noteMj(c)),
      h('div', { class: 'cm-recherche__filtres' }, champ),
      resultats) });
    setTimeout(() => flottantOuvert(fenetre)?.el.querySelector('.cm-recherche__champ')?.focus(), 0);
  }

  return {
    s, v, vueDe, ouDe, prevues, duJalon, deLEtape, duLieu, duTrajet, historique, preparees, duTirage, correspondance, ouvrirLiaison, annuler, oublierTirage,
    ligne, boutonNouvelle, nouvelle, ouvrir, ouvrirMonstre, blocContexte, lancerRencontre, demarrer, demanderFin, modifierRemarque, rouvrir,
    depuisTirage, depuisMaison, synchroniserCombat, enregistrer, libelleQuand, ficheConnue, fichesMonstres, noteMj,
    difficulteDe, difficulteActive, journee, vueJournee,
  };
}
