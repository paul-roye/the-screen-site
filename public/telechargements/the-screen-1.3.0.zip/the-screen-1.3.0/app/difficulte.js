// Difficulté d'une rencontre selon Flee, Mortals! (MCDM), que le MJ suit (2026-10-22) : règles de construction des rencontres
// de l'introduction du livre (« Encounter Building », « Minions »), résumées en français. Budget de FP par personnage selon le
// niveau moyen du groupe, plafond de FP, créatures solo, sbires (5, 8 ou 10 pour une créature standard), rôles des créatures,
// points de la journée d'aventure. Préparation des rencontres (app/rencontres-mj.js) et widget Combat ; aide en fenêtre.
// Le rôle de chaque groupe de monstres est gardé avec la rencontre (groupes[].role, etat/rencontres-mj.json) ; le choix de
// compter les compagnons, dans etat/campagne.json (difficulte.compagnons).

import { h, icone, bouton, badge, flottant, flottantOuvert, infobulle, FINE } from './ui.js';

// Niveau moyen -> [FP par personnage : facile, standard, difficile ; plafond de FP] (table « Encounter CR per Character »).
const TABLE = {
  1: [1 / 8, 1 / 8, 1 / 4, 1], 2: [1 / 8, 1 / 4, 1 / 2, 3], 3: [1 / 4, 1 / 2, 3 / 4, 4], 4: [1 / 2, 3 / 4, 1, 6],
  5: [1, 1.5, 2.5, 8], 6: [1.5, 2, 3, 9], 7: [2, 2.5, 3.5, 10], 8: [2.5, 3, 4, 12], 9: [3, 3.5, 4.5, 13], 10: [3.5, 4, 5, 15],
  11: [4, 4.5, 5.5, 16], 12: [4.5, 5, 6, 17], 13: [5, 5.5, 6.5, 19], 14: [5.5, 6, 7, 20], 15: [6, 6.5, 7.5, 22],
  16: [6.5, 7, 8, 24], 17: [7, 7.5, 8.5, 25], 18: [7.5, 8, 9, 26], 19: [8, 8.5, 9.5, 28], 20: [8.5, 9, 10, 30],
};
const ligneTable = niveau => TABLE[Math.min(20, Math.max(1, niveau))];
// Au-delà du budget difficile, par personnage, à son niveau (fixés par le MJ, 2026-10-23 ; pas des règles de Flee, Mortals!) :
// jusqu'au niveau 4, plus prudent, en proportion : extrême dès 1,5 fois son FP difficile, TPK dès 2 fois ; à partir du
// niveau 5, extrême dès son FP difficile + 1, TPK + 2. Renvoie [à ajouter pour extrême, à ajouter pour TPK].
const auDela = niveau => { const d = ligneTable(niveau)[2]; return niveau <= 4 ? [d / 2, d] : [1, 2]; };
// Le début d'une zone (demande du MJ, 2026-10-23) : son budget, arrondi au demi-FP le plus proche à partir de 1 FP, vers le
// bas à mi-chemin (difficile 2 1/4 : dès 2) ; tel quel en dessous de 1 (facile 5/8).
const palier = b => (b < 1 ? b : Math.floor(b * 2 + 0.5 - 1e-9) / 2);

// Les niveaux de difficulté et leurs points de la journée d'aventure ; la couleur de leur badge.
export const DIFFICULTES = {
  triviale: { nom: 'Triviale', points: 0, ton: null },
  facile: { nom: 'Facile', points: 1, ton: 'brume' },
  standard: { nom: 'Standard', points: 2, ton: 'soleil' },
  difficile: { nom: 'Difficile', points: 4, ton: 'cierge' },
  extreme: { nom: 'Extrême', points: 8, ton: 'sang' },
  // Au-delà d'extrême (demande du MJ, 2026-10-23 ; pas une règle de Flee, Mortals!) : la mort assurée du groupe. Budget :
  // seuil du MJ (AU_DELA) ; solo : au-delà d'une zone extrême aussi large que la zone difficile. Affichée seulement atteinte.
  tpk: { nom: 'TPK', points: 16, ton: 'tpk' },
};
export const JOURNEE = { min: 6, max: 8, rude: 12 };   // points entre deux repos longs ; 12 : une journée qui ne garantit pas la survie

// Rôles des créatures (« Using Creature Roles »), avec un conseil de jeu court.
export const ROLES = {
  embusque: { nom: 'Embusqué', en: 'Ambusher', conseil: 'Se cache ou disparaît à chaque tour, s\'acharne sur un seul héros. Il lui faut du couvert, et d\'autres créatures pour occuper le reste du groupe.' },
  artillerie: { nom: 'Artillerie', en: 'Artillery', conseil: 'Frappe à distance, faible au contact : s\'éloigne des héros à moins de 30 ft et se cache derrière une brute ou un soldat.' },
  brute: { nom: 'Brute', en: 'Brute', conseil: 'Beaucoup de PV, frappe fort ; fonce sur le groupe de héros le plus proche. Simple à jouer : on peut en mettre plusieurs.' },
  controleur: { nom: 'Contrôleur', en: 'Controller', conseil: 'Affaiblit, gêne, déplace les héros ; son plus gros effet dès le début. Un ou deux au plus par rencontre.' },
  meneur: { nom: 'Meneur', en: 'Leader', conseil: 'Renforce ses alliés, appelle des renforts, a des actions de méchant. Un seul meneur ou soutien par rencontre.' },
  soutien: { nom: 'Soutien', en: 'Support', conseil: 'Comme un meneur, sans actions de méchant. Un seul meneur ou soutien par rencontre ; reste près de ses alliés.' },
  sbire: { nom: 'Sbire', en: 'Minion', conseil: 'Tombe au premier coup, attaque en groupe. Protège l\'artillerie, les contrôleurs et les meneurs.' },
  tirailleur: { nom: 'Tirailleur', en: 'Skirmisher', conseil: 'Mobile : frappe les héros fragiles puis se replie. Se marie avec tous les rôles.' },
  soldat: { nom: 'Soldat', en: 'Soldier', conseil: 'Attire les coups pour protéger ses alliés ; plusieurs soldats se répartissent les héros.' },
  solo: { nom: 'Solo', en: 'Solo', conseil: 'Affronté seul, avec actions de méchant et de repaire ; bouge sans cesse et vise le héros qui le menace le plus.' },
};

// Sbires qui valent une créature standard de leur FP (table « Minion Encounter Building »).
export const sbiresParStandard = fp => ((fp ?? 0) <= 4 ? 5 : fp <= 8 ? 8 : 10);

// Rôle deviné d'après la fiche de D&D Beyond (monstres de Flee, Mortals!) : d'abord ses sous-types (« Solo », « Minion »,
// « Brute »… : sous-types de D&D Beyond, `subTypes`, ids de `monsterSubTypes` de www.dndbeyond.com/api/config/json, relevés
// le 2026-10-23 ; ce que le MJ coche sur son homebrew, comme les monstres de Flee, Mortals!), puis ses étiquettes (`tags`),
// puis son texte : le trait « Minion » fait un sbire, des actions de méchant (« Villain Actions ») un solo. Sinon rien.
const ROLE_PAR_SOUS_TYPE = new Map([[137, 'sbire'], [143, 'meneur'], [144, 'tirailleur'], [146, 'artillerie'], [147, 'controleur'],
  [148, 'embusque'], [149, 'solo'], [150, 'soutien'], [154, 'brute'], [160, 'soldat']]);
const ROLE_PAR_ETIQUETTE = new Map(Object.entries(ROLES).flatMap(([cle, r]) => [[normaliserRole(r.en), cle], [normaliserRole(r.nom), cle]]));
function normaliserRole(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim(); }
export function roleDevine(fiche) {
  if (!fiche) return null;
  for (const st of fiche.subTypes || []) {
    const role = ROLE_PAR_SOUS_TYPE.get(Number(st?.id ?? st));
    if (role) return role;
  }
  for (const tag of fiche.tags || []) {
    const role = ROLE_PAR_ETIQUETTE.get(normaliserRole(tag?.name ?? tag));
    if (role) return role;
  }
  const t = [fiche.specialTraitsDescription, fiche.actionsDescription, fiche.bonusActionsDescription, fiche.legendaryActionsDescription]
    .filter(Boolean).join(' ').replace(/<[^>]+>/g, ' ');
  if (/\bMinion\.?\s/.test(t)) return 'sbire';
  if (/\bVillain Actions?\b/i.test(t)) return 'solo';
  return null;
}

// Un FP ou une somme de FP, lisible : « 1/8 », « 2 + 1/2 », « 1 + 3/8 » (demande du MJ, 2026-10-23 : « 1 3/8 » se lisait
// « 13/8 »). Fraction réduite. Au-delà des huitièmes, deux décimales.
export function nombreFP(x) {
  if (x == null) return '—';
  const huitiemes = Math.round(x * 8);
  if (Math.abs(huitiemes - x * 8) > 1e-6) return String(Math.round(x * 100) / 100).replace('.', ',');
  const entier = Math.floor(huitiemes / 8), reste = huitiemes % 8;
  if (!reste) return String(entier);
  const g = reste % 4 === 0 ? 4 : reste % 2 === 0 ? 2 : 1;
  const frac = `${reste / g}/${8 / g}`;
  return entier ? `${entier}${FINE}+${FINE}${frac}` : frac;
}

// Le groupe d'aventuriers d'après les fiches de D&D Beyond (beyond.json) : les héros présents, et leurs compagnons (le
// familier) comptés comme un personnage de 2 niveaux de moins que leur maître, 1 au moins, quand `compagnons` est vrai.
// moyen : le niveau moyen des héros seuls (arrondi à l'inférieur), qui donne le plafond de FP : un compagnon n'y compte
// pas (décision du MJ, 2026-10-22). absents : clés « pj:<id> » ou « cr:<id>:<id> » du widget Combat.
export function groupeAventuriers(beyond, { absents = new Set(), compagnons = true } = {}) {
  const membres = [];
  for (const [id, f] of Object.entries(beyond?.fiches || {})) {
    if (absents.has('pj:' + id)) continue;
    const niveau = f.niveau || 1;
    membres.push({ nom: f.nom.split(' ')[0], niveau, compagnon: false });
    if (compagnons) for (const cr of f.creatures || []) {
      if (!absents.has(`cr:${id}:${cr.id}`)) membres.push({ nom: cr.nom, niveau: Math.max(1, niveau - 2), compagnon: true });
    }
  }
  const heros = membres.filter(m => !m.compagnon);
  return { membres, n: membres.length, moyen: heros.length ? Math.max(1, Math.floor(heros.reduce((a, m) => a + m.niveau, 0) / heros.length)) : 1 };
}

// La difficulté d'une dépense de FP : chaque difficulté commence à son palier (le budget arrondi), jusqu'au palier suivant ;
// sous le palier facile, triviale.
function niveauDe(depense, p) {
  const atteint = x => depense >= x - 1e-9;
  return atteint(p.tpk) ? 'tpk' : atteint(p.extreme) ? 'extreme' : atteint(p.difficile) ? 'difficile'
    : atteint(p.standard) && p.standard > p.facile ? 'standard' : atteint(p.facile) ? 'facile' : 'triviale';
}

// Évaluation d'une rencontre : groupes [{ nom, fp, quantite, role }], groupe (groupeAventuriers). Renvoie la difficulté,
// le budget de FP dépensé et les budgets du groupe, le plafond, et des alertes (texte, ton).
// Budget (lecture du MJ, 2026-10-22) : le FP par personnage de la table, au niveau de chacun, additionné : 4 héros de
// niveau 4 et un familier (niveau 2), standard : 4 × 3/4 + 1/4. Plafond : celui du niveau moyen des héros.
export function evaluer(groupes, groupe) {
  const plafond = ligneTable(groupe.moyen)[3];
  const n = Math.max(1, groupe.n);
  const somme = k => groupe.membres.reduce((a, m) => a + ligneTable(m.niveau)[k], 0);
  const auDelaDe = k => groupe.membres.reduce((a, m) => a + ligneTable(m.niveau)[2] + auDela(m.niveau)[k], 0);
  const budgets = { facile: somme(0), standard: somme(1), difficile: somme(2), extreme: auDelaDe(0), tpk: auDelaDe(1) };
  const paliers = Object.fromEntries(Object.entries(budgets).map(([k, b]) => [k, palier(b)]));
  const presents = (groupes || []).filter(g => g.quantite > 0);
  const sbires = presents.filter(g => g.role === 'sbire');
  const solos = presents.filter(g => g.role === 'solo');
  const autres = presents.filter(g => g.role !== 'sbire' && g.role !== 'solo');
  const alertes = [];
  const nb = l => l.reduce((a, g) => a + g.quantite, 0);
  const sansFp = presents.filter(g => g.fp == null);
  if (sansFp.length) alertes.push({ ton: 'cierge', texte: `FP inconnu : ${sansFp.map(g => g.nom).join(', ')} (pas compté).` });
  const tropForts = presents.filter(g => (g.fp ?? 0) > plafond && g.role !== 'solo');
  if (tropForts.length) alertes.push({ ton: 'sang', texte: `Au-dessus du plafond (FP ${plafond}) : ${tropForts.map(g => `${g.nom} (FP ${nombreFP(g.fp)})`).join(', ')}. Trop dangereux pour ce niveau, quel que soit le budget.` });
  const nonSbires = nb(autres) + nb(solos);
  if (nonSbires > 3 * n) alertes.push({ ton: 'cierge', texte: `${nonSbires} créatures (hors sbires) pour ${n} personnages : au-delà de trois par personnage, la rencontre devient plus dure que prévu.` });
  const nSbires = nb(sbires);
  if (nSbires) {
    const unStandard = Math.min(...sbires.map(g => sbiresParStandard(g.fp)));
    const max = groupe.moyen <= 10 ? 20 : 30;
    if (nSbires < unStandard) alertes.push({ ton: 'brume', texte: `${nSbires} sbire${nSbires > 1 ? 's' : ''} : il en faut au moins ${unStandard} (une créature standard) pour qu'ils pèsent.` });
    if (nSbires > max) alertes.push({ ton: 'cierge', texte: `${nSbires} sbires : ${groupe.moyen <= 10 ? '10 à 20' : '20 à 30'} suffisent à ce niveau ; au-delà, le combat traîne.` });
  }
  const parRole = r => nb(presents.filter(g => g.role === r));
  if (parRole('controleur') > 2) alertes.push({ ton: 'brume', texte: 'Plus de deux contrôleurs : leurs effets compliquent beaucoup le combat.' });
  if (parRole('meneur') + parRole('soutien') > 1) alertes.push({ ton: 'cierge', texte: 'Plus d\'un meneur ou soutien : leurs renforts se cumulent et peuvent rendre la rencontre mortelle.' });
  const rolesDistincts = new Set(autres.map(g => g.role).filter(Boolean));
  if (nb(autres) >= 3 && rolesDistincts.size === 1 && autres.every(g => g.role)) alertes.push({ ton: 'brume', texte: `Que des ${ROLES[[...rolesDistincts][0]].nom.toLowerCase()}s : mélanger les rôles rend le combat plus vivant.` });

  // Un solo : pas de budget, son FP comparé au plafond (table « Solo Creature Encounters »). Un solo de FP 4 ou moins
  // convient à un groupe d'un niveau plus bas (deux pour 6 ou 7 personnages) : le plafond se lit un ou deux niveaux plus haut
  // (niveau 2 : plafond 4, difficile de FP 2 à 4). Le MJ l'a vérifié dans le livre (2026-10-23).
  if (solos.length) {
    const s = solos.reduce((a, g) => ((g.fp ?? 0) > (a.fp ?? 0) ? g : a));
    const grand = n >= 6;
    const plafondSolo = (s.fp ?? 0) <= 4 ? ligneTable(groupe.moyen + (grand ? 2 : 1))[3] : plafond;
    const ecart = plafondSolo - (s.fp ?? 0);
    const seuils = grand ? [1, 3, 5] : [2, 4, 6];   // plafond moins : 0–1 / 0–2 difficile, … standard, … facile, au-delà triviale
    const niveau = ecart < -(seuils[0] + 1) ? 'tpk' : ecart < 0 ? 'extreme' : ecart <= seuils[0] ? 'difficile' : ecart <= seuils[1] ? 'standard' : ecart <= seuils[2] ? 'facile' : 'triviale';
    if (presents.length > 1 || s.quantite > 1) alertes.push({ ton: 'cierge', texte: 'Une créature solo s\'affronte seule : les autres créatures ne sont pas comptées, et la rencontre sera plus dure.' });
    return { mode: 'solo', niveau, points: DIFFICULTES[niveau].points, solo: s, plafond, plafondSolo, ecart, seuils, budgets, depense: s.fp ?? 0, groupe, alertes };
  }

  const depense = autres.reduce((a, g) => a + (g.fp ?? 0) * g.quantite, 0)
    + sbires.reduce((a, g) => a + (g.fp ?? 0) * g.quantite / sbiresParStandard(g.fp), 0);
  const niveau = presents.length ? niveauDe(depense, paliers) : null;
  return { mode: 'budget', niveau, points: niveau ? DIFFICULTES[niveau].points : 0, plafond, budgets, paliers, depense, groupe, alertes };
}

// Le badge de la difficulté : « Standard · 2 pts ».
export function badgeDifficulte(ev, { court = false } = {}) {
  if (!ev?.niveau) return null;
  const d = DIFFICULTES[ev.niveau];
  return badge(court ? d.nom : `${d.nom} · ${d.points}${FINE}pt${d.points > 1 ? 's' : ''}`, d.ton, 'crane');
}

// Le résumé d'une évaluation : le badge, la jauge du budget (repères facile, standard, difficile), les chiffres, les alertes.
// aide : ouvre la fenêtre des règles. reglage : un élément à placer sous les chiffres (aucun aujourd'hui : le compte des
// compagnons se règle dans la fenêtre Campagne, onglet Rencontres).
export function vueDifficulte(ev, { aide = true, reglage = null, avecBadge = true } = {}) {   // avecBadge faux : déjà montré au-dessus
  if (!ev) return null;
  const g = ev.groupe;
  const qui = libelleGroupe(g);
  const detailGroupe = calculStandard(g);
  let chiffres, jauge;
  if (ev.mode === 'solo') {
    // La jauge d'un solo (demande du MJ, 2026-10-23) : l'échelle de FP de la table « Solo Creature Encounters », une zone par
    // difficulté autour du plafond (4–5 personnages : plafond moins 7 ou plus triviale, 5–6 facile, 3–4 standard, 0–2
    // difficile, au-delà extrême) ; le curseur sur le FP du solo.
    const c = ev.plafondSolo, [s0, s1, s2] = ev.seuils;
    const finTpk = Math.max(c + s0 + 4, (ev.solo.fp ?? 0) + 1);   // la zone TPK (seulement atteinte) : de quoi placer le curseur
    // Le FP de chaque zone : de son début (ramené à 0) à la veille de la suivante ; une zone qui part de 0 dit « inférieur à »
    // (FP 1/8 à 1/2) ; « difficile » va jusqu'au plafond compris.
    const titreZone = z => (z.niveau === 'tpk' ? `solo au-dessus de FP ${c + s0 + 1} : mort assurée` : z.niveau === 'extreme' ? (ev.niveau === 'tpk' ? `solo de FP ${c + 1} à ${c + s0 + 1}` : `solo au-dessus de FP ${c}`)
      : z.niveau === 'difficile' ? `solo de FP ${z.debut} à ${c}`
        : z.debut === 0 ? `solo de FP inférieur à ${z.fin}`
          : z.fin - 1 > z.debut ? `solo de FP ${z.debut} à ${z.fin - 1}` : `solo de FP ${z.debut}`);
    const zones = [
      { niveau: 'triviale', debut: 0, fin: c - s2 },
      { niveau: 'facile', debut: c - s2, fin: c - s1 },
      { niveau: 'standard', debut: c - s1, fin: c - s0 },
      { niveau: 'difficile', debut: c - s0, fin: c },
      { niveau: 'extreme', debut: c, fin: c + s0 + 1 },
      { niveau: 'tpk', debut: c + s0 + 1, fin: finTpk },
    ].map(z => ({ ...z, debut: Math.max(0, z.debut) })).filter(z => z.fin > z.debut && (z.niveau !== 'tpk' || ev.niveau === 'tpk')).map(z => ({ ...z, titre: titreZone(z) }));
    jauge = jaugeZones(zones, ev.solo.fp ?? 0, ev.niveau, `FP ${nombreFP(ev.solo.fp)}`, z => `${DIFFICULTES[z.niveau].nom} : ${z.titre}`);
    chiffres = `Solo : ${ev.solo.nom}, FP ${nombreFP(ev.solo.fp)} pour un plafond de ${c}${c !== ev.plafond ? ` (petit solo, FP 4 ou moins : lu comme pour un groupe d'un niveau au-dessus)` : ''} : plafond ${ev.ecart >= 0 ? `moins ${ev.ecart}` : `dépassé de ${-ev.ecart}`}.`;
  } else {
    const { facile, standard, difficile } = ev.budgets;
    const p = ev.paliers;
    // La jauge (refaite à la demande du MJ, 2026-10-23) : une zone par difficulté, qui commence à son palier (le budget
    // arrondi) ; la zone TPK seulement quand la rencontre y est. Le curseur blanc marque les FP dépensés.
    const tpk = ev.niveau === 'tpk';
    const finTpk = Math.max(p.tpk + (p.tpk - p.extreme), ev.depense * 1.05);   // la zone TPK (seulement atteinte) : de quoi placer le curseur
    const debuts = [['triviale', 0], ['facile', p.facile], ['standard', p.standard], ['difficile', p.difficile], ['extreme', p.extreme], ...(tpk ? [['tpk', p.tpk]] : [])];
    // La zone extrême va jusqu'au seuil TPK, même quand la zone TPK n'est pas montrée.
    const zones = debuts.map(([niveau, debut], i) => ({ niveau, debut, fin: debuts[i + 1]?.[1] ?? (niveau === 'extreme' ? p.tpk : finTpk) })).filter(z => z.fin > z.debut);
    const des = k => `dès ${nombreFP(p[k])} FP${p[k] !== ev.budgets[k] ? ` (budget ${nombreFP(ev.budgets[k])}, arrondi)` : ''}`;
    jauge = jaugeZones(zones, ev.depense, ev.niveau, `${nombreFP(ev.depense)} FP`, z => `${DIFFICULTES[z.niveau].nom} : ${z.niveau === 'triviale' ? `moins de ${nombreFP(p.facile)} FP` : des(z.niveau)}${z.niveau === 'tpk' ? ' : mort assurée' : ''}`);
    chiffres = `FP dépensés ${nombreFP(ev.depense)} · budgets facile ${nombreFP(facile)}, standard ${nombreFP(standard)}, difficile ${nombreFP(difficile)} · extrême dès ${nombreFP(p.extreme)} · plafond FP ${ev.plafond} (héros niveau ${g.moyen})`;
  }
  return h('div', { class: 'cm-difficulte' },
    h('div', { class: 'cm-difficulte__tete' },
      avecBadge ? badgeDifficulte(ev) || h('span', { class: 'ui-s cm-sourdine' }, 'Aucun monstre') : null,
      infobulle(h('span', { class: 'ui-s cm-sourdine cm-difficulte__qui', tabindex: '0' }, qui), detailGroupe, { titre: 'Le groupe' }),
      aide ? bouton('', { icone: 'lu-circle-help', titre: 'Les règles de Flee, Mortals! : budget, plafond, sbires, solo, rôles', classe: 'bn-btn--s bn-btn--fantome', onclick: ev2 => ouvrirAide(ev, ev2.currentTarget) }) : null),
    jauge,
    h('p', { class: 'ui-s cm-sourdine cm-difficulte__chiffres' }, chiffres),
    reglage,
    ev.alertes.length ? h('ul', { class: 'cm-difficulte__alertes' }, ev.alertes.map(a => h('li', { 'data-ton': a.ton }, icone(a.ton === 'sang' ? 'lu-triangle-alert' : 'lu-info', 'bn-icone--s'), a.texte))) : null);
}

// Une jauge en zones nommées ([{ niveau, debut, fin }], dans l'ordre), la zone de la rencontre allumée, le curseur sur valeur
// avec son libellé au-dessus ; titre(zone) : son détail au survol. Toutes les zones ont la même largeur (demande du MJ,
// 2026-10-23 : l'échelle change à chaque zone, vaguement exponentielle) ; le curseur avance en proportion dans la sienne.
function jaugeZones(zones, valeur, niveau, libelle, titre) {
  const n = zones.length;
  const pos = x => {
    const trouvee = zones.findIndex(z => x < z.fin);
    const k = trouvee < 0 ? n - 1 : trouvee;
    const z = zones[k];
    const part = Math.min(1, Math.max(0, (x - z.debut) / (z.fin - z.debut || 1)));
    return ((k + part) / n) * 100;
  };
  return h('div', { class: 'cm-difficulte__jauge', role: 'img', 'aria-label': `${libelle} : rencontre ${DIFFICULTES[niveau]?.nom.toLowerCase() || 'vide'}` },
    // Le seuil de chaque zone dans l'infobulle du gestionnaire, de la couleur de la zone (noire pour TPK).
    zones.map(z => infobulle(h('span', { class: 'cm-difficulte__zone', 'data-niveau': z.niveau, 'aria-current': z.niveau === niveau ? 'true' : null,
      style: `width: ${100 / n}%` }, z.niveau === 'tpk' ? icone('crane', 'bn-icone--s') : null, DIFFICULTES[z.niveau].nom),
    titre(z).replace(/^[^:]+ : /, ''), { titre: DIFFICULTES[z.niveau].nom, ton: z.niveau === 'tpk' ? 'abysse' : undefined })),
    h('span', { class: 'cm-difficulte__curseur', style: `left: ${pos(valeur)}%` }, h('span', {}, libelle)));
}

// « 4 héros niveau 2 + Le Loup gris niveau 1 » (niveaux différents : chacun avec le sien) ; niveauCompagnons faux : sans le
// niveau des compagnons (aide des règles).
function libelleGroupe(g, { niveauCompagnons = true } = {}) {
  const heros = g.membres.filter(m => !m.compagnon), comp = g.membres.filter(m => m.compagnon);
  const niveaux = [...new Set(heros.map(m => m.niveau))];
  const lesHeros = niveaux.length === 1 ? `${heros.length} héros niveau ${niveaux[0]}` : `${heros.length} héros (${heros.map(m => `${m.nom} ${m.niveau}`).join(', ')})`;
  return [lesHeros, ...comp.map(m => (niveauCompagnons ? `${m.nom} niveau ${m.niveau}` : m.nom))].join(' + ');
}

// Le budget standard du groupe, en une ligne (demande du MJ, 2026-10-23 : l'infobulle listait chacun) : « 4 × 1/4 (héros
// niveau 2) + 1/8 (Le Loup gris, niveau 1) = 1 + 1/8 FP en standard » ; héros de niveaux différents : un terme chacun.
function calculStandard(g) {
  const std = niveau => nombreFP(ligneTable(niveau)[1]);
  const heros = g.membres.filter(m => !m.compagnon), comp = g.membres.filter(m => m.compagnon);
  const niveaux = [...new Set(heros.map(m => m.niveau))];
  const termes = [
    ...(niveaux.length === 1 ? [`${heros.length} × ${std(niveaux[0])} (héros niveau ${niveaux[0]})`] : heros.map(m => `${std(m.niveau)} (${m.nom} ${m.niveau})`)),
    ...comp.map(m => `${std(m.niveau)} (${m.nom}, niveau ${m.niveau})`),
  ];
  const total = g.membres.reduce((a, m) => a + ligneTable(m.niveau)[1], 0);
  return `${termes.join(' + ')} = ${nombreFP(total)} FP en standard.${comp.length ? ' Les compagnons ne comptent pas pour le plafond.' : ''}`;
}

// Option de campagne « Rôles des monstres » (demande du MJ, 2026-10-23 : utile seulement avec les monstres de Flee,
// Mortals! ou des homebrews qui ont ces sous-types). app/rencontres-mj.js donne la fonction qui la lit.
let lireRoles = () => true;
export function reglerRoles(fn) { lireRoles = fn; }
export const rolesActifs = () => lireRoles();

// Le choix du rôle d'un groupe : une petite liste, le conseil du rôle au survol, et l'aide des rôles en fenêtre.
export function choixRole(role, surChoix) {
  const sel = h('select', { class: 'bn-select cm-role', 'aria-label': 'Rôle (Flee, Mortals!)', title: role ? `${ROLES[role].nom} : ${ROLES[role].conseil}` : 'Rôle de la créature (Flee, Mortals!) : sbire et solo changent le calcul de la difficulté',
    onchange: e => { e.target.blur(); surChoix(e.target.value || null); } },
  h('option', { value: '' }, 'Rôle ?'),
  Object.entries(ROLES).map(([id, r]) => h('option', { value: id }, r.nom)));
  sel.value = role || '';
  return h('span', { class: 'cm-role-choix' }, sel,
    bouton('', { icone: 'lu-circle-help', classe: 'bn-btn--s bn-btn--fantome cm-role-aide', titre: 'Les rôles des monstres (Flee, Mortals!)', onclick: e => ouvrirAideRoles(e.currentTarget) }));
}

// Les rôles en liste : nom, nom anglais, conseil de jeu.
const listeRoles = () => h('ul', { class: 'ui cm-liste' }, Object.values(ROLES).map(r => h('li', {}, h('b', {}, r.nom), h('span', { class: 'cm-sourdine' }, ` (${r.en})`), ` : ${r.conseil}`)));

// Le récapitulatif des rôles, depuis le « ? » à côté du choix d'un rôle.
export function ouvrirAideRoles(depuis = null) {
  flottant('aide-roles', { surtitre: 'Flee, Mortals!', titre: 'Les rôles des monstres', largeur: 480, depuis, contenu: h('div', { class: 'cm-pile' },
    p(h('b', {}, 'Sbire'), ' et ', h('b', {}, 'solo'), ' changent le calcul de la difficulté (sbires comptés par paquets, solo comparé au plafond) ; les autres rôles servent aux conseils (varier les rôles, un seul meneur ou soutien).'),
    listeRoles(),
    h('p', { class: 'ui-s cm-sourdine' }, 'Lu sur D&D Beyond à l\'ajout d\'un monstre : son sous-type (Solo, Minion, Brute…, comme les monstres de Flee, Mortals!, ou ceux cochés sur un homebrew), sinon ses traits « Minion » et « Villain Actions ». Modifiable dans la préparation ; « Relire D&D Beyond » pose celui d\'un monstre qui n\'en a pas.')) });
}

// ───── Fenêtre d'aide : les règles de Flee, Mortals! ─────

const p = (...x) => h('p', { class: 'ui' }, ...x);
const titre = t => h('p', { class: 'etiquette cm-section__titre' }, t);

function contenuAide(ev) {
  const moyen = ev?.groupe?.moyen ?? null;
  const tableau = h('table', { class: 'bn-table cm-difficulte__table' },
    h('thead', {}, h('tr', {}, ['Niveau', 'Facile', 'Standard', 'Difficile', 'Extrême*', 'TPK*', 'Plafond FP'].map(t => h('th', { class: t === 'Niveau' ? null : 'num' }, t)))),
    h('tbody', {}, Object.entries(TABLE).map(([niv, [f, s, d, c]]) => h('tr', { 'aria-current': Number(niv) === moyen ? 'true' : null },
      h('th', {}, `${niv}`), [f, s, d, d + auDela(Number(niv))[0], d + auDela(Number(niv))[1]].map(x => h('td', { class: 'num' }, nombreFP(x))), h('td', { class: 'num' }, c)))));
  const contenu = h('div', { class: 'cm-pile cm-difficulte__aide' },
    ev?.groupe ? p(h('b', {}, `Votre groupe : ${libelleGroupe(ev.groupe, { niveauCompagnons: false })}`), ` ; plafond de FP : niveau ${moyen} (ligne en rouge).`) : null,
    ev?.groupe?.membres.some(m => m.compagnon) ? h('p', { class: 'ui-s cm-sourdine' }, 'Note : les compagnons ne comptent pas pour le plafond de FP (attention tout de même aux rencontres difficiles et extrêmes, particulièrement dangereuses pour les compagnons).') : null,
    titre('La journée d\'aventure'),
    p(`Entre deux repos longs, si vous souhaitez que les héros s'épuisent mais survivent, imaginez disposer d'un budget de ${JOURNEE.min} à ${JOURNEE.max} points (attention : ces points ne sont pas à confondre avec le FP). Vous pouvez aller jusqu'à ${JOURNEE.rude} points pour une journée qui ne garantit plus leur survie. Dépensez ces points de la manière suivante :`),
    h('ul', { class: 'ui cm-liste' }, Object.values(DIFFICULTES).map(d => h('li', {}, h('b', {}, d.nom), ` : ${d.points} point${d.points > 1 ? 's' : ''}. `,
      { triviale: 'Aucun effort, aucune ressource dépensée.', facile: 'Sans danger tant que les héros ont des ressources.', standard: 'La plus courante : coûte des ressources et des PV, une mort reste possible.', difficile: 'Le combat de boss : il faut toutes les ressources, la tête et de la chance.', extreme: 'Les héros n\'y survivent sans doute pas s\'ils se battent jusqu\'au bout.', tpk: 'Au-delà d\'extrême, la mort assurée du groupe. Pas une règle de Flee, Mortals! : seuil fixé par le MJ (table ci-dessous).' }[Object.keys(DIFFICULTES).find(k => DIFFICULTES[k] === d)]))),
    titre('Le budget de FP par rencontre'),
    p('Pour chaque personnage, la table donne le FP par personnage de la difficulté voulue, à son niveau. Un compagnon augmente le budget de FP, et compte comme un personnage de 2 niveaux de moins que son maître (1 au moins). On les additionne (exemple : 4 héros de niveau 4 et un compagnon de niveau 2, en standard : 4 × 3/4 + 1/4).'),
    tableau,
    h('p', { class: 'ui-s cm-sourdine' }, '* Extrême et TPK : seuils fixés par le MJ, pas des règles de Flee, Mortals! : jusqu\'au niveau 4, 1,5 fois et 2 fois le FP difficile par personnage ; à partir du niveau 5, le FP difficile plus 1 FP et plus 2 FP par personnage.'),
    // Le récapitulatif pour le groupe : les budgets et le plafond.
    ev?.budgets ? p(h('b', {}, 'Pour votre groupe, par rencontre'), ` : facile ${nombreFP(ev.budgets.facile)}, standard ${nombreFP(ev.budgets.standard)}, difficile ${nombreFP(ev.budgets.difficile)}, extrême ${nombreFP(ev.budgets.extreme)}, TPK ${nombreFP(ev.budgets.tpk)} (FP à dépenser) ; plafond de FP ${ev.plafond}.`) : null,
    titre('Dépenser le budget'),
    h('ul', { class: 'ui cm-liste' },
      h('li', {}, 'Additionner les FP des créatures, au plus près du budget.'),
      h('li', {}, 'Chaque difficulté commence à son budget, arrondi au demi-FP le plus proche à partir de 1 FP (difficile 2 + 1/4 : dès 2), et va jusqu\'au début de la suivante. En dessous du budget facile, la rencontre est triviale.'),
      h('li', {}, 'Aucune créature au-dessus du plafond de FP du niveau, même si le budget le permet.'),
      h('li', {}, 'Au plus trois créatures (hors sbires) par personnage.'),
      rolesActifs() ? h('li', {}, 'Varier les rôles : un contrôleur, un tirailleur et deux soldats valent mieux que quatre soldats.') : null),
    titre('Les sbires'),
    h('ul', { class: 'ui cm-liste' },
      h('li', {}, 'Pour le budget, 5 sbires (FP 4 ou moins), 8 (FP 5 à 8) ou 10 (FP 9 et plus) valent une créature standard de leur FP.'),
      h('li', {}, 'Jusqu\'au niveau 10, vous pouvez ajouter 10 à 20 sbires en plus des autres créatures ; au-delà, 20 à 30. Au moins de quoi faire une créature standard.'),
      h('li', {}, 'Leurs règles en combat : fenêtre « Sbires » du widget Combat.')),
    titre('Les créatures solo'),
    p('Pas de budget : on compare le FP du solo au plafond du niveau. Pour 4 ou 5 personnages : plafond moins 0 à 2, difficile ; moins 3 ou 4, standard ; moins 5 ou 6, facile ; moins 7 ou plus, triviale. Pour 6 ou 7 personnages : moins 0 à 1, 2 à 3, 4 à 5, 6 et plus. Un solo de FP 4 ou moins peut affronter un groupe d\'un niveau plus bas (deux pour 6 ou 7 personnages). Un solo s\'affronte seul, dans un lieu où il peut bouger et se mettre à couvert.'),
    titre('Les rôles'),
    // Sans l'option « Rôles des monstres » : pas de liste, ce que l'option changerait (demande du MJ, 2026-10-23).
    rolesActifs() ? listeRoles()
      : p('L\'option « Rôles des monstres » n\'est pas activée (fenêtre Campagne, onglet Rencontres) : les créatures n\'ont pas de rôle et comptent toutes comme des créatures standard ; sbires et créatures solo ne sont pas reconnus. À activer avec les monstres de Flee, Mortals!, ou des homebrews qui portent ces rôles.'),
    h('p', { class: 'ui-s cm-sourdine' }, 'Résumé des règles de construction des rencontres de Flee, Mortals! (MCDM), introduction du livre.'));
  return contenu;
}
export function ouvrirAide(ev = null, depuis = null) {
  flottant('aide-flee-mortals', { surtitre: 'Flee, Mortals!', titre: 'Construire une rencontre', largeur: 560, contenu: contenuAide(ev), depuis });
}
// Fenêtre d'aide ouverte : la redessiner pour le groupe du moment (case « Compter les compagnons » changée, héros absents).
export function majAide(ev) {
  flottantOuvert('aide-flee-mortals')?.maj(contenuAide(ev));
}

// Les règles des sbires en combat, pour la table.
export function ouvrirAideSbires(depuis = null) {
  flottant('aide-sbires', { surtitre: 'Flee, Mortals!', titre: 'Les sbires en combat', largeur: 480, depuis, contenu: h('div', { class: 'cm-pile' },
    h('ul', { class: 'ui cm-liste' },
      h('li', {}, h('b', {}, 'Trait Sbire'), ' : touché par une attaque, ou raté un jet de sauvegarde, et le moindre dégât le fait tomber à 0 PV. Les autres dégâts ne le tuent que s\'ils atteignent ses PV maximum ; sinon, rien.'),
      h('li', {}, h('b', {}, 'Pas de dés de dégâts'), ' : dégâts fixes, jamais de coup critique.'),
      h('li', {}, h('b', {}, 'Tour partagé'), ' : les sbires d\'un même profil jouent ensemble, chacun se déplace puis agit.'),
      h('li', {}, h('b', {}, 'Excès de dégâts'), ' : une attaque d\'arme qui dépasse les PV maximum du sbire reporte l\'excès sur un autre sbire du même profil à portée (au contact : dans l\'allonge ; à distance : sur la ligne, jusqu\'à la portée courte). Un sbire de plus pour chaque fois que l\'excès dépasse leurs PV maximum. Jamais sur une attaque d\'opportunité.'),
      h('li', {}, h('b', {}, 'Attaque de groupe'), ' : 2 à 5 sbires du même profil qui partagent le tour font un seul jet, +1 par sbire ; s\'il touche, dégâts × nombre de sbires. Avantage ou désavantage seulement si tous l\'ont ; couvert inégal : plusieurs groupes. Une réaction de la cible (bouclier de feu…) touche un seul d\'entre eux, au choix de la cible.'),
      h('li', {}, h('b', {}, 'Attaque d\'opportunité de groupe'), ' : plusieurs sbires déclenchés en même temps peuvent la faire ensemble, chacun avec sa réaction.'),
      h('li', {}, h('b', {}, 'Jets de sauvegarde (option)'), ' : un jet pour un groupe de 5 sbires au plus, face au même effet.')),
    h('p', { class: 'ui-s cm-sourdine' }, 'Dites aux joueurs comment fonctionnent les sbires avant le combat : ils joueront mieux, et plus vite.')) });
}
