// Ce qui reste à faire quand on termine ou qu'on quitte quelque chose (demande du MJ, 2026-11-01) : jalons et trajets pas
// terminés, rencontres pas jouées, pistes pas commencées, résurgences pas jouées (2026-11-05 : celles que les pistes devaient
// faire reparaître dans l'étape ou au jalon), PNJ pas rencontrés, objets pas donnés.
// - restes(quoi) : le calcul. quoi : { jalon: id }, { etape: id }, { piste: id }, { lieu, sous_lieu? } ou { itineraire }.
// - demander(quoi, …) : avant de terminer, une fenêtre (non modale : le MJ règle ce qu'il veut, chaque ligne ouvre son élément)
//   qui demande confirmation ; rien ne reste : vrai tout de suite.
// - symbole(quoi, …) et consulter(quoi, …) : le symbole d'alerte d'un élément terminé, et sa fenêtre, où le MJ peut confirmer
//   que tout est bon (`valide` du suivi, app/trame.js) : le symbole devient moindre, en jaune, « Validé par le MJ ».
// - surveillerDeparts(ctx) : une annonce quand les héros quittent un lieu, et la fenêtre de la fin d'un trajet.
// Deux niveaux : « à régler » (compte pour le symbole) et « secondaire », replié : jalon ou piste facultatifs, PNJ mineurs,
// rencontres et objets qui ne tiennent qu'à un lieu.
// Partagé par le Déroulé (terminer, symboles), la fin de session (export complet) et le tableau de bord (départs).

import { h, icone, bouton, section, flottant, flottantOuvert, infobulle } from './ui.js';
import { chargerLieux, nomLieu, etatIci } from './lieux.js';
import { etatPnj, suiviDe, rangDe, etatEffectif, boutonVu, chargerFactions, ouvrirFichePnj } from './fiche-pnj.js';
import { outilsRencontresMj } from './rencontres-mj.js';
import { outilsObjets } from './objets.js';
import { outilsQuetes } from './quetes.js';
import { ICONES_JALON, ICONE_PISTE, etatDeroule, statutDe, commencer, estValide, valider, devalider, derouleSurLeTableau, voirJalon, voirPiste, resurgenceJouee, jouerResurgence, etapeDeResurgence, remarqueResurgence, saisirRemarqueResurgence, crayonResurgence, rangeurEtapes, elementPnj, elementRencontre, elementObjet } from './trame.js';
import { annoncer, etatHorloge } from './horloge.js';

const ABSENTS = ['mort', 'disparu', 'absent'];
const pluriel = (n, un, plusieurs = un + 's') => `${n} ${n > 1 ? plusieurs : un}`;
const LIB_GENRE = { jalon: 'jalon', etape: 'étape', piste: 'piste' };

// liens : { jalon(j), piste(p) } pour ouvrir un élément du déroulé (le widget Déroulé les passe) ; à défaut, on le demande au
// Déroulé s'il est sur le tableau.
export async function outilsRestes({ donnees, etat, dialogue, R: R0 = null, O: O0 = null, liens = null }) {
  const R = R0 || await outilsRencontresMj({ donnees, etat, dialogue });
  const O = O0 || await outilsObjets({ donnees, etat, dialogue });
  const d = (await donnees('deroule-campagne')).donnees;
  const lieux = await chargerLieux(donnees);
  const donneesPnj = (await donnees('pnj')).donnees;
  const pnj = new Map((donneesPnj?.pnj || []).map(p => [p.id, p]));
  const factions = await chargerFactions(donnees);
  const sPnj = pnj.size ? await etatPnj(etat) : null;
  const s = await etatDeroule(etat, donnees);
  const jalons = d?.jalons || [], pistes = d?.pistes || [];
  const jalonParId = new Map(jalons.map(j => [j.id, j]));
  const etapeParId = new Map((d?.etapes || []).map(e => [e.id, e]));
  const pisteParId = new Map(pistes.map(p => [p.id, p]));
  const statut = (genre, id) => statutDe(s.valeur, genre, id);
  // Plusieurs étapes au même lieu : chacune ne répond que de ce qui est de ses pièces (rangeurEtapes de app/trame.js).
  const rangeur = rangeurEtapes(d);

  const pasJouee = v => v && v.statut !== 'terminee';
  const unique = liste => [...new Map(liste.filter(Boolean).map(x => [x.id, x])).values()];
  const nonRencontres = ids => [...new Set(ids)].map(id => pnj.get(id))
    .filter(p => p && sPnj && !suiviDe(sPnj, p.id).rencontre && !ABSENTS.includes(etatEffectif(p, suiviDe(sPnj, p.id))));
  const pnjDuLieu = (lieu, sous = null) => [...pnj.values()].filter(p => p.lieu === lieu && (!sous || p.sous_lieu === sous)).map(p => p.id);
  // Les jalons et pistes d'une quête pas encore prise ne comptent pas (app/quetes.js : ils ne sont pas dans le Déroulé).
  const Q = await outilsQuetes({ donnees, etat, dialogue });
  const lesJalons = liste => liste.filter(j => statut('jalon', j.id) !== 'termine' && !Q.cacheDansDeroule('jalon', j.id));
  const lesPistes = liste => liste.filter(p => statut('piste', p.id) === 'a-venir' && !Q.cacheDansDeroule('piste', p.id));
  // Les résurgences des pistes pas terminées qui remplissent `garde(m)` et n'ont pas été jouées : [{ p, m }].
  const lesResurgences = garde => pistes.filter(p => statut('piste', p.id) !== 'termine' && !Q.cacheDansDeroule('piste', p.id))
    .flatMap(p => (p.manifestations || []).filter(m => garde(m) && !resurgenceJouee(s.valeur, p.id, m)).map(m => ({ p, m })));

  // → { jalons, trajets, rencontres, pistes, resurgences, pnj, objets, jalonsFacultatifs, pistesFacultatives, pnjMineurs, surPlace, objetsSurPlace }
  function restes(quoi) {
    let js = [], ps = [], rs = [], rsPlace = [], ids = [], os = [], osPlace = [], ms = [];
    if (quoi.jalon) {
      const j = jalonParId.get(quoi.jalon);
      if (j) {
        rs = R.duJalon(j);
        ids = j.pnj || [];
        ps = pistes.filter(p => p.debut?.jalon === j.id);
        ms = lesResurgences(m => m.jalon === j.id);
        os = O.enAttente({ jalons: [j.id] }).liste;
      }
    } else if (quoi.etape) {
      const e = etapeParId.get(quoi.etape);
      if (e) {
        const siens = jalons.filter(j => j.etape === e.id);
        js = siens;
        rs = [...siens.flatMap(j => R.duJalon(j)), ...R.deLEtape(e)];
        rsPlace = (e.lieux || []).flatMap(l => R.duLieu(l)).filter(v => v && rangeur.estDe(elementRencontre(v), e.id));
        ids = [...(e.lieux || []).flatMap(l => pnjDuLieu(l)).filter(id => rangeur.estDe(elementPnj(pnj.get(id)), e.id)), ...siens.flatMap(j => j.pnj || [])];
        ps = [...pistes.filter(p => p.etape === e.id), ...(e.pistes_attendues || []).map(pa => pisteParId.get(pa.piste))].filter(Boolean);
        ms = lesResurgences(m => etapeDeResurgence(m, jalonParId) === e.id);
        const a = O.enAttente({ etapes: [e.id] });
        os = a.liste;
        osPlace = a.surPlace.filter(o => rangeur.estDe(elementObjet(o, pnj), e.id));
      }
    } else if (quoi.piste) {
      const p = pisteParId.get(quoi.piste);
      if (p) {
        js = p.fin?.jalon && jalonParId.has(p.fin.jalon) ? [jalonParId.get(p.fin.jalon)] : [];
        rs = (p.rencontres || []).map(id => R.vueDe(id));
        ids = p.pnj || [];
      }
    } else if (quoi.lieu) {
      rsPlace = R.duLieu(quoi.lieu, quoi.sous_lieu || null);
      ids = pnjDuLieu(quoi.lieu, quoi.sous_lieu || null);
      osPlace = O.duLieu(quoi.lieu, quoi.sous_lieu || null).filter(o => o.statut !== 'donne');
      return ranger({ rs: rsPlace, ids, os: osPlace });   // quand on quitte un lieu : tout est à régler, rien de secondaire
    } else if (quoi.itineraire) {
      rs = R.duTrajet(quoi.itineraire, -1).map(x => x.vue);
      const fin = quoi.itineraire.at(-1);
      js = jalons.filter(j => j.type === 'trajet' && j.vers === fin && statut('jalon', j.id) === 'en-cours');
    }
    return ranger({ js, ps, rs, rsPlace, ids, os, osPlace, ms });
  }
  function ranger({ js = [], ps = [], rs = [], rsPlace = [], ids = [], os = [], osPlace = [], ms = [] }) {
    const jalonsLa = lesJalons(unique(js)), pistesLa = lesPistes(unique(ps));
    const rencontres = unique(rs).filter(pasJouee);
    const dejaLa = new Set(rencontres.map(v => v.id));
    const gens = nonRencontres(ids);
    const estMineur = p => rangDe(p, suiviDe(sPnj, p.id)) === 'mineur';
    const fait = jalonsLa.filter(j => !j.facultatif);
    return {
      jalons: fait.filter(j => j.type !== 'trajet'),
      trajets: fait.filter(j => j.type === 'trajet'),
      rencontres,
      pistes: pistesLa.filter(p => !p.facultatif),
      // Celles d'une piste facultative jamais commencée ne comptent pas : la piste elle-même est secondaire.
      resurgences: ms.filter(x => !(x.p.facultatif && statut('piste', x.p.id) === 'a-venir')),
      pnj: gens.filter(p => !estMineur(p)),
      objets: os,
      jalonsFacultatifs: jalonsLa.filter(j => j.facultatif),
      pistesFacultatives: pistesLa.filter(p => p.facultatif),
      pnjMineurs: gens.filter(estMineur),
      surPlace: unique(rsPlace).filter(v => pasJouee(v) && !dejaLa.has(v.id)),
      objetsSurPlace: osPlace,
    };
  }
  const aRegler = r => r.jalons.length + r.trajets.length + r.rencontres.length + r.pistes.length + r.resurgences.length + r.pnj.length + r.objets.length;
  const secondaires = r => r.jalonsFacultatifs.length + r.pistesFacultatives.length + r.pnjMineurs.length + r.surPlace.length + r.objetsSurPlace.length;
  // « 2 jalons, 1 rencontre, 3 PNJ » : ce qui reste à régler.
  function resume(r) {
    return [
      r.jalons.length ? pluriel(r.jalons.length, 'jalon') : null,
      r.trajets.length ? pluriel(r.trajets.length, 'trajet') : null,
      r.rencontres.length ? pluriel(r.rencontres.length, 'rencontre') : null,
      r.pistes.length ? pluriel(r.pistes.length, 'piste') : null,
      r.resurgences.length ? pluriel(r.resurgences.length, 'résurgence') : null,
      r.pnj.length ? pluriel(r.pnj.length, 'PNJ', 'PNJ') : null,
      r.objets.length ? pluriel(r.objets.length, 'objet') : null,
    ].filter(Boolean).join(', ');
  }

  // ───── Vue ─────

  const ouvrirJalon = j => { if (liens) liens.jalon(j); else if (derouleSurLeTableau()) voirJalon(j.id); else annoncerDeroule(); };
  const ouvrirPiste = p => { if (liens) liens.piste(p); else if (derouleSurLeTableau()) voirPiste(p.id); else annoncerDeroule(); };
  const annoncerDeroule = () => annoncer({ cle: 'deroule-absent', titre: 'Widget Déroulé absent', icone: 'sablier', couleur: 'brume', texte: 'Ajoutez le widget Déroulé au tableau pour ouvrir cet élément.' });
  const ligneJalon = j => h('li', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirJalon(j) },
    icone(ICONES_JALON[j.type] || 'lu-info', 'bn-icone--s'), ` ${j.nom}`),
  statut('jalon', j.id) === 'en-cours' ? h('span', { class: 'ui-s cm-sourdine' }, ' · en cours') : null);
  const lignePiste = p => h('li', {},
    h('span', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPiste(p) }, icone(ICONE_PISTE, 'bn-icone--s'), ` ${p.nom}`)),
    bouton('Commencer', { classe: 'bn-btn--s', icone: 'lu-play', onclick: () => { commencer(s.valeur, 'piste', p.id); s.enregistrer(0); s.signaler(); } }));
  // Une résurgence pas jouée : sa piste (un clic l'ouvre), son texte, et « Jouée », qui commence la piste au besoin.
  const ligneResurgence = ({ p, m }) => h('li', {},
    h('span', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirPiste(p) }, icone(ICONE_PISTE, 'bn-icone--s'), ` ${p.nom}`),
      h('span', { class: 'ui-s' }, ` : ${m.texte}`), statut('piste', p.id) === 'a-venir' ? h('span', { class: 'ui-s cm-sourdine' }, ' · piste pas commencée') : null,
      remarqueResurgence(s.valeur, p.id, m) ? h('span', { class: 'cm-res-remarque' }, icone('livre', 'bn-icone--s'), ' ', remarqueResurgence(s.valeur, p.id, m).texte) : null),
    // Sa remarque : pourquoi elle n'a pas été jouée, par exemple (elle reste listée ; « Tout est bon : valider » lève l'alerte).
    crayonResurgence(s.valeur, p, m, () => saisirRemarqueResurgence(dialogue, s.valeur, p, m, () => { s.enregistrer(0); s.signaler(); })),
    bouton('Jouée', { classe: 'bn-btn--s', icone: 'lu-check', titre: 'Cette résurgence a été jouée' + (statut('piste', p.id) === 'a-venir' ? ' : la piste est commencée du même coup' : ''), onclick: () => {
      jouerResurgence(s.valeur, p.id, m);
      if (statut('piste', p.id) === 'a-venir') commencer(s.valeur, 'piste', p.id);
      s.enregistrer(0); s.signaler();
    } }));
  const lignePnj = p => h('li', {},
    h('span', {}, h('button', { type: 'button', class: 'bn-lien cm-lien-bouton', onclick: () => ouvrirFichePnj(p, { lieux, s: sPnj, factions, typesRang: donneesPnj?.types_rang }) }, p.nom),
      p.role ? h('span', { class: 'ui-s cm-sourdine' }, ` · ${p.role}`) : null),
    boutonVu(p, sPnj, () => sPnj.signaler()));
  const listeRencontres = vues => h('div', { class: 'cm-rmj-liste' }, vues.map(x => R.ligne(x, { voirDeroule: false, compacte: true })));
  const listeEl = (lignes, fn) => h('ul', { class: 'cm-restes__liste' }, lignes.map(fn));

  function vueRestes(r) {
    const n = aRegler(r), m = secondaires(r);
    if (!n && !m) return h('p', { class: 'ui' }, icone('lu-check', 'bn-icone--s'), ' Tout est fait.');
    return h('div', { class: 'cm-pile' },
      n ? h('div', { class: 'cm-restes' },
        r.jalons.length ? section(`Jalons pas terminés (${r.jalons.length})`, 'lu-list', listeEl(r.jalons, ligneJalon)) : null,
        r.trajets.length ? section(`Trajets pas terminés (${r.trajets.length})`, 'lu-route', listeEl(r.trajets, ligneJalon)) : null,
        r.rencontres.length ? section(`Rencontres pas jouées (${r.rencontres.length})`, 'lu-swords', listeRencontres(r.rencontres)) : null,
        r.pistes.length ? section(`Pistes pas commencées (${r.pistes.length})`, ICONE_PISTE, listeEl(r.pistes, lignePiste)) : null,
        r.resurgences.length ? section(`Résurgences pas jouées (${r.resurgences.length})`, ICONE_PISTE, listeEl(r.resurgences, ligneResurgence)) : null,
        r.pnj.length ? section(`PNJ pas rencontrés (${r.pnj.length})`, 'crocs', listeEl(r.pnj, lignePnj)) : null,
        r.objets.length ? section(`Objets pas donnés (${r.objets.length})`, 'amulette', O.liste(r.objets)) : null)
        : h('p', { class: 'ui' }, icone('lu-check', 'bn-icone--s'), ' L\'essentiel est fait.'),
      m ? h('details', { class: 'cm-repli' }, h('summary', { class: 'etiquette' }, `Secondaire (${m}) : facultatif, PNJ mineurs, sur place`),
        h('div', { class: 'cm-restes' },
          r.jalonsFacultatifs.length ? section(`Jalons facultatifs (${r.jalonsFacultatifs.length})`, 'lu-list', listeEl(r.jalonsFacultatifs, ligneJalon)) : null,
          r.surPlace.length ? section(`Rencontres sur place (${r.surPlace.length})`, 'lu-swords', listeRencontres(r.surPlace)) : null,
          r.pistesFacultatives.length ? section(`Pistes facultatives (${r.pistesFacultatives.length})`, ICONE_PISTE, listeEl(r.pistesFacultatives, lignePiste)) : null,
          r.pnjMineurs.length ? section(`PNJ mineurs (${r.pnjMineurs.length})`, 'crocs', listeEl(r.pnjMineurs, lignePnj)) : null,
          r.objetsSurPlace.length ? section(`Objets sur place (${r.objetsSurPlace.length})`, 'amulette', O.liste(r.objetsSurPlace)) : null)) : null);
  }

  // Une fenêtre par clé. pied(r) : ses boutons. Elle suit le suivi, les rencontres, les PNJ et les objets : ce qu'on règle disparaît.
  const annulations = new Map();
  function fenetre(cle, quoi, { surtitre, titre, pied = null, surFermeture = null, intro = null }) {
    annulations.get(cle)?.();
    const zone = h('div', { class: 'cm-pile' });
    const maj = () => {
      const r = restes(quoi);
      zone.replaceChildren(...[intro, vueRestes(r), pied?.(r)].filter(Boolean));
    };
    const quitter = [s, R.s, O.s, sPnj].filter(Boolean).map(x => x.abonner(maj));
    const finir = () => { annulations.delete(cle); quitter.forEach(q => q()); };
    annulations.set(cle, finir);
    maj();
    flottant(cle, { surtitre, titre, largeur: 860, pictogramme: 'lu-triangle-alert', contenu: zone, surFermeture: () => { finir(); surFermeture?.(); } });
  }

  // Avant de terminer. → faux (annulé), vrai (terminer), ou 'valide' (terminer, et tout est bon : pas d'alerte ensuite).
  function demander(quoi, { genre, id, nom }) {
    const r0 = restes(quoi);
    if (!aRegler(r0) && !secondaires(r0)) return Promise.resolve(true);
    const cle = `restes:${genre}:${id}`;
    flottantOuvert(cle)?.fermer();   // une demande précédente : annulée
    return new Promise(fin => {
      let reponse = false;
      const sortir = val => { reponse = val; flottantOuvert(cle)?.fermer(); };
      fenetre(cle, quoi, {
        surtitre: `Avant de terminer · ${LIB_GENRE[genre] || genre}`, titre: nom, surFermeture: () => fin(reponse),
        intro: h('p', { class: 'ui-s cm-sourdine' }, 'Un clic sur un élément l\'ouvre, pour le régler : la liste suit.'),
        pied: () => h('div', { class: 'bn-groupe cm-restes__pied' },
          bouton('Terminer, tout est bon', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check', titre: 'Terminé, et ce qui reste ne compte pas : « Validé par le MJ »', onclick: () => sortir('valide') }),
          bouton('Terminer, à revoir', { classe: 'bn-btn--s', icone: 'lu-triangle-alert', titre: 'Terminé, avec une alerte sur sa ligne tant qu\'il reste quelque chose', onclick: () => sortir(true) }),
          bouton('Annuler', { classe: 'bn-btn--s bn-btn--fantome', titre: 'Rien n\'est terminé', onclick: () => sortir(false) })),
      });
    });
  }

  // La fenêtre d'un élément terminé : ce qui reste, et la validation du MJ.
  function consulter(quoi, { genre, id, nom }) {
    fenetre(`restes:${genre}:${id}`, quoi, {
      surtitre: `Terminé, à vérifier · ${LIB_GENRE[genre] || genre}`, titre: nom,
      pied: () => {
        const ok = estValide(s.valeur, genre, id);
        const changer = fn => () => { fn(s.valeur, genre, id); s.enregistrer(0); s.signaler(); };
        return h('div', { class: 'bn-groupe cm-restes__pied' },
          ok ? h('span', { class: 'ui cm-restes__valide' }, icone('lu-triangle-alert', 'bn-icone--s'), ' Validé par le MJ') : null,
          ok ? bouton('Retirer la validation', { classe: 'bn-btn--s bn-btn--fantome', icone: 'lu-x', onclick: changer(devalider) })
            : bouton('Tout est bon : valider', { classe: 'bn-btn--s bn-btn--primaire', icone: 'lu-check', titre: 'Ce qui reste ne compte pas : l\'alerte devient jaune', onclick: changer(valider) }));
      },
    });
  }

  // Le symbole d'un élément terminé auquel il reste quelque chose d'important : rouge, ou jaune et moindre une fois validé.
  // Rien sinon. Un clic ouvre sa fenêtre, sans ouvrir la ligne.
  function symbole(quoi, { genre, id, nom }) {
    if (statut(genre, id) !== 'termine') return null;
    const r = restes(quoi);
    if (!aRegler(r)) return null;
    const ok = estValide(s.valeur, genre, id);
    return infobulle(h('button', { type: 'button', class: 'cm-reste' + (ok ? ' cm-reste--valide' : ''), 'aria-label': ok ? 'Validé par le MJ' : 'Pas tout à fait terminé',
      onclick: ev => { ev.preventDefault(); ev.stopPropagation(); consulter(quoi, { genre, id, nom }); } }, icone('lu-triangle-alert', 'bn-icone--s')),
    `Reste : ${resume(r)}. Un clic : voir et régler.`, { titre: ok ? 'Validé par le MJ' : 'Pas tout à fait terminé', ton: ok ? 'soleil' : 'sang' });
  }

  return { restes, aRegler, secondaires, resume, demander, consulter, symbole, fenetre };
}

// ───── Quitter un lieu, finir un trajet ─────

// Quand les héros quittent un lieu (hors d'un trajet : les lieux traversés ne comptent pas) ou partent en trajet : une annonce
// s'il y reste quelque chose, puisqu'ils y reviennent parfois. À la fin d'un trajet : la fenêtre de ce qui reste de la route.
export async function surveillerDeparts({ donnees, etat, dialogue }) {
  const sIci = await etatIci(etat, donnees);
  const sH = await etatHorloge(etat);
  const lieux = await chargerLieux(donnees);
  let outils = null;
  const charger = async () => (outils ||= await outilsRestes({ donnees, etat, dialogue }));
  const enTrajet = () => (sH.valeur.activites || []).some(a => a.type === 'voyage');

  async function depart(lieu) {
    if (!lieu) return;
    const O = await charger();
    const quoi = { lieu };
    const r = O.restes(quoi);
    if (!O.aRegler(r)) return;
    const nom = nomLieu(lieux, lieu);
    annoncer({ cle: 'depart-lieu', titre: `En quittant ${nom}`, icone: 'lu-triangle-alert', couleur: 'cierge', texte: [
      `Reste ${O.resume(r)}. `,
      bouton('Voir', { classe: 'bn-btn--s', icone: 'lu-list', onclick: () => O.fenetre('restes:lieu:' + lieu, quoi, { surtitre: 'En quittant un lieu', titre: nom }) }),
    ] });
  }

  let lieu = sIci.valeur.lieu;
  sIci.abonner(() => {
    const avant = lieu;
    lieu = sIci.valeur.lieu;
    if (avant && avant !== lieu && !enTrajet()) depart(avant);
  });
  document.addEventListener('cm:depart-lieu', e => depart(e.detail?.lieu));
  document.addEventListener('cm:trajet-fini', async e => {
    const itineraire = e.detail?.itineraire;
    if (!itineraire?.length) return;
    const O = await charger();
    const quoi = { itineraire };
    if (O.aRegler(O.restes(quoi))) O.fenetre('restes:trajet', quoi, { surtitre: 'Trajet terminé', titre: `Trajet vers ${nomLieu(lieux, itineraire.at(-1))}` });
  });
}
