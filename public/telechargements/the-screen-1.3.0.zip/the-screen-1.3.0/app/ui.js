// Petits outils DOM partagés par le tableau de bord et les widgets.
// h('div', { class: 'x', onclick: fn }, enfant, 'texte', [autres]) : jamais d'innerHTML sur des données.

const SVG = 'http://www.w3.org/2000/svg';

export function h(tag, attrs, ...enfants) {
  const el = document.createElement(tag);
  for (const [cle, val] of Object.entries(attrs || {})) {
    if (val === null || val === undefined || val === false) continue;
    if (cle.startsWith('on') && typeof val === 'function') el.addEventListener(cle.slice(2), val);
    else if (cle === 'class') el.className = val;
    // Une variable CSS (« --quete-c ») ne passe que par setProperty : Object.assign l'ignorait en silence.
    else if (cle === 'style' && typeof val === 'object') for (const [p, x] of Object.entries(val)) { if (p.startsWith('--')) el.style.setProperty(p, x); else el.style[p] = x; }
    else if (cle in el && typeof val !== 'string') el[cle] = val;
    else el.setAttribute(cle, val === true ? '' : val);
  }
  ajouter(el, enfants);
  return el;
}

function ajouter(el, enfants) {
  for (const e of enfants.flat(Infinity)) {
    if (e === null || e === undefined || e === false) continue;
    el.append(e instanceof Node ? e : document.createTextNode(String(e)));
  }
}

// Icône du sprite : thématique (bn-<nom>, design-system/icons.js) ou Lucide (lu-<nom>, app/icones-ui.js).
export function icone(nom, classe = '') {
  const svg = document.createElementNS(SVG, 'svg');
  svg.setAttribute('class', ('bn-icone ' + classe).trim());
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(SVG, 'use');
  use.setAttribute('href', '#' + (nom.startsWith('lu-') ? nom : 'bn-' + nom));
  svg.append(use);
  return svg;
}

export function bouton(texte, { icone: ic, classe = '', titre, ...attrs } = {}) {
  const seulIcone = !texte;
  return h('button', {
    type: 'button',
    class: `bn-btn ${seulIcone ? 'bn-btn--icone' : ''} ${classe}`.replace(/\s+/g, ' ').trim(),
    'aria-label': seulIcone ? titre : null,
    title: titre || null,
    ...attrs,
  }, ic ? icone(ic) : null, texte ? h('span', {}, texte) : null);
}

export function badge(texte, couleur, ic) {
  return h('span', { class: 'bn-badge' + (couleur ? ' bn-badge--' + couleur : '') }, ic ? icone(ic) : null, texte);
}

// Unités accolées au nombre (« 30 ft », « DD 12 », « 16 miles ») : espace fine insécable, jamais de retour à la ligne entre les deux.
export const FINE = ' ';

// « d’Isolde », « de Bertrand ».
export const deNom = nom => (/^[aeiouyhàâéèêîôû]/i.test(nom) ? 'd’' : 'de ') + nom;

// Un jet à faire (composant DD) : dé et difficulté dans un petit cadre. dd : nombre ou texte (« 13/14 »).
// « DD » à part (.bn-dd__mot) : un cadre vertical (dé au-dessus du nombre) peut s'en passer.
export function pastilleDD(dd, titre) {
  return h('span', { class: 'bn-badge bn-dd', title: titre || null }, icone('d20'), h('span', { class: 'bn-dd__mot' }, `DD${FINE}`), String(dd));
}

// Alerte repliée sur une ligne (titre, repère à droite : un DD, « Fatigue +1 »…), le texte à l'ouverture.
export function alerteRepliable(couleur, ic, titre, repere, texte, { ouvert = false } = {}) {
  return h('details', { class: 'bn-alerte bn-alerte--repliable' + (couleur ? ' bn-alerte--' + couleur : ''), open: ouvert },
    h('summary', {}, icone(ic), h('p', { class: 'bn-alerte__titre' }, titre), repere || null, icone('lu-chevron-down', 'bn-icone--s bn-alerte__chevron')),
    h('div', { class: 'bn-alerte__texte' }, texte));
}

export function alerte(couleur, ic, titre, texte, ...extra) {
  return h('div', { class: 'bn-alerte' + (couleur ? ' bn-alerte--' + couleur : ''), role: couleur === 'sang' ? 'alert' : null },
    icone(ic), h('p', { class: 'bn-alerte__titre' }, titre), h('div', { class: 'bn-alerte__texte' }, texte, ...extra));
}

// Onglets accessibles. onglets : [{ id, libelle, court (libellé court, facultatif), icone, compte (nombre d'éléments,
// facultatif), rendu: () => Node }]
// Barre trop étroite : jamais de défilement. Elle se resserre (écarts), puis prend les libellés courts, puis perd les icônes.
const NIVEAUX_ONGLETS = ['est-serree', 'est-courte', 'sans-icones'];
export function onglets(etiquette, liste, actif, surChangement) {
  const barre = h('div', { class: 'bn-onglets', role: 'tablist', 'aria-label': etiquette });
  const zone = h('div', { class: 'cm-onglet-zone', role: 'tabpanel' });
  const boutons = liste.map(o => h('button', {
    class: 'bn-onglet', role: 'tab', type: 'button', 'aria-selected': 'false', title: o.court ? o.libelle : null,
    onclick: () => choisir(o.id),
    onkeydown: e => {
      const i = liste.findIndex(x => x.id === o.id);
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        const j = (i + (e.key === 'ArrowRight' ? 1 : liste.length - 1)) % liste.length;
        choisir(liste[j].id); boutons[j].focus();
      }
    },
  }, o.icone ? icone(o.icone) : null,
    o.court ? [h('span', { class: 'bn-onglet__long' }, o.libelle), h('span', { class: 'bn-onglet__court' }, o.court)] : o.libelle,
    o.compte != null && o.compte !== '' ? h('span', { class: 'bn-onglet__compte' }, o.compte) : null));
  barre.append(...boutons);
  const ajuster = new ResizeObserver(() => {
    if (!barre.isConnected) { ajuster.disconnect(); return; }   // barre redessinée par le widget
    barre.classList.remove(...NIVEAUX_ONGLETS);
    for (const n of NIVEAUX_ONGLETS) {
      if (barre.scrollWidth <= barre.clientWidth + 1) break;
      barre.classList.add(n);
    }
  });
  ajuster.observe(barre);
  function choisir(id) {
    liste.forEach((o, i) => {
      boutons[i].setAttribute('aria-selected', String(o.id === id));
      boutons[i].tabIndex = o.id === id ? 0 : -1;
    });
    zone.replaceChildren(liste.find(o => o.id === id).rendu());
    if (surChangement) surChangement(id);
  }
  choisir(liste.some(o => o.id === actif) ? actif : liste[0].id);
  return { barre, zone, choisir };
}

// Bascule (design-system, Bouton) : [[valeur, libellé, icône?], …]. surChoix(valeur) au clic.
// iconesSeules : boutons carrés à icône, le libellé au survol (une ligne serrée). repliable : le libellé s'efface quand le
// conteneur de la ligne manque de place (classe cm-bascule-repliable, règle @container de app/app.css), au survol alors.
export function bascule(etiquette, options, valeur, surChoix, { iconesSeules = false, repliable = false } = {}) {
  return h('div', { class: 'bn-bascule' + (repliable ? ' cm-bascule-repliable' : ''), role: 'group', 'aria-label': etiquette }, options.map(([val, texte, ic]) => h('button', {
    type: 'button', class: 'bn-btn bn-btn--s' + (iconesSeules && ic ? ' bn-btn--icone' : ''), 'data-valeur': String(val), 'aria-pressed': String(valeur === val),
    title: (iconesSeules || repliable) && ic ? `${etiquette} : ${texte}` : null, 'aria-label': (iconesSeules || repliable) && ic ? texte : null, onclick: () => surChoix(val),
  }, ic ? icone(ic) : null, iconesSeules && ic ? null : h('span', {}, texte))));
}

// Section titrée d'une fiche : rien si le contenu est vide.
export function section(titre, ic, ...contenu) {
  const c = contenu.flat(Infinity).filter(Boolean);
  if (!c.length) return null;
  return h('div', { class: 'cm-section' }, h('p', { class: 'etiquette cm-section__titre' }, ic ? icone(ic, 'bn-icone--s') : null, titre), ...c);
}

// Provenance en bas de fiche : « Supplément, p. 12-13 du PDF ».
export function provenance(o) {
  if (!o?.source) return null;
  const pages = o.pages_livre ? `, p. ${o.pages_livre}` : o.pages_pdf ? `, p. ${o.pages_pdf} du PDF` : '';
  return h('p', { class: 'ui-s cm-sourdine' }, o.source + pages);
}

// « original » : ce que disait la source plus basse (le livre), replié.
export function blocOriginal(texte) {
  if (!texte) return null;
  return h('details', { class: 'cm-original-bloc' }, h('summary', { class: 'etiquette' }, 'Version d\'origine'), h('p', { class: 'ui-s' }, texte));
}

export function normaliser(t) {
  return String(t ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

// Écarts entre sources (voir formats/README.md) : applique, conditionnel, a_trancher. Un écart conditionnel est une
// information, repliée avec sa condition en clair : le MJ juge si elle est remplie (plus de case à cocher, 2026-10-23).
export function blocEcarts(ecarts, libelleCondition) {
  if (!ecarts || !ecarts.length) return null;
  return h('div', { class: 'cm-ecarts' }, ecarts.map(e => {
    if (e.statut === 'a_trancher') {
      return alerte('cierge', 'lu-triangle-alert', 'À trancher · ' + e.sujet, e.question || e.texte || '',
        e.original ? h('span', { class: 'cm-original' }, ' Livre : ' + e.original) : null);
    }
    const sousCondition = e.statut === 'conditionnel';
    // Écart appliqué : ouvert, il change la façon de jouer. Sous condition : replié.
    return h('details', { class: 'cm-ecart' + (sousCondition ? ' cm-ecart--condition' : ''), open: !sousCondition },
      h('summary', {},
        badge(e.source, e.source === 'MJ' ? 'sang' : 'ultra'),
        h('span', { class: 'cm-ecart__sujet' }, e.sujet),
        sousCondition ? badge('Sous condition', null) : null),
      h('p', { class: 'cm-ecart__texte' }, e.texte),
      sousCondition ? h('p', { class: 'ui-s cm-sourdine' }, 'Condition : ' + (libelleCondition ? libelleCondition(e.condition) : e.condition)) : null,
      e.original ? h('p', { class: 'ui-s cm-sourdine' }, 'Avant : ' + e.original) : null,
      e.note ? h('p', { class: 'ui-s cm-sourdine' }, e.note) : null);
  }));
}

// Distance de jeu : en pieds, l'équivalent en mètres et en cases (1 case = 5 ft) dans une infobulle ; titre : « Vitesse »…
export function distance(pieds, prefixe = '', titre = null) {
  const m = (pieds * 0.3).toLocaleString('fr-FR', { maximumFractionDigits: 1 });
  const cases = (pieds / 5).toLocaleString('fr-FR', { maximumFractionDigits: 1 });
  return infobulle(h('span', { class: 'cm-distance' }, `${prefixe}${pieds}${FINE}ft`), `${m}${FINE}m · ${cases} case${pieds > 5 ? 's' : ''}`, { titre });
}

// Infobulle (design-system, Infobulle) : au survol ou au focus de l'élément, texte et titre en option.
// Bleue pour une information ; ton 'sang' pour une info importante ou une action importante au clic. Renvoie l'élément.
export function infobulle(el, texte, { titre, ton } = {}) {
  el.dataset.bulle = texte;
  if (titre) el.dataset.bulleTitre = titre;
  if (ton) el.dataset.bulleTon = ton;
  return el;
}

// La couleur d'une infobulle sans ton donné (demande du MJ, 2026-10-23 : elle s'accorde avec l'élément qu'elle détaille) :
// le néon de la charte le plus proche de la couleur du texte de l'élément, sinon de sa bordure, sinon de son fond ; rien (bleu)
// pour un élément neutre (os, cendre, filets : peu saturés).
const NEONS = ['sang', 'ultra', 'brume', 'cierge', 'soleil', 'mousse'];
const enRgb = c => {
  const m = String(c).match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/);
  if (m) return m[4] === '0' ? null : [+m[1], +m[2], +m[3]];
  const x = String(c).trim().match(/^#([0-9a-f]{6})/i);
  return x ? [0, 2, 4].map(i => parseInt(x[1].slice(i, i + 2), 16)) : null;
};
function tonDe(el) {
  const racine = getComputedStyle(document.documentElement);
  const palette = NEONS.map(n => [n, enRgb(racine.getPropertyValue('--' + n))]).filter(([, c]) => c);
  const style = getComputedStyle(el);
  const icone = el.querySelector(':scope > .bn-icone');   // un texte neutre précédé d'une icône de couleur (le coucher du soleil)
  for (const c of [style.color, style.borderTopColor, style.backgroundColor, icone && getComputedStyle(icone).color].map(enRgb)) {
    if (!c || Math.max(...c) - Math.min(...c) < 60) continue;   // neutre : on regarde plus loin
    const [ton, d] = palette.map(([n, p]) => [n, Math.hypot(c[0] - p[0], c[1] - p[1], c[2] - p[2])]).sort((a, b) => a[1] - b[1])[0] || [];
    if (ton && d < 90) return ton === 'brume' ? null : ton;
  }
  return null;
}

// Une seule infobulle pour la page, en popover (au-dessus des dialogues), au-dessus de l'élément survolé (dessous s'il manque de place).
export function activerInfobulles() {
  const bulle = h('div', { class: 'bn-bulle', popover: 'manual', role: 'tooltip' });
  document.body.append(bulle);
  let cible = null;
  const cacher = () => {
    cible = null;
    if (bulle.matches(':popover-open')) bulle.hidePopover();
  };
  const montrer = el => {
    cible = el;
    const { bulle: texte, bulleTitre: titre } = el.dataset;
    const ton = el.dataset.bulleTon || tonDe(el);
    bulle.className = 'bn-bulle' + (ton ? ' bn-bulle--' + ton : '');
    bulle.replaceChildren(...[titre ? h('b', {}, titre) : null, h('span', {}, texte)].filter(Boolean));   // un null s'écrirait « null »
    if (!bulle.matches(':popover-open')) bulle.showPopover();
    const r = el.getBoundingClientRect(), b = bulle.getBoundingClientRect();
    const haut = r.top - b.height - 6 >= 8 ? r.top - b.height - 6 : r.bottom + 6;
    bulle.style.left = Math.round(Math.min(Math.max(8, r.left + r.width / 2 - b.width / 2), innerWidth - b.width - 8)) + 'px';
    bulle.style.top = Math.round(haut) + 'px';
  };
  const viser = e => e.target.closest?.('[data-bulle]') || null;
  document.addEventListener('pointerover', e => { const el = viser(e); if (el !== cible) (el ? montrer(el) : cacher()); });
  document.addEventListener('pointerout', e => { if (!e.relatedTarget) cacher(); });
  document.addEventListener('focusin', e => { const el = viser(e); if (el) montrer(el); });
  document.addEventListener('focusout', cacher);
  document.addEventListener('pointerdown', cacher);
  document.addEventListener('scroll', cacher, true);
}

// Bouton qui ouvre un petit menu de choix juste dessous (design-system, Menu) : [[libellé, titre, action, choisi], …].
// `choisi` (facultatif) : une fonction, relue à chaque ouverture, vraie pour le choix en cours (un filtre) : il est marqué et
// prend le focus. Popover natif : un clic ailleurs ou Échap le referment. Renvoie [bouton, menu], à placer côte à côte.
export function boutonMenu(declencheur, choix, etiquette) {
  const boutons = choix.map(([lib, titre, action, choisi]) => h('button', { type: 'button', class: 'bn-menu__choix',
    role: choisi ? 'menuitemradio' : 'menuitem', title: titre || null, onclick: () => { menu.hidePopover(); action(); } }, lib));
  const menu = h('div', { class: 'bn-menu', popover: 'auto', role: 'menu', 'aria-label': etiquette }, boutons);
  declencheur.popoverTargetElement = menu;
  declencheur.setAttribute('aria-haspopup', 'menu');
  menu.addEventListener('beforetoggle', e => {
    if (e.newState !== 'open') return;
    choix.forEach(([, , , choisi], i) => { if (choisi) boutons[i].setAttribute('aria-checked', String(!!choisi())); });
    const r = declencheur.getBoundingClientRect();
    Object.assign(menu.style, { left: Math.round(r.left) + 'px', top: Math.round(r.bottom + 4) + 'px' });
  });
  // Ouvert : gardé dans l'écran (au-dessus du bouton s'il manque de place dessous) ; le choix en cours, sinon le premier,
  // prend le focus.
  menu.addEventListener('toggle', e => {
    declencheur.setAttribute('aria-expanded', String(e.newState === 'open'));
    if (e.newState !== 'open') return;
    const r = declencheur.getBoundingClientRect(), m = menu.getBoundingClientRect();
    if (m.bottom > innerHeight - 8) menu.style.top = Math.round(r.top - m.height - 4) + 'px';
    if (m.right > innerWidth - 8) menu.style.left = Math.round(innerWidth - m.width - 8) + 'px';
    (menu.querySelector('[aria-checked="true"]') || menu.querySelector('button'))?.focus();
  });
  return [declencheur, menu];
}

// Le même menu, ouvert d'un clic sur autre chose qu'un bouton de menu (un portrait) : posé dans la page sous l'élément,
// retiré à sa fermeture. classe : sa mise en page (cm-menu-etats : trois colonnes, icône et libellé).
export function ouvrirMenu(ancre, choix, etiquette, { classe = '' } = {}) {
  const [, menu] = boutonMenu(ancre, choix, etiquette);
  ancre.popoverTargetElement = null;   // l'ancre n'ouvre pas le menu d'elle-même
  if (classe) menu.classList.add(...classe.split(' '));
  menu.addEventListener('toggle', e => { if (e.newState !== 'open') menu.remove(); });
  document.body.append(menu);
  menu.showPopover();
  return menu;
}

// Jets contre la mort d'un héros à 0 PV (design-system, JetsMort) : à gauche les réussis, à droite les ratés, un crâne
// entre les deux. Stabilisé (trois réussis, ou noté sur la fiche) : le cadre en jaune, un cœur. Trois échecs : le héros est
// mort, marqueMort() à la place. jds : { succes, echecs, stabilise } d'une fiche D&D Beyond (formats/etat.md).
export function jetsContreLaMort({ succes = 0, echecs = 0, stabilise = false } = {}) {
  const stable = stabilise || succes >= 3;
  const etat = stable ? 'stabilise' : echecs >= 3 ? 'mort' : null;
  const texte = stable ? 'Stabilisé' + (succes >= 3 ? ' : trois jets contre la mort réussis' : '') : echecs >= 3 ? 'Mort : trois jets contre la mort ratés'
    : `Jets contre la mort : ${succes} réussi${succes > 1 ? 's' : ''}, ${echecs} raté${echecs > 1 ? 's' : ''}`;
  const serie = (n, sorte) => h('span', { class: `bn-jds__serie bn-jds__serie--${sorte}` }, [0, 1, 2].map(i => h('span', { class: 'bn-jds__pas' + (i < n ? ' est-fait' : '') })));
  return h('span', { class: 'bn-jds', 'data-etat': etat, role: 'img', 'aria-label': texte, title: texte },
    serie(succes, 'reussis'), icone(stable ? 'coeur' : 'crane'), serie(echecs, 'rates'));
}

// Mort (design-system, JetsMort, .bn-mort) : à la place des jets, des PV et de la CA. grand : sur une carte de personnage.
export function marqueMort({ grand = false, titre = 'Mort : trois jets contre la mort ratés' } = {}) {
  return h('span', { class: 'bn-mort' + (grand ? ' bn-mort--grand' : ''), role: 'img', 'aria-label': titre, title: titre }, icone('crane'), h('span', {}, 'Mort'), grand ? icone('crane') : null);
}

// Charges (emplacements de sorts, usages limités) : un losange par charge, vide s'il est disponible, plein s'il a servi.
// Au-delà de 6 charges : un seul losange à moitié plein, suivi du compte disponible (« 9/10 »).
export function jauge(utilises, max, etiquette, couleur = 'cierge') {
  const dispo = Math.max(0, max - utilises);
  const texte = `${etiquette} : ${dispo} disponible${dispo > 1 ? 's' : ''} sur ${max}`;
  const pas = max > 6
    ? [h('span', { class: 'cm-jauge__pas' + (dispo === 0 ? ' est-utilise' : utilises > 0 ? ' est-moitie' : '') }), h('span', { class: 'cm-jauge__compte' }, `${dispo}/${max}`)]
    : Array.from({ length: max }, (_, i) => h('span', { class: 'cm-jauge__pas' + (i < utilises ? ' est-utilise' : '') }));
  return h('span', { class: `cm-jauge cm-jauge--${couleur}`, role: 'img', 'aria-label': texte, title: texte }, pas);
}

// Fenêtre flottante (design-system, Flottant) : non modale, déplaçable par sa tête.
// Une seule fenêtre par clé : rouvrir la ramène devant et remplace son contenu. Renvoie { el, maj(contenu), fermer }.
// Une ligne de liste qui ouvre une fenêtre porte data-flottant="<clé>" (lienFlottant) : elle a .est-ouvert tant que sa
// fenêtre est ouverte.
const flottants = new Map();
let devant = 900;
// Redessiner une fenêtre déjà ouverte sans la ramener devant ni la rouvrir si elle est réduite : une fenêtre ouverte par le
// MJ, elle, revient devant. sansRamener(() => ouvrirJalon(j)) : tout appel à flottant() fait dedans est un simple rafraîchissement.
let rafraichissements = 0;
export function sansRamener(fn) {
  rafraichissements++;
  try { return fn(); } finally { rafraichissements--; }
}
// Dernier clic (ou toucher) : une fenêtre ouverte juste après se place de son côté, à mi-chemin du centre de l'écran.
let dernierClic = null;
document.addEventListener('pointerdown', e => { dernierClic = { x: e.clientX, y: e.clientY, t: performance.now() }; }, true);
const marquerLignes =(cle, ouvert) => document.querySelectorAll(`[data-flottant="${CSS.escape(cle)}"]`).forEach(e => e.classList.toggle('est-ouvert', ouvert));
export function lienFlottant(el, cle) {
  el.dataset.flottant = cle;
  el.classList.toggle('est-ouvert', flottants.has(cle));
  return el;
}
// compact : tête resserrée, petit titre, corps sans marge (une carte, une image qui doit tenir à l'écran).
// depuis : élément d'où la fenêtre semble ouverte (une ligne amenée en vue par un autre widget), à la place du dernier clic.
// plein : toute la fenêtre du navigateur, posée en haut à gauche (une vue d'ensemble), sans placement au clic.
// surFermeture : appelée quand la fenêtre se ferme (une rencontre tirée pas lancée est abandonnée).
// fermable : faux pour une fenêtre qu'on ne doit pas perdre (une activité en cours) : ni croix ni Échap, elle se réduit seulement.
// miniature (adresse d'une image) ou pictogramme (nom d'une icône) : le repère de sa barre de titre, une fois la fenêtre réduite.
export function flottant(cle, { surtitre, titre, contenu, largeur, compact = false, depuis = null, plein = false, surFermeture = null, fermable = true, miniature = null, pictogramme = null }) {
  const deja = flottants.get(cle);
  if (deja) {
    deja.maj(contenu, titre, surtitre);
    deja.majRepere(miniature, pictogramme);
    if (!rafraichissements) { deja.restaurer(); deja.avant(); }
    if (surFermeture) deja.surFermeture = surFermeture;
    return deja;
  }
  const titres = h('div', { class: 'bn-panel__titres' });
  const corps = h('div', { class: 'bn-panel__corps' });
  const repere = h('span', { class: 'bn-flottant__repere', 'aria-hidden': 'true' });
  const btnReduire = bouton('', { icone: 'lu-chevron-up', titre: 'Réduire à la barre de titre', classe: 'bn-btn--s bn-btn--fantome bn-flottant__reduire', onclick: () => basculerReduite() });
  const tete = h('div', { class: 'bn-panel__tete' }, repere, titres, btnReduire,
    fermable ? bouton('', { icone: 'lu-x', titre: 'Fermer', classe: 'bn-btn--s bn-btn--fantome', onclick: () => fermer() }) : null);
  const el = h('dialog', { class: 'bn-flottant' + (compact ? ' bn-flottant--compact' : '') + (plein ? ' bn-flottant--plein' : ''), 'aria-label': titre }, h('div', { class: 'bn-panel' }, tete, corps));
  if (largeur && !plein) el.style.width = `min(${largeur}px, calc(100vw - 32px))`;
  document.body.append(el);
  // Ouverte depuis un dialogue modal (fiche d'un PNJ depuis une confirmation…) : modale elle aussi, sinon elle resterait
  // derrière, inerte. Fond transparent (CSS) : on voit toujours le dialogue dessous.
  // Le dialogue refermé, elle redevient une fenêtre ordinaire, à la même place.
  const modal = document.querySelector('dialog:modal');
  if (modal) {
    el.showModal();
    btnReduire.hidden = true;   // une fenêtre modale reste entière : le reste de la page est inerte
    modal.addEventListener('close', () => {
      if (!el.isConnected || !el.open) return;
      const { left, top } = el.style;
      el.close();
      el.show();
      Object.assign(el.style, { left, top });
      btnReduire.hidden = false;
    }, { once: true });
  } else el.show();
  el.addEventListener('cancel', e => { e.preventDefault(); if (fermable) fermer(); });
  // Position de départ : en cascade, à droite du centre.
  const n = flottants.size;
  const placer = (x, y) => {
    const r = el.getBoundingClientRect();
    el.style.left = Math.min(Math.max(8, x), innerWidth - Math.min(r.width, innerWidth) - 8) + 'px';
    el.style.top = Math.max(8, Math.min(y, innerHeight - r.height - 8)) + 'px';
  };
  const avant = () => {
    flottants.forEach(f => f.el.classList.remove('est-devant'));
    el.style.zIndex = String(++devant);
    el.classList.add('est-devant');
  };
  el.addEventListener('pointerdown', avant);
  el.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); if (fermable) fermer(); } });
  // Réduire : bouton chevron, ou double-clic sur la tête (hors boutons), comme un widget.
  tete.addEventListener('dblclick', e => { if (!e.target.closest('button, a, input, select')) basculerReduite(); });
  tete.addEventListener('pointerdown', e => {
    if (e.button !== 0 || e.target.closest('button, a, input, select')) return;
    const dx = e.clientX - el.offsetLeft, dy = e.clientY - el.offsetTop;
    tete.setPointerCapture(e.pointerId);
    el.classList.add('est-saisi');
    const bouger = ev => placer(ev.clientX - dx, ev.clientY - dy);
    const lacher = () => { el.classList.remove('est-saisi'); tete.removeEventListener('pointermove', bouger); tete.removeEventListener('pointerup', lacher); };
    tete.addEventListener('pointermove', bouger);
    tete.addEventListener('pointerup', lacher);
  });
  function maj(c, t = titre, st = surtitre) {
    titres.replaceChildren(...[st ? h('span', { class: 'surtitre' }, st) : null, h('h2', { class: 'titre-m' }, t)].filter(Boolean));   // un null s'écrirait « null »
    el.setAttribute('aria-label', t);
    const haut = corps.scrollTop;
    corps.replaceChildren(...[c].flat().filter(Boolean));
    corps.scrollTop = haut;
  }
  function fermer() { el.remove(); flottants.delete(cle); marquerLignes(cle, false); f.surFermeture?.(); }
  function majRepere(m, p) {
    if (!m && !p) return;
    repere.replaceChildren(m ? h('img', { src: m, alt: '', referrerpolicy: 'no-referrer' }) : icone(p));
  }
  // Réduite (demande du MJ, 2026-11-01) : elle reste à sa place, à sa largeur, à la hauteur de sa barre de titre, et se déplace
  // toujours ; son contenu reste à jour, seulement caché.
  function basculerReduite(oui = !f.reduite) {
    if (oui === f.reduite || (oui && el.matches(':modal'))) return;
    f.reduite = oui;
    el.classList.toggle('est-reduite', oui);
    const titre = oui ? 'Déplier' : 'Réduire à la barre de titre';
    btnReduire.title = titre;
    btnReduire.setAttribute('aria-label', titre);
    btnReduire.setAttribute('aria-expanded', String(!oui));
    btnReduire.replaceChildren(icone(oui ? 'lu-chevron-down' : 'lu-chevron-up'));
  }
  const restaurer = () => basculerReduite(false);
  const f = { el, maj, fermer, avant, surFermeture, reduite: false, restaurer, majRepere };
  flottants.set(cle, f);
  marquerLignes(cle, true);
  majRepere(miniature, pictogramme);
  maj(contenu);
  // Ouverte par un clic : entre le centre de l'écran et le clic (à gauche ou à droite, selon où il a eu lieu), un peu au-dessus
  // de lui ; décalée si une autre fenêtre est déjà là. Sinon (ouverte d'elle-même) : en cascade, à droite du centre.
  const r = depuis?.isConnected ? depuis.getBoundingClientRect() : null;
  const clic = r?.height ? { x: r.left + r.width / 2, y: r.top + r.height / 2 }
    : dernierClic && performance.now() - dernierClic.t < 1500 ? dernierClic : null;
  if (plein) placer(16, 16);
  else if (clic) {
    let x = (innerWidth / 2 + clic.x) / 2 - el.offsetWidth / 2, y = clic.y - 60;
    while ([...flottants.values()].some(o => o.el !== el && Math.abs(o.el.offsetLeft - x) < 12 && Math.abs(o.el.offsetTop - y) < 12)) { x += 28; y += 28; }
    placer(x, y);
  } else placer(innerWidth / 2 - el.offsetWidth / 2 + 40 + n * 28, 80 + n * 28);
  // Contenu qui grandit après coup (image chargée, résumé ajouté) : la fenêtre se replace pour rester dans l'écran.
  const garde = new ResizeObserver(() => { if (el.isConnected) placer(el.offsetLeft, el.offsetTop); else garde.disconnect(); });
  garde.observe(el);
  avant();
  return f;
}
export const flottantOuvert = cle => flottants.get(cle) || null;

// Une image en très grand, par-dessus toute l'interface et en plein écran si le navigateur le permet (montrer un monstre
// ou une image de la galerie aux joueurs, demande du MJ, 2026-10-25) : fond noir, l'image aussi grande que l'écran le
// permet, sa légende dessous. Un clic, Échap ou la croix la ferment. distante : une image d'un autre site (D&D Beyond),
// chargée sans référent comme ailleurs.
// L'écran des joueurs (plugin app/plugins/ecran-joueurs.js, quand il est actif) : fn(src, legende) y montre l'image ; un bouton
// de plus dans la fenêtre « en grand ». null : plus d'écran des joueurs.
let versEcranJoueurs = null;
export function brancherEcranJoueurs(fn) { versEcranJoueurs = fn; }
export const ecranJoueursActif = () => !!versEcranJoueurs;
// Montrer une image sur l'écran des joueurs (vrai si le plugin est là) : d'où que vienne l'image (demande du MJ, 2026-11-03 :
// portrait d'un héros, illustration d'un monstre, image d'un lieu ou de la bibliothèque…). La légende sert au MJ, pas aux joueurs.
export function montrerAuxJoueurs(src, legende = '') { if (!versEcranJoueurs || !src) return false; versEcranJoueurs(src, legende); return true; }
// Un panneau des quêtes (app/panneau-quetes.js) sur l'écran des joueurs, par-dessus comme une image (widget Quêtes).
// infos() : { rapport (largeur / hauteur de l'écran des joueurs), rotation(id) (celle qu'aurait ce panneau à l'écran) }, pour
// que l'aperçu du MJ ait la forme de ce que verront les joueurs.
let versPanneauJoueurs = null, infosPanneauJoueurs = null;
export function brancherPanneauJoueurs(fn, infos = null) { versPanneauJoueurs = fn; infosPanneauJoueurs = fn ? infos : null; }
export const ecranPanneauInfos = () => infosPanneauJoueurs?.() || { rapport: 16 / 9, rotation: () => 0 };
export function montrerPanneauAuxJoueurs(p) { if (!versPanneauJoueurs || !p) return false; versPanneauJoueurs(p); return true; }
// Le bouton qui le fait : une icône de diffusion (façon Chromecast, demande du MJ, 2026-11-03), à poser en haut à droite
// d'une image par avecEcranJoueurs() ; null quand le plugin n'est pas actif (rien à proposer).
export function boutonEcranJoueurs(src, legende = '', { classe = 'bn-btn--s bn-btn--icone cm-cast__btn' } = {}) {
  if (!versEcranJoueurs || !src) return null;
  return bouton('', { icone: 'lu-cast', classe, titre: 'Diffuser sur l\'écran des joueurs', onclick: e => { e.stopPropagation(); e.preventDefault(); montrerAuxJoueurs(src, legende); } });
}
// Une image (ou son cadre) avec l'icône de diffusion dans son coin haut droit, montrée au survol seulement (retour du MJ,
// 2026-11-05) ; l'élément tel quel sans le plugin. Un cadre (span, div) reçoit l'icône en enfant, sans rien changer à sa
// place dans la page (un enrobage décalait le rond d'inspiration du portrait d'une fiche) ; un bouton ou une image, qui
// ne peuvent pas la contenir, sont enrobés d'un cadre à leur taille.
export function avecEcranJoueurs(el, src, legende = '') {
  const btn = boutonEcranJoueurs(src, legende);
  if (!btn) return el;
  if (el.tagName === 'BUTTON' || el.tagName === 'IMG') return h('span', { class: 'cm-cast cm-cast--enrobe' }, el, btn);
  el.classList.add('cm-cast');
  el.append(btn);
  return el;
}
// L'icône calée sur l'image elle-même quand celle-ci ne remplit pas son cadre (object-fit: contain, centrée en haut) :
// à appeler avec le cadre, son image et l'icône ; recalé au chargement de l'image et à chaque survol.
export function calerIconeSurImage(cadre, img, btn) {
  if (!btn) return;
  const caler = () => {
    const w = cadre.clientWidth, hh = cadre.clientHeight;
    if (!w || !hh || !img.naturalWidth) return;
    const largeur = Math.min(w, hh * img.naturalWidth / img.naturalHeight);
    btn.style.right = `${Math.round((w - largeur) / 2) + 4}px`;
  };
  img.addEventListener('load', caler);
  cadre.addEventListener('pointerenter', caler);
}

export function afficherEnGrand(src, { legende = '', distante = false } = {}) {
  if (!src) return;
  let ferme = false;
  const fermer = () => {
    if (ferme) return;
    ferme = true;
    if (document.fullscreenElement === dlg) document.exitFullscreen().catch(() => {});
    dlg.close();
    dlg.remove();
  };
  const dlg = h('dialog', { class: 'cm-plein-ecran', 'aria-label': legende || 'Image en grand', onclick: fermer, oncancel: e => { e.preventDefault(); fermer(); } },
    h('img', { class: 'cm-plein-ecran__image', src, alt: legende, ...(distante ? { referrerpolicy: 'no-referrer' } : {}) }),
    legende ? h('p', { class: 'cm-plein-ecran__legende' }, legende) : null,
    versEcranJoueurs ? bouton('', { icone: 'lu-cast', titre: 'Diffuser sur l\'écran des joueurs', classe: 'bn-btn--s cm-plein-ecran__joueurs',
      onclick: e => { e.stopPropagation(); versEcranJoueurs(src, legende); fermer(); } }) : null,
    bouton('', { icone: 'lu-x', titre: 'Fermer', classe: 'bn-btn--s bn-btn--fantome cm-plein-ecran__fermer' }));
  dlg.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement) fermer(); });   // Échap quitte le plein écran : on ferme aussi
  document.body.append(dlg);
  dlg.showModal();
  dlg.requestFullscreen?.().catch(() => {});   // refusé (pas de geste de l'utilisateur…) : la fenêtre couvre quand même la page
}

// Valider au clavier un champ de texte à plusieurs lignes (demande du MJ, 2026-11-05) : Entrée y passe à la ligne ; avec
// Ctrl (ou Cmd) enfoncé, le bouton de validation du champ montre la touche (« Entrée Enregistrer »), et Ctrl + Entrée le
// déclenche. Le bouton est le bouton principal (`bn-btn--primaire`) de la fenêtre, du dialogue ou du panneau du champ, celui
// du pied d'abord ; un champ sans bouton (une note enregistrée d'elle-même) ne change pas. Posé une fois pour toute la page.
if (typeof document !== 'undefined') {
  const champDe = el => (el instanceof HTMLTextAreaElement && !el.readOnly && !el.disabled ? el : null);
  const boutonDe = champ => {
    for (let cadre = champ.parentElement; cadre; cadre = cadre.parentElement) {
      if (!cadre.matches('dialog, form, .bn-panel, .bn-flottant, .bn-carte, .cm-pile, .bn-widget__corps')) continue;
      const boutons = [...cadre.querySelectorAll('button.bn-btn--primaire:not([disabled])')].filter(b => b.offsetParent !== null);
      if (boutons.length) return boutons.find(b => b.closest('.bn-panel__pied')) || boutons.at(-1);
      if (cadre.matches('dialog, .bn-flottant, .bn-widget__corps')) return null;   // pas plus loin que la fenêtre du champ
    }
    return null;
  };
  let marque = null;
  const retirer = () => { marque?.touche.remove(); marque?.btn.classList.remove('est-raccourci'); marque = null; };
  const montrer = champ => {
    const btn = boutonDe(champ);
    if (!btn) { retirer(); return; }
    if (marque?.btn === btn && btn.contains(marque.touche)) return;
    retirer();
    const touche = h('kbd', { class: 'cm-touche', 'aria-hidden': 'true' }, 'Entrée');
    btn.prepend(touche);
    btn.classList.add('est-raccourci');
    marque = { btn, touche };
  };
  // Ctrl seul (pas AltGr, qui vaut Ctrl + Alt sur un clavier français : @, #, { se tapent ainsi).
  const ctrl = e => (e.ctrlKey || e.metaKey) && !e.altKey && !e.getModifierState?.('AltGraph');
  document.addEventListener('keydown', e => {
    const champ = champDe(document.activeElement);
    if (!champ || !ctrl(e)) { if (marque) retirer(); return; }
    if (e.key === 'Enter') {
      const btn = boutonDe(champ);
      if (!btn) return;
      e.preventDefault();
      champ.dispatchEvent(new Event('change', { bubbles: true }));   // un champ lu à son `change` est à jour avant la validation
      retirer();
      btn.click();
      return;
    }
    montrer(champ);
  }, true);
  document.addEventListener('keyup', e => { if (marque && !ctrl(e)) retirer(); }, true);
  document.addEventListener('focusout', retirer, true);
  window.addEventListener('blur', retirer);
}

export function heure(iso) {
  const d = new Date(iso);
  const jour = d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  // Une date seule (« 2026-10-21 », notée par le bloc maj-etat de fin de session) : pas d'heure.
  return /T/.test(iso) ? jour + ' · ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : jour;
}

export function identifiant() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
